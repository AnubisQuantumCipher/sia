# Fresh committed response-harness reproduction

Exact commit: 1292d328ebc27680a040a263a7445cb04b2d82bd. The source comes from its
committed spark archive with no overlay; every archived file matches the retained
pinned Git blob identity and source hash. The reviewed response harness and strict
project profile match their recorded identities.

The strict project build, all fifteen original Ada runtime harnesses and complete
response-harness proof passed under unchanged limits. The proof reports 90 checks,
zero justified/unproved checks and all nine intended declaration locations. Raw
channels and explicit assumption/exclusion lists are retained. Ordinary modular
assumptions remain. No focused proof or full-project proof was run in this fresh
reproduction. Full-project and installed acceptance remain OPEN.

This versioned package is separate from the earlier single-overlay development
repair package. The earlier timeout remains FAILED historical evidence. No result
here turns response-unit proof into whole-project or installed-system acceptance.

The bundle omits compiled objects, binaries, solver sessions and unrelated/private
storage inventory. storage-observations.json includes only relevant retained local
capacity/reserve/pin observations and the private source report hash; it makes no
backup or recovery-health claim.

For portable byte reproduction, keep the tar.gz and JSON sidecar beside the files
extracted from the tar.gz and run `python3 -B retainer.py --check`. That read-only
mode reconstructs and compares both complete files using explicitly selected,
bounded inputs. It runs no build, test, proof or service command. This Python
retainer is packaging orchestration, not a verified authority or proof-policy core.

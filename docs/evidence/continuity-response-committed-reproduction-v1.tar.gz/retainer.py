#!/usr/bin/env python3
"""Reproduce bounded committed-response packaging; no proof or service is run."""
from pathlib import Path
import argparse
import gzip
import hashlib
import io
import json
import re
import stat
import tarfile

ROOT=Path(__file__).resolve().parent
PIN='1292d328ebc27680a040a263a7445cb04b2d82bd'
BUNDLE='continuity-response-committed-reproduction-v1.tar.gz'
MANIFEST='CONTINUITY-RESPONSE-COMMITTED-EVIDENCE-V1.json'
TARGET='spark/tests/continuity_response_wire_tests.adb'
HARNESS_SHA='cf2ebb5c07b90a3c2cacc5829ef29a31be25b2fe83598e587755e5727a11dace'
PROJECT_SHA='d439a1e2908c70643c951d296294a87c3ba2756be6b1d0bb4c9a6bd4814ebe49'
MAX_MEMBERS=256
MAX_FILE_BYTES=16_777_216
MAX_INPUT_BYTES=33_554_432
ROOT_NAMES=('driver.py','launch.sh','source.tar','source-binding.json','archive-correspondence.json','receipt.json','source-hashes-before.json','source-hashes-after.json','tool-hashes-before.json','tool-hashes-after.json','tool-paths.json')
COMMANDS=tuple(name+suffix for name in ('head','archive','extract','inherited-tool-manifest','gnatprove-version','gprbuild-version','gnatls-version','gcc-version') for suffix in ('.command.json','.exit','.stderr','.stdout'))
RUNTIMES=('policy','transaction','request_wire','request_admission','grant_lifetime','retraction','consolidation','continuity','continuity_transition','continuity_record_wire','continuity_observation_wire','continuity_checkpoint_wire','continuity_current_wire','continuity_frame_wire','continuity_response_wire')
STAGES=('strict-build',)+tuple(name+'-runtime' for name in RUNTIMES)+('complete-response-harness',)
DECLARATIONS=(('Continuity_Response_Wire_Tests',7),('Continuity_Response_Wire_Tests.Refuse',28),('Continuity_Response_Wire_Tests.Check_Literal_Results',44),('Continuity_Response_Wire_Tests.Check_Unused_Values',69),('Continuity_Response_Wire_Tests.Check_Unused_Families',90),('Continuity_Response_Wire_Tests.Check_Header',99),('Continuity_Response_Wire_Tests.Check_Codes',127),('Continuity_Response_Wire_Tests.Check_Reserved',150),('Continuity_Response_Wire_Tests.Check_Process_Correlation',161))


def require(condition,message):
    if not condition:
        raise ValueError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def encoded(value):
    return (json.dumps(value,indent=2,sort_keys=True,ensure_ascii=True)+'\n').encode()


def unique_pairs(pairs):
    result={}
    for key,value in pairs:
        require(key not in result,'duplicate JSON key')
        result[key]=value
    return result


def decoded(data):
    def bad_constant(value):
        raise ValueError('non-JSON numeric constant: '+value)
    return json.loads(data,object_pairs_hook=unique_pairs,parse_constant=bad_constant)


def selected_inputs():
    names=list(ROOT_NAMES+COMMANDS)
    for stage in STAGES:
        names.extend(stage+'/'+name for name in ('command','command.json','exit','result.json','stdout','stderr'))
    names.extend(('complete-response-harness/inspection.json','complete-response-harness/raw/gnatprove.out','complete-response-harness/raw/continuity_response_wire_tests.spark'))
    require(len(names)==len(set(names)) and len(names)<MAX_MEMBERS,'invalid fixed member roster')
    return sorted('committed/'+name for name in names)


def read_member(name):
    path=ROOT/name
    require(not Path(name).is_absolute() and '..' not in Path(name).parts,'unsafe member path')
    for part in (path,)+tuple(path.parents):
        if part==ROOT.parent:
            break
        require(not part.is_symlink(),'symlink member or parent')
    before=path.stat()
    require(stat.S_ISREG(before.st_mode) and before.st_size<=MAX_FILE_BYTES,'input type/size bound')
    data=path.read_bytes()
    after=path.stat()
    require((before.st_ino,before.st_size,before.st_mtime_ns,before.st_ctime_ns)==(after.st_ino,after.st_size,after.st_mtime_ns,after.st_ctime_ns),'input changed during read')
    require(len(data)==before.st_size,'input length changed')
    return data


def load_members():
    selected=selected_inputs()
    require(decoded(read_member('selected-members.json'))==selected,'selection record differs from fixed names')
    members={}
    total=0
    for name in selected+['retainer.py','selected-members.json','README.md','storage-observations.json']:
        data=read_member(name)
        total+=len(data)
        require(total<=MAX_INPUT_BYTES,'aggregate input bound')
        members[name]=data
    return members


def verify_archive(members,binding):
    raw=members['committed/source.tar']
    require(sha(raw)==binding['archive_sha256'],'source archive hash mismatch')
    before=decoded(members['committed/source-hashes-before.json'])
    after=decoded(members['committed/source-hashes-after.json'])
    correspondence=decoded(members['committed/archive-correspondence.json'])
    require(before==after,'archived source changed during reproduction')
    require(correspondence['commit']==PIN and correspondence['archive_sha256']==sha(raw),'archive correspondence binding mismatch')
    expected=correspondence['git_source_objects']
    verified={}
    harness=None
    with tarfile.open(fileobj=io.BytesIO(raw),mode='r:') as archive:
        require(archive.pax_headers.get('comment')==PIN,'Git archive commit marker mismatch')
        for count,member in enumerate(archive):
            require(count<512,'source archive member bound')
            require((member.name=='spark' and member.isdir()) or member.name.startswith('spark/'),'source archive scope')
            require('..' not in Path(member.name).parts,'source archive path escape')
            require('/obj/' not in member.name and '/bin/' not in member.name and 'why3' not in member.name,'generated output in source archive')
            if member.isdir():
                continue
            require(member.isfile() and member.name in before and member.size<=MAX_FILE_BYTES,'source archive member type/size')
            require(member.name not in verified,'duplicate source archive entry')
            data=archive.extractfile(member).read()
            require(sha(data)==before[member.name],'archived source hash mismatch')
            identity=hashlib.sha1(('blob '+str(len(data))+'\0').encode()+data).hexdigest()
            require(identity==expected[member.name],'pinned Git blob identity mismatch')
            verified[member.name]=identity
            if member.name==TARGET:
                harness=data
            if member.name=='spark/sia_assurance.gpr':
                require(sha(data)==PROJECT_SHA,'original strict project profile changed')
    require(verified==expected and set(verified)==set(before),'archive/source/Git rosters differ')
    require(harness is not None and sha(harness)==HARNESS_SHA,'reviewed response harness mismatch')
    return harness


def verify_sequence(members,binding):
    receipt=decoded(members['committed/receipt.json'])
    paths=decoded(members['committed/tool-paths.json'])
    require(receipt['commit']==PIN and receipt['overlay']==[] and binding['overlay']==[],'committed/no-overlay identity mismatch')
    require([row['name'] for row in receipt['checks']]==list(STAGES),'build/runtime/proof roster differs')
    common=[paths['gnatprove'],'-P','spark/sia_assurance.gpr','-u','continuity_response_wire_tests.adb','--mode=all','--assumptions','--no-inlining','--memlimit=512','--timeout=10','-j1']
    for stage,row in zip(STAGES,receipt['checks']):
        prefix='committed/'+stage+'/'
        require(row==decoded(members[prefix+'result.json']),'stage result and receipt differ')
        require(row['exit']==0 and row['passed'] and int(members[prefix+'exit'])==0,'retained check did not pass')
        if stage=='strict-build':
            command=[paths['gprbuild'],'-p','-P','spark/sia_assurance.gpr']
            seconds='120s'
        elif stage=='complete-response-harness':
            command=common
            seconds='120s'
        else:
            command=['spark/bin/'+stage.removesuffix('-runtime')+'_tests']
            seconds='30s'
        expected=[paths['timeout'],'--kill-after=5s',seconds]+command
        require(row['command']==expected==decoded(members[prefix+'command.json']),'check command/caps differ')
    require(receipt['scoped_sequence_passed'] and receipt['tool_rosters_equal'] and receipt['archived_sources_unchanged'],'receipt correspondence refused')
    before=decoded(members['committed/tool-hashes-before.json'])
    require(before==decoded(members['committed/tool-hashes-after.json']),'tool identities changed')
    inherited=decoded(members['committed/inherited-tool-manifest.stdout'])['receipt']['proof_tools_before']
    require(all(before[name]==value for name,value in inherited.items()),'inherited tool identities differ')
    store=decoded(members['storage-observations.json'])
    require(store['storage_preflight_exit']==0 and store['matching_evidence_pins'],'recorded storage preflight/pin refused')
    require(store['final_free_bytes']==receipt['free_after_bytes']>=store['configured_local_reserve_bytes'],'recorded final reserve mismatch')
    return receipt


def verify_response_scope(members,harness):
    prefix='committed/complete-response-harness/raw/'
    data=decoded(members[prefix+'continuity_response_wire_tests.spark'])
    summary=members[prefix+'gnatprove.out'].decode()
    totals=[line for line in summary.splitlines() if line.startswith('Total ')]
    require(len(totals)==1,'missing/duplicate summary total')
    fields=re.sub(r'\([0-9]+%\)','',totals[0]).split()
    require(fields[-2:]==['.','.'] and int(fields[1])==90,'unexpected complete response total or unclosed checks')
    require(data['stop_reason']=='STOP_REASON_NONE','raw report incomplete')
    for key in ('pragma_assume','skip_proof','skip_flow_proof'):
        require(data[key]==[],'explicit assumption/exclusion')
    for channel in ('warn_error','flow','proof'):
        require(isinstance(data[channel],list),'raw diagnostic channel type')
        require(all(isinstance(item,dict) and item.get('severity') in ('info','information') for item in data[channel]),'non-information raw diagnostic')
    covered=[]
    for key,state in data['spark'].items():
        require(state=='all','partial entity analysis')
        item=data['entities'][key]
        require(len(item['sloc'])==1 and item['sloc'][0]['file']=='continuity_response_wire_tests.adb','unexpected entity location')
        covered.append((item['name'],item['sloc'][0]['line']))
    declared=[]
    for line,text in enumerate(harness.decode().splitlines(),1):
        match=re.match(r'\s*procedure\s+(\w+)',text)
        if match:
            short=match.group(1)
            declared.append((short if short=='Continuity_Response_Wire_Tests' else 'Continuity_Response_Wire_Tests.'+short,line))
    require(sorted(covered)==sorted(DECLARATIONS)==sorted(declared),'nine declaration/source/report locations differ')
    original=decoded(members['committed/complete-response-harness/inspection.json'])
    require(original['reported_total']==90 and sorted(tuple(row) for row in original['covered_declarations'])==sorted(covered),'retained scope inspection differs')
    return {'unit':'continuity_response_wire_tests','reported_total':int(fields[1]),'total_row':totals[0],'justified':0,'unproved':0,'source_declarations':declared,'reported_all_entities':covered,'raw_diagnostics':'No non-information warn_error/flow/proof entries','pragma_assume':[],'skip_proof':[],'skip_flow_proof':[],'assumptions':'Ordinary modular dependencies retained verbatim in raw report and summary','full_project_coverage':'NOT ESTABLISHED'}


def compressed_tar(members):
    require(len(members)<=MAX_MEMBERS,'bundle member bound')
    buffer=io.BytesIO()
    with tarfile.open(fileobj=buffer,mode='w',format=tarfile.USTAR_FORMAT) as archive:
        for name,data in sorted(members.items()):
            require(len(name.encode())<=100,'USTAR name bound')
            entry=tarfile.TarInfo(name)
            entry.size=len(data)
            entry.mode=0o644
            entry.uid=entry.gid=entry.mtime=0
            entry.uname=entry.gname=''
            archive.addfile(entry,io.BytesIO(data))
    require(buffer.tell()<=MAX_INPUT_BYTES+1_048_576,'tar output bound')
    output=io.BytesIO()
    with gzip.GzipFile(filename='',mode='wb',fileobj=output,compresslevel=9,mtime=0) as stream:
        stream.write(buffer.getvalue())
    return output.getvalue()


def manifest_for(members,bundle,binding,receipt,scope):
    return {
        'schema_version':1,
        'kind':'FRESH COMMITTED COMPLETE RESPONSE-HARNESS REPRODUCTION; scoped conditional proof only',
        'source':binding,
        'members':[{'path':name,'bytes':len(data),'sha256':sha(data)} for name,data in sorted(members.items())],
        'bundle':{'path':'docs/evidence/'+BUNDLE,'bytes':len(bundle),'sha256':sha(bundle)},
        'checks':receipt['checks'],
        'complete_response_harness_scope':scope,
        'tool_rosters_equal':receipt['tool_rosters_equal'],
        'archived_sources_unchanged':receipt['archived_sources_unchanged'],
        'overlay':[],
        'prior_development_evidence':{
            'path':'docs/CONTINUITY-RESPONSE-HARNESS-REPAIR-EVIDENCE-V1.json',
            'sha256':'f1ad7d6d1ec154486dc244eeddb482def3c567290507866e13d2911a28d3c568',
            'scope':'Separate committed-base plus single-overlay repair evidence, including historical timeout; never relabeled by this reproduction'},
        'full_project_proof':'UNRUN for this commit; inherited failed all-unit proof remains OPEN',
        'installed_continuity_and_protected_authority':'OPEN; no installed action or authority grant',
        'scope_limits':[
            'The complete response unit is distinct from all-project proof coverage.',
            'Ordinary modular dependencies and toolchain/runtime assumptions remain.',
            'Source correspondence and retained commands do not establish producer authenticity or system correctness.',
            'This retainer checks correspondence and deterministic packaging; it replays no proof/build/test.',
            'Original normative Power of Ten remains authoritative; no whole-system compliance or certification follows.'],
        'retainer':{
            'member':'retainer.py','command':'python3 -B retainer.py --check',
            'selection':'Fixed explicit names; bounded regular-file input; no directory crawl',
            'tar':'USTAR; sorted names; mode0644; uid/gid/mtime0; empty owner names',
            'gzip':'level9; mtime0; empty filename'},
        'storage':decoded(members['storage-observations.json'])}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    mode=parser.add_mutually_exclusive_group(required=True)
    mode.add_argument('--write',action='store_true')
    mode.add_argument('--check',action='store_true')
    args=parser.parse_args()
    members=load_members()
    binding=decoded(members['committed/source-binding.json'])
    require(binding['commit']==PIN,'wrong committed source')
    harness=verify_archive(members,binding)
    receipt=verify_sequence(members,binding)
    scope=verify_response_scope(members,harness)
    bundle=compressed_tar(members)
    manifest=encoded(manifest_for(members,bundle,binding,receipt,scope))
    if args.write:
        with (ROOT/BUNDLE).open('xb') as stream:
            stream.write(bundle)
        with (ROOT/MANIFEST).open('xb') as stream:
            stream.write(manifest)
    else:
        require(read_member(BUNDLE)==bundle,'bundle bytes do not reproduce')
        require(read_member(MANIFEST)==manifest,'manifest bytes do not reproduce')
    print(json.dumps({'status':'REPRODUCED_BYTES' if args.check else 'WROTE_COMMITTED_SCOPED_EVIDENCE','bundle':str(ROOT/BUNDLE),'bundle_sha256':sha(bundle),'manifest':str(ROOT/MANIFEST),'manifest_sha256':sha(manifest),'members':len(members),'commit':PIN,'full_project_acceptance':False},sort_keys=True))

if __name__=='__main__':
    main()

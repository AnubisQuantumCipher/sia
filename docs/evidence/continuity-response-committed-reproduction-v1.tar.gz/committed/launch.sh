#!/usr/bin/env bash
set -euo pipefail
if [[ $# != 1 || ! $1 =~ ^[0-9a-f]{40}$ ]]; then
    printf 'usage: launch.sh OWNER_SUPPLIED_FULL_COMMIT_SHA\n' >&2
    exit 2
fi
source /home/sicarii/opt/gnat/env.sh
exec flock -n -E 75 /home/sicarii/.worldline-heavy.lock python3 -B \
    /home/sicarii/Work/sia-assurance-evidence-20261019/takeover-response-committed-reproduction-v1/driver.py \
    --commit "$1"

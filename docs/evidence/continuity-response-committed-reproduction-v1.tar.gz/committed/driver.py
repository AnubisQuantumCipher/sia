#!/usr/bin/env python3
"""Committed response-harness reproduction; run only after owner supplies SHA."""
from pathlib import Path
import argparse
import hashlib
import json
import os
import platform
import re
import shlex
import shutil
import subprocess
import time

OUT=Path(__file__).resolve().parent
REPO=Path('/home/sicarii/Work/sia-assurance-kernel-20261019')
RESERVE=10_000_000_000
TARGET='spark/tests/continuity_response_wire_tests.adb'
EXPECTED_HARNESS_SHA='cf2ebb5c07b90a3c2cacc5829ef29a31be25b2fe83598e587755e5727a11dace'
EXPECTED_PROJECT_SHA='d439a1e2908c70643c951d296294a87c3ba2756be6b1d0bb4c9a6bd4814ebe49'
EXPECTED_DECLARATIONS=(('Continuity_Response_Wire_Tests',7),('Continuity_Response_Wire_Tests.Refuse',28),('Continuity_Response_Wire_Tests.Check_Literal_Results',44),('Continuity_Response_Wire_Tests.Check_Unused_Values',69),('Continuity_Response_Wire_Tests.Check_Unused_Families',90),('Continuity_Response_Wire_Tests.Check_Header',99),('Continuity_Response_Wire_Tests.Check_Codes',127),('Continuity_Response_Wire_Tests.Check_Reserved',150),('Continuity_Response_Wire_Tests.Check_Process_Correlation',161))
RUNTIMES=('policy','transaction','request_wire','request_admission','grant_lifetime','retraction','consolidation','continuity','continuity_transition','continuity_record_wire','continuity_observation_wire','continuity_checkpoint_wire','continuity_current_wire','continuity_frame_wire','continuity_response_wire')


def require(condition,message):
    if not condition:
        raise ValueError(message)


def save(path,value):
    path.write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')


def unique_pairs(pairs):
    result={}
    for key,value in pairs:
        require(key not in result,'duplicate report key')
        result[key]=value
    return result


def decoded(data):
    def invalid_constant(value):
        raise ValueError('non-JSON numeric constant: '+value)
    return json.loads(data,object_pairs_hook=unique_pairs,parse_constant=invalid_constant)


def digest(path):
    require(path.is_file() and not path.is_symlink(),'hash input type')
    require(path.stat().st_size<=536_870_912,'hash byte budget')
    value=hashlib.sha256()
    with path.open('rb') as stream:
        for unused in range(8193):
            data=stream.read(65536)
            if not data:
                return value.hexdigest()
            value.update(data)
    raise ValueError('hash iteration budget')


def roster(directory):
    result={}
    for count,(current,directories,files) in enumerate(os.walk(directory,followlinks=False)):
        require(count<1024 and len(result)+len(files)<=4096,'inventory budget')
        directories.sort()
        for name in sorted(files):
            path=Path(current)/name
            result[str(path.relative_to(directory))]=digest(path)
    return result


def small(args,label,cwd=REPO):
    value=subprocess.run(args,cwd=cwd,capture_output=True,timeout=30)
    (OUT/(label+'.stdout')).write_bytes(value.stdout)
    (OUT/(label+'.stderr')).write_bytes(value.stderr)
    save(OUT/(label+'.command.json'),args)
    (OUT/(label+'.exit')).write_text(str(value.returncode)+'\n')
    require(value.returncode==0,'preparation command failed: '+label)
    return value.stdout


def source_declarations(text):
    declarations=[]
    for line,statement in enumerate(text.splitlines(),1):
        match=re.match(r'\s*procedure\s+(\w+)',statement)
        if match:
            short=match.group(1)
            name=short if short=='Continuity_Response_Wire_Tests' else 'Continuity_Response_Wire_Tests.'+short
            declarations.append((name,line))
    return declarations


def prepare(pin):
    require(small(['git','rev-parse','HEAD'],'head').decode().strip()==pin,'HEAD differs from owner-supplied commit')
    require(not (OUT/'source').exists() and not (OUT/'source.tar').exists(),'fresh execution directory required')
    pre=decoded(small(['python3','/home/sicarii/.codex/skills/project-vault/scripts/storage_status.py'],'storage-preflight'))
    save(OUT/'storage-preflight.json',pre)
    require(any(OUT.is_relative_to(Path(p)) for p in pre['pins']),'evidence root is not pinned')
    require(shutil.disk_usage(OUT).free>=max(RESERVE,pre['configured_local_reserve_bytes']),'reserve unavailable')
    archive=OUT/'source.tar'
    small(['git','archive','--format=tar','--output='+str(archive),pin,'spark'],'archive')
    source=OUT/'source'
    source.mkdir()
    small(['tar','-xf',str(archive),'-C',str(source)],'extract')
    require(digest(source/TARGET)==EXPECTED_HARNESS_SHA,'committed harness differs from reviewed repair')
    require(digest(source/'spark/sia_assurance.gpr')==EXPECTED_PROJECT_SHA,'project profile changed')
    declarations=source_declarations((source/TARGET).read_text())
    require(declarations==list(EXPECTED_DECLARATIONS),'intended nine declaration locations changed')
    initial=roster(source)
    save(OUT/'source-hashes-before.json',initial)
    manifest=decoded(small(['git','show',pin+':docs/CONTINUITY-IO-COMMITTED-EVIDENCE-20261021.json'],'inherited-tool-manifest'))
    expected=manifest['receipt']['proof_tools_before']
    resolved={name:str(Path(shutil.which(name)).resolve()) for name in ('gnatprove','gprbuild','gnatls','gcc','timeout','git','python3','tar','flock')}
    paths=sorted(set(list(expected)+list(resolved.values())))
    before={p:digest(Path(p)) for p in paths}
    save(OUT/'tool-paths.json',resolved)
    save(OUT/'tool-hashes-before.json',before)
    require(all(before[p]==value for p,value in expected.items()),'inherited proof tool identity changed')
    for name in ('gnatprove','gprbuild','gnatls','gcc'):
        small([resolved[name],'--version'],name+'-version',source)
    save(OUT/'source-binding.json',{'commit':pin,'archive_sha256':digest(archive),'overlay':[],'harness_sha256':digest(source/TARGET),'project_sha256':digest(source/'spark/sia_assurance.gpr'),'expected_declarations':declarations,'gnat_env_sha256':digest(Path('/home/sicarii/opt/gnat/env.sh')),'platform':platform.platform(),'lock':'Held by launch.sh through flock -n -E75 /home/sicarii/.worldline-heavy.lock'})
    return source,resolved,paths,before,initial


def inspect_response_report(stage):
    raw=stage/'raw'
    summary=raw/'gnatprove.out'
    require(summary.is_file(),'fresh complete response summary missing')
    totals=[line for line in summary.read_text().splitlines() if line.startswith('Total ')]
    require(len(totals)==1,'missing/duplicate total row')
    fields=re.sub(r'\([0-9]+%\)','',totals[0]).split()
    require(fields[-2:]==['.','.'],'nonzero justified/unproved checks')
    reports=list(raw.glob('*.spark'))
    require([p.name for p in reports]==['continuity_response_wire_tests.spark'],'unexpected/missing raw report roster')
    data=decoded(reports[0].read_bytes())
    require(data['stop_reason']=='STOP_REASON_NONE','raw report incomplete')
    for channel in ('warn_error','flow','proof'):
        require(isinstance(data[channel],list),'raw channel type')
        require(all(isinstance(v,dict) and v.get('severity') in ('info','information') for v in data[channel]),'non-information raw diagnostic')
    for field in ('pragma_assume','skip_proof','skip_flow_proof'):
        require(data[field]==[],'explicit assumption/exclusion')
    covered=[]
    for key,state in data['spark'].items():
        require(state=='all','partial entity analysis')
        item=data['entities'][key]
        require(len(item['sloc'])==1,'ambiguous entity location')
        location=item['sloc'][0]
        require(location['file']=='continuity_response_wire_tests.adb','unexpected entity source')
        covered.append((item['name'],location['line']))
    require(sorted(covered)==sorted(EXPECTED_DECLARATIONS),'nine declaration coverage mismatch')
    return {'status':'COMPLETE RESPONSE UNIT ONLY; not full-project coverage','total_row':totals[0],'reported_total':int(fields[1]),'justified':0,'unproved':0,'covered_declarations':covered,'stop_reason':data['stop_reason'],'raw_diagnostics':'No non-information warn_error/flow/proof entries','pragma_assume':[],'skip_proof':[],'skip_flow_proof':[],'assumptions':data['assumptions']}


def run_stage(source,resolved,name,command,seconds,proof=False):
    stage=OUT/name
    stage.mkdir()
    args=[resolved['timeout'],'--kill-after=5s',seconds]+command
    save(stage/'command.json',args)
    (stage/'command').write_text(shlex.join(args)+'\n')
    require(shutil.disk_usage(OUT).free>=RESERVE,'reserve unavailable before '+name)
    started=time.monotonic()
    with (stage/'stdout').open('wb') as stdout,(stage/'stderr').open('wb') as stderr:
        value=subprocess.run(args,cwd=source,stdout=stdout,stderr=stderr)
    result={'name':name,'command':args,'exit':value.returncode,'elapsed_seconds':time.monotonic()-started,'passed':value.returncode==0}
    (stage/'exit').write_text(str(value.returncode)+'\n')
    if proof:
        raw=stage/'raw'
        raw.mkdir()
        report=source/'spark/obj/gnatprove'
        for path in list(report.glob('*.spark'))+list(report.glob('gnatprove.out')):
            shutil.copyfile(path,raw/path.name)
        try:
            inspection=inspect_response_report(stage)
            save(stage/'inspection.json',inspection)
        except (ValueError,KeyError,TypeError,UnicodeError) as error:
            save(stage/'inspection.json',{'status':'REFUSED','error':str(error),'full_project_acceptance':False})
            result['passed']=False
        result['fresh_summary_present']=(raw/'gnatprove.out').exists()
    save(stage/'result.json',result)
    print(json.dumps(result),flush=True)
    return result


def sequence(source,resolved):
    results=[run_stage(source,resolved,'strict-build',[resolved['gprbuild'],'-p','-P','spark/sia_assurance.gpr'],'120s')]
    if not results[-1]['passed']:
        return results
    for name in RUNTIMES:
        results.append(run_stage(source,resolved,name+'-runtime',['spark/bin/'+name+'_tests'],'30s'))
        if not results[-1]['passed']:
            return results
    proof=[resolved['gnatprove'],'-P','spark/sia_assurance.gpr','-u','continuity_response_wire_tests.adb','--mode=all','--assumptions','--no-inlining','--memlimit=512','--timeout=10','-j1']
    results.append(run_stage(source,resolved,'complete-response-harness',proof,'120s',True))
    return results


def finish(pin,source,paths,before,initial,results):
    after={p:digest(Path(p)) for p in paths}
    save(OUT/'tool-hashes-after.json',after)
    final={name:digest(source/name) for name in initial}
    save(OUT/'source-hashes-after.json',final)
    save(OUT/'source-output-hashes.json',roster(source))
    expected_names=['strict-build']+[name+'-runtime' for name in RUNTIMES]+['complete-response-harness']
    receipt={'commit':pin,'overlay':[],'checks':results,'tool_rosters_equal':before==after,'archived_sources_unchanged':initial==final,'free_after_bytes':shutil.disk_usage(OUT).free,'scoped_sequence_passed':all(row['passed'] for row in results) and [row['name'] for row in results]==expected_names and before==after and initial==final,'full_project_proof':'UNRUN for this commit; inherited failed full-project evidence remains open','installed_acceptance':'OPEN; no installed action run','scope':'Fresh committed-source strict build/all original runtimes/complete response-unit proof only; no focused or full-project proof'}
    save(OUT/'receipt.json',receipt)
    print(json.dumps(receipt,indent=2),flush=True)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--commit',required=True)
    args=parser.parse_args()
    require(re.fullmatch('[0-9a-f]{40}',args.commit) is not None,'owner-supplied full commit SHA required')
    source,resolved,paths,before,initial=prepare(args.commit)
    results=sequence(source,resolved)
    finish(args.commit,source,paths,before,initial,results)

if __name__=='__main__':
    main()

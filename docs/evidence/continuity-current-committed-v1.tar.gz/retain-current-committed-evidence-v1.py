"""Retain a committed core reproduction; full-project coverage remains open."""
import gzip
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import sys
import tarfile

ROOT = Path(__file__).parent
RUN = ROOT / 'current-committed-reproduction-v1'
REPO = Path('/home/sicarii/Work/sia-assurance-kernel-20261019')
DEST = REPO / 'docs/CONTINUITY-CURRENT-COMMITTED-EVIDENCE.json'
BUNDLE = REPO / 'docs/evidence/continuity-current-committed-v1.tar.gz'


def read(path):
    with path.open('rb') as stream:
        value = stream.read(4_194_305)
    if len(value) > 4_194_304:
        raise ValueError('evidence input exceeds cap')
    return value


def sha(path):
    return hashlib.sha256(read(path)).hexdigest()


def validate(receipt):
    expected_checks = ['build', 'policy-tests', 'transaction-tests',
        'request-wire-tests', 'request-admission-tests', 'grant-lifetime-tests',
        'retraction-tests', 'consolidation-tests', 'continuity-tests',
        'continuity-transition-tests', 'continuity-record-wire-tests',
        'continuity-observation-wire-tests', 'continuity-checkpoint-wire-tests',
        'continuity-current-wire-tests', 'core-proof']
    if receipt['base'] != 'e0725f7f0cc5fa830316d12474a9932c3360214f' or receipt['files']:
        raise ValueError('not the intended unmodified commit archive')
    if [entry['name'] for entry in receipt['checks']] != expected_checks or not receipt['tools_unchanged']:
        raise ValueError('missing check or changed tool identity')
    if (len(receipt['proof_tools_before']) != 10 or
            receipt['proof_tools_before'] != receipt['proof_tools_after']):
        raise ValueError('tool identity roster changed or is incomplete')
    runner = RUN / 'run-continuity-current-wire-development-v1.py'
    spec = importlib.util.spec_from_file_location('retained_runner', runner)
    helper = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(helper)
    expected = helper.make_plan()[:-1]
    if len(receipt['checks']) != len(expected):
        raise ValueError('unexpected diagnostic command count')
    for entry, (label, duration, command) in zip(receipt['checks'], expected):
        if (entry['name'] != label or entry['command'] !=
                ['timeout', '--kill-after=5s', duration, *command]):
            raise ValueError('command arguments or resource cap changed')
    if any(entry['exit'] != 0 for entry in receipt['checks']):
        raise ValueError('command failure')
    if receipt['checks'][-1]['fresh_proof_summary'] is not True:
        raise ValueError('missing fresh proof summary')
    if sha(RUN / 'base.tar') != receipt['archive_sha256']:
        raise ValueError('archive changed')
    for name, expected in receipt['source_files'].items():
        if sha(RUN / 'source' / name) != expected or sha(REPO / name) != expected:
            raise ValueError('source mismatch: ' + name)
    for name, expected in receipt['retained_raw']['core-proof'].items():
        if sha(RUN / 'core-proof-raw' / name) != expected:
            raise ValueError('retained proof product changed')
        if read(RUN / 'core-proof-raw' / name) != read(RUN / 'source/spark/obj/gnatprove' / name):
            raise ValueError('copied proof product differs from generated product')
    path = RUN / 'source/spark/check-proof-summary.py'
    spec = importlib.util.spec_from_file_location('gate', path)
    gate = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(gate)
    lines = read(RUN / 'core-proof-raw/gnatprove.out').decode().splitlines()
    gate.check_totals(lines)
    gate.check_details(lines)
    units = [gate.UNIT.fullmatch(line).groups() for line in lines if line.startswith('in unit ')]
    if units != [('sia_continuity_current_wire', '12', '12')]:
        raise ValueError('unexpected focused scope')
    gate.check_raw_diagnostics(RUN / 'source/spark', {'sia_continuity_current_wire'})


def package(receipt):
    names = {'receipt.json', 'base.tar', 'core-proof-raw/gnatprove.out',
             'core-proof-raw/sia_continuity_current_wire.spark'}
    names.update(entry['name'] + '.log' for entry in receipt['checks'])
    paths = [RUN / name for name in names]
    paths.extend(Path(name) for name in receipt['runner_dependencies'])
    paths.append(Path(__file__))
    if len(paths) > 64:
        raise ValueError('bundle roster exceeds cap')
    payload = io.BytesIO()
    artifacts = []
    total = 0
    with gzip.GzipFile(fileobj=payload, mode='wb', mtime=0) as zipped:
        with tarfile.open(fileobj=zipped, mode='w|', format=tarfile.USTAR_FORMAT) as archive:
            for path in sorted(set(paths)):
                raw = read(path)
                total += len(raw)
                if total > 16 * 1024 * 1024:
                    raise ValueError('bundle byte budget exceeded')
                name = str(path.relative_to(ROOT))
                info = tarfile.TarInfo(name)
                info.size, info.mode = len(raw), path.stat().st_mode & 0o777
                archive.addfile(info, io.BytesIO(raw))
                artifacts.append({'path': name, 'sha256': hashlib.sha256(raw).hexdigest()})
    return payload.getvalue(), artifacts


def main():
    checking = sys.argv[1:] == ['--check']
    if sys.argv[1:] not in ([], ['--check']):
        raise ValueError('expected optional --check')
    receipt = json.loads(read(RUN / 'receipt.json'))
    validate(receipt)
    bundle, artifacts = package(receipt)
    value = {'kind': 'COMMITTED SCOPED REPRODUCTION; no complete-system acceptance',
             'receipt': receipt, 'artifacts': artifacts,
             'bundle': {'path': str(BUNDLE.relative_to(REPO)),
                        'sha256': hashlib.sha256(bundle).hexdigest(), 'bytes': len(bundle)},
             'core_raw_gate': 'Clean reported totals, all 12 core entities, informational diagnostics only; no Assume/skip entries',
             'limits': ['Complete harness and full-project proof remain unproved.',
                        'Ordinary modular dependency and toolchain assumptions remain.',
                        'No authenticated observations, physical resource qualification or installed adapter claim.']}
    raw = (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()
    if checking:
        if read(DEST) != raw or read(BUNDLE) != bundle:
            raise ValueError('retained evidence differs')
    else:
        with BUNDLE.open('xb') as out:
            out.write(bundle)
        with DEST.open('xb') as out:
            out.write(raw)
    print('committed scoped reproduction verified')


if __name__ == '__main__':
    main()

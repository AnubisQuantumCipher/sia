"""Fixed harmless lineage. Parent owns init pidfd before descendants may fork."""
import array
import json
import os
from pathlib import Path
import socket
import time

DEADLINE = time.monotonic() + 20


def budget(connection):
    remaining = DEADLINE - time.monotonic()
    if remaining <= 0:
        raise TimeoutError('absolute fixture deadline')
    connection.settimeout(remaining)


def receive(connection):
    budget(connection)
    return connection.recv(16)


def observation(role):
    fields = dict(line.split(':', 1) for line in
                  Path('/proc/self/status').read_text().splitlines() if ':' in line)
    return dict(role=role, uid=list(os.getresuid()), gid=list(os.getresgid()),
                groups=os.getgroups(), proc_uid=[int(x) for x in fields['Uid'].split()],
                proc_gid=[int(x) for x in fields['Gid'].split()],
                namespaces={k: os.readlink('/proc/self/ns/' + k)
                            for k in ('pid', 'user', 'net')},
                caps={k: fields[k].strip() for k in
                      ('CapInh', 'CapPrm', 'CapEff', 'CapBnd', 'CapAmb', 'NoNewPrivs')})


def announce(connection, role):
    descriptors = [os.pidfd_open(os.getpid())]
    try:
        if role == 'leader':
            if os.getppid() != 1:
                raise ValueError('expected namespace reaper')
            descriptors.append(os.pidfd_open(1))
        payload = json.dumps(observation(role)).encode()
        budget(connection)
        written = connection.sendmsg([payload], [(socket.SOL_SOCKET, socket.SCM_RIGHTS,
                                                 array.array('i', descriptors))])
        if written != len(payload):
            raise ValueError('short witness record')
    finally:
        for descriptor in descriptors:
            os.close(descriptor)


def connect(role):
    connection = socket.socket(socket.AF_UNIX, socket.SOCK_SEQPACKET)
    try:
        budget(connection)
        connection.connect('/tmp/out/w.sock')
        announce(connection, role)
        return connection
    except (OSError, ValueError):
        connection.close()
        raise


def hold(connection):
    command = receive(connection)
    if command != b'exit':
        raise ValueError('missing terminal command')


def grandchild():
    with connect('grandchild') as connection:
        if receive(connection) != b'hold':
            raise ValueError('expected hold command')
        hold(connection)


def child():
    with connect('child') as connection:
        if receive(connection) != b'fork':
            raise ValueError('expected child fork admission')
        pid = os.fork()
        if pid == 0:
            connection.close()
            grandchild()
            return
        hold(connection)


def main():
    with connect('leader') as connection:
        if receive(connection) != b'fork':
            raise ValueError('expected leader fork admission')
        pid = os.fork()
        if pid == 0:
            connection.close()
            child()
            return
        hold(connection)


if __name__ == '__main__':
    main()

"""One instrumented observer-death cut; observation precedes cleanup."""
from contextlib import ExitStack
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import signal
import stat
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
RECORDS = ('witness-entry.json', 'witness-before-cleanup.json', 'witness-result.json')
ROLES = ('observer', 'launcher', 'init', 'leader')


def bootstrap():
    source = ROOT / 'execution-source.json'
    if len(sys.argv) != 2 or hashlib.sha256(source.read_bytes()).hexdigest() != sys.argv[1]:
        raise ValueError('fixed cut manifest required before import')
    manifest = json.loads(source.read_text())
    if not {'witness.py', 'observer_driver.py', 'proof_wrapper.py'} <= set(manifest):
        raise ValueError('bootstrap files missing')
    for name, expected in manifest.items():
        if hashlib.sha256((ROOT / name).read_bytes()).hexdigest() != expected:
            raise ValueError('cut source changed before import: ' + name)
    return manifest


def load_wrapper():
    spec = importlib.util.spec_from_file_location('witness_wrapper', ROOT / 'proof_wrapper.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def save(wrapper, name, value):
    if name not in RECORDS:
        raise ValueError('fixed witness record required')
    directory = descriptor = None
    errors = []
    try:
        directory = os.open(ROOT, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC)
        wrapper.check_receipt_directory(directory)
        descriptor = os.open(name, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW |
                             os.O_CLOEXEC, 0o644, dir_fd=directory)
        wrapper.write_receipt(descriptor, value)
        os.fsync(descriptor)
        os.fsync(directory)
    except (OSError, ValueError, TypeError) as error:
        errors.append(wrapper.receipt_error('witness-save', error))
    finally:
        wrapper.close_receipt(descriptor, 'witness-record', errors)
        wrapper.close_receipt(directory, 'witness-directory', errors)
    if errors:
        raise RuntimeError(json.dumps(dict(status='UNKNOWN_WITNESS_RECORD', errors=errors)))


def wait_stopped(child):
    # Fixture transition bound, not an engineering workload timeout.
    end = time.monotonic() + 5
    for _ in range(501):
        pid, status = os.waitpid(child.pid, os.WNOHANG | os.WUNTRACED)
        if pid:
            if os.WIFSTOPPED(status) and os.WSTOPSIG(status) == signal.SIGSTOP:
                return
            raise ValueError('observer exited or changed state before cut')
        if time.monotonic() >= end:
            break
        time.sleep(0.01)
    raise ValueError('observer did not reach the fixed stop')


def bind_live(helper, pid, stack, handles, role):
    descriptor = os.pidfd_open(pid)
    stack.callback(os.close, descriptor)
    handles[role] = descriptor
    if helper.descriptor_pid(descriptor) != pid or helper.events(descriptor):
        raise ValueError('live pidfd binding failed: ' + role)
    return helper.status(pid)


def process_observation(helper, pid):
    with Path('/proc', str(pid), 'stat').open('rb') as stream:
        raw = stream.read(8193)
    if len(raw) > 8192:
        raise ValueError('proc stat size')
    # proc_pid_stat(5): starttime is field 22; field 3 follows the final ") ".
    tail = raw.rsplit(b') ', 1)
    if len(tail) != 2 or len(tail[1].split()) < 20:
        raise ValueError('proc stat layout')
    status = helper.status(pid)
    return dict(pid=pid, start_ticks=int(tail[1].split()[19]), stat=raw.decode(),
                namespaces=helper.namespaces(pid), status={key: status[key].strip()
                    for key in ('State', 'PPid', 'Uid', 'Gid', 'Groups', 'NoNewPrivs', *helper.CAPS)})


def acquire_chain(helper, child, stack, handles, active, config):
    observer = helper.status(child.pid)
    if observer['State'].strip().split()[0] != 'T' or int(observer['PPid']) != os.getpid():
        raise ValueError('actual direct observer is not stopped')
    command = ['/usr/bin/python3', '-I', '-B', str(ROOT / 'observer_driver.py'), sys.argv[1]]
    with Path('/proc', str(child.pid), 'cmdline').open('rb') as stream:
        actual_command = stream.read(4097)
    if actual_command != b'\0'.join(os.fsencode(part) for part in command) + b'\0' \
            or helper.digest(Path('/proc', str(child.pid), 'exe')) != config['tools']['/usr/bin/python3']:
        raise ValueError('stopped observer executable or command changed')
    launch = bind_live(helper, active['launcher'], stack, handles, 'launcher')
    leader = bind_live(helper, active['leader'], stack, handles, 'leader')
    init_pid = int(leader['PPid'])
    init = bind_live(helper, init_pid, stack, handles, 'init')
    if int(launch['PPid']) != child.pid or int(init['PPid']) != active['launcher'] \
            or int(init['NSpid'].split()[-1]) != 1:
        raise ValueError('lineage parent binding')
    for pid in (active['leader'], init_pid):
        if helper.namespaces(pid) != active['namespace']:
            raise ValueError('lineage namespace binding')
    expected = config['expected']
    for field, key in (('Uid', 'proc_uid'), ('Gid', 'proc_gid'), ('Groups', 'groups')):
        if [int(x) for x in leader[field].split()] != expected[key]:
            raise ValueError('leader credential mismatch')
    if any(int(leader[key], 16) for key in helper.CAPS) or leader['NoNewPrivs'].strip() != '1':
        raise ValueError('leader retained authority')
    pids = dict(observer=child.pid, launcher=active['launcher'], leader=active['leader'], init=init_pid)
    observed = {role: process_observation(helper, pid) for role, pid in pids.items()}
    for role, pid in pids.items():
        if helper.descriptor_pid(handles[role]) != pid or helper.events(handles[role]) \
                or process_observation(helper, pid)['start_ticks'] != observed[role]['start_ticks']:
            raise ValueError('identity changed during acquisition')
    return dict(pids=pids, observations=observed)


def pending_binding(wrapper, helper, config, binding):
    expected = wrapper.pending_intent(sys.argv[1], config, binding, helper.LOCK.lstat())
    descriptor = os.open(wrapper.LEDGER / 'pending.json', os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
    try:
        meta = os.fstat(descriptor)
        if not stat.S_ISREG(meta.st_mode) or meta.st_uid != os.geteuid() \
                or meta.st_nlink != 1 or stat.S_IMODE(meta.st_mode) != 0o600:
            raise ValueError('pending metadata')
        data = os.read(descriptor, 65537)
        if len(data) > 65536 or len(data) != meta.st_size or json.loads(data) != expected:
            raise ValueError('pending exact operation binding')
    finally:
        os.close(descriptor)
    return dict(sha256=hashlib.sha256(data).hexdigest(), value=expected,
                identity=wrapper.metadata(meta))


def preflight(wrapper, config, helper, manifest):
    wrapper.verify_manifest(manifest)
    wrapper.verify_host(config, helper)
    helper.validate_tools(config)
    binding = json.loads((ROOT / 'source-binding.json').read_text())
    wrapper.verify_inputs(config, binding)
    with ExitStack() as stack:
        meta = helper.hold_lock(stack)
        if list(helper.identity(meta)) != config['cut']['lock_identity']:
            raise ValueError('fixed heavy lock changed')
        actual = {path.name for path in wrapper.LEDGER.iterdir()}
        if actual != set(config['cut']['ledger_files']):
            raise ValueError('predecessor ledger differs from manual reconciliation')
        for name, expected in config['cut']['ledger_files'].items():
            if wrapper.sha(wrapper.LEDGER / name) != expected:
                raise ValueError('predecessor evidence changed')


def run_cut(wrapper, helper, config, binding, stack, result):
    stdout = stack.enter_context((ROOT / 'observer.stdout').open('xb'))
    stderr = stack.enter_context((ROOT / 'observer.stderr').open('xb'))
    command = ['/usr/bin/python3', '-I', '-B', str(ROOT / 'observer_driver.py'), sys.argv[1]]
    child = subprocess.Popen(command, stdout=stdout, stderr=stderr)
    handles = {}
    before = None
    try:
        result['creation'] = dict(pid=child.pid, command=command, disposition='DIRECT_CHILD_CREATED')
        descriptor = helper.owned_pidfd(child)
        stack.callback(os.close, descriptor)
        handles['observer'] = descriptor
        wait_stopped(child)
        active = json.loads((ROOT / 'active.json').read_text())
        result['lineage'] = acquire_chain(helper, child, stack, handles, active, config)
        if set(handles) != set(ROLES):
            raise ValueError('incomplete tracked lineage')
        result['pending_binding'] = pending_binding(wrapper, helper, config, binding)
        result['pending_before'] = result['pending_binding']['sha256']
        result['active_sha256'] = wrapper.sha(ROOT / 'active.json')
        if (ROOT / 'out/payload-entered.json').exists():
            raise ValueError('payload already entered')
        result['intervention'] = helper.signal_owned(handles['observer'])
        result['observer_wait'] = child.wait(timeout=5)
        before = helper.wait_terminal(handles, 5)
        result['before_cleanup'] = before
        result['pending_after'] = wrapper.sha(wrapper.LEDGER / 'pending.json')
        result['payload_entered'] = (ROOT / 'out/payload-entered.json').exists()
        save(wrapper, 'witness-before-cleanup.json', result)
        if result['observer_wait'] != -signal.SIGKILL or result['payload_entered'] \
                or result['pending_before'] != result['pending_after'] \
                or not all(row['terminal'] and row['reaped'] for row in before.values()):
            raise ValueError('cut postcondition failed before cleanup')
        result['status'] = 'TESTED_INSTRUMENTED_PRE_ADMISSION_CUT'
    finally:
        result['acquired_roles'] = sorted(handles)
        result['unacquired_roles_unknown'] = sorted(set(ROLES) - set(handles))
        result['cleanup'] = helper.cleanup(child, handles)
        result['cleanup_was_after_observation'] = before is not None
        if result['unacquired_roles_unknown'] or result['cleanup'].get('signals'):
            result['status'] = 'FAILED_OR_UNKNOWN'


def main():
    manifest = bootstrap()
    wrapper = load_wrapper()
    wrapper.verify_manifest(manifest)
    config = json.loads((ROOT / 'config.json').read_text())
    helper = wrapper.helpers(config)
    preflight(wrapper, config, helper, manifest)
    binding = json.loads((ROOT / 'source-binding.json').read_text())
    result = dict(status='FAILED_OR_UNKNOWN', authority='NONE', manifest=sys.argv[1],
                  cut='AFTER_ACTIVE_DURABLE_BEFORE_PROVE', instrumented=True,
                  replay_authorized=False, successor_admitted=False)
    save(wrapper, 'witness-entry.json', result)
    with ExitStack() as stack:
        try:
            run_cut(wrapper, helper, config, binding, stack, result)
            wrapper.verify_inputs(config, binding)
            wrapper.verify_manifest(manifest)
            helper.validate_tools(config)
            result['post_source_and_tools_verified'] = True
        except (OSError, ValueError, RuntimeError, subprocess.TimeoutExpired) as error:
            result['status'] = 'FAILED_OR_UNKNOWN'
            result['error'] = wrapper.receipt_error('cut', error)
    if not result.get('cleanup', {}).get('complete'):
        result['status'] = 'FAILED_OR_UNKNOWN'
    save(wrapper, 'witness-result.json', result)
    print(json.dumps(result), flush=True)
    if result['status'] != 'TESTED_INSTRUMENTED_PRE_ADMISSION_CUT':
        raise SystemExit(1)


if __name__ == '__main__':
    main()

"""Nonlaunching cut ordering controls; not actual observer-death evidence."""
from contextlib import ExitStack
from pathlib import Path
import signal
import tempfile
import unittest
from unittest import mock

import observer_driver
import witness


class DriverControls(unittest.TestCase):
    def test_active_save_completes_before_stop_and_resume_always_raises(self):
        trace = []
        module = mock.Mock()
        module.save.side_effect = lambda name, _value: trace.append(('save', name))
        observer_driver.install_cut(module)
        with mock.patch.object(observer_driver.os, 'kill', side_effect=lambda _pid, sig: trace.append(('kill', sig))):
            with self.assertRaisesRegex(RuntimeError, 'must never resume'):
                module.save('active.json', {})
        self.assertEqual(trace, [('save', 'active.json'), ('kill', signal.SIGSTOP)])

    def test_other_save_never_stops(self):
        module = mock.Mock()
        original = module.save
        observer_driver.install_cut(module)
        with mock.patch.object(observer_driver.os, 'kill') as kill:
            module.save('entry.json', {})
        original.assert_called_once_with('entry.json', {})
        kill.assert_not_called()

    def test_failed_active_save_never_reaches_stop(self):
        module = mock.Mock()
        module.save.side_effect = OSError('sync failed')
        observer_driver.install_cut(module)
        with mock.patch.object(observer_driver.os, 'kill') as kill:
            with self.assertRaises(OSError):
                module.save('active.json', {})
        kill.assert_not_called()


class ObservationBeforeCleanup(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        self.root = Path(temporary.name)
        (self.root / 'active.json').write_text('{}')
        (self.root / 'out').mkdir()
        self.trace = []
        self.wrapper, self.helper, self.child = mock.Mock(), mock.Mock(), mock.Mock(pid=123)
        self.wrapper.LEDGER = self.root / 'mock-ledger'
        self.wrapper.sha.return_value = 'fixed-content'
        self.child.wait.return_value = -signal.SIGKILL
        self.helper.owned_pidfd.return_value = 99
        self.helper.signal_owned.side_effect = lambda _fd: self.trace.append('kill-observer')
        self.helper.wait_terminal.side_effect = self.observe
        self.helper.cleanup.side_effect = self.cleanup
        for module, name, value in ((witness, 'ROOT', self.root),
                                   (witness.sys, 'argv', ['witness.py', 'fixed-manifest'])):
            patcher = mock.patch.object(module, name, value)
            patcher.start()
            self.addCleanup(patcher.stop)
        self.terminal = True

    def observe(self, _handles, _seconds):
        self.trace.append('observe')
        return {role: dict(mask=17, terminal=self.terminal, reaped=self.terminal) for role in _handles}

    def cleanup(self, _child, _handles):
        self.trace.append('cleanup')
        return dict(complete=True)

    def exercise(self, result):
        def acquire(_helper, _child, _stack, handles, _active, _config):
            handles.update(launcher=100, init=101, leader=102)
            return {}
        with mock.patch.object(witness.subprocess, 'Popen', return_value=self.child), \
                mock.patch.object(witness.os, 'close'), \
                mock.patch.object(witness, 'wait_stopped'), \
                mock.patch.object(witness, 'acquire_chain', side_effect=acquire), \
                mock.patch.object(witness, 'pending_binding', return_value={'sha256': 'fixed-content'}), \
                mock.patch.object(witness, 'save', side_effect=lambda *_args: self.trace.append('save-observation')), \
                ExitStack() as stack:
            witness.run_cut(self.wrapper, self.helper, {}, {}, stack, result)

    def test_observation_is_recorded_before_any_cleanup(self):
        result = dict(status='FAILED_OR_UNKNOWN')
        self.exercise(result)
        self.assertEqual(self.trace, ['kill-observer', 'observe', 'save-observation', 'cleanup'])
        self.assertEqual(result['status'], 'TESTED_INSTRUMENTED_PRE_ADMISSION_CUT')
        self.assertTrue(result['cleanup_was_after_observation'])

    def test_successful_cleanup_cannot_turn_nontermination_into_pass(self):
        self.terminal = False
        result = dict(status='FAILED_OR_UNKNOWN')
        with self.assertRaisesRegex(ValueError, 'postcondition failed before cleanup'):
            self.exercise(result)
        self.assertEqual(self.trace, ['kill-observer', 'observe', 'save-observation', 'cleanup'])
        self.assertEqual(result['status'], 'FAILED_OR_UNKNOWN')
        self.assertTrue(result['cleanup']['complete'])

    def test_unexpected_payload_entry_is_failure_before_intervention(self):
        (self.root / 'out/payload-entered.json').write_text('unexpected')
        result = dict(status='FAILED_OR_UNKNOWN')
        with self.assertRaisesRegex(ValueError, 'payload already entered'):
            self.exercise(result)
        self.assertEqual(self.trace, ['cleanup'])
        self.assertEqual(result['status'], 'FAILED_OR_UNKNOWN')
        self.assertFalse(result['cleanup_was_after_observation'])

    def test_initial_pidfd_failure_records_creation_and_unknown_lineage(self):
        self.helper.owned_pidfd.side_effect = RuntimeError('acquisition failed; direct child fallback recorded')
        result = dict(status='FAILED_OR_UNKNOWN')
        with self.assertRaisesRegex(RuntimeError, 'acquisition failed'):
            self.exercise(result)
        self.assertEqual(result['creation']['pid'], 123)
        self.assertEqual(result['unacquired_roles_unknown'], sorted(witness.ROLES))
        self.assertEqual(result['status'], 'FAILED_OR_UNKNOWN')
        self.assertEqual(self.trace, ['cleanup'])
        self.assertFalse(result['cleanup_was_after_observation'])

    def test_cleanup_signals_cannot_be_accepted_after_observation(self):
        self.helper.cleanup.side_effect = None
        self.helper.cleanup.return_value = dict(complete=True, signals={'launcher': 'SIGKILL_SENT'})
        result = dict(status='FAILED_OR_UNKNOWN')
        self.exercise(result)
        self.assertEqual(result['status'], 'FAILED_OR_UNKNOWN')
        self.assertEqual(result['unacquired_roles_unknown'], [])


if __name__ == '__main__':
    unittest.main(verbosity=2)

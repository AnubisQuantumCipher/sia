"""Prepare one fixed instrumented cut; no privileged or process execution."""
import hashlib
import json
from pathlib import Path
import shutil

BASE = Path(__file__).resolve().parent
NORMAL = BASE / 'ordinary-recovery-latch-integration-20261026-v1'
SOURCE = BASE / 'ordinary-observer-cut-source-20261026-v2'
GUARD = BASE / 'ordinary-replay-refusal-20261026-v2'
DEST = BASE / 'ordinary-observer-cut-20261026-v1'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def create_files():
    if shutil.disk_usage(BASE).free < 10050000000:
        raise ValueError('physical reserve plus preparation space required')
    DEST.mkdir(mode=0o700)
    shutil.copytree(NORMAL / 'source', DEST / 'source')
    for name in ('obj', 'bin', 'home', 'tmp', 'cache', 'out'):
        (DEST / name).mkdir(mode=0o700)
    original = json.loads((NORMAL / 'execution-source.json').read_text())
    for name in original:
        if name not in ('config.json', 'proof_wrapper.py', 'receipt_candidate.py', 'invoke.py'):
            shutil.copy2(NORMAL / name, DEST / name)
    for name in ('proof_wrapper.py', 'receipt_candidate.py'):
        shutil.copy2(GUARD / 'receipt_candidate.py', DEST / name)
    shutil.copy2(GUARD / 'test_replay.py', DEST / 'test_replay.py')
    for name in ('observer_driver.py', 'witness.py', 'payload_sentinel.py', 'test_cut.py'):
        shutil.copy2(SOURCE / name, DEST / name)
    invocation = (NORMAL / 'invoke.py').read_text().replace("'proof_wrapper.py'", "'witness.py'")
    invocation = invocation.replace("command = ['/usr/bin/sudo', '/usr/bin/python3', '-I', '-B',",
        "command = ['/usr/bin/sudo', '/usr/bin/prlimit', '--core=0:0', '--',\n               '/usr/bin/python3', '-I', '-B',")
    (DEST / 'invoke.py').write_text(invocation)


def create_config():
    config = json.loads((NORMAL / 'config.json').read_text().replace(str(NORMAL), str(DEST)))
    config['candidate_phase'] = 'instrumented-actual-observer-death-before-prove'
    config['cases'] = ['actual-observer-before-prove']
    config['proof_command'] = ['/usr/bin/python3', '-I', '-B', '/tmp/payload_sentinel.py']
    index = config['command'].index('/usr/bin/setpriv')
    config['command'][index:index] = ['--ro-bind', str(DEST / 'payload_sentinel.py'), '/tmp/payload_sentinel.py']
    post = json.loads((BASE / 'ordinary-manual-reconciliation-20261026-v1/readback.stdout').read_text())
    config['cut'] = dict(lock_identity=[64768, 457925, 33188, 1000, 1000, 1],
                         ledger_files={name: row['sha256'] for name, row in post['rows'].items()},
                         predecessor='EXACT_NORMAL_FIXTURE_RECONCILIATION_PASS',
                         authority='NONE', successor_admitted=False)
    with (DEST / 'config.json').open('x') as stream:
        json.dump(config, stream, indent=2, sort_keys=True)
        stream.write('\n')


def main():
    create_files()
    create_config()
    names = tuple(sorted(p.name for p in DEST.iterdir() if p.is_file()))
    manifest = {name: sha(DEST / name) for name in names}
    with (DEST / 'execution-source.json').open('x') as stream:
        json.dump(manifest, stream, indent=2, sort_keys=True)
        stream.write('\n')
    print(json.dumps(dict(status='PREPARED_NOT_ADMITTED_OR_EXECUTED', path=str(DEST),
                          manifest_sha256=sha(DEST / 'execution-source.json'), files=len(manifest))))


if __name__ == '__main__':
    main()

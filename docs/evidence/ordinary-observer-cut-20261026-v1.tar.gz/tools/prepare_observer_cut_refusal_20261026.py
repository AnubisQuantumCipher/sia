"""Fresh-output refusal probe; no privileged execution during preparation."""
import hashlib
import json
from pathlib import Path
import shutil

BASE = Path(__file__).resolve().parent
ORIGINAL = BASE / 'ordinary-observer-cut-20261026-v2'
DEST = BASE / 'ordinary-observer-cut-refusal-20261026-v1'


def main():
    if shutil.disk_usage(BASE).free < 10050000000:
        raise ValueError('physical reserve plus preparation space')
    DEST.mkdir(mode=0o700)
    shutil.copytree(ORIGINAL / 'source', DEST / 'source')
    for name in ('obj', 'bin', 'home', 'tmp', 'cache', 'out'):
        (DEST / name).mkdir(mode=0o700)
    original = json.loads((ORIGINAL / 'execution-source.json').read_text())
    for name in original:
        if name not in ('config.json', 'invoke.py'):
            shutil.copy2(ORIGINAL / name, DEST / name)
    config = json.loads((ORIGINAL / 'config.json').read_text().replace(str(ORIGINAL), str(DEST)))
    with (DEST / 'config.json').open('x') as stream:
        json.dump(config, stream, indent=2, sort_keys=True)
        stream.write('\n')
    invocation = (ORIGINAL / 'invoke.py').read_text().replace("'witness.py'", "'proof_wrapper.py'")
    with (DEST / 'invoke.py').open('x') as stream:
        stream.write(invocation)
    manifest = {name: hashlib.sha256((DEST / name).read_bytes()).hexdigest() for name in original}
    with (DEST / 'execution-source.json').open('x') as stream:
        json.dump(manifest, stream, indent=2, sort_keys=True)
        stream.write('\n')
    print(json.dumps(dict(status='PREPARED_UNRUN_NEGATIVE_CONTROL', path=str(DEST),
        manifest_sha256=hashlib.sha256((DEST / 'execution-source.json').read_bytes()).hexdigest())))


if __name__ == '__main__':
    main()

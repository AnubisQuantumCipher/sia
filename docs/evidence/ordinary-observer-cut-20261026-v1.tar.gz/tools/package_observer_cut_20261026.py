"""Package retained observations and their exact source; never execute archived code."""
import argparse
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

BASE = Path(__file__).resolve().parent
ROOT = BASE / 'ordinary-observer-cut-package-20261026-v1'
ARCHIVE = 'ordinary-observer-cut-20261026-v1.tar.gz'
ROSTER = BASE / 'ordinary-observer-cut-package-roster-20261026.json'
CUT = BASE / 'ordinary-observer-cut-20261026-v2'
REFUSAL = BASE / 'ordinary-observer-cut-refusal-20261026-v1'


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def read(path):
    return json.loads(path.read_text())


def check(condition, message):
    if not condition:
        raise ValueError(message)


def verify_run(root):
    audit = read(root / 'OWNER-AUDIT.json')
    for name, expected in audit['evidence_sha256'].items():
        check(sha(root / name) == expected, 'audited evidence changed: ' + name)
    check(read(root / 'RESULT-INDEPENDENT-REVIEW.json')['audit_sha256'] ==
          sha(root / 'OWNER-AUDIT.json'), 'review binding changed')
    for name, expected in read(root / 'execution-source.json').items():
        check(sha(root / name) == expected, 'execution source changed')


def verify_components():
    for directory, tests in (('ordinary-replay-refusal-20261026-v2', 44),
                             ('ordinary-observer-cut-source-20261026-v3', 8)):
        root = BASE / directory
        result = read(root / 'TEST-RESULT.json')
        check(result['status'] == 'PASS' and result['tests'] == tests and
              result['failures'] == result['errors'] == result['skipped'] == 0, 'component result')
        for name, expected in result['source'].items():
            check(sha(root / name) == expected, 'component source changed')


def members():
    rows = read(ROSTER)
    check(len(rows) <= 800, 'closed roster bound')
    files, verified, total = {}, {}, 0
    for name, row in sorted(rows.items()):
        path = BASE / row['path']
        check(not Path(name).is_absolute() and '..' not in Path(name).parts and
              not Path(row['path']).is_absolute() and '..' not in Path(row['path']).parts, 'member path')
        size = path.stat().st_size
        check(not path.is_symlink() and path.is_file() and size == row['bytes'] and
              sha(path) == row['sha256'], 'member changed: ' + name)
        total += size
        files[name], verified[name] = path, dict(sha256=row['sha256'], bytes=size)
    check(total <= 33554432, 'encoded evidence size bound')
    for name, path in (('tools/' + Path(__file__).name, Path(__file__)), ('tools/roster.json', ROSTER)):
        check(name not in files, 'duplicate metadata member')
        files[name], verified[name] = path, dict(sha256=sha(path), bytes=path.stat().st_size)
    return files, verified


def source_bindings():
    binding = read(CUT / 'source-binding.json')
    check(len(binding['files']) == 478, 'snapshot roster')
    for name, row in binding['files'].items():
        for root in (CUT, REFUSAL):
            path = root / 'source' / name
            check(sha(path) == row['sha256'] and path.stat().st_size == row['bytes'], 'snapshot bytes')
        check(sha(Path(binding['canonical']) / name) == row['canonical_sha256'], 'canonical bytes')
    config = read(CUT / 'config.json')
    for name, expected in config['helper_hashes'].items():
        check(sha(Path(config['helper_root']) / name) == expected, 'helper bytes')
    return binding


def encoded_archive(files, rows):
    output = io.BytesIO()
    with gzip.GzipFile(fileobj=output, mode='wb', filename='', mtime=0) as zipped:
        with tarfile.open(fileobj=zipped, mode='w', format=tarfile.USTAR_FORMAT) as archive:
            for name, path in sorted(files.items()):
                with path.open('rb') as stream:
                    data = stream.read(rows[name]['bytes'] + 1)
                check(len(data) == rows[name]['bytes'] and
                      hashlib.sha256(data).hexdigest() == rows[name]['sha256'], 'packaging race')
                info = tarfile.TarInfo(name)
                info.size, info.mode, info.mtime = len(data), 0o444, 0
                archive.addfile(info, io.BytesIO(data))
    return output.getvalue()


def record(rows, data, binding):
    return dict(status='TESTED_INSTRUMENTED_PRE_ADMISSION_CUT_AND_PENDING_REFUSAL', authority='NONE',
        carrier_head='9fbc3c13396ae49539e69b7a3acebf9e4329b94a', source_head=binding['head'], members=rows,
        archive=dict(path='docs/evidence/' + ARCHIVE, sha256=hashlib.sha256(data).hexdigest(), bytes=len(data)),
        cut=read(CUT / 'OWNER-AUDIT.json'), refusal=read(REFUSAL / 'OWNER-AUDIT.json'),
        components=dict(exact_manifest_guard=44, instrumented_cut_controls=8),
        prerequisites=['fa78271acec7f9aea6dac6fe7043a53d129cc06b', '9fbc3c13396ae49539e69b7a3acebf9e4329b94a'],
        limitations=['One instrumented pre-admission observer cut; four tracked roles, external witness.',
            'Witness loss, pre-entry/post-admission and unseen descendants remain UNKNOWN or UNRUN.',
            'Pending remains unresolved; no automatic retirement, semantic replay or successor authority.',
            'Unsigned tool notes; nonhostile root/host assumptions; no hardware crash proof.',
            'Bound baseline478 source and fixed helpers included; host binaries are hash-bound, not bundled.',
            'No new SPARK proof, native C14, whole-system, installed, release or marketplace acceptance.'])


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--check', action='store_true')
    args = parser.parse_args()
    for root in (CUT, REFUSAL):
        verify_run(root)
    verify_components()
    binding = source_bindings()
    files, rows = members()
    data = encoded_archive(files, rows)
    result = record(rows, data, binding)
    encoded = (json.dumps(result, indent=2, sort_keys=True) + '\n').encode()
    if args.check:
        check((ROOT / ARCHIVE).read_bytes() == data and
              (ROOT / 'manifest.json').read_bytes() == encoded, 'byte reproduction mismatch')
    else:
        ROOT.mkdir(mode=0o700)
        for name, value in ((ARCHIVE, data), ('manifest.json', encoded)):
            with (ROOT / name).open('xb') as stream:
                check(stream.write(value) == len(value), 'short package write')
    print(json.dumps(dict(status='PACKAGE_CHECK_PASS' if args.check else 'PACKAGE_CREATED',
                         archive=result['archive'], members=len(rows))))


if __name__ == '__main__':
    main()

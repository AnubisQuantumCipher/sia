#!/usr/bin/env python3
"""Nightly publication must fail closed and remain retryable."""

import copy
import importlib.machinery
import importlib.util
import json
import os
import subprocess
import sys
import tempfile
import types
import unittest
from contextlib import ExitStack, nullcontext
from unittest import mock

try:
    import sia_test_home  # test-only import-time path isolation
except ModuleNotFoundError:
    from tests import sia_test_home  # type: ignore


REPO = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BIN = os.path.join(REPO, "bin")


def _load(name, path):
    loader = importlib.machinery.SourceFileLoader(name, path)
    spec = importlib.util.spec_from_loader(name, loader)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _graph_snapshot(slugs=()):
    slugs = sorted(slugs)
    return {
        "v": 2, "ts": "2026-08-30T12:00:00Z",
        "publication_id": "b" * 32,
        "nodes": [{
            "id": slug, "t": "note", "title": slug,
            "ts": "2026-08-30T12:00:00Z", "origin": "derived",
            "deg": 0, "din": 0, "dout": 0,
        } for slug in slugs],
        "edges": [], "pages_total": len(slugs),
        "pages_total_complete": True,
        "snapshot": {
            "complete": True, "truncated": 0,
            "omitted_nodes": 0, "omitted_edges": 0,
            "omissions_imply_absence": False,
            "aged_out": 0,
            "counts_by_kind": ({"note": len(slugs)} if slugs else {}),
            "failed_ops": [], "window_days": 14,
        },
    }


class DreamPublication(unittest.TestCase):
    def setUp(self):
        self.sialib = _load("sialib_dream_test", os.path.join(BIN, "sialib.py"))
        self.state_root = tempfile.TemporaryDirectory()
        self.old_state_paths = (
            self.sialib.STATE, self.sialib.CORPUS_OWNER_LOCK,
            self.sialib.THOUGHTS_PATH, self.sialib.siamind.MIND_PATH,
            self.sialib.LIFECYCLE_LOCK,
            self.sialib.LIFECYCLE_TOMBSTONE)
        self.sialib.STATE = self.state_root.name
        self.sialib.CORPUS_OWNER_LOCK = os.path.join(
            self.state_root.name, "corpus-owner.lock")
        self.sialib.THOUGHTS_PATH = os.path.join(
            self.state_root.name, "thoughts.json")
        self.sialib.siamind.MIND_PATH = os.path.join(
            self.state_root.name, "mind.json")
        self.sialib.LIFECYCLE_LOCK = os.path.join(
            self.state_root.name, "lifecycle.lock")
        self.sialib.LIFECYCLE_TOMBSTONE = os.path.join(
            self.state_root.name, "lifecycle-removed")
        self.memo = {
            "dream": {"last": "2026-08-29T12:00:00Z",
                      "status": "ok", "summary": "previous success"},
            "ready": {
                "v": 1, "completed_at": "2026-08-30T12:00:00Z",
                "kind": "recovery", "identity": "0" * 32,
            },
        }
        self.mind = {}
        self.corpus_pages = set()
        self.gbrain_calls = []
        self.mind_saves = []
        self.written_memo = None
        self.ledger_rows = []
        self.thought_rows = []
        self.trace = []
        self.consolidation_trace = []
        self.fake_bench = types.SimpleNamespace(run_quick=lambda: None)

    def tearDown(self):
        (self.sialib.STATE, self.sialib.CORPUS_OWNER_LOCK,
         self.sialib.THOUGHTS_PATH,
         self.sialib.siamind.MIND_PATH, self.sialib.LIFECYCLE_LOCK,
         self.sialib.LIFECYCLE_TOMBSTONE) = self.old_state_paths
        self.state_root.cleanup()

    def test_malformed_pulse_marker_precedes_dream_recovery(self):
        memo = {
            "pulse_seq": 7, "sync_needed": True,
            "pulse_publication": {
                "v": 1, "seq": 7, "id": "not-an-id",
                "started_at": "2026-08-30T12:00:00Z",
            },
        }
        with mock.patch.object(
                self.sialib, "load_memo", return_value=copy.deepcopy(memo)), \
                mock.patch.object(self.sialib, "load_cursors") as cursors, \
                mock.patch.object(self.sialib, "ensure_dirs") as ensure, \
                mock.patch.object(self.sialib, "_write_memo") as write:
            with self.assertRaisesRegex(
                    RuntimeError, "pulse publication recovery marker"):
                self.sialib._dream_transaction()
        cursors.assert_not_called()
        ensure.assert_not_called()
        write.assert_not_called()

        with mock.patch.object(
                self.sialib, "_recover_pending_thought_projection") \
                as thought_recovery:
            with self.assertRaisesRegex(
                    RuntimeError, "pulse publication recovery marker"):
                self.sialib._dream_transaction_guarded(
                    True, None, copy.deepcopy(memo), cursors={})
        thought_recovery.assert_not_called()

    def _schedule_rehearsal(self, *slugs, when=0.0):
        """Make pages genuinely due through the real usage/SM-2 planner.

        Seeding the mind is what drags the real per-page embed into this
        class' coverage instead of a hand-written report. Issue #3 shipped
        because that embed named no --source, so gbrain answered "Page not
        found" every night while the ledger recorded reviewed=0 for the
        project's whole life; a stubbed rehearsal cannot see that at all.
        """
        mind = copy.deepcopy(self.mind)
        mind.setdefault("nodes", {})
        mind.setdefault("edges", {})
        for slug in slugs:
            # arousal >= SM2_IMPORTANCE_AROUSAL makes the node important;
            # the second touch supplies the deterministic SM-2 quality
            # signal. Both go through siamind so the node shape is the one
            # production writes, not one this test invented.
            self.sialib.siamind.touch(mind, slug, ts=when, src="organ",
                                      arousal=0.8)
            self.sialib.siamind.touch(mind, slug, ts=when + 1.0,
                                      src="user-recall")
            self.corpus_pages.add(slug)
        self.mind = mind

    def _embed_like_gbrain(self, args):
        """Answer an embed the way the real gbrain binary answers it.

        gbrain resolves a slug inside exactly one registered source, so a
        missing --source is not a harmless argument difference: the binary
        searches "default", finds nothing, and refuses. Reproducing that
        refusal here means a dream cycle that ever loses --source again
        fails these tests instead of quietly reporting reviewed=0.
        """
        if list(args[2:]) != ["--source", self.sialib.GBRAIN_SOURCE]:
            return self._result(
                1, f"Page not found: {args[1]} (source=default)\n")
        return self._result(os.EX_OK)

    def _run(self, *, result, commit="clean", sync=(True, ""),
             graph=(False, False, False), embed=None, ledger=None,
             ledger_head=None,
             due_takes=None, grade_take=None, grade_summary=None,
             muse=None, save_mind=None, consolidate=None,
             add_thought=None, commit_grade=None, validate_mind=False,
             settle_signals=None, now=None):
        def capture_write(path, content, mode=None):
            if path != self.sialib.MEMO_PATH:
                os.makedirs(os.path.dirname(path), exist_ok=True)
                with open(path, "w", encoding="utf-8") as stream:
                    stream.write(content)
                return
            self.written_memo = json.loads(content)
            self.trace.append(
                ("memo", self.written_memo.get("sync_needed", False)))
            self.consolidation_trace.append(
                ("memo", self.written_memo.get(
                    "consolidation_pending", False)))

        def capture_ledger(*args):
            self.ledger_rows.append(args)
            self.consolidation_trace.append(("ledger", args[0]))

        def capture_thought(*args, **kwargs):
            self.sialib._before_corpus_mutation()
            self.trace.append(
                ("page", self.memo.get("sync_needed", False)))
            self.thought_rows.append(args + ((kwargs,) if kwargs else ()))

        # rehearse_memories is deliberately NOT stubbed in this class: the
        # whole nightly rehearsal runs for real and only the subprocess
        # boundary is faked here. Issue #3 lived for the project's entire
        # life behind a stub at the function boundary, which reported a
        # healthy shape while the real embed refused every night.
        def call_gbrain(args, timeout=120, json_out=False):
            self.gbrain_calls.append(list(args))
            if args and args[0] == "embed":
                return (embed or self._embed_like_gbrain)(list(args))
            return result

        def load_mind(*_args, **kwargs):
            value = copy.deepcopy(self.mind)
            if validate_mind:
                return self.sialib.siamind.migrate_mind(
                    value, now=kwargs.get("now"))
            return value

        def persist_mind(mind):
            if save_mind is not None:
                save_mind(mind)
            self.mind = copy.deepcopy(mind)
            self.mind_saves.append(copy.deepcopy(mind))

        def queue_transition(_order, action, arg1, arg2, content):
            row = (action, arg1, arg2, content)
            if ledger is not None:
                ledger(*row)
            else:
                capture_ledger(*row)
            return "pending-transition"

        patches = {
            "recover_ledger_transitions": (False, []),
            "load_thoughts": {"v": 1, "thoughts": []},
            "consolidate_corpus": (consolidate if consolidate is not None
                                   else (False, False, False)),
            "durable_ledger_append": ledger or capture_ledger,
            "queue_ledger_transition": queue_transition,
            "_settle_ledger_transition": None,
            "page_exists": lambda slug: slug in self.corpus_pages,
            "read_json": lambda *_args, **_kwargs: _graph_snapshot(
                self.mind.get("nodes", {})),
            "ledger_head": ((1, "a" * 64) if ledger_head is None
                            else ledger_head),
            "export_thoughts": None,
            "log": None,
            "gbrain": call_gbrain,
            "load_memo": self.memo,
            "add_thought": add_thought or capture_thought,
            "atomic_write": capture_write,
            "corpus_commit": commit,
            "brain_sync": sync,
            "export_graph": graph,
            "_settle_thought_page_signals": settle_signals or (0, 0),
        }
        with ExitStack() as stack:
            stack.enter_context(mock.patch.dict(sys.modules,
                                                {"siabench": self.fake_bench}))
            stack.enter_context(mock.patch.object(
                self.sialib.siatakes, "recover_grade_transactions",
                return_value=(False, [])))
            stack.enter_context(mock.patch.object(
                self.sialib.siatakes, "migrate_legacy_take_pages",
                return_value=([], [])))
            stack.enter_context(mock.patch.object(
                self.sialib.siatakes, "due_takes",
                return_value=[] if due_takes is None else due_takes))
            stack.enter_context(mock.patch.object(
                self.sialib.siatakes, "grade_take",
                grade_take or (lambda *_args, **_kwargs: None)))
            if commit_grade is not None:
                stack.enter_context(mock.patch.object(
                    self.sialib.siatakes, "commit_grade_transition",
                    side_effect=commit_grade))
            stack.enter_context(mock.patch.object(
                self.sialib.siatakes, "summary",
                return_value=({"resolved": 0} if grade_summary is None
                              else grade_summary)))
            stack.enter_context(mock.patch.object(
                self.sialib.siamind, "load_mind", side_effect=load_mind))
            stack.enter_context(mock.patch.object(
                self.sialib.siamind, "hebb_hygiene", return_value=False))
            stack.enter_context(mock.patch.object(
                self.sialib.siamind, "muse",
                muse or (lambda *_args, **_kwargs: None)))
            stack.enter_context(mock.patch.object(
                self.sialib.siamind, "save_mind",
                side_effect=persist_mind))
            for name, value in patches.items():
                replacement = value if callable(value) else mock.Mock(
                    return_value=value)
                stack.enter_context(mock.patch.object(
                    self.sialib, name, replacement))
            return self.sialib._dream_transaction(now=now)

    def _run_with_interphase_memory(self, *, fixed_clock=False):
        """Publication writes newer uses before subsequent maintenance reads."""
        clock = [1792308839.0]
        initial = clock[0]
        self._schedule_rehearsal("events/test/day")
        for index in range(9):
            self.sialib.siamind.touch(
                self.mind, f"notes/history-{index}", ts=1.0, src="organ")
        self.sialib.siamind.touch(
            self.mind, "notes/new-maintenance", ts=1.0, src="organ")
        real_muse = self.sialib.siamind.muse

        def publish_signals(_store):
            clock[0] += 20.0
            self.sialib.siamind.touch(
                self.mind, "notes/new-maintenance", ts=clock[0], src="organ")
            self.corpus_pages.add("notes/new-maintenance")
            return 1, 0

        with mock.patch.object(
                self.sialib.time, "time", side_effect=lambda: clock[0]):
            self._run(
                result=self._result(
                    os.EX_OK, json.dumps({"status": "ok", "totals": {}})),
                validate_mind=True, settle_signals=publish_signals,
                muse=real_muse, now=initial if fixed_clock else None)

    def test_live_dream_reads_memory_at_each_phase_clock(self):
        self._run_with_interphase_memory()
        failures = [row for row in self.ledger_rows
                    if row[0] in ("DREAM:rehearse", "DREAM:muse")
                    and row[1] == "error"]
        self.assertEqual(failures, [])
        self.assertIn(
            ["embed", "events/test/day", "--source", self.sialib.GBRAIN_SOURCE],
            self.gbrain_calls)

    def test_explicit_dream_clock_still_refuses_later_memory(self):
        self._run_with_interphase_memory(fixed_clock=True)
        failures = {row[0]: row[2] for row in self.ledger_rows
                    if row[0] in ("DREAM:rehearse", "DREAM:muse")
                    and row[1] == "error"}
        self.assertIn("chronological", failures["DREAM:rehearse"])
        self.assertIn("chronological", failures["DREAM:muse"])

    @staticmethod
    def _result(returncode, stdout="", stderr=""):
        return subprocess.CompletedProcess([], returncode, stdout, stderr)

    def test_failed_cycle_preserves_last_success_and_refuses(self):
        with self.assertRaisesRegex(RuntimeError, "gbrain dream cycle failed"):
            self._run(result=self._result(os.EX_SOFTWARE, stderr="failed"))
        self.assertEqual(self.written_memo["dream"]["last"],
                         "2026-08-29T12:00:00Z")
        self.assertEqual(self.written_memo["dream"]["status"], "failed")
        self.assertTrue(any(
            row[:3] == ("DREAM:cycle", "failed", "failed")
            for row in self.ledger_rows))

    def test_failed_cycle_redacts_diagnostic_before_memo_and_ledger(self):
        secret = "token=abcdefghijklmnop"
        prior = copy.deepcopy(self.sialib.REDACTIONS)
        self.sialib.REDACTIONS.clear()
        try:
            with self.assertRaisesRegex(
                    RuntimeError, "gbrain dream cycle failed"):
                self._run(result=self._result(
                    os.EX_SOFTWARE, stderr="subprocess " + secret))
        finally:
            self.sialib.REDACTIONS.clear()
            self.sialib.REDACTIONS.update(prior)
        serialized = json.dumps(self.written_memo, ensure_ascii=False)
        ledger = json.dumps(self.ledger_rows, ensure_ascii=False)
        self.assertNotIn(secret, serialized)
        self.assertNotIn(secret, ledger)
        self.assertIn("⟦redacted⟧", serialized)
        self.assertEqual(
            self.written_memo["redactions"], {"status-error": 1})

    def test_dream_marker_recovers_rebound_redactions_exactly_once(self):
        secret = "token=abcdefghijklmnop"
        memo = {
            "sync_needed": True, "redactions": {},
            "dream_publication": {
                "v": 1, "id": "a" * 32,
                "started_at": "2026-08-30T12:00:00Z",
                "redactions": {},
            },
        }
        durable = []
        prior = copy.deepcopy(self.sialib.REDACTIONS)
        self.sialib.REDACTIONS.clear()
        try:
            with mock.patch.object(
                    self.sialib, "_write_memo",
                    side_effect=lambda value:
                        durable.append(copy.deepcopy(value))):
                detail = self.sialib._dream_diagnostic(
                    memo, "projection " + secret, 120)
            self.assertNotIn(secret, detail)
            crash_image = copy.deepcopy(durable[-1])
            self.assertEqual(crash_image["redactions"], {})
            self.assertEqual(
                crash_image["dream_publication"]["redactions"],
                {"status-error": 1})

            with mock.patch.object(
                    self.sialib, "_write_memo",
                    side_effect=lambda value:
                        durable.append(copy.deepcopy(value))), \
                    mock.patch.object(
                        self.sialib, "queue_ledger_transition",
                        return_value="pending"), \
                    mock.patch.object(
                        self.sialib, "_settle_ledger_transition"):
                self.assertTrue(
                    self.sialib._recover_pending_dream_publication(
                        crash_image))
                self.assertFalse(
                    self.sialib._recover_pending_dream_publication(
                        crash_image))
            self.assertEqual(
                crash_image["redactions"], {"status-error": 1})
            self.assertNotIn("dream_publication", crash_image)
        finally:
            self.sialib.REDACTIONS.clear()
            self.sialib.REDACTIONS.update(prior)

    def test_skipped_cycle_preserves_last_success_and_refuses(self):
        report = {"status": "skipped", "reason": "owner busy"}
        with self.assertRaisesRegex(RuntimeError, "gbrain dream cycle skipped"):
            self._run(result=self._result(os.EX_OK, json.dumps(report)))
        self.assertEqual(self.written_memo["dream"]["last"],
                         "2026-08-29T12:00:00Z")
        self.assertEqual(self.written_memo["dream"]["status"], "skipped")

    def test_commit_failure_refuses_before_sync(self):
        with self.assertRaisesRegex(RuntimeError, "corpus git commit failed"):
            self._run(result=self._result(
                os.EX_OK, json.dumps({"status": "ok", "totals": {}})),
                commit="error")
        self.assertEqual(self.ledger_rows[-1][:2],
                         ("DREAM:publish", "error"))
        self.assertIs(self.written_memo.get("sync_needed"), True)

    def test_sync_failure_refuses_and_records_transition(self):
        with self.assertRaisesRegex(RuntimeError, "index sync failed"):
            self._run(result=self._result(
                os.EX_OK, json.dumps({"status": "ok", "totals": {}})),
                sync=(False, "sync refused"))
        self.assertEqual(self.ledger_rows[-1][:2],
                         ("DREAM:publish", "sync-fail"))
        self.assertIs(self.written_memo.get("sync_needed"), True)

    def test_graph_publication_exception_is_signed_and_refused(self):
        secret = "token=abcdefghijklmnop"

        def graph_failure():
            raise OSError("graph refused " + secret)

        with self.assertRaisesRegex(RuntimeError, "publication failed"):
            self._run(result=self._result(
                os.EX_OK, json.dumps({"status": "ok", "totals": {}})),
                graph=graph_failure)
        self.assertEqual(self.ledger_rows[-1][:2],
                         ("DREAM:publish", "error"))
        self.assertNotIn(secret, json.dumps(
            self.ledger_rows[-1], ensure_ascii=False))
        self.assertIn("⟦redacted⟧", self.ledger_rows[-1][2])
        self.assertEqual(
            self.written_memo["dream_publication"]["redactions"],
            {"status-error": 1})
        self.assertIs(self.written_memo.get("sync_needed"), True)

    def test_success_returns_report_and_records_publication(self):
        report = {"status": "ok", "totals": {}}

        def graph():
            self.trace.append(
                ("graph", self.memo.get("sync_needed", False)))
            return False, False, False

        self.assertEqual(
            self._run(result=self._result(os.EX_OK, json.dumps(report)),
                      graph=graph),
            report)
        self.assertEqual(self.written_memo["dream"]["status"], "ok")
        self.assertEqual(self.ledger_rows[-1][:2],
                         ("DREAM:publish", "ok"))
        self.assertIn(("graph", True), self.trace)
        self.assertNotIn("sync_needed", self.written_memo)
        self.assertGreater(
            max(i for i, row in enumerate(self.trace)
                if row == ("memo", False)),
            self.trace.index(("graph", True)))

    def test_dream_rehearsal_embeds_in_the_registered_source(self):
        """The nightly embed must address gbrain's registered source.

        This is issue #3 itself: the per-page embed named no --source for
        the project's whole life, gbrain resolved the slug in "default",
        answered "Page not found", and the ledger recorded reviewed=0 every
        night while nobody read it. The cycle is driven end to end here so
        losing --source again breaks a test instead of a year of sleep.
        """
        self._schedule_rehearsal("events/test/day")
        self._run(result=self._result(
            os.EX_OK, json.dumps({"status": "ok", "totals": {}})))
        self.assertIn(
            ["embed", "events/test/day", "--source",
             self.sialib.GBRAIN_SOURCE], self.gbrain_calls)
        rehearsed = [row for row in self.ledger_rows
                     if row[0] == "DREAM:rehearse"]
        self.assertEqual(rehearsed[-1][1], "reviewed=1")
        self.assertIn("embedded=1 failed=0 missing=0", rehearsed[-1][2])
        rested = [row for row in self.thought_rows
                  if row[1] == "dream"
                  and "Scheduled re-embedding completed for 1 priority pages" in row[2]]
        self.assertEqual(len(rested), 1)
        self.assertIs(rested[0][4], False)
        # The SM-2 schedule only advances on a committed embed, so a
        # persisted review record is the proof the real path ran.
        self.assertEqual(
            self.mind["nodes"]["events/test/day"]["review"]["reviews"], 1)

    def test_bounded_rehearsal_deferral_is_signed_and_visible(self):
        slugs = tuple(
            f"events/deferred/page-{index}"
            for index in range(self.sialib.siamind.WORKSPACE_K + 1))
        self._schedule_rehearsal(*slugs)
        self._run(result=self._result(
            os.EX_OK, json.dumps({"status": "ok", "totals": {}})))

        embeds = [call for call in self.gbrain_calls if call[0] == "embed"]
        self.assertEqual(len(embeds), self.sialib.siamind.WORKSPACE_K)
        rehearsed = [row for row in self.ledger_rows
                     if row[0] == "DREAM:rehearse"]
        self.assertIn(
            f"deferred={len(slugs) - self.sialib.siamind.WORKSPACE_K}",
            rehearsed[-1][2])
        published = [row for row in self.thought_rows
                     if row[1] == "dream" and "Scheduled re-embedding completed" in row[2]]
        self.assertEqual(len(published), 1)
        self.assertIn("due memory deferred", published[0][2])

    def test_multiwindow_deferral_does_not_promise_the_next_window(self):
        slugs = tuple(
            f"events/multiwindow/page-{index}"
            for index in range(self.sialib.siamind.WORKSPACE_K * 3))
        self._schedule_rehearsal(*slugs)
        self._run(result=self._result(
            os.EX_OK, json.dumps({"status": "ok", "totals": {}})))

        embeds = [call for call in self.gbrain_calls if call[0] == "embed"]
        deferred = len(slugs) - len(embeds)
        self.assertGreater(deferred, self.sialib.siamind.WORKSPACE_K)
        published = [row for row in self.thought_rows
                     if row[1] == "dream" and "Scheduled re-embedding completed" in row[2]]
        self.assertEqual(len(published), 1)
        self.assertIn(
            "remain due for later rotating nightly windows", published[0][2])
        self.assertNotIn("to the next nightly window", published[0][2])

    def test_partial_rehearsal_failure_is_not_hidden_by_one_success(self):
        self._schedule_rehearsal("events/partial/available",
                                 "events/partial/refused")

        def partial(args):
            if args[1].endswith("/refused"):
                return self._result(1, "embedding runtime refused\n")
            return self._embed_like_gbrain(args)

        self._run(result=self._result(
            os.EX_OK, json.dumps({"status": "ok", "totals": {}})),
            embed=partial)
        published = [row for row in self.thought_rows
                     if row[1] == "dream" and "Scheduled re-embedding completed" in row[2]]
        self.assertEqual(len(published), 1)
        self.assertIn("1 embed failure", published[0][2])
        self.assertIs(published[0][4], True)

    def test_rehearsal_total_failure_emits_urgent_thought(self):
        self._schedule_rehearsal("events/a", "events/b")

        def refuse(args):
            return self._result(
                1, f"Page not found: {args[1]} (source=default)\n")

        self._run(result=self._result(
            os.EX_OK, json.dumps({"status": "ok", "totals": {}})),
            embed=refuse)
        self.assertEqual(
            [call for call in self.gbrain_calls if call[0] == "embed"],
            [["embed", "events/a", "--source", self.sialib.GBRAIN_SOURCE],
             ["embed", "events/b", "--source", self.sialib.GBRAIN_SOURCE]])
        failing = [row for row in self.thought_rows
                   if row[1] == "dream"
                   and "re-embedding did not complete" in row[2]]
        self.assertEqual(len(failing), 1)
        self.assertIn("2 embed failure(s)", failing[0][2])
        self.assertIn("Page not found", failing[0][2])
        self.assertEqual(failing[0][3], ["events/a", "events/b"])
        self.assertIs(failing[0][4], True)
        # A refused embed must not advance the schedule; the page stays due
        # so tomorrow retries it rather than silently dropping it.
        self.assertIsNone(
            self.mind["nodes"]["events/a"]["review"]["last_quality"])

    def test_missing_corpus_page_is_reported_without_an_embed(self):
        """A page the corpus no longer holds is never handed to gbrain."""
        self._schedule_rehearsal("events/test/day")
        self.corpus_pages.clear()
        self._run(result=self._result(
            os.EX_OK, json.dumps({"status": "ok", "totals": {}})))
        self.assertEqual(
            [call for call in self.gbrain_calls if call[0] == "embed"], [])
        failing = [row for row in self.thought_rows
                   if row[1] == "dream"
                   and "re-embedding did not complete" in row[2]]
        self.assertEqual(len(failing), 1)
        self.assertIn("1 missing page(s)", failing[0][2])
        rehearsed = [row for row in self.ledger_rows
                     if row[0] == "DREAM:rehearse"]
        self.assertIn("embedded=0 failed=0 missing=1", rehearsed[-1][2])

    def test_rehearsal_subprocess_failure_stays_in_its_own_domain(self):
        """A crashing embed is signed and never blocks the dream cycle.

        Rehearsal is one failure domain among several on purpose: a broken
        embed must not cost the night its gbrain cycle or its publication.
        """
        def explode(_args):
            raise OSError("gbrain binary vanished")

        report = {"status": "ok", "totals": {}}
        self._schedule_rehearsal("events/test/day")
        self.assertEqual(
            self._run(result=self._result(os.EX_OK, json.dumps(report)),
                      embed=explode),
            report)
        errors = [row for row in self.ledger_rows
                  if row[0] == "DREAM:rehearse" and row[1] == "error"]
        self.assertEqual(len(errors), 1)
        self.assertIn("gbrain binary vanished", errors[0][2])
        self.assertEqual(self.ledger_rows[-1][:2],
                         ("DREAM:publish", "ok"))
        self.assertNotIn("dream_unit", self.mind)

    def test_write_ahead_marker_precedes_consolidation_mutation(self):
        def consolidate():
            self.sialib._before_corpus_mutation()
            self.trace.append(
                ("consolidate", self.memo.get("sync_needed", False)))
            return 1, 1, 0

        self._run(
            result=self._result(
                os.EX_OK, json.dumps({"status": "ok", "totals": {}})),
            consolidate=consolidate)
        self.assertLess(self.trace.index(("memo", True)),
                        self.trace.index(("consolidate", True)))

    def test_consolidation_exception_leaves_write_ahead_marker_durable(self):
        def consolidate():
            self.sialib._before_corpus_mutation()
            self.trace.append(
                ("consolidate", self.memo.get("sync_needed", False)))
            raise self.sialib.LedgerTransitionError("keeper refused")

        with self.assertRaisesRegex(
                RuntimeError, "consolidation requires recovery"):
            self._run(
                result=self._result(
                    os.EX_OK, json.dumps({"status": "ok", "totals": {}})),
                consolidate=consolidate)
        self.assertIs(self.written_memo.get("sync_needed"), True)
        consolidate_index = self.trace.index(("consolidate", True))
        self.assertTrue(any(
            row == ("memo", True)
            for row in self.trace[:consolidate_index]))

    def test_consolidation_success_is_signed_before_marker_clear(self):
        def consolidate():
            self.sialib._before_corpus_mutation()
            return 1, 1, 0

        self._run(
            result=self._result(
                os.EX_OK, json.dumps({"status": "ok", "totals": {}})),
            consolidate=consolidate)
        signed = self.consolidation_trace.index(
            ("ledger", "DREAM:consolidate"))
        cleared = next(
            index for index, row in enumerate(self.consolidation_trace)
            if index > signed and row == ("memo", False))
        self.assertLess(signed, cleared)

    def test_recovery_is_signed_before_consolidation_marker_clear(self):
        memo = {"consolidation_pending": {
            "v": 1, "id": "a" * 32,
            "started_at": "2026-08-30T12:00:00Z",
        }, "sync_needed": True}
        trace = []

        def queue(_order, action, _arg1, _arg2, _content):
            trace.append(("ledger", action))
            return "pending"

        def write(_path, payload, mode=None):
            trace.append(("memo", json.loads(payload).get(
                "consolidation_pending", False)))

        with mock.patch.object(self.sialib, "consolidate_corpus",
                               return_value=(1, 1, 0)), \
                mock.patch.object(self.sialib, "queue_ledger_transition",
                                  side_effect=queue), \
                mock.patch.object(self.sialib, "_settle_ledger_transition"), \
                mock.patch.object(self.sialib, "atomic_write",
                                  side_effect=write):
            self.assertEqual(
                self.sialib._recover_pending_consolidation(memo),
                (1, 1, 0))
        signed = trace.index(("ledger", "RECOVER:consolidate"))
        cleared = next(
            index for index, row in enumerate(trace)
            if index > signed and row == ("memo", False))
        self.assertLess(signed, cleared)

    def test_recovery_keeper_failure_retains_consolidation_marker(self):
        memo = {"consolidation_pending": {
            "v": 1, "id": "b" * 32,
            "started_at": "2026-08-30T12:00:00Z",
        }, "sync_needed": True}
        with mock.patch.object(self.sialib, "consolidate_corpus",
                               return_value=(1, 1, 0)), \
                mock.patch.object(
                    self.sialib, "queue_ledger_transition",
                    return_value="pending"), \
                mock.patch.object(
                    self.sialib, "_settle_ledger_transition",
                    side_effect=self.sialib.LedgerTransitionError(
                        "keeper refused")), \
                mock.patch.object(self.sialib, "atomic_write") as write:
            with self.assertRaisesRegex(
                    self.sialib.LedgerTransitionError, "keeper refused"):
                self.sialib._recover_pending_consolidation(memo)
        self.assertIsInstance(memo.get("consolidation_pending"), dict)
        self.assertIn("ledger", memo["consolidation_pending"])
        self.assertIn("applied_at", memo["consolidation_pending"])
        self.assertTrue(write.called)

    def test_rehearsal_keeper_failure_cannot_save_and_retry_can_commit(self):
        self._schedule_rehearsal("events/test/day")
        refuse_once = [True]

        def keeper(*row):
            self.ledger_rows.append(row)
            if row[0] == "DREAM:rehearse" and refuse_once[0]:
                refuse_once[0] = False
                raise self.sialib.LedgerTransitionError("keeper refused")

        cycle = self._result(
            os.EX_OK, json.dumps({"status": "ok", "totals": {}}))
        with self.assertRaisesRegex(
                self.sialib.LedgerTransitionError, "keeper refused"):
            self._run(result=cycle, ledger=keeper)
        # Exactly one mind save: rehearsal's own. The settle that the
        # keeper refused must not have written a second, unsigned one.
        self.assertEqual(len(self.mind_saves), 1)
        self.assertEqual(self.mind["dream_unit"]["unit"], "rehearse")
        self.assertEqual(
            self.mind["nodes"]["events/test/day"]["review"]["last_quality"],
            5)

        self._run(result=cycle, ledger=keeper)
        self.assertNotIn("dream_unit", self.mind)
        attempts = [row for row in self.ledger_rows
                    if row[0] == "DREAM:rehearse"]
        self.assertGreaterEqual(len(attempts), 2)

    def test_rehearsal_function_publishes_before_mind_save(self):
        minds = [{}, {}]
        saved = []
        refuse_once = [True]

        def apply_rehearsal(mind, plan, now=None):
            mind["reviewed"] = plan["slug"]
            return {"slug": plan["slug"], "quality": 5}

        def publish(_mind, _report):
            if refuse_once[0]:
                refuse_once[0] = False
                raise self.sialib.LedgerTransitionError("keeper refused")

        patches = (
            mock.patch.object(
                self.sialib, "read_json",
                return_value=_graph_snapshot()),
            mock.patch.object(self.sialib, "page_exists", return_value=True),
            mock.patch.object(
                self.sialib, "gbrain", return_value=self._result(os.EX_OK)),
            mock.patch.object(
                self.sialib.siamind, "load_mind", side_effect=minds),
            mock.patch.object(
                self.sialib.siamind, "sync_graph_state", return_value=None),
            mock.patch.object(
                self.sialib.siamind, "plan_rehearsal",
                return_value=[{"slug": "events/test/day"}]),
            mock.patch.object(
                self.sialib.siamind, "apply_rehearsal",
                side_effect=apply_rehearsal),
            mock.patch.object(
                self.sialib.siamind, "decay_sweep", return_value={}),
            mock.patch.object(
                self.sialib.siamind, "save_mind",
                side_effect=lambda mind: saved.append(dict(mind))),
        )
        with ExitStack() as stack:
            for patch in patches:
                stack.enter_context(patch)
            with self.assertRaisesRegex(
                    self.sialib.LedgerTransitionError, "keeper refused"):
                self.sialib.rehearse_memories(now=1, stage=publish)
            self.assertEqual(saved, [])
            self.sialib.rehearse_memories(now=1, stage=publish)

        self.assertEqual(saved, [{"reviewed": "events/test/day",
                                  "rehearsal_cursor": 0}])

    def test_musing_keeper_failure_cannot_save_and_retry_can_commit(self):
        state_saves = []
        refuse_once = [True]

        def muse(mind, *_args, **_kwargs):
            mind["musing_day"] = "prepared"
            return ("association", ["sia/cortex"])

        def save_mind(mind):
            state_saves.append(dict(mind))

        def keeper(*row):
            self.ledger_rows.append(row)
            if row[0] == "DREAM:muse" and refuse_once[0]:
                refuse_once[0] = False
                raise self.sialib.LedgerTransitionError("keeper refused")

        cycle = self._result(
            os.EX_OK, json.dumps({"status": "ok", "totals": {}}))
        with self.assertRaisesRegex(
                self.sialib.LedgerTransitionError, "keeper refused"):
            self._run(result=cycle, ledger=keeper, muse=muse,
                      save_mind=save_mind)
        self.assertEqual(self.mind["dream_unit"]["unit"], "muse")
        self.assertEqual(state_saves[-1]["dream_unit"]["unit"], "muse")

        self._run(result=cycle, ledger=keeper, muse=muse,
                  save_mind=save_mind)
        self.assertNotIn("dream_unit", self.mind)
        attempts = [row for row in self.ledger_rows
                    if row[0] == "DREAM:muse"]
        self.assertGreaterEqual(len(attempts), 2)

    def test_musing_refuses_an_unobserved_ledger_head_before_model_work(self):
        muse = mock.Mock(return_value=("association", ["sia/cortex"]))
        cycle = self._result(
            os.EX_OK, json.dumps({"status": "ok", "totals": {}}))
        self._run(result=cycle, muse=muse, ledger_head=(0, ""))
        muse.assert_not_called()
        errors = [row for row in self.ledger_rows
                  if row[:2] == ("DREAM:muse", "error")]
        self.assertEqual(len(errors), 1)
        self.assertIn("ledger head", errors[0][2])

    def test_due_grade_refusals_are_not_signed_as_none_due(self):
        report = {"status": "ok", "totals": {}}
        with self.assertRaisesRegex(RuntimeError, "due grading remains pending"):
            self._run(
                result=self._result(os.EX_OK, json.dumps(report)),
                due_takes=[{"id": "due-take"}],
                grade_take=lambda *_args, **_kwargs: None)
        grade_rows = [row for row in self.ledger_rows
                      if row[0] == "DREAM:grade"]
        self.assertEqual(grade_rows, [
            ("DREAM:grade", "refused",
             "attempted=1 completed=0 refused=1")])
        self.assertEqual(self.written_memo["dream"]["last"],
                         "2026-08-29T12:00:00Z")
        self.assertEqual(self.written_memo["dream"]["status"], "grading-pending")
        self.assertIn(("DREAM:grade-refused", "due-take",
                       "grader returned no completed result"), self.ledger_rows)

    def test_judge_refusal_reason_is_logged_and_next_take_is_attempted(self):
        attempts = []

        def refuse(row, **_kwargs):
            attempts.append(row["id"])
            raise self.sialib.siatakes.GradingJudgeUnavailable(
                "judge service unavailable")

        with self.assertRaisesRegex(RuntimeError, "due grading remains pending"):
            self._run(
                result=self._result(os.EX_OK, json.dumps({"status": "ok"})),
                due_takes=[{"id": "first"}, {"id": "second"}],
                grade_take=refuse)
        self.assertEqual(attempts, ["first", "second"])
        self.assertIn(("DREAM:grade-refused", "first",
                       "judge service unavailable"), self.ledger_rows)

    def test_durable_retry_cursor_rotates_after_restart_and_clears_on_success(self):
        report = self._result(os.EX_OK, json.dumps({"status": "ok"}))
        due = [{"id": name} for name in ("first", "second", "third", "fourth")]
        attempted = []

        def refuse(row, **_kwargs):
            attempted.append(row["id"])
            return None

        with self.assertRaisesRegex(RuntimeError, "due grading remains pending"):
            self._run(result=report, due_takes=due, grade_take=refuse)
        self.assertEqual(attempted, ["first", "second", "third"])
        self.assertEqual(self.written_memo["grade_retry_after"], "third")
        self.assertTrue(self.sialib._status_dream_shape(self.written_memo["dream"]))
        self.assertNotIn("dream_publication", self.written_memo)
        self.memo = copy.deepcopy(self.written_memo)
        attempted.clear()
        def forbid_compaction():
            self.fail("grading retry reran compaction")

        with self.assertRaisesRegex(RuntimeError, "due grading remains pending"):
            self._run(result=report, due_takes=due, grade_take=refuse,
                      consolidate=forbid_compaction)
        self.assertEqual(attempted, ["fourth", "first", "second"])
        self.assertEqual([row for row in self.gbrain_calls if row[0] == "dream"],
                         [["dream", "--json", "--phase", "lint", "--phase", "backlinks",
                          "--phase", "sync", "--phase", "extract",
                          "--phase", "recompute_emotional_weight",
                          "--phase", "embed", "--phase", "orphans", "--phase", "purge"]])
        self.memo = copy.deepcopy(self.written_memo)
        self._run(result=report, due_takes=[], consolidate=forbid_compaction)
        self.assertEqual(self.written_memo["dream"]["status"], "ok")
        self.assertEqual([row for row in self.gbrain_calls if row[0] == "dream"],
                         [["dream", "--json", "--phase", "lint", "--phase", "backlinks",
                          "--phase", "sync", "--phase", "extract",
                          "--phase", "recompute_emotional_weight",
                          "--phase", "embed", "--phase", "orphans", "--phase", "purge"]])

    def test_persistent_grade_refusal_does_not_starve_next_days_maintenance(self):
        report = self._result(os.EX_OK, json.dumps({"status": "ok"}))
        with self.assertRaisesRegex(RuntimeError, "due grading remains pending"):
            self._run(result=report, due_takes=[{"id": "refused"}])
        self.memo = copy.deepcopy(self.written_memo)
        tomorrow = self.sialib.utcnow() + self.sialib.datetime.timedelta(days=1)
        with mock.patch.object(self.sialib, "utcnow", return_value=tomorrow), \
                self.assertRaisesRegex(RuntimeError, "due grading remains pending"):
            self._run(result=report, due_takes=[{"id": "refused"}])
        self.assertEqual([row for row in self.gbrain_calls if row[0] == "dream"],
                         [["dream", "--json", "--phase", "lint", "--phase", "backlinks",
                          "--phase", "sync", "--phase", "extract",
                          "--phase", "recompute_emotional_weight",
                          "--phase", "embed", "--phase", "orphans", "--phase", "purge"], ["dream", "--json", "--phase", "lint", "--phase", "backlinks",
                          "--phase", "sync", "--phase", "extract",
                          "--phase", "recompute_emotional_weight",
                          "--phase", "embed", "--phase", "orphans", "--phase", "purge"]])

    def test_grading_retry_does_not_promote_partial_maintenance_to_ok(self):
        report = self._result(os.EX_OK, json.dumps({"status": "partial"}))
        with self.assertRaisesRegex(RuntimeError, "due grading remains pending"):
            self._run(result=report, due_takes=[{"id": "refused"}])
        self.assertEqual(self.written_memo["grade_retry_cycle_status"], "partial")
        self.memo = copy.deepcopy(self.written_memo)
        self.assertEqual(self._run(result=report, due_takes=[]),
                         {"status": "partial", "grading_only": True})
        self.assertEqual(self.written_memo["dream"]["status"], "partial")
        self.assertNotIn("grade_retry_cycle_status", self.written_memo)

    def test_multigrade_publishes_before_next_gbrain_grade(self):
        takes = [
            {"id": "first", "claim": "first held"},
            {"id": "second", "claim": "second held"},
        ]

        def commit_grade(row, _verdict, _justification, _evidence,
                         before_publish=None):
            before_publish()
            self.trace.append((
                "grade-page", row["id"],
                self.memo.get("sync_needed", False)))

        def grade_take(row, persist=None):
            self.trace.append((
                "gbrain-grade", row["id"],
                self.memo.get("sync_needed", False)))
            self.assertNotIn("sync_needed", self.memo)
            persist(row, "resolved-true", "held", [])
            self.assertNotIn("sync_needed", self.memo)
            return {"status": "resolved-true", "brier": None,
                    "claim": row["claim"], "slug": "takes/" + row["id"]}

        def corpus_commit(_message):
            self.trace.append(
                ("commit", self.memo.get("sync_needed", False)))
            return "committed"

        def brain_sync():
            self.trace.append(
                ("sync", self.memo.get("sync_needed", False)))
            return True, ""

        def export_graph():
            self.trace.append(
                ("graph", self.memo.get("sync_needed", False)))
            return False, False, False

        self._run(
            result=self._result(
                os.EX_OK, json.dumps({"status": "ok", "totals": {}})),
            due_takes=takes, grade_take=grade_take,
            commit_grade=commit_grade, commit=corpus_commit,
            sync=brain_sync, graph=export_graph,
            grade_summary={"resolved": 0})

        first = self.trace.index(("gbrain-grade", "first", False))
        second = self.trace.index(("gbrain-grade", "second", False))
        between = self.trace[first:second]
        self.assertIn(("grade-page", "first", True), between)
        self.assertIn(("graph", True), between)
        self.assertIn(("memo", False), between)
        self.assertNotIn("sync_needed", self.memo)

    def test_multigrade_publication_failure_aborts_later_grade_and_cycle(self):
        takes = [
            {"id": "first", "claim": "first held"},
            {"id": "second", "claim": "second held"},
        ]
        judged = []

        def commit_grade(_row, _verdict, _justification, _evidence,
                         before_publish=None):
            before_publish()

        def grade_take(row, persist=None):
            judged.append(row["id"])
            persist(row, "resolved-true", "held", [])
            return {"status": "resolved-true", "brier": None,
                    "claim": row["claim"], "slug": "takes/" + row["id"]}

        gbrain_cycle = mock.Mock(return_value=self._result(
            os.EX_OK, json.dumps({"status": "ok", "totals": {}})))
        with self.assertRaisesRegex(RuntimeError, "pending index sync failed"):
            self._run(
                result=gbrain_cycle, due_takes=takes,
                grade_take=grade_take, commit_grade=commit_grade,
                commit="committed", sync=(False, "index refused"),
                grade_summary={"resolved": 0})

        self.assertEqual(judged, ["first"])
        self.assertIs(self.memo.get("sync_needed"), True)
        gbrain_cycle.assert_not_called()

    def test_none_due_is_reserved_for_an_empty_due_set(self):
        self._run(result=self._result(
            os.EX_OK, json.dumps({"status": "ok", "totals": {}})))
        grade_rows = [row for row in self.ledger_rows
                      if row[0] == "DREAM:grade"]
        self.assertEqual(grade_rows, [("DREAM:grade", "none-due", "")])

    def test_nightly_grade_thought_is_model_origin(self):
        grade = {
            "status": "resolved-true", "brier": None,
            "claim": "the held outcome", "slug": "takes/held"}
        self._run(
            result=self._result(
                os.EX_OK, json.dumps({"status": "ok", "totals": {}})),
            due_takes=[{"id": "due-take"}],
            grade_take=lambda *_args, **_kwargs: grade)
        grade_thoughts = [row for row in self.thought_rows
                          if len(row) > 1 and row[1] == "grade"]
        self.assertEqual(len(grade_thoughts), 1)
        self.assertEqual(grade_thoughts[0][-1], {"origin": "model"})

    def test_quick_tripwire_uses_explicit_heuristic_metrics(self):
        self.fake_bench = types.SimpleNamespace(run_quick=lambda: {
            "schema": "sia-heuristic-slug-retrieval-tripwire-v1",
            "kind": "heuristic-slug-retrieval-drift-tripwire",
            "date": "2026-08-30",
            "probe_count": 4,
            "slug_match_at_5_blend": 0.75,
            "slug_match_at_5_keyword": 0.5,
            "reciprocal_slug_rank_blend": 0.5,
            "reciprocal_slug_rank_keyword": 0.25,
            "non_claims": ["no answer correctness"],
        })
        report = {"status": "ok", "totals": {}}
        with tempfile.TemporaryDirectory() as state, mock.patch.object(
                self.sialib, "STATE", state):
            self._run(result=self._result(os.EX_OK, json.dumps(report)))
            trend = self.sialib._bench_trend_snapshot(
                os.path.join(state, "bench-trend.jsonl"))

        self.assertEqual(trend[0]["slug_match_at_5"], 0.75)
        bench_rows = [row for row in self.ledger_rows
                      if row and row[0] == "DREAM:bench"]
        self.assertEqual(bench_rows[0][1], "blend-slug-match@5=0.75")
        self.assertIn("no answer correctness was evaluated",
                      " ".join(str(value) for row in self.thought_rows
                               for value in row))

    def test_bench_trend_migrates_legacy_name_and_skips_bad_rows(self):
        with tempfile.TemporaryDirectory() as state:
            path = os.path.join(state, "bench-trend.jsonl")
            with open(path, "w", encoding="utf-8") as stream:
                stream.write('{"date":"2026-08-28","hit5_blend":0.25}\n')
                stream.write('not json\n')
                stream.write('{"date":"2026-08-29","hit5_blend":true}\n')
                stream.write('{"date":"2026-99-99",'
                             '"slug_match_at_5_blend":0.5}\n')
                stream.write('{"date":"2026-08-30",'
                             '"slug_match_at_5_blend":0.75}\n')
            rows, boundary = self.sialib._bench_trend_snapshot(
                path, include_metadata=True)

        self.assertEqual(
            rows,
            [{"date": "2026-08-28", "slug_match_at_5": 0.25,
              "kind": "heuristic-slug-retrieval-drift-tripwire"},
             {"date": "2026-08-30", "slug_match_at_5": 0.75,
              "kind": "heuristic-slug-retrieval-drift-tripwire"}])
        self.assertEqual(boundary, {"legacy_truncated": True})
        self.assertTrue(self.sialib._status_bench_trend_shape(rows))

    def test_bench_trend_upgrade_reads_only_bounded_legacy_tail(self):
        with tempfile.TemporaryDirectory() as state:
            path = os.path.join(state, "bench-trend.jsonl")
            with open(path, "w", encoding="utf-8") as stream:
                for _index in range(32):
                    stream.write(
                        '{"date":"2026-08-28","hit5_blend":0.25}\n')
            rows = self.sialib._bench_trend_snapshot(path)
        self.assertEqual(len(rows), self.sialib.MAX_BENCH_TREND_ROWS)
        self.assertTrue(all(
            row["slug_match_at_5"] == 0.25 for row in rows))

    def test_bench_trend_symlink_is_refused_without_following(self):
        with tempfile.TemporaryDirectory() as state:
            target = os.path.join(state, "target.jsonl")
            with open(target, "w", encoding="utf-8") as stream:
                stream.write(
                    '{"date":"2026-08-28","hit5_blend":0.25}\n')
            link = os.path.join(state, "bench-trend.jsonl")
            os.symlink(target, link)
            with self.assertRaises(OSError):
                self.sialib._bench_trend_snapshot(link)

    def test_bench_trend_newline_free_legacy_overflow_is_exposed_and_empty(self):
        with tempfile.TemporaryDirectory() as state:
            path = os.path.join(state, "bench-trend.jsonl")
            with open(path, "wb") as stream:
                stream.write(
                    b"x" * (self.sialib.MAX_BENCH_TREND_BYTES + 1))
            rows, boundary = self.sialib._bench_trend_snapshot(
                path, include_metadata=True)
        self.assertEqual(rows, [])
        self.assertTrue(boundary["legacy_truncated"])

    def test_bench_trend_legacy_line_ceiling_retains_recent_complete_rows(self):
        with tempfile.TemporaryDirectory() as state:
            path = os.path.join(state, "bench-trend.jsonl")
            with open(path, "w", encoding="utf-8") as stream:
                for index in range(
                        self.sialib.MAX_BENCH_TREND_INPUT_LINES + 1):
                    stream.write(json.dumps({
                        "date": "2026-08-30",
                        "hit5_blend": 0.25,
                        "legacy_index": index,
                    }) + "\n")
            rows, boundary = self.sialib._bench_trend_snapshot(
                path, include_metadata=True)
        self.assertEqual(len(rows), self.sialib.MAX_BENCH_TREND_ROWS)
        self.assertTrue(boundary["legacy_truncated"])

    def test_bench_trend_replacement_during_read_is_refused(self):
        with tempfile.TemporaryDirectory() as state:
            path = os.path.join(state, "bench-trend.jsonl")
            replacement = os.path.join(state, "replacement.jsonl")
            with open(path, "w", encoding="utf-8") as stream:
                stream.write(
                    '{"date":"2026-08-28","hit5_blend":0.25}\n')
            with open(replacement, "w", encoding="utf-8") as stream:
                stream.write(
                    '{"date":"2026-08-29","hit5_blend":0.75}\n')
            real_lstat = os.lstat

            def replace_then_stat(candidate):
                os.replace(replacement, path)
                return real_lstat(candidate)

            with mock.patch.object(
                    self.sialib.os, "lstat",
                    side_effect=replace_then_stat), \
                    self.assertRaisesRegex(ValueError, "changed"):
                self.sialib._bench_trend_snapshot(path)

    def test_bench_trend_rotates_before_receipt_can_deadlock_recovery(self):
        with tempfile.TemporaryDirectory() as state, \
                mock.patch.object(self.sialib, "STATE", state), \
                mock.patch.object(self.sialib, "MAX_MEMO_BYTES", 180):
            path = os.path.join(state, "bench-trend.jsonl")
            with open(path, "wb") as stream:
                stream.write(b'{"legacy":"' + b"x" * 130 + b'"}\n')
            record = {"date": "2026-08-30", "slug_match_at_5": 0.75}
            receipt_id = "a" * 32
            self.assertTrue(self.sialib._append_bench_trend_once(
                record, receipt_id))
            self.assertFalse(self.sialib._append_bench_trend_once(
                record, receipt_id))
            with open(path, "rb") as stream:
                persisted = stream.read()
        self.assertLessEqual(len(persisted), 180)
        self.assertIn(receipt_id.encode(), persisted)

    def test_oversized_legacy_trend_cannot_strand_dream_receipt_or_readiness(self):
        path = os.path.join(self.state_root.name, "bench-trend.jsonl")
        legacy = b'{"date":"2026-08-29","hit5_blend":0.25}\n'
        with open(path, "wb") as stream:
            stream.write(b"x" * (self.sialib.MAX_BENCH_TREND_BYTES + 1))
            stream.write(b"\n" + legacy)
        record = {
            "date": "2026-08-30",
            "slug_match_at_5_blend": 0.75,
        }
        mind = {}
        receipt = self.sialib._stage_dream_unit(
            mind, "bench", "DREAM:bench", "blend-slug-match@5=0.75",
            "probes=1", "heuristic only", trend=record)
        real_save = self.sialib.siamind.save_mind
        real_save(mind)
        fail_once = [True]

        def crash_after_trend(value):
            if fail_once[0]:
                fail_once[0] = False
                raise OSError("simulated crash after trend replacement")
            return real_save(value)

        store = {"v": 1, "thoughts": []}
        with mock.patch.object(
                self.sialib, "queue_ledger_transition",
                return_value="pending"), \
                mock.patch.object(
                    self.sialib, "_settle_ledger_transition"), \
                mock.patch.object(
                    self.sialib.siamind, "save_mind",
                    side_effect=crash_after_trend):
            with self.assertRaisesRegex(
                    self.sialib.LedgerTransitionError,
                    "recovery remains pending"):
                self.sialib._settle_pending_dream_unit(store, "bench")
            self.assertIsNotNone(self.sialib._pending_dream_unit(
                self.sialib.siamind.load_mind()))
            self.sialib._settle_pending_dream_unit(store, "bench")

        persisted = self.sialib.siamind.load_mind()
        self.assertIsNone(self.sialib._pending_dream_unit(persisted))
        lines, compacted = self.sialib._read_bench_trend_tail(path)
        matching = [json.loads(line) for line in lines
                    if json.loads(line).get("dream_unit_id") == receipt["id"]]
        self.assertEqual(len(matching), 1)
        self.assertTrue(matching[0]["legacy_history_truncated"])
        self.assertFalse(compacted)
        rows, boundary = self.sialib._bench_trend_snapshot(
            path, include_metadata=True)
        self.assertTrue(rows)
        self.assertTrue(boundary["legacy_truncated"])

        corpus = os.path.join(self.state_root.name, "corpus")
        with mock.patch.object(self.sialib, "CORPUS", corpus), \
                mock.patch.object(
                    self.sialib, "CORTEX_BOUNDARY_REPAIR_JOURNAL",
                    os.path.join(self.state_root.name, "cortex-journal.json")), \
                mock.patch.object(
                    self.sialib, "CORTEX_BOUNDARY_REPAIR_RECEIPT",
                    os.path.join(self.state_root.name, "cortex-receipt.json")), \
                mock.patch.object(
                    self.sialib, "corpus_owner",
                    return_value=nullcontext()), \
                mock.patch.object(
                    self.sialib, "load_memo", return_value=self.memo), \
                mock.patch.object(
                    self.sialib, "_consolidation_scan_debt",
                    return_value=""), \
                mock.patch.object(
                    self.sialib, "_thought_recovery_debt",
                    return_value=""), \
                mock.patch.object(
                    self.sialib, "_graph_projection_debt",
                    return_value=""), \
                mock.patch.object(
                    self.sialib, "read_json",
                    return_value=_graph_snapshot()), \
                mock.patch.object(
                    self.sialib.siatakes,
                    "natural_history_recovery_required",
                    return_value=False), \
                mock.patch.object(
                    self.sialib.siatakes, "grade_recovery_required",
                    return_value=False), \
                mock.patch.object(
                    self.sialib.siatakes, "take_migration_required",
                    return_value=False), \
                mock.patch.object(
                    self.sialib.siatakes, "intent_history_required",
                    return_value=False):
            ready, reason = self.sialib.memory_readiness()
            self.assertFalse(ready)
            self.assertIn("cortex product-metaphor boundary root is missing", reason)
            root = self.sialib.corpus_path("sia/cortex")
            os.makedirs(os.path.dirname(root))
            self.sialib.atomic_write(
                root, self.sialib._current_cortex_root_bytes().decode("utf-8"))
            self.assertEqual(self.sialib.memory_readiness(), (True, ""))

    def test_dream_unit_receipt_version_requires_exact_json_integer(self):
        mind = {}
        self.sialib._stage_dream_unit(
            mind, "muse", "DREAM:muse", "fixture", "", "fixture")
        self.assertIsNotNone(self.sialib._pending_dream_unit(mind))
        for replacement in (True, 1.0):
            with self.subTest(replacement=replacement):
                malformed = copy.deepcopy(mind)
                malformed["dream_unit"]["v"] = replacement
                with self.assertRaisesRegex(
                        RuntimeError, "dream unit receipt is invalid"):
                    self.sialib._pending_dream_unit(malformed)


class ThoughtOrigins(unittest.TestCase):
    def setUp(self):
        self.sialib = _load(
            "sialib_thought_origin_test", os.path.join(BIN, "sialib.py"))
        self.state_root = tempfile.TemporaryDirectory()
        self.old_state_paths = (
            self.sialib.STATE, self.sialib.CORPUS_OWNER_LOCK,
            self.sialib.THOUGHTS_PATH, self.sialib.siamind.MIND_PATH,
            self.sialib.LIFECYCLE_LOCK,
            self.sialib.LIFECYCLE_TOMBSTONE)
        self.sialib.STATE = self.state_root.name
        self.sialib.CORPUS_OWNER_LOCK = os.path.join(
            self.state_root.name, "corpus-owner.lock")
        self.sialib.THOUGHTS_PATH = os.path.join(
            self.state_root.name, "thoughts.json")
        self.sialib.siamind.MIND_PATH = os.path.join(
            self.state_root.name, "mind.json")
        self.sialib.LIFECYCLE_LOCK = os.path.join(
            self.state_root.name, "lifecycle.lock")
        self.sialib.LIFECYCLE_TOMBSTONE = os.path.join(
            self.state_root.name, "lifecycle-removed")

    def tearDown(self):
        (self.sialib.STATE, self.sialib.CORPUS_OWNER_LOCK,
         self.sialib.THOUGHTS_PATH,
         self.sialib.siamind.MIND_PATH, self.sialib.LIFECYCLE_LOCK,
         self.sialib.LIFECYCLE_TOMBSTONE) = self.old_state_paths
        self.state_root.cleanup()

    def test_inbox_preserves_explicit_origin_and_defaults_new_rows(self):
        explicit = self.sialib._canonical_thought_inbox_item(
            {"kind": "note", "text": "model prose", "origin": "model"},
            queued=False)
        defaulted = self.sialib._canonical_thought_inbox_item(
            {"kind": "attention", "text": "deterministic"}, queued=False)
        legacy_queued = self.sialib._canonical_thought_inbox_item({
            "kind": "ponder", "text": "pre-upgrade model prose",
            "_queue_id": "b" * 32,
            "_queued_at": "2026-01-02T03:04:05Z"}, queued=True)
        self.assertEqual(explicit["origin"], "model")
        self.assertEqual(defaulted["origin"], "derived")
        self.assertEqual(legacy_queued["origin"], "model")
        with self.assertRaisesRegex(ValueError, "thought origin"):
            self.sialib._canonical_thought_inbox_item(
                {"kind": "note", "text": "bad", "origin": "trusted"},
                queued=False)

    def test_legacy_store_does_not_launder_unknown_rows_as_derived(self):
        legacy = {"v": 1, "thoughts": [
            {"kind": "grade", "text": "judge output"},
            {"kind": "ponder", "text": "model synthesis"},
            {"kind": "note", "text": "agent prose"},
            {"kind": "attention", "text": "unknown old generator"},
        ]}
        with mock.patch.object(
                self.sialib, "read_state_json", return_value=legacy):
            loaded = self.sialib.load_thoughts()
        self.assertEqual(
            [row.get("origin") for row in loaded["thoughts"]],
            ["model", "model", "model", None])

    def test_thought_store_version_requires_exact_json_integer(self):
        for replacement in (True, 1.0):
            with self.subTest(replacement=replacement), mock.patch.object(
                    self.sialib, "read_state_json",
                    return_value={"v": replacement, "thoughts": []}), \
                    self.assertRaisesRegex(
                        RuntimeError, "thought store schema is invalid"):
                self.sialib.load_thoughts()

    def test_legacy_model_thought_kinds_are_one_shared_policy(self):
        self.assertEqual(self.sialib.LEGACY_MODEL_THOUGHT_KINDS,
                         frozenset({"grade", "ponder", "note", "take"}))
        queued_at = "2026-01-02T03:04:05Z"

        def queued(kind, queue_id):
            return {"kind": kind, "text": "legacy model prose",
                    "_queue_id": queue_id, "_queued_at": queued_at}

        with mock.patch.object(
                self.sialib, "LEGACY_MODEL_THOUGHT_KINDS",
                frozenset({"take"})):
            queued_take = self.sialib._canonical_thought_inbox_item(
                queued("take", "a" * 32), queued=True)
            queued_note = self.sialib._canonical_thought_inbox_item(
                queued("note", "b" * 32), queued=True)
            legacy = {"v": 1, "thoughts": [
                {"kind": "take", "text": "operator prediction"},
                {"kind": "note", "text": "agent prose"},
            ]}
            with mock.patch.object(
                    self.sialib, "read_state_json", return_value=legacy):
                loaded = self.sialib.load_thoughts()

        self.assertEqual(queued_take["origin"], "model")
        self.assertEqual(queued_note["origin"], "derived")
        self.assertEqual(
            [row.get("origin") for row in loaded["thoughts"]],
            ["model", None])

    def test_thought_store_refuses_unbounded_or_ambiguous_projection_rows(self):
        minimal = {"kind": "note", "text": "bounded legacy prose"}
        cases = (
            {"v": 1, "thoughts": [minimal]
             * (self.sialib.MAX_THOUGHT_INBOX_ITEMS + 1)},
            {"v": 1, "thoughts": [{
                "ts": "2026-01-02T03:04:05Z", "kind": "note",
                "text": "missing modern projection fields",
            }]},
            {"v": 1, "thoughts": [minimal], "unexpected": True},
        )
        for value in cases:
            with self.subTest(value=value), mock.patch.object(
                    self.sialib, "read_state_json", return_value=value), \
                    self.assertRaisesRegex(
                        RuntimeError, "thought store schema is invalid"):
                self.sialib.load_thoughts()

    def test_thought_store_refuses_noncanonical_modern_rows_and_duplicates(self):
        row = {
            "ts": "2026-01-02T03:04:05Z", "kind": "note",
            "text": "canonical projection", "links": ["sia/cortex"],
            "urgent": False, "origin": "model",
            "slug": "thoughts/2026-01-02-0304-note",
        }
        cases = (
            {"v": 1, "thoughts": [{**row, "text": "raw [link]"}]},
            {"v": 1, "thoughts": [row, dict(row)]},
            {"v": 1, "thoughts": [{**row, "unknown": "field"}]},
        )
        for value in cases:
            with self.subTest(value=value), mock.patch.object(
                    self.sialib, "read_state_json", return_value=value), \
                    self.assertRaisesRegex(
                        RuntimeError, "thought store schema is invalid"):
                self.sialib.load_thoughts()

    def test_write_thought_persists_origin_and_upgrades_exact_legacy_retry(self):
        thought = {
            "ts": "2026-01-02T03:04:05Z", "kind": "note",
            "text": "remembered model prose", "links": ["sia/cortex"],
            "urgent": False, "origin": "model", "queue_id": "a" * 32}
        slug = self.sialib._queued_thought_slug(thought["queue_id"])
        legacy_fm = [
            "type: thought", self.sialib.fm_title(thought["text"]),
            "tags: [thought, note]", "date: 2026-01-02",
            f"queue_id: {thought['queue_id']}"]
        legacy_body = (
            "# thought · note\n\nremembered model prose\n\n"
            "[[sia/cortex]]\n")

        with tempfile.TemporaryDirectory() as corpus:
            old_corpus = self.sialib.CORPUS
            self.sialib.CORPUS = corpus
            try:
                self.sialib.write_page(slug, legacy_fm, legacy_body)
                self.assertEqual(self.sialib.write_thought(thought), slug)
                with open(self.sialib.corpus_path(slug)) as stream:
                    upgraded = stream.read()
                self.assertIn("\norigin: model\n", upgraded)

                tampered = upgraded.replace(
                    "remembered model prose", "different prose")
                self.sialib.atomic_write(
                    self.sialib.corpus_path(slug), tampered)
                with self.assertRaisesRegex(ValueError, "conflicts"):
                    self.sialib.write_thought(thought)
                with open(self.sialib.corpus_path(slug)) as stream:
                    self.assertEqual(stream.read(), tampered)
            finally:
                self.sialib.CORPUS = old_corpus

    def test_queue_page_identity_survives_projection_aging(self):
        queue_id = "e" * 32
        store = {"v": 1, "thoughts": []}
        with tempfile.TemporaryDirectory() as corpus, \
                mock.patch.object(self.sialib.siamind, "queue_touches",
                                  return_value=True):
            old_corpus = self.sialib.CORPUS
            self.sialib.CORPUS = corpus
            try:
                first = self.sialib.add_thought(
                    store, "note", "durable identity", ["sia/cortex"],
                    queue_id=queue_id,
                    thought_ts="2026-01-02T03:04:05Z", origin="model")
                expected_slug = self.sialib._queued_thought_slug(queue_id)
                self.assertEqual(first["slug"], expected_slug)
                with open(self.sialib.corpus_path(expected_slug)) as stream:
                    original_page = stream.read()

                # thoughts.json is a bounded projection.  The exact page is
                # the durable identity once an older row ages out.
                store["thoughts"].clear()
                retried = self.sialib.add_thought(
                    store, "note", "durable identity", ["sia/cortex"],
                    queue_id=queue_id,
                    thought_ts="2026-02-03T04:05:06Z", origin="model")

                self.assertEqual(retried, first)
                self.assertEqual(store["thoughts"], [first])
                self.assertEqual(
                    os.listdir(os.path.join(corpus, "thoughts")),
                    [expected_slug.split("/", 1)[1] + ".md"])
                with open(self.sialib.corpus_path(expected_slug)) as stream:
                    self.assertEqual(stream.read(), original_page)
            finally:
                self.sialib.CORPUS = old_corpus

    def test_existing_queued_thought_reuses_one_page_bound_intent(self):
        queue_id = "7" * 32
        store = {"v": 1, "thoughts": []}
        with tempfile.TemporaryDirectory() as corpus, \
                mock.patch.object(
                    self.sialib.siamind, "queue_touches",
                    side_effect=[False, True]) as touches:
            old_corpus = self.sialib.CORPUS
            self.sialib.CORPUS = corpus
            try:
                first = self.sialib.add_thought(
                    store, "note", "repair rehearsal", ["sia/cortex"],
                    queue_id=queue_id,
                    thought_ts="2026-01-02T03:04:05Z", origin="model")
                retried = self.sialib.add_thought(
                    store, "note", "repair rehearsal", ["sia/cortex"],
                    queue_id=queue_id,
                    thought_ts="2026-01-02T03:04:05Z", origin="model")
                self.assertEqual(retried, first)
                touches.assert_not_called()
                recovery = self.sialib._thought_recovery_record(first)
                self.assertEqual(os.listdir(
                    self.sialib._thought_recovery_dir()),
                    [recovery["record_id"] + ".json"])
            finally:
                self.sialib.CORPUS = old_corpus

    def test_recovery_reconstructs_nonqueued_thought_reinforcement(self):
        store = {"v": 1, "thoughts": []}
        mind = self.sialib.siamind._empty_mind()
        with tempfile.TemporaryDirectory() as corpus:
            old_corpus = self.sialib.CORPUS
            self.sialib.CORPUS = corpus
            try:
                with mock.patch.object(
                        self.sialib.siamind, "queue_touches",
                        return_value=False):
                    thought = self.sialib.add_thought(
                        store, "grade", "durable unqueued page",
                        ["units/a", "units/b"],
                        thought_ts="2026-01-02T03:04:05Z", origin="model")
                before = json.loads(json.dumps(mind))
                recovered, reinforced = self.sialib.reconcile_thought_pages(
                    store, mind=mind)
                self.assertEqual(recovered, 0)
                self.assertNotEqual(mind, before)
                self.assertGreater(reinforced, 0)
                after_first = json.loads(json.dumps(mind))
                recovered, reinforced = self.sialib.reconcile_thought_pages(
                    store, mind=mind)
                self.assertEqual((recovered, reinforced), (0, 0))
                self.assertEqual(mind, after_first)
                self.assertEqual(thought["slug"], store["thoughts"][0]["slug"])
            finally:
                self.sialib.CORPUS = old_corpus

    def test_recovery_applies_thought_pages_in_timestamp_order(self):
        store = {"v": 1, "thoughts": []}
        mind = self.sialib.siamind._empty_mind()
        with tempfile.TemporaryDirectory() as corpus, \
                mock.patch.object(self.sialib.siamind, "queue_touches",
                                  return_value=False):
            old_corpus = self.sialib.CORPUS
            self.sialib.CORPUS = corpus
            try:
                # The later page sorts first by queue slug. Timestamp order
                # must still preserve both distinct edges through the shared
                # receipt node.
                self.sialib.add_thought(
                    store, "note", "older", ["units/common", "units/old"],
                    queue_id="f" * 32,
                    thought_ts="2026-01-02T03:04:05Z", origin="model")
                self.sialib.add_thought(
                    store, "note", "later", ["units/common", "units/new"],
                    queue_id="0" * 32,
                    thought_ts="2026-01-02T03:04:06Z", origin="model")
                self.sialib.reconcile_thought_pages(store, mind=mind)
                self.assertIn("units/common|units/old", mind["edges"])
                self.assertIn("units/common|units/new", mind["edges"])
            finally:
                self.sialib.CORPUS = old_corpus

    def test_recovery_reconciles_page_signal_without_sync_debt(self):
        store = {"v": 1, "thoughts": []}
        with tempfile.TemporaryDirectory() as root, \
                mock.patch.object(self.sialib.siamind, "queue_touches",
                                  return_value=False):
            corpus = os.path.join(root, "corpus")
            mind_path = os.path.join(root, "mind.json")
            old_corpus = self.sialib.CORPUS
            old_mind_path = self.sialib.siamind.MIND_PATH
            self.sialib.CORPUS = corpus
            self.sialib.siamind.MIND_PATH = mind_path
            try:
                self.sialib.siamind.save_mind(
                    self.sialib.siamind._empty_mind())
                self.sialib.add_thought(
                    store, "grade", "repair without named debt", ["units/a"],
                    thought_ts="2026-01-02T03:04:05Z", origin="model")
                self.sialib._recover_pending_thought_projection(
                    {"sync_needed": False}, store)
                persisted = self.sialib.siamind.load_mind()
                self.assertIn("thought", persisted["nodes"]["units/a"]["signals"])
            finally:
                self.sialib.CORPUS = old_corpus
                self.sialib.siamind.MIND_PATH = old_mind_path

    def test_aged_out_queue_identity_conflict_is_fail_closed(self):
        queue_id = "f" * 32
        store = {"v": 1, "thoughts": []}
        with tempfile.TemporaryDirectory() as corpus, \
                mock.patch.object(self.sialib.siamind, "queue_touches",
                                  return_value=True):
            old_corpus = self.sialib.CORPUS
            self.sialib.CORPUS = corpus
            try:
                first = self.sialib.add_thought(
                    store, "note", "bound payload", ["sia/cortex"],
                    queue_id=queue_id,
                    thought_ts="2026-01-02T03:04:05Z", origin="model")
                path = self.sialib.corpus_path(first["slug"])
                with open(path) as stream:
                    original_page = stream.read()
                store["thoughts"].clear()

                with self.assertRaisesRegex(ValueError, "conflicts"):
                    self.sialib.add_thought(
                        store, "note", "different payload", ["sia/cortex"],
                        queue_id=queue_id,
                        thought_ts="2026-02-03T04:05:06Z", origin="model")

                self.assertEqual(store["thoughts"], [])
                with open(path) as stream:
                    self.assertEqual(stream.read(), original_page)
            finally:
                self.sialib.CORPUS = old_corpus

    def test_failed_page_write_leaves_thought_projection_unchanged(self):
        store = {"v": 1, "thoughts": [{
            "ts": "2026-01-01T00:00:00Z", "kind": "attention",
            "text": "existing", "links": ["sia/cortex"],
            "urgent": False, "origin": "derived",
            "slug": "thoughts/existing"}]}
        before = json.loads(json.dumps(store))
        with mock.patch.object(self.sialib, "page_exists",
                               return_value=False), \
                mock.patch.object(self.sialib, "write_page",
                                  side_effect=OSError("page fsync refused")), \
                mock.patch.object(self.sialib.siamind,
                                  "queue_touches") as touches:
            with self.assertRaisesRegex(OSError, "page fsync refused"):
                self.sialib.add_thought(
                    store, "attention", "new thought", ["sia/cortex"],
                    thought_ts="2026-01-02T03:04:05Z")
        self.assertEqual(store, before)
        touches.assert_not_called()

    def test_self_described_orphan_page_rejoins_projection(self):
        thought = {
            "ts": "2026-01-02T03:04:05Z", "kind": "note",
            "text": "recover me", "links": ["sia/cortex"],
            "urgent": False, "origin": "model", "queue_id": "c" * 32}
        with tempfile.TemporaryDirectory() as corpus:
            old_corpus = self.sialib.CORPUS
            self.sialib.CORPUS = corpus
            try:
                slug = self.sialib.write_thought(thought)
                store = {"v": 1, "thoughts": []}
                self.assertEqual(
                    self.sialib.reconcile_thought_pages(store), 1)
                self.assertEqual(store["thoughts"][0]["slug"], slug)
                self.assertEqual(store["thoughts"][0]["text"],
                                 "recover me")
            finally:
                self.sialib.CORPUS = old_corpus

    def test_misbound_orphan_refuses_without_clearing_debt(self):
        thought = {
            "ts": "2026-01-02T03:04:05Z", "kind": "note",
            "text": "recover me", "links": ["sia/cortex"],
            "urgent": False, "origin": "model", "queue_id": "d" * 32}
        with tempfile.TemporaryDirectory() as corpus:
            old_corpus = self.sialib.CORPUS
            self.sialib.CORPUS = corpus
            try:
                slug = self.sialib.write_thought(thought)
                path = self.sialib.corpus_path(slug)
                with open(path) as stream:
                    content = stream.read()
                content = content.replace(
                    f'"slug": "{slug}"',
                    '"slug": "thoughts/different"')
                self.sialib.atomic_write(path, content)
                memo = {"sync_needed": True}
                with mock.patch.object(
                        self.sialib, "export_thoughts") as export:
                    with self.assertRaisesRegex(
                            RuntimeError, "binds another page"):
                        self.sialib._recover_pending_thought_projection(
                            memo, {"v": 1, "thoughts": []})
                self.assertIs(memo.get("sync_needed"), True)
                export.assert_not_called()
            finally:
                self.sialib.CORPUS = old_corpus


class RehearsalEmbedContract(unittest.TestCase):
    """rehearse_memories must address pages in the registered gbrain source.

    The per-page embed ran without --source for the project's whole history,
    so gbrain looked the slug up in its "default" source, answered "Page not
    found", and every nightly rehearsal failed with reviewed=0 (issue #3).
    """

    def setUp(self):
        self.sialib = _load(
            "sialib_rehearse_test", os.path.join(BIN, "sialib.py"))

    def _rehearse(self, gbrain_result, apply_result=None):
        calls = []

        def fake_gbrain(args, timeout=120, json_out=False):
            calls.append(list(args))
            return gbrain_result

        plan = {"slug": "events/skills/2026-08-31", "quality": 5}
        with ExitStack() as stack:
            for name, replacement in (
                    ("gbrain", fake_gbrain),
                    ("page_exists", lambda _slug: True),
                    ("read_json", lambda *_args, **_kwargs:
                     _graph_snapshot([plan["slug"]]))):
                stack.enter_context(
                    mock.patch.object(self.sialib, name, replacement))
            for name, replacement in (
                    ("load_mind", lambda now=None: {}),
                    ("sync_graph_state", lambda *_args, **_kwargs: None),
                    ("plan_rehearsal",
                     lambda _mind, now=None: [dict(plan)]),
                    ("apply_rehearsal",
                     lambda _mind, _plan, now=None: apply_result),
                    ("decay_sweep", lambda _mind, now=None: {}),
                    ("save_mind", lambda _mind: None)):
                stack.enter_context(
                    mock.patch.object(self.sialib.siamind, name, replacement))
            report = self.sialib.rehearse_memories(now=0.0)
        return calls, report

    def test_embed_names_the_registered_source(self):
        committed = {"slug": "events/skills/2026-08-31", "quality": 5}
        calls, report = self._rehearse(
            subprocess.CompletedProcess([], 0, "", ""),
            apply_result=committed)
        self.assertEqual(calls, [[
            "embed", "events/skills/2026-08-31",
            "--source", self.sialib.GBRAIN_SOURCE]])
        self.assertEqual(report["embedded"], 1)
        self.assertEqual(report["failed"], 0)
        self.assertEqual(report["reviewed"][0]["embed"], "ok")

    def test_failed_embed_records_bounded_reason(self):
        calls, report = self._rehearse(subprocess.CompletedProcess(
            [], 1,
            "Page not found: events/skills/2026-08-31 (source=default)\n",
            ""))
        self.assertEqual(report["failed"], 1)
        self.assertEqual(report["reviewed"], [])
        item = report["planned"][0]
        self.assertEqual(item["embed"], "failed")
        self.assertIn("Page not found", item["error"])
        self.assertLessEqual(len(item["error"]), 160)
        self.assertNotIn("\n", item["error"])


if __name__ == "__main__":
    unittest.main(verbosity=True)

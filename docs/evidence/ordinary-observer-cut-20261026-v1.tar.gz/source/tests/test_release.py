#!/usr/bin/env python3
"""Release-shape and installer supply-chain regression tests."""

# KNOWN, DELIBERATE COUPLING -- read before editing install.sh/uninstall.sh.
#
# Most tests here, and nearly every recovery/fence test, treat the two
# installers as TEXT.  The _*_shell() helpers below split a 10,000-line
# script on verbatim source markers ("runtime_tree_digest() {", "\n}\n",
# "\n}\n\nwrite_runtime_receipt", ...) and execute the lifted fragment under
# bash.  That is the only way to exercise an installer's fail-closed branches
# without running the real thing against a real machine, so the coupling is
# the point, not an accident waiting to be refactored away.
#
# The price is that renaming an installer function, moving a closing brace,
# reordering two functions, or reflowing a heredoc breaks tests here for
# reasons that are not behavioural.  That price is accepted: silent
# divergence between the installer and the guard that pins it is the worse
# failure, and it is the failure these markers exist to make loud.
#
# So: edit the installers knowingly.  When a split marker stops matching, the
# repair is to re-point the marker at the moved source -- never to delete the
# assertion it feeds, and never to relax it into something that still passes.

import ast
import hashlib
import fcntl
import importlib.machinery
import importlib.util
import inspect
import io
import json
import os
import re
import shlex
import shutil
import stat
import subprocess
import sys
import tempfile
import time
import types
import unittest
from unittest import mock

try:
    import sia_test_home  # test-only import-time path isolation
except ModuleNotFoundError:
    from tests import sia_test_home  # type: ignore

if os.path.expanduser("~") != sia_test_home.ISOLATED_HOME:
    raise RuntimeError("release tests require the isolated test home")


REPO = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _read(relative):
    with open(os.path.join(REPO, relative), encoding="utf-8") as stream:
        return stream.read()


def _workflow_run_block(step_name):
    """Extract one workflow run block verbatim for behavioral testing."""
    lines = _read(".github/workflows/ci.yml").splitlines()
    marker = f"- name: {step_name}"
    starts = [index for index, line in enumerate(lines)
              if line.strip() == marker]
    if len(starts) != 1:
        raise AssertionError(
            f"workflow must define exactly one {marker!r} step")
    run = None
    for index in range(starts[0] + 1, len(lines)):
        if lines[index].strip() == "run: |":
            run = index
            break
    if run is None:
        raise AssertionError(f"workflow step {step_name!r} has no run block")
    indent = len(lines[run]) - len(lines[run].lstrip())
    body = []
    for line in lines[run + 1:]:
        if line.strip() and len(line) - len(line.lstrip()) <= indent:
            break
        body.append(line[indent + 2:] if line.strip() else "")
    return "\n".join(body) + "\n"


def _read_path(path):
    with open(path, encoding="utf-8") as stream:
        return stream.read()


def _write(path, content, mode=None):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as stream:
        stream.write(content)
    if mode is not None:
        os.chmod(path, mode)


def _fake_command(directory, name, body):
    _write(os.path.join(directory, name), "#!/bin/sh\n" + body, 0o755)


def _guard_fixture(directory, trace, admitted=True):
    """Supply only the admin prerequisite for downstream installer tests.

    This test-local dispatcher records the exact gate invocation. All other
    Python commands execute normally; production has no bypass setting.
    """
    guard = shlex.quote(os.path.realpath(
        os.path.join(REPO, "bin", "siaollamaguard.py")))
    outcome = "admitted" if admitted else "refused"
    status = 0 if admitted else 23
    body = (
        'if [ "$#" -eq 4 ] && [ "$1" = -I ] && [ "$2" = -S ] '
        '&& [ "$4" = gate ]; then\n'
        f'  if [ "$(readlink -f -- "$3")" = {guard} ]; then\n'
        f"    printf '%s\\n' {outcome} >> {shlex.quote(trace)} || exit 125\n"
        f"    exit {status}\n"
        "  fi\n"
        "fi\n"
        f'exec {shlex.quote(sys.executable)} "$@"\n')
    _fake_command(directory, "python3", body)


def _load(name, path):
    loader = importlib.machinery.SourceFileLoader(name, path)
    spec = importlib.util.spec_from_loader(name, loader)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


SIARELEASE = _load(
    "siarelease_test_support", os.path.join(REPO, "bin", "siarelease.py"))


class _OsShim:
    """Module-local syscall overrides without patching the global os module."""

    def __init__(self, **overrides):
        self._overrides = overrides

    def __getattr__(self, name):
        if name in self._overrides:
            return self._overrides[name]
        return getattr(os, name)


ABSENT_USER_UNIT = (
    'if [ "$1 $2" = "--user show" ]; then\n'
    '  echo "LoadState=not-found"; echo "ActiveState=inactive"\n'
    '  echo "FragmentPath="; echo "UnitFileState="\n'
    '  echo "DropInPaths="; echo "MainPID=0"\n'
    '  echo "RefuseManualStart=no"; echo "Job="\n'
    '  exit 0\n'
    'fi\n'
    'exit 0\n')


def _managed_file_receipt(path, kind):
    with open(path, "rb") as stream:
        digest = hashlib.sha256(stream.read()).hexdigest()
    return ("managed-by=khephri.sia\n"
            f"kind={kind}\npath={path}\nsha256={digest}\n")


def _runtime_digest(root):
    return SIARELEASE.runtime_tree_digest(root)


def _managed_cli_runtime(home):
    runtime = os.path.join(home, ".local/share/sia/bin")
    for name in ("sia-brainstem", "sia-ledger", "sia-mcp", "siabench.py",
                 "sialib.py", "siamind.py", "siaqueue.py", "siatakes.py"):
        _write(os.path.join(runtime, name), name + "\n")
    cli = os.path.join(home, ".local/bin/sia")
    _write(cli, "managed cli\n")
    managed = os.path.join(home, ".local/state/sia/managed-install")
    _write(os.path.join(managed, "sia-cli"),
           _managed_file_receipt(cli, "sia-cli"))
    _write(os.path.join(managed, "runtime"),
           "managed-by=khephri.sia\nkind=runtime\n"
           f"path={runtime}\nsha256={_runtime_digest(runtime)}\n")
    return cli, runtime


def _managed_brainstem_install(home):
    unit = os.path.join(
        home, ".config/systemd/user/sia-brainstem.service")
    _write(unit, _read("systemd/sia-brainstem.service"), 0o644)
    receipt = os.path.join(
        home, ".local/state/sia/managed-install/sia-brainstem.service")
    _write(receipt, _managed_file_receipt(unit, "brainstem-unit"), 0o600)
    return unit


def _brainstem_show(unit, *, drop_in="", refuse="no", load="loaded",
                    unit_state="enabled", active="active", pid="1", job="",
                    daemon_reload="no"):
    values = {
        "LoadState": load,
        "UnitFileState": unit_state,
        "ActiveState": active,
        "FragmentPath": unit,
        "DropInPaths": drop_in,
        "MainPID": pid,
        "RefuseManualStart": refuse,
        "Job": job,
        "NeedDaemonReload": daemon_reload,
    }
    return ("\n".join(f"{key}={value}" for key, value in values.items())
            + "\n").encode("utf-8")


def _restore_adoption_fields(binding, *, ledger_head=None, order=7):
    ledger_head = ledger_head or "0" * 64
    confirmation = {
        "schema_version": 1,
        "phrase": "RESTORE",
        "snapshot_id": binding["snapshot_id"],
        "ledger_head": ledger_head,
        "corpus_receipt_re_adopt": True,
    }
    target = {
        "corpus_root": {
            "device": 1, "inode": 2, "mode": 448,
            "owner": os.geteuid(),
        },
        "receipt_sha256": "f" * 64,
        "receipt_mode": 384,
    }
    confirmation_raw = (json.dumps(
        confirmation, ensure_ascii=True, sort_keys=True,
        separators=(",", ":")) + "\n").encode("utf-8")
    confirmation_sha256 = hashlib.sha256(confirmation_raw).hexdigest()
    content = json.dumps({
        "accepted_ledger_head": ledger_head,
        "confirmation_sha256": confirmation_sha256,
        "snapshot_id": binding["snapshot_id"],
        "manifest_sha256": binding["manifest_sha256"],
        "target": target,
        "receipt_re_adopted": True,
    }, ensure_ascii=True, sort_keys=True, separators=(",", ":"))
    basis = {
        "order": order,
        "action": "RESTORE:adopt",
        "arg1": binding["prepared_id"],
        "arg2": binding["capsule_id"],
        "content": content,
    }
    record_id = hashlib.sha256(json.dumps(
        basis, ensure_ascii=False, sort_keys=True,
        separators=(",", ":")).encode("utf-8")).hexdigest()
    adoption = {"order": order, "record_id": record_id, "target": target}
    return confirmation, adoption, {
        "identity_key_file": "",
        "accepted_ledger_head": ledger_head,
        "confirmation_sha256": confirmation_sha256,
        "adoption_order": str(order),
        "adoption_record_id": record_id,
        "target": target,
    }


def _mcp_guard_contents(home, client, reason):
    runtime = os.path.join(home, ".local/share/sia/bin")
    return (
        "guarded-by=khephri.sia\n"
        "kind=external-mcp-consumer\n"
        f"consumer={client}\n"
        "ownership=external\n"
        "command=python3\n"
        f"arg={runtime}/sia-mcp\n"
        f"reason={reason}\n"
    )


def _generate_stable_launcher(path):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    installer = _read("install.sh")
    body = installer.split("write_stable_generation_launcher() {", 1)[1] \
        .split("\n}\n\npreflight_owned_file", 1)[0]
    function = "write_stable_generation_launcher() {" + body + "\n}\n"
    result = subprocess.run(
        ["bash", "-c", function + '\nwrite_stable_generation_launcher "$1"',
         "launcher-test", path], text=True, stdout=subprocess.PIPE,
        stderr=subprocess.PIPE, check=False)
    if result.returncode:
        raise RuntimeError(result.stderr)


def _bounded_commands_shell(script):
    return _lifetime_command_context() + "bounded_command_capture() {" + script.split(
        "bounded_command_capture() {", 1)[1].split(
        "\nowned_metadata() {", 1)[0]


def _lifetime_command_context():
    return "SIA_LIFETIME_SOURCE=" + shlex.quote(
        os.path.join(REPO, "bin", "sialifetime.py")) + "\n"


def _run_release_fragment(script, environment):
    """Run the actual admitted entry around an isolated release-body fixture."""
    with tempfile.TemporaryDirectory(prefix="sia-release-fragment-") as root:
        os.mkdir(os.path.join(root, "bin"))
        shutil.copy2(os.path.join(REPO, "bin", "sialifetime.py"),
                     os.path.join(root, "bin", "sialifetime.py"))
        bootstrap = _read("install.sh").split(
            "# BEGIN SIA RELEASE LIFETIME\n", 1)[1].split(
                "# END SIA RELEASE LIFETIME\n", 1)[0]
        entry = os.path.join(root, "install.sh")
        with open(entry, "w", encoding="utf-8") as stream:
            stream.write("#!/usr/bin/env bash\n" + bootstrap + script)
        os.chmod(entry, 0o700)
        return subprocess.run(
            [entry], env=environment, text=True, stdout=subprocess.PIPE,
            stderr=subprocess.PIPE, check=False)


def _owned_metadata_shell(script):
    bounded = _bounded_commands_shell(script)
    body = script.split("owned_metadata() {", 1)[1].split(
        "\n}\n\nwrite_lifecycle_tombstone", 1)[0]
    return bounded + "\nowned_metadata() {" + body + "\n}\n"


def _owned_metadata_python(script):
    return script.split("owned_metadata() {\n"
                        "  python3 - \"$@\" <<'PY'\n", 1)[1].split(
                            "\nPY\n}", 1)[0]


def _runtime_barrier_shell(script):
    body = script.split("brainstem_runtime_barrier_file() {", 1)[1].split(
        "\nPY\n}", 1)[0]
    return "brainstem_runtime_barrier_file() {" + body + "\nPY\n}\n"


def _publication_receipt_recovery_shell(script):
    body = script.split(
        "recover_publication_receipts_from_fence() {", 1)[1].split(
            "\n}\n\narm_install_launch_fence", 1)[0]
    return "recover_publication_receipts_from_fence() {" + body + "\n}\n"


def _fenced_runtime_authorization_shell(script):
    body = script.split(
        "fenced_runtime_authorized() {", 1)[1].split(
            "\n}\n\nwrite_runtime_receipt", 1)[0]
    return "fenced_runtime_authorized() {" + body + "\n}\n"


def _runtime_tree_digest_shell(script):
    body = script.split("runtime_tree_digest() {", 1)[1].split(
        "\n}", 1)[0]
    authority = shlex.quote(os.path.join(REPO, "bin", "siarelease.py"))
    return (f"REPO={shlex.quote(REPO)}\n"
            f"SIA_RELEASE_AUTHORITY={authority}\n"
            "runtime_tree_digest() {" + body + "\n}\n")


def _uninstaller_fenced_runtime_shell(script):
    body = script.split(
        "fenced_runtime_authorized() {", 1)[1].split(
            "\n}\n\ncapture_runtime_removal_authority", 1)[0]
    authority = shlex.quote(os.path.join(REPO, "bin", "siarelease.py"))
    return (f"SIA_RELEASE_AUTHORITY={authority}\n"
            "fenced_runtime_authorized() {" + body + "\n}\n")


LEGACY_RUNTIME_NAMES = (
    "sia-brainstem", "sia-ledger", "sia-mcp", "siabench.py", "sialib.py",
    "siamind.py", "siaqueue.py", "siatakes.py")

MODERN_V2_RUNTIME_NAMES = (
    "sia-brainstem", "sia-brainstem.py", "sia-cli", "sia-ledger", "sia-mcp",
    "siabench.py", "sialib.py", "siamind.py", "siaqueue.py", "siatakes.py")

MODERN_V3_RUNTIME_NAMES = MODERN_V2_RUNTIME_NAMES + ("siasenses.py",)

MODERN_V4_RUNTIME_NAMES = MODERN_V3_RUNTIME_NAMES + (
    "siacapsule.py", "siabackup.py", "siarestoreadmit.py",
    "sia-continuity-worker")

MODERN_V5_RUNTIME_NAMES = MODERN_V4_RUNTIME_NAMES + ("siagraph.py",)
MODERN_V6_RUNTIME_NAMES = MODERN_V5_RUNTIME_NAMES + ("siathought.py",)
MODERN_V7_RUNTIME_NAMES = MODERN_V6_RUNTIME_NAMES + (
    "siaactivation.py", "siacognitivebaseline.py",
    "siacognitivecommand.py", "siacognitivehistory.py",
    "siacognitiveselect.py", "siacontrollerliveinput.py",
    "siacontrollerstatus.py", "siacoretrieval.py",
    "siacortexrepair.py", "siaencoding.py", "siaeventintake.py",
    "siaeventplan.py", "siagist.py", "siajournalcapture.py",
    "sialivegist.py", "sialiveloop.py", "sialivepublication.py",
    "siasourcebatch.py", "siasourcepublication.py", "siavector.py",
    "siavectoradmit.py", "siavectormodel.py", "siavectorprepare.py",
    "siavectorrun.py", "siaworkspace.py",
)
MODERN_V8_RUNTIME_NAMES = MODERN_V7_RUNTIME_NAMES + (
    "siasourceack.py", "siasourceeffects.py", "siasourceengine.py",
    "siasourcegit.py",
)
MODERN_V9_RUNTIME_NAMES = MODERN_V8_RUNTIME_NAMES + (
    "siacontrollerepoch.py", "siacontrollersourcerunner.py",
)

# Independent rung fixtures, not an operational ladder.  The historical
# entries pin bytes already accepted by shipped receipts, while the newest
# entry pins the candidate contract emitted by the release front door.
RUNTIME_RUNG_FIXTURES = (
    ("v1", b"sia-runtime-v1\0", LEGACY_RUNTIME_NAMES,
     "f9dc027491272df1e17648cb4dc936b2928a0f15953758b72495f8a29fad29d7"),
    ("v2", b"sia-runtime-v2\0", MODERN_V2_RUNTIME_NAMES,
     "cf26e711604a57f8e539646beca7b0027aa1ad051e3729b92f45f4c0cc3f0544"),
    ("v3", b"sia-runtime-v3\0", MODERN_V3_RUNTIME_NAMES,
     "c0042e7df7d9c09ba1247b6d25140b0f91afee0d8e7df1200d4831988ed3dbf4"),
    ("v4", b"sia-runtime-v4\0", MODERN_V4_RUNTIME_NAMES,
     "f96c9529bcb56570278b53d0edef86976268ed52a948deb81db1c0ab129ae212"),
    ("v5", b"sia-runtime-v5\0", MODERN_V5_RUNTIME_NAMES,
     "e8e8e2c5fe0aab2a5823d887d525aa49e123e18d391b90058b8363fb2e0c6db8"),
    ("v6", b"sia-runtime-v6\0", MODERN_V6_RUNTIME_NAMES,
     "3ba7772c833c658c6ad4be4273d5dbff5324fc123824dd62c75514a38a8e182f"),
    ("v7", b"sia-runtime-v7\0", MODERN_V7_RUNTIME_NAMES,
     "54f7917d096b318649cf6c15138eb9dade967277e41fe9256e3f003f69e360bc"),
    ("v8", b"sia-runtime-v8\0", MODERN_V8_RUNTIME_NAMES,
     "0225ff0d0a864a8f26ad75f37afb92ced45ef5966ad2c17b7343e5081a8ebcfc"),
    ("v9", b"sia-runtime-v9\0", MODERN_V9_RUNTIME_NAMES,
     "8f68448335643681bebf024dd14fa946280f5d888e24d5d0c55688931fadb524"),
)


def _plant_runtime_tree(runtime, names):
    for name in names:
        _write(os.path.join(runtime, name), name + "\n", 0o644)


def _staged_runtime_members(script):
    # Recover the runtime members install.sh actually stages, from the
    # installer source rather than from a second hand-kept list.  A restated
    # list would drift in exactly the same silence as the rung ladder it is
    # meant to police, which is the whole defect.
    #
    # The block stages three ways -- a loop over modules, a loop over
    # commands, and bare install(1) lines -- so both the loop word lists and
    # the literal destinations have to be read back out.
    marker = '\nstep "3/9 runtime"\n'
    terminator = "\nSTAGED_RUNTIME_DIGEST="
    if script.count(marker) != 1 or script.count(terminator) != 1:
        raise AssertionError(
            "install.sh runtime staging block is no longer uniquely "
            "delimited by its step banner and its digest assignment; "
            "re-point this extractor at the moved source")
    region = script.split(marker, 1)[1].split(terminator, 1)[0]
    # Fold shell line continuations first: the module list wraps across
    # three physical lines and would otherwise be read short.
    flat = region.replace("\\\n", " ")
    staged = []
    for match in re.finditer(
            r'"\$SIA_RUNTIME_STAGE/(\$?[A-Za-z0-9_.-]+)"', flat):
        token = match.group(1)
        if not token.startswith("$"):
            staged.append(token)
            continue
        variable = token[1:]
        loop = re.search(
            r"\bfor " + re.escape(variable) + r" in ([^;]+); do", flat)
        if loop is None:
            raise AssertionError(
                f"install.sh stages ${variable} with no visible `for "
                f"{variable} in ...` list to expand")
        staged.extend(shlex.split(loop.group(1)))
    return tuple(staged)


# The marketplace refuses to snapshot a source file larger than this, so a
# file that crosses it is not shippable at all.
MARKETPLACE_SCAN_CAP = 524288

# The guard below fires at 95% of that cap -- 498,073 bytes, still 26,215
# bytes short of unshippable.  The threshold is deliberately not 99%: it has
# to fire while a module extraction can still be planned and landed calmly,
# so crossing it is a scheduling signal, not a release blocker.  Raising this
# number to buy silence is the one repair that is not available; the repair
# is to make the file smaller.
MARKETPLACE_SCAN_HEADROOM_FLOOR = MARKETPLACE_SCAN_CAP * 95 // 100


def _marketplace_scanned_sources():
    # The marketplace snapshot scans by extension, plus the four
    # extensionless executables in bin/.  The hard cap test and the headroom
    # guard must walk exactly one set: if they diverge, one of them is
    # policing files the marketplace never reads, and the other is silently
    # missing files it does.
    extensions = {".js", ".py", ".qml", ".sh"}
    extensionless = {
        os.path.join("bin", name) for name in (
            "sia", "sia-brainstem", "sia-ledger", "sia-mcp")}
    found = []
    for directory, subdirectories, filenames in os.walk(REPO):
        subdirectories[:] = [
            name for name in subdirectories
            if name not in {".git", "assets", "__pycache__"}]
        for filename in filenames:
            absolute = os.path.join(directory, filename)
            relative = os.path.relpath(absolute, REPO)
            if (os.path.splitext(filename)[1] not in extensions
                    and relative not in extensionless):
                continue
            found.append((relative, absolute))
    return sorted(found)


class ReleaseContract(unittest.TestCase):
    def setUp(self):
        self._xdg_runtime = tempfile.TemporaryDirectory(
            prefix="sia-release-runtime-")
        os.chmod(self._xdg_runtime.name, 0o700)
        self.addCleanup(self._xdg_runtime.cleanup)
        previous = os.environ.get("XDG_RUNTIME_DIR")
        os.environ["XDG_RUNTIME_DIR"] = self._xdg_runtime.name

        def restore_xdg_runtime():
            if previous is None:
                os.environ.pop("XDG_RUNTIME_DIR", None)
            else:
                os.environ["XDG_RUNTIME_DIR"] = previous

        self.addCleanup(restore_xdg_runtime)

    def test_runtime_barrier_artifact_lifecycle_and_refusals(self):
        installer_function = _runtime_barrier_shell(_read("install.sh"))
        self.assertEqual(
            installer_function,
            _runtime_barrier_shell(_read("uninstall.sh")))
        barrier = os.path.join(
            self._xdg_runtime.name, "systemd", "user",
            "sia-brainstem.service.d", "sia-lifecycle-barrier.conf")
        retired = os.path.splitext(barrier)[0] + ".retired"
        environment = os.environ.copy()
        environment["BRAINSTEM_RUNTIME_BARRIER"] = barrier

        def action(name):
            return subprocess.run(
                ["bash", "-c", installer_function +
                 '\nbrainstem_runtime_barrier_file "$1"',
                 "runtime-barrier-test", name],
                env=environment, text=True, stdout=subprocess.PIPE,
                stderr=subprocess.PIPE, check=False)

        result = action("state")
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stdout, "absent\n")

        result = action("install")
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stdout, "active\n")
        self.assertEqual(
            _read_path(barrier),
            "[Unit]\nRefuseManualStart=yes\nConditionPathExists=\n"
            "ConditionPathExists=!/\n")
        self.assertEqual(os.stat(barrier).st_mode & 0o777, 0o644)
        self.assertEqual(action("state").stdout, "active\n")

        result = action("retire")
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertFalse(os.path.lexists(barrier))
        self.assertTrue(os.path.isfile(retired))
        self.assertEqual(action("state").stdout, "retired\n")

        result = action("restore")
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertTrue(os.path.isfile(barrier))
        self.assertFalse(os.path.lexists(retired))
        result = action("remove")
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stdout, "absent\n")
        self.assertFalse(os.path.lexists(barrier))

        target = os.path.join(self._xdg_runtime.name, "foreign")
        _write(target, "foreign\n", 0o644)
        os.symlink(target, barrier)
        result = action("state")
        self.assertNotEqual(result.returncode, 0)
        os.unlink(barrier)

        _write(barrier, "[Unit]\nRefuseManualStart=no\n", 0o644)
        result = action("state")
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("foreign or unstable", result.stderr)

    def test_manifest_entrypoints_and_versions_are_consistent(self):
        manifest = json.loads(_read("manifest.json"))
        self.assertEqual(manifest["schemaVersion"], 1)
        self.assertRegex(manifest["id"], r"^[a-z0-9]+(?:[._-][a-z0-9]+)+$")
        for relative in manifest["entryPoints"].values():
            self.assertTrue(os.path.isfile(os.path.join(REPO, relative)),
                            relative)
        version = manifest["version"]
        self.assertRegex(
            version,
            r"^(?:0|[1-9][0-9]*)\.(?:0|[1-9][0-9]*)\."
            r"(?:0|[1-9][0-9]*)$")
        patterns = {
            "bin/sialib.py": r'(?m)^VERSION = "([^"]+)"$',
            "bin/sia-mcp": r'(?m)^SERVER_VERSION = "([^"]+)"$',
            "Model.js": (
                r'(?m)^function releaseVersion\(\) \{ return "([^"]+)" \}$'),
        }
        for relative, pattern in patterns.items():
            self.assertEqual(re.findall(pattern, _read(relative)), [version],
                             relative)
        document_patterns = {
            "README.md": r"(?m)^\*\*Current release: v([^*]+)\.\*\*",
            "docs/MANUAL.md": r"(?m)^\*\*Describes SIA v([^ ]+) ·",
            "docs/CONTINUITY.md": r"(?m)^\*\*Describes SIA v([^ ]+) ·",
            "docs/WHITEPAPER.md": (
                r"(?m)^\*\*Khephri Labs · open source \(MIT\) · "
                r"[^·]+ · v([^*]+)\*\*$"),
        }
        for relative, pattern in document_patterns.items():
            self.assertEqual(re.findall(pattern, _read(relative)), [version],
                             relative)
        headings = re.findall(
            r"(?m)^## ((?:0|[1-9][0-9]*)\.(?:0|[1-9][0-9]*)\."
            r"(?:0|[1-9][0-9]*)) —", _read("CHANGELOG.md"))
        self.assertTrue(headings)
        self.assertEqual(headings[0], version)

    def test_operator_docs_match_release_and_recovery_boundaries(self):
        owner = _read("bin/sialifetime.py")
        self.assertIn("ALLOWED_DEADLINES = {120, 300, 1800}", owner)
        for script_name in ("install.sh", "uninstall.sh"):
            script = _read(script_name)
            deadline_comment = script.split(
                "# Status=exact deadline constants:", 1)[1].split(
                    "run_with_deadline() {", 1)[0]
            self.assertNotIn("parsed=15 exact=15", deadline_comment)
            self.assertIn("accepted set is 120, 300, and 1800 seconds",
                          deadline_comment)

        readme = " ".join(_read("README.md").split())
        for requirement in (
                "pidfd_send_signal", "waitid/WNOWAIT/WSTOPPED",
                "child-subreaper", "sealed memfd", "/proc",
                "SCM_CREDENTIALS", "SCM_RIGHTS",
                "before the mutating shell launches"):
            self.assertIn(requirement, readme)

        architecture = _read("docs/ARCHITECTURE.md")
        self.assertIn("root directory descriptor", architecture)
        self.assertIn("descriptor-relative", architecture)

        manual = _read("docs/MANUAL.md")
        quarantine = next(
            line for line in manual.splitlines()
            if line.startswith("| Source replay quarantine"))
        self.assertIn("memo.json", quarantine)
        self.assertIn("cursors.json", quarantine)
        self.assertIn("same known-good backup generation", quarantine)
        self.assertIn("Do not delete", quarantine)
        self.assertIn("Continuity", quarantine)

        config = json.loads(_read("config.example.json"))
        senses_comment = config["senses"]["_comment"]
        self.assertIn("The skills source is the exception", senses_comment)
        self.assertIn("root roster", senses_comment)
        skill_comment = config["skills"]["_comment"].casefold()
        for term in (
                "omitting", "default roster", "empty", "disables",
                "every root is absent", "removal"):
            self.assertIn(term, skill_comment)

    def test_marketplace_documentation_and_license_are_present(self):
        readme = _read("README.md").casefold()
        readme_flat = " ".join(readme.split())
        self.assertTrue(os.path.isfile(os.path.join(REPO, "LICENSE")))
        self.assertIn("install", readme)
        self.assertIn("remove", readme)
        self.assertIn("uninstall.sh", readme)
        self.assertIn("--purge", readme)
        for dependency in ("python", "git", "curl", "tar", "unzip",
                           "bzip2", "sha256sum", "zstd", "systemctl",
                           "flock", "iproute2"):
            self.assertIn(dependency, readme)
        self.assertIn("already listed", readme_flat)
        self.assertIn("private restic", readme_flat)
        self.assertIn("sia foundation", readme_flat)
        marketplace_command = (
            "omarchy plugin add https://github.com/anubisquantumcipher/"
            "sia.git --enable")
        self.assertIn(marketplace_command, readme)
        manual_source = _read("docs/MANUAL.md").casefold()
        manual = " ".join(manual_source.split())
        self.assertIn(marketplace_command, manual_source)
        self.assertIn("already listed", manual)
        self.assertIn("current upstream head", manual)
        self.assertIn("sia backup list", manual)
        self.assertIn("sia restore prepare full_source_snapshot_id", manual)
        self.assertNotIn("sia restore prepare latest", manual)
        self.assertNotIn("not a claim that sia is already listed", manual)

    def test_marketplace_scanned_source_files_fit_the_static_limit(self):
        # Observed from the marketplace baseline's source-snapshot guard.
        for relative, absolute in _marketplace_scanned_sources():
            with self.subTest(path=relative):
                self.assertFalse(os.path.islink(absolute))
                self.assertLessEqual(
                    os.path.getsize(absolute), MARKETPLACE_SCAN_CAP)

    def test_marketplace_scanned_sources_keep_headroom_under_the_limit(self):
        # The cap test above only tells us we have not shipped an
        # unpublishable file YET; it goes green at 524,287 bytes and offers
        # no warning on the way up.  This guard converts the remaining slack
        # into a deadline visible in CI while a module extraction can still
        # be scheduled.
        #
        # The failure names the exact bytes free on purpose: "over 95%" is
        # not actionable, "15,823 bytes left" is.
        crowded = []
        for relative, absolute in _marketplace_scanned_sources():
            size = os.path.getsize(absolute)
            if size > MARKETPLACE_SCAN_HEADROOM_FLOOR:
                crowded.append(
                    f"{relative} is {size} bytes with only "
                    f"{MARKETPLACE_SCAN_CAP - size} bytes free of the "
                    f"{MARKETPLACE_SCAN_CAP}-byte cap")
        self.assertEqual(
            crowded, [],
            "marketplace per-file scan headroom is nearly gone (guard "
            f"trips above {MARKETPLACE_SCAN_HEADROOM_FLOOR} bytes, 95% of "
            f"the {MARKETPLACE_SCAN_CAP}-byte cap): " + "; ".join(crowded)
            + ". Extract a module; raising the threshold is not a repair.")

    def test_architecture_does_not_duplicate_live_module_measurements(self):
        architecture = _read("docs/ARCHITECTURE.md")
        split_modules = architecture.split(
            "## What is already split", 1)[1].split("\n## ", 1)[0]
        section = architecture.split(
            "## What remains in `bin/sialib.py`", 1)[1].split(
                "\n## ", 1)[0]

        self.assertIn("| Module | Lane |", split_modules)
        self.assertNotIn("| Module | Size | Lane |", split_modules)
        self.assertNotRegex(split_modules, r"(?:\bbytes\b|\bKB\b)")
        self.assertIn("wc -lc bin/sialib.py", section)
        self.assertIn(
            "test_marketplace_scanned_source_files_fit_the_static_limit",
            section)
        self.assertIn(
            "test_marketplace_scanned_sources_keep_headroom_under_the_limit",
            section)
        self.assertNotIn("| Lane |", section)
        # This live section deliberately contains no numeric measurements;
        # historical release measurements remain in Extraction progress.
        self.assertNotRegex(section, r"[0-9]")

    def test_operator_docs_state_installer_and_removal_boundaries(self):
        readme = _read("README.md")
        manual = _read("docs/MANUAL.md")
        for document in (readme, manual):
            self.assertIn("# SIA corpus — this machine's memory", document)
            self.assertIn("bin/sia-ledger verify", document)
            self.assertIn("does not attest to extra entries", document)
            self.assertIn("not byte-for-byte intact", document)
            self.assertIn("not transactional", document)
            self.assertIn("unrelated mismatched", document)
            self.assertIn("Python-cryptography", document)
        self.assertIn("malformed/non-list JSON", readme)
        self.assertIn("valid top-level-list JSON", manual)
        self.assertIn("SIA does not silently delete", manual)
        self.assertIn("SIA does not guess", manual)
        for document in (readme, manual):
            self.assertIn("archives the plugin checkout", document)
            self.assertIn("omarchy-shell shell rescanPlugins", document)
            self.assertNotIn("then run `omarchy plugin remove khephri.sia`",
                             document)
        self.assertIn("For a standalone install", _read("skill/SKILL.md"))
        self.assertIn("not access-control or egress controls",
                      _read("SECURITY.md"))
        config = json.loads(_read("config.example.json"))
        boundary = config["_egress_trust_boundary"]
        self.assertIn("MCP client", boundary)
        self.assertIn("CLI", boundary)

    def test_readme_stays_readable(self):
        # A shape ceiling, not a vocabulary assertion (ROADMAP.md, standing gates).
        # The README was once 1,137 lines of duplicated specification; the front
        # door must stay something a person reads. Deep material belongs in
        # docs/MANUAL.md, docs/WHITEPAPER.md, and CHANGELOG.md.
        lines = _read("README.md").count("\n") + 1
        self.assertLessEqual(
            lines, 500,
            f"README.md is {lines} lines; move specification material to the "
            "manual/whitepaper instead of growing the front door")

    def test_generalized_publication_and_legacy_upgrade_are_documented(self):
        # The deep migration/publication vocabulary belongs in the specification
        # documents. The README is the front door and describes the same behavior
        # in operator language; forcing the migration jargon into it made it
        # unreadable without protecting any user, so the README is deliberately
        # NOT in this list (its own operator-facing promises are pinned by the
        # marketplace, boundary, and recovery documentation tests).
        documents = {
            relative: _read(relative)
            for relative in (
                "docs/MANUAL.md", "docs/WHITEPAPER.md",
                "CHANGELOG.md", "SECURITY.md",
            )
        }
        contract_terms = (
            "MIGRATE:take-origin",
            "model-inert-v1",
            "legacy-v1-normalize",
            "origin: derived",
            "origin: model",
            "take-migrations",
            "sync_needed",
        )
        for relative, document in documents.items():
            with self.subTest(document=relative):
                for term in contract_terms:
                    self.assertIn(term, document)
                folded = " ".join(document.casefold().split())
                for term in (
                    "publication debt",
                    "grade-transactions",
                    "same corpus generation",
                    "pulse sequence",
                    "returned result",
                    "memory-backed",
                ):
                    self.assertIn(term, folded)
                for writer in (
                    "`pulse`", "`dream`", "`take`", "`intent`",
                    "`grade`", "`ponder`",
                ):
                    self.assertIn(writer, document)
                for surface in ("git", "PGLite", "graph"):
                    self.assertIn(surface, document)

        # These are operator-visible behaviors, so the README keeps them too.
        readme = _read("README.md")
        for relative, document in (("README.md", readme),
                                   ("docs/MANUAL.md", documents["docs/MANUAL.md"]),
                                   ("CHANGELOG.md", documents["CHANGELOG.md"])):
            with self.subTest(first_light_document=relative):
                self.assertIn("first-light pulse", document)
                self.assertIn("successful `sia pulse`", document)
                self.assertIn("last-published", document)

        for relative, document in (("README.md", readme),
                                   ("docs/MANUAL.md", documents["docs/MANUAL.md"])):
            with self.subTest(readiness_document=relative):
                self.assertIn("SIA memory read refused", document)
                self.assertIn("readiness line", document)

        for relative in ("docs/WHITEPAPER.md", "SECURITY.md"):
            document = documents[relative].casefold()
            with self.subTest(non_claim_document=relative):
                self.assertIn("not prove", document)
                self.assertIn("verdict", document)
                self.assertIn("access-control boundary", document)
                self.assertIn("gbrain", document)
                self.assertIn("raw corpus", document)

    def test_default_configuration_requires_explicit_judge_consent(self):
        config = json.loads(_read("config.example.json"))
        self.assertEqual(config["judge"]["backend"], "none")
        self.assertEqual(config["judge"]["model"], "")

    def test_brainstem_service_waits_for_post_admission_readiness(self):
        unit = _read("systemd/sia-brainstem.service")
        self.assertIn("Type=notify\n", unit)
        self.assertIn("NotifyAccess=main\n", unit)
        self.assertIn("TimeoutStartSec=120\n", unit)
        self.assertIn("RestartPreventExitStatus=78\n", unit)
        self.assertNotIn("Type=simple\n", unit)

    def test_brainstem_restart_suppression_matches_source_exit_policy(self):
        statuses = re.findall(
            r"(?m)^RestartPreventExitStatus=([0-9]+)$",
            _read("systemd/sia-brainstem.service"))
        self.assertEqual(statuses, ["78"])
        service_status = int(statuses[0], 10)

        assignments = [
            node for node in ast.parse(_read("bin/sia-brainstem")).body
            if isinstance(node, ast.Assign)
            and any(isinstance(target, ast.Name)
                    and target.id == "INTENTIONAL_STOP_EXIT"
                    for target in node.targets)
        ]
        self.assertEqual(len(assignments), 1)
        assignment = assignments[0]
        self.assertEqual(len(assignment.targets), 1)
        self.assertIsInstance(assignment.targets[0], ast.Name)

        policy = assignment.value
        self.assertIsInstance(policy, ast.Call)
        self.assertIsInstance(policy.func, ast.Name)
        self.assertEqual(policy.func.id, "getattr")
        self.assertEqual(len(policy.args), 3)
        self.assertEqual(policy.keywords, [])
        self.assertIsInstance(policy.args[0], ast.Name)
        self.assertEqual(policy.args[0].id, "os")
        self.assertEqual(ast.literal_eval(policy.args[1]), "EX_CONFIG")

        fallback = ast.literal_eval(policy.args[2])
        self.assertIs(type(fallback), int)
        self.assertEqual(service_status, fallback)
        self.assertEqual(
            service_status, getattr(os, "EX_CONFIG", fallback))

    def test_installer_uses_full_pins_and_verified_downloads(self):
        installer = _read("install.sh")
        flattened_installer = re.sub(r"\\\n\s*", " ", installer)
        ordered_installer = re.sub(r"\s+", " ", flattened_installer)
        pins = dict(line.split("=", 1)
                    for line in _read("GBRAIN_PIN").splitlines()
                    if "=" in line and not line.startswith("#"))
        self.assertRegex(pins["commit"], r"^[0-9a-f]{40}$")
        self.assertRegex(pins["bun_lock_sha256"], r"^[0-9a-f]{64}$")
        self.assertRegex(pins["overlay_sha256"], r"^[0-9a-f]{64}$")
        self.assertRegex(pins["overlay_tree_oid"], r"^[0-9a-f]{40}$")
        self.assertIn('[[ "$PIN" =~ ^[0-9a-f]{40}$ ]]', installer)
        self.assertIn('git -C "$GBRAIN_SOURCE" rev-parse HEAD', installer)
        self.assertRegex(
            flattened_installer,
            r'run_with_deadline 1800 "\$\{GBRAIN_STERILE_ENV\[@\]\}"\s+'
            r'"\$BUN_BIN" install\s+--no-env-file\s+'
            r'--cwd "\$GBRAIN_SOURCE"\s+--frozen-lockfile')
        self.assertIn('--production --ignore-scripts --no-progress', installer)
        self.assertRegex(
            flattened_installer,
            r'run_with_deadline 1800 "\$\{GBRAIN_STERILE_ENV\[@\]\}"\s+'
            r'"\$BUN_BIN" build[^\n]*'
            r'--compile\s+--outfile')
        self.assertIn(
            'GBRAIN_VERSION_OUTPUT="$(bounded_command_capture', installer)
        self.assertIn('GBRAIN_BIN="$GBRAIN_ROOT/bin/gbrain"', installer)
        self.assertNotIn('bun install -g', installer)
        self.assertNotIn('$HOME/.bun', installer)
        self.assertIn("sha256sum -c -", installer)
        download_helper = installer.split("download_verified() {", 1)[1].split(
            "\n}\n", 1)[0]
        self.assertIn('local url="$1" artifact_file="$2" expected="$3"',
                      download_helper)
        self.assertIn('-o "$artifact_file" "$url"', download_helper)
        self.assertNotIn('"$out"', download_helper)
        self.assertNotIn("releases/latest", installer)
        self.assertNotRegex(installer,
                            r"curl[^\n]*\|\s*(?:ba)?sh(?:\s|$)")
        self.assertIn("--max-filesize 2147483648", installer)
        self.assertIn("run_with_deadline 300 unzip -q", installer)
        self.assertIn("run_with_deadline 300 tar --zstd", installer)
        checksums = re.findall(r"^\s*[A-Z0-9_]+_SHA256=([0-9a-f]+)$",
                              installer, re.MULTILINE)
        self.assertTrue(checksums)
        self.assertTrue(all(len(value) == 64 for value in checksums))
        self.assertIn('siabench.py siaqueue.py', installer)
        self.assertIn('bin/siasenses.py', installer)
        self.assertIn('bin/siarestoreadmit.py', installer)
        self.assertIn('siasenses.py siarestoreadmit.py', installer)
        self.assertIn('siarestoreadmit.py siamind.py', installer)
        self.assertIn('SIA_INSTALL_KEYBINDING:-0', installer)
        self.assertIn('SIA_BRAINSTEM_WAS_ACTIVE=1', installer)
        self.assertIn('SIA_INSTALL_MUTATED=1', installer)
        self.assertIn('"INSTALL:runtime"', installer)
        self.assertIn('"INSTALL:index"', installer)
        self.assertGreaterEqual(installer.count("sialib.durable_ledger_append"),
                                2)
        bun_mutation = installer.index('SIA_INSTALL_MUTATED=1',
                                       installer.index('BUN_VERSION='))
        self.assertLess(bun_mutation,
                        installer.index('atomic_install_tree "$SIA_BUN_STAGE"'))
        self.assertIn('install failed after mutation; sia-brainstem was disabled and stopped',
                      installer)
        self.assertIn('SIA_RUNTIME_STAGE="$(mktemp -d '
                      '"$SHARE/.bin.stage.XXXXXX")"', installer)
        self.assertIn('atomic_install_tree "$SIA_RUNTIME_STAGE" "$BINDIR"',
                      installer)
        self.assertIn('SIA_LAUNCHER_ABI', installer)
        self.assertIn('"$SIA_RUNTIME_STAGE/sia-brainstem.py"', installer)
        self.assertIn('"$SIA_RUNTIME_STAGE/sia-cli"', installer)
        self.assertIn('drain_legacy_launchers', installer)
        self.assertIn('previous runtime tree retained', installer)
        self.assertNotIn('cp "$REPO"/bin/sialib.py', installer)
        self.assertIn('export GBRAIN_SKIP_STARTUP_HOOKS=1', installer)
        self.assertLess(installer.index('export GBRAIN_SKIP_STARTUP_HOOKS=1'),
                        installer.index('"$GBRAIN_BIN" --version'))
        self.assertIn('[ "$GBRAIN_VERSION_OUTPUT" = "gbrain $PIN_VERSION" ]',
                      installer)
        self.assertNotIn('gbrain config set self_upgrade.mode off', installer)
        self.assertIn('self_upgrade["mode"] = "off"', installer)
        self.assertIn('"$GBRAIN_BIN" config get self_upgrade.mode', installer)
        self.assertIn("source: file/env plane", installer)
        self.assertIn("GBRAIN_SELF_UPGRADE_OUTPUT", installer)
        self.assertNotIn(
            '[ "$GBRAIN_SELF_UPGRADE_MODE" = "off" ]', installer)
        self.assertIn('"$GBRAIN_BIN" sources list --json', installer)
        self.assertNotIn(
            'gbrain sources add sia --path "$SHARE/corpus" 2>/dev/null || true',
            installer)
        self.assertNotIn(
            'gbrain schema validate sia-pack >/dev/null && gbrain schema use',
            installer)
        self.assertIn('SIA_CANONICAL_HOME="$(cd -P -- "$HOME"', installer)
        self.assertIn('HOME resolves to /', installer)
        self.assertIn('LIFECYCLE_LOCK="$HOME/.local/state/sia.lifecycle.lock"',
                      installer)
        self.assertIn('acquire_owner_lock "$STATE/corpus-owner.lock"',
                      installer)
        self.assertIn('preflight_corpus', installer)
        cli_preflight = installer.index(
            'preflight_owned_file "$SIA_STABLE_LAUNCHER" "$CLI_PATH"')
        runtime_exchange = installer.index(
            'atomic_install_tree "$SIA_RUNTIME_STAGE" "$BINDIR"')
        self.assertLess(cli_preflight, runtime_exchange)
        self.assertIn('[[ "$digest" =~ ^[0-9a-f]{64}$ ]]', installer)
        self.assertIn("MAX_METADATA_BYTES = 65_536", installer)
        self.assertIn('getattr(os, "O_NOFOLLOW", 0)', installer)
        self.assertIn("finish_stable(path, descriptor, before)", installer)
        self.assertIn('owned_metadata managed-file "$receipt" "$kind"',
                      installer)
        self.assertNotIn('contents="$(cat -- "$receipt")"', installer)
        self.assertIn("DropInPaths", installer)
        self.assertIn("is not running the exact managed runtime", installer)
        self.assertNotIn('SIA_BACKFILL=1 "$HOME/.local/bin/sia" pulse || true',
                         installer)
        first_light = installer.index(
            'SIA_BACKFILL=1 python3 "$BINDIR/sia-cli" pulse')
        readiness_attestation = installer.index(
            'python3 "$BINDIR/sia-cli" ready', first_light)
        brainstem_release = installer.index(
            'flock -u "$SIA_BRAINSTEM_LOCK_FD"')
        brainstem_reacquire = installer.index(
            '"brainstem after first light"')
        self.assertLess(brainstem_release, first_light)
        self.assertLess(first_light, readiness_attestation)
        self.assertLess(readiness_attestation, brainstem_reacquire)
        self.assertLess(first_light, brainstem_reacquire)
        first_light_block = installer[
            installer.index('step "7/9 first light'):
            installer.index('step "8/9 desktop')]
        self.assertIn('SIA_INHERITED_LIFECYCLE_FD="$SIA_INSTALL_LOCK_FD"',
                      first_light_block)
        self.assertIn(
            'environment.pop("SIA_INHERITED_CORPUS_FD", None)', installer)
        self.assertNotIn('clear_lifecycle_tombstone', first_light_block)
        self.assertNotIn('write_lifecycle_tombstone', first_light_block)
        self.assertNotIn('flock -s "$SIA_INSTALL_LOCK_FD"',
                         first_light_block)
        self.assertIn('flock -n "$SIA_INSTALL_LOCK_FD"', installer)
        self.assertNotIn('flock "$SIA_INSTALL_LOCK_FD"', installer)
        main_installer = ordered_installer[
            ordered_installer.index('SIA_RELEASE_FILES=('):]
        runtime_barrier = main_installer.index(
            'install_brainstem_runtime_barrier')
        lifecycle_acquire = main_installer.index(
            'acquire_install_lifecycle ')
        final_lifecycle_release = main_installer.rindex(
            'flock -u "$SIA_INSTALL_LOCK_FD"')
        runtime_unbarrier = main_installer.rindex(
            'retire_install_brainstem_runtime_barrier')
        final_start = main_installer.rindex(
            'systemctl --user start sia-brainstem.service')
        self.assertLess(runtime_barrier, lifecycle_acquire)
        self.assertLess(final_lifecycle_release, runtime_unbarrier)
        self.assertLess(runtime_unbarrier, final_start)
        self.assertIn('RefuseManualStart=yes', installer)
        self.assertIn('ConditionPathExists=!/', installer)
        self.assertIn('sia-lifecycle-barrier.conf', installer)
        self.assertNotIn('systemctl --user mask --runtime', installer)
        self.assertNotIn('systemctl --user unmask --runtime', installer)

    def test_installer_rejects_home_that_resolves_to_root(self):
        environment = os.environ.copy()
        environment["HOME"] = "/tmp/.."
        result = subprocess.run(
            ["bash", os.path.join(REPO, "install.sh")],
            cwd=REPO, env=environment, text=True,
            stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
        self.assertEqual(result.returncode, 2)
        self.assertIn("HOME resolves to /", result.stderr)

    def test_owned_metadata_rejects_nonexact_and_unstable_files(self):
        for relative in ("install.sh", "uninstall.sh"):
            with self.subTest(script=relative), tempfile.TemporaryDirectory() as root:
                function = _owned_metadata_shell(_read(relative))
                target = os.path.join(root, "target")
                receipt = os.path.join(root, "receipt")
                _write(target, "managed target\n")
                exact = _managed_file_receipt(target, "sia-cli")
                command = (function +
                           '\nowned_metadata managed-file "$1" sia-cli "$2"')

                _write(receipt, exact)
                valid = subprocess.run(
                    ["bash", "-c", command, "metadata-test", receipt, target],
                    stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
                self.assertEqual(valid.returncode, 0, valid.stderr.decode())

                with open(receipt, "wb") as stream:
                    stream.write(exact.encode() + b"\0ignored")
                nul = subprocess.run(
                    ["bash", "-c", command, "metadata-test", receipt, target],
                    stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
                self.assertNotEqual(nul.returncode, 0)

                with open(receipt, "wb") as stream:
                    stream.write(b"x" * 65_537)
                oversized = subprocess.run(
                    ["bash", "-c", command, "metadata-test", receipt, target],
                    stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
                self.assertNotEqual(oversized.returncode, 0)

                os.unlink(receipt)
                replacement = os.path.join(root, "replacement")
                _write(replacement, exact)
                os.symlink(replacement, receipt)
                linked = subprocess.run(
                    ["bash", "-c", command, "metadata-test", receipt, target],
                    stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
                self.assertNotEqual(linked.returncode, 0)

        installer = _read("install.sh")
        python_source = _owned_metadata_python(installer)
        with tempfile.TemporaryDirectory() as root:
            receipt = os.path.join(root, "receipt")
            replacement = os.path.join(root, "replacement")
            _write(receipt, "managed-by=khephri.sia\n")
            _write(replacement, "managed-by=khephri.sia\n")
            real_stat = os.stat
            replaced = False

            def replacing_stat(path, *args, **kwargs):
                nonlocal replaced
                if path == receipt and not replaced:
                    os.replace(replacement, receipt)
                    replaced = True
                return real_stat(path, *args, **kwargs)

            with mock.patch.object(sys, "argv", [
                    "owned-metadata", "exact", receipt,
                    "managed-by=khephri.sia"]), \
                    mock.patch.object(os, "stat", replacing_stat):
                with self.assertRaises(SystemExit) as stopped:
                    exec(compile(python_source, "owned-metadata", "exec"), {})
            self.assertNotEqual(stopped.exception.code, 0)

            _write(receipt, "managed-by=khephri.sia\n")
            real_fstat = os.fstat
            inspections = 0

            def mutating_fstat(descriptor):
                nonlocal inspections
                inspections += 1
                if inspections == 2:
                    with open(receipt, "ab") as stream:
                        stream.write(b"changed")
                return real_fstat(descriptor)

            with mock.patch.object(sys, "argv", [
                    "owned-metadata", "exact", receipt,
                    "managed-by=khephri.sia"]), \
                    mock.patch.object(os, "fstat", mutating_fstat):
                with self.assertRaises(SystemExit) as stopped:
                    exec(compile(python_source, "owned-metadata", "exec"), {})
            self.assertNotEqual(stopped.exception.code, 0)

    def test_lifecycle_lease_blocks_install_and_uninstall(self):
        with tempfile.TemporaryDirectory() as root:
            home = os.path.join(root, "home")
            fake_bin = os.path.join(root, "bin")
            os.makedirs(fake_bin)
            _fake_command(fake_bin, "systemctl", ABSENT_USER_UNIT)
            _fake_command(fake_bin, "sleep", "exit 0\n")
            guard_trace = os.path.join(root, "guard-trace")
            _guard_fixture(fake_bin, guard_trace)
            lock_path = os.path.join(home, ".local/state/sia.lifecycle.lock")
            _write(lock_path, "")
            environment = os.environ.copy()
            environment.update({
                "HOME": home,
                "PATH": fake_bin + os.pathsep + environment["PATH"],
            })
            with open(lock_path, "a+") as lease:
                fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
                for script in ("install.sh", "uninstall.sh"):
                    result = subprocess.run(
                        ["bash", os.path.join(REPO, script)],
                        cwd=REPO, env=environment, text=True,
                        stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                        timeout=30, check=False)
                    self.assertNotEqual(result.returncode, 0, script)
                    self.assertIn("active SIA clients did not leave",
                                  result.stderr, script)
                self.assertEqual(_read_path(guard_trace), "admitted\n")

    def test_uninstaller_fences_legacy_launchers_before_integration_mutation(self):
        uninstaller = _read("uninstall.sh")
        lifecycle = uninstaller.index("acquire_uninstall_lifecycle || exit 1")
        recovery = uninstaller.index(
            "recover_publication_receipts_from_fence || {", lifecycle)
        first_drain = uninstaller.index(
            "drain_legacy_launchers || {", recovery)
        tombstone = uninstaller.index(
            "write_lifecycle_tombstone || {", first_drain)
        fence = uninstaller.index(
            "arm_uninstall_launch_fence || {", tombstone)
        second_drain = uninstaller.index(
            "drain_legacy_launchers || {", fence)
        plugin_mutation = uninstaller.index(
            "omarchy plugin disable khephri.sia", second_drain)
        mcp_mutation = uninstaller.index(
            "remove_managed_mcp claude", second_drain)
        unit_mutation = uninstaller.index(
            'owned_file_cas archive "$UNIT_BACKUP"', second_drain)
        cli_mutation = uninstaller.index(
            'attempt "remove SIA CLI" remove_owned_cli', second_drain)
        purge_mutation = uninstaller.index(
            'attempt "purge retained SIA state"', second_drain)
        self.assertEqual(
            sorted((lifecycle, recovery, first_drain, tombstone, fence,
                    second_drain, plugin_mutation, mcp_mutation,
                    unit_mutation, cli_mutation, purge_mutation)),
            [lifecycle, recovery, first_drain, tombstone, fence,
             second_drain, plugin_mutation, mcp_mutation,
             unit_mutation, cli_mutation, purge_mutation])
        fence_body = uninstaller.split(
            "arm_uninstall_launch_fence() {", 1)[1].split(
                "\n}\n\nrestore_runtime_archive_fence_modes", 1)[0]
        self.assertLess(fence_body.index("os.fsync(stream.fileno())"),
                        fence_body.index("os.fchmod(descriptor, 0)"))
        self.assertIn("os.fsync(directory)", fence_body)
        self.assertIn("os.fsync(descriptor)", fence_body)

    def test_uninstaller_drains_legacy_mcp_then_mutates_behind_durable_fence(self):
        with tempfile.TemporaryDirectory() as root:
            home = os.path.join(root, "home")
            fake_bin = os.path.join(root, "bin")
            waiting = os.path.join(root, "drain-waiting")
            allow_drain = os.path.join(root, "allow-drain")
            legacy_started = os.path.join(root, "legacy-started")
            release_legacy = os.path.join(root, "release-legacy")
            mcp_removed = os.path.join(root, "mcp-removed")
            mcp_mutated = os.path.join(root, "mcp-mutated")
            os.makedirs(fake_bin)
            cli, runtime = _managed_cli_runtime(home)
            legacy_mcp = os.path.join(runtime, "sia-mcp")
            _write(
                legacy_mcp,
                "#!/usr/bin/env python3\n"
                "import os, sys, time\n"
                "open(sys.argv[1], 'w', encoding='utf-8').close()\n"
                "while not os.path.exists(sys.argv[2]):\n"
                "    time.sleep(0.01)\n",
                0o755)
            runtime_receipt = os.path.join(
                home, ".local/state/sia/managed-install/runtime")
            _write(
                runtime_receipt,
                "managed-by=khephri.sia\nkind=runtime\n"
                f"path={runtime}\nsha256={_runtime_digest(runtime)}\n")
            _write(
                os.path.join(home, ".local/state/sia/managed-mcp/claude"),
                "managed-by=khephri.sia\ncommand=python3\n"
                f"arg={legacy_mcp}\n")
            _fake_command(fake_bin, "systemctl", ABSENT_USER_UNIT)
            _fake_command(
                fake_bin, "sleep",
                ': > "$DRAIN_WAITING"\n'
                'while [ ! -e "$ALLOW_DRAIN" ]; do '
                '/usr/bin/sleep 0.01; done\n')
            _fake_command(
                fake_bin, "claude",
                'test -f "$HOME/.local/state/sia.lifecycle-removed" '
                '|| exit 90\n'
                'test -f "$HOME/.local/state/sia/managed-install/'
                'launch-fence.json" || exit 91\n'
                'test "$(stat -c %a "$HOME/.local/bin/sia")" = 0 '
                '|| exit 92\n'
                'test "$(stat -c %a "$HOME/.local/share/sia/bin/sia-mcp")" '
                '= 0 || exit 93\n'
                'if [ "$1 $2 $3" = "mcp get sia" ]; then\n'
                '  if [ -e "$MCP_REMOVED" ]; then\n'
                '    echo "No MCP server named sia" >&2; exit 1\n'
                '  fi\n'
                '  echo "sia:"\n'
                '  echo "  Scope: User config (available in all your projects)"\n'
                '  echo "  Status: Connected"\n'
                '  echo "  Type: stdio"\n'
                '  echo "  Command: python3"\n'
                '  echo "  Args: $HOME/.local/share/sia/bin/sia-mcp"\n'
                '  echo "  Environment:"\n'
                '  echo\n'
                '  exit 0\n'
                'fi\n'
                'if [ "$1 $2" = "mcp remove" ]; then\n'
                '  : > "$MCP_REMOVED"; : > "$MCP_MUTATED"; exit 0\n'
                'fi\n'
                'exit 1\n')
            _fake_command(
                fake_bin, "codex",
                'echo "No MCP server named sia" >&2\nexit 1\n')
            _fake_command(fake_bin, "grok", 'echo "[]"\n')
            environment = os.environ.copy()
            environment.update({
                "HOME": home,
                "PATH": fake_bin + os.pathsep + environment["PATH"],
                "DRAIN_WAITING": waiting,
                "ALLOW_DRAIN": allow_drain,
                "MCP_REMOVED": mcp_removed,
                "MCP_MUTATED": mcp_mutated,
            })
            legacy = subprocess.Popen(
                [sys.executable, legacy_mcp, legacy_started, release_legacy],
                env=environment, stdout=subprocess.PIPE,
                stderr=subprocess.PIPE, text=True)
            uninstaller = None
            try:
                deadline = time.monotonic() + 30
                while not os.path.exists(legacy_started):
                    if legacy.poll() is not None:
                        stdout, stderr = legacy.communicate()
                        self.fail("legacy MCP exited before drain: "
                                  f"{stdout}\n{stderr}")
                    if time.monotonic() >= deadline:
                        self.fail("legacy MCP did not start")
                    time.sleep(0.01)
                uninstaller = subprocess.Popen(
                    ["bash", os.path.join(REPO, "uninstall.sh")],
                    cwd=REPO, env=environment, text=True,
                    stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                while not os.path.exists(waiting):
                    if uninstaller.poll() is not None:
                        stdout, stderr = uninstaller.communicate()
                        self.fail("uninstaller did not wait for legacy MCP: "
                                  f"{stdout}\n{stderr}")
                    if time.monotonic() >= deadline:
                        self.fail("uninstaller did not enter legacy drain")
                    time.sleep(0.01)
                self.assertFalse(os.path.exists(mcp_mutated))
                self.assertFalse(os.path.exists(os.path.join(
                    home, ".local/state/sia.lifecycle-removed")))
                self.assertFalse(os.path.exists(os.path.join(
                    home, ".local/state/sia/managed-install/launch-fence.json")))

                _write(release_legacy, "release\n")
                legacy_stdout, legacy_stderr = legacy.communicate(timeout=30)
                self.assertEqual(legacy.returncode, 0,
                                 legacy_stdout + legacy_stderr)
                _write(allow_drain, "continue\n")
                stdout, stderr = uninstaller.communicate(timeout=30)
                self.assertEqual(uninstaller.returncode, 0, stderr)
                self.assertFalse(os.path.exists(mcp_mutated))
                self.assertTrue(os.path.lexists(cli))
                self.assertTrue(os.path.lexists(runtime))
                self.assertFalse(os.path.isfile(os.path.join(
                    home, ".local/state/sia.lifecycle-removed")))
                self.assertFalse(os.path.lexists(os.path.join(
                    home,
                    ".local/state/sia/managed-install/launch-fence.json")))
                self.assertIn("uninstall completed successfully", stdout)
            finally:
                for process in (uninstaller, legacy):
                    if process is not None and process.poll() is None:
                        process.terminate()
                        try:
                            process.wait(timeout=30)
                        except subprocess.TimeoutExpired:
                            process.kill()
                            process.wait(timeout=30)

    def test_uninstaller_recovers_interrupted_install_publication_receipts(self):
        with tempfile.TemporaryDirectory() as root:
            home = os.path.join(root, "home")
            fake_bin = os.path.join(root, "bin")
            runtime = os.path.join(home, ".local/share/sia/bin")
            cli = os.path.join(home, ".local/bin/sia")
            managed = os.path.join(
                home, ".local/state/sia/managed-install")
            journal = os.path.join(managed, "launch-fence.json")
            tombstone = os.path.join(
                home, ".local/state/sia.lifecycle-removed")
            os.makedirs(fake_bin)
            for name in (
                    "sia-brainstem", "sia-brainstem.py", "sia-cli",
                    "sia-ledger", "sia-mcp", "siabench.py", "sialib.py", "siasenses.py",
                    "siamind.py", "siaqueue.py", "siatakes.py"):
                _write(os.path.join(runtime, name), name + "\n", 0o755)
            _write(cli, "new stable launcher\n", 0o755)
            with open(cli, "rb") as stream:
                cli_digest = hashlib.sha256(stream.read()).hexdigest()
            payload = {
                "schema": "sia-launch-fence-v1",
                "runtime_before_digest": hashlib.sha256(
                    b"prior runtime").hexdigest(),
                "runtime_digest": _runtime_digest(runtime),
                "cli_digest": cli_digest,
                "entries": [],
            }
            _write(journal, json.dumps(
                payload, sort_keys=True, separators=(",", ":")) + "\n",
                0o600)
            _write(tombstone, "removed-by=khephri.sia\n", 0o600)
            _fake_command(fake_bin, "systemctl", ABSENT_USER_UNIT)
            for client in ("claude", "codex"):
                _fake_command(
                    fake_bin, client,
                    'echo "No MCP server named sia" >&2\nexit 1\n')
            _fake_command(fake_bin, "grok", 'echo "[]"\n')
            environment = os.environ.copy()
            environment.update({
                "HOME": home,
                "PATH": fake_bin + os.pathsep + environment["PATH"],
            })
            result = subprocess.run(
                ["bash", os.path.join(REPO, "uninstall.sh")],
                cwd=REPO, env=environment, text=True,
                stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertIn("recovered exact runtime receipt", result.stdout)
            self.assertIn("recovered exact CLI receipt", result.stdout)
            self.assertFalse(os.path.lexists(cli))
            self.assertFalse(os.path.lexists(runtime))
            self.assertFalse(os.path.lexists(journal))
            self.assertEqual(_read_path(tombstone),
                             "removed-by=khephri.sia\n")

    def test_install_fence_recovery_preserves_empty_runtime_named_field(self):
        recovery = _publication_receipt_recovery_shell(_read("install.sh"))
        with tempfile.TemporaryDirectory() as root:
            home = os.path.join(root, "home")
            bindir = os.path.join(home, ".local/share/sia/bin")
            cli = os.path.join(home, ".local/bin/sia")
            managed = os.path.join(
                home, ".local/state/sia/managed-install")
            journal = os.path.join(managed, "launch-fence.json")
            tombstone = os.path.join(
                home, ".local/state/sia.lifecycle-removed")
            trace = os.path.join(root, "unexpected-call")
            os.makedirs(bindir)
            _write(cli, "old fenced launcher\n", 0o755)
            with open(cli, "rb") as stream:
                fenced_digest = hashlib.sha256(stream.read()).hexdigest()
            cli_info = os.lstat(cli)
            os.chmod(cli, 0)
            desired_digest = hashlib.sha256(
                b"desired replacement launcher\n").hexdigest()
            self.assertNotEqual(desired_digest, fenced_digest)
            payload = {
                "schema": "sia-launch-fence-v1",
                "runtime_before_digest": "",
                "runtime_digest": "",
                "cli_digest": desired_digest,
                "entries": [{
                    "path": cli,
                    "device": cli_info.st_dev,
                    "inode": cli_info.st_ino,
                    "mode": stat.S_IMODE(cli_info.st_mode),
                    "sha256": fenced_digest,
                }],
            }
            _write(journal, json.dumps(
                payload, sort_keys=True, separators=(",", ":")) + "\n",
                0o600)
            _write(tombstone, "removed-by=khephri.sia\n", 0o600)
            script = recovery + r'''
set -u
LAUNCH_FENCE_JOURNAL="$JOURNAL"
LIFECYCLE_TOMBSTONE="$TOMBSTONE"
BINDIR="$TEST_BINDIR"
CLI_PATH="$TEST_CLI"
RUNTIME_RECEIPT="$TEST_MANAGED/runtime"
CLI_RECEIPT="$TEST_MANAGED/sia-cli"
runtime_tree_digest() {
  printf '%s\n' runtime-tree-digest >> "$TRACE"
  return 91
}
owned_metadata() {
  printf '%s\n' owned-metadata-digest >> "$TRACE"
  return 92
}
write_managed_receipt() {
  printf '%s\n' receipt-publication >> "$TRACE"
  return 0
}
recover_publication_receipts_from_fence || exit 93
printf '%s\n' recovery-complete
'''
            environment = os.environ.copy()
            environment.update({
                "HOME": home,
                "JOURNAL": journal,
                "TOMBSTONE": tombstone,
                "TEST_BINDIR": bindir,
                "TEST_CLI": cli,
                "TEST_MANAGED": managed,
                "TRACE": trace,
            })
            result = subprocess.run(
                ["bash", "-c", script], env=environment, text=True,
                stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(result.stdout, "recovery-complete\n")
            self.assertFalse(os.path.lexists(trace))
            self.assertEqual(stat.S_IMODE(os.lstat(cli).st_mode), 0)

    def test_install_fence_recovery_rejects_bad_named_field_output(self):
        recovery = _publication_receipt_recovery_shell(_read("install.sh"))
        malformed_outputs = {
            "duplicate": (
                "runtime_digest=\nruntime_digest=duplicate\n"
                "cli_digest=desired\nfenced_cli=fenced\n"),
            "unknown": (
                "runtime_digest=\ncli_digest=desired\n"
                "fenced_cli=fenced\nunexpected=value\n"),
            "missing": "runtime_digest=\ncli_digest=desired\n",
        }
        for case, recovered_fields in malformed_outputs.items():
            with self.subTest(case=case), \
                    tempfile.TemporaryDirectory() as root:
                journal = os.path.join(root, "launch-fence.json")
                _write(journal, "present\n", 0o600)
                script = recovery + r'''
set -u
LAUNCH_FENCE_JOURNAL="$JOURNAL"
LIFECYCLE_TOMBSTONE="$JOURNAL"
BINDIR="$WORK/runtime"
CLI_PATH="$WORK/sia"
RUNTIME_RECEIPT="$WORK/runtime-receipt"
CLI_RECEIPT="$WORK/cli-receipt"
python3() { printf '%s' "$RECOVERED_FIELDS"; }
recover_publication_receipts_from_fence
'''
                environment = os.environ.copy()
                environment.update({
                    "JOURNAL": journal,
                    "WORK": root,
                    "RECOVERED_FIELDS": recovered_fields,
                })
                result = subprocess.run(
                    ["bash", "-c", script], env=environment, text=True,
                    stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                    check=False)
                self.assertNotEqual(result.returncode, 0)

    def test_runtime_v3_digest_migrates_without_replacing_valid_v2_tree(self):
        installer = _read("install.sh")
        digest_function = _runtime_tree_digest_shell(installer)
        receipt_function = "runtime_receipt_valid() {" + installer.split(
            "runtime_receipt_valid() {", 1)[1].split(
                "\n}\n\nfenced_managed_file_authorized", 1)[0] + "\n}\n"
        preflight_function = "preflight_runtime() {" + installer.split(
            "preflight_runtime() {", 1)[1].split(
                "\n}\n\nrecover_publication_receipts_from_fence", 1)[0] \
            + "\n}\n"
        functions = digest_function + receipt_function + preflight_function
        with tempfile.TemporaryDirectory() as root:
            share = os.path.join(root, "share")
            runtime = os.path.join(share, "bin")
            receipt = os.path.join(root, "managed", "runtime")
            for name in MODERN_V2_RUNTIME_NAMES:
                _write(os.path.join(runtime, name), name + "\n", 0o644)

            def write_receipt():
                _write(
                    receipt,
                    "managed-by=khephri.sia\nkind=runtime\n"
                    f"path={runtime}\nsha256={_runtime_digest(runtime)}\n",
                    0o600)

            script = functions + r'''
set -u
SHARE="$TEST_SHARE"
BINDIR="$TEST_RUNTIME"
RUNTIME_RECEIPT="$TEST_RECEIPT"
SIA_REPLACE_RUNTIME=0
SIA_RUNTIME_TREE_EXPECTED=
owned_tree_cas() { [ "$1" = recover ]; }
owned_tree_generation() { printf '%s\n' stable-runtime-generation; }
fenced_runtime_authorized() { return 1; }
owned_metadata() {
  local kind="$1" receipt="$2" path="$3" digest="$4" expected
  [ "$kind" = runtime ] || return 1
  expected="$(printf \
    'managed-by=khephri.sia\nkind=runtime\npath=%s\nsha256=%s\n' \
    "$path" "$digest")"
  [ "$(cat -- "$receipt")" = "$expected" ]
}
preflight_runtime
'''
            environment = os.environ.copy()
            environment.update({
                "TEST_SHARE": share,
                "TEST_RUNTIME": runtime,
                "TEST_RECEIPT": receipt,
            })

            def preflight():
                return subprocess.run(
                    ["bash", "-c", script], env=environment, text=True,
                    stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                    check=False)

            # A receipt from the currently published modern-v2 runtime stays
            # valid, so its normal upgrade path never requires replacement.
            write_receipt()
            result = preflight()
            self.assertEqual(result.returncode, 0, result.stderr)

            # The child file changes the membership version. It cannot be
            # smuggled into a v2 receipt, and the v3 receipt then validates.
            _write(os.path.join(runtime, "siasenses.py"), "child\n", 0o644)
            self.assertNotEqual(preflight().returncode, 0)
            write_receipt()
            result = preflight()
            self.assertEqual(result.returncode, 0, result.stderr)

            # A v3 receipt never authorizes an incomplete/rolled-back tree.
            os.unlink(os.path.join(runtime, "siasenses.py"))
            self.assertNotEqual(preflight().returncode, 0)

    def test_uninstaller_fence_requires_complete_v3_runtime(self):
        function = _uninstaller_fenced_runtime_shell(_read("uninstall.sh"))
        with tempfile.TemporaryDirectory() as root:
            runtime = os.path.join(root, "runtime")
            managed = os.path.join(root, "managed")
            journal = os.path.join(managed, "launch-fence.json")
            receipt = os.path.join(managed, "runtime")
            tombstone = os.path.join(root, "sia.lifecycle-removed")
            for name in MODERN_V3_RUNTIME_NAMES:
                _write(os.path.join(runtime, name), name + "\n", 0o644)
            digest = _runtime_digest(runtime)
            _write(
                receipt,
                "managed-by=khephri.sia\nkind=runtime\n"
                f"path={runtime}\nsha256={digest}\n",
                0o600)
            _write(
                journal,
                json.dumps({
                    "schema": "sia-launch-fence-v1",
                    "runtime_before_digest": digest,
                    "runtime_digest": digest,
                    "cli_digest": "",
                    "entries": [],
                }, sort_keys=True, separators=(",", ":")) + "\n",
                0o600)
            _write(tombstone, "removed-by=khephri.sia\n", 0o600)
            script = function + r'''
set -u
LAUNCH_FENCE_JOURNAL="$TEST_JOURNAL"
LIFECYCLE_TOMBSTONE="$TEST_TOMBSTONE"
RUNTIME_RECEIPT="$TEST_RECEIPT"
RUNTIME_BIN_DIR="$TEST_RUNTIME"
fenced_runtime_authorized
'''
            environment = os.environ.copy()
            environment.update({
                "TEST_JOURNAL": journal,
                "TEST_TOMBSTONE": tombstone,
                "TEST_RECEIPT": receipt,
                "TEST_RUNTIME": runtime,
            })

            def authorize():
                return subprocess.run(
                    ["bash", "-c", script], env=environment, text=True,
                    stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                    check=False)

            result = authorize()
            self.assertEqual(result.returncode, 0, result.stderr)
            os.unlink(os.path.join(runtime, "siasenses.py"))
            self.assertNotEqual(authorize().returncode, 0)

    def test_staged_runtime_members_match_the_latest_rung_member_set(self):
        # Two independent hand-maintained lists have to agree and nothing
        # made them: install.sh stages the runtime tree one install(1) line
        # at a time, while the rung ladder decides which members the receipt
        # written straight afterwards actually measures.
        #
        # Staged but not in the ladder: the module is installed into $BINDIR
        # and the publication receipt covering that tree never hashes it, so
        # a later tamper of exactly that file verifies clean.  In the ladder
        # but never staged: runtime_tree_digest refuses on a tree the
        # installer just published, and the install cannot complete.  Both
        # halves are silent at authoring time, so pin them to each other.
        staged = _staged_runtime_members(_read("install.sh"))
        self.assertEqual(
            len(staged), len(set(staged)),
            f"install.sh stages a runtime member more than once: {staged}")
        self.assertNotIn("LATEST_RUNTIME_NAMES", _read("bin/siarelease.py"))
        SIARELEASE.validate_runtime_ladder()
        latest_names = SIARELEASE.RUNTIME_LADDER[0][1]
        missing = sorted(set(latest_names) - set(staged))
        unmeasured = sorted(set(staged) - set(latest_names))
        self.assertEqual(
            (missing, unmeasured), ([], []),
            f"install.sh stages {len(staged)} runtime members but the latest "
            f"rung ladder covers {len(latest_names)}. In the "
            f"ladder yet never staged (digest will refuse): {missing}. "
            f"Staged yet outside the ladder (installed unmeasured by any "
            f"receipt): {unmeasured}")

    def test_v9_runtime_modules_are_in_the_release_source_snapshot(self):
        installer = _read("install.sh")
        release_files = set(shlex.split(installer.split(
            "SIA_RELEASE_FILES=(", 1)[1].split("\n)", 1)[0]))
        expected = {
            "bin/siasourceack.py", "bin/siasourceeffects.py",
            "bin/siasourceengine.py", "bin/siasourcegit.py",
            "bin/siacontrollerepoch.py",
            "bin/siacontrollersourcerunner.py",
        }
        self.assertTrue(expected.issubset(release_files),
                        expected - release_files)

    def test_v12_recall_front_door_is_one_complete_runtime_rung(self):
        additions = (
            "siacontrollerdeliverywriter.py", "siacontrollerrecallprojection.py",
            "siacontrollerrecalloutput.py", "siacontrollerrecallcli.py",
            "siagetrenderadmit.py", "siainstalledengine.py",
            "siainstalledexpectations.py",
        )
        salt, names, selectors = next(
            rung for rung in SIARELEASE.RUNTIME_LADDER
            if rung[0] == b"sia-runtime-v12\0")
        self.assertEqual(salt, b"sia-runtime-v12\0")
        self.assertEqual(selectors, additions)
        self.assertEqual(
            names, SIARELEASE.MODERN_V11_RUNTIME_NAMES + additions)
        staged = _staged_runtime_members(_read("install.sh"))
        self.assertTrue(set(additions).issubset(staged),
                        set(additions) - set(staged))
        installer = _read("install.sh")
        release_files = set(shlex.split(installer.split(
            "SIA_RELEASE_FILES=(", 1)[1].split("\n)", 1)[0]))
        expected = {"bin/" + name for name in additions}
        self.assertTrue(expected.issubset(release_files),
                        expected - release_files)

    def test_runtime_fence_metadata_parser_is_strict_and_named(self):
        with tempfile.TemporaryDirectory() as root:
            runtime = os.path.join(root, "runtime")
            managed = os.path.join(root, "managed")
            journal = os.path.join(managed, "launch-fence.json")
            receipt = os.path.join(managed, "runtime")
            tombstone = os.path.join(root, "sia.lifecycle-removed")
            _plant_runtime_tree(runtime, LEGACY_RUNTIME_NAMES)
            before_digest = _runtime_digest(runtime)
            _write(
                receipt,
                "managed-by=khephri.sia\nkind=runtime\n"
                f"path={runtime}\nsha256={before_digest}\n",
                0o600)
            _write(tombstone, "removed-by=khephri.sia\n", 0o600)
            payload = {
                "schema": "sia-launch-fence-v1",
                "runtime_before_digest": before_digest,
                "runtime_digest": "",
                "cli_digest": "",
                "entries": [{
                    "path": os.path.join(root, "unused-entry"),
                    "device": 0,
                    "inode": 0,
                    "mode": 0,
                    "sha256": "0" * 64,
                }],
            }

            def authorize_raw(raw):
                _write(journal, raw + "\n", 0o600)
                stderr = io.StringIO()
                with mock.patch.object(sys, "stderr", stderr):
                    status = SIARELEASE.main([
                        "runtime-authorize-fence", journal, tombstone,
                        receipt, runtime])
                return status, stderr.getvalue()

            valid_optional_digests = (
                ("", ""),
                (hashlib.sha256(b"published runtime").hexdigest(),
                 hashlib.sha256(b"published cli").hexdigest()),
            )
            for runtime_digest, cli_digest in valid_optional_digests:
                with self.subTest(
                        valid_runtime=runtime_digest, valid_cli=cli_digest):
                    candidate = dict(
                        payload, runtime_digest=runtime_digest,
                        cli_digest=cli_digest)
                    status, stderr = authorize_raw(json.dumps(
                        candidate, sort_keys=True, separators=(",", ":")))
                    self.assertEqual(status, 0, stderr)

            canonical = json.dumps(
                payload, sort_keys=True, separators=(",", ":"))
            ambiguous = {
                "duplicate top-level field": canonical.replace(
                    '"schema":"sia-launch-fence-v1"',
                    '"schema":"discarded",'
                    '"schema":"sia-launch-fence-v1"', 1),
                "duplicate nested field": canonical.replace(
                    '"path":', '"path":"discarded","path":', 1),
                "NaN": canonical.replace(
                    '"cli_digest":""', '"cli_digest":NaN', 1),
                "Infinity": canonical.replace(
                    '"cli_digest":""', '"cli_digest":Infinity', 1),
                "negative Infinity": canonical.replace(
                    '"cli_digest":""', '"cli_digest":-Infinity', 1),
            }
            for case, raw in ambiguous.items():
                with self.subTest(case=case):
                    status, stderr = authorize_raw(raw)
                    self.assertEqual(status, 2)
                    self.assertEqual(
                        stderr,
                        "SIA runtime fence refused: invalid runtime "
                        "launch-fence metadata\n")

            invalid_optional_digests = (
                None, True, [], {}, "A" * 64, "not-a-digest")
            for field in ("runtime_digest", "cli_digest"):
                for value in invalid_optional_digests:
                    with self.subTest(field=field, value=value):
                        candidate = dict(payload)
                        candidate[field] = value
                        status, stderr = authorize_raw(json.dumps(
                            candidate, sort_keys=True,
                            separators=(",", ":")))
                        self.assertEqual(status, 2)
                        self.assertEqual(
                            stderr,
                            "SIA runtime fence refused: invalid runtime "
                            "launch-fence digest\n")

            with mock.patch.object(
                    SIARELEASE.json, "loads",
                    side_effect=RecursionError("deep JSON")):
                status, stderr = authorize_raw(canonical)
            self.assertEqual(status, 2)
            self.assertEqual(
                stderr,
                "SIA runtime fence refused: invalid runtime "
                "launch-fence metadata\n")
            self.assertNotIn("Traceback", stderr)

            class ParserPanic(BaseException):
                pass

            _write(journal, canonical + "\n", 0o600)
            with mock.patch.object(
                    SIARELEASE.json, "loads",
                    side_effect=ParserPanic("native parser panic")):
                with self.assertRaises(ParserPanic):
                    SIARELEASE.authorize_fenced_runtime(
                        journal, tombstone, receipt, runtime)

    def test_runtime_ladder_has_one_authority_and_every_consumer_delegates(
            self):
        authority = _read("bin/siarelease.py")
        installer = _read("install.sh")
        uninstaller = _read("uninstall.sh")

        # A copied declaration can drift even when today's copies agree.
        # Keep every membership, marker, and salt decision in siarelease.
        for relative, source in (("install.sh", installer),
                                 ("uninstall.sh", uninstaller)):
            with self.subTest(relative=relative):
                self.assertNotIn("legacy_names = (", source)
                self.assertNotIn("modern_v6_names =", source)
                self.assertNotIn("sia-runtime-v", source)
        self.assertEqual(authority.count("RUNTIME_LADDER = ("), 1)

        install_digest = installer.split(
            "runtime_tree_digest() {", 1)[1].split(
                "\n}\n\nruntime_receipt_valid", 1)[0]
        uninstall_digest = uninstaller.split(
            "runtime_tree_digest() {", 1)[1].split(
                "\n}\nruntime_receipt_valid", 1)[0]
        uninstall_fence = uninstaller.split(
            "fenced_runtime_authorized() {", 1)[1].split(
                "\n}\n\ncapture_runtime_removal_authority", 1)[0]
        self.assertIn('"$REPO/bin/siarelease.py" runtime-tree-digest',
                      install_digest)
        self.assertIn('"$SIA_RELEASE_AUTHORITY" runtime-tree-digest',
                      uninstall_digest)
        self.assertIn('"$SIA_RELEASE_AUTHORITY" runtime-authorize-fence',
                      uninstall_fence)

    def test_manual_names_the_authoritative_current_runtime_rung(self):
        manual = _read("docs/MANUAL.md")
        current = SIARELEASE.RUNTIME_LADDER[0][0].rstrip(b"\0").decode(
            "ascii")
        self.assertIn(f"current `{current}` member set", manual)
        self.assertIn("`bin/siarelease.py:RUNTIME_LADDER`", manual)

    def test_runtime_ladder_authority_preserves_every_shipped_rung(self):
        authority = SIARELEASE
        for rung, expected_salt, expected_names, expected_digest in \
                RUNTIME_RUNG_FIXTURES:
            with self.subTest(rung=rung), \
                    tempfile.TemporaryDirectory() as runtime:
                _plant_runtime_tree(runtime, expected_names)
                salt, names = authority.runtime_rung(runtime)
                self.assertEqual(salt, expected_salt)
                self.assertEqual(names, expected_names)
                self.assertEqual(
                    authority.runtime_tree_digest(runtime), expected_digest)

    def test_runtime_ladder_schema_refuses_malformed_authority(self):
        ladder = SIARELEASE.RUNTIME_LADDER

        def changed(index, *, salt=None, names=None, selectors=None):
            result = list(ladder)
            old_salt, old_names, old_selectors = result[index]
            result[index] = (
                old_salt if salt is None else salt,
                old_names if names is None else names,
                old_selectors if selectors is None else selectors)
            return tuple(result)

        malformed = {
            "empty": (),
            "duplicate salt": changed(0, salt=ladder[1][0]),
            "duplicate member": changed(
                0, names=ladder[0][1] + (ladder[0][1][0],)),
            "non-cumulative": changed(
                0, names=tuple(
                    name for name in ladder[0][1] if name != "sia-ledger")),
            "selector outside introduction": changed(
                0, selectors=("sia-brainstem",)),
            "nested member": changed(
                0, names=ladder[0][1] + ("nested/member",)),
            "nul member": changed(
                0, names=ladder[0][1] + ("member\0tail",)),
            "nested selector": changed(
                0, selectors=("nested/siathought.py",)),
        }
        for case, candidate in malformed.items():
            with self.subTest(case=case):
                with self.assertRaises(ValueError):
                    SIARELEASE.validate_runtime_ladder(candidate)

        # Validation is part of the executable classification boundary, not
        # an optional test helper a caller can forget to invoke.
        with tempfile.TemporaryDirectory() as runtime, \
                mock.patch.object(SIARELEASE, "RUNTIME_LADDER", ()):
            with self.assertRaises(ValueError):
                SIARELEASE.runtime_rung(runtime)
            with self.assertRaises(ValueError):
                SIARELEASE.runtime_tree_digest(runtime)

    def test_runtime_digest_refuses_member_over_declared_bound(self):
        ladder = ((b"sia-runtime-v1\0", ("member",), ()),)
        with tempfile.TemporaryDirectory() as runtime, \
                mock.patch.object(SIARELEASE, "RUNTIME_LADDER", ladder), \
                mock.patch.object(
                    SIARELEASE, "MAX_RUNTIME_SOURCE_BYTES", 4):
            _write(os.path.join(runtime, "member"), "12345", 0o600)

            with self.assertRaisesRegex(ValueError, "byte bound"):
                SIARELEASE.runtime_tree_digest(runtime)

    def test_runtime_digest_refuses_root_generation_swap(self):
        ladder = ((
            b"sia-runtime-v1\0", ("alpha", "bravo"), ()),)
        with tempfile.TemporaryDirectory() as parent, \
                mock.patch.object(SIARELEASE, "RUNTIME_LADDER", ladder):
            runtime = os.path.join(parent, "runtime")
            replacement = os.path.join(parent, "replacement")
            archive = os.path.join(parent, "archive")
            for root, label in ((runtime, "old"), (replacement, "new")):
                _write(os.path.join(root, "alpha"), label + " alpha", 0o600)
                _write(os.path.join(root, "bravo"), label + " bravo", 0o600)
            original_open = os.open
            swapped = False

            def swap_before_second_member(path, flags, *args, **kwargs):
                nonlocal swapped
                target = os.fspath(path)
                if not swapped and target in {
                        "bravo", os.path.join(runtime, "bravo")}:
                    os.rename(runtime, archive)
                    os.rename(replacement, runtime)
                    swapped = True
                return original_open(path, flags, *args, **kwargs)

            with mock.patch.object(
                    SIARELEASE, "os",
                    _OsShim(open=swap_before_second_member)), \
                    self.assertRaisesRegex(
                        ValueError, "runtime tree changed"):
                SIARELEASE.runtime_tree_digest(runtime)
            self.assertTrue(swapped)

    def test_runtime_digest_revalidates_earlier_members_at_completion(self):
        ladder = ((
            b"sia-runtime-v1\0", ("alpha", "bravo"), ()),)
        with tempfile.TemporaryDirectory() as runtime, \
                mock.patch.object(SIARELEASE, "RUNTIME_LADDER", ladder):
            alpha = os.path.join(runtime, "alpha")
            _write(alpha, "old alpha", 0o600)
            _write(os.path.join(runtime, "bravo"), "stable bravo", 0o600)
            original_open = os.open
            changed = False

            def change_first_before_second_open(
                    path, flags, *args, **kwargs):
                nonlocal changed
                if not changed and os.fspath(path) == "bravo":
                    _write(alpha, "new alpha", 0o600)
                    changed = True
                return original_open(path, flags, *args, **kwargs)

            with mock.patch.object(
                    SIARELEASE, "os",
                    _OsShim(open=change_first_before_second_open)), \
                    self.assertRaisesRegex(
                        ValueError, "runtime member changed"):
                SIARELEASE.runtime_tree_digest(runtime)
            self.assertTrue(changed)

    def test_fenced_runtime_refuses_member_over_declared_bound(self):
        ladder = ((b"sia-runtime-v1\0", ("member",), ()),)
        with tempfile.TemporaryDirectory() as root, \
                mock.patch.object(SIARELEASE, "RUNTIME_LADDER", ladder):
            runtime = os.path.join(root, "runtime")
            managed = os.path.join(root, "managed")
            journal = os.path.join(managed, "launch-fence.json")
            receipt = os.path.join(managed, "runtime")
            tombstone = os.path.join(root, "sia.lifecycle-removed")
            _write(os.path.join(runtime, "member"), "12345", 0o600)
            before_digest = SIARELEASE.runtime_tree_digest(runtime)
            _write(
                receipt,
                "managed-by=khephri.sia\nkind=runtime\n"
                f"path={runtime}\nsha256={before_digest}\n",
                0o600)
            _write(
                journal,
                json.dumps({
                    "schema": "sia-launch-fence-v1",
                    "runtime_before_digest": before_digest,
                    "runtime_digest": "",
                    "cli_digest": "",
                    "entries": [],
                }, sort_keys=True, separators=(",", ":")) + "\n",
                0o600)
            _write(tombstone, "removed-by=khephri.sia\n", 0o600)

            with mock.patch.object(
                    SIARELEASE, "MAX_RUNTIME_SOURCE_BYTES", 4), \
                    self.assertRaisesRegex(ValueError, "byte bound"):
                SIARELEASE.authorize_fenced_runtime(
                    journal, tombstone, receipt, runtime)

    def test_fenced_runtime_accepts_stable_attested_mode_zero_member(self):
        ladder = ((b"sia-runtime-v1\0", ("member",), ()),)
        with tempfile.TemporaryDirectory() as root, \
                mock.patch.object(SIARELEASE, "RUNTIME_LADDER", ladder):
            runtime = os.path.join(root, "runtime")
            managed = os.path.join(root, "managed")
            member = os.path.join(runtime, "member")
            journal = os.path.join(managed, "launch-fence.json")
            receipt = os.path.join(managed, "runtime")
            tombstone = os.path.join(root, "sia.lifecycle-removed")
            _write(member, "fenced member", 0o600)
            before_digest = SIARELEASE.runtime_tree_digest(runtime)
            info = os.lstat(member)
            with open(member, "rb") as stream:
                member_digest = hashlib.sha256(stream.read()).hexdigest()
            os.chmod(member, 0)
            _write(
                receipt,
                "managed-by=khephri.sia\nkind=runtime\n"
                f"path={runtime}\nsha256={before_digest}\n",
                0o600)
            _write(
                journal,
                json.dumps({
                    "schema": "sia-launch-fence-v1",
                    "runtime_before_digest": before_digest,
                    "runtime_digest": "",
                    "cli_digest": "",
                    "entries": [{
                        "path": member,
                        "device": info.st_dev,
                        "inode": info.st_ino,
                        "mode": stat.S_IMODE(info.st_mode),
                        "sha256": member_digest,
                    }],
                }, sort_keys=True, separators=(",", ":")) + "\n",
                0o600)
            _write(tombstone, "removed-by=khephri.sia\n", 0o600)

            self.assertEqual(
                SIARELEASE.authorize_fenced_runtime(
                    journal, tombstone, receipt, runtime),
                before_digest)

    def test_fenced_runtime_closes_mode_zero_fd_when_inspection_fails(self):
        if not getattr(SIARELEASE.os, "O_PATH", 0):
            return
        ladder = ((b"sia-runtime-v1\0", ("member",), ()),)
        with tempfile.TemporaryDirectory() as runtime, \
                mock.patch.object(SIARELEASE, "RUNTIME_LADDER", ladder):
            member = os.path.join(runtime, "member")
            _write(member, "fenced member", 0o600)
            info = os.lstat(member)
            os.chmod(member, 0)
            entries = {member: {
                "device": info.st_dev,
                "inode": info.st_ino,
                "sha256": "0" * 64,
            }}
            original_open = os.open
            original_fstat = os.fstat
            member_descriptor = None

            def capture_member_descriptor(path, flags, *args, **kwargs):
                nonlocal member_descriptor
                descriptor = original_open(path, flags, *args, **kwargs)
                if os.fspath(path) == "member":
                    member_descriptor = descriptor
                return descriptor

            def refuse_member_fstat(descriptor):
                if descriptor == member_descriptor:
                    raise OSError("synthetic member fstat refusal")
                return original_fstat(descriptor)

            with mock.patch.object(
                    SIARELEASE, "os", _OsShim(
                        open=capture_member_descriptor,
                        fstat=refuse_member_fstat)), \
                    self.assertRaisesRegex(
                        OSError, "synthetic member fstat refusal"):
                SIARELEASE._measure_runtime_tree(runtime, entries)
            self.assertIsNotNone(member_descriptor)
            with self.assertRaises(OSError):
                original_fstat(member_descriptor)

    def test_fenced_runtime_refuses_root_generation_swap(self):
        ladder = ((
            b"sia-runtime-v1\0", ("alpha", "bravo"), ()),)
        with tempfile.TemporaryDirectory() as root, \
                mock.patch.object(SIARELEASE, "RUNTIME_LADDER", ladder):
            runtime = os.path.join(root, "runtime")
            replacement = os.path.join(root, "replacement")
            archive = os.path.join(root, "archive")
            managed = os.path.join(root, "managed")
            journal = os.path.join(managed, "launch-fence.json")
            receipt = os.path.join(managed, "runtime")
            tombstone = os.path.join(root, "sia.lifecycle-removed")
            for tree in (runtime, replacement):
                _write(os.path.join(tree, "alpha"), "same alpha", 0o600)
                _write(os.path.join(tree, "bravo"), "same bravo", 0o600)
            before_digest = SIARELEASE.runtime_tree_digest(runtime)
            _write(
                receipt,
                "managed-by=khephri.sia\nkind=runtime\n"
                f"path={runtime}\nsha256={before_digest}\n",
                0o600)
            _write(
                journal,
                json.dumps({
                    "schema": "sia-launch-fence-v1",
                    "runtime_before_digest": before_digest,
                    "runtime_digest": "",
                    "cli_digest": "",
                    "entries": [],
                }, sort_keys=True, separators=(",", ":")) + "\n",
                0o600)
            _write(tombstone, "removed-by=khephri.sia\n", 0o600)
            original_open = os.open
            swapped = False

            def swap_before_second_member(path, flags, *args, **kwargs):
                nonlocal swapped
                target = os.fspath(path)
                if not swapped and target in {
                        "bravo", os.path.join(runtime, "bravo")}:
                    os.rename(runtime, archive)
                    os.rename(replacement, runtime)
                    swapped = True
                return original_open(path, flags, *args, **kwargs)

            with mock.patch.object(
                    SIARELEASE, "os",
                    _OsShim(open=swap_before_second_member)), \
                    self.assertRaisesRegex(
                        ValueError, "runtime tree changed"):
                SIARELEASE.authorize_fenced_runtime(
                    journal, tombstone, receipt, runtime)
            self.assertTrue(swapped)

    def test_a_partial_tree_classifies_by_its_marker_not_completeness(self):
        # Marker presence selects the newest applicable contract even when a
        # required older member is absent.  Digesting must refuse that partial
        # newer tree; it must not fall back to an older receipt.
        with tempfile.TemporaryDirectory() as root:
            runtime = os.path.join(root, "bin")
            _plant_runtime_tree(runtime, MODERN_V4_RUNTIME_NAMES)
            salt, names = SIARELEASE.runtime_rung(runtime)
            self.assertEqual(salt, b"sia-runtime-v4\0")
            self.assertEqual(names, MODERN_V4_RUNTIME_NAMES)

            _write(os.path.join(runtime, "siagraph.py"), "siagraph.py\n",
                   0o644)
            for name in ("siacapsule.py", "siarestoreadmit.py",
                         "sia-continuity-worker", "siasenses.py"):
                os.unlink(os.path.join(runtime, name))
            salt, names = SIARELEASE.runtime_rung(runtime)
            self.assertEqual(salt, b"sia-runtime-v5\0")
            self.assertEqual(names, MODERN_V5_RUNTIME_NAMES)
            self.assertIn("siacapsule.py", names)
            self.assertRaises(FileNotFoundError, _runtime_digest, runtime)

            _write(
                os.path.join(runtime, "siathought.py"), "siathought.py\n",
                0o644)
            salt, names = SIARELEASE.runtime_rung(runtime)
            self.assertEqual(salt, b"sia-runtime-v6\0")
            self.assertEqual(names, MODERN_V6_RUNTIME_NAMES)
            self.assertIn("siagraph.py", names)
            self.assertRaises(FileNotFoundError, _runtime_digest, runtime)

            _plant_runtime_tree(runtime, MODERN_V7_RUNTIME_NAMES)
            for selector in (
                    "siasourceack.py", "siasourceeffects.py",
                    "siasourceengine.py", "siasourcegit.py"):
                with self.subTest(v8_selector=selector):
                    _write(os.path.join(runtime, selector), selector + "\n",
                           0o644)
                    salt, names = SIARELEASE.runtime_rung(runtime)
                    self.assertEqual(salt, b"sia-runtime-v8\0")
                    self.assertEqual(names, MODERN_V8_RUNTIME_NAMES)
                    self.assertRaises(
                        FileNotFoundError, _runtime_digest, runtime)
                    os.unlink(os.path.join(runtime, selector))

            _plant_runtime_tree(runtime, MODERN_V8_RUNTIME_NAMES)
            for selector in (
                    "siacontrollerepoch.py",
                    "siacontrollersourcerunner.py"):
                with self.subTest(v9_selector=selector):
                    _write(os.path.join(runtime, selector), selector + "\n",
                           0o644)
                    salt, names = SIARELEASE.runtime_rung(runtime)
                    self.assertEqual(salt, b"sia-runtime-v9\0")
                    self.assertEqual(names, MODERN_V9_RUNTIME_NAMES)
                    self.assertRaises(
                        FileNotFoundError, _runtime_digest, runtime)
                    os.unlink(os.path.join(runtime, selector))

    def test_runtime_v5_digest_migrates_without_replacing_valid_v4_tree(self):
        installer = _read("install.sh")
        digest_function = _runtime_tree_digest_shell(installer)
        receipt_function = "runtime_receipt_valid() {" + installer.split(
            "runtime_receipt_valid() {", 1)[1].split(
                "\n}\n\nfenced_managed_file_authorized", 1)[0] + "\n}\n"
        preflight_function = "preflight_runtime() {" + installer.split(
            "preflight_runtime() {", 1)[1].split(
                "\n}\n\nrecover_publication_receipts_from_fence", 1)[0] \
            + "\n}\n"
        functions = digest_function + receipt_function + preflight_function
        with tempfile.TemporaryDirectory() as root:
            share = os.path.join(root, "share")
            runtime = os.path.join(share, "bin")
            receipt = os.path.join(root, "managed", "runtime")
            graph = os.path.join(runtime, "siagraph.py")
            member = os.path.join(runtime, "siarestoreadmit.py")
            _plant_runtime_tree(runtime, MODERN_V4_RUNTIME_NAMES)

            def write_receipt():
                _write(
                    receipt,
                    "managed-by=khephri.sia\nkind=runtime\n"
                    f"path={runtime}\nsha256={_runtime_digest(runtime)}\n",
                    0o600)

            script = functions + r'''
set -u
SHARE="$TEST_SHARE"
BINDIR="$TEST_RUNTIME"
RUNTIME_RECEIPT="$TEST_RECEIPT"
SIA_REPLACE_RUNTIME=0
SIA_RUNTIME_TREE_EXPECTED=
owned_tree_cas() { [ "$1" = recover ]; }
owned_tree_generation() { printf '%s\n' stable-runtime-generation; }
fenced_runtime_authorized() { return 1; }
owned_metadata() {
  local kind="$1" receipt="$2" path="$3" digest="$4" expected
  [ "$kind" = runtime ] || return 1
  expected="$(printf \
    'managed-by=khephri.sia\nkind=runtime\npath=%s\nsha256=%s\n' \
    "$path" "$digest")"
  [ "$(cat -- "$receipt")" = "$expected" ]
}
preflight_runtime
'''
            environment = os.environ.copy()
            environment.update({
                "TEST_SHARE": share,
                "TEST_RUNTIME": runtime,
                "TEST_RECEIPT": receipt,
            })

            def preflight():
                return subprocess.run(
                    ["bash", "-c", script], env=environment, text=True,
                    stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                    check=False)

            # A receipt from the currently published modern-v4 runtime stays
            # valid, so its normal upgrade path never requires replacement.
            write_receipt()
            self.assertEqual(preflight().returncode, 0)
            v4_receipt = _read_path(receipt)

            # siagraph.py moves the membership rung. It cannot be smuggled
            # into a v4 receipt, and the v5 receipt then validates.
            _write(graph, "siagraph.py\n", 0o644)
            self.assertNotEqual(preflight().returncode, 0)
            write_receipt()
            self.assertEqual(preflight().returncode, 0)
            v5_receipt = _read_path(receipt)
            self.assertNotEqual(v4_receipt, v5_receipt)

            # A genuinely partial v5 tree authorizes nothing: not the v5
            # receipt it was cut from, and not the older complete v4 receipt
            # it would have to fall back to.
            os.unlink(member)
            self.assertNotEqual(preflight().returncode, 0)
            _write(receipt, v4_receipt, 0o600)
            self.assertNotEqual(preflight().returncode, 0)

            # The v4 receipt is not poisoned; it authorizes the complete v4
            # tree again. The refusal above was the partial tree, nothing
            # else.
            _write(member, "siarestoreadmit.py\n", 0o644)
            os.unlink(graph)
            self.assertEqual(preflight().returncode, 0)

    def test_uninstaller_fence_requires_complete_v6_runtime(self):
        function = _uninstaller_fenced_runtime_shell(_read("uninstall.sh"))
        with tempfile.TemporaryDirectory() as root:
            runtime = os.path.join(root, "runtime")
            managed = os.path.join(root, "managed")
            journal = os.path.join(managed, "launch-fence.json")
            receipt = os.path.join(managed, "runtime")
            tombstone = os.path.join(root, "sia.lifecycle-removed")
            marker = os.path.join(runtime, "siathought.py")
            member = os.path.join(runtime, "siarestoreadmit.py")
            _plant_runtime_tree(runtime, MODERN_V6_RUNTIME_NAMES)
            _write(tombstone, "removed-by=khephri.sia\n", 0o600)

            def publish_fence():
                digest = _runtime_digest(runtime)
                _write(
                    receipt,
                    "managed-by=khephri.sia\nkind=runtime\n"
                    f"path={runtime}\nsha256={digest}\n",
                    0o600)
                _write(
                    journal,
                    json.dumps({
                        "schema": "sia-launch-fence-v1",
                        "runtime_before_digest": digest,
                        "runtime_digest": digest,
                        "cli_digest": "",
                        "entries": [],
                    }, sort_keys=True, separators=(",", ":")) + "\n",
                    0o600)

            script = function + r'''
set -u
LAUNCH_FENCE_JOURNAL="$TEST_JOURNAL"
LIFECYCLE_TOMBSTONE="$TEST_TOMBSTONE"
RUNTIME_RECEIPT="$TEST_RECEIPT"
RUNTIME_BIN_DIR="$TEST_RUNTIME"
fenced_runtime_authorized
'''
            environment = os.environ.copy()
            environment.update({
                "TEST_JOURNAL": journal,
                "TEST_TOMBSTONE": tombstone,
                "TEST_RECEIPT": receipt,
                "TEST_RUNTIME": runtime,
            })

            def authorize():
                return subprocess.run(
                    ["bash", "-c", script], env=environment, text=True,
                    stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                    check=False)

            publish_fence()
            self.assertEqual(authorize().returncode, 0)

            # Dropping the rung marker is a rollback, not a shorter v6 tree.
            os.unlink(marker)
            self.assertNotEqual(authorize().returncode, 0)
            _write(marker, "siathought.py\n", 0o644)
            self.assertEqual(authorize().returncode, 0)

            # A fence cut from the complete v5 tree never authorizes the v6
            # tree that grew out of it.
            os.unlink(marker)
            publish_fence()
            self.assertEqual(authorize().returncode, 0)
            _write(marker, "siathought.py\n", 0o644)
            self.assertNotEqual(authorize().returncode, 0)

            # A partial v6 tree authorizes against neither rung's fence.
            os.unlink(member)
            self.assertNotEqual(authorize().returncode, 0)
            _write(marker, "siathought.py\n", 0o644)
            _write(member, "siarestoreadmit.py\n", 0o644)
            publish_fence()
            os.unlink(member)
            self.assertNotEqual(authorize().returncode, 0)

    def test_runtime_digest_consumers_agree_across_v4_through_v9(self):
        # Both normal shell consumers delegate to the authority and the
        # uninstaller's fenced path must accept exactly the same receipt
        # bytes, including the current top rung.
        installer_digest = _runtime_tree_digest_shell(_read("install.sh"))
        uninstaller_digest = _runtime_tree_digest_shell(_read("uninstall.sh"))
        fence = _uninstaller_fenced_runtime_shell(_read("uninstall.sh"))
        with tempfile.TemporaryDirectory() as root:
            runtime = os.path.join(root, "runtime")
            managed = os.path.join(root, "managed")
            journal = os.path.join(managed, "launch-fence.json")
            receipt = os.path.join(managed, "runtime")
            tombstone = os.path.join(root, "sia.lifecycle-removed")
            graph = os.path.join(runtime, "siagraph.py")
            thought = os.path.join(runtime, "siathought.py")
            member = os.path.join(runtime, "siarestoreadmit.py")
            _plant_runtime_tree(runtime, MODERN_V4_RUNTIME_NAMES)
            _write(tombstone, "removed-by=khephri.sia\n", 0o600)
            fence_script = fence + r'''
set -u
LAUNCH_FENCE_JOURNAL="$TEST_JOURNAL"
LIFECYCLE_TOMBSTONE="$TEST_TOMBSTONE"
RUNTIME_RECEIPT="$TEST_RECEIPT"
RUNTIME_BIN_DIR="$TEST_RUNTIME"
fenced_runtime_authorized
'''
            environment = os.environ.copy()
            environment.update({
                "TEST_JOURNAL": journal,
                "TEST_TOMBSTONE": tombstone,
                "TEST_RECEIPT": receipt,
                "TEST_RUNTIME": runtime,
            })

            def shell_digest(function):
                return subprocess.run(
                    ["bash", "-c", function + '\nruntime_tree_digest "$1"\n',
                     "digest-test", runtime], text=True,
                    stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                    check=False)

            def fence_admits(digest):
                _write(
                    receipt,
                    "managed-by=khephri.sia\nkind=runtime\n"
                    f"path={runtime}\nsha256={digest}\n",
                    0o600)
                _write(
                    journal,
                    json.dumps({
                        "schema": "sia-launch-fence-v1",
                        "runtime_before_digest": digest,
                        "runtime_digest": digest,
                        "cli_digest": "",
                        "entries": [],
                    }, sort_keys=True, separators=(",", ":")) + "\n",
                    0o600)
                return subprocess.run(
                    ["bash", "-c", fence_script], env=environment, text=True,
                    stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                    check=False).returncode == 0

            measured = {}
            for rung in ("v4", "v5", "v6", "v7", "v8", "v9"):
                if rung == "v5":
                    _write(graph, "siagraph.py\n", 0o644)
                elif rung == "v6":
                    _write(thought, "siathought.py\n", 0o644)
                elif rung == "v7":
                    _plant_runtime_tree(runtime, MODERN_V7_RUNTIME_NAMES)
                elif rung == "v8":
                    _plant_runtime_tree(runtime, MODERN_V8_RUNTIME_NAMES)
                elif rung == "v9":
                    _plant_runtime_tree(runtime, MODERN_V9_RUNTIME_NAMES)
                mirror = _runtime_digest(runtime)
                measured[rung] = mirror
                for site, result in (
                        ("install.sh", shell_digest(installer_digest)),
                        ("uninstall.sh", shell_digest(uninstaller_digest))):
                    with self.subTest(rung=rung, site=site):
                        self.assertEqual(result.returncode, 0, result.stderr)
                        self.assertEqual(result.stdout.strip(), mirror)
                with self.subTest(rung=rung, site="uninstall.sh fence"):
                    self.assertTrue(fence_admits(mirror))
            self.assertNotEqual(measured["v4"], measured["v5"])
            self.assertNotEqual(measured["v5"], measured["v6"])
            self.assertNotEqual(measured["v6"], measured["v7"])
            self.assertNotEqual(measured["v7"], measured["v8"])
            self.assertNotEqual(measured["v8"], measured["v9"])
            for historical in ("v4", "v5", "v6", "v7", "v8"):
                self.assertFalse(fence_admits(measured[historical]))

            # Every site refuses the partial v9 tree, and none of them falls
            # back to a digest any stored receipt would accept.
            os.unlink(member)
            for site, result in (
                    ("install.sh", shell_digest(installer_digest)),
                    ("uninstall.sh", shell_digest(uninstaller_digest))):
                with self.subTest(site=site):
                    self.assertNotEqual(result.returncode, 0)
                    for prior in measured.values():
                        self.assertNotIn(prior, result.stdout)
            self.assertRaises(FileNotFoundError, _runtime_digest, runtime)
            for prior in measured.values():
                self.assertFalse(fence_admits(prior))

    def test_fenced_runtime_authorization_requires_exact_journal_and_tombstone(
            self):
        function = _fenced_runtime_authorization_shell(_read("install.sh"))
        with tempfile.TemporaryDirectory() as root:
            runtime = os.path.join(root, "runtime")
            managed = os.path.join(root, "managed")
            journal = os.path.join(managed, "launch-fence.json")
            receipt = os.path.join(managed, "runtime")
            tombstone = os.path.join(root, "sia.lifecycle-removed")
            entries = []
            for name in ("sia-brainstem", "sia-mcp"):
                path = os.path.join(runtime, name)
                _write(path, name + "\n", 0o755)
                current = os.lstat(path)
                with open(path, "rb") as stream:
                    digest = hashlib.sha256(stream.read()).hexdigest()
                entries.append({
                    "path": path,
                    "device": current.st_dev,
                    "inode": current.st_ino,
                    "mode": stat.S_IMODE(current.st_mode),
                    "sha256": digest,
                })
                os.chmod(path, 0)
            before_digest = hashlib.sha256(b"prior runtime").hexdigest()
            payload = {
                "schema": "sia-launch-fence-v1",
                "runtime_before_digest": before_digest,
                "runtime_digest": "",
                "cli_digest": "",
                "entries": entries,
            }
            _write(
                receipt,
                "managed-by=khephri.sia\nkind=runtime\n"
                f"path={runtime}\nsha256={before_digest}\n",
                0o600)
            _write(tombstone, "removed-by=khephri.sia\n", 0o600)

            script = function + r'''
set -u
LAUNCH_FENCE_JOURNAL="$JOURNAL"
LIFECYCLE_TOMBSTONE="$TOMBSTONE"
RUNTIME_RECEIPT="$RECEIPT"
BINDIR="$RUNTIME"
fenced_runtime_authorized
'''
            environment = os.environ.copy()
            environment.update({
                "JOURNAL": journal,
                "TOMBSTONE": tombstone,
                "RECEIPT": receipt,
                "RUNTIME": runtime,
            })

            def authorize(candidate, marker="regular"):
                _write(
                    journal,
                    json.dumps(candidate, sort_keys=True,
                               separators=(",", ":")) + "\n",
                    0o600)
                if os.path.lexists(tombstone):
                    os.unlink(tombstone)
                if marker == "regular":
                    _write(tombstone, "removed-by=khephri.sia\n", 0o600)
                elif marker == "symlink":
                    os.symlink(receipt, tombstone)
                return subprocess.run(
                    ["bash", "-c", script], env=environment, text=True,
                    stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                    check=False)

            result = authorize(payload)
            self.assertEqual(result.returncode, 0, result.stderr)

            unexpected = json.loads(json.dumps(payload))
            unexpected["unexpected"] = "field"
            self.assertNotEqual(authorize(unexpected).returncode, 0)

            malformed = json.loads(json.dumps(payload))
            malformed["entries"][0]["device"] = True
            self.assertNotEqual(authorize(malformed).returncode, 0)

            duplicate = json.loads(json.dumps(payload))
            duplicate["entries"].append(dict(duplicate["entries"][0]))
            self.assertNotEqual(authorize(duplicate).returncode, 0)

            self.assertNotEqual(authorize(payload, marker="absent").returncode,
                                0)
            self.assertNotEqual(authorize(payload, marker="symlink").returncode,
                                0)

    def test_retry_does_not_retain_an_already_fenced_cli_twice(self):
        installer = _read("install.sh")
        fenced_body = installer.split(
            "fenced_managed_file_authorized() {", 1)[1].split(
                "\n}\n\nfenced_runtime_authorized", 1)[0]
        retain_body = installer.split(
            "retain_unowned_cli_before_fence() {", 1)[1].split(
                "\n}\n\ninstall_preflighted_cli", 1)[0]
        functions = (
            "fenced_managed_file_authorized() {" + fenced_body + "\n}\n" +
            "retain_unowned_cli_before_fence() {" + retain_body + "\n}\n")

        with tempfile.TemporaryDirectory() as root:
            home = os.path.join(root, "home")
            cli = os.path.join(home, ".local/bin/sia")
            managed = os.path.join(
                home, ".local/state/sia/managed-install")
            journal = os.path.join(managed, "launch-fence.json")
            tombstone = os.path.join(
                home, ".local/state/sia.lifecycle-removed")
            trace = os.path.join(root, "unexpected-copy")
            _write(cli, "already retained before fence\n", 0o755)
            with open(cli, "rb") as stream:
                digest = hashlib.sha256(stream.read()).hexdigest()
            before = os.lstat(cli)
            os.chmod(cli, 0)
            payload = {
                "schema": "sia-launch-fence-v1",
                "runtime_before_digest": "",
                "runtime_digest": "",
                "cli_digest": hashlib.sha256(
                    b"desired replacement\n").hexdigest(),
                "entries": [{
                    "path": cli,
                    "device": before.st_dev,
                    "inode": before.st_ino,
                    "mode": stat.S_IMODE(before.st_mode),
                    "sha256": digest,
                }],
            }
            _write(journal, json.dumps(
                payload, sort_keys=True, separators=(",", ":")) + "\n",
                0o600)
            _write(tombstone, "removed-by=khephri.sia\n", 0o600)
            script = functions + r'''
set -u
LAUNCH_FENCE_JOURNAL="$JOURNAL"
LIFECYCLE_TOMBSTONE="$TOMBSTONE"
CLI_PATH="$TEST_CLI"
CLI_RECEIPT="$MANAGED/sia-cli.receipt"
SIA_STABLE_LAUNCHER="$WORK/desired"
SIA_REPLACE_SIA_CLI=1
managed_receipt_matches() { return 1; }
owned_metadata() { return 1; }
cp() { printf '%s\n' called > "$TRACE"; return 97; }
retain_unowned_cli_before_fence
'''
            environment = os.environ.copy()
            environment.update({
                "HOME": home,
                "JOURNAL": journal,
                "TOMBSTONE": tombstone,
                "TEST_CLI": cli,
                "MANAGED": managed,
                "WORK": root,
                "TRACE": trace,
            })
            result = subprocess.run(
                ["bash", "-c", script], env=environment, text=True,
                stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertFalse(os.path.lexists(trace))
            self.assertEqual(stat.S_IMODE(os.lstat(cli).st_mode), 0)
            self.assertFalse([
                name for name in os.listdir(os.path.dirname(cli))
                if name.startswith(".sia-cli.previous.")])

    def test_inherited_lifecycle_handoff_preserves_tombstone_and_nesting(self):
        cli = _load("sia_lifecycle_valid", os.path.join(REPO, "bin/sia"))
        library = _load(
            "sialib_lifecycle_valid", os.path.join(REPO, "bin/sialib.py"))
        with tempfile.TemporaryDirectory() as home:
            state = os.path.join(home, ".local/state")
            os.makedirs(state)
            lock = os.path.join(state, "sia.lifecycle.lock")
            tombstone = os.path.join(state, "sia.lifecycle-removed")
            _write(tombstone, "removed-by=khephri.sia\n", 0o600)
            descriptor = os.open(lock, os.O_RDWR | os.O_CREAT, 0o600)
            try:
                fcntl.flock(descriptor, fcntl.LOCK_EX | fcntl.LOCK_NB)
                child_environment = os.environ.copy()
                child_environment["SIA_INHERITED_LIFECYCLE_FD"] = str(
                    descriptor)
                child_code = (
                    "import importlib.machinery, importlib.util, sys\n"
                    "loader = importlib.machinery.SourceFileLoader("
                    "'sia_handoff_child', sys.argv[1])\n"
                    "spec = importlib.util.spec_from_loader("
                    "'sia_handoff_child', loader)\n"
                    "module = importlib.util.module_from_spec(spec)\n"
                    "loader.exec_module(module)\n"
                    "with module._runtime_generation_lease(sys.argv[2]):\n"
                    "    print('inherited-exclusive-handoff')\n")
                child = subprocess.run(
                    [sys.executable, "-c", child_code,
                     os.path.join(REPO, "bin/sia"), home],
                    env=child_environment, pass_fds=(descriptor,), text=True,
                    stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                    check=False)
                self.assertEqual(child.returncode, 0, child.stderr)
                self.assertEqual(
                    child.stdout.strip(), "inherited-exclusive-handoff")
                with mock.patch.dict(
                        os.environ,
                        {"SIA_INHERITED_LIFECYCLE_FD": str(descriptor)}), \
                        mock.patch.object(library, "LIFECYCLE_LOCK", lock), \
                        mock.patch.object(
                            library, "LIFECYCLE_TOMBSTONE", tombstone):
                    with cli._runtime_generation_lease(home):
                        with library._lifecycle_reader():
                            with library._lifecycle_reader():
                                self.assertTrue(os.path.isfile(tombstone))
                    with self.assertRaisesRegex(RuntimeError, "first-light"):
                        with cli._runtime_generation_lease(home):
                            raise RuntimeError("first-light crash")
                self.assertEqual(
                    _read_path(tombstone), "removed-by=khephri.sia\n")
                probe = os.open(lock, os.O_RDWR)
                try:
                    with self.assertRaises(BlockingIOError):
                        fcntl.flock(probe, fcntl.LOCK_SH | fcntl.LOCK_NB)
                finally:
                    os.close(probe)
            finally:
                fcntl.flock(descriptor, fcntl.LOCK_UN)
                os.close(descriptor)

    def test_inherited_lifecycle_handoff_rejects_spoof_and_shared_lock(self):
        cli = _load("sia_lifecycle_spoof", os.path.join(REPO, "bin/sia"))
        library = _load(
            "sialib_lifecycle_spoof", os.path.join(REPO, "bin/sialib.py"))
        with tempfile.TemporaryDirectory() as home:
            state = os.path.join(home, ".local/state")
            os.makedirs(state)
            lock = os.path.join(state, "sia.lifecycle.lock")
            owner = os.open(lock, os.O_RDWR | os.O_CREAT, 0o600)
            spoof = os.open(lock, os.O_RDWR)
            try:
                fcntl.flock(owner, fcntl.LOCK_EX | fcntl.LOCK_NB)
                with mock.patch.dict(
                        os.environ,
                        {"SIA_INHERITED_LIFECYCLE_FD": str(spoof)}), \
                        mock.patch.object(library, "LIFECYCLE_LOCK", lock):
                    with self.assertRaisesRegex(
                            RuntimeError, "does not own the lease"):
                        cli._validated_inherited_lifecycle_fd(lock)
                    with self.assertRaisesRegex(
                            RuntimeError, "does not own the lease"):
                        library._validated_inherited_lifecycle_fd()

                fcntl.flock(owner, fcntl.LOCK_UN)
                fcntl.flock(spoof, fcntl.LOCK_SH | fcntl.LOCK_NB)
                with mock.patch.dict(
                        os.environ,
                        {"SIA_INHERITED_LIFECYCLE_FD": str(spoof)}), \
                        mock.patch.object(library, "LIFECYCLE_LOCK", lock):
                    with self.assertRaisesRegex(
                            RuntimeError, "not exclusively held"):
                        cli._validated_inherited_lifecycle_fd(lock)
                    with self.assertRaisesRegex(
                            RuntimeError, "not exclusively held"):
                        library._validated_inherited_lifecycle_fd()
                shared_probe = os.open(lock, os.O_RDWR)
                try:
                    fcntl.flock(
                        shared_probe, fcntl.LOCK_SH | fcntl.LOCK_NB)
                    fcntl.flock(shared_probe, fcntl.LOCK_UN)
                finally:
                    os.close(shared_probe)

                fcntl.flock(spoof, fcntl.LOCK_UN)
                with mock.patch.dict(
                        os.environ,
                        {"SIA_INHERITED_LIFECYCLE_FD": str(spoof)}):
                    with self.assertRaisesRegex(
                            RuntimeError, "no conflicting lease"):
                        cli._validated_inherited_lifecycle_fd(lock)
            finally:
                fcntl.flock(owner, fcntl.LOCK_UN)
                os.close(spoof)
                os.close(owner)

    def test_inherited_corpus_handoff_requires_the_exclusive_owner(self):
        library = _load(
            "sialib_corpus_handoff", os.path.join(REPO, "bin/sialib.py"))
        with tempfile.TemporaryDirectory() as home:
            state = os.path.join(home, ".local/state/sia")
            os.makedirs(state)
            lock = os.path.join(state, "corpus-owner.lock")
            owner = os.open(lock, os.O_RDWR | os.O_CREAT, 0o600)
            spoof = os.open(lock, os.O_RDWR)
            try:
                fcntl.flock(owner, fcntl.LOCK_EX | fcntl.LOCK_NB)
                with mock.patch.dict(
                        os.environ,
                        {"SIA_INHERITED_CORPUS_FD": str(owner)}), \
                        mock.patch.object(
                            library, "CORPUS_OWNER_LOCK", lock):
                    with library.corpus_owner():
                        with library.corpus_owner():
                            self.assertEqual(
                                library._CORPUS_OWNER_DEPTH.get(), 2)
                    probe = os.open(lock, os.O_RDWR)
                    try:
                        with self.assertRaises(BlockingIOError):
                            fcntl.flock(
                                probe, fcntl.LOCK_SH | fcntl.LOCK_NB)
                    finally:
                        os.close(probe)

                with mock.patch.dict(
                        os.environ,
                        {"SIA_INHERITED_CORPUS_FD": str(spoof)}), \
                        mock.patch.object(
                            library, "CORPUS_OWNER_LOCK", lock):
                    with self.assertRaisesRegex(
                            RuntimeError, "does not own the lease"):
                        with library.corpus_owner():
                            pass

                fcntl.flock(owner, fcntl.LOCK_UN)
                fcntl.flock(spoof, fcntl.LOCK_SH | fcntl.LOCK_NB)
                with mock.patch.dict(
                        os.environ,
                        {"SIA_INHERITED_CORPUS_FD": str(spoof)}), \
                        mock.patch.object(
                            library, "CORPUS_OWNER_LOCK", lock):
                    with self.assertRaisesRegex(
                            RuntimeError, "not exclusively held"):
                        with library.corpus_owner():
                            pass
            finally:
                fcntl.flock(owner, fcntl.LOCK_UN)
                os.close(spoof)
                os.close(owner)

    def test_stable_launcher_holds_generation_lease_across_exec(self):
        with tempfile.TemporaryDirectory() as home:
            runtime = os.path.join(home, ".local/share/sia/bin")
            launcher = os.path.join(home, ".local/bin/sia")
            target = os.path.join(runtime, "sia-cli")
            _generate_stable_launcher(launcher)
            _write(
                target,
                "import time\nprint('target-ready', flush=True)\n"
                "time.sleep(2)\n",
                0o644)
            environment = os.environ.copy()
            environment["HOME"] = home
            process = subprocess.Popen(
                [launcher], env=environment, text=True,
                stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            try:
                self.assertEqual(process.stdout.readline().strip(),
                                 "target-ready")
                lock = os.path.join(home, ".local/state/sia.lifecycle.lock")
                probe = os.open(lock, os.O_RDWR)
                try:
                    with self.assertRaises(BlockingIOError):
                        fcntl.flock(probe, fcntl.LOCK_EX | fcntl.LOCK_NB)
                finally:
                    os.close(probe)
            finally:
                process.terminate()
                process.communicate(timeout=2)

            _write(target, _read("bin/sia"), 0o644)
            for name in ("sialib.py", "siagraph.py", "siathought.py", "siasenses.py",
                         "siarestoreadmit.py", "siacorpuslease.py", "siaprocess.py",
                         "sianotes.py", "siamind.py", "siatakes.py", "siaqueue.py"):
                _write(os.path.join(runtime, name), _read("bin/" + name),
                       0o644)
            result = subprocess.run(
                [launcher, "status"], env=environment, text=True,
                stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
            self.assertEqual(result.returncode, 1, result.stderr)
            self.assertIn("SIA has no status yet", result.stdout)
            self.assertNotIn("stable-launcher handoff", result.stderr)

            tombstone = os.path.join(
                home, ".local/state/sia.lifecycle-removed")
            _write(tombstone, "removed-by=khephri.sia\n", 0o600)
            removed = subprocess.run(
                [launcher, "status"], env=environment, text=True,
                stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
            self.assertNotEqual(removed.returncode, 0)
            self.assertIn("runtime was removed", removed.stderr)

    def test_stable_launcher_handoff_rejects_unlocked_and_wrong_target_fds(self):
        cli = _load("sia_launcher_spoof", os.path.join(REPO, "bin/sia"))
        with tempfile.TemporaryDirectory() as root:
            lock = os.path.join(root, "lifecycle.lock")
            wrong = os.path.join(root, "wrong-target")
            _write(wrong, "wrong\n", 0o600)
            lifecycle_fd = os.open(lock, os.O_RDWR | os.O_CREAT, 0o600)
            target_fd = os.open(os.path.join(REPO, "bin/sia"), os.O_RDONLY)
            wrong_fd = os.open(wrong, os.O_RDONLY)
            base = {
                "SIA_LAUNCHER_ABI": "sia-launch-v1",
                "SIA_LAUNCHER_LIFECYCLE_FD": str(lifecycle_fd),
                "SIA_LAUNCHER_TARGET_FD": str(target_fd),
                "SIA_LAUNCHER_TARGET_PATH": os.path.join(REPO, "bin/sia"),
            }
            try:
                with mock.patch.dict(os.environ, base):
                    with self.assertRaisesRegex(RuntimeError,
                                                "holds no shared lease"):
                        cli._validated_launcher_lifecycle_fd(
                            lock, os.path.join(REPO, "bin/sia"))
                fcntl.flock(lifecycle_fd, fcntl.LOCK_SH | fcntl.LOCK_NB)
                wrong_environment = dict(base)
                wrong_environment["SIA_LAUNCHER_TARGET_FD"] = str(wrong_fd)
                with mock.patch.dict(os.environ, wrong_environment):
                    with self.assertRaisesRegex(RuntimeError,
                                                "changed generation"):
                        cli._validated_launcher_lifecycle_fd(
                            lock, os.path.join(REPO, "bin/sia"))
                with mock.patch.dict(os.environ, base):
                    self.assertEqual(
                        cli._validated_launcher_lifecycle_fd(
                            lock, os.path.join(REPO, "bin/sia")),
                        lifecycle_fd)
            finally:
                fcntl.flock(lifecycle_fd, fcntl.LOCK_UN)
                os.close(wrong_fd)
                os.close(target_fd)
                os.close(lifecycle_fd)

    def test_restore_supervisor_uses_owned_runtime_drop_in_not_runtime_mask(self):
        with tempfile.TemporaryDirectory() as home:
            launcher_path = os.path.join(home, ".local", "bin", "sia")
            _generate_stable_launcher(launcher_path)
            source = _read_path(launcher_path)
            self.assertNotIn('["mask", "--runtime"', source)
            self.assertNotIn('["unmask", "--runtime"', source)
            self.assertIn("ConditionPathExists=!/", source)
            self.assertIn("RefuseManualStart=yes", source)

    def test_restore_supervisor_carries_exact_repository_binding(self):
        with tempfile.TemporaryDirectory() as home:
            launcher_path = os.path.join(home, ".local", "bin", "sia")
            _generate_stable_launcher(launcher_path)
            launcher = _load("sia_restore_repository_binding", launcher_path)
            root = os.path.join(home, ".local/state/sia-continuity")
            requests = os.path.join(root, "requests")
            os.makedirs(requests, mode=0o700)
            request_id = "a" * 32
            request_path = os.path.join(requests, request_id + ".json")
            repository_binding = {
                "repository": "rest:https://backup.invalid/sia",
                "environment_file": "",
                "repository_id": "c" * 64,
                "configured_at": "2026-09-01T00:00:00Z",
                "target_public_key": "d" * 64,
                "restored_public_key": "e" * 64,
            }
            core_binding = {
                "prepared_id": "d" * 32,
                "snapshot_id": "9" * 64,
                "capsule_id": "a" * 32,
                "manifest_sha256": "b" * 64,
                **repository_binding,
            }
            confirmation, adoption, _adoption_debt = \
                _restore_adoption_fields(core_binding)
            request = {
                "schema": launcher._REQUEST_SCHEMA,
                "id": request_id,
                "created_at": "2026-09-01T00:00:00Z",
                "action": "apply",
                "args": {
                    **core_binding,
                    "confirmation": confirmation,
                    "identity_key_file": None,
                    "adoption": adoption,
                },
            }
            _write(request_path, json.dumps(request) + "\n", 0o600)
            binding = launcher._request_binding(request_path, root)
            for key, value in repository_binding.items():
                self.assertEqual(binding[key], value)

            for field, replacement in (
                    ("created_at", "2026-09-01T00:00:00.0Z"),
                    ("configured_at", "not-a-time")):
                changed_request = {
                    **request,
                    "args": dict(request["args"]),
                }
                if field == "created_at":
                    changed_request[field] = replacement
                else:
                    changed_request["args"][field] = replacement
                _write(
                    request_path, json.dumps(changed_request) + "\n",
                    0o600)
                with self.subTest(request_timestamp=field), \
                        self.assertRaisesRegex(
                            RuntimeError, "request binding is invalid"):
                    launcher._request_binding(request_path, root)
            _write(request_path, json.dumps(request) + "\n", 0o600)

            runtime_info = os.lstat(launcher_path)
            debt = {
                "schema": launcher._SUPERVISOR_SCHEMA,
                "kind": "restore-apply",
                **binding,
                "phase": "accepted",
                "child_code": "pending",
                "restart_pid": "pending",
                "runtime_path": launcher_path,
                "runtime_device": str(runtime_info.st_dev),
                "runtime_inode": str(runtime_info.st_ino),
            }
            launcher._write_supervisor(root, debt)
            self.assertEqual(launcher._supervisor_debt(root), debt)
            _write(
                launcher._supervisor_path(root),
                json.dumps({**debt, "configured_at": "not-a-time"})
                + "\n", 0o600)
            with self.assertRaisesRegex(
                    RuntimeError, "supervisor debt is malformed"):
                launcher._supervisor_debt(root)
            _write(
                launcher._supervisor_path(root),
                json.dumps(debt) + "\n", 0o600)
            changed = {**debt, "repository_id": "f" * 64}
            with self.assertRaisesRegex(
                    RuntimeError, "supervisor debt binding changed"):
                launcher._write_supervisor(root, changed)
            os.unlink(launcher._supervisor_path(root))
            recovery = {
                **debt,
                "kind": "restore-recover",
                "request_path": "",
                "prepared_id": "",
                "snapshot_id": "",
                "capsule_id": "",
                "manifest_sha256": "",
                **{key: "" for key in repository_binding},
                **{key: "" for key in {
                    "identity_key_file", "request_device", "request_inode",
                    "accepted_ledger_head", "confirmation_sha256",
                    "adoption_order", "adoption_record_id", "target"}},
            }
            launcher._write_supervisor(root, recovery)
            self.assertEqual(launcher._supervisor_debt(root), recovery)
            _write(
                launcher._supervisor_path(root),
                json.dumps({**recovery, "request_id": "a"}) + "\n",
                0o600)
            with self.assertRaisesRegex(
                    RuntimeError, "supervisor debt is malformed"):
                launcher._supervisor_debt(root)

    def test_brainstem_restart_admits_current_restore_binding_schema(self):
        library = _load(
            "sialib_restore_admission", os.path.join(REPO, "bin/sialib.py"))
        admission = _load(
            "siarestoreadmit_contract",
            os.path.join(REPO, "bin/siarestoreadmit.py"))
        with tempfile.TemporaryDirectory() as home:
            runtime = os.path.join(home, ".local/share/sia/bin")
            root = os.path.join(home, ".local/state/sia-continuity")
            requests = os.path.join(root, "requests")
            os.makedirs(runtime, mode=0o700)
            os.makedirs(requests, mode=0o700)
            runtime_path = os.path.join(runtime, "sia-cli")
            _write(runtime_path, "runtime\n", 0o600)
            request_id = "a" * 32
            request_path = os.path.join(requests, request_id + ".json")
            binding = {
                "prepared_id": "d" * 32,
                "snapshot_id": "f" * 64,
                "capsule_id": "a" * 32,
                "manifest_sha256": "b" * 64,
                "repository": "rest:https://backup.invalid/sia",
                "environment_file": "",
                "repository_id": "c" * 64,
                "configured_at": "2026-09-01T00:00:00Z",
                "target_public_key": "d" * 64,
                "restored_public_key": "e" * 64,
            }
            confirmation, adoption, adoption_debt = \
                _restore_adoption_fields(binding)
            request = {
                "schema": "sia-continuity-request-v1",
                "id": request_id,
                "created_at": "2026-09-01T00:00:00Z",
                "action": "apply",
                "args": {
                    **binding,
                    "confirmation": confirmation,
                    "identity_key_file": None,
                    "adoption": adoption,
                },
            }
            _write(request_path, json.dumps(request) + "\n", 0o600)
            request_info = os.lstat(request_path)
            info = os.lstat(runtime_path)
            debt = {
                "schema": "sia-restore-supervisor-v1",
                "kind": "restore-apply",
                "request_path": request_path,
                "request_id": request_id,
                **binding,
                "phase": "restart-starting",
                "child_code": "0",
                "restart_pid": "pending",
                "runtime_path": runtime_path,
                "runtime_device": str(info.st_dev),
                "runtime_inode": str(info.st_ino),
                "request_device": str(request_info.st_dev),
                "request_inode": str(request_info.st_ino),
                **adoption_debt,
            }
            supervisor = os.path.join(root, "restore-supervisor.json")
            _write(supervisor, json.dumps(debt) + "\n", 0o600)
            with mock.patch.object(library, "BIN", runtime), \
                    mock.patch.object(
                        library, "RESTORE_BARRIER_PATH",
                        os.path.join(root, "restore-in-progress.json")), \
                    mock.patch.object(
                        library, "RESTORE_MASK_PATH",
                        os.path.join(root, "restore-runtime-mask")), \
                    mock.patch.object(
                        library, "RESTORE_SUPERVISOR_PATH", supervisor):
                self.assertTrue(
                    admission._brainstem_restore_restart_admitted(library))
                short_id = {**debt, "request_id": "a"}
                _write(
                    supervisor,
                    json.dumps(short_id) + "\n", 0o600)
                with self.assertRaisesRegex(
                        RuntimeError, "restart is not admissible"):
                    admission._brainstem_restore_restart_admitted(library)
                _write(supervisor, json.dumps(debt) + "\n", 0o600)
                request["args"]["repository_id"] = "9" * 64
                _write(request_path, json.dumps(request) + "\n", 0o600)
                with self.assertRaisesRegex(
                        RuntimeError, "request binding changed"):
                    admission._brainstem_restore_restart_admitted(library)
                request["args"]["repository_id"] = binding["repository_id"]
                request["args"]["confirmation"]["unexpected"] = True
                _write(request_path, json.dumps(request) + "\n", 0o600)
                with self.assertRaisesRegex(
                        RuntimeError, "request binding changed"):
                    admission._brainstem_restore_restart_admitted(library)
                del request["args"]["confirmation"]["unexpected"]
                _write(request_path, json.dumps(request) + "\n", 0o600)
                self.assertTrue(
                    admission._brainstem_restore_restart_admitted(library))

                replacement = request_path + ".replacement"
                _write(replacement, json.dumps(request) + "\n", 0o600)
                os.replace(replacement, request_path)
                with self.assertRaisesRegex(
                        RuntimeError, "request binding changed"):
                    admission._brainstem_restore_restart_admitted(library)

                os.unlink(request_path)
                status_path = os.path.join(root, "status.json")
                status = {
                    "schema_version": 2,
                    "state": "recovery-only",
                    "detail": "Restore verified; repository copy unclaimed.",
                    "repository_display": "External recovery repository",
                    "latest": None,
                    "prepared": None,
                    "operation": {
                        "request_id": request_id,
                        "kind": "restore-apply",
                        "prepared_id": binding["prepared_id"],
                        "phase": "verified",
                        "ready": True,
                        "sia_ledger_verified": True,
                    },
                    "updated_at": "2026-09-01T00:00:00Z",
                }
                _write(status_path, json.dumps(status) + "\n", 0o600)
                self.assertTrue(
                    admission._brainstem_restore_restart_admitted(library))
                _write(
                    status_path,
                    json.dumps({**status, "unexpected": True}) + "\n",
                    0o600)
                with self.assertRaisesRegex(
                        RuntimeError, "replay is uncorrelated"):
                    admission._brainstem_restore_restart_admitted(library)

    def test_public_recovery_emits_an_admissible_correlation_identifier(self):
        library = _load(
            "sialib_public_recovery_admission",
            os.path.join(REPO, "bin/sialib.py"))
        admission = _load(
            "siarestoreadmit_public_recovery",
            os.path.join(REPO, "bin/siarestoreadmit.py"))
        with tempfile.TemporaryDirectory() as home:
            launcher_path = os.path.join(home, ".local", "bin", "sia")
            target = os.path.join(
                home, ".local", "share", "sia", "bin", "sia-cli")
            _generate_stable_launcher(launcher_path)
            _write(target, "# runtime target\n", 0o600)
            launcher = _load("sia_public_recovery_id", launcher_path)
            state_parent = os.path.join(home, ".local", "state")
            root = os.path.join(state_parent, "sia-continuity")
            os.makedirs(root, mode=0o700)
            launcher._write_marker(root)

            with mock.patch.object(
                    launcher, "_gate_brainstem", return_value=True), \
                    mock.patch.object(
                        launcher.subprocess, "run",
                        return_value=subprocess.CompletedProcess([], 1)), \
                    mock.patch.object(sys, "argv", [
                        launcher_path, launcher._RECOVER_COMMAND]):
                stopped = launcher._restore_main(
                    home, target,
                    os.path.join(state_parent, "sia.lifecycle-removed"),
                    state_parent, [launcher._RECOVER_COMMAND],
                    public_recovery=True)
            self.assertEqual(stopped, 1)
            debt = launcher._supervisor_debt(root)
            self.assertRegex(debt["request_id"], r"^[0-9a-f]{32}$")

            debt["phase"] = "restart-starting"
            debt["child_code"] = "0"
            launcher._write_supervisor(root, debt)
            launcher._remove_marker(root)
            with mock.patch.object(library, "BIN", os.path.dirname(target)), \
                    mock.patch.object(
                        library, "RESTORE_BARRIER_PATH",
                        os.path.join(root, "restore-in-progress.json")), \
                    mock.patch.object(
                        library, "RESTORE_MASK_PATH",
                        os.path.join(root, "restore-runtime-mask")), \
                    mock.patch.object(
                        library, "RESTORE_SUPERVISOR_PATH",
                        launcher._supervisor_path(root)):
                self.assertTrue(
                    admission._brainstem_restore_restart_admitted(library))

    def test_restore_supervisor_refuses_foreign_effective_unit_before_stop(self):
        with tempfile.TemporaryDirectory() as home:
            launcher_path = os.path.join(home, ".local", "bin", "sia")
            _generate_stable_launcher(launcher_path)
            launcher = _load("sia_restore_effective_unit", launcher_path)
            unit = _managed_brainstem_install(home)
            root = os.path.join(home, ".local/state/sia-continuity")
            os.makedirs(root, mode=0o700)
            cases = (
                ("fragment", os.path.join(home, "foreign.service"), ""),
                ("drop-in", unit, os.path.join(home, "foreign.conf")),
            )
            for label, fragment, drop_in in cases:
                with self.subTest(label=label):
                    calls = []

                    def systemctl(arguments, _label, *, capture=False,
                                  calls=calls, fragment=fragment, drop_in=drop_in):
                        calls.append(list(arguments))
                        output = (_brainstem_show(fragment, drop_in=drop_in)
                                  if capture else b"")
                        return subprocess.CompletedProcess(
                            arguments, 0, stdout=output)

                    with mock.patch.object(
                            launcher, "_systemctl", side_effect=systemctl), \
                            self.assertRaisesRegex(
                                RuntimeError,
                                "effective unit is not the managed unit"):
                        launcher._gate_brainstem(home, root)
                    self.assertFalse(any(
                        call[:1] == ["stop"] for call in calls))
                    self.assertFalse(launcher._marker_present(root))
                    self.assertEqual(launcher._barrier_file("state"),
                                     "absent")

    def test_restore_supervisor_requires_exact_managed_brainstem_receipt(self):
        with tempfile.TemporaryDirectory() as home:
            launcher_path = os.path.join(home, ".local", "bin", "sia")
            _generate_stable_launcher(launcher_path)
            launcher = _load("sia_restore_managed_unit", launcher_path)
            unit = _managed_brainstem_install(home)
            _write(unit, _read_path(unit) + "# local mutation\n", 0o644)
            with mock.patch.object(launcher, "_systemctl") as systemctl, \
                    self.assertRaisesRegex(
                        RuntimeError,
                        "managed brainstem unit receipt does not match"):
                launcher._service_state(home, "")
            systemctl.assert_not_called()

    def test_restore_supervisor_refuses_cached_brainstem_generation(self):
        with tempfile.TemporaryDirectory() as home:
            launcher_path = os.path.join(home, ".local", "bin", "sia")
            _generate_stable_launcher(launcher_path)
            launcher = _load("sia_restore_cached_unit", launcher_path)
            unit = _managed_brainstem_install(home)
            observed = []

            def systemctl(arguments, _label, *, capture=False):
                observed.append(list(arguments))
                return subprocess.CompletedProcess(
                    arguments, 0,
                    stdout=_brainstem_show(unit, daemon_reload="yes"))

            with mock.patch.object(
                    launcher, "_systemctl", side_effect=systemctl), \
                    self.assertRaisesRegex(
                        RuntimeError, "daemon reload is pending"):
                launcher._service_state(home, "")
            self.assertIn("--property=NeedDaemonReload", observed[0])

    def test_restore_supervisor_drop_in_gate_and_operator_mask_controls(self):
        with tempfile.TemporaryDirectory() as home:
            launcher_path = os.path.join(home, ".local", "bin", "sia")
            _generate_stable_launcher(launcher_path)
            launcher = _load("sia_restore_drop_in_gate", launcher_path)
            unit = _managed_brainstem_install(home)
            root = os.path.join(home, ".local/state/sia-continuity")
            os.makedirs(root, mode=0o700)
            reports = [
                _brainstem_show(unit),
                _brainstem_show(
                    unit, drop_in=launcher._runtime_barrier_path(),
                    refuse="yes", active="inactive", pid="0"),
            ]
            calls = []

            def systemctl(arguments, _label, *, capture=False):
                calls.append(list(arguments))
                output = reports.pop(0) if capture else b""
                return subprocess.CompletedProcess(arguments, 0, stdout=output)

            with mock.patch.object(
                    launcher, "_systemctl", side_effect=systemctl):
                self.assertTrue(launcher._gate_brainstem(home, root))
            self.assertTrue(launcher._marker_present(root))
            self.assertEqual(launcher._barrier_file("state"), "active")
            self.assertIn(["stop", launcher._SERVICE], calls)
            launcher._remove_marker(root)
            self.assertEqual(launcher._barrier_file("retire"), "retired")
            self.assertEqual(launcher._barrier_file("discard"), "absent")

        with tempfile.TemporaryDirectory() as home:
            launcher_path = os.path.join(home, ".local", "bin", "sia")
            _generate_stable_launcher(launcher_path)
            launcher = _load("sia_restore_operator_gate", launcher_path)
            _managed_brainstem_install(home)
            root = os.path.join(home, ".local/state/sia-continuity")
            os.makedirs(root, mode=0o700)
            reports = [
                _brainstem_show(
                    "/dev/null", load="masked", unit_state="masked-runtime",
                    active="active"),
                _brainstem_show(
                    "/dev/null", load="masked", unit_state="masked-runtime",
                    active="inactive", pid="0"),
            ]

            def systemctl(arguments, _label, *, capture=False):
                output = reports.pop(0) if capture else b""
                return subprocess.CompletedProcess(arguments, 0, stdout=output)

            with mock.patch.object(
                    launcher, "_systemctl", side_effect=systemctl):
                self.assertFalse(launcher._gate_brainstem(home, root))
            self.assertFalse(launcher._marker_present(root))
            self.assertEqual(launcher._barrier_file("state"), "absent")

    def test_restore_supervisor_rechecks_effective_unit_before_restart(self):
        with tempfile.TemporaryDirectory() as home:
            launcher_path = os.path.join(home, ".local", "bin", "sia")
            _generate_stable_launcher(launcher_path)
            launcher = _load("sia_restore_restart_recheck", launcher_path)
            unit = _managed_brainstem_install(home)
            root = os.path.join(home, ".local/state/sia-continuity")
            os.makedirs(root, mode=0o700)
            launcher._write_marker(root)
            launcher._barrier_file("install")
            launcher._remove_marker(root)
            reports = [
                _brainstem_show(
                    unit, drop_in=launcher._runtime_barrier_path(),
                    refuse="yes", active="inactive", pid="0"),
                _brainstem_show(
                    os.path.join(home, "foreign.service"),
                    active="inactive", pid="0"),
            ]
            calls = []

            def systemctl(arguments, _label, *, capture=False):
                calls.append(list(arguments))
                output = reports.pop(0) if capture else b""
                return subprocess.CompletedProcess(arguments, 0, stdout=output)

            with mock.patch.object(
                    launcher, "_systemctl", side_effect=systemctl), \
                    self.assertRaisesRegex(
                        RuntimeError,
                        "effective unit is not the managed unit"):
                launcher._retire_gate(
                    home, root, owned=True, barrier_present=False)
            self.assertFalse(any(
                call[:1] == ["start"] for call in calls))

    def test_restore_supervisor_marker_retirement_failure_never_finalizes(self):
        with tempfile.TemporaryDirectory() as home:
            launcher_path = os.path.join(home, ".local", "bin", "sia")
            target = os.path.join(
                home, ".local", "share", "sia", "bin", "sia-cli")
            _generate_stable_launcher(launcher_path)
            _write(target, "# runtime target\n", 0o600)
            launcher = _load("sia_restore_supervisor_failure",
                             launcher_path)
            state_parent = os.path.join(home, ".local", "state")
            root = os.path.join(state_parent, "sia-continuity")
            os.makedirs(root, mode=0o700)
            request_path = os.path.join(root, "requests", "abc123.json")
            target_info = os.lstat(target)
            persisted = {
                "schema": launcher._SUPERVISOR_SCHEMA,
                "kind": "restore-apply",
                "request_path": request_path,
                "request_id": "abc123",
                "prepared_id": "def456",
                "snapshot_id": "snapshot",
                "capsule_id": "a" * 32,
                "manifest_sha256": "b" * 64,
                "repository": "rest:https://backup.invalid/sia",
                "environment_file": "",
                "repository_id": "c" * 64,
                "configured_at": "2030-01-01T00:00:00Z",
                "target_public_key": "d" * 64,
                "restored_public_key": "e" * 64,
                "phase": "accepted",
                "child_code": "pending",
                "restart_pid": "pending",
                "runtime_path": target,
                "runtime_device": str(target_info.st_dev),
                "runtime_inode": str(target_info.st_ino),
            }
            binding = {
                key: persisted[key] for key in {
                    "request_path", "request_id", "prepared_id",
                    "snapshot_id", "capsule_id", "manifest_sha256",
                    "repository", "environment_file", "repository_id",
                    "configured_at", "target_public_key",
                    "restored_public_key"}
            }
            finalizer_calls = []

            def read_debt(_root):
                return dict(persisted)

            def write_debt(_root, value):
                persisted.clear()
                persisted.update(value)

            def post(_stable, arguments, _admin_fd):
                finalizer_calls.append(arguments)
                return True

            child = subprocess.CompletedProcess([], 0)
            with mock.patch.object(
                    launcher, "_supervisor_debt", side_effect=read_debt), \
                    mock.patch.object(
                        launcher, "_write_supervisor",
                        side_effect=write_debt), \
                    mock.patch.object(
                        launcher, "_request_binding",
                        return_value=binding), \
                    mock.patch.object(
                        launcher, "_marker_present", return_value=False), \
                    mock.patch.object(
                        launcher, "_gate_brainstem", return_value=True), \
                    mock.patch.object(
                        launcher, "_remove_marker",
                        side_effect=OSError("marker unlink refused")), \
                    mock.patch.object(
                        launcher, "_post_supervisor", side_effect=post), \
                    mock.patch.object(
                        launcher.subprocess, "run", return_value=child), \
                    mock.patch.object(
                        sys, "argv", [launcher_path,
                                      launcher._RESTORE_COMMAND,
                                      request_path]), \
                    self.assertRaises(SystemExit):
                launcher._restore_main(
                    home, target,
                    os.path.join(state_parent, "sia.lifecycle-removed"),
                    state_parent,
                    [launcher._RESTORE_COMMAND, request_path],
                    apply_request=request_path)
            self.assertEqual(persisted["phase"], "restart-failed")
            self.assertIn(
                ["_continuity-restore-restart-failed", request_path],
                finalizer_calls)
            self.assertNotIn(
                ["_continuity-supervisor-reconcile"], finalizer_calls)

    def test_restore_discard_failure_regates_started_resident_without_attestation(self):
        with tempfile.TemporaryDirectory() as home:
            launcher_path = os.path.join(home, ".local", "bin", "sia")
            target = os.path.join(
                home, ".local", "share", "sia", "bin", "sia-cli")
            _generate_stable_launcher(launcher_path)
            _write(target, "# runtime target\n", 0o600)
            launcher = _load(
                "sia_restore_discard_failure_regate", launcher_path)
            state_parent = os.path.join(home, ".local", "state")
            root = os.path.join(state_parent, "sia-continuity")
            os.makedirs(root, mode=0o700)
            request_path = os.path.join(root, "requests", "request.json")
            target_info = os.lstat(target)
            persisted = {
                "schema": launcher._SUPERVISOR_SCHEMA,
                "kind": "restore-apply",
                "request_path": request_path,
                "request_id": "a" * 32,
                "prepared_id": "b" * 32,
                "snapshot_id": "c" * 64,
                "capsule_id": "d" * 32,
                "manifest_sha256": "e" * 64,
                "phase": "accepted",
                "child_code": "pending",
                "restart_pid": "pending",
                "runtime_path": target,
                "runtime_device": str(target_info.st_dev),
                "runtime_inode": str(target_info.st_ino),
            }
            binding = {
                key: persisted[key] for key in {
                    "request_path", "request_id", "prepared_id",
                    "snapshot_id", "capsule_id", "manifest_sha256"}
            }
            gate_calls = []
            finalizer_calls = []
            service_states = [
                {
                    "LoadState": "loaded", "UnitFileState": "enabled",
                    "ActiveState": "inactive", "MainPID": "0",
                },
                {
                    "LoadState": "loaded", "UnitFileState": "enabled",
                    "ActiveState": "inactive", "MainPID": "0",
                },
                {
                    "LoadState": "loaded", "UnitFileState": "enabled",
                    "ActiveState": "active", "MainPID": "123",
                },
            ]

            def read_debt(_root):
                return dict(persisted)

            def write_debt(_root, value):
                persisted.clear()
                persisted.update(value)

            def gate(*_args, **kwargs):
                gate_calls.append(kwargs.get("supervisor_owned", False))
                return True

            def barrier_file(action):
                if action == "state":
                    return "active"
                if action == "retire":
                    return "retired"
                if action == "discard":
                    return "retired"
                raise AssertionError(f"unexpected barrier action: {action}")

            def service_state(*_args, **_kwargs):
                return service_states.pop(0)

            def post(_stable, arguments, _admin_fd):
                finalizer_calls.append(arguments)
                return True

            systemctl = mock.Mock()
            error = io.StringIO()
            with mock.patch.object(
                    launcher, "_supervisor_debt", side_effect=read_debt), \
                    mock.patch.object(
                        launcher, "_write_supervisor",
                        side_effect=write_debt), \
                    mock.patch.object(
                        launcher, "_request_binding",
                        return_value=binding), \
                    mock.patch.object(
                        launcher, "_marker_present", return_value=False), \
                    mock.patch.object(
                        launcher, "_gate_brainstem", side_effect=gate), \
                    mock.patch.object(launcher, "_remove_marker"), \
                    mock.patch.object(
                        launcher, "_barrier_file", side_effect=barrier_file), \
                    mock.patch.object(
                        launcher, "_service_state", side_effect=service_state), \
                    mock.patch.object(
                        launcher, "_systemctl", systemctl), \
                    mock.patch.object(
                        launcher, "_post_supervisor", side_effect=post), \
                    mock.patch.object(
                        launcher.subprocess, "run",
                        return_value=subprocess.CompletedProcess([], 0)), \
                    mock.patch.object(
                        sys, "argv", [launcher_path,
                                      launcher._RESTORE_COMMAND,
                                      request_path]), \
                    mock.patch.object(sys, "stderr", error), \
                    self.assertRaises(SystemExit):
                launcher._restore_main(
                    home, target,
                    os.path.join(state_parent, "sia.lifecycle-removed"),
                    state_parent,
                    [launcher._RESTORE_COMMAND, request_path],
                    apply_request=request_path)

            self.assertEqual(service_states, [])
            self.assertIn(
                mock.call(["start", launcher._SERVICE],
                          "restart the SIA brainstem"),
                systemctl.call_args_list)
            self.assertIn(
                "retired SIA restore runtime barrier remains",
                error.getvalue())
            self.assertEqual(gate_calls, [False, True])
            self.assertEqual(persisted["phase"], "restart-failed")
            self.assertEqual(persisted["restart_pid"], "pending")
            self.assertIn(
                ["_continuity-restore-restart-failed", request_path],
                finalizer_calls)
            self.assertNotIn(
                ["_continuity-supervisor-reconcile"], finalizer_calls)

    def test_restore_finalizer_failure_regates_after_visible_debt_unlink(self):
        with tempfile.TemporaryDirectory() as home:
            launcher_path = os.path.join(home, ".local", "bin", "sia")
            target = os.path.join(
                home, ".local", "share", "sia", "bin", "sia-cli")
            _generate_stable_launcher(launcher_path)
            _write(target, "# runtime target\n", 0o600)
            launcher = _load(
                "sia_restore_finalizer_regate", launcher_path)
            state_parent = os.path.join(home, ".local", "state")
            root = os.path.join(state_parent, "sia-continuity")
            os.makedirs(root, mode=0o700)
            request_path = os.path.join(root, "requests", "request.json")
            target_info = os.lstat(target)
            persisted = {
                "schema": launcher._SUPERVISOR_SCHEMA,
                "kind": "restore-apply",
                "request_path": request_path,
                "request_id": "a" * 32,
                "prepared_id": "b" * 32,
                "snapshot_id": "c" * 64,
                "capsule_id": "d" * 32,
                "manifest_sha256": "e" * 64,
                "phase": "accepted",
                "child_code": "pending",
                "restart_pid": "pending",
                "runtime_path": target,
                "runtime_device": str(target_info.st_dev),
                "runtime_inode": str(target_info.st_ino),
            }
            binding = {
                key: persisted[key] for key in {
                    "request_path", "request_id", "prepared_id",
                    "snapshot_id", "capsule_id", "manifest_sha256"}
            }
            debt_visible = True
            gate_calls = []
            gate_statuses = []
            visible_status = "restoring"

            def read_debt(_root):
                return dict(persisted) if debt_visible else None

            def write_debt(_root, value):
                nonlocal debt_visible
                debt_visible = True
                persisted.clear()
                persisted.update(value)

            def gate(*_args, **_kwargs):
                gate_calls.append(True)
                gate_statuses.append(visible_status)
                return True

            def post(_stable, arguments, _admin_fd):
                nonlocal debt_visible, visible_status
                if arguments == ["_continuity-supervisor-reconcile"]:
                    debt_visible = False
                    visible_status = "verified"
                    return False
                if arguments == ["_continuity-restore-restart-failed",
                                 request_path]:
                    visible_status = "blocked"
                    return True
                return True

            with mock.patch.object(
                    launcher, "_supervisor_debt", side_effect=read_debt), \
                    mock.patch.object(
                        launcher, "_write_supervisor",
                        side_effect=write_debt), \
                    mock.patch.object(
                        launcher, "_request_binding",
                        return_value=binding), \
                    mock.patch.object(
                        launcher, "_marker_present", return_value=False), \
                    mock.patch.object(
                        launcher, "_gate_brainstem", side_effect=gate), \
                    mock.patch.object(launcher, "_remove_marker"), \
                    mock.patch.object(
                        launcher, "_retire_gate",
                        return_value=(True, "123")), \
                    mock.patch.object(
                        launcher, "_post_supervisor", side_effect=post), \
                    mock.patch.object(
                        launcher.subprocess, "run",
                        return_value=subprocess.CompletedProcess([], 0)), \
                    mock.patch.object(
                        sys, "argv", [launcher_path,
                                      launcher._RESTORE_COMMAND,
                                      request_path]), \
                    self.assertRaises(SystemExit):
                launcher._restore_main(
                    home, target,
                    os.path.join(state_parent, "sia.lifecycle-removed"),
                    state_parent,
                    [launcher._RESTORE_COMMAND, request_path],
                    apply_request=request_path)
            self.assertEqual(len(gate_calls), 2)
            self.assertEqual(gate_statuses, ["restoring", "blocked"])
            self.assertTrue(debt_visible)
            self.assertEqual(persisted["phase"], "restart-failed")
            self.assertEqual(visible_status, "blocked")

    def test_restore_supervisor_never_claims_an_operator_mask(self):
        with tempfile.TemporaryDirectory() as home:
            launcher_path = os.path.join(home, ".local", "bin", "sia")
            target = os.path.join(
                home, ".local", "share", "sia", "bin", "sia-cli")
            _generate_stable_launcher(launcher_path)
            _write(target, "# runtime target\n", 0o600)
            launcher = _load("sia_restore_operator_mask",
                             launcher_path)
            state_parent = os.path.join(home, ".local", "state")
            root = os.path.join(state_parent, "sia-continuity")
            os.makedirs(root, mode=0o700)
            request_path = os.path.join(root, "requests", "abc123.json")
            target_info = os.lstat(target)
            persisted = {
                "schema": launcher._SUPERVISOR_SCHEMA,
                "kind": "restore-apply",
                "request_path": request_path,
                "request_id": "abc123",
                "prepared_id": "def456",
                "snapshot_id": "snapshot",
                "capsule_id": "a" * 32,
                "manifest_sha256": "b" * 64,
                "repository": "rest:https://backup.invalid/sia",
                "environment_file": "",
                "repository_id": "c" * 64,
                "configured_at": "2030-01-01T00:00:00Z",
                "target_public_key": "d" * 64,
                "restored_public_key": "e" * 64,
                "phase": "accepted",
                "child_code": "pending",
                "restart_pid": "pending",
                "runtime_path": target,
                "runtime_device": str(target_info.st_dev),
                "runtime_inode": str(target_info.st_ino),
            }
            binding = {
                key: persisted[key] for key in {
                    "request_path", "request_id", "prepared_id",
                    "snapshot_id", "capsule_id", "manifest_sha256",
                    "repository", "environment_file", "repository_id",
                    "configured_at", "target_public_key",
                    "restored_public_key"}
            }
            finalizer_calls = []

            def read_debt(_root):
                return dict(persisted)

            def write_debt(_root, value):
                persisted.clear()
                persisted.update(value)

            def post(_stable, arguments, _admin_fd):
                finalizer_calls.append(arguments)
                return True

            child = subprocess.CompletedProcess([], 0)
            with mock.patch.object(
                    launcher, "_supervisor_debt", side_effect=read_debt), \
                    mock.patch.object(
                        launcher, "_write_supervisor",
                        side_effect=write_debt), \
                    mock.patch.object(
                        launcher, "_request_binding",
                        return_value=binding), \
                    mock.patch.object(
                        launcher, "_marker_present", return_value=False), \
                    mock.patch.object(
                        launcher, "_gate_brainstem", return_value=False), \
                    mock.patch.object(
                        launcher, "_remove_marker") as remove_marker, \
                    mock.patch.object(
                        launcher, "_retire_gate") as retire_gate, \
                    mock.patch.object(
                        launcher, "_post_supervisor", side_effect=post), \
                    mock.patch.object(
                        launcher.subprocess, "run", return_value=child), \
                    mock.patch.object(
                        sys, "argv", [launcher_path,
                                      launcher._RESTORE_COMMAND,
                                      request_path]), \
                    self.assertRaises(SystemExit):
                launcher._restore_main(
                    home, target,
                    os.path.join(state_parent, "sia.lifecycle-removed"),
                    state_parent,
                    [launcher._RESTORE_COMMAND, request_path],
                    apply_request=request_path)
            self.assertEqual(persisted["phase"], "restart-failed")
            remove_marker.assert_not_called()
            retire_gate.assert_not_called()
            self.assertIn(
                ["_continuity-restore-restart-failed", request_path],
                finalizer_calls)
            self.assertNotIn(
                ["_continuity-supervisor-reconcile"], finalizer_calls)

    def test_new_sialib_rejects_loaded_old_installed_launchers(self):
        with tempfile.TemporaryDirectory() as home:
            runtime = os.path.join(home, ".local/share/sia/bin")
            for name in ("sialib.py", "siagraph.py", "siathought.py", "siasenses.py",
                         "siarestoreadmit.py", "siacorpuslease.py", "siaprocess.py",
                         "sianotes.py", "siamind.py", "siatakes.py", "siaqueue.py"):
                _write(os.path.join(runtime, name), _read("bin/" + name),
                       0o644)
            environment = os.environ.copy()
            environment["HOME"] = home
            for launcher in (
                    os.path.join(home, ".local/bin/sia"),
                    os.path.join(runtime, "sia-brainstem")):
                with self.subTest(launcher=launcher):
                    _write(
                        launcher,
                        "import sys\n"
                        f"sys.path.insert(0, {runtime!r})\n"
                        "import sialib\n",
                        0o755)
                    result = subprocess.run(
                        [sys.executable, launcher], env=environment, text=True,
                        stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                        check=False)
                    self.assertNotEqual(result.returncode, 0)
                    self.assertIn("did not pin its runtime", result.stderr)

    # The bind/invoke façade is the whole interface between sialib and each
    # extracted child module: sialib builds one delegate per name in
    # _EXPORTED_FUNCTIONS and resolves every call through
    # _ORIGINAL_CHILD_FUNCTIONS.  An extraction is a pure move, so a name
    # that quietly leaves this set is a delegate sialib stops publishing,
    # not a smaller module.  Pin the exact set; the next extraction adds its
    # module here and inherits every façade guard below.
    FACADE_CHILD_EXPORTS = {
        "sianotes": (
            "_account_agent_note_redactions",
            "_forget_agent_note_redaction_receipt",
            "_read_existing_agent_note",
            "_rebind_pending_redaction_targets",
            "acknowledge_agent_notes",
            "materialize_agent_notes",
        ),
        "sialivepublication": (
            "_live_authority_memo",
            "_live_bytes",
            "_live_controller_source_pending",
            "_live_files",
            "_live_final_memo",
            "_live_generation",
            "_live_graph_status",
            "_live_memo_bytes",
            "_live_memo_sha",
            "_live_own",
            "_live_parent_generation",
            "_live_prepare_replay",
            "_live_receipt",
            "_live_receipt_shape",
            "_live_replay_candidate",
            "_live_same",
            "_live_sha",
            "_live_source_effects_paid_corpus_debt",
            "_live_status_image",
            "_live_upstream_refusal",
            "_publish_staged_live_generation",
            "_read_committed_live_generation",
            "_read_historical_live_generation",
            "_read_live_generation_against_graph",
            "_recover_pending_live_generation",
            "_stage_live_generation",
        ),
        "siagraph": (
            "_admit_graph_candidate", "_advance_graph_projection",
            "_append_graph_failure", "_canonical_graph_projection_state",
            "_export_graph_publication", "_fresh_graph_projection_state",
            "_graph_display_nodes", "_graph_projection_debt",
            "_graph_projection_pages", "_graph_projection_state_path",
            "_graph_snapshot_body_counts",
            "_infer_domain_link_type", "_iter_corpus_link_edges",
            "_load_graph_projection_state", "_mark_graph_projection_dirty",
            "_recoverable_graph_snapshot",
            "_read_graph_corpus_page", "_read_owned_stable_lines",
            "_record_graph_failure", "_relation_context",
            "_save_graph_projection_state", "_sia_schema_pack_path",
            "_suppress_shadowed_mentions", "_validate_domain_regex",
            "_yaml_scalar", "corpus_edges", "export_graph",
            "load_domain_edge_spec",
        ),
        "siathought": (
            "_parse_sia_counts", "_event_shard_slug", "_read_event_page",
            "_bounded_event_directory_snapshot", "_event_page_state",
            "_event_day_shards", "_event_line", "_render_event_shard",
            "_event_shard_trial", "_event_source_parts", "_event_payload_digest",
            "_event_index_relative", "_canonical_event_index_entry",
            "_event_index_encoded", "_read_event_index_entry",
            "_validate_event_index_raw", "_join_event_index_occurrences",
            "_verify_event_index_entries",
            "_preflight_event_index_entries", "_publish_event_index_entries",
            "_missing_event_index_expectations", "_other_event_occurrences",
            "_retained_source_text", "_event_ids_in_source_text",
            "_reconstructed_epoch_event_ids",
            "_preflight_event_lookup", "_preflight_event_path_plan",
            "_plan_event_day_update", "update_day_page",
            "_acknowledge_consolidation_claims",
            "_advance_consolidation_scan",
            "_bind_consolidation_ledger",
            "_bounded_event_directory_entries",
            "_canonical_consolidation_day",
            "_canonical_consolidation_queue",
            "_canonical_consolidation_claims",
            "_canonical_consolidation_scan",
            "_canonical_epoch_event_ids",
            "_canonical_epoch_source_manifest",
            "_claimed_consolidation_paths",
            "_clear_consolidation_marker",
            "_consolidation_scan_debt",
            "_consolidation_scan_path",
            "_ensure_structured_consolidation_marker",
            "_epoch_exemplars", "_epoch_json_field", "_epoch_slug_for_day",
            "_event_index_entries_for_sources",
            "_fresh_consolidation_scan", "_load_consolidation_scan",
            "_mark_consolidation_applied", "_mark_consolidation_pending",
            "_merge_epoch_event_ids", "_merge_epoch_source_manifest",
            "_observe_consolidation_claims",
            "_consolidation_pending_summary",
            "_extend_consolidation_summary",
            "_render_consolidation_epoch",
            "_plan_consolidation_group",
            "_apply_consolidation_groups",
            "_execute_consolidation_claims",
            "_consolidation_day_paths",
            "_consolidation_day_lineage",
            "_consolidation_day_is_durable",
            "_read_consolidation_source",
            "_consolidation_day_items",
            "_group_consolidation_claims",
            "_unlink_consolidation_source",
            "_pending_consolidation_marker",
            "_prepare_consolidation_claims", "_read_epoch_state",
            "_recover_pending_consolidation", "_render_bounded_epoch",
            "_render_epoch_source_manifest", "_save_consolidation_scan",
            "_settle_consolidation_ledger", "_write_bounded_epoch",
            "_write_epoch_source_manifest", "consolidate_corpus",
            "_acknowledge_thought_recovery_claim",
            "_apply_thought_recovery_claim",
            "_archive_legacy_reset_path",
            "_assert_legacy_thought_directory_generation",
            "_canonical_thought_page_record",
            "_clear_legacy_thought_mind_replay_locked",
            "_clear_native_thought_mind_replay_locked",
            "_clear_thought_mind_replay_scope_locked",
            "_commit_thought_legacy_claim",
            "_current_legacy_thought_directory_generation",
            "_decode_exact_thought_page",
            "_ensure_private_recovery_directory",
            "_execute_legacy_thought_reset_locked",
            "_finalize_native_thought_mind_replay",
            "_index_legacy_thought_batch_locked",
            "_legacy_thought_claim_locked",
            "_list_thought_recovery_records_locked",
            "_load_thought_legacy_scan",
            "_mark_thought_mind_replay_applied_locked",
            "_materialize_thought_recovery_page",
            "_pending_external_thought_queue_ids",
            "_persist_thought", "_prepare_thought_recovery_claim",
            "_queue_thought_recovery", "_queued_thought_slug",
            "_read_legacy_thought_directory_page",
            "_read_thought_legacy_index_entry",
            "_read_thought_page_text",
            "_read_thought_recovery_claim",
            "_read_thought_recovery_record",
            "_remove_empty_thought_mind_replay_artifacts_locked",
            "_save_thought_legacy_scan",
            "_schedule_legacy_thought_reset_locked",
            "_sync_directory", "_thought_directory_generation",
            "_thought_legacy_catalog", "_thought_legacy_catalog_batch",
            "_thought_legacy_catalog_path",
            "_thought_legacy_index_bytes",
            "_thought_legacy_index_dir",
            "_thought_legacy_index_entry",
            "_thought_legacy_scan_path",
            "_thought_mind_replay_catalog", "_thought_mind_replay_intent",
            "_thought_mind_replay_path",
            "_thought_mind_replay_records", "_thought_page_parts",
            "_thought_queue_binding",
            "_thought_recovery_claim_basis",
            "_thought_recovery_claim_bytes",
            "_thought_recovery_claim_document",
            "_thought_recovery_claim_path",
            "_thought_recovery_debt", "_thought_recovery_dir",
            "_thought_recovery_lock_path",
            "_thought_recovery_receipt", "_thought_recovery_record",
            "_thought_recovery_record_bytes",
            "_upsert_thought_legacy_catalog",
            "_validated_thought_directory_generation",
            "_validated_thought_legacy_scan",
            "_validated_thought_recovery_receipt",
            "_write_thought_legacy_index",
            "_write_thought_recovery_claim_locked",
            "reconcile_thought_pages", "write_thought",
        ),
        "siasenses": (
            "_agent_scan_candidate", "_agent_source_capture",
            "_agent_source_capture_matches", "_agent_source_capture_valid",
            "_agent_transition_events", "_agent_usage_row_valid",
            "_normalized_agent_usage_row", "_normalized_legacy_agent_key",
            "_attest_generation", "_attest_rows",
            "_await_process_exit_unreaped", "_configured_skill_roots",
            "_custom_json_record_refusal", "_custom_match_literals",
            "_discard_skill_root_candidate",
            "_journal_abort_process", "_journal_catalog_cursor",
            "_journal_create_tmp", "_journal_file_identity", "_journal_msg",
            "_journal_refusal", "_journal_require_exact_cursor",
            "_journal_seed_cursor", "_journal_unlink_tmp", "_journalctl",
            "_journalctl_projected_records", "_journalctl_records",
            "_migrated_legacy_skill_state",
            "_legacy_notify_cursor_valid", "_list_skill_entries",
            "_new_skill_scan", "_notification_name_valid",
            "_notification_source_order", "_notify_baseline",
            "_notify_baseline_from_scan", "_notify_baseline_refusal_event",
            "_notify_filter_add", "_notify_filter_contains",
            "_notify_generation", "_notify_opaque_baseline",
            "_notify_replay_authority", "_notify_scan_candidate",
            "_notify_scan_page_authority",
            "_notify_cursor_checkpoint_safe",
            "_notify_recover_interrupted_baseline",
            "_obsidian_commit_record",
            "_obsidian_control_file", "_obsidian_git_directory_identity",
            "_obsidian_git_environment", "_obsidian_git_metadata",
            "_obsidian_object_name", "_parse_custom_json_record",
            "_parse_obsidian_git_metadata", "_queue_source_entry_refusal",
            "_read_skill_manifest", "_real_process_pid",
            "_set_worldline_cursor",
            "_normalized_session_cursor_row", "_session_cursor_row_valid",
            "_signal_and_reap_process_group", "_skill_description",
            "_skill_description_from_head", "_skill_display_name",
            "_skill_entity_token", "_skill_manifest_capture_matches",
            "_skill_manifest_identity", "_skill_manifest_state_valid",
            "_skill_name_bytes",
            "_skill_catalog_event", "_skill_positive_merge",
            "_skill_root_generation_matches", "_skill_root_id",
            "_skill_root_refusal", "_skill_snapshot_from_rows",
            "_store_agent_state", "_validated_skill_scan",
            "_validated_skill_root_history", "_validated_skill_snapshot",
            "_verified_builtin_attest_rows",
            "_worldline_cursor", "_worldline_decode_text",
            "_worldline_observation", "_worldline_observation_digest",
            "_worldline_ordering_identity", "_worldline_refusal_event",
            "_worldline_refusal_record", "_worldline_select_list",
            "_worldline_time", "sense_aegis", "sense_agents", "sense_claude",
            "sense_codex", "sense_custom", "sense_custos", "sense_git",
            "sense_guardian", "sense_jackal", "sense_journal", "sense_notify",
            "sense_obsidian", "sense_pacman", "sense_sekhmet", "sense_sia",
            "sense_skills", "sense_worldline",
            "signed_ledger_event_projection",
        ),
    }

    def _facade_child(self, name):
        # Compile the file rather than loading it through the source loader.
        # A pure-move extraction can leave both the mtime second and the byte
        # length unchanged, and a stale bin/__pycache__ entry would then
        # answer this contract instead of the file under review.  The name is
        # deliberately not the module's own: the capture rule is
        # __module__ == __name__, so the façade must hold under any alias.
        path = os.path.join(REPO, "bin", name + ".py")
        module = types.ModuleType("release_facade_" + name)
        module.__file__ = path
        exec(compile(_read_path(path), path, "exec"), module.__dict__)
        return module

    def test_facade_child_modules_are_all_pinned(self):
        # Discovery, not a hand-list: any bin module that captures its own
        # exports is a façade child, and one missing from the pin above
        # would inherit none of the guards below.
        found = set()
        for entry in sorted(os.listdir(os.path.join(REPO, "bin"))):
            if not entry.endswith(".py"):
                continue
            source = _read_path(os.path.join(REPO, "bin", entry))
            if "\n_EXPORTED_FUNCTIONS = tuple(" in source:
                found.add(os.path.splitext(entry)[0])
        self.assertEqual(found, set(self.FACADE_CHILD_EXPORTS))

    def test_facade_child_modules_export_their_pinned_functions(self):
        for name, pinned in sorted(self.FACADE_CHILD_EXPORTS.items()):
            with self.subTest(module=name):
                exported = self._facade_child(name)._EXPORTED_FUNCTIONS
                # The count is asserted first so a dropped or added export
                # fails on a readable number, and the name comparison that
                # follows names the one that moved.
                self.assertEqual(len(exported), len(pinned))
                self.assertEqual(sorted(exported), sorted(pinned))

    def test_facade_child_modules_hold_their_bind_invariants(self):
        for name in sorted(self.FACADE_CHILD_EXPORTS):
            with self.subTest(module=name):
                module = self._facade_child(name)
                exported = module._EXPORTED_FUNCTIONS
                path = os.path.join(REPO, "bin", name + ".py")
                # bind() skips _CHILD_FUNCTIONS so a parent name never
                # overwrites a child implementation, and invoke() resolves
                # only through _ORIGINAL_CHILD_FUNCTIONS.  The three views
                # must describe one set or a rebind silently drops a
                # function from the façade while sialib still delegates it.
                self.assertEqual(module._CHILD_FUNCTIONS,
                                 frozenset(exported))
                self.assertEqual(sorted(module._ORIGINAL_CHILD_FUNCTIONS),
                                 sorted(exported))
                self.assertTrue(callable(module.bind))
                self.assertTrue(callable(module.invoke))
                # The capture runs before bind()/invoke() exist and before
                # the control names are assigned.  Exporting one of them
                # would let a parent rebind replace the binding machinery
                # itself, or make sialib delegate bind() to bind().
                self.assertTrue(
                    module._BIND_CONTROL_NAMES.isdisjoint(exported),
                    sorted(module._BIND_CONTROL_NAMES.intersection(exported)))
                for export in sorted(exported):
                    with self.subTest(export=export):
                        target = module._ORIGINAL_CHILD_FUNCTIONS[export]
                        # _ORIGINAL_CHILD_FUNCTIONS is the pre-bind identity
                        # bind() restores; it must still be the plain
                        # function this file defines, never a rebound parent
                        # façade, an import, or a non-callable constant.
                        self.assertIs(target, getattr(module, export))
                        self.assertTrue(inspect.isfunction(target))
                        self.assertEqual(target.__module__, module.__name__)
                        implementation = target
                        if export in getattr(module, "_CONTEXT_EXPORTS", ()):
                            implementation = target.__wrapped__
                            self.assertTrue(inspect.isgeneratorfunction(
                                implementation))
                        self.assertEqual(
                            os.path.realpath(
                                implementation.__code__.co_filename),
                            os.path.realpath(path))
                # bind()'s delegate branch is what keeps a parent façade out
                # of the child's own calls: a value marked
                # _sia_senses_delegate must restore the child original,
                # while a plain parent replacement is mirrored so a test
                # patch reaches intra-module calls.  Assert both here so
                # every pinned child inherits the guard, not only the two
                # names ChildModuleBindSeam knows.
                def delegate():
                    def stub(*args, **kwargs):
                        raise AssertionError("delegate round-trip")
                    stub._sia_senses_delegate = True
                    return stub

                module.bind({export: delegate() for export in exported})
                for export in sorted(exported):
                    with self.subTest(delegate=export):
                        self.assertIs(
                            module.__dict__[export],
                            module._ORIGINAL_CHILD_FUNCTIONS[export])
                patches = {export: (lambda *a, **k: None)
                           for export in exported}
                module.bind(patches)
                for export in sorted(exported):
                    with self.subTest(patched=export):
                        self.assertIs(module.__dict__[export],
                                      patches[export])

    def test_facade_child_modules_import_no_sia_core_module(self):
        core = {os.path.splitext(entry)[0]
                for entry in os.listdir(os.path.join(REPO, "bin"))
                if entry.endswith(".py")}
        self.assertTrue(core.issuperset(self.FACADE_CHILD_EXPORTS))
        for name in sorted(self.FACADE_CHILD_EXPORTS):
            with self.subTest(module=name):
                path = os.path.join(REPO, "bin", name + ".py")
                imported = set()
                for node in ast.walk(ast.parse(_read_path(path), path)):
                    if isinstance(node, ast.Import):
                        imported.update(alias.name.split(".")[0]
                                        for alias in node.names)
                    elif isinstance(node, ast.ImportFrom):
                        imported.add("." * node.level
                                     + (node.module or "").split(".")[0])
                # Importing a SIA module here would build a second core with
                # its own stale STATE/CORPUS while the owner rebinds the
                # first.  Every other name a child needs (os, json, the
                # sialib constants) arrives through bind(), so the pre-bind
                # lock import is the whole import surface.
                self.assertTrue(imported.isdisjoint(core),
                                sorted(imported.intersection(core)))
                expected_imports = {"threading"}
                if name in {"siathought", "sialivepublication"}:
                    expected_imports.add("contextlib")
                if name == "siasenses":
                    expected_imports.add("errno")
                self.assertEqual(imported, expected_imports)
                # Loading the child must stay side-effect free: no SIA
                # module may reach sys.modules as a consequence.
                before = set(sys.modules)
                self._facade_child(name)
                self.assertTrue(core.isdisjoint(set(sys.modules) - before))

    def test_siathought_context_exports_are_child_owned_and_reuse_source_libc(self):
        module = self._facade_child("siathought")
        context_exports = frozenset({
            "_thought_legacy_catalog", "_thought_mind_replay_catalog",
        })
        self.assertEqual(module._CONTEXT_EXPORTS, context_exports)
        self.assertTrue(context_exports.issubset(module._CHILD_FUNCTIONS))

        core_path = os.path.join(REPO, "bin", "sialib.py")
        core_tree = ast.parse(_read_path(core_path), core_path)
        core_definitions = {
            node.name for node in ast.walk(core_tree)
            if isinstance(node, (ast.ClassDef, ast.FunctionDef,
                                 ast.AsyncFunctionDef))}
        self.assertTrue(context_exports.isdisjoint(core_definitions))
        self.assertNotIn("_ThoughtRecoveryDirent", core_definitions)
        self.assertNotIn("_THOUGHT_RECOVERY_LIBC", _read_path(core_path))

        child_path = os.path.join(REPO, "bin", "siathought.py")
        child_tree = ast.parse(_read_path(child_path), child_path)
        reader = next(
            node for node in ast.walk(child_tree)
            if isinstance(node, ast.FunctionDef)
            and node.name == "_read_legacy_thought_directory_page")
        reader_names = {
            node.id for node in ast.walk(reader) if isinstance(node, ast.Name)}
        self.assertIn("_SOURCE_LIBC", reader_names)
        self.assertNotIn("_THOUGHT_RECOVERY_LIBC", reader_names)

    def test_siathought_context_invoke_rebinds_each_protocol_phase(self):
        module = self._facade_child("siathought")
        phases = []

        class SuppressedError(Exception):
            pass

        class RecordingContext:
            def __enter__(self):
                phases.append(("enter", module.ACTIVE))
                return module.ACTIVE

            def __exit__(self, exc_type, _exc, _traceback):
                phases.append(("exit", module.ACTIVE, exc_type))
                return exc_type is SuppressedError

        def context_factory():
            phases.append(("factory", module.ACTIVE))
            return RecordingContext()

        module._ORIGINAL_CHILD_FUNCTIONS[
            "_thought_legacy_catalog"] = context_factory
        first = {"ACTIVE": "first"}
        second = {"ACTIVE": "second"}
        manager = module.invoke(first, "_thought_legacy_catalog")
        self.assertEqual(phases, [])
        module.bind(second)
        with manager as active:
            self.assertEqual(active, "first")
            module.bind(second)
            raise SuppressedError("the wrapped manager suppresses this")
        self.assertEqual(phases, [
            ("factory", "first"),
            ("enter", "first"),
            ("exit", "first", SuppressedError),
        ])


    def test_preflight_names_a_panicking_cryptography_backend(self):
        # A python-cryptography whose compiled extension does not match the
        # running interpreter fails inside its Rust extension, and pyo3
        # surfaces that as pyo3_runtime.PanicException, which derives from
        # BaseException so a panic is never silently swallowed. Catching only
        # Exception meant the one failure this preflight exists to name was
        # the one it could not name. Reported from a sandbox whose
        # _cffi_backend was built for a different Python minor version.
        installer = _read("install.sh")
        body = "preflight_python_capabilities() {" + installer.split(
            "preflight_python_capabilities() {", 1)[1].split(
                "\n}\n", 1)[0] + "\n}\n"
        self.assertIn("except BaseException as error:", body)
        self.assertNotIn("except Exception as error:", body)

        def run_preflight(root, failure):
            environment = os.environ.copy()
            environment.update({
                "PYTHONPATH": root,
                "SIA_TEST_CRYPTOGRAPHY_FAILURE": failure,
            })
            return subprocess.run(
                ["bash", "-c", "set -euo pipefail\n" + body
                 + "\npreflight_python_capabilities\n"
                 + "echo REACHED_MUTATION_PHASE"],
                env=environment, text=True, stdout=subprocess.PIPE,
                stderr=subprocess.PIPE, check=False)

        with tempfile.TemporaryDirectory() as root:
            # Preserve the historical import-panic regression.
            _write(os.path.join(root, "cryptography", "__init__.py"), "")
            _write(os.path.join(root, "cryptography", "hazmat",
                                "__init__.py"), "")
            _write(os.path.join(root, "cryptography", "hazmat", "primitives",
                                "__init__.py"),
                   'class _Panic(BaseException):\n    pass\n'
                   'raise _Panic("Python API call failed unexpectedly")\n')
            imported = run_preflight(root, "import-panic")
        self.assertNotEqual(imported.returncode, 0)
        self.assertNotIn("REACHED_MUTATION_PHASE", imported.stdout)
        self.assertIn("python-cryptography with Ed25519 support is required",
                      imported.stderr)
        self.assertNotIn("Traceback (most recent call last)", imported.stderr)

        with tempfile.TemporaryDirectory() as root:
            # Import succeeds; generate() is the compiled-backend boundary.
            for package in (
                    "cryptography", "cryptography/hazmat",
                    "cryptography/hazmat/primitives",
                    "cryptography/hazmat/primitives/asymmetric"):
                _write(os.path.join(root, package, "__init__.py"), "")
            _write(os.path.join(
                root, "cryptography", "hazmat", "primitives",
                "serialization.py"), "")
            _write(os.path.join(
                root, "cryptography", "hazmat", "primitives", "asymmetric",
                "ed25519.py"), r'''
import os

class _Panic(BaseException):
    pass

class Ed25519PrivateKey:
    @classmethod
    def generate(cls):
        failure = os.environ["SIA_TEST_CRYPTOGRAPHY_FAILURE"]
        if failure == "backend-panic":
            raise _Panic("Rust Ed25519 backend panicked")
        if failure == "keyboard-interrupt":
            raise KeyboardInterrupt("operator interrupted backend probe")
        if failure == "system-exit":
            raise SystemExit(73)
        raise AssertionError("test did not select a backend failure")

class Ed25519PublicKey:
    pass
''')
            panicked = run_preflight(root, "backend-panic")
            interrupted = run_preflight(root, "keyboard-interrupt")
            exited = run_preflight(root, "system-exit")

        self.assertNotEqual(panicked.returncode, 0)
        self.assertNotIn("REACHED_MUTATION_PHASE", panicked.stdout)
        self.assertIn("python-cryptography cannot generate, raw-serialize",
                      panicked.stderr)
        self.assertNotIn("Traceback (most recent call last)", panicked.stderr)

        self.assertNotEqual(interrupted.returncode, 0)
        self.assertNotIn("REACHED_MUTATION_PHASE", interrupted.stdout)
        self.assertIn("KeyboardInterrupt", interrupted.stderr)
        self.assertNotIn("python-cryptography cannot generate",
                         interrupted.stderr)

        self.assertEqual(exited.returncode, 73)
        self.assertNotIn("REACHED_MUTATION_PHASE", exited.stdout)
        self.assertNotIn("python-cryptography cannot generate", exited.stderr)
        self.assertEqual(
            body.count("except (KeyboardInterrupt, SystemExit):"), 2)

    def test_uninstaller_owner_lock_open_failure_is_aggregated(self):
        uninstaller = _read("uninstall.sh")
        body = uninstaller.split("acquire_owner_lock() {", 1)[1].split(
            "\n}\n\nfor dependency", 1)[0]
        function = "acquire_owner_lock() {" + body + "\n}\n"
        with tempfile.TemporaryDirectory() as root:
            script = function + r'''
set -u
failed() { printf 'failed: %s\n' "$1" >&2; }
LOCK_FD=""
if acquire_owner_lock "$WORK/missing/owner.lock" LOCK_FD corpus; then
  exit 9
fi
printf 'failure aggregated\n'
'''
            environment = os.environ.copy()
            environment["WORK"] = root
            result = subprocess.run(
                ["bash", "-c", script], env=environment, text=True,
                stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertIn("failure aggregated", result.stdout)
            self.assertIn("failed: open corpus lock", result.stderr)
            self.assertNotIn("unbound variable", result.stderr)

    def test_managed_root_symlinks_are_refused_before_external_mutation(self):
        for relative in (".config/hypr", ".claude",
                         ".local/state/sia/managed-install",
                         ".local/state/sia/managed-mcp",
                         ".local/share/sia/.gbrain/schema-packs",
                         ".local/state/sia/model-manifest-backups"):
            with self.subTest(relative=relative), \
                    tempfile.TemporaryDirectory() as root:
                home = os.path.join(root, "home")
                outside = os.path.join(root, "outside")
                os.makedirs(outside)
                sentinel = os.path.join(outside, "sentinel")
                _write(sentinel, "unchanged\n")
                target = os.path.join(home, relative)
                os.makedirs(os.path.dirname(target), exist_ok=True)
                os.symlink(outside, target)
                fake_bin = os.path.join(root, "bin")
                guard_trace = os.path.join(root, "guard-trace")
                _guard_fixture(fake_bin, guard_trace)
                environment = os.environ.copy()
                environment["HOME"] = home
                environment["PATH"] = fake_bin + os.pathsep + environment["PATH"]
                scripts = ("install.sh", "uninstall.sh") \
                    if relative in (".config/hypr", ".claude",
                                    ".local/state/sia/managed-install",
                                    ".local/state/sia/managed-mcp") \
                    else ("install.sh",)
                for script in scripts:
                    result = subprocess.run(
                        ["bash", os.path.join(REPO, script)],
                        cwd=REPO, env=environment, text=True,
                        stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                        timeout=30, check=False)
                    self.assertNotEqual(result.returncode, 0, script)
                    self.assertIn("refusing symlinked managed root", result.stderr)
                    self.assertEqual(_read_path(sentinel), "unchanged\n")
                self.assertEqual(_read_path(guard_trace), "admitted\n")

    def test_installer_guard_refusal_precedes_state_mutation(self):
        with tempfile.TemporaryDirectory() as root:
            home = os.path.join(root, "home")
            os.mkdir(home)
            fake_bin = os.path.join(root, "bin")
            trace = os.path.join(root, "guard-trace")
            _guard_fixture(fake_bin, trace, admitted=False)
            environment = os.environ.copy()
            environment.update({
                "HOME": home,
                "PATH": fake_bin + os.pathsep + environment["PATH"],
            })
            result = subprocess.run(
                ["bash", os.path.join(REPO, "install.sh")],
                cwd=REPO, env=environment, text=True,
                stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                timeout=30, check=False)
            self.assertNotEqual(result.returncode, 0)
            self.assertIn("administrator-installed local-account guard", result.stderr)
            self.assertEqual(_read_path(trace), "refused\n")
            self.assertEqual(os.listdir(home), [])

    def test_installer_refuses_nonempty_unowned_corpus(self):
        with tempfile.TemporaryDirectory() as root:
            home = os.path.join(root, "home")
            fake_bin = os.path.join(root, "bin")
            os.makedirs(fake_bin)
            _fake_command(fake_bin, "systemctl", ABSENT_USER_UNIT)
            guard_trace = os.path.join(root, "guard-trace")
            _guard_fixture(fake_bin, guard_trace)
            foreign = os.path.join(
                home, ".local/share/sia/corpus/foreign.txt")
            _write(foreign, "operator data\n")
            environment = os.environ.copy()
            environment["HOME"] = home
            environment["PATH"] = fake_bin + os.pathsep + environment["PATH"]
            result = subprocess.run(
                ["bash", os.path.join(REPO, "install.sh")],
                cwd=REPO, env=environment, text=True,
                stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                timeout=30, check=False)
            self.assertNotEqual(result.returncode, 0)
            self.assertIn("refusing nonempty corpus", result.stderr)
            self.assertEqual(_read_path(foreign), "operator data\n")
            self.assertEqual(_read_path(guard_trace), "admitted\n")

    def test_failure_cleanup_stops_mutated_runtime_without_restart(self):
        installer = _read("install.sh")
        body = installer.split("sia_install_cleanup() {", 1)[1].split(
            "\n}\ntrap sia_install_cleanup EXIT", 1)[0]
        function = (_bounded_commands_shell(installer) +
                    "\nsia_install_cleanup() {" + body + "\n}\n")
        with tempfile.TemporaryDirectory() as root:
            trace = os.path.join(root, "trace")
            script = function + r'''
run_with_deadline() { shift; "$@"; }
systemctl() {
  printf '%s\n' "$*" >> "$TRACE"
  return 0
}
SIA_INSTALL_TMP="$WORK/install-tmp"
SIA_OLLAMA_STAGE=""
SIA_PLUGIN_STAGE=""
SIA_RUNTIME_STAGE=""
SIA_BUN_STAGE=""
SIA_GBRAIN_STAGE=""
SIA_INSTALL_MUTATED=1
SIA_RESTORE_LIFECYCLE_TOMBSTONE=0
SIA_LIFECYCLE_TOMBSTONE_CLEARED=0
SIA_BRAINSTEM_FINAL_UNBARRIERED=0
SIA_BRAINSTEM_RUNTIME_BARRIER_ARMED=0
SIA_KEEP_BRAINSTEM_RUNTIME_BARRIER=0
SIA_BRAINSTEM_WAS_ACTIVE=1
SIA_BRAINSTEM_WAS_ENABLED=1
SIA_OLLAMA_SERVICE_MUTATED=1
SIA_OLLAMA_WAS_ACTIVE=0
SIA_OLLAMA_WAS_ENABLED=0
mkdir -p "$SIA_INSTALL_TMP"
false
sia_install_cleanup
'''
            environment = os.environ.copy()
            environment.update({"TRACE": trace, "WORK": root})
            result = _run_release_fragment(script, environment)
            self.assertNotEqual(result.returncode, 0)
            calls = _read_path(trace)
            self.assertIn("--user disable --now sia-brainstem.service", calls)
            self.assertNotIn("--user start sia-brainstem.service", calls)
            self.assertIn("--user disable --now ollama.service", calls)
            self.assertIn("install failed after mutation", result.stderr)

    def test_successful_barrier_discard_clears_recovery_debt(self):
        installer = _read("install.sh")
        body = installer.split(
            "discard_install_brainstem_retired_barrier() {", 1)[1].split(
                "\n}", 1)[0]
        self.assertIn(
            "SIA_KEEP_BRAINSTEM_RUNTIME_BARRIER=0", body)
        final_activation = installer.split(
            "retire_install_brainstem_runtime_barrier\n", 1)[1]
        self.assertIn(
            "discard_install_brainstem_retired_barrier", final_activation)

    def test_final_activation_failure_rearms_barrier_before_disable(self):
        installer = _read("install.sh")
        body = installer.split("sia_install_cleanup() {", 1)[1].split(
            "\n}\ntrap sia_install_cleanup EXIT", 1)[0]
        function = (_bounded_commands_shell(installer) +
                    "\nsia_install_cleanup() {" + body + "\n}\n")
        with tempfile.TemporaryDirectory() as root:
            trace = os.path.join(root, "trace")
            script = function + r'''
run_with_deadline() { shift; "$@"; }
install_brainstem_runtime_barrier() {
  echo barrier >> "$TRACE"
  SIA_BRAINSTEM_RUNTIME_BARRIER_ARMED=1
}
verify_install_brainstem_runtime_barrier() { echo verify >> "$TRACE"; }
remove_install_brainstem_runtime_barrier() {
  echo unbarrier >> "$TRACE"
  SIA_BRAINSTEM_RUNTIME_BARRIER_ARMED=0
}
systemctl() { printf 'systemctl %s\n' "$*" >> "$TRACE"; }
SIA_INSTALL_TMP="$WORK/install-tmp"
mkdir -p "$SIA_INSTALL_TMP"
SIA_OLLAMA_STAGE="" SIA_PLUGIN_STAGE="" SIA_RUNTIME_STAGE=""
SIA_BUN_STAGE="" SIA_GBRAIN_STAGE=""
SIA_INSTALL_MUTATED=1 SIA_OLLAMA_SERVICE_MUTATED=0
SIA_RESTORE_LIFECYCLE_TOMBSTONE=0 SIA_LIFECYCLE_TOMBSTONE_CLEARED=0
SIA_BRAINSTEM_FINAL_UNBARRIERED=1 SIA_BRAINSTEM_RUNTIME_BARRIER_ARMED=0
SIA_KEEP_BRAINSTEM_RUNTIME_BARRIER=0
SIA_GBRAIN_LOCK_FD="" SIA_CORPUS_LOCK_FD=""
SIA_BRAINSTEM_LOCK_FD="" SIA_INSTALL_LOCK_FD=""
false
sia_install_cleanup
'''
            environment = os.environ.copy()
            environment.update({"TRACE": trace, "WORK": root})
            result = _run_release_fragment(script, environment)
            self.assertNotEqual(result.returncode, 0)
            calls = _read_path(trace).splitlines()
            barrier = calls.index("barrier")
            disable = calls.index(
                "systemctl --user disable --now sia-brainstem.service")
            self.assertLess(barrier, disable)
            self.assertNotIn("unbarrier", calls)
            self.assertIn("re-established sia-brainstem runtime barrier",
                          result.stderr)
            self.assertIn("disabled and stopped", result.stderr)
            self.assertIn("retains its runtime start barrier", result.stderr)

    def test_ollama_runtime_and_model_store_are_fail_closed(self):
        installer = _read("install.sh")
        flattened_installer = re.sub(r"\\\n\s*", " ", installer)
        self.assertIn("https://github.com/ollama/ollama/releases/tag/v0.33.2",
                      installer)
        self.assertIn("https://registry.ollama.ai/v2/library/"
                      "nomic-embed-text/manifests/v1.5", installer)
        self.assertIn("OLLAMA_VERSION=0.33.2", installer)
        self.assertIn("SIA_ALLOW_UNPINNED_OLLAMA", installer)
        self.assertIn("effective_ollama_models_dir", installer)
        self.assertIn('open(f"/proc/{pid}/environ", "rb")', installer)
        self.assertIn('environment.get(b"OLLAMA_MODELS"', installer)
        self.assertIn('environment.get(b"HOME"', installer)
        self.assertIn('pwd.getpwuid(os.stat(f"/proc/{pid}").st_uid).pw_dir',
                      installer)
        model_dir_function = installer.split(
            "effective_ollama_models_dir()", 1)[1].split(
                "verify_ollama_model_store()", 1)[0]
        self.assertIn('python3 - "$daemon_pid"', model_dir_function)
        self.assertNotIn('python3 - "$daemon_pid" "$HOME"',
                         model_dir_function)
        self.assertIn("verify_ollama_model_store", installer)
        self.assertNotIn("rollback_model_manifest() {", installer)
        self.assertIn("rejected v1.5 manifest preserved", installer)
        self.assertIn("rejected compatibility alias preserved", installer)
        self.assertNotIn(
            'rollback_model_manifest "$NOMIC_MANIFEST"', installer)
        self.assertNotIn(
            'rollback_model_manifest "$NOMIC_ALIAS_MANIFEST"', installer)
        self.assertIn("ollama_runtime_receipt_valid", installer)
        self.assertIn("binary_sha256=", installer)
        self.assertIn('OLLAMA_RECEIPT_EXPECTED="managed-by=khephri.sia',
                      installer)
        replacement_gate = installer.split(
            "if ! ollama_runtime_receipt_valid; then", 1)[1].split(
                "  download_verified", 1)[0]
        self.assertIn('[ "${SIA_REPLACE_OLLAMA_RUNTIME:-0}" != "1" ]',
                      replacement_gate)
        self.assertNotIn("grep -q '^binary_sha256=", replacement_gate)
        self.assertIn('sha256sum "/proc/$OLLAMA_DAEMON_PID/exe"', installer)
        self.assertIn("is not running SIA's verified Ollama binary", installer)
        self.assertIn("blob size mismatch", installer)
        self.assertIn("blob digest mismatch", installer)
        self.assertIn("MAX_MODEL_MANIFEST_BYTES = 1_048_576", installer)
        self.assertIn("read_stable_bounded_regular", installer)
        self.assertIn("exceeds its byte ceiling", installer)
        self.assertIn("changed while reading", installer)
        self.assertIn("NOMIC_MANIFEST_SHA256="
                      "0a109f422b47e3a30ba2b10eca18548e944e8a23073ee3f3e947efcf3c45e59f",
                      installer)
        self.assertIn("NOMIC_MODEL=nomic-embed-text:v1.5", installer)
        self.assertIn("NOMIC_COMPAT_ALIAS=nomic-embed-text:latest", installer)
        self.assertRegex(
            flattened_installer,
            r'run_with_deadline 1800 "\$OLLAMA_BIN" cp\s+'
            r'"\$NOMIC_MODEL" "\$NOMIC_COMPAT_ALIAS"')
        self.assertIn("SIA_REPLACE_NOMIC_LATEST", installer)
        self.assertIn("--embedding-model ollama:nomic-embed-text:v1.5",
                      installer)
        self.assertNotRegex(installer,
                            r'pull\s+(?:"?nomic-embed-text"?)(?:\s|$)')

    def test_ollama_runtime_receipt_binds_owner_and_current_binary(self):
        installer = _read("install.sh")
        metadata_function = _owned_metadata_shell(installer)
        version_body = installer.split("ollama_client_version() {", 1)[1].split(
            "\n}\n\neffective_ollama_models_dir", 1)[0]
        version_function = "ollama_client_version() {" + version_body + "\n}\n"
        body = installer.split("ollama_runtime_receipt_valid() {", 1)[1].split(
            "\n}\n\n# Validate SIA's owned operator drop-in", 1)[0]
        function = "ollama_runtime_receipt_valid() {" + body + "\n}\n"
        with tempfile.TemporaryDirectory() as root:
            binary = os.path.join(root, "bin/ollama")
            receipt = os.path.join(root, ".sia-release")
            sentinel = os.path.join(root, "executed")
            _write(binary, "#!/bin/sh\n"
                   ': > "${SENTINEL:?}"\n'
                   "printf 'Warning: client version is %s\\n' "
                   '"$FAKE_VERSION"\n', 0o755)
            with open(binary, "rb") as stream:
                binary_digest = hashlib.sha256(stream.read()).hexdigest()
            expected_prefix = (
                "managed-by=khephri.sia\n"
                "version=0.33.2\n"
                "asset=ollama-linux-amd64.tar.zst\n"
                "sha256=" + "0" * 64)
            script = metadata_function + version_function + function + r'''
ollama_runtime_receipt_valid
'''
            environment = os.environ.copy()
            environment.update({
                "OLLAMA_BIN": binary,
                "OLLAMA_RECEIPT": receipt,
                "OLLAMA_VERSION": "0.33.2",
                "OLLAMA_RECEIPT_EXPECTED": expected_prefix,
                "SENTINEL": sentinel,
                "FAKE_VERSION": "0.33.2",
            })

            _write(receipt, "managed-by=khephri.sia\n")
            invalid = subprocess.run(
                ["bash", "-c", script], env=environment, text=True,
                stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
            self.assertNotEqual(invalid.returncode, 0)
            self.assertFalse(os.path.exists(sentinel))

            _write(receipt, expected_prefix +
                   f"\nbinary_sha256={binary_digest}\n")
            valid = subprocess.run(
                ["bash", "-c", script], env=environment, text=True,
                stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
            self.assertEqual(valid.returncode, 0, valid.stderr)
            self.assertTrue(os.path.exists(sentinel))
            os.unlink(sentinel)

            _write(receipt, expected_prefix.split("\n", 1)[1] +
                   f"\nbinary_sha256={binary_digest}\n")
            unmarked = subprocess.run(
                ["bash", "-c", script], env=environment, text=True,
                stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
            self.assertNotEqual(unmarked.returncode, 0)
            self.assertFalse(os.path.exists(sentinel))

            _write(receipt, expected_prefix +
                   f"\nbinary_sha256={binary_digest}\n")
            _write(binary, "locally modified runtime\n", 0o755)
            modified = subprocess.run(
                ["bash", "-c", script], env=environment, text=True,
                stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
            self.assertNotEqual(modified.returncode, 0)
            self.assertFalse(os.path.exists(sentinel))

    def test_ollama_operator_drop_in_valid_enforces_the_documented_contract(
            self):
        installer = _read("install.sh")
        body = installer.split(
            "ollama_operator_drop_in_valid() {", 1)[1].split(
                '\nOLLAMA_OPERATOR_DROP_IN_EXPECTED=""', 1)[0]
        function = "ollama_operator_drop_in_valid() {" + body

        def check(content, mode=0o644, symlink_to=None):
            with tempfile.TemporaryDirectory() as root:
                path = os.path.join(root, "sia-operator.conf")
                if symlink_to is not None:
                    target = os.path.join(root, "target.conf")
                    _write(target, symlink_to, 0o644)
                    os.symlink(target, path)
                else:
                    _write(path, content, mode)
                result = subprocess.run(
                    ["bash", "-c",
                     function + '\nollama_operator_drop_in_valid "$1"',
                     "operator-drop-in-test", path],
                    text=True, stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE, check=False, timeout=30)
                return result

        valid = check("[Service]\nEnvironment=OLLAMA_IGPU_ENABLE=1\n")
        self.assertEqual(valid.returncode, 0, valid.stderr)
        self.assertEqual(valid.stdout.strip(), "OLLAMA_IGPU_ENABLE")

        symlinked = check(None, symlink_to="[Service]\n")
        self.assertNotEqual(symlinked.returncode, 0)

        loose_mode = check(
            "[Service]\nEnvironment=OLLAMA_IGPU_ENABLE=1\n", mode=0o666)
        self.assertNotEqual(loose_mode.returncode, 0)
        self.assertIn("unsafe mode", loose_mode.stderr)

        stray_directive = check("[Service]\nExecStart=/bin/sh\n")
        self.assertNotEqual(stray_directive.returncode, 0)
        self.assertIn("unsupported line", stray_directive.stderr)

        managed_host = check(
            "[Service]\nEnvironment=OLLAMA_HOST=0.0.0.0:11434\n")
        self.assertNotEqual(managed_host.returncode, 0)
        self.assertIn("SIA-managed", managed_host.stderr)

        managed_models = check(
            "[Service]\nEnvironment=OLLAMA_MODELS=/tmp/elsewhere\n")
        self.assertNotEqual(managed_models.returncode, 0)
        self.assertIn("SIA-managed", managed_models.stderr)

        spaced_value = check(
            "[Service]\nEnvironment=OLLAMA_FOO=has space\n")
        self.assertNotEqual(spaced_value.returncode, 0)
        self.assertIn("unsupported line", spaced_value.stderr)

        command_substitution = check(
            "[Service]\nEnvironment=OLLAMA_FOO=$(evil)\n")
        self.assertNotEqual(command_substitution.returncode, 0)
        self.assertIn("unsupported line", command_substitution.stderr)

        second_section = check(
            "[Service]\nEnvironment=OLLAMA_IGPU_ENABLE=1\n"
            "[Unit]\nConditionPathExists=\n")
        self.assertNotEqual(second_section.returncode, 0)
        self.assertIn("only one [Service] section", second_section.stderr)

        oversized = check("[Service]\n" + "a" * 5000 + "\n")
        self.assertNotEqual(oversized.returncode, 0)
        self.assertIn("4096-byte ceiling", oversized.stderr)

        commented = check(
            "# SIA operator override for ollama.service\n"
            "[Service]\n"
            "Environment=OLLAMA_IGPU_ENABLE=1\n")
        self.assertEqual(commented.returncode, 0, commented.stderr)
        self.assertEqual(commented.stdout.strip(), "OLLAMA_IGPU_ENABLE")

    def test_ollama_operator_drop_in_caller_computes_expected_paths(self):
        installer = _read("install.sh")
        self.assertNotIn(
            'inspect_user_unit ollama.service OLLAMA_INSPECT || exit 1',
            installer)
        self.assertNotIn(
            'inspect_user_unit ollama.service OLLAMA_LIVE || exit 1',
            installer)
        self.assertIn(
            'inspect_user_unit ollama.service OLLAMA_INSPECT \\\n'
            '  "$OLLAMA_OPERATOR_DROP_IN_EXPECTED" no || exit 1',
            installer)
        self.assertIn(
            'inspect_user_unit ollama.service OLLAMA_LIVE \\\n'
            '  "$OLLAMA_OPERATOR_DROP_IN_EXPECTED" no || exit 1',
            installer)
        self.assertIn(
            'OLLAMA_OPERATOR_DROP_IN="$SYSTEMD_USER_DIR/ollama.service.d/'
            'sia-operator.conf"', installer)

        validator = "ollama_operator_drop_in_valid() {" + installer.split(
            "ollama_operator_drop_in_valid() {", 1)[1].split(
                '\nOLLAMA_OPERATOR_DROP_IN_EXPECTED=""', 1)[0]
        caller = installer.split(
            'OLLAMA_OPERATOR_DROP_IN_EXPECTED=""', 1)[1].split(
                '\n\ninspect_user_unit ollama.service OLLAMA_INSPECT', 1)[0]
        caller = 'OLLAMA_OPERATOR_DROP_IN_EXPECTED=""' + caller

        def run(home, drop_in_content=None, mode=0o644):
            drop_in = os.path.join(
                home, "ollama.service.d", "sia-operator.conf")
            if drop_in_content is not None:
                _write(drop_in, drop_in_content, mode)
            script = (
                'set -euo pipefail\n'
                f'OLLAMA_OPERATOR_DROP_IN={shlex.quote(drop_in)}\n'
                + validator + "\n" + caller +
                '\necho "expected=$OLLAMA_OPERATOR_DROP_IN_EXPECTED"\n')
            return subprocess.run(
                ["bash", "-c", script], text=True,
                stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                check=False, timeout=30)

        with tempfile.TemporaryDirectory() as home:
            absent = run(home)
            self.assertEqual(absent.returncode, 0, absent.stderr)
            self.assertIn("expected=\n", absent.stdout)

        with tempfile.TemporaryDirectory() as home:
            accepted = run(
                home, "[Service]\nEnvironment=OLLAMA_IGPU_ENABLE=1\n")
            self.assertEqual(accepted.returncode, 0, accepted.stderr)
            self.assertIn(
                "operator drop-in accepted: "
                + os.path.join(home, "ollama.service.d", "sia-operator.conf"),
                accepted.stdout)
            self.assertIn("environment overrides: OLLAMA_IGPU_ENABLE",
                          accepted.stdout)
            self.assertIn(
                "expected=" + os.path.join(
                    home, "ollama.service.d", "sia-operator.conf"),
                accepted.stdout)

        with tempfile.TemporaryDirectory() as home:
            refused = run(home, "[Service]\nExecStart=/bin/sh\n")
            self.assertNotEqual(refused.returncode, 0)
            self.assertIn("must contain exactly", refused.stderr)
            self.assertIn("[Service]", refused.stderr)
            self.assertIn("Environment=OLLAMA_<NAME>=<value>", refused.stderr)

    def test_ollama_inference_compute_notice_is_read_only_and_never_fails(
            self):
        installer = _read("install.sh")
        bounded = _bounded_commands_shell(installer)
        body = installer.split(
            "ollama_inference_compute_notice() {", 1)[1].split(
                "\n}\nollama_inference_compute_notice\n", 1)[0]
        function = ("ollama_inference_compute_notice() {" + body
                    + "\n}\n")
        self.assertIn(
            "\nollama_inference_compute_notice\n\nOLLAMA_MODELS_DIR=",
            installer)

        def run(fake_bin, home, mode):
            # The installer runs under errexit and pipefail; the notice
            # must survive those, not only a permissive shell.
            script = ("set -euo pipefail\n" + bounded + "\n" + function +
                      'OLLAMA_OPERATOR_DROP_IN='
                      + shlex.quote(os.path.join(
                          home, "ollama.service.d", "sia-operator.conf"))
                      + '\nollama_inference_compute_notice\n')
            environment = os.environ.copy()
            environment.update({
                "PATH": fake_bin + os.pathsep + environment["PATH"],
                "FAKE_JOURNAL_MODE": mode,
            })
            return subprocess.run(
                ["bash", "-c", script], env=environment, text=True,
                stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                check=False, timeout=30)

        with tempfile.TemporaryDirectory() as root:
            home = os.path.join(root, "home")
            fake_bin = os.path.join(root, "bin")
            os.makedirs(fake_bin)
            _fake_command(
                fake_bin, "journalctl",
                'case "$FAKE_JOURNAL_MODE" in\n'
                '  igpu)\n'
                '    echo \'msg="dropping integrated GPU; to enable, set '
                'OLLAMA_IGPU_ENABLE=1"\'\n'
                '    ;;\n'
                '  cpu)\n'
                '    echo \'msg="inference compute" library=cpu\'\n'
                '    ;;\n'
                '  gpu)\n'
                '    echo \'msg="inference compute" library=cuda\'\n'
                '    ;;\n'
                '  fail)\n'
                '    exit 1\n'
                '    ;;\n'
                '  quiet)\n'
                '    echo \'msg="listening" addr=127.0.0.1:11434\'\n'
                '    ;;\n'
                'esac\n'
                'exit 0\n')

            # A journal with no "inference compute" line at all (a rotated
            # journal, or a fresh boot) yields silence and exit 0; under
            # pipefail an empty grep once aborted the whole installer here.
            quiet = run(fake_bin, home, "quiet")
            self.assertEqual(quiet.returncode, 0, quiet.stderr)
            self.assertEqual(quiet.stdout, "")

            igpu = run(fake_bin, home, "igpu")
            self.assertEqual(igpu.returncode, 0, igpu.stderr)
            self.assertIn("declined an integrated GPU", igpu.stdout)
            self.assertIn("OLLAMA_IGPU_ENABLE=1", igpu.stdout)
            self.assertIn("[Service]", igpu.stdout)
            self.assertIn(os.path.join(
                home, "ollama.service.d", "sia-operator.conf"), igpu.stdout)
            self.assertNotIn("dropping integrated GPU", igpu.stdout)

            cpu_only = run(fake_bin, home, "cpu")
            self.assertEqual(cpu_only.returncode, 0, cpu_only.stderr)
            self.assertIn("CPU-only inference", cpu_only.stdout)
            self.assertNotIn("declined an integrated GPU", cpu_only.stdout)
            self.assertNotIn("library=cpu", cpu_only.stdout)

            gpu_present = run(fake_bin, home, "gpu")
            self.assertEqual(gpu_present.returncode, 0, gpu_present.stderr)
            self.assertEqual(gpu_present.stdout, "")

            journal_failure = run(fake_bin, home, "fail")
            self.assertEqual(journal_failure.returncode, 0,
                             journal_failure.stderr)
            self.assertEqual(journal_failure.stdout, "")

    def test_toolchain_receipts_are_validated_before_execution(self):
        installer = _read("install.sh")
        metadata_function = _owned_metadata_shell(installer)
        cases = (
            (
                "restic",
                "restic_runtime_receipt_valid",
                "\n}\nif ! restic_runtime_receipt_valid",
                {
                    "RESTIC_VERSION": "1.2.3",
                    "RESTIC_ASSET": "restic_1.2.3_linux_amd64.bz2",
                    "RESTIC_SHA256": "d" * 64,
                    "RESTIC_ARCH": "amd64",
                },
                "managed-by=khephri.sia\nversion=1.2.3\n"
                "asset=restic_1.2.3_linux_amd64.bz2\nsha256=" + "d" * 64,
                "restic 1.2.3 compiled with go-fixture on linux/amd64",
            ),
            (
                "bun",
                "bun_runtime_receipt_valid",
                "\n}\nif ! bun_runtime_receipt_valid",
                {
                    "BUN_VERSION": "1.2.3",
                    "BUN_ASSET": "bun-linux-x64.zip",
                    "BUN_SHA256": "a" * 64,
                },
                "managed-by=khephri.sia\nversion=1.2.3\n"
                "asset=bun-linux-x64.zip\nsha256=" + "a" * 64,
                "1.2.3",
            ),
            (
                "gbrain",
                "gbrain_runtime_receipt_valid",
                "\n}\nif ! gbrain_runtime_receipt_valid",
                {
                    "PIN": "b" * 40,
                    "PIN_VERSION": "4.5.6",
                    "PIN_LOCK_SHA256": "c" * 64,
                    "PIN_OVERLAY_SHA256": "d" * 64,
                    "PIN_OVERLAY_TREE_OID": "e" * 40,
                },
                "managed-by=khephri.sia\ncommit=" + "b" * 40 +
                "\nversion=4.5.6\nbun_lock_sha256=" + "c" * 64 +
                "\noverlay_sha256=" + "d" * 64 +
                "\noverlay_tree_oid=" + "e" * 40,
                "gbrain 4.5.6",
            ),
        )
        for label, function_name, end_marker, variables, prefix, version in cases:
            with self.subTest(tool=label), tempfile.TemporaryDirectory() as root:
                body = installer.split(function_name + "() {", 1)[1].split(
                    end_marker, 1)[0]
                function = function_name + "() {" + body + "\n}\n"
                binary = os.path.join(root, "bin", label)
                receipt = os.path.join(root, ".sia-release")
                sentinel = os.path.join(root, "executed")
                _write(binary, "#!/bin/sh\n"
                       f": > {shlex.quote(sentinel)}\n"
                       f"printf '%s\\n' {shlex.quote(version)}\n", 0o755)
                with open(binary, "rb") as stream:
                    digest = hashlib.sha256(stream.read()).hexdigest()
                environment = os.environ.copy()
                environment.update(variables)
                environment.update({
                    function_name.split("_runtime", 1)[0].upper() + "_BIN":
                        binary,
                    function_name.split("_runtime", 1)[0].upper() +
                    "_RECEIPT": receipt,
                    "SENTINEL": sentinel,
                    "FAKE_VERSION": version,
                })
                sterile = (
                    "GBRAIN_STERILE_ENV=(/usr/bin/env -i PATH=/usr/bin:/bin)\n"
                    if label == "gbrain" else "")
                script = (metadata_function + sterile + function + "\n" +
                          function_name + "\n")

                _write(receipt, "managed-by=khephri.sia\n")
                invalid = subprocess.run(
                    ["bash", "-c", script], env=environment, text=True,
                    stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
                self.assertNotEqual(invalid.returncode, 0)
                self.assertFalse(os.path.exists(sentinel))

                _write(receipt, prefix + f"\nbinary_sha256={digest}\n")
                valid = subprocess.run(
                    ["bash", "-c", script], env=environment, text=True,
                    stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
                self.assertEqual(valid.returncode, 0, valid.stderr)
                self.assertTrue(os.path.exists(sentinel))

        restic_gate = installer.split(
            "if ! restic_runtime_receipt_valid; then", 1)[1].split(
                "  download_verified", 1)[0]
        bun_gate = installer.split(
            "if ! bun_runtime_receipt_valid; then", 1)[1].split(
                "  download_verified", 1)[0]
        gbrain_gate = installer.split(
            "if ! gbrain_runtime_receipt_valid; then", 1)[1].split(
                "  GBRAIN_SOURCE=", 1)[0]
        for gate in (restic_gate, bun_gate, gbrain_gate):
            self.assertIn("SIA_REPLACE_TOOLCHAIN", gate)
            self.assertNotIn("grep -qx 'managed-by=khephri.sia'", gate)

    def test_standalone_plugin_snapshot_is_allowlisted_and_atomic(self):
        installer = _read("install.sh")
        desktop = installer.split('step "8/9 desktop', 1)[1].split(
            'step "9/9 agents', 1)[0]
        for relative in (
                "manifest.json", "preview.png", "Panel.qml", "Cockpit.qml", "Model.js",
                "README.md", "ROADMAP.md", "LICENSE", "SECURITY.md", "CHANGELOG.md",
                "GBRAIN_PIN", "config.example.json", "install.sh",
                "uninstall.sh", "bin", "docs", "schema-pack",
                "skill", "systemd"):
            self.assertIn(relative, desktop)
        directory_roster = re.search(
            r"PLUGIN_DIRS=\(([^)]*)\)", desktop)
        self.assertIsNotNone(directory_roster)
        for relative in shlex.split(directory_roster.group(1)):
            self.assertTrue(os.path.isdir(os.path.join(REPO, relative)))
        root_roster = re.search(
            r"PLUGIN_ROOT_FILES=\(([^)]*)\)", desktop)
        self.assertIsNotNone(root_roster)
        root_files = shlex.split(root_roster.group(1))
        self.assertIn("ROADMAP.md", root_files)
        for relative in root_files:
            self.assertTrue(os.path.isfile(os.path.join(REPO, relative)))
        self.assertIn(".khephri.sia.stage.XXXXXX", desktop)
        self.assertIn("atomic_install_tree", desktop)
        self.assertNotIn("RENAME_EXCHANGE", installer)
        self.assertIn("rename_noreplace(target_name, archive)", installer)
        self.assertIn("SIA_REPLACE_PLUGIN", desktop)
        self.assertIn("previous plugin tree retained", desktop)
        self.assertIn("__pycache__", desktop)
        self.assertNotIn('"$REPO/.git"', desktop)
        self.assertNotIn('"$REPO/tests"', desktop)
        self.assertNotIn('"$REPO/.local"', desktop)
        self.assertIn("omarchy plugin enable khephri.sia", desktop)
        self.assertNotIn("omarchy plugin enable khephri.sia 2>/dev/null || true",
                         desktop)
        self.assertIn('[ "$SIA_ORIGINAL_REPO" != "$PLUGDIR" ]', desktop)
        self.assertNotIn('[ "$REPO" != "$PLUGDIR" ]', desktop)
        self.assertIn(
            'SIA_ORIGINAL_REPO="$SIA_LIFETIME_SOURCE_ROOT_PATH"', installer)
        self.assertIn('SIA_BOUND_RELEASE_ROOT="$REPO"', installer)
        self.assertLess(
            installer.index("release_source_frontdoor snapshot"),
            installer.index("prepare_and_lock_install\n"))
        self.assertIn('release_source_frontdoor snapshot "$SIA_BOUND_RELEASE_ROOT"',
                      installer)
        self.assertIn('release_source_frontdoor verify "$SIA_BOUND_RELEASE_ROOT"',
                      installer)
        self.assertIn('"$SIA_PLUGIN_STAGE/bin/sia-setup"', desktop)

    def test_release_source_snapshot_is_bounded_and_churn_safe(self):
        installer = _read("install.sh")
        body = installer.split("release_source_frontdoor() {", 1)[1].split(
            "\n}\n\nSIA_RELEASE_FILES", 1)[0]
        function = "release_source_frontdoor() {" + body + "\n}\n"
        self.assertIn("MAX_SOURCE_FILE_BYTES = 16_777_216", function)
        self.assertIn("MAX_SOURCE_TOTAL_BYTES = 67_108_864", function)
        self.assertIn("open_absolute_directory", function)
        self.assertIn("dir_fd=parent_fd", function)
        self.assertIn("source_tree.require_unchanged()", function)
        self.assertNotIn("__pycache__", installer.split(
            "SIA_RELEASE_FILES=(", 1)[1].split("\n)", 1)[0])
        self.assertIn("docs/ARCHITECTURE.md", installer.split(
            "SIA_RELEASE_FILES=(", 1)[1].split("\n)", 1)[0])
        self.assertIn('chmod -R u+w -- "$SIA_INSTALL_TMP"', installer)

        with tempfile.TemporaryDirectory() as root:
            source = os.path.join(root, "source")
            snapshot = os.path.join(root, "snapshot")
            _write(os.path.join(source, "one"), "first\n")
            _write(os.path.join(source, "nested/two"), "second\n")
            _write(os.path.join(source, "unlisted"), "ignored\n")
            command = (function +
                       '\nrelease_source_frontdoor snapshot "$1" "$2" '
                       'one nested/two')
            captured = subprocess.run(
                ["bash", "-c", command, "snapshot-test", source, snapshot],
                text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                check=False)
            self.assertEqual(captured.returncode, 0, captured.stderr)
            self.assertEqual(_read_path(os.path.join(snapshot, "one")),
                             "first\n")
            self.assertFalse(os.path.lexists(
                os.path.join(snapshot, "unlisted")))

            _write(os.path.join(source, "one"), "concurrent update\n")
            verified = subprocess.run(
                ["bash", "-c", function +
                 '\nrelease_source_frontdoor verify "$1" "$2" '
                 'one nested/two', "snapshot-test", source, snapshot],
                text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                check=False)
            self.assertNotEqual(verified.returncode, 0)
            cleanup = subprocess.run(
                ["bash", "-c", 'chmod -R u+w -- "$1" && rm -rf -- "$1"',
                 "snapshot-cleanup", snapshot], text=True,
                stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
            self.assertEqual(cleanup.returncode, 0, cleanup.stderr)
            self.assertFalse(os.path.lexists(snapshot))

        with tempfile.TemporaryDirectory() as root:
            real_source = os.path.join(root, "real-source")
            linked_source = os.path.join(root, "linked-source")
            snapshot = os.path.join(root, "snapshot")
            _write(os.path.join(real_source, "one"), "source\n")
            os.symlink(real_source, linked_source)
            linked = subprocess.run(
                ["bash", "-c", function +
                 '\nrelease_source_frontdoor snapshot "$1" "$2" one',
                 "snapshot-test", linked_source, snapshot], text=True,
                stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
            self.assertNotEqual(linked.returncode, 0)

            os.unlink(linked_source)
            with open(os.path.join(real_source, "one"), "wb") as stream:
                stream.truncate(16_777_217)
            oversized = subprocess.run(
                ["bash", "-c", function +
                 '\nrelease_source_frontdoor snapshot "$1" "$2" one',
                 "snapshot-test", real_source, snapshot], text=True,
                stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
            self.assertNotEqual(oversized.returncode, 0)

        python_source = installer.split(
            "release_source_frontdoor() {\n"
            "  python3 - \"$@\" <<'PY'\n", 1)[1].split("\nPY\n}", 1)[0]
        with tempfile.TemporaryDirectory() as root:
            source = os.path.join(root, "source")
            snapshot = os.path.join(root, "snapshot")
            replacement = os.path.join(root, "replacement")
            _write(os.path.join(source, "one"), "stable bytes\n")
            _write(replacement, "stable bytes\n")
            real_stat = os.stat
            inspections = 0

            def replacing_stat(path, *args, **kwargs):
                nonlocal inspections
                if path == "one" and kwargs.get("dir_fd") is not None:
                    inspections += 1
                    if inspections == 3:
                        os.replace(replacement, os.path.join(source, "one"))
                return real_stat(path, *args, **kwargs)

            with mock.patch.object(sys, "argv", [
                    "release-source", "snapshot", source, snapshot, "one"]), \
                    mock.patch.object(os, "stat", replacing_stat):
                with self.assertRaises(SystemExit) as stopped:
                    exec(compile(python_source, "release-source", "exec"), {})
            self.assertNotEqual(stopped.exception.code, 0)
            if os.path.isdir(snapshot):
                subprocess.run(["chmod", "-R", "u+w", snapshot], check=True)

    def test_release_source_refuses_group_or_world_writable_inputs(self):
        installer = _read("install.sh")
        body = installer.split("release_source_frontdoor() {", 1)[1].split(
            "\n}\n\nSIA_RELEASE_FILES", 1)[0]
        function = "release_source_frontdoor() {" + body + "\n}\n"
        for boundary, relative, diagnostic in (
                ("root", "", "unsafe release-source root"),
                ("directory", "nested",
                 "unsafe release-source directory: nested"),
                ("file", "nested/two",
                 "unsafe release-source file: nested/two")):
            for writable in (stat.S_IWGRP, stat.S_IWOTH):
                with self.subTest(boundary=boundary, writable=writable), \
                        tempfile.TemporaryDirectory() as root:
                    source = os.path.join(root, "source")
                    snapshot = os.path.join(root, "snapshot")
                    _write(os.path.join(source, "one"), "first\n")
                    _write(os.path.join(source, "nested/two"), "second\n")
                    target = (source if not relative else
                              os.path.join(source, relative))
                    os.chmod(target, stat.S_IMODE(os.stat(target).st_mode)
                             | writable)
                    command = (function +
                               '\nrelease_source_frontdoor snapshot "$1" '
                               '"$2" one nested/two')
                    result = subprocess.run(
                        ["bash", "-c", command, "snapshot-test", source,
                         snapshot], text=True, stdout=subprocess.PIPE,
                        stderr=subprocess.PIPE, check=False)
                    if os.path.isdir(snapshot):
                        subprocess.run(
                            ["chmod", "-R", "u+w", snapshot], check=True)
                    self.assertNotEqual(result.returncode, 0)
                    self.assertIn(diagnostic, result.stderr)
                    self.assertFalse(os.path.lexists(snapshot))

    def test_release_source_snapshot_accepts_the_admitted_root_descriptor(self):
        installer = _read("install.sh")
        body = installer.split("release_source_frontdoor() {", 1)[1].split(
            "\n}\n\nSIA_RELEASE_FILES", 1)[0]
        function = "release_source_frontdoor() {" + body + "\n}\n"
        with tempfile.TemporaryDirectory() as root:
            source = os.path.join(root, "source")
            retired = os.path.join(root, "retired")
            snapshot = os.path.join(root, "snapshot")
            _write(os.path.join(source, "one"), "original\n")
            root_fd = os.open(
                source, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
            try:
                os.rename(source, retired)
                _write(os.path.join(source, "one"), "replacement\n")
                command = (function
                           + '\nrelease_source_frontdoor snapshot '
                             '"/proc/self/fd/$1" "$2" one')
                result = subprocess.run(
                    ["bash", "-c", command, "snapshot-test", str(root_fd),
                     snapshot], text=True, stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE, check=False,
                    pass_fds=(root_fd,))
                self.assertEqual(result.returncode, 0, result.stderr)
                self.assertEqual(_read_path(os.path.join(snapshot, "one")),
                                 "original\n")
            finally:
                os.close(root_fd)
                if os.path.isdir(snapshot):
                    subprocess.run(
                        ["chmod", "-R", "u+w", snapshot], check=True)

    def test_gbrain_config_update_is_bounded_nofollow_and_strict(self):
        installer = _read("install.sh")
        marker = ('python3 - "$GBRAIN_CONFIG_PATH" '
                  '"$GBRAIN_CONFIG_STAGE" <<\'PY\'\n')
        program = installer.split(marker, 1)[1].split("\nPY\n", 1)[0]
        self.assertIn("O_NOFOLLOW", program)
        self.assertIn("MAX_BYTES = 1_048_576", program)
        self.assertIn("generation(before) != generation(after)", program)
        self.assertIn("object_pairs_hook=unique_object", program)
        self.assertIn("allow_nan=False", program)
        block = installer.split("GBRAIN_CONFIG_EXPECTED=", 1)[1].split(
            "if ! GBRAIN_SELF_UPGRADE_MODE=", 1)[0]
        self.assertIn("owned_metadata generation", block)
        self.assertIn("owned_file_cas publish", block)
        self.assertNotIn("os.replace", program)

        with tempfile.TemporaryDirectory() as root:
            config = os.path.join(root, "config.json")
            stage = os.path.join(root, "stage")
            _write(config, '{"self_upgrade":{"mode":"auto"},"kept":1}\n',
                   0o600)
            _write(stage, "", 0o600)
            prepared = subprocess.run(
                [sys.executable, "-c", program, config, stage], text=True,
                stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
            self.assertEqual(prepared.returncode, 0, prepared.stderr)
            self.assertEqual(prepared.stdout.strip(), "publish")
            value = json.loads(_read_path(stage))
            self.assertEqual(value["self_upgrade"]["mode"], "off")
            self.assertEqual(value["kept"], 1)
            self.assertEqual(os.stat(stage).st_mode & 0o777, 0o600)
            self.assertEqual(
                json.loads(_read_path(config))["self_upgrade"]["mode"],
                "auto")

            _write(config, '{"self_upgrade":{"mode":"off"}}\n', 0o600)
            _write(stage, "", 0o600)
            unchanged = subprocess.run(
                [sys.executable, "-c", program, config, stage], text=True,
                stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
            self.assertEqual(unchanged.returncode, 0, unchanged.stderr)
            self.assertEqual(unchanged.stdout.strip(), "unchanged")

            _write(config, '{"duplicate":1,"duplicate":2}\n', 0o600)
            _write(stage, "", 0o600)
            duplicate = subprocess.run(
                [sys.executable, "-c", program, config, stage], text=True,
                stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
            self.assertNotEqual(duplicate.returncode, 0)
            self.assertIn("duplicate gbrain config key", duplicate.stderr)

            outside = os.path.join(root, "outside.json")
            _write(outside, '{"self_upgrade":{"mode":"auto"}}\n', 0o600)
            os.unlink(config)
            os.symlink(outside, config)
            _write(stage, "", 0o600)
            linked = subprocess.run(
                [sys.executable, "-c", program, config, stage], text=True,
                stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
            self.assertNotEqual(linked.returncode, 0)
            self.assertEqual(
                json.loads(_read_path(outside))["self_upgrade"]["mode"],
                "auto")

    def test_corpus_bootstrap_is_crash_resumable_and_no_clobber(self):
        installer = _read("install.sh")
        functions = ("durable_fixed_metadata_stage() {" + installer.split(
            "durable_fixed_metadata_stage() {", 1)[1].split(
                "\n}\n\nruntime_tree_digest()", 1)[0] + "\n}\n")
        tree = ("owned_tree_cas() {" + installer.split(
            "owned_tree_cas() {", 1)[1].split(
                "\n}\n\nowned_tree_generation()", 1)[0] +
                '\n}\nowned_tree_generation() { '
                'owned_tree_cas generation "$1"; }\n')
        block = ('step "4/9' + installer.split(
            'step "4/9', 1)[1].split('\nstep "5/9', 1)[0] + "\n")
        prefix = (_owned_metadata_shell(installer) + tree + functions +
                  "\nstep() { :; }\n")

        def run(home, selected_block=block, selected_functions=None,
                extra_environment=None):
            share = os.path.join(home, "share")
            state = os.path.join(home, "state")
            managed = os.path.join(state, "managed-install")
            os.makedirs(share, exist_ok=True)
            os.makedirs(managed, exist_ok=True)
            active_prefix = (prefix if selected_functions is None else
                             _owned_metadata_shell(installer) + tree +
                             selected_functions + "\nstep() { :; }\n")
            variables = f'''
SHARE={shlex.quote(share)}
STATE={shlex.quote(state)}
MANAGED_DIR={shlex.quote(managed)}
REPO={shlex.quote(REPO)}
CORPUS_RECEIPT="$MANAGED_DIR/corpus"
CORPUS_BOOTSTRAP_INTENT="$MANAGED_DIR/corpus-bootstrap"
CORPUS_ADOPTION_INTENT="$MANAGED_DIR/corpus-adoption"
SIA_CORPUS_NEEDS_RECEIPT=0
SIA_CORPUS_BOOTSTRAP_NEEDED=0
SIA_CORPUS_ADOPTION_NEEDED=0
SIA_INSTALL_LOCK_FD=installer-test
SIA_CORPUS_LOCK_FD=corpus-test
SIA_CORPUS_RECEIPT_LOCKS_HELD=1
preflight_corpus locked
'''
            environment = os.environ.copy()
            if extra_environment:
                environment.update(extra_environment)
            script = ("set -euo pipefail\n" + active_prefix + variables
                      + selected_block)
            script_path = None
            try:
                # The generated extractor is intentionally large.  Source it from
                # an owner-private file so inspectors run with ordinary stdin
                # semantics instead of inheriting the test program's script pipe.
                with tempfile.NamedTemporaryFile(
                        "w", encoding="utf-8", dir=home,
                        prefix=".corpus-bootstrap-test-", suffix=".sh",
                        delete=False) as stream:
                    script_path = stream.name
                    stream.write(script)
                # Match `bash -s corpus-bootstrap-test`: preserve its `$0` and
                # `$1` for the extracted fixture while keeping the path quoted.
                environment["SIA_TEST_CORPUS_BOOTSTRAP_SCRIPT"] = script_path
                return subprocess.run(
                    ["bash", "-c",
                     'source "$SIA_TEST_CORPUS_BOOTSTRAP_SCRIPT"',
                     "bash", "corpus-bootstrap-test"],
                    env=environment, text=True, stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE, check=False, timeout=30)
            finally:
                if script_path is not None:
                    os.unlink(script_path)

        positional_contract = (
            'test "$0" = bash\n'
            'test "$1" = corpus-bootstrap-test\n')
        with tempfile.TemporaryDirectory() as home:
            positional = run(
                home, positional_contract + block,
                extra_environment={
                    "SIA_TEST_CORPUS_BOOTSTRAP_SCRIPT": "/dev/null"})
            self.assertEqual(positional.returncode, 0, positional.stderr)

        with tempfile.TemporaryDirectory() as home:
            installed = run(home)
            self.assertEqual(installed.returncode, 0, installed.stderr)
            corpus = os.path.join(home, "share", "corpus")
            self.assertEqual(
                _read_path(os.path.join(corpus, "README.md")),
                "# SIA corpus — this machine's memory\n")
            self.assertEqual(subprocess.run(
                ["git", "-C", corpus, "show", "HEAD:README.md"],
                text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                check=False).stdout,
                "# SIA corpus — this machine's memory\n")
            self.assertEqual(run(home).returncode, 0)

        boundaries = (
            "# Durable bootstrap boundary: target directory creation is replayable.",
            "# Durable bootstrap boundary: hardened git initialization is replayable.",
            "# Durable bootstrap boundary: the exact narrow index update is replayable.",
            "# Durable bootstrap boundary: the exact genesis commit is replayable.",
            "# Durable bootstrap/adoption boundary: receipt publication is replayable.",
        )
        for boundary in boundaries:
            with self.subTest(boundary=boundary), \
                    tempfile.TemporaryDirectory() as home:
                interrupted = block.replace(boundary, "false", 1)
                failed = run(home, interrupted)
                self.assertNotEqual(failed.returncode, 0)
                resumed = run(home)
                self.assertEqual(resumed.returncode, 0, resumed.stderr)
                managed = os.path.join(home, "state", "managed-install")
                self.assertTrue(os.path.isfile(os.path.join(managed, "corpus")))
                self.assertFalse(os.path.lexists(
                    os.path.join(managed, "corpus-bootstrap")))
                self.assertFalse(any(
                    name.endswith(".stage") for name in os.listdir(managed)))

        intent_boundary = (
            "  # The durable intent precedes off-path construction.")
        self.assertIn(intent_boundary, block)
        with tempfile.TemporaryDirectory() as home:
            interrupted = block.replace(
                intent_boundary, "  false\n" + intent_boundary, 1)
            failed = run(home, interrupted)
            self.assertNotEqual(failed.returncode, 0)
            corpus = os.path.join(home, "share", "corpus")
            os.mkdir(corpus, 0o700)
            foreign = os.stat(corpus)

            refused = run(home)
            self.assertNotEqual(refused.returncode, 0)
            current = os.stat(corpus)
            self.assertEqual(
                (current.st_dev, current.st_ino),
                (foreign.st_dev, foreign.st_ino))
            managed = os.path.join(home, "state", "managed-install")
            self.assertTrue(os.path.isfile(os.path.join(
                managed, "corpus-bootstrap")))
            self.assertFalse(os.path.lexists(os.path.join(
                managed, "corpus")))

        with tempfile.TemporaryDirectory() as home:
            corpus = os.path.join(home, "share", "corpus")
            os.makedirs(corpus)
            interrupted = block.replace(
                intent_boundary, "  false\n" + intent_boundary, 1)
            failed = run(home, interrupted)
            self.assertNotEqual(failed.returncode, 0)
            prior = corpus + ".operator-prior"
            os.rename(corpus, prior)
            os.mkdir(corpus, 0o700)
            replacement = os.stat(corpus)

            refused = run(home)
            self.assertNotEqual(refused.returncode, 0)
            current = os.stat(corpus)
            self.assertEqual(
                (current.st_dev, current.st_ino),
                (replacement.st_dev, replacement.st_ino))
            self.assertFalse(os.path.lexists(os.path.join(
                home, "state", "managed-install", "corpus")))

        root_boundaries = (
            "# Durable corpus-root boundary: the intent-bound off-path tree exists.",
            "# Durable corpus-root boundary: the exact staged generation is authorized.",
            "# Durable corpus-root boundary: the no-clobber canonical rename is synced.",
            "# Durable corpus-root boundary: the canonical root identity is bound.",
        )
        for boundary in root_boundaries:
            with self.subTest(root_boundary=boundary), \
                    tempfile.TemporaryDirectory() as home:
                self.assertIn(boundary, functions)
                interrupted_functions = functions.replace(
                    boundary, "return 1\n    " + boundary, 1)
                failed = run(
                    home, selected_functions=interrupted_functions)
                self.assertNotEqual(failed.returncode, 0)

                resumed = run(home)
                self.assertEqual(resumed.returncode, 0, resumed.stderr)
                managed = os.path.join(home, "state", "managed-install")
                self.assertTrue(os.path.isfile(os.path.join(
                    managed, "corpus")))
                self.assertFalse(os.path.lexists(os.path.join(
                    managed, "corpus-bootstrap")))
                self.assertFalse(os.path.lexists(os.path.join(
                    home, "share", ".corpus-bootstrap-tree")))

        init_boundary = (
            "# Durable bootstrap boundary: hardened git initialization is replayable.")
        with tempfile.TemporaryDirectory() as home:
            raced = block.replace(
                init_boundary,
                init_boundary + '\nprintf "%s\\n" "concurrent README" > '
                '"$SHARE/corpus/README.md"', 1)
            refused = run(home, raced)
            self.assertNotEqual(refused.returncode, 0)
            self.assertEqual(_read_path(os.path.join(
                home, "share", "corpus", "README.md")),
                "concurrent README\n")

        with tempfile.TemporaryDirectory() as home:
            raced = block.replace(
                init_boundary,
                init_boundary + '\nprintf "%s\\n" "concurrent memory" > '
                '"$SHARE/corpus/operator.md"', 1)
            refused = run(home, raced)
            self.assertNotEqual(refused.returncode, 0)
            self.assertEqual(_read_path(os.path.join(
                home, "share", "corpus", "operator.md")),
                "concurrent memory\n")

        publish = ('  if ! installed="$(owned_file_cas publish "$stage" \\\n'
                   '      "$CORPUS_BOOTSTRAP_INTENT" absent)"; then')
        self.assertIn(publish, functions)
        interrupted_functions = functions.replace(
            publish, "  return 1\n" + publish, 1)
        with tempfile.TemporaryDirectory() as home:
            for _attempt in ("first", "second"):
                self.assertNotEqual(
                    run(home, selected_functions=interrupted_functions).returncode,
                    0)
            managed = os.path.join(home, "state", "managed-install")
            self.assertEqual(
                [name for name in os.listdir(managed)
                 if name == ".corpus-bootstrap.intent.stage"],
                [".corpus-bootstrap.intent.stage"])
            resumed = run(home)
            self.assertEqual(resumed.returncode, 0, resumed.stderr)

        with tempfile.TemporaryDirectory() as home:
            directory_failure = block.replace(boundaries[0], "false", 1)
            self.assertNotEqual(run(home, directory_failure).returncode, 0)
            corpus = os.path.join(home, "share", "corpus")
            subprocess.run(
                ["git", "-C", corpus, "init", "-q", "-b", "sia-genesis",
                 "--template="], check=True)
            sentinel = os.path.join(home, "hook-executed")
            hook = os.path.join(corpus, ".git", "hooks", "pre-commit")
            _write(hook, "#!/bin/sh\n: > " + shlex.quote(sentinel) + "\n",
                   0o755)
            refused = run(home)
            self.assertNotEqual(refused.returncode, 0)
            self.assertFalse(os.path.exists(sentinel))
            self.assertTrue(os.path.isfile(hook))

        with tempfile.TemporaryDirectory() as home:
            directory_failure = block.replace(boundaries[0], "false", 1)
            self.assertNotEqual(run(home, directory_failure).returncode, 0)
            corpus = os.path.join(home, "share", "corpus")
            subprocess.run(
                ["git", "-C", corpus, "init", "-q", "-b", "sia-genesis",
                 "--template="], check=True)
            config = os.path.join(corpus, ".git", "config")
            malicious = (
                "[core]\n\trepositoryformatversion = 0\n\tbare = false\n"
                "\tfsmonitor = !touch " +
                os.path.join(home, "config-executed") + "\n")
            _write(config, malicious)
            refused = run(home)
            self.assertNotEqual(refused.returncode, 0)
            self.assertEqual(_read_path(config), malicious)
            self.assertFalse(os.path.exists(
                os.path.join(home, "config-executed")))

        with tempfile.TemporaryDirectory() as home:
            directory_failure = block.replace(boundaries[0], "false", 1)
            self.assertNotEqual(run(home, directory_failure).returncode, 0)
            corpus = os.path.join(home, "share", "corpus")
            subprocess.run(
                ["git", "-C", corpus, "init", "-q", "-b", "sia-genesis",
                 "--template="], check=True)
            readme = os.path.join(corpus, "README.md")
            _write(readme, "# SIA corpus — this machine's memory\n")
            subprocess.run(["git", "-C", corpus, "add", "README.md"], check=True)
            subprocess.run(
                ["git", "-C", corpus, "-c", "user.name=Other",
                 "-c", "user.email=other@localhost", "commit", "-qm",
                 "not genesis"], check=True)
            prior = subprocess.run(
                ["git", "-C", corpus, "rev-parse", "HEAD"], text=True,
                stdout=subprocess.PIPE, check=True).stdout
            refused = run(home)
            self.assertNotEqual(refused.returncode, 0)
            current = subprocess.run(
                ["git", "-C", corpus, "rev-parse", "HEAD"], text=True,
                stdout=subprocess.PIPE, check=True).stdout
            self.assertEqual(current, prior)

        receipt_publish = (
            '  if ! installed="$(owned_file_cas publish "$stage" '
            '"$CORPUS_RECEIPT" \\\n      absent)"; then')
        self.assertIn(receipt_publish, functions)
        interrupted_receipt = functions.replace(
            receipt_publish, "  return 1\n" + receipt_publish, 1)
        with tempfile.TemporaryDirectory() as home:
            for _attempt in ("first", "second"):
                self.assertNotEqual(run(
                    home, selected_functions=interrupted_receipt).returncode, 0)
            managed = os.path.join(home, "state", "managed-install")
            self.assertEqual(
                [name for name in os.listdir(managed)
                 if name == ".corpus.receipt.stage"],
                [".corpus.receipt.stage"])
            resumed = run(home)
            self.assertEqual(resumed.returncode, 0, resumed.stderr)

        def make_operator_corpus(home):
            corpus = os.path.join(home, "share", "corpus")
            os.makedirs(corpus, exist_ok=True)
            subprocess.run(["git", "init", "-q", corpus], check=True)
            _write(os.path.join(corpus, "operator.md"), "operator memory\n")
            subprocess.run(
                ["git", "-C", corpus, "add", "operator.md"], check=True)
            subprocess.run(
                ["git", "-C", corpus, "-c", "user.name=Operator",
                 "-c", "user.email=operator@localhost", "commit", "-qm",
                 "operator genesis"], check=True)
            return corpus

        with tempfile.TemporaryDirectory() as home:
            corpus = make_operator_corpus(home)
            consent = {"SIA_ADOPT_EXISTING_CORPUS": "1"}
            interrupted = run(home, "false\n", extra_environment=consent)
            self.assertNotEqual(interrupted.returncode, 0)
            intent = os.path.join(
                home, "state", "managed-install", "corpus-adoption")
            self.assertTrue(os.path.isfile(intent))
            resumed = run(home)
            self.assertEqual(resumed.returncode, 0, resumed.stderr)
            self.assertEqual(
                _read_path(os.path.join(corpus, "operator.md")),
                "operator memory\n")

        with tempfile.TemporaryDirectory() as home:
            corpus = make_operator_corpus(home)
            consent = {"SIA_ADOPT_EXISTING_CORPUS": "1"}
            interrupted = block.replace(boundaries[-1], "false", 1)
            failed = run(home, interrupted, extra_environment=consent)
            self.assertNotEqual(failed.returncode, 0)
            managed = os.path.join(home, "state", "managed-install")
            self.assertTrue(os.path.isfile(os.path.join(managed, "corpus")))
            self.assertTrue(os.path.isfile(os.path.join(
                managed, "corpus-adoption")))

            prior = corpus + ".adoption-prior"
            os.rename(corpus, prior)
            replacement = make_operator_corpus(home)
            replacement_info = os.stat(replacement)
            refused = run(home)
            self.assertNotEqual(refused.returncode, 0)
            current = os.stat(replacement)
            self.assertEqual(
                (current.st_dev, current.st_ino),
                (replacement_info.st_dev, replacement_info.st_ino))
            self.assertTrue(os.path.isfile(os.path.join(
                managed, "corpus-adoption")))

        with tempfile.TemporaryDirectory() as home:
            corpus = make_operator_corpus(home)
            consent = {"SIA_ADOPT_EXISTING_CORPUS": "1"}
            self.assertNotEqual(
                run(home, "false\n", extra_environment=consent).returncode, 0)
            _write(os.path.join(corpus, "later.md"), "later memory\n")
            refused = run(home)
            self.assertNotEqual(refused.returncode, 0)
            self.assertEqual(
                _read_path(os.path.join(corpus, "later.md")), "later memory\n")
            self.assertFalse(os.path.exists(os.path.join(
                home, "state", "managed-install", "corpus")))

        adoption_publish = (
            '  if ! installed="$(owned_file_cas publish "$stage" \\\n'
            '      "$CORPUS_ADOPTION_INTENT" absent)"; then')
        self.assertIn(adoption_publish, functions)
        interrupted_adoption = functions.replace(
            adoption_publish, "  return 1\n" + adoption_publish, 1)
        with tempfile.TemporaryDirectory() as home:
            make_operator_corpus(home)
            consent = {"SIA_ADOPT_EXISTING_CORPUS": "1"}
            for _attempt in ("first", "second"):
                self.assertNotEqual(run(
                    home, selected_functions=interrupted_adoption,
                    extra_environment=consent).returncode, 0)
            managed = os.path.join(home, "state", "managed-install")
            self.assertEqual(
                [name for name in os.listdir(managed)
                 if name == ".corpus-adoption.intent.stage"],
                [".corpus-adoption.intent.stage"])
            resumed = run(home, extra_environment=consent)
            self.assertEqual(resumed.returncode, 0, resumed.stderr)

    def test_earlier_pin_toolchain_receipt_rebuilds_without_replacement_consent(self):
        """A release that moves the gbrain/bun/restic pin must rebuild a tree
        that carries a genuine SIA receipt for the earlier pin; only an
        unreceipted, foreign or torn tree still needs SIA_REPLACE_TOOLCHAIN=1."""
        installer = _read("install.sh")
        metadata = _owned_metadata_shell(installer)
        for label in ("restic", "Bun", "gbrain"):
            block = installer.split(
                f'echo "existing private {label} tree lacks an exact current '
                'release receipt; preserved" >&2', 1)[0][-700:]
            self.assertIn("owned_metadata prior-release", block, label)
            # One backslash continues the echo; a doubled one once turned the
            # notice into a command and failed the install mid-transaction.
            self.assertIn('earlier pin;" \\\n        "rebuilding for this release',
                          block, label)
            self.assertNotIn('pin;" \\\\\n', block, label)

        def probe(home, receipt_text, *, binary_bytes=b"engine"):
            root = os.path.join(home, "tool")
            os.makedirs(os.path.join(root, "bin"))
            binary = os.path.join(root, "bin", "tool")
            with open(binary, "wb") as stream:
                stream.write(binary_bytes)
            os.chmod(binary, 0o755)
            receipt = os.path.join(root, ".sia-release")
            _write(receipt, receipt_text, 0o644)
            script = (metadata + "\nowned_metadata prior-release "
                      + shlex.quote(receipt) + " " + shlex.quote(binary) + "\n")
            return subprocess.run(["bash", "-s"], input=script, text=True,
                                  stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                  check=False, timeout=30).returncode

        digest = hashlib.sha256(b"engine").hexdigest()
        earlier = ("managed-by=khephri.sia\ncommit=7b7921d8\nversion=0.47.6.0\n"
                   "bun_lock_sha256=d9f9\noverlay_sha256=91ba1c7d\n"
                   f"overlay_tree_oid=0436748d\nbinary_sha256={digest}\n")
        with tempfile.TemporaryDirectory() as home:
            self.assertEqual(probe(home, earlier), 0)
        with tempfile.TemporaryDirectory() as home:
            self.assertNotEqual(probe(home, earlier.replace("khephri.sia", "other")), 0)
        with tempfile.TemporaryDirectory() as home:
            self.assertNotEqual(probe(home, earlier, binary_bytes=b"replaced"), 0)
        with tempfile.TemporaryDirectory() as home:
            self.assertNotEqual(probe(home, earlier.rstrip("\n")), 0)
        with tempfile.TemporaryDirectory() as home:
            self.assertNotEqual(probe(home, earlier.replace(
                "version=0.47.6.0\n", "version=0.47.6.0\nrm -rf /\n")), 0)

    def test_installer_retires_the_controller_lane_only_by_consent_before_first_light(self):
        installer = _read("install.sh")
        block = installer.split('if [ "${SIA_RETIRE_CONTROLLER_SOURCE:-0}" = 1 ]; then', 1)[1]
        self.assertIn('python3 "$BINDIR/sia-cli" controller retire --yes', block.split("fi\n", 1)[0])
        self.assertLess(installer.index('SIA_RETIRE_CONTROLLER_SOURCE:-0'),
                        installer.index('SIA_BACKFILL=1 python3 "$BINDIR/sia-cli" pulse'))
        self.assertGreater(installer.index('SIA_RETIRE_CONTROLLER_SOURCE:-0'),
                           installer.index('python3 "$BINDIR/sia-cli" readmit --yes'))

    def test_existing_plugin_tree_is_named_before_the_first_mutation(self):
        """Step 8 refuses to replace a user-editable plugin tree without
        SIA_REPLACE_PLUGIN=1. On the maintainer machine that refusal came
        after a thirty-minute first light and left the brainstem disabled.
        A read-only preflight names it before step 1 and changes nothing."""
        installer = _read("install.sh")
        self.assertLess(installer.index("preflight_corpus read-only\npreflight_plugin_tree\n"),
                        installer.index('step "1/9'))
        function = "preflight_plugin_tree() {" + installer.split(
            "preflight_plugin_tree() {", 1)[1].split("\n}\n", 1)[0] + "\n}\n"
        self.assertNotRegex(function, r"\b(rm|mv|cp|mkdir|ln|chmod|touch|>|>>)\b")

        def run(home, *, original, replace=None, omarchy=True):
            plugdir = os.path.join(home, ".config", "omarchy", "plugins", "khephri.sia")
            script = (
                "set -euo pipefail\n"
                f"HOME={shlex.quote(home)}\n"
                f"SIA_ORIGINAL_REPO={shlex.quote(original)}\n"
                + (f"SIA_REPLACE_PLUGIN={replace}\n" if replace is not None
                   else "unset SIA_REPLACE_PLUGIN\n")
                + ("have() { [ \"$1\" = omarchy ]; }\n" if omarchy
                   else "have() { return 1; }\n")
                + function + "preflight_plugin_tree\n")
            result = subprocess.run(
                ["bash", "-s", "plugin-preflight-test"], input=script, text=True,
                stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False, timeout=30)
            return result, plugdir

        with tempfile.TemporaryDirectory() as home:
            checkout = os.path.join(home, "checkout")
            os.makedirs(checkout)
            absent, plugdir = run(home, original=checkout)
            self.assertEqual(absent.returncode, 0, absent.stderr)
            os.makedirs(plugdir)
            before = sorted(os.listdir(os.path.dirname(plugdir)))
            refused, _ = run(home, original=checkout)
            self.assertNotEqual(refused.returncode, 0)
            self.assertIn("existing Omarchy plugin tree is user-editable; preserved: " + plugdir,
                          refused.stderr)
            self.assertIn("SIA_REPLACE_PLUGIN=1 ./install.sh", refused.stderr)
            self.assertIn("omarchy plugin update khephri.sia", refused.stderr)
            self.assertEqual(sorted(os.listdir(os.path.dirname(plugdir))), before)
            consented, _ = run(home, original=checkout, replace=1)
            self.assertEqual(consented.returncode, 0, consented.stderr)
            self.assertIn("replaced by operator consent", consented.stdout)
            # The plugin's own install.sh (marketplace flow) is not gated.
            own, _ = run(home, original=plugdir)
            self.assertEqual(own.returncode, 0, own.stderr)
            # Without omarchy there is no plugin step to gate.
            headless, _ = run(home, original=checkout, omarchy=False)
            self.assertEqual(headless.returncode, 0, headless.stderr)
            # A symlink or file where the tree should be is refused as unsafe.
            os.rmdir(plugdir)
            os.symlink(checkout, plugdir)
            unsafe, _ = run(home, original=checkout, replace=1)
            self.assertNotEqual(unsafe.returncode, 0)
            self.assertIn("existing Omarchy plugin path is unsafe", unsafe.stderr)

    def test_moved_corpus_receipt_is_named_and_rebound_only_by_consent(self):
        """A v2 receipt whose root no longer matches the live corpus (rsync,
        btrfs subvolume, restore by copy) is recognized as `moved`, named
        with both identities, and re-bound only under explicit consent."""
        installer = _read("install.sh")
        metadata = _owned_metadata_shell(installer)
        tree = ("owned_tree_cas() {" + installer.split(
            "owned_tree_cas() {", 1)[1].split(
                "\n}\n\nowned_tree_generation()", 1)[0] +
                '\n}\nowned_tree_generation() { '
                'owned_tree_cas generation "$1"; }\n')
        functions = ("durable_fixed_metadata_stage() {" + installer.split(
            "durable_fixed_metadata_stage() {", 1)[1].split(
                "\n}\n\nruntime_tree_digest()", 1)[0] + "\n}\n")
        # The readmission runs before the first-light pulse, under the same
        # consent variable, and never silently.
        readmit = installer.index('python3 "$BINDIR/sia-cli" readmit --yes')
        report = installer.index('python3 "$BINDIR/sia-cli" readmit || {', readmit)
        pulse = installer.index(
            'SIA_BACKFILL=1 python3 "$BINDIR/sia-cli" pulse', report)
        self.assertLess(readmit, report)
        self.assertLess(report, pulse)
        self.assertIn('if [ "${SIA_READMIT_MOVED_STORAGE:-0}" = 1 ]; then',
                      installer[readmit - 400:readmit])

        def prepare(home, recorded_root):
            share = os.path.join(home, "share")
            managed = os.path.join(home, "state", "managed-install")
            corpus = os.path.join(share, "corpus")
            os.makedirs(corpus, mode=0o700)
            os.makedirs(managed)
            receipt = os.path.join(managed, "corpus")
            stale = ("managed-by=khephri.sia\nkind=corpus-v2\n"
                     f"path={corpus}\nroot={recorded_root}\n")
            _write(receipt, stale, 0o600)
            observed = os.stat(corpus)
            live_root = (f"{observed.st_dev}:{observed.st_ino}:"
                         f"{observed.st_mode}:{observed.st_uid}")
            return managed, corpus, receipt, stale, live_root

        def run(home, command, *, locked=False, consent=False,
                early_state="absent", early_root="", early_generation=""):
            share = os.path.join(home, "share")
            managed = os.path.join(home, "state", "managed-install")
            variables = f'''
SHARE={shlex.quote(share)}
STATE={shlex.quote(os.path.join(home, "state"))}
MANAGED_DIR={shlex.quote(managed)}
CORPUS_RECEIPT="$MANAGED_DIR/corpus"
CORPUS_BOOTSTRAP_INTENT="$MANAGED_DIR/corpus-bootstrap"
CORPUS_ADOPTION_INTENT="$MANAGED_DIR/corpus-adoption"
CORPUS_BOOTSTRAP_STAGE="$SHARE/.corpus-bootstrap-tree"
SIA_INSTALL_LOCK_FD={"installer-test" if locked else ""}
SIA_CORPUS_LOCK_FD={"corpus-test" if locked else ""}
SIA_CORPUS_RECEIPT_LOCKS_HELD={1 if locked else 0}
SIA_CORPUS_EARLY_RECEIPT_STATE={early_state}
SIA_CORPUS_EARLY_RECEIPT_ROOT={shlex.quote(early_root)}
SIA_CORPUS_EARLY_RECEIPT_GENERATION={shlex.quote(early_generation)}
SIA_CORPUS_EARLY_RECEIPT_JOURNAL_STATE=absent
{"SIA_READMIT_MOVED_STORAGE=1" if consent else "unset SIA_READMIT_MOVED_STORAGE"}
'''
            script = ("set -euo pipefail\n" + metadata + tree + functions
                      + variables + command)
            return subprocess.run(
                ["bash", "-s", "moved-receipt-test"], input=script, text=True,
                stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False,
                timeout=30)

        stale_root = "66306:3710730:16877:1000"
        with tempfile.TemporaryDirectory() as home:
            managed, corpus, receipt, stale, live_root = prepare(home, stale_root)
            self.assertNotEqual(live_root, stale_root)
            state = run(home, 'corpus_receipt_state\n')
            self.assertEqual(state.returncode, 0, state.stderr)
            self.assertEqual(state.stdout.strip(), "moved")
            recorded = run(home, 'corpus_receipt_recorded_root\n')
            self.assertEqual(recorded.stdout.strip(), stale_root)

            refused = run(home, 'preflight_corpus read-only\n')
            self.assertNotEqual(refused.returncode, 0)
            self.assertIn(f"corpus receipt binds root {stale_root} but the live "
                          f"corpus root is {live_root}", refused.stderr)
            self.assertIn("SIA_READMIT_MOVED_STORAGE=1 ./install.sh", refused.stderr)
            self.assertIn("sia readmit --yes", refused.stderr)
            self.assertNotIn("existing corpus receipt is invalid", refused.stderr)
            self.assertEqual(_read_path(receipt), stale)

            consented = run(
                home,
                'preflight_corpus read-only\n'
                'test "$SIA_CORPUS_EARLY_RECEIPT_STATE" = moved\n'
                'test "$SIA_CORPUS_EARLY_RECEIPT_ROOT" = ' + shlex.quote(live_root)
                + '\n', consent=True)
            self.assertEqual(consented.returncode, 0, consented.stderr)
            self.assertIn("re-bound by operator consent", consented.stdout)
            self.assertEqual(_read_path(receipt), stale)

            # The locked migration refuses without consent and re-binds with it.
            generation = run(home, 'owned_metadata generation "$CORPUS_RECEIPT"\n')
            self.assertEqual(generation.returncode, 0, generation.stderr)
            unconsented = run(
                home, "migrate_legacy_corpus_receipt\n", locked=True,
                early_state="moved", early_root=live_root,
                early_generation=generation.stdout.strip())
            self.assertNotEqual(unconsented.returncode, 0)
            self.assertIn("SIA_READMIT_MOVED_STORAGE=1", unconsented.stderr)
            self.assertEqual(_read_path(receipt), stale)
            migrated = run(
                home, "migrate_legacy_corpus_receipt\ncorpus_receipt_state\n",
                locked=True, consent=True, early_state="moved",
                early_root=live_root, early_generation=generation.stdout.strip())
            self.assertEqual(migrated.returncode, 0, migrated.stderr)
            self.assertIn(f"root {stale_root} -> {live_root}", migrated.stdout)
            self.assertEqual(migrated.stdout.strip().splitlines()[-1], "v2")
            self.assertEqual(
                _read_path(receipt),
                "managed-by=khephri.sia\nkind=corpus-v2\n"
                f"path={corpus}\nroot={live_root}\n")
            self.assertEqual(
                sorted(name for name in os.listdir(managed)
                       if not name.startswith(".sia-cas-lock-")),
                ["corpus"])
            valid = run(home, 'corpus_receipt_valid\n')
            self.assertEqual(valid.returncode, 0, valid.stderr)

        with tempfile.TemporaryDirectory() as home:
            # A receipt for another path is not "moved"; it stays invalid.
            managed, corpus, receipt, _stale, _live = prepare(home, stale_root)
            _write(receipt, "managed-by=khephri.sia\nkind=corpus-v2\n"
                   f"path={corpus}-other\nroot={stale_root}\n", 0o600)
            state = run(home, 'corpus_receipt_state\n')
            self.assertNotEqual(state.returncode, 0)
            refused = run(home, 'preflight_corpus read-only\n', consent=True)
            self.assertNotEqual(refused.returncode, 0)
            self.assertIn("existing corpus receipt is invalid", refused.stderr)

    def test_corpus_receipt_v2_is_root_bound_and_lock_migrated(self):
        installer = _read("install.sh")
        metadata = _owned_metadata_shell(installer)
        tree = ("owned_tree_cas() {" + installer.split(
            "owned_tree_cas() {", 1)[1].split(
                "\n}\n\nowned_tree_generation()", 1)[0] +
                '\n}\nowned_tree_generation() { '
                'owned_tree_cas generation "$1"; }\n')
        functions = ("durable_fixed_metadata_stage() {" + installer.split(
            "durable_fixed_metadata_stage() {", 1)[1].split(
                "\n}\n\nruntime_tree_digest()", 1)[0] + "\n}\n")

        early = installer.index("preflight_corpus read-only")
        lifecycle = installer.index("acquire_install_lifecycle", early)
        corpus_lock = installer.index(
            'acquire_owner_lock "$STATE/corpus-owner.lock"', lifecycle)
        lock_state = installer.index(
            "SIA_CORPUS_RECEIPT_LOCKS_HELD=1", corpus_lock)
        migration = installer.index("migrate_legacy_corpus_receipt", lock_state)
        locked = installer.index("preflight_corpus locked", migration)
        self.assertLess(early, lifecycle)
        self.assertLess(lifecycle, corpus_lock)
        self.assertLess(corpus_lock, lock_state)
        self.assertLess(lock_state, migration)
        self.assertLess(migration, locked)
        read_only = installer.split("preflight_corpus_read_only() {", 1)[1] \
            .split("\n}\n\npreflight_corpus()", 1)[0]
        self.assertNotIn("owned_file_cas", read_only)
        self.assertNotIn("retire_corpus", read_only)
        self.assertNotIn("write_corpus", read_only)

        def prepare(home):
            share = os.path.join(home, "share")
            managed = os.path.join(home, "state", "managed-install")
            corpus = os.path.join(share, "corpus")
            os.makedirs(corpus, mode=0o700)
            os.makedirs(managed)
            receipt = os.path.join(managed, "corpus")
            legacy = ("managed-by=khephri.sia\nkind=corpus\n"
                      f"path={corpus}\n")
            _write(receipt, legacy, 0o600)
            return share, managed, corpus, receipt, legacy

        def run(home, command, *, locked=False, selected_metadata=metadata,
                selected_functions=functions):
            share = os.path.join(home, "share")
            managed = os.path.join(home, "state", "managed-install")
            variables = f'''
SHARE={shlex.quote(share)}
STATE={shlex.quote(os.path.join(home, "state"))}
MANAGED_DIR={shlex.quote(managed)}
CORPUS_RECEIPT="$MANAGED_DIR/corpus"
CORPUS_BOOTSTRAP_INTENT="$MANAGED_DIR/corpus-bootstrap"
CORPUS_ADOPTION_INTENT="$MANAGED_DIR/corpus-adoption"
CORPUS_BOOTSTRAP_STAGE="$SHARE/.corpus-bootstrap-tree"
SIA_INSTALL_LOCK_FD={"installer-test" if locked else ""}
SIA_CORPUS_LOCK_FD={"corpus-test" if locked else ""}
SIA_CORPUS_RECEIPT_LOCKS_HELD={1 if locked else 0}
SIA_CORPUS_EARLY_RECEIPT_STATE=absent
SIA_CORPUS_EARLY_RECEIPT_ROOT=""
SIA_CORPUS_EARLY_RECEIPT_GENERATION=""
SIA_CORPUS_EARLY_RECEIPT_JOURNAL_STATE=absent
'''
            locked_preflight = "preflight_corpus read-only\n" if locked else ""
            script = ("set -euo pipefail\n" + selected_metadata + tree
                      + selected_functions + variables + locked_preflight
                      + command)
            return subprocess.run(
                ["bash", "-s", "corpus-receipt-test"], input=script,
                text=True,
                stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False,
                timeout=30)

        with tempfile.TemporaryDirectory() as home:
            _, managed, corpus, receipt, legacy = prepare(home)
            observed = os.stat(corpus)
            expected = (
                "managed-by=khephri.sia\nkind=corpus-v2\n"
                f"path={corpus}\nroot={observed.st_dev}:{observed.st_ino}:"
                f"{observed.st_mode}:{observed.st_uid}\n")

            recognized = run(
                home,
                'preflight_corpus read-only\n'
                'test "$SIA_CORPUS_EARLY_RECEIPT_STATE" = legacy\n'
                'test -n "$SIA_CORPUS_EARLY_RECEIPT_ROOT"\n'
                'test -n "$SIA_CORPUS_EARLY_RECEIPT_GENERATION"\n')
            self.assertEqual(recognized.returncode, 0, recognized.stderr)
            self.assertEqual(_read_path(receipt), legacy)
            self.assertFalse(os.path.lexists(os.path.join(
                managed, ".corpus.receipt.stage")))

            unlocked = run(home, "migrate_legacy_corpus_receipt\n")
            self.assertNotEqual(unlocked.returncode, 0)
            self.assertEqual(_read_path(receipt), legacy)

            migrated = run(
                home, "migrate_legacy_corpus_receipt\ncorpus_receipt_valid\n",
                locked=True)
            self.assertEqual(migrated.returncode, 0, migrated.stderr)
            self.assertEqual(_read_path(receipt), expected)
            self.assertFalse(os.path.lexists(os.path.join(
                managed, ".corpus.receipt.stage")))

            _write(os.path.join(corpus, "ordinary-memory.md"), "changed\n")
            still_valid = run(home, "corpus_receipt_valid\n")
            self.assertEqual(still_valid.returncode, 0, still_valid.stderr)

            prior = corpus + ".operator-prior"
            os.rename(corpus, prior)
            os.mkdir(corpus, 0o700)
            replacement = os.stat(corpus)
            refused = run(home, "corpus_receipt_valid\n")
            self.assertNotEqual(refused.returncode, 0)
            refused = run(
                home, "migrate_legacy_corpus_receipt\n", locked=True)
            self.assertNotEqual(refused.returncode, 0)
            current = os.stat(corpus)
            self.assertEqual((current.st_dev, current.st_ino),
                             (replacement.st_dev, replacement.st_ino))
            self.assertEqual(_read_path(receipt), expected)

        with tempfile.TemporaryDirectory() as home:
            _, _, corpus, receipt, legacy = prepare(home)
            prior = corpus + ".prelock-observed"
            replaced = run(
                home,
                f'mv -- {shlex.quote(corpus)} {shlex.quote(prior)}\n'
                f'mkdir -m 700 -- {shlex.quote(corpus)}\n'
                'migrate_legacy_corpus_receipt\n',
                locked=True)
            self.assertNotEqual(replaced.returncode, 0)
            self.assertEqual(_read_path(receipt), legacy)
            self.assertTrue(os.path.isdir(corpus))
            self.assertFalse(os.path.lexists(os.path.join(
                home, "state", "managed-install", ".corpus.receipt.stage")))

        with tempfile.TemporaryDirectory() as home:
            _, managed, _, receipt, legacy = prepare(home)
            observed_receipt = receipt + ".prelock-observed"
            disappeared = run(
                home,
                f'mv -- {shlex.quote(receipt)} '
                f'{shlex.quote(observed_receipt)}\n'
                'migrate_legacy_corpus_receipt\n',
                locked=True)
            self.assertNotEqual(disappeared.returncode, 0)
            self.assertFalse(os.path.lexists(receipt))
            self.assertEqual(_read_path(observed_receipt), legacy)
            self.assertFalse(os.path.lexists(os.path.join(
                managed, ".corpus.receipt.stage")))

        continuity_boundary = (
            "  # Locked corpus-receipt boundary: continuity remains the "
            "publication baseline.")
        self.assertIn(continuity_boundary, functions)
        swapped_functions = functions.replace(
            continuity_boundary,
            '  cp -- "$CORPUS_RECEIPT" "$CORPUS_RECEIPT.swap"\n'
            '  chmod 0600 "$CORPUS_RECEIPT.swap"\n'
            '  mv -- "$CORPUS_RECEIPT.swap" "$CORPUS_RECEIPT"\n' +
            continuity_boundary, 1)
        with tempfile.TemporaryDirectory() as home:
            _, managed, _, receipt, legacy = prepare(home)
            swapped = run(
                home, "migrate_legacy_corpus_receipt\n", locked=True,
                selected_functions=swapped_functions)
            self.assertNotEqual(swapped.returncode, 0)
            self.assertEqual(_read_path(receipt), legacy)
            self.assertFalse(os.path.lexists(os.path.join(
                managed, ".corpus.receipt.stage")))

        with tempfile.TemporaryDirectory() as home:
            share = os.path.join(home, "share")
            managed = os.path.join(home, "state", "managed-install")
            corpus = os.path.join(share, "corpus")
            os.makedirs(corpus, mode=0o700)
            os.makedirs(managed)
            appeared = run(
                home,
                'payload="$(corpus_v2_receipt_payload '
                '\"$(corpus_root_identity)\")"\n'
                'durable_fixed_metadata_stage "$CORPUS_RECEIPT" "$payload"\n'
                'migrate_legacy_corpus_receipt\n',
                locked=True)
            self.assertNotEqual(appeared.returncode, 0)
            self.assertIn("kind=corpus-v2\n", _read_path(os.path.join(
                managed, "corpus")))

        with tempfile.TemporaryDirectory() as home:
            _, _, _, receipt, _ = prepare(home)
            migrated = run(
                home, "migrate_legacy_corpus_receipt\n", locked=True)
            self.assertEqual(migrated.returncode, 0, migrated.stderr)
            observed_receipt = receipt + ".prelock-observed"
            disappeared = run(
                home,
                f'mv -- {shlex.quote(receipt)} '
                f'{shlex.quote(observed_receipt)}\n'
                'migrate_legacy_corpus_receipt\n',
                locked=True)
            self.assertNotEqual(disappeared.returncode, 0)
            self.assertFalse(os.path.lexists(receipt))
            self.assertIn("kind=corpus-v2\n", _read_path(observed_receipt))

        with tempfile.TemporaryDirectory() as home:
            _, _, _, receipt, _ = prepare(home)
            migrated = run(
                home, "migrate_legacy_corpus_receipt\n", locked=True)
            self.assertEqual(migrated.returncode, 0, migrated.stderr)
            replacement = receipt + ".replacement"
            replaced = run(
                home,
                f'cp -- {shlex.quote(receipt)} {shlex.quote(replacement)}\n'
                f'chmod 0600 -- {shlex.quote(replacement)}\n'
                f'mv -- {shlex.quote(replacement)} {shlex.quote(receipt)}\n'
                'migrate_legacy_corpus_receipt\n',
                locked=True)
            self.assertNotEqual(replaced.returncode, 0)
            self.assertIn("kind=corpus-v2\n", _read_path(receipt))

        with tempfile.TemporaryDirectory() as home:
            _, _, corpus, receipt, _ = prepare(home)
            migrated = run(
                home, "migrate_legacy_corpus_receipt\n", locked=True)
            self.assertEqual(migrated.returncode, 0, migrated.stderr)
            bound = _read_path(receipt)
            os.chmod(corpus, 0o770)
            self.assertNotEqual(
                run(home, "corpus_receipt_valid\n").returncode, 0)
            self.assertNotEqual(run(
                home, "migrate_legacy_corpus_receipt\n",
                locked=True).returncode, 0)
            self.assertEqual(_read_path(receipt), bound)

        crash_point = (
            "            rename_noreplace(target_name, archive_name)\n"
            "            sync_parent()\n"
            "            archived = token(\n")
        self.assertIn(crash_point, metadata)
        interrupted_metadata = metadata.replace(
            crash_point,
            "            rename_noreplace(target_name, archive_name)\n"
            "            sync_parent()\n"
            "            raise SystemExit('fixture crash after archival')\n"
            "            archived = token(\n", 1)
        with tempfile.TemporaryDirectory() as home:
            _, managed, _, receipt, _ = prepare(home)
            interrupted = run(
                home, "migrate_legacy_corpus_receipt\n", locked=True,
                selected_metadata=interrupted_metadata)
            self.assertNotEqual(interrupted.returncode, 0)
            self.assertFalse(os.path.lexists(receipt))
            stage = os.path.join(managed, ".corpus.receipt.stage")
            self.assertTrue(os.path.isfile(stage))

            inspected = run(home, "preflight_corpus read-only\n")
            self.assertEqual(inspected.returncode, 0, inspected.stderr)
            self.assertFalse(os.path.lexists(receipt))
            self.assertTrue(os.path.isfile(stage))

            resumed = run(
                home, "migrate_legacy_corpus_receipt\ncorpus_receipt_valid\n",
                locked=True)
            self.assertEqual(resumed.returncode, 0, resumed.stderr)
            self.assertTrue(os.path.isfile(receipt))
            self.assertFalse(os.path.lexists(stage))

        boundary = (
            "  # Durable corpus-receipt migration boundary: v2 is canonical.")
        self.assertIn(boundary, functions)
        interrupted_functions = functions.replace(
            boundary, "  return 1\n" + boundary, 1)
        with tempfile.TemporaryDirectory() as home:
            _, managed, _, receipt, legacy = prepare(home)
            interrupted = run(
                home, "migrate_legacy_corpus_receipt\n", locked=True,
                selected_functions=interrupted_functions)
            self.assertNotEqual(interrupted.returncode, 0)
            self.assertIn("kind=corpus-v2\n", _read_path(receipt))
            stage = os.path.join(managed, ".corpus.receipt.stage")
            self.assertEqual(_read_path(stage), legacy)

            inspected = run(home, "preflight_corpus read-only\n")
            self.assertEqual(inspected.returncode, 0, inspected.stderr)
            self.assertEqual(_read_path(stage), legacy)

            archive_crash_point = (
                "        rename_noreplace(archive_name, staged_name)\n"
                "        sync_parent()\n"
                "        if not moved_token_matches(\n")
            self.assertIn(archive_crash_point, metadata)
            archive_interrupted_metadata = metadata.replace(
                archive_crash_point,
                "        rename_noreplace(archive_name, staged_name)\n"
                "        sync_parent()\n"
                "        raise SystemExit('fixture crash after archive')\n"
                "        if not moved_token_matches(\n",
                1)
            retired = os.path.join(managed, ".corpus.receipt.retired")
            retirement_interrupted = run(
                home, "migrate_legacy_corpus_receipt\n", locked=True,
                selected_metadata=archive_interrupted_metadata)
            self.assertNotEqual(retirement_interrupted.returncode, 0)
            self.assertFalse(os.path.lexists(stage))
            self.assertEqual(_read_path(retired), legacy)
            inspected = run(home, "preflight_corpus read-only\n")
            self.assertEqual(inspected.returncode, 0, inspected.stderr)
            self.assertEqual(_read_path(retired), legacy)

            resumed = run(
                home, "migrate_legacy_corpus_receipt\ncorpus_receipt_valid\n",
                locked=True)
            self.assertEqual(resumed.returncode, 0, resumed.stderr)
            self.assertFalse(os.path.lexists(stage))
            self.assertFalse(os.path.lexists(retired))

        with tempfile.TemporaryDirectory() as home:
            _, managed, _, _, _ = prepare(home)
            interrupted = run(
                home, "migrate_legacy_corpus_receipt\n", locked=True,
                selected_functions=interrupted_functions)
            self.assertNotEqual(interrupted.returncode, 0)
            stage = os.path.join(managed, ".corpus.receipt.stage")
            _write(stage, "independent stage\n", 0o600)
            refused = run(
                home, "migrate_legacy_corpus_receipt\n", locked=True)
            self.assertNotEqual(refused.returncode, 0)
            self.assertEqual(_read_path(stage), "independent stage\n")

        with tempfile.TemporaryDirectory() as home:
            share = os.path.join(home, "share")
            managed = os.path.join(home, "state", "managed-install")
            corpus = os.path.join(share, "corpus")
            os.makedirs(corpus, mode=0o700)
            os.makedirs(managed)
            fresh = run(
                home, "write_corpus_receipt\ncorpus_receipt_valid\n",
                locked=True)
            self.assertEqual(fresh.returncode, 0, fresh.stderr)
            self.assertIn("kind=corpus-v2\n", _read_path(os.path.join(
                managed, "corpus")))

        fresh_crash_point = (
            "        write_journal(record)\n"
            "        if expected != \"absent\":")
        self.assertIn(fresh_crash_point, metadata)
        fresh_interrupted_metadata = metadata.replace(
            fresh_crash_point,
            "        write_journal(record)\n"
            "        raise SystemExit('fixture crash after fresh journal')\n"
            "        if expected != \"absent\":", 1)
        with tempfile.TemporaryDirectory() as home:
            share = os.path.join(home, "share")
            managed = os.path.join(home, "state", "managed-install")
            corpus = os.path.join(share, "corpus")
            os.makedirs(corpus, mode=0o700)
            os.makedirs(managed)
            receipt = os.path.join(managed, "corpus")
            interrupted = run(
                home, "write_corpus_receipt\n", locked=True,
                selected_metadata=fresh_interrupted_metadata)
            self.assertNotEqual(interrupted.returncode, 0)
            self.assertFalse(os.path.lexists(receipt))
            stage = os.path.join(managed, ".corpus.receipt.stage")
            self.assertTrue(os.path.isfile(stage))

            inspected = run(home, "preflight_corpus read-only\n")
            self.assertEqual(inspected.returncode, 0, inspected.stderr)
            self.assertFalse(os.path.lexists(receipt))
            self.assertTrue(os.path.isfile(stage))
            resumed = run(
                home,
                "migrate_legacy_corpus_receipt\n"
                "write_corpus_receipt\ncorpus_receipt_valid\n",
                locked=True)
            self.assertEqual(resumed.returncode, 0, resumed.stderr)
            self.assertTrue(os.path.isfile(receipt))
            self.assertFalse(os.path.lexists(stage))

        with tempfile.TemporaryDirectory() as home:
            _, managed, _, receipt, legacy = prepare(home)
            adoption = os.path.join(managed, "corpus-adoption")
            intent_stage = os.path.join(managed, ".hidden-intent.stage")
            _write(adoption, "operator intent\n", 0o600)
            _write(intent_stage, "replacement intent\n", 0o600)
            hidden = run(
                home,
                'expected="$(owned_metadata generation '
                '\"$CORPUS_ADOPTION_INTENT\")"\n'
                'owned_file_cas publish "$MANAGED_DIR/.hidden-intent.stage" '
                '"$CORPUS_ADOPTION_INTENT" "$expected"\n',
                selected_metadata=interrupted_metadata)
            self.assertNotEqual(hidden.returncode, 0)
            self.assertFalse(os.path.lexists(adoption))

            refused = run(
                home, "migrate_legacy_corpus_receipt\n", locked=True)
            self.assertNotEqual(refused.returncode, 0)
            self.assertEqual(_read_path(receipt), legacy)
            self.assertEqual(_read_path(adoption), "operator intent\n")
            self.assertFalse(os.path.lexists(os.path.join(
                managed, ".corpus.receipt.stage")))

    def test_plugin_rescan_discovers_exact_id_before_enablement(self):
        installer = _read("install.sh")
        desktop = installer.split('step "8/9 desktop', 1)[1].split(
            'step "9/9 agents', 1)[0]
        self.assertIn("omarchy-shell shell rescanPlugins", desktop)
        self.assertIn("omarchy plugin list --json", desktop)
        self.assertIn("attempt < 40", desktop)
        self.assertIn("sleep 0.05", desktop)
        self.assertIn('plugin.get("id") == plugin_id', desktop)
        self.assertLess(desktop.index("rescan_and_verify_omarchy_plugin khephri.sia"),
                        desktop.index("omarchy plugin enable khephri.sia"))

        functions = _bounded_commands_shell(installer) + \
            "\nplugin_id_is_discovered() {" + installer.split(
            "plugin_id_is_discovered() {", 1)[1].split(
                "\nbinding_block_state()", 1)[0]
        with tempfile.TemporaryDirectory() as root:
            fake_bin = os.path.join(root, "bin")
            trace = os.path.join(root, "trace")
            seen = os.path.join(root, "seen")
            os.makedirs(fake_bin)
            _fake_command(
                fake_bin, "omarchy-shell",
                'echo "omarchy-shell $*" >> "$TRACE"\nexit 0\n')
            _fake_command(
                fake_bin, "omarchy",
                'echo "omarchy $*" >> "$TRACE"\n'
                'if [ "$1 $2 $3" = "plugin list --json" ]; then\n'
                '  if [ -e "$SEEN" ]; then\n'
                '    echo \'[{"id":"khephri.sia"}]\'\n'
                '  else\n'
                '    : > "$SEEN"\n'
                '    echo \'[{"id":"khephri.sia-extra"}]\'\n'
                '  fi\n'
                'fi\n')
            _fake_command(
                fake_bin, "sleep",
                'echo "sleep $*" >> "$TRACE"\nexit 0\n')
            environment = os.environ.copy()
            environment.update({
                "PATH": fake_bin + os.pathsep + environment["PATH"],
                "TRACE": trace,
                "SEEN": seen,
            })
            result = subprocess.run(
                ["bash", "-c", functions +
                 "\nrescan_and_verify_omarchy_plugin khephri.sia"],
                env=environment, text=True, stdout=subprocess.PIPE,
                stderr=subprocess.PIPE, check=False)
            self.assertEqual(result.returncode, 0, result.stderr)
            calls = _read_path(trace).splitlines()
            self.assertEqual(calls[0],
                             "omarchy-shell shell rescanPlugins")
            self.assertEqual(calls[1], "omarchy plugin list --json")
            self.assertEqual(calls[2], "sleep 0.05")
            self.assertEqual(calls[3], "omarchy plugin list --json")

    def test_plugin_activation_restarts_and_attests_loaded_source_release(self):
        installer = _read("install.sh")
        activation = "activate_and_verify_omarchy_plugin() {" + \
            installer.split(
                "activate_and_verify_omarchy_plugin() {", 1)[1].split(
                    "\n}\n\nbinding_block_state()", 1)[0] + "\n}\n"
        functions = _bounded_commands_shell(installer) + "\n" + activation

        self.assertIn("omarchy restart shell", activation)
        self.assertIn("loadedReleaseVersion", activation)
        self.assertIn('[ "$actual" = "$expected" ]', activation)
        self.assertNotIn("|| true", activation)
        self.assertIn(
            '[ "$SIA_PLUGIN_LIVE_TREE" = '
            '"$SIA_PLUGIN_INSTALLED_TREE" ]', installer)
        # A generation that was never captured and one that moved are
        # separate refusals, so neither hides inside the other.
        self.assertIn(
            "installed plugin tree generation was never observed", installer)
        self.assertIn(
            "installed plugin tree changed during activation", installer)
        self.assertLess(
            installer.rindex(
                "activate_and_verify_omarchy_plugin \\\n    khephri.sia"),
            installer.rindex(
                'publish_first_light_state "$BINDIR" ready'))

        with tempfile.TemporaryDirectory() as root:
            fake_bin = os.path.join(root, "bin")
            trace = os.path.join(root, "trace")
            restarted = os.path.join(root, "restarted")
            os.makedirs(fake_bin)
            _fake_command(
                fake_bin, "omarchy",
                'echo "omarchy $*" >> "$TRACE"\n'
                '[ "${RESTART_EXIT:-0}" = 0 ] || exit "$RESTART_EXIT"\n'
                ': > "$RESTARTED"\n')
            _fake_command(
                fake_bin, "omarchy-shell",
                'echo "omarchy-shell $*" >> "$TRACE"\n'
                'printf "%s\\n" "${LOADED_RELEASE:-unknown}"\n')
            _fake_command(
                fake_bin, "sleep",
                'echo "sleep $*" >> "$TRACE"\n')
            environment = os.environ.copy()
            environment.update({
                "PATH": fake_bin + os.pathsep + environment["PATH"],
                "TRACE": trace,
                "RESTARTED": restarted,
                "LOADED_RELEASE": "1.7.3",
            })
            result = subprocess.run(
                ["bash", "-c", functions +
                 "\nactivate_and_verify_omarchy_plugin "
                 "khephri.sia 1.7.3"],
                env=environment, text=True, stdout=subprocess.PIPE,
                stderr=subprocess.PIPE, check=False)
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(
                _read_path(trace).splitlines(),
                ["omarchy restart shell",
                 "omarchy-shell shell call khephri.sia "
                 "loadedReleaseVersion probe"])

            os.unlink(trace)
            environment["RESTART_EXIT"] = "9"
            refused = subprocess.run(
                ["bash", "-c", functions +
                 "\nactivate_and_verify_omarchy_plugin "
                 "khephri.sia 1.7.3"],
                env=environment, text=True, stdout=subprocess.PIPE,
                stderr=subprocess.PIPE, check=False)
            self.assertNotEqual(refused.returncode, 0)
            self.assertEqual(
                _read_path(trace).splitlines(), ["omarchy restart shell"])

            os.unlink(trace)
            environment.pop("RESTART_EXIT")
            environment["LOADED_RELEASE"] = "unknown"
            refused = subprocess.run(
                ["bash", "-c", functions +
                 "\nactivate_and_verify_omarchy_plugin "
                 "khephri.sia 1.7.3"],
                env=environment, text=True, stdout=subprocess.PIPE,
                stderr=subprocess.PIPE, check=False)
            self.assertNotEqual(refused.returncode, 0)
            self.assertIn(
                "did not activate its exact installed release",
                refused.stderr)
            self.assertIn("sleep 0.05", _read_path(trace).splitlines())

    def test_keybinding_mutations_are_atomic_and_refuse_open_blocks(self):
        installer = _read("install.sh")
        uninstaller = _read("uninstall.sh")
        self.assertIn("binding_block_state()", installer)
        self.assertIn("binding_block_state()", uninstaller)
        self.assertIn("incomplete, duplicated, or malformed", installer)
        self.assertIn("incomplete, duplicated, or malformed", uninstaller)
        self.assertIn(".bindings.lua.sia-stage.XXXXXX", installer)
        self.assertIn("restored the original bindings", installer)
        self.assertNotIn('cat >> "$BINDINGS"', installer)
        self.assertNotIn("sed -i '/-- BEGIN SIA/,/-- END SIA/d'", uninstaller)
        self.assertIn('owned_file_cas publish "$stage" "$bindings"',
                      installer)
        self.assertIn('owned_file_cas publish "$stage" "$bindings"',
                      uninstaller)

    def test_owned_file_cas_preserves_concurrent_generations(self):
        installer = _read("install.sh")
        metadata = _owned_metadata_shell(installer)
        body = installer.split("owned_file_cas() {", 1)[1].split(
            "\n}\n\nwrite_lifecycle_tombstone", 1)[0]
        function = "owned_file_cas() {" + body + "\n}\n"
        python_source = installer.split(
            "owned_file_cas() {\n  python3 - \"$@\" <<'PY'\n", 1)[1].split(
                "\nPY\n}", 1)[0]
        self.assertNotIn("RENAME_EXCHANGE", python_source)
        self.assertNotIn("os.replace", python_source)
        self.assertIn("rename_noreplace(target_name, archive_name)",
                      python_source)
        self.assertIn("rename_noreplace(staged_name, target_name)",
                      python_source)
        self.assertIn("recover_journal()", python_source)

        def generation(path):
            result = subprocess.run(
                ["bash", "-c", metadata +
                 '\nowned_metadata generation "$1"', "cas-test", path],
                text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                check=False)
            self.assertEqual(result.returncode, 0, result.stderr)
            return result.stdout.strip()

        with tempfile.TemporaryDirectory() as root:
            target = os.path.join(root, "bindings.lua")
            stage = os.path.join(root, ".stage")
            _write(target, "operator original\n")
            _write(stage, "installer desired\n")
            expected = generation(target)
            _write(target, "concurrent before publish\n")
            refused = subprocess.run(
                ["bash", "-c", function +
                 '\nowned_file_cas publish "$1" "$2" "$3"',
                 "cas-test", stage, target, expected], text=True,
                stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
            self.assertNotEqual(refused.returncode, 0)
            self.assertEqual(_read_path(target), "concurrent before publish\n")

            _write(target, "operator original\n")
            _write(stage, "installer desired\n")
            expected = generation(target)
            intruder = os.path.join(root, "intruder")
            _write(intruder, "concurrent canonical generation\n")
            publish_needle = (
                "            rename_noreplace(staged_name, target_name)\n"
                "            sync_parent()")
            self.assertIn(publish_needle, python_source)
            displaced_source = python_source.replace(
                publish_needle, publish_needle +
                '\n            os.rename(os.environ["CAS_INTRUDER"], target)',
                1)
            with mock.patch.object(sys, "argv", [
                    "owned-file-cas", "publish", stage, target, expected]), \
                    mock.patch.dict(os.environ, {"CAS_INTRUDER": intruder}):
                with self.assertRaises(SystemExit) as stopped:
                    exec(compile(displaced_source, "owned-file-cas", "exec"), {})
            self.assertNotEqual(stopped.exception.code, 0)
            self.assertEqual(_read_path(target),
                             "concurrent canonical generation\n")
            self.assertFalse(os.path.lexists(stage))
            retained = [name for name in os.listdir(root)
                        if name.startswith(".sia-cas-prior.")]
            self.assertEqual(len(retained), 1)
            self.assertEqual(_read_path(os.path.join(root, retained[0])),
                             "operator original\n")

        with tempfile.TemporaryDirectory() as root:
            target = os.path.join(root, "bindings.lua")
            stage = os.path.join(root, ".stage")
            _write(target, "operator original\n")
            _write(stage, "installer desired\n")
            expected = generation(target)
            archive_needle = (
                "            rename_noreplace(target_name, archive_name)\n"
                "            sync_parent()")
            self.assertIn(archive_needle, python_source)
            crashed_source = python_source.replace(
                archive_needle, archive_needle +
                '\n            raise RuntimeError("simulated crash")', 1)
            with mock.patch.object(sys, "argv", [
                    "owned-file-cas", "publish", stage, target, expected]), \
                    self.assertRaises(RuntimeError):
                exec(compile(crashed_source, "owned-file-cas", "exec"), {})
            self.assertFalse(os.path.lexists(target))
            recovered = subprocess.run(
                ["bash", "-c", function +
                 '\nowned_file_cas recover "$1"', "cas-test", target],
                text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                check=False)
            self.assertEqual(recovered.returncode, 0, recovered.stderr)
            self.assertEqual(_read_path(target), "operator original\n")
            self.assertFalse([
                name for name in os.listdir(root)
                if name.startswith(".sia-cas-journal-")])

        with tempfile.TemporaryDirectory() as root:
            target = os.path.join(root, "bindings.lua")
            stage = os.path.join(root, ".stage")
            _write(target, "operator original\n")
            _write(stage, "installer desired\n")
            expected = generation(target)
            original_write = os.write
            writes = {"count": 0}

            def short_write(descriptor, data):
                writes["count"] += 1
                if writes["count"] == 1:
                    return original_write(descriptor, data[:1])
                return 0

            with mock.patch.object(sys, "argv", [
                    "owned-file-cas", "publish", stage, target, expected]), \
                    mock.patch("os.write", side_effect=short_write), \
                    self.assertRaises(OSError):
                exec(compile(python_source, "owned-file-cas", "exec"), {})
            self.assertEqual(_read_path(target), "operator original\n")
            self.assertEqual(_read_path(stage), "installer desired\n")
            self.assertFalse([
                name for name in os.listdir(root)
                if name.startswith(".sia-cas-journal-")])
            self.assertFalse([
                name for name in os.listdir(root)
                if name.startswith(".sia-cas-journal-stage.")])

    def test_owned_file_cas_replaces_exact_fenced_mode_zero_generation(self):
        installer = _read("install.sh")
        body = installer.split("owned_file_cas() {", 1)[1].split(
            "\n}\n\nwrite_lifecycle_tombstone", 1)[0]
        function = "owned_file_cas() {" + body + "\n}\n"
        python_source = installer.split(
            "owned_file_cas() {\n  python3 - \"$@\" <<'PY'\n", 1)[1].split(
                "\nPY\n}", 1)[0]

        def fenced_token(path, content):
            current = os.lstat(path)
            return "present:" + ":".join(str(value) for value in (
                current.st_dev, current.st_ino, current.st_mode,
                current.st_uid, current.st_size, current.st_mtime_ns,
                current.st_ctime_ns, hashlib.sha256(content).hexdigest()))

        def recover(target):
            return subprocess.run(
                ["bash", "-c", function +
                 '\nowned_file_cas recover "$1"',
                 "fenced-file-cas-test", target],
                text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                check=False)

        with tempfile.TemporaryDirectory() as root:
            target = os.path.join(root, "sia")
            stage = os.path.join(root, ".stage")
            prior = b"fenced prior launcher\n"
            _write(target, prior.decode("ascii"))
            os.chmod(target, 0)
            expected = fenced_token(target, prior)
            _write(stage, "desired launcher\n", 0o755)

            published = subprocess.run(
                ["bash", "-c", function +
                 '\nowned_file_cas publish "$1" "$2" "$3"',
                 "fenced-file-cas-test", stage, target, expected],
                text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                check=False)
            self.assertEqual(published.returncode, 0, published.stderr)
            self.assertEqual(_read_path(target), "desired launcher\n")
            self.assertTrue(os.path.isfile(stage))
            self.assertEqual(stat.S_IMODE(os.lstat(stage).st_mode), 0)
            os.chmod(stage, 0o600)
            self.assertEqual(_read_path(stage), prior.decode("ascii"))

        with tempfile.TemporaryDirectory() as root:
            target = os.path.join(root, "sia")
            stage = os.path.join(root, ".stage")
            prior = b"canonical one\n"
            changed = prior.replace(b"one", b"two")
            _write(target, prior.decode("ascii"))
            os.chmod(target, 0)
            expected = fenced_token(target, prior)
            before = os.lstat(target)
            os.chmod(target, 0o600)
            _write(target, changed.decode("ascii"))
            os.utime(target, ns=(before.st_atime_ns, before.st_mtime_ns))
            os.chmod(target, 0)
            after = os.lstat(target)
            self.assertNotEqual(after.st_ctime_ns, before.st_ctime_ns)
            _write(stage, "desired launcher\n", 0o755)

            refused = subprocess.run(
                ["bash", "-c", function +
                 '\nowned_file_cas publish "$1" "$2" "$3"',
                 "fenced-file-cas-test", stage, target, expected],
                text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                check=False)
            self.assertNotEqual(refused.returncode, 0)
            self.assertTrue(os.path.isfile(stage))
            self.assertEqual(stat.S_IMODE(os.lstat(target).st_mode), 0)
            os.chmod(target, 0o600)
            self.assertEqual(_read_path(target), changed.decode("ascii"))

        with tempfile.TemporaryDirectory() as root:
            target = os.path.join(root, "sia")
            stage = os.path.join(root, ".stage")
            prior = b"fenced prior launcher\n"
            _write(target, prior.decode("ascii"))
            os.chmod(target, 0)
            expected = fenced_token(target, prior)
            _write(stage, "desired launcher\n", 0o755)
            archive_needle = (
                "            rename_noreplace(target_name, archive_name)\n"
                "            sync_parent()")
            self.assertIn(archive_needle, python_source)
            crashed_source = python_source.replace(
                archive_needle, archive_needle +
                '\n            raise RuntimeError("fenced archive crash")', 1)
            with mock.patch.object(sys, "argv", [
                    "owned-file-cas", "publish", stage, target, expected]), \
                    self.assertRaises(RuntimeError):
                exec(compile(crashed_source, "owned-file-cas", "exec"), {})
            self.assertFalse(os.path.lexists(target))

            recovered = recover(target)
            self.assertEqual(recovered.returncode, 0, recovered.stderr)
            self.assertEqual(stat.S_IMODE(os.lstat(target).st_mode), 0)
            os.chmod(target, 0o600)
            self.assertEqual(_read_path(target), prior.decode("ascii"))
            self.assertEqual(_read_path(stage), "desired launcher\n")
            self.assertFalse([
                name for name in os.listdir(root)
                if name.startswith(".sia-cas-journal-")])

        with tempfile.TemporaryDirectory() as root:
            target = os.path.join(root, "sia")
            stage = os.path.join(root, ".stage")
            prior = b"fenced prior launcher\n"
            _write(target, prior.decode("ascii"))
            os.chmod(target, 0)
            expected = fenced_token(target, prior)
            _write(stage, "desired launcher\n", 0o755)
            publish_needle = (
                "            rename_noreplace(staged_name, target_name)\n"
                "            sync_parent()")
            self.assertIn(publish_needle, python_source)
            crashed_source = python_source.replace(
                publish_needle, publish_needle +
                '\n            raise RuntimeError("fenced publication crash")', 1)
            with mock.patch.object(sys, "argv", [
                    "owned-file-cas", "publish", stage, target, expected]), \
                    self.assertRaises(RuntimeError):
                exec(compile(crashed_source, "owned-file-cas", "exec"), {})
            self.assertEqual(_read_path(target), "desired launcher\n")
            self.assertFalse(os.path.lexists(stage))

            recovered = recover(target)
            self.assertEqual(recovered.returncode, 0, recovered.stderr)
            self.assertEqual(_read_path(target), "desired launcher\n")
            self.assertEqual(stat.S_IMODE(os.lstat(stage).st_mode), 0)
            os.chmod(stage, 0o600)
            self.assertEqual(_read_path(stage), prior.decode("ascii"))
            self.assertFalse([
                name for name in os.listdir(root)
                if name.startswith(".sia-cas-journal-")])

    def test_owned_tree_cas_is_generation_bound_and_crash_recoverable(self):
        installer = _read("install.sh")
        body = installer.split("owned_tree_cas() {", 1)[1].split(
            "\n}\n\nowned_tree_generation()", 1)[0]
        function = "owned_tree_cas() {" + body + "\n}\n"
        python_source = installer.split(
            "owned_tree_cas() {\n  python3 - \"$@\" <<'PY'\n", 1)[1].split(
                "\nPY\n}", 1)[0]
        self.assertNotIn("RENAME_EXCHANGE", python_source)
        self.assertNotIn("os.replace", python_source)
        for call in (
                '"$TOOLCHAIN/.bun.previous.XXXXXX" "$BUN_TREE_EXPECTED"',
                '"$TOOLCHAIN/.gbrain.previous.XXXXXX" "$GBRAIN_TREE_EXPECTED"',
                '"$OLLAMA_TREE_EXPECTED"',
                '"$SHARE/.bin.previous.XXXXXX" "$SIA_RUNTIME_TREE_EXPECTED"',
                '"$PLUGIN_TREE_EXPECTED"'):
            self.assertIn(call, installer)

        def generation(path):
            result = subprocess.run(
                ["bash", "-c", function +
                 '\nowned_tree_cas generation "$1"', "tree-cas-test", path],
                text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                check=False)
            self.assertEqual(result.returncode, 0, result.stderr)
            return result.stdout.strip()

        with tempfile.TemporaryDirectory() as root:
            target = os.path.join(root, "runtime")
            stage = os.path.join(root, ".stage")
            backup = os.path.join(root, ".backup")
            intruder = os.path.join(root, ".intruder")
            os.mkdir(target)
            os.mkdir(stage)
            os.mkdir(intruder)
            _write(os.path.join(target, "value"), "operator original\n")
            _write(os.path.join(stage, "value"), "installer desired\n")
            _write(os.path.join(intruder, "value"), "concurrent tree\n")
            expected = generation(target)
            archive_needle = (
                "        rename_noreplace(target_name, archive)\n"
                "        sync_parent()")
            self.assertIn(archive_needle, python_source)
            raced_source = python_source.replace(
                archive_needle, archive_needle +
                '\n        os.rename(os.environ["TREE_INTRUDER"], target)', 1)
            with mock.patch.object(sys, "argv", [
                    "owned-tree-cas", "publish", stage, target, backup,
                    expected]), mock.patch.dict(
                        os.environ, {"TREE_INTRUDER": intruder}):
                with self.assertRaises(SystemExit) as stopped:
                    exec(compile(raced_source, "owned-tree-cas", "exec"), {})
            self.assertNotEqual(stopped.exception.code, 0)
            self.assertEqual(
                _read_path(os.path.join(target, "value")),
                "concurrent tree\n")
            retained = [name for name in os.listdir(root)
                        if name.startswith(".sia-tree-cas-prior.")]
            self.assertEqual(len(retained), 1)
            self.assertEqual(
                _read_path(os.path.join(root, retained[0], "value")),
                "operator original\n")

        with tempfile.TemporaryDirectory() as root:
            target = os.path.join(root, "runtime")
            stage = os.path.join(root, ".stage")
            backup = os.path.join(root, ".backup")
            os.mkdir(target)
            os.mkdir(stage)
            _write(os.path.join(target, "value"), "operator original\n")
            _write(os.path.join(stage, "value"), "installer desired\n")
            expected = generation(target)
            crashed_source = python_source.replace(
                archive_needle, archive_needle +
                '\n        raise RuntimeError("simulated tree crash")', 1)
            with mock.patch.object(sys, "argv", [
                    "owned-tree-cas", "publish", stage, target, backup,
                    expected]), self.assertRaises(RuntimeError):
                exec(compile(crashed_source, "owned-tree-cas", "exec"), {})
            self.assertFalse(os.path.lexists(target))
            recovered = subprocess.run(
                ["bash", "-c", function +
                 '\nowned_tree_cas recover "$1"', "tree-cas-test", target],
                text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                check=False)
            self.assertEqual(recovered.returncode, 0, recovered.stderr)
            self.assertEqual(
                _read_path(os.path.join(target, "value")),
                "operator original\n")
            self.assertFalse([
                name for name in os.listdir(root)
                if name.startswith(".sia-tree-cas-journal-")])

    def test_owned_tree_cas_preserves_safe_relative_file_symlinks(self):
        installer = _read("install.sh")
        body = installer.split("owned_tree_cas() {", 1)[1].split(
            "\n}\n\nowned_tree_generation()", 1)[0]
        function = "owned_tree_cas() {" + body + "\n}\n"
        python_source = installer.split(
            "owned_tree_cas() {\n  python3 - \"$@\" <<'PY'\n", 1)[1].split(
                "\nPY\n}", 1)[0]

        def populate(tree, value):
            library = os.path.join(tree, "lib/ollama")
            binary = os.path.join(tree, "bin")
            os.makedirs(library)
            os.makedirs(binary)
            _write(os.path.join(library, "libllama.so.0.3.0"), value)
            os.symlink("libllama.so.0.3.0",
                       os.path.join(library, "libllama.so.0"))
            os.symlink("libllama.so.0",
                       os.path.join(library, "libllama.so"))
            os.symlink("../lib/ollama/libllama.so",
                       os.path.join(binary, "ollama"))

        def invoke(*arguments):
            return subprocess.run(
                ["bash", "-c", function +
                 '\nowned_tree_cas "$@"', "tree-symlink-test",
                 *arguments], text=True, stdout=subprocess.PIPE,
                stderr=subprocess.PIPE, check=False)

        with tempfile.TemporaryDirectory() as root:
            target = os.path.join(root, "runtime")
            stage = os.path.join(root, ".stage")
            backup = os.path.join(root, ".backup")
            populate(target, "operator original\n")
            populate(stage, "installer desired\n")

            expected_result = invoke("generation", target)
            self.assertEqual(expected_result.returncode, 0,
                             expected_result.stderr)
            expected = expected_result.stdout.strip()
            published = invoke("publish", stage, target, backup, expected)
            self.assertEqual(published.returncode, 0, published.stderr)
            installed = published.stdout.strip().split("\t", 1)[0]
            current = invoke("generation", target)
            self.assertEqual(current.returncode, 0, current.stderr)
            self.assertEqual(current.stdout.strip(), installed)
            self.assertEqual(
                os.readlink(os.path.join(target, "lib/ollama/libllama.so")),
                "libllama.so.0")
            self.assertEqual(
                os.readlink(os.path.join(target, "bin/ollama")),
                "../lib/ollama/libllama.so")
            self.assertEqual(_read_path(os.path.join(target, "bin/ollama")),
                             "installer desired\n")
            prior = invoke("generation", backup)
            self.assertEqual(prior.returncode, 0, prior.stderr)

        with tempfile.TemporaryDirectory() as root:
            target = os.path.join(root, "runtime")
            stage = os.path.join(root, ".stage")
            backup = os.path.join(root, ".backup")
            populate(target, "operator original\n")
            populate(stage, "installer desired\n")
            expected_result = invoke("generation", target)
            self.assertEqual(expected_result.returncode, 0,
                             expected_result.stderr)
            archive_needle = (
                "        rename_noreplace(target_name, archive)\n"
                "        sync_parent()")
            self.assertIn(archive_needle, python_source)
            crashed_source = python_source.replace(
                archive_needle, archive_needle +
                '\n        raise RuntimeError("simulated symlink tree crash")',
                1)
            with mock.patch.object(sys, "argv", [
                    "owned-tree-cas", "publish", stage, target, backup,
                    expected_result.stdout.strip()]), \
                    self.assertRaises(RuntimeError):
                exec(compile(crashed_source, "owned-tree-cas", "exec"), {})
            self.assertFalse(os.path.lexists(target))

            recovered = invoke("recover", target)
            self.assertEqual(recovered.returncode, 0, recovered.stderr)
            self.assertEqual(
                os.readlink(os.path.join(target, "lib/ollama/libllama.so")),
                "libllama.so.0")
            self.assertEqual(_read_path(os.path.join(target, "bin/ollama")),
                             "operator original\n")
            recovered_token = invoke("generation", target)
            self.assertEqual(recovered_token.returncode, 0,
                             recovered_token.stderr)
            self.assertFalse([
                name for name in os.listdir(root)
                if name.startswith(".sia-tree-cas-journal-")])

    def test_owned_tree_cas_rejects_nested_symlink_generation_races(self):
        installer = _read("install.sh")
        python_source = installer.split(
            "owned_tree_cas() {\n  python3 - \"$@\" <<'PY'\n", 1)[1].split(
                "\nPY\n}", 1)[0]

        nested_walk = "                    walk(child_fd, child_relative)\n"
        completed_walk = '        walk(root_fd, "")\n'
        self.assertIn(nested_walk, python_source)
        self.assertIn(completed_walk, python_source)
        mutations = (
            (
                "after-nested-walk",
                nested_walk,
                nested_walk
                + '                    if child_relative == "bin":\n'
                + '                        os.unlink(os.path.join('
                  'target, "bin", "ollama"))\n'
                + '                        os.symlink("../../outside", '
                  'os.path.join(target, "bin", "ollama"))\n',
            ),
            (
                "before-final-link-validation",
                completed_walk,
                completed_walk
                + '        os.unlink(os.path.join(target, "bin", "ollama"))\n'
                + '        os.symlink("../../outside", os.path.join('
                  'target, "bin", "ollama"))\n',
            ),
        )

        for label, needle, replacement in mutations:
            with self.subTest(label=label), tempfile.TemporaryDirectory() as root:
                tree = os.path.join(root, "runtime")
                os.makedirs(os.path.join(tree, "bin"))
                _write(os.path.join(tree, "payload"), "owned payload\n")
                _write(os.path.join(root, "outside"), "outside payload\n")
                os.symlink("../payload", os.path.join(tree, "bin", "ollama"))
                raced_source = python_source.replace(
                    needle, replacement, 1)
                result = subprocess.run(
                    [sys.executable, "-c", raced_source, "generation", tree],
                    text=True, stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE, check=False)
                self.assertNotEqual(
                    result.returncode, 0,
                    "nested symbolic-link mutation was accepted: " + label)

    def test_owned_tree_cas_rejects_unsafe_links_modes_and_link_counts(self):
        installer = _read("install.sh")
        body = installer.split("owned_tree_cas() {", 1)[1].split(
            "\n}\n\nowned_tree_generation()", 1)[0]
        function = "owned_tree_cas() {" + body + "\n}\n"

        def generation(path):
            return subprocess.run(
                ["bash", "-c", function +
                 '\nowned_tree_cas generation "$1"',
                 "tree-unsafe-entry-test", path], text=True,
                stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                check=False)

        cases = (
            "absolute-symlink",
            "escaping-symlink",
            "dangling-symlink",
            "directory-symlink",
            "group-writable-directory",
            "world-writable-directory",
            "group-writable-file",
            "world-writable-file",
            "multiply-linked-file",
        )
        for case in cases:
            with self.subTest(case=case), tempfile.TemporaryDirectory() as root:
                tree = os.path.join(root, "runtime")
                os.mkdir(tree)
                payload = os.path.join(tree, "payload")
                _write(payload, "owned payload\n")

                if case == "absolute-symlink":
                    os.symlink(payload, os.path.join(tree, "unsafe"))
                elif case == "escaping-symlink":
                    outside = os.path.join(root, "outside")
                    _write(outside, "outside payload\n")
                    os.symlink("../outside", os.path.join(tree, "unsafe"))
                elif case == "dangling-symlink":
                    os.symlink("missing", os.path.join(tree, "unsafe"))
                elif case == "directory-symlink":
                    os.mkdir(os.path.join(tree, "directory"))
                    os.symlink("directory", os.path.join(tree, "unsafe"))
                elif case in {"group-writable-directory",
                              "world-writable-directory"}:
                    directory = os.path.join(tree, "directory")
                    os.mkdir(directory)
                    mode = stat.S_IMODE(os.stat(directory).st_mode)
                    writable = (stat.S_IWGRP if case.startswith("group")
                                else stat.S_IWOTH)
                    os.chmod(directory, mode | writable)
                elif case in {"group-writable-file",
                              "world-writable-file"}:
                    mode = stat.S_IMODE(os.stat(payload).st_mode)
                    writable = (stat.S_IWGRP if case.startswith("group")
                                else stat.S_IWOTH)
                    os.chmod(payload, mode | writable)
                else:
                    os.link(payload, os.path.join(tree, "second-name"))

                result = generation(tree)
                self.assertNotEqual(result.returncode, 0,
                                    "unsafe tree was accepted: " + case)

    def test_owned_tree_generation_accepts_safe_mode_zero_launch_file(self):
        installer = _read("install.sh")
        body = installer.split("owned_tree_cas() {", 1)[1].split(
            "\n}\n\nowned_tree_generation()", 1)[0]
        function = "owned_tree_cas() {" + body + "\n}\n"
        python_source = installer.split(
            "owned_tree_cas() {\n  python3 - \"$@\" <<'PY'\n", 1)[1].split(
                "\nPY\n}", 1)[0]
        self.assertIn('getattr(os, "O_PATH", os.O_RDONLY)', python_source)
        self.assertIn("file_flags if synchronize else path_flags",
                      python_source)

        def generation(path):
            return subprocess.run(
                ["bash", "-c", function +
                 '\nowned_tree_cas generation "$1"',
                 "tree-mode-zero-test", path], text=True,
                stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                check=False)

        with tempfile.TemporaryDirectory() as root:
            tree = os.path.join(root, "runtime")
            os.mkdir(tree)
            launcher = os.path.join(tree, "sia-brainstem")
            _write(launcher, "fenced launch file\n", 0)

            fenced = generation(tree)
            self.assertEqual(fenced.returncode, 0, fenced.stderr)
            self.assertTrue(fenced.stdout.startswith("tree:"))

            os.chmod(launcher, stat.S_IWGRP)
            writable = generation(tree)
            self.assertNotEqual(writable.returncode, 0)

            os.chmod(launcher, 0)
            os.link(launcher, os.path.join(tree, "second-launch-name"))
            hardlinked = generation(tree)
            self.assertNotEqual(hardlinked.returncode, 0)

    def test_uninstall_archives_are_generation_bound_and_preserve_writers(self):
        uninstaller = _read("uninstall.sh")
        metadata = _owned_metadata_shell(uninstaller)
        file_body = uninstaller.split("owned_file_cas() {", 1)[1].split(
            "\n}\n\n# Descriptor-rooted, generation-bound archival", 1)[0]
        file_function = "owned_file_cas() {" + file_body + "\n}\n"
        file_source = uninstaller.split(
            "owned_file_cas() {\n  python3 - \"$@\" <<'PY'\n", 1)[1].split(
                "\nPY\n}", 1)[0]
        self.assertIn(file_source, file_function)
        tree_body = uninstaller.split("owned_tree_cas() {", 1)[1].split(
            "\n}\n\nowned_tree_generation()", 1)[0]
        tree_function = "owned_tree_cas() {" + tree_body + "\n}\n"
        tree_source = uninstaller.split(
            "owned_tree_cas() {\n  python3 - \"$@\" <<'PY'\n", 1)[1].split(
                "\nPY\n}", 1)[0]

        self.assertNotIn("mv -T", uninstaller)
        self.assertNotIn("RENAME_EXCHANGE", tree_source)
        self.assertNotIn("os.replace", tree_source)
        self.assertIn('owned_file_cas archive "$UNIT_BACKUP"', uninstaller)
        self.assertIn('owned_file_cas archive "$backup" "$CLI_PATH"',
                      uninstaller)
        self.assertIn('owned_tree_cas archive "$RUNTIME_BIN_DIR"',
                      uninstaller)
        self.assertIn('owned_tree_cas archive "$PLUGIN_DIR"', uninstaller)
        self.assertIn('"$UNIT_RECEIPT" "$UNIT_RECEIPT_EXPECTED"',
                      uninstaller)

        with tempfile.TemporaryDirectory() as root:
            target = os.path.join(root, "sia")
            intruder = os.path.join(root, "intruder")
            backup = os.path.join(root, ".removed")
            _write(target, "managed cli\n")
            digest = hashlib.sha256(b"managed cli\n").hexdigest()
            os.chmod(target, 0)
            expected_result = subprocess.run(
                ["bash", "-c", metadata +
                 '\nowned_metadata fenced-generation "$1" "$2"',
                 "uninstall-file-cas", target, digest], text=True,
                stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
            self.assertEqual(expected_result.returncode, 0,
                             expected_result.stderr)
            expected = expected_result.stdout.strip()
            _write(intruder, "concurrent cli\n")
            archive_needle = (
                "        rename_noreplace(target_name, archive_name)\n"
                "        sync_parent()")
            self.assertIn(archive_needle, file_source)
            raced_source = file_source.replace(
                archive_needle, archive_needle +
                '\n        os.rename(os.environ["CAS_INTRUDER"], target)', 1)
            with mock.patch.object(sys, "argv", [
                    "owned-file-cas", "archive", backup, target, expected]), \
                    mock.patch.dict(os.environ, {"CAS_INTRUDER": intruder}):
                with self.assertRaises(SystemExit) as stopped:
                    exec(compile(raced_source, "uninstall-file-cas", "exec"), {})
            self.assertNotEqual(stopped.exception.code, 0)
            self.assertEqual(_read_path(target), "concurrent cli\n")
            retained = [name for name in os.listdir(root)
                        if name.startswith(".sia-cas-prior.")]
            self.assertEqual(len(retained), 1)
            os.chmod(os.path.join(root, retained[0]), 0o600)
            self.assertEqual(_read_path(os.path.join(root, retained[0])),
                             "managed cli\n")

        def tree_generation(function, path):
            result = subprocess.run(
                ["bash", "-c", function +
                 '\nowned_tree_cas generation "$1"',
                 "uninstall-tree-cas", path], text=True,
                stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
            self.assertEqual(result.returncode, 0, result.stderr)
            return result.stdout.strip()

        with tempfile.TemporaryDirectory() as root:
            target = os.path.join(root, "runtime")
            intruder = os.path.join(root, "intruder")
            backup = os.path.join(root, ".runtime.removed")
            os.mkdir(target)
            os.mkdir(intruder)
            _write(os.path.join(target, "member"), "managed runtime\n")
            _write(os.path.join(intruder, "member"), "concurrent runtime\n")
            expected = tree_generation(tree_function, target)
            archive_needle = (
                "    rename_noreplace(target_name, archive)\n"
                "    sync_parent()")
            self.assertIn(archive_needle, tree_source)
            raced_source = tree_source.replace(
                archive_needle, archive_needle +
                '\n    os.rename(os.environ["TREE_INTRUDER"], target)', 1)
            with mock.patch.object(sys, "argv", [
                    "owned-tree-cas", "archive", target, backup, expected]), \
                    mock.patch.dict(os.environ, {"TREE_INTRUDER": intruder}):
                with self.assertRaises(SystemExit) as stopped:
                    exec(compile(raced_source, "uninstall-tree-cas", "exec"), {})
            self.assertNotEqual(stopped.exception.code, 0)
            self.assertEqual(
                _read_path(os.path.join(target, "member")),
                "concurrent runtime\n")
            self.assertEqual(
                _read_path(os.path.join(backup, "member")),
                "managed runtime\n")

        with tempfile.TemporaryDirectory() as root:
            target = os.path.join(root, "plugin")
            backup = os.path.join(root, ".plugin.removed")
            os.mkdir(target)
            _write(os.path.join(target, "member"), "managed plugin\n")
            expected = tree_generation(tree_function, target)
            crashed_source = tree_source.replace(
                archive_needle, archive_needle +
                '\n    raise RuntimeError("simulated archive crash")', 1)
            with mock.patch.object(sys, "argv", [
                    "owned-tree-cas", "archive", target, backup, expected]), \
                    self.assertRaises(RuntimeError):
                exec(compile(crashed_source, "uninstall-tree-cas", "exec"), {})
            self.assertFalse(os.path.lexists(target))
            recovered = subprocess.run(
                ["bash", "-c", tree_function +
                 '\nowned_tree_cas recover "$1"',
                 "uninstall-tree-cas", target], text=True,
                stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
            self.assertEqual(recovered.returncode, 0, recovered.stderr)
            self.assertFalse(os.path.lexists(target))
            self.assertEqual(_read_path(os.path.join(backup, "member")),
                             "managed plugin\n")
            self.assertFalse([
                name for name in os.listdir(root)
                if name.startswith(".sia-tree-cas-journal-")])

    def test_gbrain_pin_retirement_requires_exact_target_and_receipt(self):
        uninstaller = _read("uninstall.sh")
        authority_functions = "managed_receipt_matches() {" + \
            uninstaller.split("managed_receipt_matches() {", 1)[1].split(
                "\n\ncapture_cli_removal_authority", 1)[0]
        metadata_function = "remove_managed_metadata() {" + \
            uninstaller.split("remove_managed_metadata() {", 1)[1].split(
                "\n}\nruntime_tree_digest()", 1)[0] + "\n}\n"
        pin_function = "remove_owned_gbrain_pin() {" + uninstaller.split(
            "remove_owned_gbrain_pin() {", 1)[1].split(
                "\n}\n\nmcp_marker_state()", 1)[0] + "\n}\n"
        functions = (_owned_metadata_shell(uninstaller) + "\n" +
                     authority_functions + "\n" + metadata_function +
                     "\n" + pin_function)
        self.assertIn(
            'owned_file_cas archive "$backup" "$GBRAIN_PIN_PATH"',
            pin_function)
        self.assertIn("remove_managed_metadata", pin_function)
        self.assertIn(
            '"$GBRAIN_PIN_RECEIPT" "$receipt_expected"', pin_function)

        def run(function_text, root):
            share = os.path.join(root, "share")
            managed = os.path.join(root, "managed")
            target = os.path.join(share, "GBRAIN_PIN")
            receipt = os.path.join(managed, "gbrain-pin")
            script = ("set -u\n" + function_text +
                      f"\nSHARE_DIR={share!r}\n"
                      f"GBRAIN_PIN_PATH={target!r}\n"
                      f"GBRAIN_PIN_RECEIPT={receipt!r}\n"
                      "remove_owned_gbrain_pin\n")
            result = subprocess.run(
                ["bash", "-c", script], text=True,
                stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
            return result, target, receipt

        with tempfile.TemporaryDirectory() as root:
            share = os.path.join(root, "share")
            managed = os.path.join(root, "managed")
            target = os.path.join(share, "GBRAIN_PIN")
            receipt = os.path.join(managed, "gbrain-pin")
            _write(target, "managed pin\n")
            exact_receipt = _managed_file_receipt(target, "gbrain-pin")
            _write(receipt, exact_receipt)
            _write(target, "operator-modified pin\n")
            result, target, receipt = run(functions, root)
            self.assertNotEqual(result.returncode, 0)
            self.assertEqual(_read_path(target), "operator-modified pin\n")
            self.assertEqual(_read_path(receipt), exact_receipt)

        race_needle = (
            '  if ! archived="$(owned_file_cas archive "$backup" '
            '"$GBRAIN_PIN_PATH"')
        self.assertIn(race_needle, pin_function)
        raced_pin_function = pin_function.replace(
            race_needle,
            '  replacement="$SHARE_DIR/.GBRAIN_PIN.concurrent"\n'
            '  printf "%s\\n" "concurrent pin" > "$replacement"\n'
            '  mv -T -- "$replacement" "$GBRAIN_PIN_PATH"\n' +
            race_needle, 1)
        raced_functions = (_owned_metadata_shell(uninstaller) + "\n" +
                           authority_functions + "\n" + metadata_function +
                           "\n" + raced_pin_function)
        with tempfile.TemporaryDirectory() as root:
            share = os.path.join(root, "share")
            managed = os.path.join(root, "managed")
            target = os.path.join(share, "GBRAIN_PIN")
            receipt = os.path.join(managed, "gbrain-pin")
            _write(target, "managed pin\n")
            exact_receipt = _managed_file_receipt(target, "gbrain-pin")
            _write(receipt, exact_receipt)
            result, target, receipt = run(raced_functions, root)
            self.assertNotEqual(result.returncode, 0)
            self.assertEqual(_read_path(target), "concurrent pin\n")
            self.assertEqual(_read_path(receipt), exact_receipt)

    def test_binding_and_skill_callers_preserve_concurrent_writes(self):
        installer = _read("install.sh")
        uninstaller = _read("uninstall.sh")
        race_wrapper = r'''
eval "$(declare -f owned_file_cas | sed '1s/^owned_file_cas/real_owned_file_cas/')"
owned_file_cas() {
  if [ "$3" = "$RACE_TARGET" ]; then
    printf '%s\n' 'concurrent writer' > "$3"
  fi
  real_owned_file_cas "$@"
}
'''

        install_binding = "binding_block_state() {" + installer.split(
            "binding_block_state() {", 1)[1].split(
                "\nif have omarchy; then", 1)[0]
        uninstall_binding = "binding_block_state() {" + uninstaller.split(
            "binding_block_state() {", 1)[1].split(
                "\nif have systemctl; then", 1)[0]
        install_skill_body = installer.split(
            "install_agent_skill() {", 1)[1].split(
                "\n}\ninstall_agent_skill", 1)[0]
        install_skill = "install_agent_skill() {" + install_skill_body + "\n}\n"
        uninstall_skill_body = uninstaller.split(
            "remove_managed_skill() {", 1)[1].split(
                "\n}\n\nbinding_block_state", 1)[0]
        uninstall_skill = ("remove_managed_skill() {" +
                           uninstall_skill_body + "\n}\n")

        with tempfile.TemporaryDirectory() as root:
            bindings = os.path.join(root, "bindings.lua")
            _write(bindings, "-- operator binding\n")
            script = (_owned_metadata_shell(installer) + install_binding +
                      race_wrapper + r'''
have() { return 1; }
SIA_INSTALL_KEYBINDING=1
install_sia_keybinding "$1"
''')
            result = subprocess.run(
                ["bash", "-c", script, "binding-install-race", bindings],
                env={**os.environ, "RACE_TARGET": bindings}, text=True,
                stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
            self.assertNotEqual(result.returncode, 0)
            self.assertEqual(_read_path(bindings), "concurrent writer\n")

            _write(bindings, "-- operator binding\n\n"
                   "-- BEGIN SIA (managed by khephri.sia/install.sh)\n"
                   "managed line\n-- END SIA\n")
            script = (_owned_metadata_shell(uninstaller) + uninstall_binding +
                      race_wrapper + r'''
FAILURES=()
failed() { FAILURES+=("$1"); }
have() { return 1; }
remove_managed_binding "$1"
[ "${#FAILURES[@]}" -gt 0 ]
''')
            result = subprocess.run(
                ["bash", "-c", script, "binding-uninstall-race", bindings],
                env={**os.environ, "RACE_TARGET": bindings}, text=True,
                stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(_read_path(bindings), "concurrent writer\n")

        with tempfile.TemporaryDirectory() as root:
            skill_dir = os.path.join(root, "agent-skill")
            skill = os.path.join(skill_dir, "SKILL.md")
            marker = os.path.join(skill_dir, ".sia-managed")
            release = os.path.join(root, "release")
            source_skill = os.path.join(release, "skill/SKILL.md")
            _write(skill, "old managed skill\n")
            with open(skill, "rb") as stream:
                digest = hashlib.sha256(stream.read()).hexdigest()
            _write(marker, "managed-by=khephri.sia\n"
                   f"skill_sha256={digest}\n")
            _write(source_skill, "new release skill\n")
            script = (_owned_metadata_shell(installer) + install_skill +
                      race_wrapper + r'''
atomic_install_file() { cp -- "$1" "$2" && chmod "$3" "$2"; }
SKILL_DIR="$1"
SKILL_FILE="$SKILL_DIR/SKILL.md"
SKILL_MARKER="$SKILL_DIR/.sia-managed"
REPO="$2"
SIA_ORIGINAL_REPO="$REPO"
install_agent_skill
''')
            result = subprocess.run(
                ["bash", "-c", script, "skill-install-race", skill_dir,
                 release], env={**os.environ, "RACE_TARGET": skill,
                      "SIA_INSTALL_AGENT_SKILL": "1"},
                text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                check=False)
            self.assertNotEqual(result.returncode, 0)
            self.assertEqual(_read_path(skill), "concurrent writer\n")

            _write(skill, "old managed skill\n")
            with open(skill, "rb") as stream:
                digest = hashlib.sha256(stream.read()).hexdigest()
            _write(marker, "managed-by=khephri.sia\n"
                   f"skill_sha256={digest}\n")
            marker_race_wrapper = r'''
eval "$(declare -f owned_file_cas | sed '1s/^owned_file_cas/real_owned_file_cas/')"
owned_file_cas() {
  if [ "$1" = publish ] && [ "$3" = "$RACE_MARKER" ]; then
    printf '%s\n' 'concurrent across marker publication' > "$RACE_SKILL"
  fi
  real_owned_file_cas "$@"
}
'''
            script = (_owned_metadata_shell(installer) + install_skill +
                      marker_race_wrapper + r'''
atomic_install_file() { cp -- "$1" "$2" && chmod "$3" "$2"; }
SKILL_DIR="$1"
SKILL_FILE="$SKILL_DIR/SKILL.md"
SKILL_MARKER="$SKILL_DIR/.sia-managed"
REPO="$2"
SIA_ORIGINAL_REPO="$REPO"
install_agent_skill
''')
            result = subprocess.run(
                ["bash", "-c", script, "skill-marker-race", skill_dir,
                 release], env={**os.environ, "RACE_MARKER": marker,
                      "SIA_INSTALL_AGENT_SKILL": "1",
                                "RACE_SKILL": skill}, text=True,
                stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
            self.assertNotEqual(result.returncode, 0)
            self.assertEqual(
                _read_path(skill), "concurrent across marker publication\n")
            self.assertFalse(os.path.lexists(marker))

            _write(skill, "old managed skill\n")
            with open(skill, "rb") as stream:
                digest = hashlib.sha256(stream.read()).hexdigest()
            _write(marker, "managed-by=khephri.sia\n"
                   f"skill_sha256={digest}\n")
            script = (_owned_metadata_shell(uninstaller) + uninstall_skill +
                      race_wrapper + r'''
SKILL_DIR="$1"
SKILL_FILE="$SKILL_DIR/SKILL.md"
SKILL_MARKER="$SKILL_DIR/.sia-managed"
remove_managed_skill
''')
            result = subprocess.run(
                ["bash", "-c", script, "skill-uninstall-race", skill_dir],
                env={**os.environ, "RACE_TARGET": skill,
                      "SIA_INSTALL_AGENT_SKILL": "1"}, text=True,
                stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
            self.assertNotEqual(result.returncode, 0)
            self.assertEqual(_read_path(skill), "concurrent writer\n")
            retained = [name for name in os.listdir(skill_dir)
                        if name.startswith(".sia-managed.removed.")]
            self.assertTrue(retained)

    def test_agent_config_mutations_are_owned_and_fail_visibly(self):
        installer = _read("install.sh")
        agents = installer.split('step "9/9 agents', 1)[1]
        self.assertIn('SKILL_MARKER="$SKILL_DIR/.sia-managed"', agents)
        self.assertIn("managed-by=khephri.sia", agents)
        self.assertIn("skill_sha256=", agents)
        self.assertIn("SIA_REPLACE_AGENT_SKILL", agents)
        self.assertIn('atomic_install_file "$REPO/skill/SKILL.md"', agents)
        self.assertIn('owned_file_cas publish "$skill_stage" "$SKILL_FILE"',
                      agents)
        self.assertIn('owned_file_cas publish "$marker_stage"',
                      agents)
        self.assertIn("existing agent skill preserved", agents)
        self.assertIn("exact owned $harness MCP registration recovered", agents)
        self.assertIn("exact unmarked $harness MCP registration is user-owned; preserved",
                      agents)
        self.assertIn("state=committed", agents)
        self.assertNotIn('write_mcp_marker "$harness" pending-add', agents)
        self.assertNotIn("add_mcp_server()", agents)
        self.assertNotIn("rollback_added_mcp", agents)
        self.assertIn("no compare-and-add API is available", agents)
        self.assertIn("not installed; MCP registration skipped", agents)
        self.assertIn('MCP_MARKER_DIR="$STATE/managed-mcp"', agents)
        self.assertIn('MCP_GUARD_DIR="$STATE/mcp-consumer-guards"', agents)
        self.assertIn("external MCP clients can preserve the CLI/runtime",
                      agents)
        self.assertIn('write_mcp_marker "$harness" committed', agents)
        self.assertIn("claude mcp add --scope user sia -- python3", agents)
        self.assertIn("codex mcp add sia -- python3", agents)
        self.assertIn("grok mcp add --scope user sia -- python3", agents)
        self.assertNotIn("mcp add --scope user sia -- python3 "
                         '"$BINDIR/sia-mcp" 2>/dev/null || true', agents)
        self.assertNotIn("mcp_servers.sia", agents)
        uninstaller = _read("uninstall.sh")
        self.assertIn("remove_managed_mcp claude", uninstaller)
        self.assertIn("MCP registration still references SIA",
                      uninstaller)

    def test_mcp_transaction_metadata_is_storage_durable(self):
        installer = _read("install.sh")
        uninstaller = _read("uninstall.sh")
        for script in (installer, uninstaller):
            durable = script.split("durable_replace_file() {", 1)[1].split(
                "\n}\n", 1)[0]
            self.assertIn("owned_file_cas publish", durable)
            self.assertNotIn("os.replace", durable)
            self.assertIn('"$3"', durable)
        marker_writer = installer.split("write_mcp_marker() {", 1)[1].split(
            "\n}\n", 1)[0]
        install_guard_writer = installer.split(
            "write_mcp_consumer_guard() {", 1)[1].split("\n}\n", 1)[0]
        uninstall_guard_writer = uninstaller.split(
            "write_mcp_consumer_guard() {", 1)[1].split("\n}\n", 1)[0]
        self.assertIn("durable_replace_file", marker_writer)
        self.assertIn("durable_replace_file", install_guard_writer)
        self.assertIn("durable_replace_file", uninstall_guard_writer)

    def test_external_inspection_capture_is_bounded(self):
        for script_name in ("install.sh", "uninstall.sh"):
            script = _read(script_name)
            body = script.split("bounded_command_capture() {", 1)[1].split(
                "\n}\n", 1)[0]
            function = _lifetime_command_context() + "bounded_command_capture() {" + body + "\n}\n"
            owner = _read("bin/sialifetime.py")
            self.assertNotIn("subprocess.Popen", function)
            self.assertIn('"$SIA_LIFETIME_SOURCE" capture --caller "$BASHPID" "$@"', function)
            self.assertIn("MAX_CAPTURE_BYTES = 1_048_576", owner)
            self.assertIn("subprocess.DEVNULL", owner)
            self.assertIn('commands[:1] == ["--stdin"]', owner)
            self.assertIn("start_new_session=True", owner)
            self.assertIn("_send_signal(pinned[pid], signal.SIGKILL)", owner)
            self.assertIn("os.pidfd_open(process.pid, 0)", owner)
            self.assertIn("os.WNOWAIT", owner)
            self.assertNotIn("os.P_PIDFD", owner)
            self.assertLess(
                owner.index("_send_signal(pinned[pid], signal.SIGKILL)"),
                owner.index("os.waitpid(pid, os.WNOHANG)"))
            self.assertIn('b"\\0" in output', owner)
            self.assertIn('decode("utf-8", "strict")', owner)
            overflow = subprocess.run(
                ["bash", "-c", function +
                 '\nbounded_command_capture "$1" -c "$2"',
                 "bounded-inspector", sys.executable,
                 "import os; os.write(1, b'x' * 1048577)"],
                text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                check=False)
            self.assertNotEqual(overflow.returncode, 0, script_name)
            self.assertEqual(overflow.stdout, "", script_name)
            self.assertIn("exceeded its output byte ceiling",
                          overflow.stderr, script_name)

            accepted = subprocess.run(
                ["bash", "-c", function +
                 '\nbounded_command_capture "$1" -c "$2"',
                 "bounded-inspector", sys.executable,
                 "print('bounded output')"], text=True,
                stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
            self.assertEqual(accepted.returncode, 0, accepted.stderr)
            self.assertEqual(accepted.stdout, "bounded output\n")
            self.assertNotIn('inspection="$("$harness" mcp get', script)
            self.assertNotIn('inspection="$("$client" mcp get', script)
            self.assertNotIn('inspection="$(grok mcp list', script)
            self.assertIn("bounded_command_capture", script.split(
                "inspect_mcp_server() {", 1)[1])

    def test_command_runners_kill_descendants_before_reaping_leader(self):
        child_program = (
            "import os,time\n"
            "child=os.fork()\n"
            "if child == 0:\n"
            "    time.sleep(300)\n"
            "else:\n"
            "    print(child, flush=True)\n")

        def non_zombie(pid):
            try:
                with open(f"/proc/{pid}/stat", encoding="ascii") as stream:
                    fields = stream.read().split()
            except (FileNotFoundError, ProcessLookupError):
                # A child may exit after /proc opens but before its state is
                # read. It is no longer a live or zombie descendant.
                return False
            return len(fields) > 2 and fields[2] != "Z"

        with mock.patch("builtins.open", side_effect=ProcessLookupError):
            self.assertFalse(non_zombie(1))

        for script_name in ("install.sh", "uninstall.sh"):
            script = _read(script_name)
            bounded_body = script.split(
                "bounded_command_capture() {", 1)[1].split("\n}\n", 1)[0]
            bounded = _lifetime_command_context() + "bounded_command_capture() {" + bounded_body + "\n}\n"
            deadline_body = script.split(
                "run_with_deadline() {", 1)[1].split("\n}\n", 1)[0]
            deadline = _lifetime_command_context() + "run_with_deadline() {" + deadline_body + "\n}\n"
            owner = _read("bin/sialifetime.py")
            self.assertNotIn("subprocess.Popen", deadline)
            self.assertIn('"$SIA_LIFETIME_SOURCE" run --caller "$BASHPID" "$@"', deadline)
            self.assertIn("os.WNOWAIT", owner)
            self.assertIn("os.pidfd_open(process.pid, 0)", owner)
            self.assertNotIn("os.P_PIDFD", owner)
            self.assertLess(
                owner.index("_send_signal(pinned[pid], signal.SIGKILL)"),
                owner.index("os.waitpid(pid, os.WNOHANG)"))
            cases = (
                (bounded,
                 '\nbounded_command_capture "$1" -c "$2"'),
                (deadline,
                 '\nrun_with_deadline 120 "$1" -c "$2"'),
            )
            for function, invocation in cases:
                with self.subTest(script=script_name,
                                  runner=invocation.split()[0]):
                    result = subprocess.run(
                        ["bash", "-c", function + invocation,
                         "runner-descendant-test", sys.executable,
                         child_program], text=True, stdout=subprocess.PIPE,
                        stderr=subprocess.PIPE, check=False)
                    self.assertEqual(result.returncode, 0, result.stderr)
                    child_pid = int(result.stdout.strip())
                    for _ in range(100):
                        if not non_zombie(child_pid):
                            break
                        time.sleep(0.01)
                    self.assertFalse(non_zombie(child_pid))

    def test_external_mcp_shapes_create_durable_nonownership_guards(self):
        installer = _read("install.sh")
        agents = installer.split('step "9/9 agents', 1)[1]
        functions = _owned_metadata_shell(installer) + \
            "durable_replace_file() {" + agents.split(
            "durable_replace_file() {", 1)[1].split(
                "\nregister_mcp_server claude", 1)[0]
        fixtures = {
            ("claude", "exact-unmarked"): (
                'echo "sia:"\n'
                'echo "  Scope: User config (available in all your projects)"\n'
                'echo "  Status: Disconnected"\n'
                'echo "  Type: stdio"\n'
                'echo "  Command: python3"\n'
                'echo "  Args: $HOME/.local/share/sia/bin/sia-mcp"\n'
                'echo "  Environment:"\n'
                'echo\n'),
            ("claude", "modified-reference"): (
                'echo "sia:"\n'
                'echo "  Scope: User config (available in all your projects)"\n'
                'echo "  Status: Connected"\n'
                'echo "  Type: stdio"\n'
                'echo "  Command: python3"\n'
                'echo "  Args: $HOME/.local/share/sia/bin/sia-mcp"\n'
                'echo "  Environment:"\n'
                'echo "    SIA_EXTERNAL: true"\n'
                'echo\n'),
            ("codex", "exact-unmarked"): (
                'echo "sia"\n'
                'echo "  enabled: true"\n'
                'echo "  transport: stdio"\n'
                'echo "  command: python3"\n'
                'echo "  args: $HOME/.local/share/sia/bin/sia-mcp"\n'
                'echo "  cwd: -"\n'
                'echo "  env: -"\n'),
            ("codex", "modified-reference"): (
                'echo "sia"\n'
                'echo "  enabled: true"\n'
                'echo "  transport: stdio"\n'
                'echo "  command: python3"\n'
                'echo "  args: $HOME/.local/share/sia/bin/sia-mcp"\n'
                'echo "  cwd: /tmp"\n'
                'echo "  env: -"\n'),
            ("grok", "exact-unmarked"): (
                'printf \'[{"name":"sia","command":"python3",'
                '"args":["%s"],"enabled":true,"scope":"user"}]\\n\' '
                '"$HOME/.local/share/sia/bin/sia-mcp"\n'),
            ("grok", "modified-reference"): (
                'printf \'[{"name":"sia","command":"python3",'
                '"args":["%s","--external"],"enabled":true,'
                '"scope":"user"}]\\n\' '
                '"$HOME/.local/share/sia/bin/sia-mcp"\n'),
        }
        for (client, reason), inspection in fixtures.items():
            with self.subTest(client=client, reason=reason), \
                    tempfile.TemporaryDirectory() as root:
                home = os.path.join(root, "home")
                fake_bin = os.path.join(root, "bin")
                trace = os.path.join(root, "trace")
                marker_dir = os.path.join(
                    home, ".local/state/sia/managed-mcp")
                guard_dir = os.path.join(
                    home, ".local/state/sia/mcp-consumer-guards")
                runtime = os.path.join(home, ".local/share/sia/bin")
                os.makedirs(fake_bin)
                os.makedirs(marker_dir)
                os.makedirs(guard_dir)
                _fake_command(
                    fake_bin, client,
                    f'echo "{client} $*" >> "$TRACE"\n' + inspection)
                environment = os.environ.copy()
                environment.update({
                    "HOME": home,
                    "PATH": fake_bin + os.pathsep + environment["PATH"],
                    "TRACE": trace,
                })
                script = (
                    "set -euo pipefail\n"
                    f"MCP_MARKER_DIR={marker_dir!r}\n"
                    f"MCP_GUARD_DIR={guard_dir!r}\n"
                    f"BINDIR={runtime!r}\n"
                    "have() { command -v \"$1\" >/dev/null 2>&1; }\n" +
                    functions + f"\nregister_mcp_server {client}\n")
                result = subprocess.run(
                    ["bash", "-c", script], env=environment, text=True,
                    stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                    check=False)
                self.assertEqual(result.returncode, 0, result.stderr)
                guard = os.path.join(guard_dir, client)
                self.assertEqual(_read_path(guard),
                                 _mcp_guard_contents(home, client, reason))
                self.assertFalse(os.path.lexists(
                    os.path.join(marker_dir, client)))
                calls = _read_path(trace)
                self.assertNotIn("mcp add", calls)
                self.assertNotIn("mcp remove", calls)

    def test_pending_mcp_reference_cannot_launder_owned_add_into_guard(self):
        installer = _read("install.sh")
        agents = installer.split('step "9/9 agents', 1)[1]
        functions = _owned_metadata_shell(installer) + \
            "durable_replace_file() {" + agents.split(
            "durable_replace_file() {", 1)[1].split(
                "\nregister_mcp_server claude", 1)[0]
        with tempfile.TemporaryDirectory() as root:
            home = os.path.join(root, "home")
            fake_bin = os.path.join(root, "bin")
            trace = os.path.join(root, "trace")
            added = os.path.join(root, "added")
            marker_dir = os.path.join(
                home, ".local/state/sia/managed-mcp")
            guard_dir = os.path.join(
                home, ".local/state/sia/mcp-consumer-guards")
            runtime = os.path.join(home, ".local/share/sia/bin")
            os.makedirs(fake_bin)
            os.makedirs(marker_dir)
            os.makedirs(guard_dir)
            _fake_command(
                fake_bin, "claude",
                'echo "claude $*" >> "$TRACE"\n'
                'if [ "$1 $2 $3" = "mcp get sia" ]; then\n'
                '  if [ ! -e "$ADDED" ]; then\n'
                '    echo "No MCP server named sia" >&2\n'
                '    exit 1\n'
                '  fi\n'
                '  echo "sia:"\n'
                '  echo "  Scope: User config (available in all your projects)"\n'
                '  echo "  Status: Connected"\n'
                '  echo "  Type: stdio"\n'
                '  echo "  Command: python3"\n'
                '  echo "  Args: $HOME/.local/share/sia/bin/sia-mcp"\n'
                '  echo "  Environment:"\n'
                '  echo "  New Field: benign display-format drift"\n'
                '  echo\n'
                '  exit 0\n'
                'fi\n'
                'if [ "$1 $2 $3 $4 $5" = "mcp add --scope user sia" ]; then\n'
                '  : > "$ADDED"\n'
                '  exit 0\n'
                'fi\n'
                'exit 1\n')
            environment = os.environ.copy()
            environment.update({
                "HOME": home,
                "PATH": fake_bin + os.pathsep + environment["PATH"],
                "TRACE": trace,
                "ADDED": added,
            })
            script = (
                "set -euo pipefail\n"
                f"MCP_MARKER_DIR={marker_dir!r}\n"
                f"MCP_GUARD_DIR={guard_dir!r}\n"
                f"BINDIR={runtime!r}\n"
                "have() { command -v \"$1\" >/dev/null 2>&1; }\n" +
                functions +
                "\nfirst=accepted\n"
                "register_mcp_server claude || first=refused\n"
                "second=accepted\n"
                "register_mcp_server claude || second=refused\n"
                "printf 'first=%s second=%s\\n' \"$first\" \"$second\"\n")
            result = subprocess.run(
                ["bash", "-c", script], env=environment, text=True,
                stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertTrue(result.stdout.endswith(
                "first=accepted second=accepted\n"), result.stdout)
            marker = os.path.join(marker_dir, "claude")
            self.assertFalse(os.path.lexists(marker))
            self.assertFalse(os.path.lexists(
                os.path.join(guard_dir, "claude")))
            self.assertFalse(os.path.lexists(added))
            self.assertEqual(
                _read_path(trace),
                "claude mcp get sia\n"
                "claude mcp get sia\n")

    def test_committed_and_legacy_mcp_references_retain_owned_markers(self):
        installer = _read("install.sh")
        agents = installer.split('step "9/9 agents', 1)[1]
        functions = _owned_metadata_shell(installer) + \
            "\ndurable_replace_file() {" + agents.split(
            "durable_replace_file() {", 1)[1].split(
                "\nregister_mcp_server claude", 1)[0]
        marker_bodies = {
            "committed": (
                "managed-by=khephri.sia\nstate=committed\n"
                "command=python3\narg={runtime}/sia-mcp\n"),
            "legacy": (
                "managed-by=khephri.sia\ncommand=python3\n"
                "arg={runtime}/sia-mcp\n"),
        }
        for marker_state, template in marker_bodies.items():
            with self.subTest(marker_state=marker_state), \
                    tempfile.TemporaryDirectory() as root:
                home = os.path.join(root, "home")
                fake_bin = os.path.join(root, "bin")
                trace = os.path.join(root, "trace")
                marker_dir = os.path.join(
                    home, ".local/state/sia/managed-mcp")
                guard_dir = os.path.join(
                    home, ".local/state/sia/mcp-consumer-guards")
                runtime = os.path.join(home, ".local/share/sia/bin")
                os.makedirs(fake_bin)
                os.makedirs(marker_dir)
                os.makedirs(guard_dir)
                marker = os.path.join(marker_dir, "claude")
                expected_marker = template.format(runtime=runtime)
                _write(marker, expected_marker)
                _fake_command(
                    fake_bin, "claude",
                    'echo "claude $*" >> "$TRACE"\n'
                    'echo "sia:"\n'
                    'echo "  Scope: User config (available in all your projects)"\n'
                    'echo "  Status: Connected"\n'
                    'echo "  Type: stdio"\n'
                    'echo "  Command: python3"\n'
                    'echo "  Args: $HOME/.local/share/sia/bin/sia-mcp"\n'
                    'echo "  Environment:"\n'
                    'echo "  New Field: benign display-format drift"\n'
                    'echo\n')
                environment = os.environ.copy()
                environment.update({
                    "HOME": home,
                    "PATH": fake_bin + os.pathsep + environment["PATH"],
                    "TRACE": trace,
                })
                script = (
                    "set -euo pipefail\n"
                    f"MCP_MARKER_DIR={marker_dir!r}\n"
                    f"MCP_GUARD_DIR={guard_dir!r}\n"
                    f"BINDIR={runtime!r}\n"
                    "have() { command -v \"$1\" >/dev/null 2>&1; }\n" +
                    functions +
                    "\nresult=accepted\n"
                    "register_mcp_server claude || result=refused\n"
                    "printf 'result=%s\\n' \"$result\"\n")
                result = subprocess.run(
                    ["bash", "-c", script], env=environment, text=True,
                    stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                    check=False)
                self.assertEqual(result.returncode, 0, result.stderr)
                self.assertEqual(result.stdout, "result=refused\n")
                self.assertEqual(_read_path(marker), expected_marker)
                self.assertFalse(os.path.lexists(
                    os.path.join(guard_dir, "claude")))
                self.assertEqual(_read_path(trace), "claude mcp get sia\n")

    def test_uninstaller_preserves_state_and_reports_each_integration(self):
        with tempfile.TemporaryDirectory() as root:
            home = os.path.join(root, "home")
            fake_bin = os.path.join(root, "bin")
            trace = os.path.join(root, "trace")
            os.makedirs(fake_bin)
            for client in ("claude", "codex"):
                if client == "claude":
                    inspection = (
                        '  echo "sia:"\n'
                        '  echo "  Scope: User config (available in all your projects)"\n'
                        '  echo "  Status: Connected"\n'
                        '  echo "  Type: stdio"\n'
                        '  echo "  Command: python3"\n'
                        '  echo "  Args: $HOME/.local/share/sia/bin/sia-mcp"\n'
                        '  echo "  Environment:"\n'
                        '  echo\n')
                else:
                    inspection = (
                        '  echo "sia"\n'
                        '  echo "  enabled: true"\n'
                        '  echo "  transport: stdio"\n'
                        '  echo "  command: python3"\n'
                        '  echo "  args: $HOME/.local/share/sia/bin/sia-mcp"\n'
                        '  echo "  cwd: -"\n'
                        '  echo "  env: -"\n')
                _fake_command(
                    fake_bin, client,
                    'echo "' + client + ' $*" >> "$TRACE"\n'
                    'if [ "$1 $2 $3" = "mcp get sia" ]; then\n'
                    '  if [ -f "$HOME/.' + client + '-removed" ]; then\n'
                    '    echo "No MCP server named sia" >&2\n'
                    '    exit 1\n'
                    '  fi\n' + inspection +
                    '  exit 0\n'
                    'fi\n'
                    'if [ "$1 $2" = "mcp remove" ]; then\n'
                    '  touch "$HOME/.' + client + '-removed"\n'
                    'fi\n'
                    'exit 0\n')
            _fake_command(
                fake_bin, "grok",
                'echo "grok $*" >> "$TRACE"\n'
                'if [ "$1 $2 $3" = "mcp list --json" ]; then\n'
                '  if [ -f "$HOME/.grok-removed" ]; then echo "[]"; exit 0; fi\n'
                '  echo "[{\\"name\\":\\"sia\\",\\"command\\":\\"python3\\",'
                '\\"args\\":[\\"$HOME/.local/share/sia/bin/sia-mcp\\"],'
                '\\"enabled\\":true,\\"scope\\":\\"user\\"}]"\n'
                '  exit 0\n'
                'fi\n'
                'if [ "$1 $2" = "mcp remove" ]; then touch "$HOME/.grok-removed"; fi\n'
                'exit 0\n')
            _fake_command(
                fake_bin, "systemctl",
                'echo "systemctl $*" >> "$TRACE"\n'
                'if [ "$1 $2" = "--user show" ]; then\n'
                '  if [ "$3" != "sia-brainstem.service" ]; then\n'
                '    echo "LoadState=not-found"; echo "ActiveState=inactive"\n'
                '    echo "FragmentPath="; echo "UnitFileState="\n'
                '    echo "DropInPaths="; echo "MainPID=0"\n'
                '    echo "RefuseManualStart=no"; echo "Job="\n'
                '    exit 0\n'
                '  fi\n'
                '  unit=$HOME/.config/systemd/user/sia-brainstem.service\n'
                '  barrier=$XDG_RUNTIME_DIR/systemd/user/'
                'sia-brainstem.service.d/sia-lifecycle-barrier.conf\n'
                '  if [ ! -f "$unit" ]; then\n'
                '    echo "LoadState=not-found"\n'
                '    echo "ActiveState=inactive"; echo "UnitFileState="\n'
                '    fragment=; main_pid=0\n'
                '  elif [ -f "$HOME/.brainstem-disabled" ]; then\n'
                '    echo "LoadState=loaded"\n'
                '    echo "ActiveState=inactive"; echo "UnitFileState=disabled"\n'
                '    fragment=$unit\n'
                '    main_pid=0\n'
                '  else\n'
                '    echo "LoadState=loaded"\n'
                '    echo "ActiveState=active"; echo "UnitFileState=enabled"\n'
                '    fragment=$unit\n'
                '    main_pid=123\n'
                '  fi\n'
                '  echo "FragmentPath=$fragment"\n'
                '  if [ -f "$barrier" ] && [ -f "$unit" ]; then\n'
                '    echo "DropInPaths=$barrier"\n'
                '    echo "RefuseManualStart=yes"\n'
                '  else\n'
                '    echo "DropInPaths="; echo "RefuseManualStart=no"\n'
                '  fi\n'
                '  echo "MainPID=$main_pid"; echo "Job="\n'
                '  exit 0\n'
                'fi\n'
                'if [ "$1 $2 $3" = "--user disable --now" ]; then\n'
                '  touch "$HOME/.brainstem-disabled"\n'
                'fi\n'
                'exit 0\n')
            _fake_command(fake_bin, "omarchy",
                          'echo "omarchy $*" >> "$TRACE"\nexit 0\n')
            _fake_command(fake_bin, "hyprctl",
                          'echo "hyprctl $*" >> "$TRACE"\nexit 0\n')

            paths = {
                "corpus": ".local/share/sia/corpus/memory.md",
                "runtime": ".local/share/sia/bin/sialib.py",
                "pin": ".local/share/sia/GBRAIN_PIN",
                "queue": ".local/state/sia/agent-queue/request.json",
                "config": ".config/sia/config.json",
                "cli": ".local/bin/sia",
                "unit": ".config/systemd/user/sia-brainstem.service",
                "skill": ".claude/skills/sia/SKILL.md",
                "plugin": ".config/omarchy/plugins/khephri.sia/local.txt",
            }
            for relative in paths.values():
                _write(os.path.join(home, relative), relative + "\n")
            runtime_dir = os.path.join(home, ".local/share/sia/bin")
            for name in ("sia-brainstem", "sia-ledger", "sia-mcp",
                         "siabench.py", "sialib.py", "siamind.py",
                         "siaqueue.py", "siatakes.py"):
                runtime_path = os.path.join(runtime_dir, name)
                if not os.path.exists(runtime_path):
                    _write(runtime_path, name + "\n")
            managed_dir = os.path.join(
                home, ".local/state/sia/managed-install")
            unit_path = os.path.join(home, paths["unit"])
            cli_path = os.path.join(home, paths["cli"])
            _write(os.path.join(managed_dir, "sia-brainstem.service"),
                   _managed_file_receipt(unit_path, "brainstem-unit"))
            _write(os.path.join(managed_dir, "sia-cli"),
                   _managed_file_receipt(cli_path, "sia-cli"))
            _write(
                os.path.join(managed_dir, "runtime"),
                "managed-by=khephri.sia\nkind=runtime\n"
                f"path={runtime_dir}\nsha256={_runtime_digest(runtime_dir)}\n")
            skill_path = os.path.join(home, paths["skill"])
            skill_hash = hashlib.sha256(
                _read_path(skill_path).encode("utf-8")).hexdigest()
            _write(os.path.join(home, ".claude/skills/sia/.sia-managed"),
                   "managed-by=khephri.sia\n"
                   f"skill_sha256={skill_hash}\n")
            for client in ("claude", "codex", "grok"):
                _write(os.path.join(
                    home, ".local/state/sia/managed-mcp", client),
                    "managed-by=khephri.sia\ncommand=python3\n"
                    f"arg={home}/.local/share/sia/bin/sia-mcp\n")
            bindings = os.path.join(home, ".config/hypr/bindings.lua")
            _write(bindings, "before\n-- BEGIN SIA\nmanaged\n-- END SIA\nafter\n")

            environment = os.environ.copy()
            environment.update({
                "HOME": home,
                "PATH": fake_bin + os.pathsep + environment["PATH"],
                "TRACE": trace,
                "HYPRLAND_INSTANCE_SIGNATURE": "test-instance",
            })
            result = subprocess.run(
                ["bash", os.path.join(REPO, "uninstall.sh")],
                cwd=REPO, env=environment, text=True,
                stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
            self.assertEqual(result.returncode, 0, result.stderr)

            for key in ("corpus", "queue", "config"):
                self.assertTrue(os.path.exists(os.path.join(home, paths[key])))
            for key in ("unit", "skill", "plugin"):
                self.assertFalse(os.path.exists(os.path.join(home, paths[key])))
            for key in ("runtime", "pin", "cli"):
                self.assertTrue(os.path.exists(os.path.join(home, paths[key])))
            plugin_parent = os.path.join(home, ".config/omarchy/plugins")
            backups = [name for name in os.listdir(plugin_parent)
                       if name.startswith(".khephri.sia.removed.")]
            self.assertEqual(len(backups), 1)
            self.assertTrue(os.path.isfile(os.path.join(
                plugin_parent, backups[0], "local.txt")))
            self.assertEqual(_read_path(bindings), "before\nafter\n")
            calls = _read_path(trace)
            self.assertNotIn("mcp remove", calls)
            self.assertIn("no compare-and-remove API", result.stdout)
            self.assertIn("systemctl --user daemon-reload", calls)
            self.assertIn("hyprctl reload", calls)
            self.assertIn("hyprctl configerrors", calls)
            self.assertIn("uninstall completed successfully", result.stdout)

    def test_uninstaller_recovers_exact_retired_brainstem_barrier(self):
        barrier_content = (
            "[Unit]\nRefuseManualStart=yes\nConditionPathExists=\n"
            "ConditionPathExists=!/\n")
        for inject_failure in (False, True):
            with self.subTest(inject_failure=inject_failure), \
                    tempfile.TemporaryDirectory() as root:
                home = os.path.join(root, "home")
                runtime = os.path.join(root, "runtime")
                fake_bin = os.path.join(root, "bin")
                os.makedirs(home)
                os.makedirs(runtime, mode=0o700)
                os.chmod(runtime, 0o700)
                os.makedirs(fake_bin)
                active = os.path.join(
                    runtime, "systemd", "user",
                    "sia-brainstem.service.d",
                    "sia-lifecycle-barrier.conf")
                retired = os.path.splitext(active)[0] + ".retired"
                _write(retired, barrier_content, 0o644)
                _fake_command(
                    fake_bin, "systemctl",
                    'if [ "$1 $2" = "--user daemon-reload" ]; then\n'
                    '  if [ -f "$TRACE_DIR/reload-seen" ]; then\n'
                    '    : > "$TRACE_DIR/retry-reload"\n'
                    '  else\n'
                    '    : > "$TRACE_DIR/reload-seen"\n'
                    '  fi\n'
                    '  exit 0\n'
                    'fi\n'
                    'if [ "$1 $2" = "--user show" ]; then\n'
                    '  if [ -f "$TRACE_DIR/retry-reload" ]; then\n'
                    '    : > "$TRACE_DIR/absence-attested"\n'
                    '  fi\n'
                    '  echo "LoadState=not-found"\n'
                    '  echo "ActiveState=inactive"; echo "FragmentPath="\n'
                    '  echo "UnitFileState="; echo "DropInPaths="\n'
                    '  echo "MainPID=0"; echo "RefuseManualStart=no"\n'
                    '  echo "Job="; exit 0\n'
                    'fi\n'
                    'exit 0\n')
                for client in ("claude", "codex"):
                    _fake_command(
                        fake_bin, client,
                        'echo "No MCP server named sia" >&2\nexit 1\n')
                _fake_command(fake_bin, "grok", 'echo "[]"\n')
                if inject_failure:
                    _write(
                        os.path.join(home, ".config/hypr/bindings.lua"),
                        "-- BEGIN SIA\nincomplete managed block\n")
                environment = os.environ.copy()
                environment.update({
                    "HOME": home,
                    "PATH": fake_bin + os.pathsep + environment["PATH"],
                    "TRACE_DIR": root,
                    "XDG_RUNTIME_DIR": runtime,
                })
                result = subprocess.run(
                    ["bash", os.path.join(REPO, "uninstall.sh")],
                    cwd=REPO, env=environment, text=True,
                    stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                    check=False)

                self.assertTrue(os.path.isfile(
                    os.path.join(root, "reload-seen")),
                    result.stdout + result.stderr)
                self.assertFalse(os.path.lexists(active))
                if inject_failure:
                    self.assertNotEqual(result.returncode, 0)
                    self.assertTrue(os.path.isfile(retired))
                    self.assertEqual(_read_path(retired), barrier_content)
                    self.assertFalse(os.path.lexists(
                        os.path.join(root, "retry-reload")))
                    self.assertFalse(os.path.lexists(
                        os.path.join(root, "absence-attested")))
                    self.assertIn(
                        "retired sia-brainstem barrier recovery copy retained",
                        result.stderr)
                else:
                    self.assertEqual(result.returncode, 0, result.stderr)
                    self.assertFalse(os.path.lexists(retired))
                    self.assertTrue(os.path.isfile(
                        os.path.join(root, "retry-reload")))
                    self.assertTrue(os.path.isfile(
                        os.path.join(root, "absence-attested")))
                    self.assertIn(
                        "uninstall completed successfully", result.stdout)

    def test_uninstaller_holds_owner_leases_through_verified_purge(self):
        with tempfile.TemporaryDirectory() as root:
            home = os.path.join(root, "home")
            fake_bin = os.path.join(root, "bin")
            purge_entered = os.path.join(root, "purge-entered")
            purge_continue = os.path.join(root, "purge-continue")
            contender_attempted = os.path.join(root, "contender-attempted")
            contender_acquired = os.path.join(root, "contender-acquired")
            os.makedirs(fake_bin)
            _write(os.path.join(
                home, ".local/share/sia/corpus/memory.md"), "retained\n")
            _fake_command(fake_bin, "systemctl", ABSENT_USER_UNIT)
            for client in ("claude", "codex"):
                _fake_command(
                    fake_bin, client,
                    'echo "No MCP server named sia" >&2\nexit 1\n')
            _fake_command(fake_bin, "grok", 'echo "[]"\n')
            _fake_command(
                fake_bin, "rm",
                'if [ "$#" -eq 3 ] && [ "$1" = -rf ] && [ "$2" = -- ] '
                '&& [ "$3" = "$HOME/.local/state/sia" ]; then\n'
                '  : > "$PURGE_ENTERED"\n'
                '  while [ ! -e "$PURGE_CONTINUE" ]; do /usr/bin/sleep 0.01; done\n'
                'fi\n'
                'exec /usr/bin/rm "$@"\n')
            environment = os.environ.copy()
            environment.update({
                "HOME": home,
                "PATH": fake_bin + os.pathsep + environment["PATH"],
                "PURGE_ENTERED": purge_entered,
                "PURGE_CONTINUE": purge_continue,
            })
            uninstaller = subprocess.Popen(
                ["bash", os.path.join(REPO, "uninstall.sh"), "--purge"],
                cwd=REPO, env=environment, text=True,
                stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            contender = None
            try:
                deadline = time.monotonic() + 30
                while not os.path.exists(purge_entered):
                    if uninstaller.poll() is not None:
                        stdout, stderr = uninstaller.communicate()
                        self.fail(
                            "uninstaller exited before purge gate: "
                            f"{stdout}\n{stderr}")
                    if time.monotonic() >= deadline:
                        self.fail("uninstaller did not reach the purge gate")
                    time.sleep(0.01)

                lock_path = os.path.join(
                    home, ".local/state/sia/corpus-owner.lock")
                probe = subprocess.run(
                    ["flock", "-n", lock_path, "true"],
                    env=environment, stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE, text=True, check=False)
                self.assertNotEqual(
                    probe.returncode, 0,
                    "corpus owner lease was released before purge")

                contender_code = (
                    "import fcntl, os, sys\n"
                    "fd = os.open(sys.argv[1], os.O_RDWR)\n"
                    "open(sys.argv[2], 'w').close()\n"
                    "fcntl.flock(fd, fcntl.LOCK_EX)\n"
                    "state = 'after-purge' if all("
                    "not os.path.lexists(path) for path in sys.argv[4:]) "
                    "else 'before-purge'\n"
                    "with open(sys.argv[3], 'w', encoding='utf-8') as stream:\n"
                    "    stream.write(state + '\\n')\n")
                contender = subprocess.Popen(
                    [sys.executable, "-c", contender_code, lock_path,
                     contender_attempted, contender_acquired,
                     os.path.join(home, ".local/state/sia"),
                     os.path.join(home, ".local/share/sia"),
                     os.path.join(home, ".config/sia")],
                    env=environment, stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE, text=True)
                while not os.path.exists(contender_attempted):
                    if contender.poll() is not None:
                        stdout, stderr = contender.communicate()
                        self.fail(
                            "owner-lock contender exited before flock: "
                            f"{stdout}\n{stderr}")
                    if time.monotonic() >= deadline:
                        self.fail("owner-lock contender did not start")
                    time.sleep(0.01)
                self.assertFalse(os.path.exists(contender_acquired))

                _write(purge_continue, "continue\n")
                stdout, stderr = uninstaller.communicate(timeout=30)
                self.assertEqual(uninstaller.returncode, 0, stderr)
                self.assertIn("purge verified:", stdout)
                contender_stdout, contender_stderr = contender.communicate(
                    timeout=30)
                self.assertEqual(contender.returncode, 0,
                                 contender_stdout + contender_stderr)
                self.assertEqual(_read_path(contender_acquired),
                                 "after-purge\n")
            finally:
                if not os.path.exists(purge_continue):
                    _write(purge_continue, "continue\n")
                for process in (contender, uninstaller):
                    if process is not None and process.poll() is None:
                        process.terminate()
                        try:
                            process.wait(timeout=30)
                        except subprocess.TimeoutExpired:
                            process.kill()
                            process.wait(timeout=30)

    def test_uninstaller_preserves_unowned_mcp_registration(self):
        uninstaller = _read("uninstall.sh")
        self.assertIn('marker="$MCP_MARKER_DIR/$client"', uninstaller)
        marker_guard = uninstaller.split("remove_managed_mcp()", 1)[1].split(
            "remove_managed_skill()", 1)[0]
        self.assertIn("exact unowned $client MCP registration preserved",
                      marker_guard)
        self.assertIn("RUNTIME_NEEDED_BY_MCP=1", marker_guard)

    def test_uninstaller_behavior_preserves_exact_unmarked_mcp_runtime(self):
        with tempfile.TemporaryDirectory() as root:
            home = os.path.join(root, "home")
            fake_bin = os.path.join(root, "bin")
            trace = os.path.join(root, "trace")
            os.makedirs(fake_bin)
            cli, runtime = _managed_cli_runtime(home)
            _fake_command(fake_bin, "systemctl", ABSENT_USER_UNIT)
            _fake_command(
                fake_bin, "claude",
                'echo "claude $*" >> "$TRACE"\n'
                'echo "sia:"\n'
                'echo "  Scope: User config (available in all your projects)"\n'
                'echo "  Status: Disconnected"\n'
                'echo "  Type: stdio"\n'
                'echo "  Command: python3"\n'
                'echo "  Args: $HOME/.local/share/sia/bin/sia-mcp"\n'
                'echo "  Environment:"\n'
                'echo\n')
            _fake_command(
                fake_bin, "codex",
                'echo "No MCP server named sia" >&2\nexit 1\n')
            _fake_command(fake_bin, "grok", 'echo "[]"\n')
            environment = os.environ.copy()
            environment.update({"HOME": home,
                                "PATH": fake_bin + os.pathsep
                                + environment["PATH"],
                                "TRACE": trace})
            result = subprocess.run(
                ["bash", os.path.join(REPO, "uninstall.sh")],
                cwd=REPO, env=environment, text=True,
                stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertTrue(os.path.isfile(cli))
            self.assertTrue(os.path.isdir(runtime))
            self.assertIn("exact unowned claude MCP registration preserved",
                          result.stdout)
            calls = _read_path(trace) if os.path.exists(trace) else ""
            self.assertNotIn("mcp remove", calls)
            guard = os.path.join(
                home, ".local/state/sia/mcp-consumer-guards/claude")
            self.assertEqual(
                _read_path(guard),
                _mcp_guard_contents(home, "claude", "exact-unmarked"))

    def test_uninstaller_keeps_owned_markers_on_mcp_format_drift(self):
        marker_bodies = {
            "pending": (
                "managed-by=khephri.sia\nstate=pending-add\n"
                "command=python3\narg={runtime}/sia-mcp\n"),
            "committed": (
                "managed-by=khephri.sia\nstate=committed\n"
                "command=python3\narg={runtime}/sia-mcp\n"),
            "legacy": (
                "managed-by=khephri.sia\ncommand=python3\n"
                "arg={runtime}/sia-mcp\n"),
            "invalid": "invalid ownership marker\n",
        }
        for marker_state, template in marker_bodies.items():
            with self.subTest(marker_state=marker_state), \
                    tempfile.TemporaryDirectory() as root:
                home = os.path.join(root, "home")
                fake_bin = os.path.join(root, "bin")
                trace = os.path.join(root, "trace")
                os.makedirs(fake_bin)
                cli, runtime = _managed_cli_runtime(home)
                marker = os.path.join(
                    home, ".local/state/sia/managed-mcp/claude")
                expected_marker = template.format(runtime=runtime)
                _write(marker, expected_marker)
                _fake_command(fake_bin, "systemctl", ABSENT_USER_UNIT)
                _fake_command(
                    fake_bin, "claude",
                    'echo "claude $*" >> "$TRACE"\n'
                    'echo "sia:"\n'
                    'echo "  Scope: User config (available in all your projects)"\n'
                    'echo "  Status: Connected"\n'
                    'echo "  Type: stdio"\n'
                    'echo "  Command: python3"\n'
                    'echo "  Args: $HOME/.local/share/sia/bin/sia-mcp"\n'
                    'echo "  Environment:"\n'
                    'echo "  New Field: benign display-format drift"\n'
                    'echo\n')
                _fake_command(
                    fake_bin, "codex",
                    'echo "No MCP server named sia" >&2\nexit 1\n')
                _fake_command(fake_bin, "grok", 'echo "[]"\n')
                environment = os.environ.copy()
                environment.update({
                    "HOME": home,
                    "PATH": fake_bin + os.pathsep + environment["PATH"],
                    "TRACE": trace,
                })
                result = subprocess.run(
                    ["bash", os.path.join(REPO, "uninstall.sh")],
                    cwd=REPO, env=environment, text=True,
                    stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                    check=False)
                self.assertNotEqual(result.returncode, 0)
                self.assertTrue(os.path.isfile(cli))
                self.assertTrue(os.path.isdir(runtime))
                self.assertEqual(_read_path(marker), expected_marker)
                self.assertFalse(os.path.lexists(os.path.join(
                    home,
                    ".local/state/sia/mcp-consumer-guards/claude")))
                self.assertNotIn("mcp remove", _read_path(trace))
                if marker_state == "invalid":
                    self.assertIn("invalid claude MCP ownership marker",
                                  result.stderr)
                else:
                    self.assertIn(
                        "registration references SIA but no longer verifies exactly; owned marker retained",
                        result.stderr)

    def test_uninstaller_guard_overrides_stale_ownership_marker(self):
        with tempfile.TemporaryDirectory() as root:
            home = os.path.join(root, "home")
            fake_bin = os.path.join(root, "bin")
            trace = os.path.join(root, "trace")
            os.makedirs(fake_bin)
            cli, runtime = _managed_cli_runtime(home)
            _write(os.path.join(
                home, ".local/state/sia/managed-mcp/claude"),
                "managed-by=khephri.sia\nstate=committed\ncommand=python3\n"
                f"arg={runtime}/sia-mcp\n")
            guard = os.path.join(
                home, ".local/state/sia/mcp-consumer-guards/claude")
            _write(guard, _mcp_guard_contents(
                home, "claude", "modified-reference"))
            _fake_command(fake_bin, "systemctl", ABSENT_USER_UNIT)
            _fake_command(
                fake_bin, "claude",
                'echo "claude $*" >> "$TRACE"\n'
                'echo "sia:"\n'
                'echo "  Scope: User config (available in all your projects)"\n'
                'echo "  Status: Connected"\n'
                'echo "  Type: stdio"\n'
                'echo "  Command: python3"\n'
                'echo "  Args: $HOME/.local/share/sia/bin/sia-mcp"\n'
                'echo "  Environment:"\n'
                'echo\n')
            _fake_command(
                fake_bin, "codex",
                'echo "No MCP server named sia" >&2\nexit 1\n')
            _fake_command(fake_bin, "grok", 'echo "[]"\n')
            environment = os.environ.copy()
            environment.update({
                "HOME": home,
                "PATH": fake_bin + os.pathsep + environment["PATH"],
                "TRACE": trace,
            })
            result = subprocess.run(
                ["bash", os.path.join(REPO, "uninstall.sh")],
                cwd=REPO, env=environment, text=True,
                stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertTrue(os.path.isfile(cli))
            self.assertTrue(os.path.isdir(runtime))
            self.assertTrue(os.path.isfile(guard))
            self.assertTrue(os.path.isfile(os.path.join(
                home, ".local/state/sia/managed-mcp/claude")))
            calls = _read_path(trace) if os.path.exists(trace) else ""
            self.assertNotIn("mcp remove", calls)
            self.assertIn("preserved by its durable non-ownership guard",
                          result.stdout)

    def test_generic_external_mcp_guard_preserves_cli_and_runtime(self):
        with tempfile.TemporaryDirectory() as root:
            home = os.path.join(root, "home")
            fake_bin = os.path.join(root, "bin")
            os.makedirs(fake_bin)
            cli, runtime = _managed_cli_runtime(home)
            generic_guard = os.path.join(
                home,
                ".local/state/sia/mcp-consumer-guards/my-resident-agent")
            _write(generic_guard, "operator guard: external MCP consumer\n")
            _fake_command(fake_bin, "systemctl", ABSENT_USER_UNIT)
            for client in ("claude", "codex"):
                _fake_command(
                    fake_bin, client,
                    'echo "No MCP server named sia" >&2\nexit 1\n')
            _fake_command(fake_bin, "grok", 'echo "[]"\n')
            environment = os.environ.copy()
            environment.update({
                "HOME": home,
                "PATH": fake_bin + os.pathsep + environment["PATH"],
            })
            result = subprocess.run(
                ["bash", os.path.join(REPO, "uninstall.sh")],
                cwd=REPO, env=environment, text=True,
                stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertTrue(os.path.isfile(cli))
            self.assertTrue(os.path.isdir(runtime))
            self.assertTrue(os.path.isfile(generic_guard))
            self.assertIn("durable external MCP consumer guard(s)",
                          result.stdout)

    def test_uninstaller_preserves_runtime_when_systemd_is_indeterminate(self):
        with tempfile.TemporaryDirectory() as root:
            home = os.path.join(root, "home")
            fake_bin = os.path.join(root, "bin")
            os.makedirs(fake_bin)
            cli, runtime = _managed_cli_runtime(home)
            _fake_command(fake_bin, "systemctl",
                          'echo "user manager unavailable" >&2\nexit 1\n')
            for client in ("claude", "codex"):
                _fake_command(
                    fake_bin, client,
                    'echo "No MCP server named sia" >&2\nexit 1\n')
            _fake_command(fake_bin, "grok", 'echo "[]"\n')
            environment = os.environ.copy()
            environment.update({"HOME": home,
                                "PATH": fake_bin + os.pathsep
                                + environment["PATH"]})
            result = subprocess.run(
                ["bash", os.path.join(REPO, "uninstall.sh"), "--purge"],
                cwd=REPO, env=environment, text=True,
                stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
            self.assertNotEqual(result.returncode, 0)
            self.assertTrue(os.path.isfile(cli))
            self.assertTrue(os.path.isdir(runtime))
            self.assertIn("inspect sia-brainstem.service state",
                          result.stderr)
            self.assertIn("purge blocked", result.stderr)

    def test_plugin_disable_failure_preserves_plugin_binding_cli_and_runtime(self):
        with tempfile.TemporaryDirectory() as root:
            home = os.path.join(root, "home")
            fake_bin = os.path.join(root, "bin")
            os.makedirs(fake_bin)
            cli, runtime = _managed_cli_runtime(home)
            plugin = os.path.join(
                home, ".config/omarchy/plugins/khephri.sia")
            binding = os.path.join(home, ".config/hypr/bindings.lua")
            _write(os.path.join(plugin, "manifest.json"), "{}\n")
            _write(binding, "before\n-- BEGIN SIA\nmanaged\n-- END SIA\n")
            _fake_command(fake_bin, "systemctl", ABSENT_USER_UNIT)
            _fake_command(fake_bin, "omarchy", "exit 1\n")
            for client in ("claude", "codex"):
                _fake_command(
                    fake_bin, client,
                    'echo "No MCP server named sia" >&2\nexit 1\n')
            _fake_command(fake_bin, "grok", 'echo "[]"\n')
            environment = os.environ.copy()
            environment.update({"HOME": home,
                                "PATH": fake_bin + os.pathsep
                                + environment["PATH"]})
            result = subprocess.run(
                ["bash", os.path.join(REPO, "uninstall.sh")],
                cwd=REPO, env=environment, text=True,
                stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
            self.assertNotEqual(result.returncode, 0)
            self.assertTrue(os.path.isdir(plugin))
            self.assertEqual(_read_path(binding),
                             "before\n-- BEGIN SIA\nmanaged\n-- END SIA\n")
            self.assertTrue(os.path.isfile(cli))
            self.assertTrue(os.path.isdir(runtime))
            self.assertIn("disable Omarchy plugin", result.stderr)

    def test_uninstaller_preserves_unmanaged_agent_skill(self):
        with tempfile.TemporaryDirectory() as root:
            home = os.path.join(root, "home")
            fake_bin = os.path.join(root, "bin")
            os.makedirs(fake_bin)
            _fake_command(
                fake_bin, "systemctl", ABSENT_USER_UNIT)
            skill_path = os.path.join(
                home, ".claude/skills/sia/SKILL.md")
            _write(skill_path, "user-owned skill\n")
            environment = os.environ.copy()
            environment.update({
                "HOME": home,
                "PATH": fake_bin + os.pathsep + environment["PATH"],
            })
            result = subprocess.run(
                ["bash", os.path.join(REPO, "uninstall.sh")],
                cwd=REPO, env=environment, text=True,
                stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertTrue(os.path.isfile(skill_path))
            self.assertIn("agent skill preserved", result.stdout)

    def test_uninstaller_returns_nonzero_and_names_failures(self):
        with tempfile.TemporaryDirectory() as root:
            home = os.path.join(root, "home")
            fake_bin = os.path.join(root, "bin")
            trace = os.path.join(root, "trace")
            os.makedirs(fake_bin)
            _fake_command(fake_bin, "systemctl", ABSENT_USER_UNIT)
            _fake_command(fake_bin, "hyprctl",
                          '[ "$1" != configerrors ]\n')
            bindings = os.path.join(home, ".config/hypr/bindings.lua")
            _write(bindings, "-- BEGIN SIA\nmanaged\n-- END SIA\n")
            environment = os.environ.copy()
            environment.update({
                "HOME": home,
                "PATH": fake_bin + os.pathsep + environment["PATH"],
                "TRACE": trace,
                "HYPRLAND_INSTANCE_SIGNATURE": "test-instance",
            })
            result = subprocess.run(
                ["bash", os.path.join(REPO, "uninstall.sh")],
                cwd=REPO, env=environment, text=True,
                stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
            self.assertNotEqual(result.returncode, 0)
            self.assertIn("validate Hyprland configuration", result.stderr)
            self.assertIn("uninstall completed with", result.stderr)
            self.assertEqual(
                _read_path(bindings),
                "-- BEGIN SIA\nmanaged\n-- END SIA\n")

    def test_uninstaller_blocks_purge_when_brainstem_cannot_stop(self):
        with tempfile.TemporaryDirectory() as root:
            home = os.path.join(root, "home")
            fake_bin = os.path.join(root, "bin")
            trace = os.path.join(root, "trace")
            os.makedirs(fake_bin)
            _fake_command(
                fake_bin, "systemctl",
                'echo "$*" >> "$TRACE"\n'
                'if [ "$1 $2" = "--user show" ]; then\n'
                '  echo "LoadState=loaded"; echo "ActiveState=active"\n'
                '  echo "FragmentPath=$HOME/.config/systemd/user/sia-brainstem.service"\n'
                '  echo "UnitFileState=enabled"; echo "DropInPaths="\n'
                '  echo "MainPID=123"; echo "RefuseManualStart=no"\n'
                '  echo "Job="; exit 0\n'
                'fi\n'
                'case "$*" in *"disable --now sia-brainstem.service"*) '
                'exit 1;; esac\nexit 0\n')
            retained = (
                ".local/share/sia/bin/sialib.py",
                ".local/share/sia/corpus/memory.md",
                ".local/state/sia/queue/request.json",
                ".config/sia/config.json",
                ".config/systemd/user/sia-brainstem.service",
            )
            for relative in retained:
                _write(os.path.join(home, relative), "must survive\n")
            unit = os.path.join(home, retained[-1])
            _write(os.path.join(
                home, ".local/state/sia/managed-install/"
                "sia-brainstem.service"),
                _managed_file_receipt(unit, "brainstem-unit"))
            environment = os.environ.copy()
            environment.update({
                "HOME": home,
                "PATH": fake_bin + os.pathsep + environment["PATH"],
                "TRACE": trace,
            })
            result = subprocess.run(
                ["bash", os.path.join(REPO, "uninstall.sh"), "--purge"],
                cwd=REPO, env=environment, text=True,
                stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
            self.assertNotEqual(result.returncode, 0)
            for relative in retained:
                self.assertTrue(os.path.isfile(os.path.join(home, relative)),
                                relative)
            self.assertIn("runtime preserved", result.stderr)
            self.assertIn("purge blocked", result.stderr)
            self.assertIn(
                "--user disable --now sia-brainstem.service",
                _read_path(trace))

    def test_uninstaller_preserves_incomplete_keybinding_block_and_tail(self):
        with tempfile.TemporaryDirectory() as root:
            home = os.path.join(root, "home")
            fake_bin = os.path.join(root, "bin")
            os.makedirs(fake_bin)
            _fake_command(
                fake_bin, "systemctl", ABSENT_USER_UNIT)
            bindings = os.path.join(home, ".config/hypr/bindings.lua")
            original = ("before\n-- BEGIN SIA "
                        "(managed by khephri.sia/install.sh)\n"
                        "managed\nuser tail must survive\n")
            _write(bindings, original)
            environment = os.environ.copy()
            environment.update({
                "HOME": home,
                "PATH": fake_bin + os.pathsep + environment["PATH"],
            })
            result = subprocess.run(
                ["bash", os.path.join(REPO, "uninstall.sh")],
                cwd=REPO, env=environment, text=True,
                stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
            self.assertNotEqual(result.returncode, 0)
            self.assertEqual(_read_path(bindings), original)
            self.assertIn("malformed SIA keybinding markers preserved",
                          result.stderr)
            self.assertIn("uninstall completed with", result.stderr)

    def test_repository_contains_no_symlinks(self):
        for root, dirs, files in os.walk(REPO):
            if ".git" in dirs:
                dirs.remove(".git")
            for name in dirs + files:
                path = os.path.join(root, name)
                self.assertFalse(os.path.islink(path),
                                 os.path.relpath(path, REPO))

    def test_ci_discovers_the_tests_directory_and_promotes_resource_leaks(self):
        workflow = _read(".github/workflows/ci.yml")
        self.assertRegex(workflow, r"(?m)^permissions:\n  contents: read$")
        self.assertIn("persist-credentials: false", workflow)
        self.assertIn("unittest discover -s tests -v", workflow)
        self.assertIn("PYTHONWARNINGS: error::ResourceWarning", workflow)
        self.assertIn("python3 -m json.tool manifest.json", workflow)
        self.assertIn("python3 -m json.tool config.example.json", workflow)
        self.assertIn("test -s schema-pack/pack.yaml", workflow)
        self.assertIn("test -s preview.png", workflow)
        self.assertIn(
            'git diff --check "$(git hash-object -t tree /dev/null)" HEAD --',
            workflow)
        self.assertIn("koalaman/shellcheck-alpine@sha256:", workflow)
        self.assertIn("--network none --cap-drop all", workflow)
        self.assertIn(
            "shellcheck /mnt/install.sh /mnt/uninstall.sh /mnt/bin/sia-setup",
            workflow)
        self.assertEqual(_workflow_run_block("shell syntax").splitlines(), [
            "set -euo pipefail",
            "bash -n install.sh",
            "bash -n uninstall.sh",
            "bash -n bin/sia-setup",
            "bash -n spark/check-event-pack-model.sh",
        ])
        uses = re.findall(r"uses:\s+([^@\s]+)@([^\s#]+)", workflow)
        self.assertTrue(uses)
        for action, revision in uses:
            self.assertRegex(revision, r"^[0-9a-f]{40}$", action)
        self.assertIn("actions/checkout@"
                      "3d3c42e5aac5ba805825da76410c181273ba90b1 # v7.0.1",
                      workflow)
        self.assertIn("actions/setup-python@"
                      "5fda3b95a4ea91299a34e894583c3862153e4b97 # v7.0.0",
                      workflow)
        self.assertNotIn("pip install cryptography", workflow)
        self.assertIn("cryptography==50.0.1", workflow)
        self.assertIn("cffi==2.0.0", workflow)
        self.assertIn("pycparser==3.0", workflow)
        self.assertIn("--only-binary=:all: --require-hashes", workflow)
        self.assertIn(
            "ff838d62ec1bfce4f9ba7fa16f4a7b554cd8d0c299e6be37502161a660c84eef",
            workflow)
        self.assertIn("https://pypi.org/pypi/cryptography/50.0.1/json",
                      workflow)

    def test_ci_shell_syntax_checks_every_script_without_execution(self):
        script = _workflow_run_block("shell syntax")
        names = ("install.sh", "uninstall.sh", "bin/sia-setup",
                 "spark/check-event-pack-model.sh")
        for damaged in (None,) + names:
            with self.subTest(damaged=damaged), tempfile.TemporaryDirectory() as root:
                for name in names:
                    content = "printf 'unexpected execution\\n' > executed\n"
                    if name == damaged:
                        content += "if then\n"
                    _write(os.path.join(root, name), content)
                result = subprocess.run(
                    ("bash", "--noprofile", "--norc", "-e", "-o", "pipefail",
                     "-c", script), cwd=root,
                    env={"PATH": os.defpath, "HOME": root, "LC_ALL": "C"},
                    text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                    timeout=3, check=False)
                self.assertFalse(os.path.exists(os.path.join(root, "executed")))
                self.assertEqual(result.stdout, "")
                self.assertEqual(result.returncode, 0 if damaged is None else 2,
                                 result.stderr)
                if damaged is None:
                    self.assertEqual(result.stderr, "")
                else:
                    self.assertIn(damaged + ": line 2:", result.stderr)
                    self.assertIn("syntax error", result.stderr)

    def test_ci_release_artifact_block_checks_committed_tree_damage(self):
        script = _workflow_run_block("release artifact contracts")
        with tempfile.TemporaryDirectory() as root:
            for relative, content in (
                    ("manifest.json", '{"version":"1.0.0"}\n'),
                    ("config.example.json", "{}\n"),
                    ("schema-pack/pack.yaml", "name: fixture\n"),
                    ("preview.png", "fixture\n"),
                    ("bad.txt", "clean\ntrailing-space \n"
                     "<<<<<<< HEAD\nleft\n=======\nright\n>>>>>>> topic\n")):
                _write(os.path.join(root, relative), content)
            for argv in (
                    ("init", "-q"),
                    ("config", "user.email", "ci@test.invalid"),
                    ("config", "user.name", "CI Fixture"),
                    ("add", "-A"),
                    ("commit", "-qm", "fixture")):
                subprocess.run(
                    ("git",) + argv, cwd=root, check=True,
                    stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            status = subprocess.run(
                ("git", "status", "--porcelain"), cwd=root, check=True,
                text=True, stdout=subprocess.PIPE,
                stderr=subprocess.PIPE)
            self.assertEqual(status.stdout, "")
            environment = os.environ.copy()
            environment.update({
                "GITHUB_REF_TYPE": "branch",
                "GITHUB_REF_NAME": "fixture",
            })
            result = subprocess.run(
                ("bash", "-e", "-o", "pipefail", "-c", script),
                cwd=root, env=environment, text=True,
                stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                check=False)
        detail = result.stdout + result.stderr
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("trailing whitespace", detail)
        self.assertIn("leftover conflict marker", detail)

    def test_cockpit_and_bar_share_the_configured_stale_threshold(self):
        cockpit = _read("Cockpit.qml")
        panel = _read("Panel.qml")
        model = _read("Model.js")
        manifest = json.loads(_read("manifest.json"))
        defaults = manifest["barWidget"]["defaults"]
        self.assertIn("staleAfterSec", defaults)
        schema = next(item for item in manifest["barWidget"]["schema"]
                      if item["key"] == "staleAfterSec")
        self.assertEqual(defaults["staleAfterSec"], schema["defaultValue"])
        for function, expected in (
                ("staleAfterMinSec", schema["min"]),
                ("staleAfterMaxSec", schema["max"]),
                ("staleAfterDefaultSec", schema["defaultValue"])):
            self.assertRegex(
                model,
                rf"function {function}\(\) \{{ return {expected} \}}")
        self.assertIn("validStaleAfterSec", cockpit)
        self.assertIn("validStaleAfterSec", panel)
        self.assertIn("root.shell.shellConfig", cockpit)
        self.assertRegex(
            cockpit,
            r"Model\.timestampStale\(\s*root\.status\.ts,\s*root\.nowMs,"
            r"\s*root\.staleAfterSec\)")
        self.assertIn(
            "interval: 1000; running: root.opened; repeat: true", cockpit)
        self.assertRegex(
            panel,
            r"Model\.timestampStale\(\s*parsed\.ts,\s*Date\.now\(\),"
            r"\s*root\.staleAfterSec\)")
        self.assertRegex(
            panel,
            r"Model\.timestampStale\(\s*root\.status\.ts,\s*root\.nowMs,"
            r"\s*root\.staleAfterSec\)")
        self.assertNotIn("root.staleAfterSec * 1000", panel)
        self.assertNotRegex(cockpit, r">\s*240\s*\*\s*1000")

    def test_cockpit_exposes_snapshot_and_live_memory_boundaries(self):
        cockpit = _read("Cockpit.qml")
        model = _read("Model.js")
        # Snapshot diagnostics cannot impersonate `sia ready`. The cockpit
        # must retain its graph-first design while keeping this boundary and
        # the v1.3 policy/agent projections visible to the operator.
        self.assertIn('"ready"', cockpit)
        self.assertIn("id: readyProc", cockpit)
        self.assertIn("id: readyTooltip", cockpit)
        self.assertIn("PUBLISHED SNAPSHOT", cockpit)
        self.assertIn("check live readiness", cockpit)
        self.assertIn("clearReadyCheck", cockpit)
        self.assertIn("function startCheck()", cockpit)
        self.assertIn("function cancel()", cockpit)
        self.assertIn("onStarted:", cockpit)
        self.assertIn("readyProc.launchPending", cockpit)
        self.assertIn("readyProc.markLaunchFailure()", cockpit)
        self.assertIn("readyProc.startCheck()", cockpit)
        self.assertIn("readyProc.cancel()", cockpit)
        self.assertNotIn("onErrorOccurred", cockpit)
        self.assertIn("anchors.rightMargin: wsMapState.visible", cockpit)
        self.assertNotIn("width: visible ? implicitWidth : 0", cockpit)
        self.assertIn("projectionDebtKeys", cockpit)
        self.assertIn("projectionDebtKnown", cockpit)
        self.assertIn("DEBT UNKNOWN", cockpit)
        self.assertIn("validStatusSnapshot", cockpit)
        self.assertIn("MEMORY LENS", cockpit)
        self.assertIn("AGENT RELAY — last published pulse", cockpit)
        self.assertIn("off-map", cockpit)
        # The retained-source card replaces compatibility workspace slugs;
        # off-map remains a display limit, never loss of retained selection.
        self.assertIn("Off-map is only a graph-display limit", cockpit)
        self.assertIn("compatibility slugs are not used here", cockpit)
        self.assertNotIn("root.currentStatus.workspace", cockpit)
        self.assertIn("CORPUS-LINKED RELATIONS", cockpit)
        self.assertIn("Model.originLabel", cockpit)
        self.assertIn('return "record"', model)
        self.assertIn("function edgeColor", model)
        self.assertIn("function originLabel", model)

    def test_cockpit_workspace_lock_and_memory_lens_fit(self):
        cockpit = _read("Cockpit.qml")
        panel = _read("Panel.qml")
        manifest = json.loads(_read("manifest.json"))
        defaults = manifest["barWidget"]["defaults"]
        self.assertEqual(defaults["cockpitWorkspace"], "")
        workspace_schema = next(
            item for item in manifest["barWidget"]["schema"]
            if item["key"] == "cockpitWorkspace")
        self.assertEqual(workspace_schema["type"], "string")
        self.assertEqual(workspace_schema["defaultValue"], "")

        # Layer-shell surfaces have no native Hyprland workspace assignment.
        # The cockpit must gate its own visibility and input focus, keep its
        # settings entry intact, and expose an ordinary host close lifecycle.
        self.assertIn("import Quickshell.Hyprland", cockpit)
        self.assertIn("Hyprland.focusedWorkspace", cockpit)
        self.assertIn("workspaceLockMismatch", cockpit)
        self.assertIn("visible: root.cockpitVisible", cockpit)
        self.assertIn("WlrKeyboardFocus.None", cockpit)
        self.assertIn("function toggleWorkspaceLock()", cockpit)
        self.assertIn("function close()", cockpit)
        self.assertIn("function configuredPluginSettings()", cockpit)
        self.assertIn("root.clearWorkspaceLock()", cockpit)
        self.assertNotIn("Hyprland.dispatch", cockpit)
        self.assertNotIn("hyprctl dispatch", cockpit)
        self.assertIn("cockpitWorkspace", panel)

        # Native Qt tooltips use a bright default surface. Cockpit hover help
        # must use Omarchy's themed primitive, including the readiness detail.
        self.assertEqual(cockpit.count("PanelToolTip {"), 2)
        self.assertIn("panelForeground: root.fg", cockpit)

        # Grid column widths, rather than the rail width, constrain the
        # values so strings such as "demoted" are allowed to wrap in place.
        self.assertIn("width: vitalsCol.width", cockpit)
        self.assertIn("readonly property real labelWidth", cockpit)
        self.assertIn("readonly property real valueWidth", cockpit)
        self.assertIn("width: memoryLens.valueWidth; wrapMode: Text.WordWrap",
                      cockpit)

        for document in (_read("README.md"), _read("docs/MANUAL.md"),
                         _read("CHANGELOG.md")):
            self.assertIn("workspace lock", document.casefold())

    def test_cockpit_continuity_actions_are_async_accessible_and_guarded(self):
        cockpit = _read("Cockpit.qml")
        panel = _read("Panel.qml")
        model = _read("Model.js")

        status_path = "/.local/state/sia-continuity/status.json"
        self.assertIn(status_path, cockpit)
        self.assertIn(status_path, panel)
        self.assertIn(
            "Model.validContinuityStatus(parsed, receiptAuthenticated)",
            cockpit)
        self.assertIn(
            "Model.validContinuityStatus(parsed, receiptAuthenticated)",
            panel)
        self.assertIn("last good continuity status", cockpit)

        # Continuity is deliberately above ordinary status counts, while the graph
        # remains the central cockpit instrument.
        self.assertLess(cockpit.index('text: "CONTINUITY"'),
                        cockpit.index('text: "STATUS COUNTS"'))
        self.assertIn("id: continuityLayer", cockpit)
        self.assertIn("parent: keyCatcher", cockpit)

        # The QML process only hands explicit argv to SIA. Accepted work is
        # status-file driven and is never canceled merely because the overlay
        # closes.
        for command in (
                '["backup", "now"]', '["backup", "check"]',
                '["restore", "prepare", snapshot]'):
            self.assertIn(command, cockpit)
        self.assertIn(
            '["restore", "apply", prepared.prepared_id, "--confirm-stdin"]',
            cockpit)
        self.assertIn('"backup", "setup", "--repository"', cockpit)
        self.assertIn('"backup", "connect", "--repository"', cockpit)
        self.assertIn('"--identity-key-out", identityKey', cockpit)
        self.assertNotIn("continuityProc.cancel()", cockpit)
        self.assertNotIn('["bash", "-c"', cockpit)
        self.assertNotIn('prepared.prepared_id, "--confirm"]', cockpit)

        # The destructive ceremony travels as one bounded stdin record, never
        # in argv or a reusable confirmation file. The process and form copies
        # are cleared after hand-off.
        self.assertIn("stdinEnabled: true", cockpit)
        self.assertIn('continuityProc.write(inputLine + "\\n")', cockpit)
        self.assertIn('continuityProc.stdinPayload = ""', cockpit)
        self.assertIn("maximumLength: root.continuityInputMaxLength", cockpit)
        for field in (
                "phrase: root.restorePhraseInput",
                "snapshot_id: root.restorePreparedSnapshotInput",
                "ledger_head: root.restoreLedgerHeadInput",
                "corpus_receipt_re_adopt: true"):
            self.assertIn(field, cockpit)
        self.assertIn('root.restorePhraseInput === "RESTORE"', cockpit)
        self.assertIn("root.restoreReceiptReadoptAck", cockpit)
        self.assertIn("Ui.Toggle", cockpit)
        self.assertIn("Accessible.role: Accessible.CheckBox", cockpit)
        self.assertNotIn("--confirmation-file", cockpit)

        # Restore is accessible from the card but application remains a
        # separate, destructive confirmation whose keyboard default is Cancel.
        self.assertIn("Ui.ConfirmDialog", cockpit)
        self.assertIn("selectedIndex: 0", cockpit)
        self.assertIn("continuityRestoreConfirm.handleKey(event)", cockpit)
        self.assertIn("context: Qt.WindowShortcut", cockpit)
        self.assertIn("Accessible.role: Accessible.Button", cockpit)
        self.assertIn("focusable: true", cockpit)
        self.assertIn("function validRestoreAcceptance", cockpit)
        self.assertIn("function matchingRestoreOperation", cockpit)
        self.assertIn("operation.request_id === root.restoreRequestId", cockpit)
        self.assertIn('operation.kind === "restore-apply"', cockpit)
        self.assertIn("operation.prepared_id === root.restoreExpectedPreparedId",
                      cockpit)
        self.assertIn("operation.ready", cockpit)
        self.assertIn("operation.sia_ledger_verified", cockpit)
        self.assertNotIn("restoreObservedRunning", cockpit)
        self.assertIn(
            "Success is withheld until SIA reports ready", cockpit)

        # Right-click is a deep link, not a direct destructive action.
        self.assertIn('{\\"mode\\":\\"continuity\\"}', panel)
        self.assertIn("right-click for continuity", panel)

        self.assertIn("function validContinuityStatus", model)
        self.assertIn('/^[0-9a-f]{64}$/.test(value.ledger_head)', model)
        self.assertIn('typeof value.identity_matches === "boolean"', model)
        self.assertIn("function validContinuityOperation", model)
        self.assertIn(
            "validContinuityCorrelationId(value.request_id)", model)
        self.assertIn('typeof value.sia_ledger_verified !== "boolean"', model)
        self.assertIn("recordHasExactly(value, CONTINUITY_STATUS_FIELDS)",
                      model)
        self.assertIn("Model.strictContinuityJsonParse(text)", cockpit)
        self.assertIn("Model.strictContinuityJsonParse(text)", panel)
        self.assertNotIn('return "PROTECTED"', model)
        for state in (
                "unconfigured", "queued", "capturing", "uploading",
                "checking", "preparing", "prepared", "restoring",
                "verified", "recovery-only", "failed", "blocked"):
            self.assertIn(f'"{state}"', model)

    def test_continuity_timer_policy_is_explicit(self):
        timers = {
            "systemd/sia-backup.timer": (
                "OnCalendar=hourly", "Unit=sia-backup.service"),
            "systemd/sia-backup-check.timer": (
                "OnCalendar=weekly", "Unit=sia-backup-check.service"),
        }
        for path, (calendar, target) in timers.items():
            with self.subTest(path=path):
                unit = _read(path)
                self.assertIn(calendar, unit)
                self.assertIn(target, unit)
                self.assertIn("Persistent=true", unit)
                self.assertIn("WakeSystem=false", unit)

    def test_recovery_boundaries_are_operator_visible(self):
        readme = _read("README.md")
        manual = _read("docs/MANUAL.md")
        changelog = _read("CHANGELOG.md")
        for document in (readme, manual, changelog):
            self.assertIn("corpus-bootstrap", document)
            self.assertIn("corpus-adoption", document)
            self.assertIn("GENESIS:init", document)
            self.assertIn("gbrain-bootstrap", document)
            self.assertIn("database_path", document)
        for document in (readme, manual):
            self.assertIn("prepared", document)
            self.assertIn("publishing", document)
            self.assertIn("published", document)
            folded = " ".join(document.split())
            self.assertIn("destination `.gbrain` root", folded)
            self.assertIn("`brain.pglite`", folded)
            self.assertIn("managed receipt", folded)
            self.assertIn("unknown children", folded)
            self.assertIn("generation-CAS rebind", document)
        self.assertIn("`key.hex`, then the matching `pub.hex`", readme)
        self.assertIn("one canonical signed", readme)
        self.assertIn("`GENESIS:init` row in `ledger.tsv`", readme)
        self.assertIn("then the matching `head.pin`", readme)
        self.assertNotIn("before it begins mutation", readme)
        self.assertNotIn("Before mutation, the installer", manual)
        self.assertNotRegex(
            manual,
            r"(?m)^\s*(?:rm|mv)\s+[^\n]*[.]gbrain(?:/|\s|$)")

    def test_agent_note_privacy_boundary_is_consistent(self):
        readme = _read("README.md")
        manual = _read("docs/MANUAL.md")
        skill = _read("skill/SKILL.md")
        mcp = _read("bin/sia-mcp")
        for document in (readme, manual, skill, mcp):
            self.assertIn("credentials", document)
            self.assertIn("persist", document.lower())
        self.assertIn("secrecy guarantee", readme)
        self.assertIn("secrecy guarantee", manual)
        self.assertIn("no cloud or external network calls", skill)
        self.assertIn("no cloud or external network calls", manual)


if __name__ == "__main__":
    unittest.main(verbosity=2)

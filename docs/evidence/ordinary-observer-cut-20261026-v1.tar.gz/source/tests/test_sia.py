#!/usr/bin/env python3
"""SIA test suite — the invariants the whitepaper claims were verified in
review, now shipped as executable checks. unittest, never pytest; it
never opens a socket, starts the daemon, or reads resident memory. It is
NOT, however, pure stdlib: `cryptography` is imported at module scope and
is load-bearing (Ed25519 ledger fixtures), chain and vault fixtures shell
out to git, and the process-bound tests read /proc — so importing it
needs `cryptography` and running it needs a Linux host with git. Run:
python3 -m unittest -v tests.test_sia (from the repo root), or
./tests/test_sia.py.

Covers the load-bearing correctness properties a reviewer would poke at
first: cursor/replay semantics, epoch-merge idempotence, ledger verify,
PageRank mass conservation, novelty-as-absence, empirical surprise incl.
absence detection, redaction fail-closed, and touch-source weighting.
"""

import ast, contextlib, copy, datetime, fcntl, hashlib, importlib.machinery
import importlib.util, io, json, os, re, shlex, shutil, sqlite3, stat
import subprocess, sys, tempfile, time, unittest
from unittest import mock

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

try:
    import sia_test_home  # test-only import-time path isolation
except ModuleNotFoundError:
    from tests import sia_test_home  # type: ignore

REPO = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BIN = os.path.join(REPO, "bin")


def _load(name, path):
    if not path.endswith(".py"):
        loader = importlib.machinery.SourceFileLoader(name, path)
        spec = importlib.util.spec_from_loader(name, loader)
    else:
        spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod

siamind = _load("siamind", os.path.join(BIN, "siamind.py"))


def _empty_graph_snapshot():
    return {
        "v": 2, "ts": "2026-08-30T12:00:00Z",
        "publication_id": "b" * 32,
        "nodes": [], "edges": [], "pages_total": 0,
        "pages_total_complete": True,
        "snapshot": {
            "complete": True, "truncated": 0,
            "omitted_nodes": 0, "omitted_edges": 0,
            "omissions_imply_absence": False,
            "aged_out": 0, "counts_by_kind": {},
            "failed_ops": [], "window_days": 14,
        },
    }


class TailCursors(unittest.TestCase):
    """Cursor semantics: first-run establishes without replay; truncation
    resets without replay; append yields only the new tail; torn byte
    tails wait for a whole line."""

    def setUp(self):
        self.tmp = tempfile.NamedTemporaryFile(mode="w", suffix=".log",
                                               delete=False)
        self.path = self.tmp.name
        self.tmp.close()
        self.cur = {}

    def tearDown(self):
        os.unlink(self.path)

    def _write(self, lines):
        with open(self.path, "w") as f:
            f.write("".join(l + "\n" for l in lines))

    def test_first_run_no_replay(self):
        self._write(["a", "b", "c"])
        self.assertEqual(siamind and [] or [], [])  # module import sanity
        import importlib
        sialib = _load("sialib", os.path.join(BIN, "sialib.py"))
        got = sialib.tail_lines(self.path, self.cur, "k")
        self.assertEqual(got, [], "first run must emit nothing")
        self.assertEqual(self.cur["k"], 3)

    def test_append_tail_only(self):
        sialib = _load("sialib", os.path.join(BIN, "sialib.py"))
        self._write(["a", "b"])
        sialib.tail_lines(self.path, self.cur, "k")
        self._write(["a", "b", "c", "d"])
        got = sialib.tail_lines(self.path, self.cur, "k")
        self.assertEqual(got, ["c", "d"])

    def test_truncation_replays_reachable_replacement(self):
        sialib = _load("sialib", os.path.join(BIN, "sialib.py"))
        self._write(["a", "b", "c", "d", "e"])
        sialib.tail_lines(self.path, self.cur, "k")
        self._write(["x", "y"])            # file shrank (rotation)
        got = sialib.tail_lines(self.path, self.cur, "k")
        self.assertEqual(got, ["x", "y"],
                         "replacement rows must not be silently skipped")
        self.assertEqual(self.cur["k"], 2)

    def test_moved_file_with_matching_fingerprints_continues_without_replay(self):
        """rsync, a btrfs subvolume change, or a restore by copy gives a log a
        new device/inode with identical bytes; the cursor must continue at
        its offset (and record the new identity) rather than replay."""
        sialib = _load("sialib", os.path.join(BIN, "sialib.py"))
        self._write(["a", "b", "c"])
        sialib.tail_lines(self.path, self.cur, "k")
        self.assertEqual(self.cur["k"], 3)
        recorded = (self.cur["k.device"], self.cur["k.inode"])
        copied = self.path + ".copy"
        with open(self.path, "rb") as source, open(copied, "wb") as target:
            target.write(source.read())
        os.replace(copied, self.path)
        moved = os.stat(self.path)
        self.assertNotEqual(recorded, (moved.st_dev, moved.st_ino))
        self.assertEqual(sialib.tail_lines(self.path, self.cur, "k"), [],
                         "identical content under a new inode must not replay")
        self.assertEqual(self.cur["k"], 3)
        self.assertEqual(self.cur["k.generation"], 0)
        self.assertEqual((self.cur["k.device"], self.cur["k.inode"]),
                         (moved.st_dev, moved.st_ino))
        self._write(["a", "b", "c", "d"])
        self.assertEqual(sialib.tail_lines(self.path, self.cur, "k"), ["d"])
        # Different content under a new inode is still a replacement.
        with open(copied, "w", encoding="utf-8") as stream:
            stream.write("x\ny\n")
        os.replace(copied, self.path)
        self.assertEqual(sialib.tail_lines(self.path, self.cur, "k"), ["x", "y"])
        self.assertEqual(self.cur["k.generation"], 1)

    def test_same_or_larger_replacement_replays_after_digest_bootstrap(self):
        sialib = _load("sialib", os.path.join(BIN, "sialib.py"))
        self._write(["a", "b"])
        sialib.tail_lines(self.path, self.cur, "k")
        self._write(["x", "y", "z"])
        got = sialib.tail_lines(self.path, self.cur, "k")
        self.assertEqual(got, ["x", "y", "z"])
        self.assertEqual(self.cur["k.generation"], 1)

    def test_legacy_cursor_without_digest_replays_once_on_upgrade(self):
        sialib = _load("sialib", os.path.join(BIN, "sialib.py"))
        self._write(["a", "b", "c"])
        self.cur["k"] = 2
        got = sialib.tail_lines(self.path, self.cur, "k")
        self.assertEqual(got, ["a", "b", "c"])
        self.assertIn("k.prefix_sha256", self.cur)

    def test_partial_or_malformed_cursor_metadata_cannot_rebaseline(self):
        sialib = _load(
            "sialib_cursor_metadata", os.path.join(BIN, "sialib.py"))
        self._write(["unseen"])
        for cursor in (
                {"k.cursor_v": True},
                {"k.offset": 0},
                {"k": 0, "k.generation": 0}):
            with self.subTest(cursor=cursor):
                prior = dict(cursor)
                with self.assertRaisesRegex(ValueError, "cursor metadata"):
                    sialib.tail_lines(self.path, cursor, "k")
                self.assertEqual(cursor, prior)

    def test_same_inode_rewrite_after_read_cannot_advance_cursor(self):
        sialib = _load(
            "sialib_cursor_post_read_rewrite", os.path.join(BIN, "sialib.py"))
        with open(self.path, "wb") as stream:
            stream.write(b"old\n")
        cursor = {}
        original_identity = sialib._source_path_identity

        def rewrite_then_reopen(path, flags):
            with open(path, "r+b") as stream:
                stream.write(b"new\n")
                stream.flush()
                os.fsync(stream.fileno())
            return original_identity(path, flags)

        with mock.patch.dict(os.environ, {"SIA_BACKFILL": "1"}), \
                mock.patch.object(
                    sialib, "_source_path_identity",
                    side_effect=rewrite_then_reopen), \
                self.assertRaisesRegex(RuntimeError, "changed while cursoring"):
            sialib._stable_tail_chunk(self.path, cursor, "k", 16)
        self.assertEqual(cursor, {})

    def test_torn_byte_tail_waits(self):
        sialib = _load("sialib", os.path.join(BIN, "sialib.py"))
        with open(self.path, "w") as f:
            f.write("first line\n")
        sialib.tail_bytes(self.path, self.cur, "b")
        with open(self.path, "a") as f:
            f.write("second line\nthird partial")   # no trailing newline
        data = sialib.tail_bytes(self.path, self.cur, "b")
        self.assertTrue(data.endswith(b"line\n"))
        self.assertNotIn(b"partial", data)          # torn tail withheld

    def test_bounded_line_windows_make_resumable_progress(self):
        sialib = _load("sialib_tail_window", os.path.join(BIN, "sialib.py"))
        self._write(["aa", "bb", "cc", "dd"])
        with mock.patch.dict(os.environ, {"SIA_BACKFILL": "1"}), \
                mock.patch.object(sialib, "MAX_SOURCE_TAIL_BYTES", 16), \
                mock.patch.object(sialib, "MAX_SOURCE_TAIL_RECORDS", 2), \
                mock.patch.object(sialib, "SOURCE_CURSOR_GUARD_BYTES", 4):
            first = sialib.tail_line_records(self.path, self.cur, "window")
            first_offset = self.cur["window.offset"]
            second = sialib.tail_line_records(self.path, self.cur, "window")
        self.assertEqual([row[2] for row in first], ["aa", "bb"])
        self.assertEqual([row[2] for row in second], ["cc", "dd"])
        self.assertLess(first_offset, self.cur["window.offset"])

    def test_only_literal_lf_advances_the_physical_record_ordinal(self):
        sialib = _load("sialib_literal_lf", os.path.join(BIN, "sialib.py"))
        with open(self.path, "w", encoding="utf-8") as stream:
            stream.write("alpha\u2028omega\nsecond\n")
        with mock.patch.dict(os.environ, {"SIA_BACKFILL": "1"}):
            rows = sialib.tail_line_records(self.path, self.cur, "physical")
        self.assertEqual([row[1] for row in rows], [0, 1])
        self.assertEqual([row[2] for row in rows],
                         ["alpha\u2028omega", "second"])

    def test_invalid_utf8_signable_refusal_advances_only_one_record(self):
        sialib = _load("sialib_invalid_utf8", os.path.join(BIN, "sialib.py"))
        with open(self.path, "wb") as stream:
            stream.write(b"invalid-\xff\nlater\n")
        with mock.patch.dict(os.environ, {"SIA_BACKFILL": "1"}):
            rows = sialib.tail_line_records(
                self.path, self.cur, "invalid")
            refusal = sialib._take_source_record_refusals(self.cur)
            later = sialib.tail_line_records(
                self.path, self.cur, "invalid")
        self.assertEqual(rows, [])
        self.assertEqual(len(refusal), 1)
        self.assertEqual(refusal[0]["reason"], "invalid-utf8-record")
        self.assertEqual(refusal[0]["ordinal"], 0)
        self.assertEqual([row[2] for row in later], ["later"])


class SourceReplayJournal(unittest.TestCase):
    def setUp(self):
        self.sialib = _load(
            "sialib_source_replay_test", os.path.join(BIN, "sialib.py"))
        self.when = datetime.datetime(
            2026, 8, 30, 12, 0, tzinfo=datetime.timezone.utc)

    def _event(self, summary="observed row"):
        return self.sialib.Event(
            "custom", self.when, "event", summary,
            {"organs/custom"}, {"custom"},
            occurrence="custom:demo:0:7")

    def _notification_event(self, name="fresh.json"):
        token = self.sialib._source_entity_token(name, "notification")
        return self.sialib.Event(
            "notify", self.when, "notification", "new notification",
            {"organs/notify"}, {"notification"},
            occurrence=f"notification:{token}")

    def _effects(self):
        return {"day": "2026-08-30", "events_pulse": 1,
                "organs": {"custom": {
                    "today": 1, "last_ts": "2026-08-30T12:00:00Z"}}}

    def _marker(self, events, sources):
        effects = self._effects()
        effects["events_pulse"] = len(events)
        return self.sialib._source_replay_marker_value(
            {}, 9, sources, events, effects)

    def _generation(self):
        return {"device": 1, "inode": 2, "size": 3,
                "mtime_ns": 4, "ctime_ns": 5}

    def test_notification_replay_authority_matrix_is_fail_closed(self):
        event = self._notification_event()
        marker = self._marker([event], {"sense_notify"})
        exact = {"schema": "sia-notification-baseline-v1",
                 "kind": "exact", "names": ["old.json"]}
        empty = {"schema": "sia-notification-baseline-v1",
                 "kind": "exact", "names": []}
        filter_bits = self.sialib._notify_filter_add(
            self.sialib._notify_scan_candidate(None)["baseline_bits"],
            "old.json")
        filter_baseline = {
            "schema": "sia-notification-baseline-v1",
            "kind": "filter", "bits": filter_bits}
        page = {**self._generation(), "cookie": 1, "reset": False}
        scan = {
            "schema": "sia-notification-directory-scan-v3",
            "generation": self._generation(), "sources": [],
            "truncated": False,
            "baseline_bits": self.sialib._notify_scan_candidate(
                None)["baseline_bits"],
        }
        valid = (
            {"notify.baseline": exact,
             "notify.generation": self._generation()},
            {"notify.baseline": filter_baseline,
             "notify.generation": self._generation()},
            {"notify.last": ""},
            {"notify.baseline": empty,
             "notify.scan_mode": "empty-replay"},
            {"notify.baseline": empty,
             "notify.scan_mode": "empty-replay",
             "source.notify.page": page, "notify.scan": scan},
        )
        for cursors in valid:
            with self.subTest(valid=cursors):
                self.assertIs(
                    self.sialib._authorize_pending_source_replay(
                        marker, cursors), marker)

        opaque = {"schema": "sia-notification-baseline-v1",
                  "kind": "opaque", "cause": "v2-migration"}
        invalid = (
            {"notify.generation": self._generation()},
            {"notify.baseline": opaque,
             "notify.generation": self._generation()},
            {"notify.baseline": None,
             "notify.generation": self._generation()},
            {"notify.baseline": {"schema": "wrong"},
             "notify.generation": self._generation()},
            {"notify.baseline": empty,
             "notify.generation": None,
             "notify.scan_mode": "empty-replay"},
            {"notify.last": "old.json"},
            {"notify.last": "", "notify.pending": []},
            {"source.notify.page": {}},
            {"notify.baseline": empty,
             "notify.scan_mode": "empty-replay",
             "notify.scan_tainted": "yes"},
        )
        for cursors in invalid:
            with self.subTest(invalid=cursors), self.assertRaisesRegex(
                    self.sialib.SourceReplayQuarantine,
                    "notification cursor authority is ambiguous"):
                self.sialib._authorize_pending_source_replay(
                    marker, cursors)

    def test_notification_diagnostics_require_owned_cursor_authority(self):
        diagnostic = self.sialib.Event(
            "notify", self.when, "source-truncated", "bounded refusal",
            {"organs/notify"}, {"refusal"},
            occurrence="source-truncated:notify:notification-history")
        custom_collision = self.sialib.Event(
            "notify", self.when, "notification", "custom row",
            {"organs/notify"}, {"custom"},
            occurrence="custom:demo:0:7")
        diagnostic_marker = self._marker([diagnostic], {"sense_notify"})
        with self.assertRaisesRegex(
                self.sialib.SourceReplayQuarantine,
                "notification cursor authority is ambiguous"):
            self.sialib._authorize_pending_source_replay(
                diagnostic_marker, {})
        opaque = {
            "notify.baseline": {
                "schema": "sia-notification-baseline-v1",
                "kind": "opaque", "cause": "baseline-unstable",
            },
            "notify.scan_mode": "replay",
        }
        self.assertIs(
            self.sialib._authorize_pending_source_replay(
                diagnostic_marker, opaque), diagnostic_marker)

        custom_marker = self._marker(
            [custom_collision], {"sense_custom:demo"})
        self.assertIs(
            self.sialib._authorize_pending_source_replay(custom_marker, {}),
            custom_marker)

    def test_notification_marker_without_source_ownership_is_quarantined(self):
        marker = self._marker(
            [self._notification_event()], {"sense_custom:demo"})
        with self.assertRaisesRegex(
                self.sialib.SourceReplayQuarantine,
                "notification-source ownership"):
            self.sialib._authorize_pending_source_replay(
                marker, {"notify.last": ""})

    def test_preupgrade_quarantine_precedes_live_generation_recovery(self):
        with mock.patch.object(
                self.sialib, "_recover_pending_live_generation",
                side_effect=AssertionError("live recovery before source authority")):
            self.test_preupgrade_notification_batch_refuses_before_any_recovery()

    def test_preupgrade_notification_batch_refuses_before_any_recovery(self):
        with tempfile.TemporaryDirectory() as state:
            memo_path = os.path.join(state, "memo.json")
            cursor_path = os.path.join(state, "cursors.json")
            mind_path = os.path.join(state, "mind.json")
            corpus = os.path.join(state, "corpus")
            events = [self._notification_event(), self._event()]
            source = self._marker(
                events, {"sense_notify", "sense_custom:demo"})
            pulse = {
                "v": 1, "seq": 9, "id": "c" * 32,
                "started_at": source["started_at"],
                "effects": source["effects"],
            }
            memo = {
                # Model the caller's already-durable reservation for the
                # attempted pulse while retaining the older publication.
                "pulse_seq": 10, "sync_needed": True,
                "pulse_publication": pulse,
                "source_replay_pending": source,
            }
            cursors = {"notify.generation": self._generation()}
            mind = self.sialib.siamind._empty_mind()
            mind["event_batch_applied"] = source["id"]
            with mock.patch.object(self.sialib, "MEMO_PATH", memo_path), \
                    mock.patch.object(
                        self.sialib, "CURSORS_PATH", cursor_path), \
                    mock.patch.object(self.sialib, "CORPUS", corpus), \
                    mock.patch.object(
                        self.sialib.siamind, "MIND_PATH", mind_path):
                self.sialib._write_memo(memo)
                self.sialib.save_cursors(cursors)
                self.sialib.siamind.save_mind(mind)
                paths = (memo_path, cursor_path, mind_path)

                def read_bytes(path):
                    with open(path, "rb") as stream:
                        return stream.read()

                before = {path: read_bytes(path) for path in paths}
                day_page = os.path.join(
                    corpus, "events", "notify", "2026-08-30.md")
                forbidden = (
                    mock.patch.object(
                        self.sialib, "ensure_dirs",
                        side_effect=AssertionError("directory mutation")),
                    mock.patch.object(
                        self.sialib, "_write_memo",
                        side_effect=AssertionError("memo mutation")),
                    mock.patch.object(
                        self.sialib, "load_thoughts",
                        side_effect=AssertionError("thought recovery")),
                    mock.patch.object(
                        self.sialib, "update_day_page",
                        side_effect=AssertionError("page publication")),
                    mock.patch.object(
                        self.sialib, "export_status",
                        side_effect=AssertionError("status publication")),
                    mock.patch.object(
                        self.sialib.siamind, "save_mind",
                        side_effect=AssertionError("mind mutation")),
                    mock.patch.object(
                        self.sialib, "save_cursors",
                        side_effect=AssertionError("cursor mutation")),
                )
                with contextlib.ExitStack() as stack:
                    for patcher in forbidden:
                        stack.enter_context(patcher)
                    entries = (
                        (self.sialib._pulse_transaction, (10,)),
                        (self.sialib._dream_transaction, ()),
                    )
                    for entry, args in entries:
                        with self.subTest(entry=entry.__name__), \
                                self.assertRaisesRegex(
                                    self.sialib.SourceReplayQuarantine,
                                    "notification cursor authority is "
                                    "ambiguous"):
                            entry(*args)
                after = {path: read_bytes(path) for path in paths}
                self.assertEqual(after, before)
                self.assertEqual(
                    self.sialib.load_memo()["source_replay_pending"], source)
                self.assertFalse(os.path.exists(day_page))
                with mock.patch.object(
                        self.sialib, "corpus_owner",
                        return_value=contextlib.nullcontext()), \
                        mock.patch.object(
                            self.sialib, "_cortex_boundary_status",
                            return_value=(True, "")):
                    ready, reason = self.sialib.memory_readiness()
                self.assertFalse(ready)
                self.assertIn("source replay quarantine", reason)

    def test_replay_record_round_trip_binds_timestamp_and_meaning(self):
        original = self._event()
        record = self.sialib._event_replay_record(original)
        replay = self.sialib._event_from_replay_record(record)
        self.assertEqual(replay.ts, original.ts)
        self.assertEqual(
            self.sialib.event_memory_identity(replay),
            self.sialib.event_memory_identity(original))
        self.assertEqual(
            self.sialib.event_semantic_identity(replay),
            self.sialib.event_semantic_identity(original))

    def test_source_replay_clock_is_marker_bound_across_midnight(self):
        marker = {"started_at": "2026-08-30T23:59:59Z"}
        first = self.sialib._source_replay_clock(marker)
        second = self.sialib._source_replay_clock(marker)
        self.assertEqual(first, second)
        self.assertEqual(first[1], "2026-08-30")

    def test_marker_is_durable_and_semantic_conflicts_refuse(self):
        with tempfile.TemporaryDirectory() as state, mock.patch.object(
                self.sialib, "MEMO_PATH", os.path.join(state, "memo.json")):
            memo = {}
            self.sialib._mark_source_replay_pending(
                memo, 9, {"sense_custom:demo"}, [self._event()],
                self._effects())
            persisted = self.sialib.load_memo()
            marker = self.sialib._pending_source_replay_marker(persisted)
            self.assertEqual(len(marker["events"]), 1)
            with self.assertRaisesRegex(ValueError, "conflicts"):
                self.sialib._mark_source_replay_pending(
                    memo, 9, {"sense_custom:demo"},
                    [self._event("different meaning")], self._effects())

    def test_source_replay_version_requires_exact_json_integer(self):
        marker = self._marker([self._event()], {"sense_custom:demo"})
        self.assertIsNotNone(self.sialib._pending_source_replay_marker(
            {"source_replay_pending": marker}))
        for replacement in (True, 1.0):
            with self.subTest(replacement=replacement):
                malformed = copy.deepcopy(marker)
                malformed["v"] = replacement
                with self.assertRaisesRegex(
                        RuntimeError, "source replay marker is invalid"):
                    self.sialib._pending_source_replay_marker(
                        {"source_replay_pending": malformed})

    def test_source_replay_clock_preserves_post_drain_subsecond_time(self):
        policy_at = self.when.timestamp() + 0.75
        marker = self.sialib._source_replay_marker_value(
            {}, 9, {"sense_custom:demo"}, [self._event()],
            self._effects(), policy_at=policy_at)

        clock, day = self.sialib._source_replay_clock(marker)

        self.assertEqual(marker["v"], 2)
        self.assertEqual(marker["policy_at"], policy_at)
        self.assertEqual(clock, policy_at)
        self.assertEqual(day, "2026-08-30")

    def test_legacy_source_replay_clock_remains_accepted(self):
        marker = self.sialib._source_replay_marker_value(
            {}, 9, {"sense_custom:demo"}, [self._event()],
            self._effects(), policy_at=self.when.timestamp() + 0.75)
        policy_at = marker.pop("policy_at")
        marker["v"] = 1

        validated = self.sialib._pending_source_replay_marker(
            {"source_replay_pending": marker})
        clock, day = self.sialib._source_replay_clock(validated)

        self.assertEqual(clock, int(policy_at))
        self.assertEqual(day, "2026-08-30")

    def test_post_drain_fractional_recall_does_not_break_source_policy(self):
        base = self.when.timestamp()
        mind = self.sialib.siamind._empty_mind()
        self.sialib.siamind.touch(
            mind, "organs/recalled", base + 0.5, src="user-ask")
        marker = self.sialib._source_replay_marker_value(
            {}, 9, {"sense_custom:demo"}, [self._event()],
            self._effects(), policy_at=base + 0.75)
        policy_at, policy_day = self.sialib._source_replay_clock(marker)

        result = self.sialib._event_cognitive_transition(
            mind, [(self._event(), "events/custom/2026-08-30")],
            policy_at, policy_day, marker["id"])

        self.assertFalse(result["already_applied"])
        self.assertEqual(result["memory_state"]["v"],
                         self.sialib.siamind.MIND_VERSION)

    def test_marker_preserves_duplicate_filtered_cognitive_admission(self):
        with tempfile.TemporaryDirectory() as state, mock.patch.object(
                self.sialib, "MEMO_PATH", os.path.join(state, "memo.json")):
            memo = {}
            self.sialib._mark_source_replay_pending(
                memo, 9, {"sense_custom:demo"}, [self._event()],
                self._effects(), cognitive_ids=[])
            marker = self.sialib._pending_source_replay_marker(
                self.sialib.load_memo())
        self.assertEqual(len(marker["events"]), 1)
        self.assertEqual(marker["cognitive_ids"], [])

    def test_one_batch_receipt_makes_cognitive_replay_idempotent(self):
        mind = self.sialib.siamind._empty_mind()
        event = self._event()
        admitted = [(event, "events/custom/2026-08-30")]
        identity = "a" * 32
        first = self.sialib._event_cognitive_transition(
            mind, admitted, self.when.timestamp(), "2026-08-30", identity)
        touches = mind["nodes"]["events/custom/2026-08-30"]["n"]
        second = self.sialib._event_cognitive_transition(
            mind, admitted, self.when.timestamp(), "2026-08-30", identity)
        self.assertFalse(first["already_applied"])
        self.assertTrue(second["already_applied"])
        self.assertEqual(
            mind["nodes"]["events/custom/2026-08-30"]["n"], touches)
        self.assertEqual(mind["event_batch_applied"], identity)

    def test_native_event_time_after_controller_frame_is_not_a_usage_time(self):
        """A long capture may finish after its one pinned controller clock.

        Native event chronology remains novelty/source metadata.  Perception
        admission is the use, so every legacy usage/co-return touch from this
        transaction must use the controller frame instead of manufacturing a
        future use that makes its own activation snapshot invalid.
        """
        mind = self.sialib.siamind._empty_mind()
        observed_at = self.when.timestamp()
        later = self.sialib.Event(
            "custom", self.when + datetime.timedelta(seconds=30),
            "event", "captured after the controller frame",
            {"organs/custom"}, {"custom"},
            occurrence="custom:demo:0:later")

        result = self.sialib._event_cognitive_transition(
            mind, [(later, "events/custom/2026-08-30")],
            observed_at, "2026-08-30", "e" * 32)

        self.assertFalse(result["already_applied"])
        for slug in ("events/custom/2026-08-30", "organs/custom"):
            self.assertEqual(mind["nodes"][slug]["rt"], [[observed_at, 1.0]])
        self.assertEqual(
            mind["edges"][
                "events/custom/2026-08-30|organs/custom"]["last_touch"],
            observed_at)

    def test_event_transition_does_not_regress_familiarity_watermarks(self):
        mind = self.sialib.siamind._empty_mind()
        entity = "organs/custom"
        pair = "pair:custom:event"
        latest = self.when.timestamp()
        mind["seen"].update({entity: latest, pair: latest})
        older_when = self.when - datetime.timedelta(seconds=1)
        older = self.sialib.Event(
            "custom", older_when, "event", "older observed row",
            {entity}, {"custom"}, occurrence="custom:demo:0:older")

        self.sialib._event_cognitive_transition(
            mind, [(older, "events/custom/2026-08-30")], latest,
            "2026-08-30", "d" * 32)

        self.assertEqual(mind["seen"][entity], latest)
        self.assertEqual(mind["seen"][pair], latest)

    def test_full_cognitive_candidate_detects_retained_pin_growth(self):
        mind = self.sialib.siamind._empty_mind()
        pinned = self.sialib.siamind.touch(
            mind, "organs/custom", ts=1, src="organ")
        pinned["pins"] = ["user"]
        pinned["padding"] = "x" * 800
        limit = len(self.sialib.siamind._mind_text(mind).encode("utf-8")) + 1
        self.sialib._event_cognitive_transition(
            mind, [(self._event(), "events/custom/2026-08-30")],
            self.when.timestamp(), "2026-08-30", "b" * 32)
        with mock.patch.object(
                self.sialib.siamind, "MAX_MIND_BYTES", limit), \
                self.assertRaisesRegex(ValueError, "persistence bound"):
            self.sialib.siamind.compact_mind_for_persistence(mind)

    def test_ordinary_pin_generation_settles_before_source_candidate(self):
        with tempfile.TemporaryDirectory() as root:
            corpus = os.path.join(root, "corpus")
            state = os.path.join(root, "state")
            os.makedirs(os.path.join(corpus, "events", "custom"))
            os.makedirs(state)
            slug = "events/custom/old"
            with open(os.path.join(corpus, slug + ".md"), "w") as stream:
                stream.write("# retained\n")
            queue = os.path.join(state, "touch-queue.jsonl")
            mind_path = os.path.join(state, "mind.json")
            with mock.patch.object(self.sialib, "CORPUS", corpus), \
                    mock.patch.object(
                        self.sialib.siamind, "MIND_PATH", mind_path), \
                    mock.patch.object(
                        self.sialib.siamind, "TOUCH_QUEUE", queue):
                self.sialib.siamind.save_mind(
                    self.sialib.siamind._empty_mind())
                self.assertTrue(self.sialib.siamind.queue_pin(
                    slug, True, ts=10))
                mind = self.sialib.siamind.load_mind(now=11)
                drained, refused = self.sialib._drain_ordinary_touches(
                    mind, 11)
                persisted = self.sialib.siamind.load_mind(now=11)
            self.assertEqual((drained, refused), (1, 0))
            self.assertIn("user", persisted["nodes"][slug]["pins"])
            self.assertNotIn("touch_queue_claim_sha256", persisted)
            self.assertFalse(os.path.exists(queue + ".draining"))

    def test_custom_source_success_is_reported_without_an_emitted_row(self):
        with tempfile.NamedTemporaryFile(mode="w") as stream, \
                mock.patch.object(self.sialib, "CONFIG", {
                    "custom_senses": [{"name": "demo", "path": stream.name}]
                }):
            events, errors, sources = self.sialib.sense_custom(
                {}, include_sources=True)
        self.assertEqual(events, [])
        self.assertEqual(errors, [])
        self.assertEqual(sources, ["sense_custom:demo"])

    def test_batch_occurrence_dedupes_across_dates_and_refuses_conflict(self):
        first = self._event()
        later = self._event()
        later.ts = later.ts + datetime.timedelta(days=1)
        self.assertEqual(self.sialib._dedupe_event_batch([first, later]),
                         [first])
        conflict = self._event("different meaning")
        conflict.ts = later.ts
        with self.assertRaisesRegex(ValueError, "identity conflicts"):
            self.sialib._dedupe_event_batch([first, conflict])

    def test_batch_path_preflight_counts_all_planned_dates_together(self):
        with tempfile.TemporaryDirectory() as corpus, \
                mock.patch.object(self.sialib, "CORPUS", corpus), \
                mock.patch.object(
                    self.sialib, "MAX_EVENT_LOOKUP_PAGES", 2):
            root = os.path.join(corpus, "events", "custom")
            os.makedirs(root)
            with open(os.path.join(root, "2026-08-29.md"), "w") as stream:
                stream.write("existing")
            planned = {"custom": {
                os.path.join(root, "2026-08-30.md"),
                os.path.join(root, "2026-08-31.md"),
            }}
            with self.assertRaisesRegex(ValueError, "bounded occurrence"):
                self.sialib._preflight_event_path_plan(planned)

    def test_event_directory_snapshot_refuses_before_unbounded_materialization(self):
        with tempfile.TemporaryDirectory() as corpus, \
                mock.patch.object(self.sialib, "CORPUS", corpus), \
                mock.patch.object(
                    self.sialib, "MAX_EVENT_LOOKUP_PAGES", 2), \
                mock.patch.object(
                    self.sialib, "MAX_EVENT_DIRECTORY_INSPECTIONS", 3), \
                mock.patch.object(
                    self.sialib.glob, "glob",
                    side_effect=AssertionError("glob is unbounded")):
            root = os.path.join(corpus, "events", "custom")
            os.makedirs(root)
            for name in ("alpha.md", "bravo.md", "charlie.md"):
                with open(os.path.join(root, name), "w") as stream:
                    stream.write("fixture")
            with self.assertRaisesRegex(ValueError, "page bound"):
                self.sialib._bounded_event_directory_snapshot(root)

    def test_event_directory_snapshot_does_not_turn_disappearance_into_empty(self):
        first_page = ([{"name": "alpha.md", "mode": stat.S_IFREG}],
                      False, 1, {"device": 1, "inode": 2, "cookie": 3,
                                 "size": 4, "mtime_ns": 5,
                                 "ctime_ns": 6, "reset": False})
        with mock.patch.object(
                self.sialib, "_bounded_source_entries",
                side_effect=[first_page, FileNotFoundError("gone")]), \
                self.assertRaisesRegex(RuntimeError, "disappeared"):
            self.sialib._bounded_event_directory_snapshot("/fixture")

    def test_source_refusal_is_signed_with_stable_event_identity(self):
        event = self._event()
        event_id = self.sialib.event_memory_identity(event)
        with mock.patch.object(
                self.sialib, "durable_ledger_append") as append:
            self.sialib._settle_source_refusals(
                "sense_custom:demo", [event], "event-capacity")
            first = append.call_args
            append.reset_mock()
            self.sialib._settle_source_refusals(
                "sense_custom:demo", [event], "event-capacity")
            second = append.call_args
        self.assertEqual(first, second)
        args, kwargs = first
        self.assertEqual(args[:3], (
            "SOURCE:refuse", "sense_custom:demo", "event-capacity"))
        payload = json.loads(args[3])
        self.assertEqual(payload["event_id"], event_id)
        self.assertEqual(payload["source"], "sense_custom:demo")
        self.assertEqual(kwargs, {"order": int(event_id, 16)})

    def test_legacy_event_identity_collision_is_a_signed_refusal_class(self):
        refusal = self.sialib._source_refusal_code(ValueError(
            "legacy event cannot be identity-upgraded automatically"))
        self.assertEqual(refusal, "legacy-event-identity")
        self.assertIsNone(self.sialib._source_refusal_code(ValueError(
            "event identity conflicts with its day page")))

    def test_source_preflight_memo_refusal_has_no_corpus_side_effect(self):
        with tempfile.TemporaryDirectory() as corpus, \
                mock.patch.object(self.sialib, "CORPUS", corpus), \
                mock.patch.object(self.sialib, "MAX_MEMO_BYTES", 1):
            organs = {"custom": {"today": 0, "last_ts": ""}}
            with self.assertRaisesRegex(
                    ValueError, "brainstem memo exceeds its byte bound"):
                self.sialib._preflight_source_admission_image(
                    {}, 1, {"sense_custom:demo"}, [self._event()],
                    "2026-08-30", organs)
            self.assertEqual(os.listdir(corpus), [])


class WorldlineCursor(unittest.TestCase):
    """WORLDLINE pagination is total even when a page shares one timestamp."""

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        state = os.path.join(
            self.tmp.name, ".local", "state", "worldline")
        os.makedirs(state)
        self.db = os.path.join(state, "worldline.sqlite3")
        with contextlib.closing(sqlite3.connect(self.db)) as con:
            con.execute(
                "CREATE TABLE causal_events ("
                "event_id TEXT PRIMARY KEY, kind TEXT NOT NULL, actor TEXT, "
                "tool TEXT, reason TEXT, path_display TEXT, "
                "created_at TEXT NOT NULL, world_instance TEXT NOT NULL)")
            con.commit()
        self.sialib = _load(
            "sialib_worldline_cursor", os.path.join(BIN, "sialib.py"))
        self.sialib.HOME = self.tmp.name

    def tearDown(self):
        self.tmp.cleanup()

    def _insert(self, rows):
        with contextlib.closing(sqlite3.connect(self.db)) as con:
            con.executemany(
                "INSERT INTO causal_events VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                rows)
            con.commit()

    def test_composite_cursor_keeps_every_tied_row_across_pages(self):
        stamp = "2026-08-30T12:00:00.000000Z"
        row_count = 2001
        with contextlib.closing(sqlite3.connect(self.db)) as con:
            con.executemany(
                "INSERT INTO causal_events VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                [(f"event-{index:04d}", "result", "tester",
                  f"tool-{index:04d}", "", "", stamp, "world-a")
                 for index in range(row_count)])
            con.commit()

        # This is the v1.2 timestamp-only cursor.  Replaying its tied instant
        # is safe and migrates it to the stable (created_at, event_id) pair.
        cursors = {"worldline.created_at": stamp}
        first = self.sialib.sense_worldline(cursors)
        second = self.sialib.sense_worldline(cursors)
        third = self.sialib.sense_worldline(cursors)

        self.assertEqual(len(first), 2000)
        self.assertEqual(len(second), 1)
        self.assertEqual(third, [])
        observed = first + second
        self.assertEqual(len(observed), row_count)
        self.assertEqual(len({event.summary for event in observed}), row_count)
        self.assertEqual(cursors, {
            "worldline.created_at": stamp,
            "worldline.event_id": "event-2000",
        })

    def test_malformed_composite_cursor_refuses_without_mutation(self):
        stamp = "2026-08-30T12:00:00.000000Z"
        malformed = [
            {"worldline.created_at": []},
            {"worldline.created_at": "not-a-timestamp"},
            {"worldline.event_id": "event-a"},
            {"worldline.created_at": "", "worldline.event_id": "event-a"},
            {"worldline.created_at": stamp, "worldline.event_id": []},
        ]
        for cursors in malformed:
            with self.subTest(cursors=cursors):
                before = copy.deepcopy(cursors)
                with self.assertRaisesRegex(ValueError, "worldline cursor"):
                    self.sialib.sense_worldline(cursors)
                self.assertEqual(cursors, before)

    def test_bad_page_row_never_partially_advances_cursor(self):
        self._insert([
            ("event-a", "result", "tester", "", "r" * (
                self.sialib.MAX_CONFIG_TEXT_CHARS + 1), "",
             "2026-08-30T12:00:00.000000Z", "world-a"),
            ("event-b", "result", "tester", "tool-b", "", "",
             "not-a-timestamp", "world-a"),
        ])
        cursors = {
            "worldline.created_at": "",
            "worldline.event_id": "",
        }
        before = copy.deepcopy(cursors)
        with self.assertRaisesRegex(ValueError, "worldline cursor"):
            self.sialib.sense_worldline(cursors)
        self.assertEqual(cursors, before)

    def test_guarded_query_is_rowwise_and_never_materializes_whole_text(self):
        stamp = "2026-08-30T12:00:00.000000Z"
        self._insert([("event-a", "result", "tester", "tool-a", "", "",
                      stamp, "world-a")])
        real_connect = sqlite3.connect
        statements = []

        class GuardCursor:
            def __init__(self, cursor):
                self.cursor = cursor

            def fetchone(self):
                return self.cursor.fetchone()

            def fetchall(self):
                raise AssertionError("WORLDLINE must not use fetchall")

        class GuardConnection:
            def __init__(self, connection):
                self.connection = connection

            def execute(self, statement, parameters=()):
                statements.append(statement)
                return GuardCursor(self.connection.execute(
                    statement, parameters))

            def close(self):
                self.connection.close()

        def guarded_connect(*args, **kwargs):
            return GuardConnection(real_connect(*args, **kwargs))

        cursors = {"worldline.created_at": "",
                   "worldline.event_id": ""}
        with mock.patch.object(
                self.sialib.sqlite3, "connect",
                side_effect=guarded_connect):
            events = self.sialib.sense_worldline(cursors)

        self.assertEqual(len(events), 1)
        self.assertEqual(cursors["worldline.event_id"], "event-a")
        self.assertEqual(len(statements), 1)
        statement = statements[0]
        self.assertIn("typeof(event_id)", statement)
        self.assertIn("length(CAST(event_id AS BLOB))", statement)
        self.assertIn("substr(CAST(reason AS BLOB), 1, ?)", statement)
        self.assertIn("LIMIT ?", statement)

    def test_oversized_fields_refuse_and_later_row_progresses(self):
        stamp = "2026-08-30T12:00:00.000000Z"
        huge_kind = "k" * (self.sialib.MAX_SOURCE_NAME_CHARS + 1)
        huge_reason = "r" * (self.sialib.MAX_CONFIG_TEXT_CHARS + 1)
        self._insert([
            ("event-a", huge_kind, "tester", "", "", "", stamp,
             "world-a"),
            ("event-b", "result", "tester", "", huge_reason, "", stamp,
             "world-a"),
            ("event-c", "result", "tester", "tool-c", "", "", stamp,
             "bad world"),
            ("event-z", "result", "tester", "tool-z", "", "", stamp,
             "world-a"),
        ])
        cursors = {"worldline.created_at": "",
                   "worldline.event_id": ""}

        events = self.sialib.sense_worldline(cursors)

        self.assertEqual([event.kind for event in events], [
            "source-entry-refused", "source-entry-refused",
            "source-entry-refused", "result"])
        self.assertEqual(cursors["worldline.event_id"], "event-z")
        refusals = self.sialib._take_source_entry_refusals(
            cursors, "sense_worldline")
        self.assertEqual([row["reason"] for row in refusals], [
            "worldline-kind-capacity", "worldline-reason-capacity",
            "worldline-world-identity-invalid"])
        payload = json.dumps(refusals, sort_keys=True)
        self.assertNotIn(huge_kind, payload)
        self.assertNotIn(huge_reason, payload)

    def test_selected_byte_budget_paginates_without_drop_or_replay(self):
        stamp = "2026-08-30T12:00:00.000000Z"
        self._insert([
            (f"event-{letter}", "result", "tester", f"tool-{letter}",
             "", "", stamp, "world-a")
            for letter in "abc"
        ])
        cursors = {"worldline.created_at": "",
                   "worldline.event_id": ""}
        # parsed=59*2, exact=118. Both results are exact rational
        with mock.patch.object(
                self.sialib, "MAX_WORLDLINE_PAGE_BYTES", 100):
            pages = [self.sialib.sense_worldline(cursors)
                     for _index in range(4)]

        self.assertEqual([len(page) for page in pages], [1, 1, 1, 0])
        occurrences = [event.occurrence
                       for page in pages for event in page]
        self.assertEqual(occurrences, [
            "worldline:event-a", "worldline:event-b", "worldline:event-c"])
        self.assertEqual(cursors["worldline.event_id"], "event-c")

    def test_refusal_signing_retries_exactly_and_is_source_namespaced(self):
        stamp = "2026-08-30T12:00:00.000000Z"
        huge_reason = "r" * (self.sialib.MAX_CONFIG_TEXT_CHARS + 1)
        self._insert([
            ("event-a", "result", "tester", "", huge_reason, "", stamp,
             "world-a"),
            ("event-b", "result", "tester", "tool-b", "", "", stamp,
             "world-a"),
        ])
        durable = {"worldline.created_at": "",
                   "worldline.event_id": ""}
        attempts = []
        append_calls = []
        for _attempt in range(2):
            trial = copy.deepcopy(durable)
            events = self.sialib.sense_worldline(trial)
            pending = self.sialib._take_source_entry_refusals(
                trial, "sense_worldline")
            with mock.patch.object(
                    self.sialib, "durable_ledger_append") as append:
                self.sialib._settle_source_entry_refusals(
                    "sense_worldline", pending)
                append_calls.append((
                    copy.deepcopy(append.call_args.args),
                    copy.deepcopy(append.call_args.kwargs)))
            attempts.append((
                [event.occurrence for event in events], pending, trial))

        # The first settled trial is discarded as though the process died
        # before cursor publication. Its exact refusal is regenerated and
        # keeper settlement receives the same idempotent occurrence.
        self.assertEqual(attempts[0], attempts[1])
        self.assertEqual(append_calls[0], append_calls[1])
        self.assertEqual(durable["worldline.event_id"], "")
        durable.clear()
        durable.update(attempts[1][2])
        self.assertEqual(durable["worldline.event_id"], "event-b")
        persisted = {
            self.sialib.SOURCE_ENTRY_REFUSALS_KEY:
                copy.deepcopy(attempts[1][1])}
        carried = copy.deepcopy(persisted)
        self.assertEqual(self.sialib._take_owned_source_entry_refusals(
            lambda _cursors: [], carried, True,
            persisted[self.sialib.SOURCE_ENTRY_REFUSALS_KEY]), [])
        self.assertEqual(carried, persisted)
        injected = {
            self.sialib.SOURCE_ENTRY_REFUSALS_KEY:
                copy.deepcopy(attempts[1][1])}
        with self.assertRaisesRegex(ValueError, "reserved for sense_worldline"):
            self.sialib._take_owned_source_entry_refusals(
                lambda _cursors: [], injected, False, None)
        wrong_source = {
            self.sialib.SOURCE_ENTRY_REFUSALS_KEY:
                copy.deepcopy(attempts[1][1])}
        with self.assertRaisesRegex(
                ValueError, "source entry refusal state is invalid"):
            self.sialib._take_source_entry_refusals(
                wrong_source, "sense_journal")

    def test_oversized_ordering_identity_never_advances(self):
        stamp = "2026-08-30T12:00:00.000000Z"
        self._insert([(
            "e" * (self.sialib.MAX_SOURCE_NAME_CHARS + 1),
            "result", "tester", "tool-a", "", "", stamp, "world-a")])
        cursors = {"worldline.created_at": "",
                   "worldline.event_id": ""}
        before = copy.deepcopy(cursors)
        with self.assertRaisesRegex(ValueError, "worldline cursor event id"):
            self.sialib.sense_worldline(cursors)
        self.assertEqual(cursors, before)


class PPRMass(unittest.TestCase):
    """Personalized PageRank: dangling mass returns to the personalization
    vector (no rank leaks to zero); retrieval order is the primary signal."""

    # ppr_rerank returns a BLEND, never the rank vector: with no `mind`
    # the score is base * (1 + K * rank_i / rank_max), where base is
    # (retrieval_score / retrieval_max) * the origin weight. Divide out the base, then
    # divide every remainder by the top hit's, and rank_i / rank_max
    # comes back with K cancelled — so these tests pin the mass
    # invariant and not the tuning constant next to it.
    #
    # What this CANNOT see, stated so nobody reads more into it: losing
    # the teleport entirely leaves the fixed point on the same ray
    # (both updates are c * pers + (1 - damping) * A * rank, differing
    # only in c), so every rank_i / rank_max is unchanged and the total
    # is not recoverable through this API. What changes shape — and what
    # is pinned below — is whether the dangling mass comes back to the
    # dangling SEEDS in the right proportion.
    def _rank_shares(self, out, bases):
        excess = {slug: score / bases[slug] - 1.0 for slug, score in out}
        top = max(excess.values())
        self.assertGreater(top, 0.0, "no PPR contribution to recover")
        return {slug: value / top for slug, value in excess.items()}

    def test_dangling_conserved(self):
        graph = {"nodes": [{"id": c} for c in "abcde"],
                 "edges": [{"s": "a", "d": "b"}, {"s": "b", "d": "c"}]}
        # 'd' is dangling (no edges); its mass must not vanish
        out = siamind.ppr_rerank(
            graph, [("a", 1.0), ("d", 0.5)],
            origins={slug: "evidence" for slug in "abcde"})
        self.assertTrue(out, "must return results")
        slugs = [s for s, _ in out]
        self.assertIn("a", slugs)
        self.assertIn("d", slugs)
        # top hit is the strongest retrieval seed
        self.assertEqual(out[0][0], "a")
        # Mass. Personalization is a = 2/3, d = 1/3 ((retrieval score / max) over
        # max(1, deg)), and the conserving fixed point of the damping-0.5
        # walk is rank = [7, 4, 1, 3, 0] / 15 — total exactly 1, with 'd'
        # holding 3/15 although no edge points at it. Every unit of that
        # arrived by teleport, so d/a = 3/7 IS the returned dangling
        # mass: a walk that handed it back only to nodes with edges
        # leaves d at 18/49, and one that dropped dangling seeds from the
        # personalization vector leaves it at 0. The old version of this
        # test asserted membership and order only, which all three
        # satisfy. Tolerance: 30 power iterations at damping 0.5 leave
        # ~1e-9 of residual here, and the nearest wrong answer is 0.09
        # away, so 1e-6 is both stable and decisive.
        shares = self._rank_shares(out, {"a": 1.0, "d": 0.5})
        self.assertGreater(shares["d"], 0.0, "dangling rank leaked to 0")
        self.assertAlmostEqual(shares["d"], 3 / 7, delta=1e-6)
        self.assertAlmostEqual(sum(shares.values()), 10 / 7, delta=1e-6)

    def test_total_rank_mass_stays_one(self):
        # Same graph, every node seeded, so the whole rank vector is
        # observable in the output instead of two entries of it.
        # Personalization is [2, 1, 2, 2, 2] / 9 and the conserving fixed
        # point is rank = [3, 4, 3, 2, 2] / 14: total 1, top rank 2/7 at
        # 'b'. Rank reaches the caller divided by that top rank, so a
        # conserved total of 1 has to show up as shares summing to
        # 1 / (2/7) = 7/2. Returning the dangling mass only to nodes with
        # edges sums to ~3.32; dropping the dangling seeds from the
        # personalization vector, 2.5 with two nodes at flat zero.
        graph = {"nodes": [{"id": c} for c in "abcde"],
                 "edges": [{"s": "a", "d": "b"}, {"s": "b", "d": "c"}]}
        hits = [(c, 1.0) for c in "abcde"]
        shares = self._rank_shares(
            siamind.ppr_rerank(
                graph, hits,
                origins={slug: "evidence" for slug in "abcde"}),
            {c: 1.0 for c in "abcde"})
        self.assertAlmostEqual(sum(shares.values()), 7 / 2, delta=1e-6)
        for slug, expected in (("a", 3 / 4), ("b", 1.0), ("c", 3 / 4),
                               ("d", 1 / 2), ("e", 1 / 2)):
            with self.subTest(slug=slug):
                self.assertGreater(shares[slug], 0.0,
                                   "rank leaked to zero")
                self.assertAlmostEqual(shares[slug], expected, delta=1e-6)

    def test_uncertainty_fallback(self):
        # empty graph -> input retrieval order preserved
        out = siamind.ppr_rerank({"nodes": [], "edges": []},
                                 [("x", 0.9), ("y", 0.3)])
        self.assertEqual([s for s, _ in out], ["x", "y"])

    def test_declared_model_origin_is_demoted_with_and_without_graph(self):
        hits = [("thoughts/model", 1.0), ("events/evidence", 1.0)]
        origins = {"thoughts/model": "model",
                   "events/evidence": "evidence"}
        for graph in (None, {"nodes": [], "edges": []}):
            with self.subTest(graph=graph):
                out = siamind.ppr_rerank(graph, hits, origins=origins)
                self.assertEqual(out[0][0], "events/evidence")
                self.assertLess(dict(out)["thoughts/model"],
                                dict(out)["events/evidence"])

        graph = {
            "nodes": [
                {"id": "thoughts/model", "t": "thought",
                 "origin": "model"},
                {"id": "events/evidence", "t": "event-day",
                 "origin": "evidence"},
            ],
            "edges": [{"s": "thoughts/model", "d": "events/evidence"}],
        }
        out = siamind.ppr_rerank(graph, hits)
        self.assertEqual(out[0][0], "events/evidence")

    def test_legacy_thought_and_invalid_origin_fail_safe(self):
        self.assertEqual(siamind.origin_class(
            "thoughts/old", "thought"), "legacy-unlabeled")
        self.assertEqual(siamind.origin_class(
            "thoughts/old", "thought", "invented"),
            "legacy-unlabeled")
        self.assertEqual(siamind.origin_class(
            "thoughts/new", "thought", "model"), "model")
        self.assertEqual(siamind.origin_class(
            "takes/legacy-graded", "take"), "legacy-unlabeled")
        self.assertEqual(siamind.origin_class(
            "takes/new-open", "take", "derived"), "derived")

    def test_removed_tuning_arguments_cannot_masquerade_as_controls(self):
        graph = {"nodes": [], "edges": []}
        hits = [("events/example/day", 1.0)]
        for name in ("alpha", "beta", "gamma"):
            with self.subTest(name=name), self.assertRaises(TypeError):
                siamind.ppr_rerank(graph, hits, **{name: 0.0})
        with self.assertRaises(TypeError):
            siamind.ppr_rerank(graph, hits, 0.0)

    def test_named_ppr_tiebreak_gain_drives_the_actual_blend(self):
        graph = {
            "nodes": [
                {"id": "events/a/day", "t": "event-day"},
                {"id": "events/b/day", "t": "event-day"},
            ],
            "edges": [{"s": "events/a/day", "d": "events/b/day"}],
        }
        hits = [("events/a/day", 1.0), ("events/b/day", 1.0)]
        rank = [1.0, 0.0]
        with mock.patch.object(
                siamind, "_ppr_power_iteration", return_value=rank), \
                mock.patch.object(siamind, "PPR_TIEBREAK_GAIN", 0.0):
            disabled = siamind.ppr_rerank(graph, hits)
        self.assertEqual(dict(disabled)["events/a/day"],
                         dict(disabled)["events/b/day"])

        with mock.patch.object(
                siamind, "_ppr_power_iteration", return_value=rank):
            enabled = siamind.ppr_rerank(graph, hits)
        self.assertGreater(dict(enabled)["events/a/day"],
                           dict(enabled)["events/b/day"])

    def test_named_activation_tiebreak_gain_drives_the_actual_blend(self):
        graph = {
            "nodes": [
                {"id": "events/a/day", "t": "event-day"},
                {"id": "events/b/day", "t": "event-day"},
            ],
            "edges": [{"s": "events/a/day", "d": "events/b/day"}],
        }
        hits = [("events/a/day", 1.0), ("events/b/day", 1.0)]
        mind = {"nodes": {}, "edges": {}}
        activations = {"events/a/day": 0.0, "events/b/day": 1.0}
        with mock.patch.object(
                siamind, "activations", return_value=activations), \
                mock.patch.object(siamind, "PPR_TIEBREAK_GAIN", 0.0), \
                mock.patch.object(siamind, "ACTIVATION_TIEBREAK_GAIN", 0.0):
            disabled = siamind.ppr_rerank(graph, hits, mind=mind)
        self.assertEqual(dict(disabled)["events/a/day"],
                         dict(disabled)["events/b/day"])

        with mock.patch.object(
                siamind, "activations", return_value=activations), \
                mock.patch.object(siamind, "PPR_TIEBREAK_GAIN", 0.0):
            enabled = siamind.ppr_rerank(graph, hits, mind=mind)
        self.assertGreater(dict(enabled)["events/b/day"],
                           dict(enabled)["events/a/day"])


    def test_dangling_mass_is_conserved_not_leaked(self):
        """The invariant the class name claims, asserted on the vector.

        Through ``ppr_rerank`` this is untestable: the caller divides by
        ``max(rank)``, and a pure leak scales the whole vector uniformly, so
        the ranking is byte-identical either way. Deleting the teleport block
        was therefore invisible to every earlier test in this class. Assert it
        on ``_ppr_power_iteration``, where the mass still exists.
        """
        siamind = _load("siamind_ppr_mass", os.path.join(BIN, "siamind.py"))
        # Node 1 is a sink: everything that reaches it must come back to the
        # seeds rather than evaporate.
        pers = [1.0, 0.0]
        adj = [[(1, 1.0)], []]
        rank = siamind._ppr_power_iteration(pers, adj)
        self.assertAlmostEqual(
            sum(rank), 1.0, places=9,
            msg="dangling mass leaked instead of teleporting to the seeds")

    def test_a_leaking_iteration_is_caught_by_that_assertion(self):
        """Prove the guard bites: the same graph, with the teleport removed,
        loses mass. This is the mutation the old test could not see."""
        siamind = _load("siamind_ppr_leak", os.path.join(BIN, "siamind.py"))
        pers = [1.0, 0.0]
        adj = [[(1, 1.0)], []]
        damping = siamind.PPR_DAMPING
        rank = pers[:]
        for _ in range(siamind.PPR_ITers):
            nxt = [damping * p for p in pers]
            for i, r in enumerate(rank):
                if r and adj[i]:
                    total = sum(w for _, w in adj[i]) or 1.0
                    share = (1 - damping) * r / total
                    for j, weight in adj[i]:
                        nxt[j] += share * weight
            rank = nxt          # no teleport: the sink swallows the mass
        self.assertLess(
            sum(rank), 0.999,
            "a leaking iteration must not satisfy the conservation check")

class Novelty(unittest.TestCase):
    """Novelty measures an observation gap, not initial-observation age: a continuously
    seen entity never re-fires the 30-day bonus."""

    def test_absence_not_age(self):
        mind = siamind._empty_mind()
        now = 1_000_000_000.0
        s1, _ = siamind.novelty(mind, "o", "k", ["e"], ["k"] * 10, now)
        self.assertGreaterEqual(s1, 0.4)               # first recorded occurrence
        # seen again one hour later: no bonus (not absent)
        s2, _ = siamind.novelty(mind, "o", "k", ["e"], ["k"] * 10, now + 3600)
        self.assertLess(s2, 0.4)
        # seen again 40 days after THAT: genuine return
        s3, _ = siamind.novelty(mind, "o", "k", ["e"], ["k"] * 10,
                                now + 3600 + 40 * 86400)
        self.assertGreaterEqual(s3, 0.2)
        # Bands alone do not say it: s2 < 0.4 and s3 >= 0.2 are both true
        # of s2 = 0.35, s3 = 0.25 — the non-return scoring ABOVE the
        # genuine return, which is the claim inverted. An absence window
        # read as 30 minutes instead of 30 days lands exactly there
        # (s2 = s3 = 0.2) and passed the bands unchanged. Ordering is the
        # claim: the 30-day bonus re-fires for the return and for
        # nothing else, and a return is still worth less than a first
        # sighting.
        self.assertGreater(s3, s2)
        self.assertGreater(s1, s3)


class Surprise(unittest.TestCase):
    """Empirical-band surprise: no Poisson, and absence is reachable for a
    paced band once it has enough samples."""

    def test_no_poisson_symbols(self):
        self.assertFalse(hasattr(siamind, "SURPRISAL_BITS"))
        self.assertFalse(hasattr(siamind, "EWMA_HALFLIFE_H"))

    def test_absence_reachable(self):
        mind = {"hourbuf": {}, "hist": {}, "ewma": {}, "cooldown": {}}
        # Cover every weekday/weekend × six-hour band with a fully active
        # history independent of the wall-clock day on which CI runs. JACKAL
        active_hours = 1344
        for hour in range(active_hours):
            siamind.surprisal_update(
                mind, {"org": 5}, hour * 3600 + 10)
        # Only an explicit zero is a quiet intake sample. Another organ's
        # activity does not certify that this organ was observed.
        siamind.surprisal_update(
            mind, {"org": 0, "other": 1}, active_hours * 3600 + 10)
        found = siamind.surprisal_update(
            mind, {"org": 0, "other": 1}, (active_hours + 1) * 3600 + 10)
        self.assertTrue(any(o == "org" and k == "absence"
                            for o, k, _ in found),
                        "absence-surprise must fire for a paced band")


class ChainVerdict(unittest.TestCase):
    def test_absent_chain_never_aggregates_to_pass(self):
        sialib = _load("sialib_chain_verdict", os.path.join(BIN, "sialib.py"))
        self.assertEqual(sialib.chain_verdict({"sia": "absent"}),
                         "degraded")
        self.assertEqual(sialib.chain_verdict(
            {"sia": "pass", "custos": "absent"}), "degraded")
        self.assertEqual(sialib.chain_verdict(
            {"sia": "pass", "custos": "fail"}), "fail")
        self.assertEqual(sialib.chain_verdict({"sia": "pass"}), "pass")

    def test_removed_verified_chain_emits_absent_transition_once(self):
        sialib = _load("sialib_chain_transition",
                       os.path.join(BIN, "sialib.py"))
        memo = {"chains": {"sia": "pass", "custos": "pass"}}

        def thought(_store, kind, text, links, urgent=False, **_metadata):
            return {"kind": kind, "text": text, "links": links,
                    "urgent": urgent}

        with mock.patch.object(sialib, "add_thought", side_effect=thought):
            first = sialib.think({}, memo, [], {"sia": "pass"}, [], [])
            after_first = copy.deepcopy(memo["chains"])
            repeated = sialib.think({}, memo, [], {"sia": "pass"}, [], [])
            recovered = sialib.think(
                {}, memo, [], {"sia": "pass", "custos": "pass"}, [], [])
        self.assertIn("no longer verifiable: custos", first[0]["text"])
        self.assertTrue(first[0]["urgent"])
        self.assertEqual(after_first, {"sia": "pass"})
        self.assertEqual(memo["chains"], {"sia": "pass", "custos": "pass"})
        self.assertEqual(repeated, [])
        self.assertIn("Newly observed evidence chain verifies",
                      recovered[0]["text"])

    def test_new_absent_chain_never_claims_all_verify(self):
        sialib = _load("sialib_chain_new_absent",
                       os.path.join(BIN, "sialib.py"))
        memo = {"chains": {"sia": "pass"}}

        def thought(_store, kind, text, links, urgent=False, **_metadata):
            return {"kind": kind, "text": text, "links": links,
                    "urgent": urgent}

        with mock.patch.object(sialib, "add_thought", side_effect=thought):
            emitted = sialib.think(
                {}, memo, [], {"sia": "pass", "custos": "absent"}, [], [])
        texts = [item["text"] for item in emitted]
        self.assertTrue(any("no longer verifiable: custos" in text
                            for text in texts))
        self.assertFalse(any("All evidence chains verify again" in text
                             for text in texts))

    def test_event_thought_identity_uses_source_day_not_retry_day(self):
        sialib = _load("sialib_think_source_clock",
                       os.path.join(BIN, "sialib.py"))
        event = sialib.Event(
            "journal", datetime.datetime.now(datetime.timezone.utc),
            "error", "process crashed", {"units/example"}, {"coredump"},
            occurrence="journal:stable")
        observed = []

        def thought(_store, kind, text, links, urgent=False, **metadata):
            observed.append(metadata["queue_id"])
            return {"kind": kind, "text": text}

        with mock.patch.object(sialib, "today", return_value="2026-08-31"), \
                mock.patch.object(sialib, "add_thought", side_effect=thought):
            sialib.think(
                {}, {}, [event], {}, [], [], event_day="2026-08-30")
        text = "Something crashed: process crashed."
        expected = sialib.thought_queue_identity(
            "think.generated", "crash", text, ["units/example"], True,
            day="2026-08-30")
        self.assertEqual(observed, [expected])

    def test_refusal_thought_attribution_preserves_source_boundary(self):
        sialib = _load("sialib_think_refusal_boundary",
                       os.path.join(BIN, "sialib.py"))
        emitted = []

        def thought(_store, kind, text, links, urgent=False, **_metadata):
            emitted.append((kind, text, links))
            return {"kind": kind, "text": text}

        journal = sialib.Event(
            "journal", datetime.datetime.now(datetime.timezone.utc),
            "source-entry-refused", "row could not be admitted",
            {"organs/journal"}, {"refusal"}, occurrence="journal:refusal")
        jackal = sialib.Event(
            "jackal", datetime.datetime.now(datetime.timezone.utc),
            "refused", "fixture → refused", {"organs/jackal"},
            {"refusal", "unverified-observation"},
            occurrence="jackal:refusal")
        with mock.patch.object(sialib, "add_thought", side_effect=thought):
            sialib.think({}, {}, [journal], {}, [], [],
                         event_day="2026-08-30")
        self.assertNotIn("JACKAL", emitted[0][1])
        self.assertIn("journal source refused", emitted[0][1])
        emitted.clear()
        with mock.patch.object(sialib, "add_thought", side_effect=thought):
            sialib.think({}, {}, [jackal], {}, [], [],
                         event_day="2026-08-30")
        self.assertIn("unverified JACKAL recall ledger reports", emitted[0][1])
        self.assertIn("not front-door reverified", emitted[0][1])
        self.assertNotIn("JACKAL refused to answer", emitted[0][1])

    def test_anomaly_and_attention_identities_preserve_recurrence(self):
        sialib = _load("sialib_think_recurring_identity",
                       os.path.join(BIN, "sialib.py"))
        observed = []

        def thought(_store, kind, text, links, urgent=False, **metadata):
            observed.append((kind, metadata["queue_id"]))
            return {"kind": kind, "text": text}

        anomaly = [{"cohort_kind": "organ", "cohort_value": "journal",
                    "count": 9, "baseline_mean": 2, "baseline_stddev": 1}]
        memo = {"salience_top": "events/old"}
        with mock.patch.object(sialib, "today", return_value="2026-08-30"), \
                mock.patch.object(sialib, "add_thought", side_effect=thought):
            sialib.think({}, memo, [], {},
                         [{"slug": "events/new", "title": "New"}], anomaly)
        first = dict(observed)
        observed.clear()
        memo["anomaly_keys"] = []
        memo["salience_top"] = "events/new"
        with mock.patch.object(sialib, "today", return_value="2026-08-31"), \
                mock.patch.object(sialib, "add_thought", side_effect=thought):
            sialib.think({}, memo, [], {},
                         [{"slug": "events/old", "title": "Old"}], anomaly)
        second = dict(observed)
        self.assertNotEqual(first["anomaly"], second["anomaly"])
        self.assertNotEqual(first["attention"], second["attention"])


class Ledger(unittest.TestCase):
    """The signed run ledger initializes and verifies; a tampered row is
    rejected (sticky)."""

    def _ledger_command(self, *args):
        return subprocess.run(
            [sys.executable, os.path.join(BIN, "sia-ledger"), *args],
            capture_output=True, text=True, timeout=30)

    def _initialize(self, state):
        initialized = self._ledger_command("init", state)
        self.assertEqual(initialized.returncode, 0, initialized.stderr)

    def test_init_verify_tamper(self):
        with tempfile.TemporaryDirectory() as d:
            led = os.path.join(BIN, "sia-ledger")
            r = subprocess.run([sys.executable, led, "init", d],
                               capture_output=True, text=True, timeout=30)
            self.assertEqual(r.returncode, 0, r.stderr)
            v = subprocess.run([sys.executable, led, "verify", d, "--quiet"],
                               capture_output=True, text=True, timeout=30)
            self.assertEqual(v.returncode, 0, "fresh ledger must verify")
            # append a row, verify still good
            subprocess.run([sys.executable, led, "append", d, "TEST:row",
                            "a", "b",
                            "0" * 64, "0"], capture_output=True, timeout=30)
            v2 = subprocess.run([sys.executable, led, "verify", d, "--quiet"],
                                capture_output=True, timeout=30)
            self.assertEqual(v2.returncode, 0)
            # tamper: flip a byte in the ledger, expect failure
            lp = os.path.join(d, "ledger.tsv")
            with open(lp) as stream:
                rows = stream.read().splitlines()
            rows[-1] = rows[-1].replace("\tb\t", "\tZ\t", 1)
            with open(lp, "w") as stream:
                stream.write("\n".join(rows) + "\n")
            v3 = subprocess.run([sys.executable, led, "verify", d, "--quiet"],
                                capture_output=True, timeout=30)
            self.assertNotEqual(v3.returncode, 0, "tampered row must reject")

    def test_signed_tail_recovers_after_pin_publish_interruption(self):
        with tempfile.TemporaryDirectory() as state:
            led = os.path.join(BIN, "sia-ledger")
            initialized = subprocess.run(
                [sys.executable, led, "init", state], capture_output=True,
                text=True, timeout=30)
            self.assertEqual(initialized.returncode, 0, initialized.stderr)
            keeper = _load("sia_ledger_recovery", led)
            original_atomic = keeper._atomic_write

            def interrupt_pin(path, data):
                if path.endswith("head.pin"):
                    raise OSError("injected pin publish interruption")
                return original_atomic(path, data)

            keeper._atomic_write = interrupt_pin
            try:
                with keeper._ledger_lock(state):
                    with self.assertRaisesRegex(
                            OSError, "injected pin publish interruption"):
                        keeper._append_row(
                            state, "TEST:recovery", "a", "b", "0" * 64, 0)
            finally:
                keeper._atomic_write = original_atomic

            verified = subprocess.run(
                [sys.executable, led, "verify", state, "--quiet"],
                capture_output=True, text=True, timeout=30)
            self.assertEqual(verified.returncode, 0, verified.stdout)
            with open(os.path.join(state, "ledger.tsv")) as stream:
                rows = stream.read().splitlines()
            with open(os.path.join(state, "head.pin")) as stream:
                count, _head = stream.read().split()
            self.assertEqual(int(count), len(rows))

    def test_authoritative_file_reads_refuse_symlinks(self):
        for name in ("ledger.tsv", "key.hex", "pub.hex", "head.pin"):
            with self.subTest(name=name), tempfile.TemporaryDirectory() as state:
                self._initialize(state)
                path = os.path.join(state, name)
                real = path + ".real"
                os.replace(path, real)
                os.symlink(os.path.basename(real), path)
                with open(real, "rb") as stream:
                    before = stream.read()
                if name == "key.hex":
                    result = self._ledger_command(
                        "append", state, "TEST:symlink", "a", "b",
                        "0" * 64, "0")
                else:
                    result = self._ledger_command(
                        "verify", state, "--quiet")
                self.assertNotEqual(result.returncode, 0)
                with open(real, "rb") as stream:
                    self.assertEqual(stream.read(), before)

    def test_dangling_authoritative_link_refuses_fresh_init(self):
        with tempfile.TemporaryDirectory() as state:
            ledger = os.path.join(state, "ledger.tsv")
            target = os.path.join(state, "must-not-be-created")
            os.symlink(target, ledger)
            refused = self._ledger_command("init", state)
            self.assertNotEqual(refused.returncode, 0)
            self.assertIn("incomplete initialized state", refused.stderr)
            self.assertTrue(os.path.islink(ledger))
            self.assertFalse(os.path.exists(target))
            for name in ("key.hex", "pub.hex", "head.pin"):
                self.assertFalse(os.path.lexists(os.path.join(state, name)))

    def test_predictable_stage_symlinks_are_never_followed(self):
        with tempfile.TemporaryDirectory() as state:
            self._initialize(state)
            victim = os.path.join(state, "victim")
            with open(victim, "wb") as stream:
                stream.write(b"unchanged")
            traps = [os.path.join(state, "ledger.tsv.new"),
                     os.path.join(state, "head.pin.new")]
            for trap in traps:
                os.symlink(victim, trap)
            appended = self._ledger_command(
                "append", state, "TEST:staging", "a", "b",
                "0" * 64, "0")
            self.assertEqual(appended.returncode, 0, appended.stderr)
            with open(victim, "rb") as stream:
                self.assertEqual(stream.read(), b"unchanged")
            self.assertTrue(all(os.path.islink(trap) for trap in traps))
            stage_names = [name for name in os.listdir(state)
                           if ".stage." in name]
            self.assertEqual(stage_names, [])

    def test_pending_journal_symlink_refuses_without_following(self):
        with tempfile.TemporaryDirectory() as state:
            self._initialize(state)
            victim = os.path.join(state, "victim")
            with open(victim, "wb") as stream:
                stream.write(b"do not touch")
            os.symlink(victim, os.path.join(state, "ledger.pending"))
            ledger = os.path.join(state, "ledger.tsv")
            with open(ledger, "rb") as stream:
                before = stream.read()
            refused = self._ledger_command(
                "append", state, "TEST:journal-link", "a", "b",
                "0" * 64, "0")
            self.assertNotEqual(refused.returncode, 0)
            with open(victim, "rb") as stream:
                self.assertEqual(stream.read(), b"do not touch")
            with open(ledger, "rb") as stream:
                self.assertEqual(stream.read(), before)

    def test_torn_append_recovers_only_from_exact_pending_row(self):
        with tempfile.TemporaryDirectory() as state:
            self._initialize(state)
            led = os.path.join(BIN, "sia-ledger")
            keeper = _load("sia_ledger_torn_recovery", led)
            original_append = keeper._append_bytes

            def interrupt_append(path, data, _expected_info):
                fd = os.open(path, os.O_WRONLY | os.O_APPEND)
                try:
                    os.write(fd, data[:8])
                    os.fsync(fd)
                finally:
                    os.close(fd)
                raise OSError("injected partial append")

            keeper._append_bytes = interrupt_append
            try:
                with keeper._ledger_lock(state):
                    with self.assertRaisesRegex(
                            OSError, "injected partial append"):
                        keeper._append_row(
                            state, "TEST:torn", "a", "b", "0" * 64, 0)
            finally:
                keeper._append_bytes = original_append

            self.assertTrue(os.path.exists(
                os.path.join(state, "ledger.pending")))
            verified = self._ledger_command("verify", state, "--quiet")
            self.assertEqual(verified.returncode, 0, verified.stdout)
            self.assertFalse(os.path.lexists(
                os.path.join(state, "ledger.pending")))
            with open(os.path.join(state, "ledger.tsv")) as stream:
                self.assertEqual(len(stream.read().splitlines()), 2)

    def test_published_journal_recovers_before_any_append_byte(self):
        with tempfile.TemporaryDirectory() as state:
            self._initialize(state)
            led = os.path.join(BIN, "sia-ledger")
            keeper = _load("sia_ledger_preappend_recovery", led)
            original_append = keeper._append_bytes

            def interrupt_before_append(_path, _data, _expected_info):
                raise OSError("injected pre-append interruption")

            keeper._append_bytes = interrupt_before_append
            try:
                with keeper._ledger_lock(state):
                    with self.assertRaisesRegex(
                            OSError, "injected pre-append interruption"):
                        keeper._append_row(
                            state, "TEST:preappend", "a", "b", "0" * 64, 0)
            finally:
                keeper._append_bytes = original_append

            verified = self._ledger_command("verify", state, "--quiet")
            self.assertEqual(verified.returncode, 0, verified.stdout)
            with open(os.path.join(state, "ledger.tsv")) as stream:
                rows = stream.read().splitlines()
            self.assertEqual([row.split("\t")[2] for row in rows],
                             ["GENESIS:init", "TEST:preappend"])
            self.assertFalse(os.path.lexists(
                os.path.join(state, "ledger.pending")))

    def test_pin_durable_before_cleanup_recovers_without_duplicate(self):
        with tempfile.TemporaryDirectory() as state:
            self._initialize(state)
            led = os.path.join(BIN, "sia-ledger")
            keeper = _load("sia_ledger_postpin_recovery", led)
            original_remove = keeper._remove_pending

            def interrupt_cleanup(_state, _expected_info):
                raise OSError("injected journal cleanup interruption")

            keeper._remove_pending = interrupt_cleanup
            try:
                with keeper._ledger_lock(state):
                    with self.assertRaisesRegex(
                            OSError, "injected journal cleanup interruption"):
                        keeper._append_row(
                            state, "TEST:postpin", "a", "b", "0" * 64, 0)
            finally:
                keeper._remove_pending = original_remove

            verified = self._ledger_command("verify", state, "--quiet")
            self.assertEqual(verified.returncode, 0, verified.stdout)
            with open(os.path.join(state, "ledger.tsv")) as stream:
                rows = stream.read().splitlines()
            self.assertEqual([row.split("\t")[2] for row in rows],
                             ["GENESIS:init", "TEST:postpin"])
            self.assertFalse(os.path.lexists(
                os.path.join(state, "ledger.pending")))

    def test_torn_tail_without_journal_refuses_without_mutation(self):
        with tempfile.TemporaryDirectory() as state:
            self._initialize(state)
            ledger = os.path.join(state, "ledger.tsv")
            with open(ledger, "ab") as stream:
                stream.write(b"unsigned partial tail")
                stream.flush()
                os.fsync(stream.fileno())
            with open(ledger, "rb") as stream:
                before = stream.read()
            refused = self._ledger_command("verify", state, "--quiet")
            self.assertNotEqual(refused.returncode, 0)
            with open(ledger, "rb") as stream:
                self.assertEqual(stream.read(), before)

    def test_mismatched_torn_tail_and_journal_refuse_without_truncation(self):
        with tempfile.TemporaryDirectory() as state:
            self._initialize(state)
            led = os.path.join(BIN, "sia-ledger")
            keeper = _load("sia_ledger_mismatched_torn_tail", led)
            original_append = keeper._append_bytes

            def interrupt_before_append(_path, _data, _expected_info):
                raise OSError("injected pre-append interruption")

            keeper._append_bytes = interrupt_before_append
            try:
                with keeper._ledger_lock(state):
                    with self.assertRaisesRegex(
                            OSError, "injected pre-append interruption"):
                        keeper._append_row(
                            state, "TEST:mismatch", "a", "b", "0" * 64, 0)
            finally:
                keeper._append_bytes = original_append

            ledger = os.path.join(state, "ledger.tsv")
            with open(ledger, "ab") as stream:
                stream.write(b"not-the-journal-row")
                stream.flush()
                os.fsync(stream.fileno())
            with open(ledger, "rb") as stream:
                before = stream.read()
            refused = self._ledger_command("verify", state, "--quiet")
            self.assertNotEqual(refused.returncode, 0)
            with open(ledger, "rb") as stream:
                self.assertEqual(stream.read(), before)
            self.assertTrue(os.path.exists(
                os.path.join(state, "ledger.pending")))

    def test_exact_signed_tail_recovers_without_journal(self):
        with tempfile.TemporaryDirectory() as state:
            self._initialize(state)
            led = os.path.join(BIN, "sia-ledger")
            keeper = _load("sia_ledger_legacy_tail", led)
            original_atomic = keeper._atomic_write

            def interrupt_pin(path, data):
                if path.endswith("head.pin"):
                    raise OSError("injected pin publish interruption")
                return original_atomic(path, data)

            keeper._atomic_write = interrupt_pin
            try:
                with keeper._ledger_lock(state):
                    with self.assertRaisesRegex(
                            OSError, "injected pin publish interruption"):
                        keeper._append_row(
                            state, "TEST:exact-tail", "a", "b",
                            "0" * 64, 0)
            finally:
                keeper._atomic_write = original_atomic
            os.unlink(os.path.join(state, "ledger.pending"))

            verified = self._ledger_command("verify", state, "--quiet")
            self.assertEqual(verified.returncode, 0, verified.stdout)
            with open(os.path.join(state, "ledger.tsv")) as stream:
                rows = stream.read().splitlines()
            with open(os.path.join(state, "head.pin")) as stream:
                count, _head = stream.read().split()
            self.assertEqual(int(count), len(rows))

    def test_append_is_in_place_and_preserves_ledger_inode(self):
        with tempfile.TemporaryDirectory() as state:
            self._initialize(state)
            ledger = os.path.join(state, "ledger.tsv")
            before = os.stat(ledger)
            appended = self._ledger_command(
                "append", state, "TEST:inode", "a", "b",
                "0" * 64, "0")
            self.assertEqual(appended.returncode, 0, appended.stderr)
            after = os.stat(ledger)
            self.assertEqual((after.st_dev, after.st_ino),
                             (before.st_dev, before.st_ino))

    def test_ledger_rollback_behind_pin_is_rejected(self):
        with tempfile.TemporaryDirectory() as state:
            self._initialize(state)
            ledger = os.path.join(state, "ledger.tsv")
            with open(ledger, "rb") as stream:
                genesis = stream.read()
            appended = self._ledger_command(
                "append", state, "TEST:rollback", "a", "b",
                "0" * 64, "0")
            self.assertEqual(appended.returncode, 0, appended.stderr)
            with open(ledger, "wb") as stream:
                stream.write(genesis)
                stream.flush()
                os.fsync(stream.fileno())
            refused = self._ledger_command("verify", state, "--quiet")
            self.assertNotEqual(refused.returncode, 0)
            with open(ledger, "rb") as stream:
                self.assertEqual(stream.read(), genesis)

    def test_size_ceiling_refuses_before_journal_or_ledger_mutation(self):
        with tempfile.TemporaryDirectory() as state:
            self._initialize(state)
            led = os.path.join(BIN, "sia-ledger")
            keeper = _load("sia_ledger_size_ceiling", led)
            ledger = os.path.join(state, "ledger.tsv")
            with open(ledger, "rb") as stream:
                before = stream.read()
            original_limit = keeper.MAX_LEDGER_BYTES
            keeper.MAX_LEDGER_BYTES = len(before)
            try:
                with keeper._ledger_lock(state):
                    with self.assertRaisesRegex(
                            ValueError, "LEDGER SIZE LIMIT"):
                        keeper._append_row(
                            state, "TEST:ceiling", "a", "b", "0" * 64, 0)
            finally:
                keeper.MAX_LEDGER_BYTES = original_limit
            with open(ledger, "rb") as stream:
                self.assertEqual(stream.read(), before)
            self.assertFalse(os.path.lexists(
                os.path.join(state, "ledger.pending")))

    def test_mismatched_private_key_refuses_before_ledger_mutation(self):
        with tempfile.TemporaryDirectory() as state:
            led = os.path.join(BIN, "sia-ledger")
            initialized = subprocess.run(
                [sys.executable, led, "init", state], capture_output=True,
                text=True, timeout=30)
            self.assertEqual(initialized.returncode, 0, initialized.stderr)
            ledger_path = os.path.join(state, "ledger.tsv")
            with open(ledger_path) as stream:
                before = stream.read()
            with open(os.path.join(state, "pub.hex")) as stream:
                expected_public = stream.read().strip()
            replacement = Ed25519PrivateKey.generate()
            while replacement.public_key().public_bytes_raw().hex() \
                    == expected_public:
                replacement = Ed25519PrivateKey.generate()
            with open(os.path.join(state, "key.hex"), "w") as stream:
                stream.write(replacement.private_bytes_raw().hex() + "\n")

            refused = subprocess.run(
                [sys.executable, led, "append", state, "TEST:key", "a", "b",
                 "0" * 64, "0"], capture_output=True, text=True, timeout=30)
            self.assertNotEqual(refused.returncode, 0)
            self.assertIn("DOES NOT MATCH", refused.stderr)
            with open(ledger_path) as stream:
                self.assertEqual(stream.read(), before)
            verified = subprocess.run(
                [sys.executable, led, "verify", state, "--quiet"],
                capture_output=True, text=True, timeout=30)
            self.assertEqual(verified.returncode, 0, verified.stdout)

    def test_public_key_swap_after_signer_binding_refuses_before_append(self):
        with tempfile.TemporaryDirectory() as state:
            self._initialize(state)
            led = os.path.join(BIN, "sia-ledger")
            keeper = _load("sia_ledger_key_swap", led)
            ledger = os.path.join(state, "ledger.tsv")
            public_path = os.path.join(state, "pub.hex")
            with open(ledger, "rb") as stream:
                before = stream.read()
            with open(public_path, "rb") as stream:
                original_public = stream.read()
            replacement_public = Ed25519PrivateKey.generate() \
                .public_key().public_bytes_raw().hex()
            original_signing_key = keeper._signing_key

            def swap_after_binding(bound_state):
                signing_key = original_signing_key(bound_state)
                with open(public_path, "w") as stream:
                    stream.write(replacement_public + "\n")
                return signing_key

            keeper._signing_key = swap_after_binding
            try:
                with keeper._ledger_lock(state):
                    with self.assertRaisesRegex(
                            ValueError, "PUBLIC KEY CHANGED"):
                        keeper._append_row(
                            state, "TEST:key-swap", "a", "b", "0" * 64, 0)
            finally:
                keeper._signing_key = original_signing_key
                with open(public_path, "wb") as stream:
                    stream.write(original_public)
            with open(ledger, "rb") as stream:
                self.assertEqual(stream.read(), before)
            self.assertFalse(os.path.lexists(
                os.path.join(state, "ledger.pending")))


class SessionMetadataPrivacy(unittest.TestCase):
    def test_claude_session_sense_never_opens_jsonl_payload(self):
        sialib = _load("sialib_claude_metadata",
                       os.path.join(BIN, "sialib.py"))
        with tempfile.TemporaryDirectory() as home:
            directory = os.path.join(home, ".claude", "projects", "fixture")
            os.makedirs(directory)
            session = os.path.join(directory, "session.jsonl")
            with open(session, "w") as stream:
                stream.write('{"type":"user","message":"private"}\n')
            old_home = sialib.HOME
            sialib.HOME = home
            cursors = {}
            try:
                first = sialib.sense_claude(cursors)
                self.assertTrue(first)
                with open(session, "a") as stream:
                    stream.write(
                        '{"type":"assistant","message":"also private"}\n')
                with mock.patch("builtins.open",
                                side_effect=AssertionError(
                                    "session payload must remain unopened")):
                    later = sialib.sense_claude(cursors)
            finally:
                sialib.HOME = old_home
            self.assertTrue(later)
            self.assertTrue(all("private" not in event.summary
                                for event in later))



def _requires_pid_namespace(method):
    """Skip PID-namespace assertions where the host refuses unprivileged
    user namespaces; the skip names the missing host feature and is not
    proof of containment."""
    import importlib
    lib = importlib.import_module("sialib")
    return unittest.skipUnless(
        lib.process_tree_isolation() == "pid-namespace",
        "host refuses unprivileged PID namespaces; namespace containment "
        "NOT EXERCISED here")(method)

class GbrainProcessBounds(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.sialib = _load(
            "sialib_gbrain_process_bounds", os.path.join(BIN, "sialib.py"))

    def _run(self, code, *, timeout=30):
        with tempfile.TemporaryDirectory() as cwd:
            return self.sialib._run_bounded_text_process(
                [sys.executable, "-c", code], env=dict(os.environ),
                timeout=timeout, cwd=cwd)

    def _assert_lock_released(self, path, message):
        descriptor = os.open(path, os.O_RDWR)
        try:
            deadline = time.monotonic() + 2
            released = False
            while time.monotonic() < deadline:
                try:
                    fcntl.flock(descriptor, fcntl.LOCK_EX | fcntl.LOCK_NB)
                    released = True
                    break
                except BlockingIOError:
                    time.sleep(0.01)
            self.assertTrue(released, message)
        finally:
            try:
                fcntl.flock(descriptor, fcntl.LOCK_UN)
            finally:
                os.close(descriptor)

    def test_combined_stdout_stderr_overflow_is_refused(self):
        code = (
            "import os; os.write(1, b'x' * 40); "
            "os.write(2, b'y' * 25)")
        with mock.patch.object(
                self.sialib, "MAX_EXTERNAL_OUTPUT_BYTES", 64), \
                self.assertRaisesRegex(
                    OverflowError, "fixture output exceeded"):
            with tempfile.TemporaryDirectory() as cwd:
                self.sialib._run_bounded_text_process(
                    [sys.executable, "-c", code], env=dict(os.environ),
                    timeout=30, cwd=cwd, label="fixture")

    def test_invalid_utf8_is_refused_before_text_admission(self):
        with self.assertRaises(UnicodeDecodeError):
            self._run("import os; os.write(1, bytes([255]))")

    def test_progress_heartbeat_is_constant_and_does_not_echo_child_output(self):
        output = io.StringIO()
        with tempfile.TemporaryDirectory() as cwd, \
                contextlib.redirect_stderr(output):
            result = self.sialib._run_bounded_text_process(
                [sys.executable, "-c",
                 "import sys,time; print('private corpus text'); "
                 "print('private diagnostic', file=sys.stderr); "
                 "time.sleep(0.05)"],
                env=dict(os.environ), timeout=30, cwd=cwd,
                progress_interval=0.01,
                progress_label="fixture first light")
        self.assertEqual(result.returncode, 0)
        self.assertIn(
            "SIA: fixture first light is still running\n", output.getvalue())
        self.assertNotIn("private", output.getvalue())

    def test_first_light_gbrain_requests_safe_progress_heartbeats(self):
        completed = subprocess.CompletedProcess(
            ["gbrain"], 0, stdout="", stderr="")
        with mock.patch.object(
                self.sialib, "gbrain_owner",
                return_value=contextlib.nullcontext(9)), \
                mock.patch.object(
                    self.sialib, "_run_bounded_text_process",
                    return_value=completed) as bounded:
            self.sialib.gbrain(["sync", "--source", "sia"], timeout=1800)
        self.assertEqual(bounded.call_args.kwargs["progress_interval"], 30)
        self.assertEqual(
            bounded.call_args.kwargs["progress_label"],
            "CPU-only first-light memory indexing")

    def test_progress_label_is_bounded_before_child_launch(self):
        with tempfile.TemporaryDirectory() as cwd, mock.patch.object(
                self.sialib.subprocess, "Popen",
                side_effect=AssertionError("unsafe child launch")) as launch, \
                self.assertRaisesRegex(ValueError, "progress label"):
            self.sialib._run_bounded_text_process(
                [sys.executable, "-c", "pass"], env=dict(os.environ),
                timeout=30, cwd=cwd, progress_interval=0.01,
                progress_label="x" * 201)
        launch.assert_not_called()

    def test_process_group_cleanup_refuses_non_real_pid_before_signal(self):
        process = mock.MagicMock()
        os_shim = mock.Mock(wraps=self.sialib.os)
        os_shim.killpg.side_effect = AssertionError("unsafe signal")
        cleanup = self.sialib._siasenses._ORIGINAL_CHILD_FUNCTIONS[
            "_signal_and_reap_process_group"]
        with mock.patch.object(self.sialib._siasenses, "os", os_shim), \
                self.assertRaisesRegex(RuntimeError, "process identity"):
            cleanup(process, 1)
        os_shim.killpg.assert_not_called()

    def test_timeout_kills_descendant_after_direct_parent_exits(self):
        with tempfile.TemporaryDirectory() as cwd:
            pid_file = os.path.join(cwd, "descendant.pid")
            parent = (
                "import pathlib,subprocess,sys; "
                "child=subprocess.Popen([sys.executable,'-c',"
                "'import time; time.sleep(60)']); "
                "pathlib.Path(sys.argv[1]).write_text(str(child.pid))")
            with self.assertRaises(subprocess.TimeoutExpired):
                self.sialib._run_bounded_text_process(
                    [sys.executable, "-c", parent, pid_file],
                    env=dict(os.environ), timeout=1, cwd=cwd)
            with open(pid_file, encoding="utf-8") as stream:
                child_pid = int(stream.read())
            deadline = time.monotonic() + 2
            alive = True
            while time.monotonic() < deadline:
                try:
                    with open(f"/proc/{child_pid}/stat",
                              encoding="utf-8") as stream:
                        state = stream.read().split()[2]
                except FileNotFoundError:
                    alive = False
                    break
                if state == "Z":
                    alive = False
                    break
                time.sleep(0.01)
            self.assertFalse(alive, "gbrain descendant survived group kill")

    @_requires_pid_namespace
    def test_private_pid_namespace_removes_new_session_descendant(self):
        with tempfile.TemporaryDirectory() as cwd:
            lock_file = os.path.join(cwd, "descendant.lock")
            child = (
                "import fcntl,os,sys,time\n"
                "stream=open(sys.argv[1],'w')\n"
                "fcntl.flock(stream,fcntl.LOCK_EX)\n"
                "stream.write('ready');stream.flush();os.fsync(stream.fileno())\n"
                "time.sleep(60)\n")
            parent = (
                "import os,pathlib,subprocess,sys,time\n"
                f"child_code={child!r}\n"
                "subprocess.Popen([sys.executable,'-c',child_code,sys.argv[1]],"
                "start_new_session=True,stdout=subprocess.DEVNULL,"
                "stderr=subprocess.DEVNULL,close_fds=True)\n"
                "while not os.path.exists(sys.argv[1]) or "
                "pathlib.Path(sys.argv[1]).read_text()!='ready':\n"
                "    time.sleep(0.01)\n")
            result = self.sialib._run_bounded_text_process(
                [sys.executable, "-c", parent, lock_file],
                env=dict(os.environ), timeout=30, cwd=cwd,
                isolate_process_tree=True)
            self.assertEqual(result.returncode, 0)
            self._assert_lock_released(
                lock_file,
                "new-session descendant survived namespace teardown")

    @_requires_pid_namespace
    def test_private_pid_namespace_does_not_expose_host_parent_in_procfs(self):
        code = (
            "import os,sys\n"
            "host_parent=sys.argv[1]\n"
            "raise SystemExit(1 if os.path.exists('/proc/'+host_parent) "
            "else 0)\n")
        with tempfile.TemporaryDirectory() as cwd:
            result = self.sialib._run_bounded_text_process(
                [sys.executable, "-c", code, str(os.getpid())],
                env=dict(os.environ), timeout=30, cwd=cwd,
                isolate_process_tree=True)
        self.assertEqual(result.returncode, 0)

    @_requires_pid_namespace
    def test_private_pid_namespace_timeout_removes_new_session_descendant(self):
        with tempfile.TemporaryDirectory() as cwd:
            lock_file = os.path.join(cwd, "descendant.lock")
            child = (
                "import fcntl,os,sys,time\n"
                "stream=open(sys.argv[1],'w')\n"
                "fcntl.flock(stream,fcntl.LOCK_EX)\n"
                "stream.write('ready');stream.flush();os.fsync(stream.fileno())\n"
                "time.sleep(60)\n")
            parent = (
                "import os,pathlib,subprocess,sys,time\n"
                f"child_code={child!r}\n"
                "subprocess.Popen([sys.executable,'-c',child_code,sys.argv[1]],"
                "start_new_session=True,stdout=subprocess.DEVNULL,"
                "stderr=subprocess.DEVNULL,close_fds=True)\n"
                "while not os.path.exists(sys.argv[1]) or "
                "pathlib.Path(sys.argv[1]).read_text()!='ready':\n"
                "    time.sleep(0.01)\n"
                "time.sleep(60)\n")
            with self.assertRaises(subprocess.TimeoutExpired):
                self.sialib._run_bounded_text_process(
                    [sys.executable, "-c", parent, lock_file],
                    env=dict(os.environ), timeout=1, cwd=cwd,
                    isolate_process_tree=True)
            self._assert_lock_released(
                lock_file,
                "timed-out descendant survived namespace teardown")

    def test_process_group_fallback_runs_isolated_children_without_unshare(self):
        """When the host refuses user namespaces the bounded runner still
        runs the child, without unshare, and still kills its process group."""
        with tempfile.TemporaryDirectory() as cwd:
            pid_file = os.path.join(cwd, "child.pid")
            launches = []
            real_popen = subprocess.Popen

            def observing_popen(command, *args, **kwargs):
                launches.append(list(command))
                return real_popen(command, *args, **kwargs)

            announced = io.StringIO()
            with mock.patch.dict(self.sialib._PROCESS_TREE_ISOLATION,
                                 {"mode": None, "announced": False}), \
                    mock.patch.object(
                        self.sialib, "_probe_process_tree_isolation",
                        return_value=False), \
                    mock.patch.object(subprocess, "Popen", observing_popen), \
                    contextlib.redirect_stderr(announced):
                self.assertEqual(self.sialib.process_tree_isolation(),
                                 "process-group")
                self.assertEqual(self.sialib.process_tree_isolation(),
                                 "process-group")
                result = self.sialib._run_bounded_text_process(
                    [sys.executable, "-c",
                     "import os,sys;open(sys.argv[1],'w').write(str(os.getpid()))",
                     pid_file],
                    env=dict(os.environ), timeout=30, cwd=cwd,
                    isolate_process_tree=True)
            self.assertEqual(result.returncode, 0)
            self.assertEqual(len(launches), 1)
            self.assertNotIn("/usr/bin/unshare", launches[0])
            self.assertEqual(launches[0][0], sys.executable)
            self.assertEqual(
                announced.getvalue().count("process-group isolation"), 1,
                "the fallback is announced exactly once per process")
            with open(pid_file, encoding="utf-8") as stream:
                self.assertTrue(stream.read().isdigit())

    def test_public_wrappers_share_the_bounded_runner(self):
        completed = subprocess.CompletedProcess(
            ["gbrain"], 0, stdout='{"ok":true}', stderr="")
        with mock.patch.object(
                self.sialib, "gbrain_owner",
                return_value=contextlib.nullcontext(9)), \
                mock.patch.object(
                    self.sialib, "_run_bounded_text_process",
                    return_value=completed) as bounded:
            result = self.sialib.gbrain(["query", "bounded"])
            called = self.sialib._gbrain_call_unlocked(
                "bounded-op", {"value": 1}, owner_fd=9)
        self.assertIs(result, completed)
        self.assertEqual(called, {"ok": True})
        self.assertEqual(bounded.call_count, 2)

    def test_git_corpus_helpers_use_bounded_output_and_preserve_tristate(self):
        with tempfile.TemporaryDirectory() as corpus:
            subprocess.run(["git", "init", "-q", corpus], check=True)
            page = os.path.join(corpus, "page.md")
            with open(page, "w", encoding="utf-8") as stream:
                stream.write("first\n")
            with mock.patch.object(self.sialib, "CORPUS", corpus):
                self.assertEqual(self.sialib.corpus_commit("fixture"),
                                 "committed")
                self.assertEqual(self.sialib.corpus_commit("fixture"),
                                 "clean")
                with open(page, "a", encoding="utf-8") as stream:
                    stream.write("second\n")
                self.assertTrue(self.sialib.corpus_dirty())
            with mock.patch.object(
                    self.sialib, "_run_bounded_text_process",
                    side_effect=OverflowError("git output refused")):
                self.assertEqual(self.sialib.corpus_commit("fixture"),
                                 "error")
                self.assertIsNone(self.sialib.corpus_dirty())

    def test_keeper_invalid_utf8_refuses_without_cursor_progress(self):
        with tempfile.TemporaryDirectory() as share:
            keeper = os.path.join(share, "sia-ledger")
            with open(keeper, "w", encoding="utf-8") as stream:
                stream.write(
                    "import os\nos.write(1, bytes([255]))\n")
            cursor = {"sia.lines": 0}
            with mock.patch.object(self.sialib, "SHARE", share), \
                    mock.patch.object(self.sialib, "BIN", share), \
                    self.assertRaisesRegex(
                        RuntimeError, "projection keeper is incomplete"):
                self.sialib.sense_sia(cursor)
            self.assertEqual(cursor, {"sia.lines": 0})

    def test_keeper_and_git_callers_fail_closed_on_bounded_runner_refusal(self):
        refusal = OverflowError("bounded fixture refusal")
        with mock.patch.object(
                self.sialib, "_run_bounded_text_process",
                side_effect=refusal) as bounded:
            with self.assertRaisesRegex(RuntimeError, "signed ledger refused"):
                self.sialib.ledger_append(
                    "TEST:bounded", "a", "b", required=True)
            with self.assertRaises(OverflowError):
                self.sialib.ledger_contains("TEST:bounded", "a", "b", "")
            with self.assertRaises(OverflowError):
                self.sialib.ledger_settle("TEST:bounded", "a", "b", "")
            self.assertEqual(self.sialib.ledger_head(), (0, ""))
        labels = [call.kwargs["label"] for call in bounded.call_args_list]
        self.assertEqual(labels, [
            "signed ledger append", "signed ledger presence",
            "signed ledger settlement", "signed ledger head",
        ])

    def test_ledger_append_log_redaction_is_durably_accounted(self):
        old_memo_path = self.sialib.MEMO_PATH
        old_redactions = copy.deepcopy(self.sialib.REDACTIONS)
        self.sialib.REDACTIONS.clear()
        with tempfile.TemporaryDirectory() as root, \
                tempfile.TemporaryFile(mode="w+", encoding="utf-8") \
                as output:
            try:
                self.sialib.MEMO_PATH = os.path.join(root, "memo.json")
                self.sialib._write_memo({"redactions": {}})
                with mock.patch.object(
                        self.sialib, "corpus_owner",
                        return_value=contextlib.nullcontext()), \
                        mock.patch.object(
                            self.sialib, "_run_bounded_text_process",
                            side_effect=RuntimeError(
                                "token=abcdefghijklmnop")), \
                        contextlib.redirect_stdout(output):
                    self.assertFalse(self.sialib.ledger_append(
                        "TEST:failure", "a", "b"))
                output.seek(0)
                logged = output.read()
                self.assertNotIn("abcdefghijklmnop", logged)
                self.assertIn("⟦redacted⟧", logged)
                self.assertEqual(
                    self.sialib.load_memo()["redactions"],
                    {"status-error": 1})
                self.assertEqual(self.sialib.REDACTIONS, {})
            finally:
                self.sialib.MEMO_PATH = old_memo_path
                self.sialib.REDACTIONS.clear()
                self.sialib.REDACTIONS.update(old_redactions)

    def test_memory_readiness_redacts_displayed_failure_and_accounts_it(self):
        old_memo_path = self.sialib.MEMO_PATH
        old_redactions = copy.deepcopy(self.sialib.REDACTIONS)
        self.sialib.REDACTIONS.clear()
        with tempfile.TemporaryDirectory() as root:
            try:
                self.sialib.MEMO_PATH = os.path.join(root, "memo.json")
                self.sialib._write_memo({"redactions": {}})
                with mock.patch.object(
                        self.sialib, "corpus_owner",
                        return_value=contextlib.nullcontext()), \
                        mock.patch.object(
                            self.sialib, "_cortex_boundary_status",
                            return_value=(True, "")), \
                        mock.patch.object(
                            self.sialib, "_consolidation_scan_debt",
                            side_effect=RuntimeError(
                                "token=abcdefghijklmnop")):
                    ready, reason = self.sialib.memory_readiness()
                self.assertFalse(ready)
                self.assertNotIn("abcdefghijklmnop", reason)
                self.assertIn("⟦redacted⟧", reason)
                self.assertEqual(
                    self.sialib.load_memo()["redactions"],
                    {"status-error": 1})
                self.assertEqual(self.sialib.REDACTIONS, {})
            finally:
                self.sialib.MEMO_PATH = old_memo_path
                self.sialib.REDACTIONS.clear()
                self.sialib.REDACTIONS.update(old_redactions)

    def test_ledger_head_rejects_parseable_output_from_failed_keeper(self):
        failed = subprocess.CompletedProcess(
            [], 1, "7 " + "a" * 64 + "\n", "keeper failed")
        with mock.patch.object(
                self.sialib, "_run_bounded_text_process",
                return_value=failed):
            self.assertEqual(self.sialib.ledger_head(), (0, ""))


class BuiltinSourceBounds(unittest.TestCase):
    def setUp(self):
        self.sialib = _load("sialib_source_bounds",
                            os.path.join(BIN, "sialib.py"))

    def test_directory_pages_resume_instead_of_repeating_a_prefix(self):
        with tempfile.TemporaryDirectory() as directory, mock.patch.object(
                self.sialib, "MAX_SOURCE_SCAN_ENTRIES", 2):
            names = ["alpha", "bravo", "charlie", "delta"]
            for name in names:
                with open(os.path.join(directory, name), "w"):
                    pass
            page_state = None
            observed = []
            complete = False
            for _unused in names:
                page, complete, _inspected, page_state = \
                    self.sialib._bounded_source_entries(
                        directory, page_state)
                self.assertLessEqual(len(page),
                                     self.sialib.MAX_SOURCE_SCAN_ENTRIES)
                observed.extend(entry["name"] for entry in page)
                if complete:
                    break
            self.assertTrue(complete)
            self.assertEqual(set(observed), set(names))

    def test_snapshot_sources_refuse_linked_files_and_directories(self):
        with tempfile.TemporaryDirectory() as directory:
            target_file = os.path.join(directory, "target.jsonl")
            target_directory = os.path.join(directory, "target-directory")
            with open(target_file, "w") as stream:
                stream.write("{}\n")
            os.makedirs(target_directory)
            linked_file = os.path.join(directory, "linked.jsonl")
            linked_directory = os.path.join(directory, "linked-directory")
            os.symlink(target_file, linked_file)
            os.symlink(target_directory, linked_directory)
            with self.assertRaises(OSError):
                self.sialib._stable_bounded_source_tail(linked_file)
            with self.assertRaises(OSError):
                self.sialib._bounded_source_entries(linked_directory)

    def test_jackal_uses_bounded_tail_and_skips_nonfinite_timestamps(self):
        with tempfile.TemporaryDirectory() as home:
            ledger = os.path.join(
                home, ".local", "state", "jackal", "results.jsonl")
            os.makedirs(os.path.dirname(ledger))
            long_status = "s" * 253
            old = json.dumps({"ts": 0, "tool": "old", "status": "exact"}) \
                + "\n"
            current = json.dumps(
                {"ts": 1, "tool": "bounded", "status": long_status}) + "\n"
            invalid = json.dumps(
                {"ts": float("nan"), "tool": "bad", "status": "exact"}) \
                + "\n"
            with open(ledger, "w") as stream:
                stream.write(old + current + invalid)
            bound = len(("\n" + current + invalid).encode("utf-8"))
            old_home = self.sialib.HOME
            self.sialib.HOME = home
            try:
                with mock.patch.object(
                        self.sialib, "MAX_SOURCE_TAIL_BYTES", bound), \
                        mock.patch.dict(os.environ, {"SIA_BACKFILL": "1"}):
                    cursors = {}
                    events = self.sialib.sense_jackal(cursors)
            finally:
                self.sialib.HOME = old_home
            self.assertTrue(any(event.kind == "source-truncated"
                                for event in events))
            admitted = [event for event in events
                        if event.summary.startswith("bounded")]
            self.assertEqual(len(admitted), 1)
            self.assertTrue(admitted[0].kind.startswith("jackal-status_h"))
            self.assertNotIn("jackal.ts", cursors)
            self.assertEqual(
                cursors["jackal.window"]["schema"],
                "sia-jackal-window-v1")

    def test_jackal_literal_unicode_separator_remains_one_json_record(self):
        with tempfile.TemporaryDirectory() as home:
            ledger = os.path.join(
                home, ".local", "state", "jackal", "results.jsonl")
            os.makedirs(os.path.dirname(ledger))
            row = {"ts": 1, "tool": "jack\u2028al", "status": "exact"}
            with open(ledger, "w", encoding="utf-8") as stream:
                stream.write(json.dumps(row, ensure_ascii=False) + "\n")
            old_home = self.sialib.HOME
            self.sialib.HOME = home
            try:
                with mock.patch.dict(os.environ, {"SIA_BACKFILL": "1"}):
                    cursors = {}
                    events = self.sialib.sense_jackal(cursors)
            finally:
                self.sialib.HOME = old_home
            admitted = [event for event in events
                        if event.organ == "jackal" and event.kind == "exact"]
            self.assertEqual(len(admitted), 1)
            self.assertEqual(len(cursors["jackal.window"]["seen"]), 1)

    def test_jackal_claimed_formal_rows_and_corrupt_receipts_are_unverified(self):
        with tempfile.TemporaryDirectory() as home:
            state = os.path.join(home, ".local", "state", "jackal")
            receipts = os.path.join(state, "receipts")
            os.makedirs(receipts)
            ledger = os.path.join(state, "results.jsonl")
            with open(ledger, "w", encoding="utf-8") as stream:
                stream.write(json.dumps({
                    "ts": 1, "tool": "fixture", "status": "checked",
                    "formal": True}) + "\n")
            with open(os.path.join(receipts, "corrupt.json"), "w",
                      encoding="utf-8") as stream:
                stream.write("{torn")
            old_home = self.sialib.HOME
            self.sialib.HOME = home
            cursors = {}
            try:
                with mock.patch.dict(os.environ, {"SIA_BACKFILL": "1"}):
                    first = self.sialib.sense_jackal(cursors)
                claimed = [event for event in first
                           if event.summary.startswith("fixture")]
                self.assertEqual(len(claimed), 1)
                self.assertIn("unverified-observation", claimed[0].tags)
                self.assertNotIn("formal-receipt", claimed[0].tags)

                with open(os.path.join(receipts, "arbitrary.json"), "w",
                          encoding="utf-8") as stream:
                    stream.write("not a receipt")
                observed = []
                for _attempt in range(4):
                    observed.extend(self.sialib.sense_jackal(cursors))
                    if any(event.kind == "receipt-observed"
                           for event in observed):
                        break
            finally:
                self.sialib.HOME = old_home
            receipt_events = [
                event for event in observed
                if event.kind == "receipt-observed"]
            self.assertTrue(receipt_events)
            self.assertTrue(all(
                event.tags == {"jackal", "unverified-observation"}
                for event in receipt_events))
            self.assertTrue(all("formal" not in event.summary.casefold()
                                for event in receipt_events))

    def test_jackal_window_identity_admits_same_and_lower_timestamp_rewrites(self):
        with tempfile.TemporaryDirectory() as home:
            ledger = os.path.join(
                home, ".local", "state", "jackal", "results.jsonl")
            os.makedirs(os.path.dirname(ledger))
            first = {"ts": 10, "tool": "first", "status": "exact"}
            same = {"ts": 10, "tool": "same", "status": "bounded"}
            lower = {"ts": 9, "tool": "lower", "status": "checked"}
            with open(ledger, "w") as stream:
                stream.write(json.dumps(first) + "\n")
            old_home = self.sialib.HOME
            self.sialib.HOME = home
            cursors = {}
            try:
                with mock.patch.dict(os.environ, {"SIA_BACKFILL": "1"}):
                    initial = self.sialib.sense_jackal(cursors)
                replacement = ledger + ".new"
                with open(replacement, "w") as stream:
                    for row in (first, same, lower):
                        stream.write(json.dumps(row) + "\n")
                os.replace(replacement, ledger)
                rewritten = self.sialib.sense_jackal(cursors)
                repeated = self.sialib.sense_jackal(cursors)
            finally:
                self.sialib.HOME = old_home
            self.assertEqual([event.summary.split(" ", 1)[0]
                              for event in initial], ["first"])
            self.assertEqual(
                {event.summary.split(" ", 1)[0] for event in rewritten},
                {"same", "lower"})
            self.assertEqual(repeated, [])

    def test_source_entity_tokens_do_not_collapse_lossy_slug_pairs(self):
        plus = self.sialib._source_entity_token("a+b", "project")
        hyphen = self.sialib._source_entity_token("a-b", "project")
        underscore = self.sialib._source_entity_token("a_b", "project")
        escaped = self.sialib._source_entity_token("a_2bb", "project")
        self.assertEqual(len({plus, hyphen, underscore, escaped}), 4)
        self.assertEqual(hyphen, "a-b")
        self.assertEqual(plus, "a_2bb")

    def test_versioned_source_state_does_not_reencode_canonical_tokens(self):
        cursors = {}
        state, truncated = self.sialib._bounded_source_state(
            cursors, "sessions", "session")
        self.assertFalse(truncated)
        token = self.sialib._source_entity_token("A", "session")
        state[token] = {"size": 1}
        again, truncated = self.sialib._bounded_source_state(
            cursors, "sessions", "session")
        self.assertFalse(truncated)
        self.assertEqual(again, {token: {"size": 1}})
        self.assertNotIn("_5f41", again)

    def test_source_entity_token_accepts_surrogateescaped_filenames(self):
        raw = os.fsdecode(b"session-\xff")
        token = self.sialib._source_entity_token(raw, "session")
        self.assertRegex(token, r"^[a-z0-9_][a-z0-9._-]*$")
        self.assertLessEqual(
            len(token.encode("utf-8")), self.sialib.MAX_CORPUS_LEAF_BYTES)

    def test_directory_cookie_resets_on_between_page_generation_change(self):
        with tempfile.TemporaryDirectory() as directory:
            for name in ("alpha", "bravo"):
                with open(os.path.join(directory, name), "w"):
                    pass
            _page, complete, _inspected, state = \
                self.sialib._bounded_source_entries(
                    directory, None, limit=1)
            self.assertFalse(complete)
            with open(os.path.join(directory, "charlie"), "w"):
                pass
            _page, _complete, _inspected, restarted = \
                self.sialib._bounded_source_entries(
                    directory, state, limit=1)
            self.assertTrue(restarted["reset"])

    def test_current_source_tree_cursor_requires_its_exact_state_shape(self):
        fresh = self.sialib._validated_source_tree_state(
            None, self.sialib.MAX_GRAPH_TREE_LEVELS)
        mutations = []
        missing_catalog = copy.deepcopy(fresh)
        missing_catalog.pop("directories")
        mutations.append(missing_catalog)
        extra_top_level = copy.deepcopy(fresh)
        extra_top_level["unexpected"] = False
        mutations.append(extra_top_level)
        extra_frame = copy.deepcopy(fresh)
        next(iter(extra_frame["queue"]))["unexpected"] = False
        mutations.append(extra_frame)
        with tempfile.TemporaryDirectory() as directory:
            generation = self.sialib._source_tree_path_generation(directory)
            generation["unexpected"] = False
            extra_generation = copy.deepcopy(fresh)
            extra_generation["directories"] = [{
                "relative": "", "generation": generation}]
            mutations.append(extra_generation)
            for mutation in mutations:
                with self.subTest(mutation=mutation), \
                        self.assertRaisesRegex(
                            ValueError, "source tree .*invalid"):
                    self.sialib._validated_source_tree_state(
                        mutation, self.sialib.MAX_GRAPH_TREE_LEVELS)

    def test_current_source_tree_cursor_refuses_partial_page_identity(self):
        with tempfile.TemporaryDirectory() as directory:
            _entries, _complete, _inspected, page = \
                self.sialib._bounded_source_entries(directory)
        page.pop("device")
        current = self.sialib._validated_source_tree_state(
            None, self.sialib.MAX_GRAPH_TREE_LEVELS)
        next(iter(current["queue"]))["page"] = page
        with self.assertRaisesRegex(ValueError, "source tree .*invalid"):
            self.sialib._validated_source_tree_state(
                current, self.sialib.MAX_GRAPH_TREE_LEVELS)

    def test_session_tree_self_certifying_cursors_refuse_without_pruning(self):
        cases = (
            ("claude", "claude.sessions", "source.claude.tree",
             "claude-session", self.sialib.sense_claude, 1),
            ("codex", "codex.sessions", "source.codex.tree",
             "codex-session", self.sialib.sense_codex, 3),
        )
        for label, session_key, tree_key, namespace, sense, depth in cases:
            with self.subTest(label=label), \
                    tempfile.TemporaryDirectory() as home:
                if label == "claude":
                    root = os.path.join(home, ".claude", "projects")
                    os.makedirs(os.path.join(root, "project"))
                else:
                    root = os.path.join(home, ".codex", "sessions")
                    os.makedirs(os.path.join(root, "year", "month", "day"))
                prior = self.sialib._source_entity_token("prior", namespace)
                session_state = [
                    "sia-source-entity-state-v1",
                    {prior: {"size": 0, "announced": False,
                             "generation": 0}}]
                wrong_depth = self.sialib._validated_source_tree_state(
                    None, depth)
                wrong_depth["queue"][0]["levels"] = 0
                duplicate_path = self.sialib._validated_source_tree_state(
                    None, depth)
                duplicate_path["queue"].append(
                    copy.deepcopy(duplicate_path["queue"][0]))
                _entries, _complete, _inspected, page = \
                    self.sialib._bounded_source_entries(root)
                page["reset"] = True
                persisted_reset = self.sialib._validated_source_tree_state(
                    None, depth)
                persisted_reset["queue"][0]["page"] = page
                old_home = self.sialib.HOME
                self.sialib.HOME = home
                try:
                    for malformed, tree_state in (
                            ("wrong-depth", wrong_depth),
                            ("duplicate-path", duplicate_path),
                            ("persisted-reset", persisted_reset)):
                        cursors = {
                            session_key: copy.deepcopy(session_state),
                            tree_key: copy.deepcopy(tree_state)}
                        before = copy.deepcopy(cursors)
                        with self.subTest(malformed=malformed):
                            with self.assertRaisesRegex(
                                    ValueError, "source tree"):
                                sense(cursors)
                            self.assertEqual(cursors, before)
                finally:
                    self.sialib.HOME = old_home

    def test_source_tree_missing_frame_taints_cycle_and_reappearance_rebaselines(self):
        with tempfile.TemporaryDirectory() as root:
            gone = os.path.join(root, "gone")
            stay = os.path.join(root, "stay")
            os.makedirs(gone)
            os.makedirs(stay)
            with open(os.path.join(gone, "gone.jsonl"), "w"):
                pass
            with open(os.path.join(stay, "stay.jsonl"), "w"):
                pass
            key = "source.fixture.tree"
            cursors = {key: {
                "schema": self.sialib.SOURCE_TREE_SCHEMA,
                "generation": 7, "phase": "scan", "coverage": True,
                "queue": [
                    {"relative": "gone", "levels": 0, "page": {}},
                    {"relative": "stay", "levels": 0, "page": {}},
                ],
                "directories": [
                    {"relative": "", "generation":
                        self.sialib._source_tree_path_generation(root)},
                    {"relative": "gone", "generation":
                        self.sialib._source_tree_path_generation(gone)},
                ],
                "validation_cursor": 0,
            }}
            held = root + ".held"
            os.replace(gone, held)
            try:
                with mock.patch.object(
                        self.sialib, "MAX_SOURCE_SCAN_ENTRIES", 3):
                    _files, complete, refused, generation = \
                        self.sialib._bounded_source_tree_files(
                            root, cursors, key, 1, ".jsonl")
                    self.assertFalse(complete)
                    self.assertEqual(generation, 7)
                    self.assertIn("gone", refused)
                    self.assertFalse(cursors[key]["coverage"])

                    # Reappearance cannot erase the refusal carried by this
                    # generation. It is admitted by the following clean one.
                    os.replace(held, gone)
                    for _attempt in range(20):
                        if cursors[key]["generation"] != 7:
                            break
                        _files, complete, _refused, _generation = \
                            self.sialib._bounded_source_tree_files(
                                root, cursors, key, 1, ".jsonl")
                        self.assertFalse(complete)
                    self.assertNotEqual(cursors[key]["generation"], 7)
                    admitted = set()
                    complete = False
                    for _attempt in range(20):
                        files, complete, refused, generation = \
                            self.sialib._bounded_source_tree_files(
                                root, cursors, key, 1, ".jsonl")
                        self.assertEqual(refused, [])
                        admitted.update(os.path.basename(row["path"])
                                        for row in files)
                        if complete:
                            break
                    self.assertTrue(complete)
                self.assertEqual(generation, 8)
                self.assertEqual(admitted, {"gone.jsonl", "stay.jsonl"})
            finally:
                if os.path.exists(held):
                    os.replace(held, gone)

    def test_source_tree_revalidates_nested_frames_after_restore(self):
        with tempfile.TemporaryDirectory() as root:
            active = os.path.join(root, "active")
            restored = os.path.join(root, "restored")
            os.makedirs(active)
            os.makedirs(restored)
            with open(os.path.join(active, "active.jsonl"), "w"):
                pass
            with open(os.path.join(restored, "restored.jsonl"), "w"):
                pass
            key = "source.fixture.tree"
            cursors = {key: {
                "schema": self.sialib.SOURCE_TREE_SCHEMA,
                "generation": 11, "phase": "scan", "coverage": True,
                "queue": [{"relative": "active", "levels": 0,
                           "page": {}}],
                "directories": [
                    {"relative": "", "generation":
                        self.sialib._source_tree_path_generation(root)},
                    {"relative": "restored", "generation":
                        self.sialib._source_tree_path_generation(restored)},
                ],
                "validation_cursor": 0,
            }}
            held = root + ".nested-held"
            original = self.sialib._bounded_source_entries
            changed = []

            def disappear_during_active(directory, page=None, limit=None):
                if directory == active and not changed:
                    changed.append(True)
                    os.replace(restored, held)
                    try:
                        return original(directory, page, limit)
                    finally:
                        os.replace(held, restored)
                return original(directory, page, limit)

            with mock.patch.object(
                    self.sialib, "MAX_SOURCE_SCAN_ENTRIES", 4), \
                    mock.patch.object(
                        self.sialib, "_bounded_source_entries",
                        side_effect=disappear_during_active):
                _files, complete, refused, generation = \
                    self.sialib._bounded_source_tree_files(
                        root, cursors, key, 1, ".jsonl")
            self.assertTrue(changed)
            self.assertFalse(complete)
            self.assertEqual(generation, 11)
            self.assertIn(".", refused)

    def test_claude_restored_nested_frame_cannot_authorize_prune(self):
        with tempfile.TemporaryDirectory() as home:
            root = os.path.join(home, ".claude", "projects")
            active = os.path.join(root, "active")
            restored = os.path.join(root, "restored")
            os.makedirs(active)
            os.makedirs(restored)
            with open(os.path.join(active, "active.jsonl"), "w"):
                pass
            with open(os.path.join(restored, "restored.jsonl"), "w"):
                pass
            old_home = self.sialib.HOME
            self.sialib.HOME = home
            cursors = {}
            try:
                self.sialib.sense_claude(cursors)
                restored_id = self.sialib._source_entity_token(
                    "restored", "claude-session")
                generation = cursors["source.claude.tree"]["generation"]
                cursors["source.claude.tree"] = {
                    "schema": self.sialib.SOURCE_TREE_SCHEMA,
                    "generation": generation, "phase": "scan",
                    "coverage": True,
                    "queue": [{"relative": "active", "levels": 0,
                               "page": {}}],
                    "directories": [
                        {"relative": "", "generation":
                            self.sialib._source_tree_path_generation(root)},
                        {"relative": "restored", "generation":
                            self.sialib._source_tree_path_generation(
                                restored)},
                    ],
                    "validation_cursor": 0,
                }
                held = os.path.join(home, "restored-held")
                original = self.sialib._bounded_source_entries
                changed = []

                def disappear(directory, page=None, limit=None):
                    if directory == active and not changed:
                        changed.append(True)
                        os.replace(restored, held)
                        try:
                            return original(directory, page, limit)
                        finally:
                            os.replace(held, restored)
                    return original(directory, page, limit)

                with mock.patch.object(
                        self.sialib, "MAX_SOURCE_SCAN_ENTRIES", 4), \
                        mock.patch.object(
                            self.sialib, "_bounded_source_entries",
                            side_effect=disappear):
                    events = self.sialib.sense_claude(cursors)
                sessions = cursors["claude.sessions"][1]
                self.assertTrue(changed)
                self.assertIn(restored_id, sessions)
                self.assertTrue(any(event.kind == "source-entry-refused"
                                    for event in events))
            finally:
                self.sialib.HOME = old_home

    def test_codex_restored_nested_frame_cannot_authorize_prune(self):
        with tempfile.TemporaryDirectory() as home:
            root = os.path.join(home, ".codex", "sessions")
            active = os.path.join(root, "2026", "09", "30")
            restored = os.path.join(root, "2026", "08")
            os.makedirs(active)
            os.makedirs(os.path.join(restored, "30"))
            with open(os.path.join(active, "rollout-active.jsonl"), "w"):
                pass
            with open(os.path.join(
                    restored, "30", "rollout-restored.jsonl"), "w"):
                pass
            old_home = self.sialib.HOME
            self.sialib.HOME = home
            cursors = {}
            try:
                self.sialib.sense_codex(cursors)
                restored_id = self.sialib._source_entity_token(
                    "restored", "codex-session")
                generation = cursors["source.codex.tree"]["generation"]
                directory_relatives = ["", "2026", "2026/08",
                                        "2026/08/30", "2026/09"]
                cursors["source.codex.tree"] = {
                    "schema": self.sialib.SOURCE_TREE_SCHEMA,
                    "generation": generation, "phase": "scan",
                    "coverage": True,
                    "queue": [{"relative": "2026/09/30",
                               "levels": 0, "page": {}}],
                    "directories": [{
                        "relative": relative,
                        "generation": self.sialib
                            ._source_tree_path_generation(
                                os.path.join(root, relative))}
                        for relative in directory_relatives],
                    "validation_cursor": 0,
                }
                held = os.path.join(home, "codex-restored-held")
                original = self.sialib._bounded_source_entries
                changed = []

                def disappear(directory, page=None, limit=None):
                    if directory == active and not changed:
                        changed.append(True)
                        os.replace(restored, held)
                        try:
                            return original(directory, page, limit)
                        finally:
                            os.replace(held, restored)
                    return original(directory, page, limit)

                with mock.patch.object(
                        self.sialib, "MAX_SOURCE_SCAN_ENTRIES", 8), \
                        mock.patch.object(
                            self.sialib, "_bounded_source_entries",
                            side_effect=disappear):
                    events = self.sialib.sense_codex(cursors)
                sessions = cursors["codex.sessions"][1]
                self.assertTrue(changed)
                self.assertIn(restored_id, sessions)
                self.assertTrue(any(event.kind == "source-entry-refused"
                                    for event in events))
            finally:
                self.sialib.HOME = old_home

    def test_claude_nested_rename_never_false_prunes_and_reappears(self):
        with tempfile.TemporaryDirectory() as home:
            root = os.path.join(home, ".claude", "projects")
            project = os.path.join(root, "project")
            os.makedirs(project)
            with open(os.path.join(project, "existing.jsonl"), "w"):
                pass
            old_home = self.sialib.HOME
            self.sialib.HOME = home
            cursors = {}
            try:
                self.sialib.sense_claude(cursors)
                existing = self.sialib._source_entity_token(
                    "existing", "claude-session")
                sessions = cursors["claude.sessions"][1]
                self.assertIn(existing, sessions)
                generation = cursors["source.claude.tree"]["generation"]
                cursors["source.claude.tree"] = {
                    "schema": self.sialib.SOURCE_TREE_SCHEMA,
                    "generation": generation, "phase": "scan",
                    "coverage": True,
                    "queue": [{"relative": "project", "levels": 0,
                               "page": {}}],
                    "directories": [{
                        "relative": "", "generation":
                            self.sialib._source_tree_path_generation(root)}],
                    "validation_cursor": 0,
                }
                held = os.path.join(home, "project-held")
                os.replace(project, held)
                with mock.patch.object(
                        self.sialib, "MAX_SOURCE_SCAN_ENTRIES", 4):
                    refused = self.sialib.sense_claude(cursors)
                    self.assertTrue(any(event.kind == "source-entry-refused"
                                        for event in refused))
                    self.assertIn(existing, sessions)
                    os.replace(held, project)
                    with open(os.path.join(project, "new.jsonl"), "w"):
                        pass
                    target_generation = cursors[
                        "source.claude.tree"]["generation"]
                    for _attempt in range(20):
                        if cursors["source.claude.tree"]["generation"] \
                                != target_generation:
                            break
                        self.sialib.sense_claude(cursors)
                    self.assertNotEqual(
                        cursors["source.claude.tree"]["generation"],
                        target_generation)
                new = self.sialib._source_entity_token(
                    "new", "claude-session")
                sessions = cursors["claude.sessions"][1]
                self.assertIn(existing, sessions)
                self.assertIn(new, sessions)
            finally:
                self.sialib.HOME = old_home

    def test_codex_paginated_clean_generation_prunes_by_durable_marks(self):
        with tempfile.TemporaryDirectory() as home:
            root = os.path.join(
                home, ".codex", "sessions", "2026", "08", "30")
            os.makedirs(root)
            with open(os.path.join(root, "rollout-live.jsonl"), "w"):
                pass
            old_home = self.sialib.HOME
            self.sialib.HOME = home
            stale = self.sialib._source_entity_token(
                "stale", "codex-session")
            live = self.sialib._source_entity_token(
                "live", "codex-session")
            cursors = {"codex.sessions": [
                "sia-source-entity-state-v1",
                {stale: {"size": 0, "announced": False,
                         "generation": 0}}]}
            try:
                with mock.patch.object(
                        self.sialib, "MAX_SOURCE_SCAN_ENTRIES", 4):
                    for _attempt in range(20):
                        self.sialib.sense_codex(cursors)
                        if cursors["source.codex.tree"]["generation"]:
                            break
                    self.assertTrue(
                        cursors["source.codex.tree"]["generation"])
                sessions = cursors["codex.sessions"][1]
                self.assertIn(live, sessions)
                self.assertNotIn(stale, sessions)
            finally:
                self.sialib.HOME = old_home

    def test_session_senses_refuse_type_confused_persisted_rows(self):
        with tempfile.TemporaryDirectory() as home:
            claude_root = os.path.join(home, ".claude", "projects", "demo")
            codex_root = os.path.join(
                home, ".codex", "sessions", "year", "month", "day")
            os.makedirs(claude_root)
            os.makedirs(codex_root)
            with open(os.path.join(claude_root, "session.jsonl"), "w"):
                pass
            with open(os.path.join(
                    codex_root, "rollout-session.jsonl"), "w"):
                pass
            old_home = self.sialib.HOME
            self.sialib.HOME = home
            try:
                for key, sense in (
                        ("claude.sessions", self.sialib.sense_claude),
                        ("codex.sessions", self.sialib.sense_codex)):
                    cursors = {key: [
                        "sia-source-entity-state-v1", {
                            "session": {
                                "size": 0, "announced": "yes",
                                "generation": 0}}]}
                    with self.subTest(key=key), self.assertRaisesRegex(
                            ValueError, f"source cursor {re.escape(key)}"):
                        sense(cursors)
            finally:
                self.sialib.HOME = old_home

    def test_future_session_mtime_is_not_reported_as_fresh(self):
        source = {"path": "/source/session.jsonl", "size": 0,
                  "mtime": 1}
        for sense in (self.sialib.sense_claude, self.sialib.sense_codex):
            cursors = {}
            with self.subTest(sense=sense.__name__), \
                    mock.patch.object(
                        self.sialib, "_bounded_source_tree_files",
                        return_value=([source], False, [], 0)), \
                    mock.patch.object(self.sialib.time, "time", return_value=0):
                events = sense(cursors)
            self.assertEqual(events, [])

    def test_overbound_line_progresses_by_bounded_chunks_then_signs_skip(self):
        with tempfile.TemporaryDirectory() as directory:
            path = os.path.join(directory, "source.log")
            refused = b"x" * 11 + b"\n"
            with open(path, "wb") as stream:
                stream.write(refused + b"ok\n")
            cursors = {}
            pending = []
            with mock.patch.dict(os.environ, {"SIA_BACKFILL": "1"}):
                for _unused in range(10):
                    _generation, _ordinal, data = \
                        self.sialib._stable_tail_chunk(
                            path, cursors, "fixture.lines", 4)
                    self.assertEqual(data, b"")
                    pending = self.sialib._take_source_record_refusals(
                        cursors)
                    if pending:
                        break
            self.assertEqual(len(pending), 1)
            self.assertEqual(pending[0]["bytes"], len(refused))
            self.assertEqual(
                pending[0]["end"] - pending[0]["start"], len(refused))
            with mock.patch.object(
                    self.sialib, "durable_ledger_append") as append:
                self.sialib._settle_source_record_refusals(
                    "sense_fixture", pending)
            self.assertEqual(
                append.call_args.args[:3],
                ("SOURCE:refuse", "sense_fixture", "over-bound-record"))
            _generation, _ordinal, data = self.sialib._stable_tail_chunk(
                path, cursors, "fixture.lines", 4)
            self.assertEqual(data, b"ok\n")

    def test_overlong_unit_and_package_fields_are_hashed_before_events(self):
        raw = "x" * 300
        with mock.patch.object(
                self.sialib, "_verified_builtin_attest_rows", return_value=[
                    ("1", "2026-08-30T00:00:00Z", "OUTCOME:restart",
                     raw, "ok", "digest", "0", "prev", "signature")]):
            sekhmet = self.sialib.sense_sekhmet({})
        with mock.patch.object(
                self.sialib, "tail_line_records", return_value=[(
                    0, 0,
                    f"[2026-08-30T00:00:00+00:00] [ALPM] installed "
                    f"{raw} 1.0")]):
            pacman = self.sialib.sense_pacman({})
        expected_unit = "units/" + self.sialib._source_entity_token(
            raw, "unit")
        expected_package = "packages/" + self.sialib._source_entity_token(
            raw, "package")
        self.assertIn(expected_unit, sekhmet[0].links)
        self.assertIn(expected_package, pacman[0].links)

    def test_long_repository_name_is_hashed_before_event_construction(self):
        with tempfile.TemporaryDirectory() as home:
            repo = "r" * 253
            head_log = os.path.join(
                home, "Projects", repo, ".git", "logs", "HEAD")
            os.makedirs(os.path.dirname(head_log))
            with open(head_log, "w") as stream:
                stream.write("metadata\tcommit: bounded repository\n")
            old_home = self.sialib.HOME
            self.sialib.HOME = home
            try:
                with mock.patch.dict(os.environ, {"SIA_BACKFILL": "1"}):
                    events = self.sialib.sense_git({})
            finally:
                self.sialib.HOME = old_home
            self.assertEqual(len(events), 1)
            project_links = [link for link in events[0].links
                             if link.startswith("projects/")]
            self.assertEqual(len(project_links), 1)
            leaf = project_links[0].split("/")[-1]
            self.assertTrue(leaf.startswith("project_h"))
            self.assertLessEqual(len(leaf.encode("utf-8")),
                                 self.sialib.MAX_CORPUS_LEAF_BYTES)

    def test_lossy_repository_names_have_independent_tail_cursors(self):
        with tempfile.TemporaryDirectory() as home:
            for repo in ("a+b", "a-b"):
                head_log = os.path.join(
                    home, "Projects", repo, ".git", "logs", "HEAD")
                os.makedirs(os.path.dirname(head_log))
                with open(head_log, "w") as stream:
                    stream.write(f"metadata\tcommit: {repo}\n")
            old_home = self.sialib.HOME
            self.sialib.HOME = home
            cursors = {}
            try:
                with mock.patch.dict(os.environ, {"SIA_BACKFILL": "1"}):
                    events = self.sialib.sense_git(cursors)
                repeated = self.sialib.sense_git(cursors)
            finally:
                self.sialib.HOME = old_home
            project_links = {
                link for event in events for link in event.links
                if link.startswith("projects/")}
            self.assertEqual(len(project_links), 2)
            self.assertIn("git.a-b", cursors)
            self.assertIn("git.a_2bb", cursors)
            self.assertEqual(repeated, [])

    def test_session_special_nodes_cannot_authorize_pruning(self):
        cases = (
            ("claude", "claude.sessions", "claude-session",
             self.sialib.sense_claude,
             "Claude session path linked-project", "linked-project"),
            ("codex", "codex.sessions", "codex-session",
             self.sialib.sense_codex,
             "Codex session path year/month/day/rollout-hidden.jsonl",
             "year/month/day/rollout-hidden.jsonl"),
        )
        for label, cursor_key, namespace, sense, source_label, relative in cases:
            with self.subTest(label=label), \
                    tempfile.TemporaryDirectory() as home:
                sid = self.sialib._source_entity_token("hidden", namespace)
                cursors = {cursor_key: [
                    "sia-source-entity-state-v1",
                    {sid: {"size": 0, "announced": False,
                           "generation": 0}}]}
                if label == "claude":
                    root = os.path.join(home, ".claude", "projects")
                    target = os.path.join(home, "linked-claude-project")
                    os.makedirs(root)
                    os.makedirs(target)
                    with open(os.path.join(target, "hidden.jsonl"), "w"):
                        pass
                    os.symlink(target, os.path.join(root, relative))
                else:
                    leaf = os.path.join(
                        home, ".codex", "sessions", "year", "month", "day")
                    os.makedirs(leaf)
                    target = os.path.join(home, "linked-codex-session.jsonl")
                    with open(target, "w"):
                        pass
                    os.symlink(target, os.path.join(
                        home, ".codex", "sessions", relative))
                old_home = self.sialib.HOME
                self.sialib.HOME = home
                try:
                    events = sense(cursors)
                finally:
                    self.sialib.HOME = old_home
                self.assertIn(sid, cursors[cursor_key][1])
                refusals = [event for event in events
                            if event.kind == "source-entry-refused"]
                self.assertEqual(len(refusals), 1)
                self.assertEqual(
                    refusals[0].summary,
                    source_label
                    + " could not be admitted within the bounded source state")

    def test_git_special_project_path_cannot_authorize_pruning(self):
        with tempfile.TemporaryDirectory() as home:
            projects = os.path.join(home, "Projects")
            linked = os.path.join(home, "linked-project")
            os.makedirs(os.path.join(linked, ".git", "logs"))
            with open(os.path.join(linked, ".git", "logs", "HEAD"), "w"):
                pass
            os.makedirs(projects)
            repo = "linked"
            os.symlink(linked, os.path.join(projects, repo))
            repo_id = self.sialib._source_entity_token(repo, "project")
            cursor_key = f"git.{repo_id}"
            cursors = {
                "source.git.repositories": [repo_id], cursor_key: 0}
            old_home = self.sialib.HOME
            self.sialib.HOME = home
            try:
                events = self.sialib.sense_git(cursors)
            finally:
                self.sialib.HOME = old_home
            self.assertIn(repo_id, cursors["source.git.repositories"])
            self.assertIn(cursor_key, cursors)
            refusals = [event for event in events
                        if event.kind == "source-entry-refused"]
            self.assertEqual(len(refusals), 1)
            self.assertEqual(
                refusals[0].summary,
                "project repository linked could not be admitted within "
                "the bounded source state")

    def test_guardian_nonregular_entry_refuses_without_marking_seen(self):
        with tempfile.TemporaryDirectory() as home:
            checkpoints = os.path.join(
                home, ".local", "state", "omarchy-guardian", "checkpoints")
            os.makedirs(checkpoints)
            candidate = os.path.join(checkpoints, "candidate")
            os.makedirs(candidate)
            cursors = {}
            old_home = self.sialib.HOME
            self.sialib.HOME = home
            try:
                refused = self.sialib.sense_guardian(cursors)
                self.assertEqual(cursors["guardian.checkpoints"], [])
                os.rmdir(candidate)
                with open(candidate, "w"):
                    pass
                admitted = self.sialib.sense_guardian(cursors)
            finally:
                self.sialib.HOME = old_home
            refusals = [event for event in refused
                        if event.kind == "source-entry-refused"]
            self.assertEqual(len(refusals), 1)
            self.assertEqual(
                refusals[0].summary,
                "guardian checkpoint candidate could not be admitted within "
                "the bounded source state")
            self.assertEqual(
                [(event.kind, event.summary) for event in admitted],
                [("checkpoint", "new checkpoint: candidate")])

    def test_paginated_notifications_process_every_bounded_page(self):
        with tempfile.TemporaryDirectory() as home:
            history = os.path.join(
                home, ".local/state/omarchy/notifications/history")
            os.makedirs(history)
            names = ["alpha.json", "bravo.json", "charlie.json",
                     "delta.json"]
            for name in names:
                with open(os.path.join(history, name), "w") as stream:
                    json.dump({"app": "fixture", "summary": name}, stream)
            old_home = self.sialib.HOME
            self.sialib.HOME = home
            cursors = {"notify.last": ""}
            events = []
            try:
                with mock.patch.object(
                        self.sialib, "MAX_SOURCE_SCAN_ENTRIES", 2):
                    for _unused in range(len(names) + 1):
                        events.extend(self.sialib.sense_notify(cursors))
                        if "source.notify.page" not in cursors:
                            break
            finally:
                self.sialib.HOME = old_home
            self.assertEqual(
                {event.summary for event in events},
                {f"fixture: {name}" for name in names})
            self.assertFalse(any(event.kind == "source-entry-refused"
                                 for event in events))
            self.assertIn("notify.generation", cursors)
            self.assertFalse(any(
                key in cursors for key in (
                    "notify.last", "notify.pending", "notify.seen",
                    "notify.cycle_max")))

    def test_builtin_snapshot_senses_do_not_use_listdir_or_glob(self):
        with tempfile.TemporaryDirectory() as home:
            guardian = os.path.join(
                home, ".local/state/omarchy-guardian/checkpoints")
            agents = os.path.join(
                home, ".local/state/omarchy/agents/usage")
            receipts = os.path.join(
                home, ".local/state/jackal/receipts")
            claude = os.path.join(home, ".claude/projects/demo")
            codex = os.path.join(home, ".codex/sessions/2026/08/30")
            notify = os.path.join(
                home, ".local/state/omarchy/notifications/history")
            git_log = os.path.join(
                home, "Projects/demo/.git/logs/HEAD")
            for directory in (guardian, agents, receipts, claude, codex,
                              notify, os.path.dirname(git_log)):
                os.makedirs(directory)
            with open(os.path.join(guardian, "checkpoint"), "w"):
                pass
            with open(os.path.join(receipts, "receipt.json"), "w"):
                pass
            with open(os.path.join(claude, "session.jsonl"), "w"):
                pass
            with open(os.path.join(codex, "rollout-session.jsonl"), "w"):
                pass
            with open(git_log, "w") as stream:
                stream.write("metadata\tcommit: fixture\n")
            with open(os.path.join(agents, "agent.json"), "w") as stream:
                json.dump({"id": "fixture", "todayTotalTokens": 0}, stream)
            with open(os.path.join(notify, "notice.json"), "w") as stream:
                json.dump({"app": "fixture"}, stream)
            old_home = self.sialib.HOME
            self.sialib.HOME = home
            try:
                with mock.patch.object(
                        self.sialib.os, "listdir",
                        side_effect=AssertionError("listdir is unbounded")), \
                        mock.patch.object(
                            self.sialib.glob, "glob",
                            side_effect=AssertionError("glob is unbounded")):
                    self.sialib.sense_jackal({})
                    self.sialib.sense_guardian({})
                    self.sialib.sense_git({})
                    self.sialib.sense_claude({})
                    self.sialib.sense_codex({})
                    self.sialib.sense_notify({})
                    self.sialib.sense_agents({})
            finally:
                self.sialib.HOME = old_home


class LoadBearingCommentIntegrity(unittest.TestCase):
    """A garbled explanatory comment is a defect, not cosmetics.

    Two blocks in sialib.py shipped broken: the bench-trend rotation
    comment stopped mid-phrase before naming the bound it protects, and
    the dream-unit comment stuttered "failure / failure" across a line
    break and then restarted its own clause.  Both describe why a bound
    exists, which is the only thing a later reader has to go on.
    """

    ANCHORS = ("    prior = collections.deque(",
               "    ncomp = nepoch = nkept = 0")

    def setUp(self):
        with open(os.path.join(BIN, "sialib.py"), encoding="utf-8") as src:
            self.lines = src.read().splitlines()

    def _comment_block_above(self, anchor):
        index = self.lines.index(anchor)
        block = []
        while index > 0 and self.lines[index - 1].strip().startswith("#"):
            index -= 1
            block.insert(0, self.lines[index].strip().lstrip("#").strip())
        self.assertTrue(block, f"no comment block above {anchor!r}")
        return block

    def test_comment_blocks_end_in_a_finished_sentence(self):
        for anchor in self.ANCHORS:
            block = self._comment_block_above(anchor)
            self.assertTrue(
                block[-1].endswith("."),
                f"comment above {anchor!r} stops mid-sentence: "
                f"{block[-1]!r}")

    def test_comment_blocks_do_not_stutter_across_a_line_break(self):
        for anchor in self.ANCHORS:
            block = self._comment_block_above(anchor)
            words = re.findall(r"[A-Za-z']+", " ".join(block).lower())
            repeats = [first for first, second in zip(words, words[1:])
                       if first == second]
            self.assertEqual(
                repeats, [],
                f"comment above {anchor!r} repeats a word: {repeats}")


class ObsidianVaultOrgan(unittest.TestCase):
    """The optional vault organ admits Git records, never note bodies."""

    def setUp(self):
        self.sialib = _load("sialib_obsidian",
                            os.path.join(BIN, "sialib.py"))

    @contextlib.contextmanager
    def _vault(self, object_format="sha1"):
        with tempfile.TemporaryDirectory() as home:
            vault = os.path.join(home, "Obsidian")
            os.makedirs(vault)
            init = ["/usr/bin/git", "init", "-q"]
            if object_format != "sha1":
                init.append(f"--object-format={object_format}")
            result = subprocess.run(
                init, cwd=vault, stdout=subprocess.PIPE,
                stderr=subprocess.PIPE, text=True)
            if result.returncode != 0:
                self.skipTest(f"Git object format {object_format} unavailable")
            self.sialib.OBSIDIAN_VAULT = vault
            yield vault

    def _write(self, vault, relative, text):
        path = os.path.join(vault, relative)
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w", encoding="utf-8") as stream:
            stream.write(text)
        return path

    def _git(self, vault, *args, check=True):
        return subprocess.run(
            ["/usr/bin/git", "-C", vault, *args], check=check,
            stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)

    def _commit(self, vault, subject):
        self._git(vault, "add", "-A")
        self._git(vault, "-c", "user.email=fixture@example.invalid",
                  "-c", "user.name=fixture", "commit", "-qm", subject)
        return self._git(vault, "rev-parse", "HEAD").stdout.strip()

    def _sense(self, cursors=None, *, backfill=True):
        cursors = {} if cursors is None else cursors
        value = "1" if backfill else ""
        with mock.patch.dict(os.environ, {"SIA_BACKFILL": value},
                             clear=False):
            return self.sialib.sense_obsidian(cursors)

    def test_absent_vault_is_silent_not_an_empty_catalog(self):
        with tempfile.TemporaryDirectory() as home:
            self.sialib.OBSIDIAN_VAULT = os.path.join(home, "Obsidian")
            cursors = {}
            self.assertEqual(self._sense(cursors), [])
            self.assertEqual(cursors, {})

    def test_actual_subject_and_markdown_path_counts_only(self):
        with self._vault() as vault:
            self._write(vault, "keep.md", "private first body\n")
            self._write(vault, "delete.md", "private deleted body\n")
            self._write(vault, "ignore.txt", "not markdown\n")
            self._write(vault, ".obsidian/private.md", "private settings\n")
            self._commit(vault, "initial vault")

            self._write(vault, "keep.md", "changed private body\n")
            self._write(vault, "added-secret-name.md", "new private body\n")
            self._write(vault, "ignore.txt", "changed non-markdown\n")
            self._write(vault, ".obsidian/private.md", "changed settings\n")
            os.unlink(os.path.join(vault, "delete.md"))
            oid = self._commit(vault, "actual commit subject")

            # A reflog message is mutable metadata, not the commit subject.
            log_path = os.path.join(vault, ".git", "logs", "HEAD")
            with open(log_path, encoding="utf-8") as stream:
                rows = stream.readlines()
            rows[-1] = rows[-1].split("\t", 1)[0] \
                + "\tcommit: forged reflog subject\n"
            with open(log_path, "w", encoding="utf-8") as stream:
                stream.writelines(rows)

            events = self._sense()

        event = next(item for item in events
                     if item.occurrence == f"obsidian:{oid}")
        self.assertEqual(
            event.summary,
            f"vault {oid[:12]}: actual commit subject — Markdown +1 ~1 -1")
        self.assertEqual(event.organ, "obsidian")
        self.assertEqual(event.kind, "commit")
        self.assertEqual(event.links, {"organs/obsidian"})
        self.assertIn("markdown-metadata", event.tags)
        self.assertNotIn("forged reflog", event.summary)
        self.assertNotIn("added-secret-name", event.summary)
        self.assertNotIn("private body", event.summary)

    def test_history_is_tailed_without_replay(self):
        with self._vault() as vault:
            self._write(vault, "first.md", "first\n")
            self._commit(vault, "first")
            cursors = {}
            first = self._sense(cursors)
            repeated = self._sense(cursors)
            self._write(vault, "second.md", "second\n")
            oid = self._commit(vault, "second")
            appended = self._sense(cursors)
        self.assertEqual(len(first), 1)
        self.assertEqual(repeated, [])
        self.assertEqual(len(appended), 1)
        self.assertEqual(appended[0].occurrence, f"obsidian:{oid}")
        self.assertIn(": second — Markdown +1 ~0 -0", appended[0].summary)

    def test_first_observation_baselines_without_backfill(self):
        with self._vault() as vault:
            self._write(vault, "first.md", "first\n")
            self._commit(vault, "first")
            cursors = {}
            self.assertEqual(self._sense(cursors, backfill=False), [])
            self._write(vault, "second.md", "second\n")
            oid = self._commit(vault, "second")
            events = self._sense(cursors, backfill=False)
        self.assertEqual([event.occurrence for event in events],
                         [f"obsidian:{oid}"])

    def test_no_note_body_is_ever_opened(self):
        with self._vault() as vault:
            self._write(vault, "daily/private.md", "private note body\n")
            self._write(vault, ".obsidian/state.md", "private app state\n")
            self._commit(vault, "metadata only")
            opened = []
            real_open = self.sialib.os.open

            def recording_open(path, *args, **kwargs):
                opened.append(os.fsdecode(path))
                return real_open(path, *args, **kwargs)

            with mock.patch.object(self.sialib.os, "open", recording_open):
                events = self._sense()
        self.assertEqual(len(events), 1)
        self.assertFalse([name for name in opened if name.endswith(".md")],
                         opened)
        self.assertNotIn("private note body", events[0].summary)
        self.assertNotIn("private app state", events[0].summary)

    def test_control_bearing_markdown_filename_is_counted_then_discarded(self):
        with self._vault() as vault:
            hostile_name = "private\n\t\x1e-name.md"
            self._write(vault, hostile_name, "private note body\n")
            oid = self._commit(vault, "hostile path metadata")
            event = self._sense()[0]
        self.assertEqual(event.occurrence, f"obsidian:{oid}")
        self.assertIn("Markdown +1 ~0 -0", event.summary)
        self.assertNotIn("private", event.summary)
        self.assertNotIn("\n", event.summary)
        self.assertNotIn("\t", event.summary)
        self.assertNotIn("\x1e", event.summary)

    def test_non_utf8_markdown_filename_is_quoted_counted_and_discarded(self):
        with self._vault() as vault:
            raw_path = os.fsencode(vault) + b"/private-\xff.md"
            descriptor = os.open(
                raw_path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
            try:
                os.write(descriptor, b"private note body\n")
            finally:
                os.close(descriptor)
            oid = self._commit(vault, "non-UTF-8 path metadata")
            event = self._sense()[0]
        self.assertEqual(event.occurrence, f"obsidian:{oid}")
        self.assertIn("Markdown +1 ~0 -0", event.summary)
        self.assertNotIn("private", event.summary)
        self.assertNotIn("377", event.summary)

    def test_repository_commands_cannot_run_diff_drivers_hooks_or_notes(self):
        with self._vault() as vault:
            sentinel = os.path.join(vault, "command-ran")
            script = self._write(
                vault, "leak.sh", "#!/bin/sh\nprintf ran > "
                + shlex.quote(sentinel) + "\n")
            os.chmod(script, 0o700)
            self._write(vault, ".gitattributes", "*.md diff=leak\n")
            self._write(vault, "private.md", "body never for textconv\n")
            self._git(vault, "config", "diff.leak.command", script)
            self._git(vault, "config", "diff.leak.textconv", script)
            oid = self._commit(vault, "safe subject")
            hook = self._write(
                vault, ".git/hooks/post-rewrite",
                "#!/bin/sh\nprintf hook > " + shlex.quote(sentinel) + "\n")
            os.chmod(hook, 0o700)
            self._git(vault, "-c", "user.email=fixture@example.invalid",
                      "-c", "user.name=fixture", "notes", "add", "-m",
                      "private note metadata", oid)
            events = self._sense()
            self.assertFalse(os.path.exists(sentinel))
        self.assertEqual(len(events), 1)
        self.assertNotIn("private note metadata", events[0].summary)

    def test_vault_config_cannot_include_or_parse_a_markdown_note(self):
        with self._vault() as vault:
            self._write(vault, "note.md", "private note body\n")
            oid = self._commit(vault, "isolated repository config")
            included = self._write(
                vault, "private-config.md", "not valid git config [[secret]]\n")
            config_path = os.path.join(vault, ".git", "config")
            with open(config_path, "a", encoding="utf-8") as stream:
                stream.write("\n[include]\n\tpath = ../private-config.md\n")

            events = self._sense()

        self.assertEqual([event.occurrence for event in events],
                         [f"obsidian:{oid}"])
        self.assertNotIn(os.path.basename(included), events[0].summary)
        self.assertNotIn("secret", events[0].summary)

    def test_worktree_pointer_file_and_links_are_silent(self):
        with tempfile.TemporaryDirectory() as home:
            vault = os.path.join(home, "Obsidian")
            os.makedirs(vault)
            with open(os.path.join(vault, ".git"), "w") as stream:
                stream.write("gitdir: /elsewhere/worktrees/vault\n")
            self.sialib.OBSIDIAN_VAULT = vault
            cursors = {}
            self.assertEqual(self._sense(cursors), [])
            self.assertEqual(cursors, {})

        with self._vault() as vault:
            self._write(vault, "note.md", "private\n")
            self._commit(vault, "linked")
            real_git = os.path.join(os.path.dirname(vault), "real.git")
            os.rename(os.path.join(vault, ".git"), real_git)
            os.symlink(real_git, os.path.join(vault, ".git"))
            cursors = {}
            self.assertEqual(self._sense(cursors), [])
            self.assertEqual(cursors, {})

    def test_symlinked_vault_ancestor_is_silent(self):
        with self._vault() as vault:
            self._write(vault, "note.md", "private\n")
            self._commit(vault, "linked ancestor")
            linked = os.path.join(os.path.dirname(vault), "linked-vault")
            os.symlink(vault, linked)
            self.sialib.OBSIDIAN_VAULT = linked
            cursors = {}
            self.assertEqual(self._sense(cursors), [])
            self.assertEqual(cursors, {})

    def test_missing_reflog_in_a_real_git_directory_is_silent(self):
        with self._vault():
            self.assertEqual(self._sense(), [])

    def test_organ_activates_only_when_the_vault_git_exists(self):
        self.assertIn("obsidian", self.sialib.OPTIONAL_ORGANS)
        self.assertEqual(self.sialib._SENSE_ORGAN["sense_obsidian"],
                         "obsidian")
        with tempfile.TemporaryDirectory() as home:
            vault = os.path.join(home, "Obsidian")
            self.sialib.OBSIDIAN_VAULT = vault
            self.assertNotIn("obsidian", self.sialib._build_organs())
            os.makedirs(os.path.join(vault, ".git"))
            self.assertIn("obsidian", self.sialib._build_organs())
            real_git = os.path.join(home, "real.git")
            os.rename(os.path.join(vault, ".git"), real_git)
            os.symlink(real_git, os.path.join(vault, ".git"))
            self.assertNotIn("obsidian", self.sialib._build_organs())

    def test_environment_override_is_absolute_bounded_and_fail_closed(self):
        old = os.environ.pop("OBSIDIAN_VAULT_PATH", None)
        try:
            self.assertEqual(self.sialib._configured_obsidian_vault(),
                             os.path.join(self.sialib.HOME, "Obsidian"))
        finally:
            if old is not None:
                os.environ["OBSIDIAN_VAULT_PATH"] = old
        with tempfile.TemporaryDirectory() as home:
            override = os.path.join(home, "vault")
            with mock.patch.dict(os.environ,
                                 {"OBSIDIAN_VAULT_PATH": override}):
                self.assertEqual(self.sialib._configured_obsidian_vault(),
                                 override)
        for bad in ("", "relative/vault",
                    "/" + "x" * self.sialib.MAX_CONFIG_PATH_CHARS):
            self.sialib.CONFIG_ERRORS.clear()
            with mock.patch.dict(os.environ,
                                 {"OBSIDIAN_VAULT_PATH": bad}):
                self.assertIsNone(self.sialib._configured_obsidian_vault())
            self.assertIn({
                "config": "config.json",
                "error": "obsidian-vault-environment-invalid",
            }, self.sialib.CONFIG_ERRORS)

    def test_sha1_and_sha256_object_names_are_complete(self):
        for object_format, expected_length in (("sha1", 40), ("sha256", 64)):
            with self.subTest(object_format=object_format), \
                    self._vault(object_format) as vault:
                self._write(vault, "note.md", "private\n")
                oid = self._commit(vault, f"{object_format} commit")
                events = self._sense()
                self.assertEqual(len(oid), expected_length)
                self.assertEqual([event.occurrence for event in events],
                                 [f"obsidian:{oid}"])
        for bad in ("a" * 4, "a" * 39, "a" * 41,
                    "a" * 63, "a" * 65, "0" * 40, "G" * 40):
            self.assertFalse(self.sialib._obsidian_object_name(bad))

    def test_git_failures_leave_the_source_cursor_unchanged(self):
        failures = (
            subprocess.CompletedProcess([], 0, "malformed", ""),
            subprocess.TimeoutExpired(["git"], 1),
            OverflowError("bounded output"),
        )
        with self._vault() as vault:
            self._write(vault, "note.md", "private\n")
            self._commit(vault, "fixture")
            for failure in failures:
                with self.subTest(failure=type(failure).__name__):
                    cursors = {"sentinel": "kept"}
                    kwargs = ({"return_value": failure}
                              if isinstance(failure,
                                            subprocess.CompletedProcess)
                              else {"side_effect": failure})
                    with mock.patch.object(
                            self.sialib, "_run_bounded_text_process",
                            **kwargs), self.assertRaises(Exception):
                        self._sense(cursors)
                    self.assertEqual(cursors, {"sentinel": "kept"})

    def test_missing_commit_object_leaves_the_cursor_unchanged(self):
        with self._vault() as vault:
            self._write(vault, "note.md", "private\n")
            self._commit(vault, "fixture")
            log_path = os.path.join(vault, ".git", "logs", "HEAD")
            with open(log_path, encoding="utf-8") as stream:
                row = stream.read()
            fields = row.split(" ", 2)
            missing = "f" * len(fields[1])
            with open(log_path, "w", encoding="utf-8") as stream:
                stream.write(fields[0] + " " + missing + " " + fields[2])
            cursors = {"sentinel": "kept"}
            with self.assertRaisesRegex(RuntimeError, "metadata read failed"):
                self._sense(cursors)
            self.assertEqual(cursors, {"sentinel": "kept"})

    def test_blob_oid_in_commit_reflog_row_never_reaches_git_output(self):
        body = "PRIVATE-NOTE-BODY-SENTINEL"
        with self._vault() as vault:
            self._write(vault, "note.md", body + "\n")
            self._commit(vault, "fixture")
            blob_oid = self._git(
                vault, "rev-parse", "HEAD:note.md").stdout.strip()
            log_path = os.path.join(vault, ".git", "logs", "HEAD")
            with open(log_path, encoding="utf-8") as stream:
                row = stream.read()
            fields = row.split(" ", 2)
            with open(log_path, "w", encoding="utf-8") as stream:
                stream.write(fields[0] + " " + blob_oid + " " + fields[2])

            captured = []
            real_run = self.sialib._run_bounded_text_process

            def recording_run(*args, **kwargs):
                result = real_run(*args, **kwargs)
                captured.append(result)
                return result

            cursors = {"sentinel": "kept"}
            with mock.patch.object(
                    self.sialib, "_run_bounded_text_process",
                    side_effect=recording_run), self.assertRaisesRegex(
                        RuntimeError, "metadata read failed"):
                self._sense(cursors)
        self.assertEqual(cursors, {"sentinel": "kept"})
        child_output = "".join(
            item.stdout + item.stderr for item in captured)
        self.assertNotIn(body, child_output)

    def test_subject_is_redacted_and_controls_are_neutralized(self):
        with self._vault() as vault:
            self._write(vault, "note.md", "private\n")
            self._commit(
                vault, "password=hunter2supersecret\x1e\a visible")
            event = self._sense()[0]
        self.assertNotIn("hunter2supersecret", event.summary)
        self.assertNotIn("\a", event.summary)
        self.assertNotIn("\x1e", event.summary)
        self.assertIn("visible", event.summary)
        self.assertIn("⟦redacted⟧", event.summary)

    def test_event_day_retains_evidence_origin(self):
        with self._vault() as vault:
            self._write(vault, "note.md", "private\n")
            self._commit(vault, "evidence event")
            event = self._sense()[0]
        with tempfile.TemporaryDirectory() as corpus:
            self.sialib.CORPUS = corpus
            day = event.ts.strftime("%Y-%m-%d")
            self.sialib.update_day_page("obsidian", day, [event])
            self.assertEqual(self.sialib.corpus_origin(
                f"events/obsidian/{day}", "event-day"), "evidence")


class Redaction(unittest.TestCase):
    """Secret-shaped spans are dropped at the sense boundary; hex ledger
    digests are preserved (they are evidence)."""

    def setUp(self):
        self.sialib = _load("sialib_r", os.path.join(BIN, "sialib.py"))

    def test_secrets_redacted(self):
        for secret in ["sk-abcdef0123456789ABCDEF01",
                       "Bearer abcdef0123456789ABCDEFxyz",
                       "AKIAIOSFODNN7EXAMPLE",
                       "password=hunter2supersecret"]:
            out = self.sialib.redact(f"log line {secret} tail", "t")
            self.assertIn("redacted", out, secret)
            self.assertNotIn(secret.split("=")[-1][:8], out)

    def test_hex_digest_preserved(self):
        digest = "a" * 64
        out = self.sialib.redact(f"chain head {digest}", "t")
        self.assertIn(digest, out, "ledger digests must survive redaction")

    def test_terminal_and_bidi_controls_are_removed(self):
        hostile = "plain\x1b]52;c;payload\x07\x1b[31mred\u202eevil"
        out = self.sialib.redact(hostile, "t")
        for control in ("\x1b", "\x07", "\u202e"):
            self.assertNotIn(control, out)
        self.assertIn("plain", out)

    def test_event_boundary_makes_untrusted_graph_markup_inert(self):
        event = self.sialib.Event(
            "notify", self.sialib.utcnow(), "notification",
            "app [[events/forged]]\n## injected **Timeline**",
            {"organs/notify"})
        self.assertNotIn("[[events/forged]]", event.summary)
        self.assertNotIn("\n", event.summary)
        self.assertNotIn("**", event.summary)

    def test_event_boundary_neutralizes_html_and_markdown_links(self):
        event = self.sialib.Event(
            "notify", self.sialib.utcnow(), "notification",
            "![forged](https://example.invalid/x) "
            "<img src=x onerror=alert(1)>", {"organs/notify"})
        self.assertNotIn("![", event.summary)
        self.assertNotIn("<img", event.summary)
        self.assertNotIn("[forged](", event.summary)

    def test_event_capacity_accepts_duplicate_normalized_values(self):
        bound = self.sialib.MAX_LEDGER_PENDING_RECORDS
        links = [f"projects/event-capacity-{index}"
                 for index in range(bound)]
        tags = [f"tag-{index}" for index in range(bound)]
        event = self.sialib.Event(
            "test", self.sialib.utcnow(), "capacity", "duplicates",
            links=links + [links[0]], tags=tags + [" TAG 0 "])
        self.assertEqual(event.links, set(links))
        self.assertEqual(event.tags, set(tags))

    def test_event_capacity_refuses_excess_unique_links_and_tags(self):
        bound = self.sialib.MAX_LEDGER_PENDING_RECORDS
        links = [f"projects/event-capacity-{index}"
                 for index in range(bound)]
        tags = [f"tag-{index}" for index in range(bound)]
        with self.assertRaisesRegex(
                ValueError, "event links exceed their unique-value bound"):
            self.sialib.Event(
                "test", self.sialib.utcnow(), "capacity", "links",
                links=links + ["projects/event-capacity-overflow"])
        with self.assertRaisesRegex(
                ValueError, "event tags exceed their unique-value bound"):
            self.sialib.Event(
                "test", self.sialib.utcnow(), "capacity", "tags",
                tags=tags + ["tag-overflow"])


class SignedSiaLedgerProjection(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.sialib = _load("sialib_sia_projection",
                            os.path.join(BIN, "sialib.py"))
        self.sialib.SHARE = self.temp.name
        # Exercise the keeper shipped by this checkout.  A developer machine
        # may already have SIA installed under ~/.local/share/sia/bin, while a
        # clean CI runner does not; leaving BIN at its import-time default
        # makes this fixture accidentally depend on that ambient installation.
        self.sialib.BIN = BIN
        self.keeper = os.path.join(BIN, "sia-ledger")
        subprocess.run([sys.executable, self.keeper, "init", self.temp.name],
                       check=True, capture_output=True, text=True)

    def tearDown(self):
        self.temp.cleanup()

    def _append(self, action, arg1, arg2):
        subprocess.run(
            [sys.executable, self.keeper, "append", self.temp.name,
             action, arg1, arg2, hashlib.sha256(b"").hexdigest(), "0"],
            check=True, capture_output=True, text=True)

    def test_projection_is_verified_answer_bearing_and_non_recursive(self):
        self._append("INSTALL:runtime", "sia-1.3.0", "prepared")
        self._append("PULSE:ingest", "pulse=1", "ok")
        self._append("DREAM:bench", "passed", "local")
        self._append("SOURCE:refuse", "journal", "event-capacity")
        self._append("BOOT:brainstem", "1.3.0", "pulse=60s")
        cursors = {"sia.lines": 0}
        events = self.sialib.sense_sia(cursors)
        self.assertEqual(len(events), 2)
        summaries = [event.summary for event in events]
        self.assertTrue(any("INSTALL:runtime sia-1.3.0 prepared" in value
                            for value in summaries))
        self.assertTrue(any("BOOT:brainstem 1.3.0 pulse=60s" in value
                            for value in summaries))
        self.assertFalse(any("PULSE:ingest" in value for value in summaries))
        self.assertFalse(any("DREAM:bench" in value for value in summaries))
        self.assertFalse(any("SOURCE:refuse" in value for value in summaries))
        self.assertEqual(self.sialib.sense_sia(cursors), [])

    def test_keeper_refusal_does_not_advance_projection_cursor(self):
        self._append("INSTALL:runtime", "sia-1.3.0", "prepared")
        ledger = os.path.join(self.temp.name, "ledger.tsv")
        with open(ledger, "r+b") as stream:
            stream.seek(-2, os.SEEK_END)
            byte = stream.read(1)
            stream.seek(-1, os.SEEK_CUR)
            stream.write(bytes([byte[0] ^ 1]))
        cursors = {"sia.lines": 0}
        with self.assertRaisesRegex(RuntimeError, "projection refused"):
            self.sialib.sense_sia(cursors)
        self.assertEqual(cursors, {"sia.lines": 0})

    def test_optional_chain_refuses_invalid_row_before_projection(self):
        ledger = os.path.join(self.temp.name, "optional.tsv")
        verifier = os.path.join(self.temp.name, "verify.py")
        with open(verifier, "w", encoding="utf-8") as stream:
            stream.write(
                "import pathlib,sys\n"
                "raw=pathlib.Path(sys.argv[1]).read_bytes()\n"
                "raise SystemExit(0 if raw.endswith(b'\\tvalid\\n') else 1)\n")
        with open(ledger, "w", encoding="utf-8") as stream:
            stream.write(
                "1\t2026-08-30T00:00:00Z\tOUTCOME:restart\tunit\tok\t"
                "digest\t0\tprev\tinvalid\n")
        binding = (ledger, verifier,
                   [sys.executable, verifier, ledger])
        cursors = {"sekhmet.lines": 0}
        with mock.patch.object(
                self.sialib, "_chain_cmds",
                return_value={"sekhmet": binding}):
            with self.assertRaisesRegex(RuntimeError, "projection refused"):
                self.sialib.sense_sekhmet(cursors)
        self.assertEqual(cursors, {"sekhmet.lines": 0})

    def test_optional_chain_refuses_hardlinked_ledger_or_verifier(self):
        ledger = os.path.join(self.temp.name, "optional.tsv")
        verifier = os.path.join(self.temp.name, "verify.py")
        with open(verifier, "w", encoding="utf-8") as stream:
            stream.write("raise SystemExit(0)\n")
        with open(ledger, "w", encoding="utf-8") as stream:
            stream.write(
                "1\t2026-08-30T00:00:00Z\tOUTCOME:restart\tunit\tok\t"
                "digest\t0\tprev\tvalid\n")
        binding = (ledger, verifier,
                   [sys.executable, verifier, ledger])
        for target in (ledger, verifier):
            with self.subTest(target=target):
                alias = target + ".alias"
                os.link(target, alias)
                try:
                    with mock.patch.object(
                            self.sialib, "_chain_cmds",
                            return_value={"sekhmet": binding}), \
                            self.assertRaisesRegex(
                                RuntimeError, "single-link"):
                        self.sialib.sense_sekhmet({"sekhmet.lines": 0})
                finally:
                    os.unlink(alias)

    def test_optional_chain_verifier_uses_private_launch_context(self):
        ledger = os.path.join(self.temp.name, "optional.tsv")
        verifier = os.path.join(self.temp.name, "verify.py")
        with open(ledger, "w", encoding="utf-8") as stream:
            stream.write("ledger\n")
        with open(verifier, "w", encoding="utf-8") as stream:
            stream.write("raise SystemExit(1)\n")
        binding = (ledger, verifier,
                   [sys.executable, verifier, ledger])
        observed = {}

        def reject(_command, **kwargs):
            observed["cwd"] = kwargs["cwd"]
            observed["cwd_entries"] = os.listdir(kwargs["cwd"])
            observed["env"] = dict(kwargs["env"])
            return subprocess.CompletedProcess([], 1, "", "keeper refused")

        with mock.patch.object(
                self.sialib, "_chain_cmds",
                return_value={"sekhmet": binding}), \
                mock.patch.dict(
                    os.environ,
                    {"SIA_TEST_AMBIENT_VERIFIER_SECRET": "must-not-pass"}), \
                mock.patch.object(
                    self.sialib, "_run_bounded_text_process",
                    side_effect=reject), \
                self.assertRaisesRegex(RuntimeError, "projection refused"):
            self.sialib.sense_sekhmet({"sekhmet.lines": 0})

        self.assertTrue(os.path.isabs(observed["cwd"]))
        self.assertEqual(observed["cwd_entries"], [])
        self.assertEqual(set(observed["env"]), {
            "HOME", "TMPDIR", "PATH", "LANG", "LC_ALL",
        })
        self.assertNotIn(
            "SIA_TEST_AMBIENT_VERIFIER_SECRET", observed["env"])

    def test_optional_chain_verifier_output_is_not_persistable_diagnostic(self):
        ledger = os.path.join(self.temp.name, "optional.tsv")
        verifier = os.path.join(self.temp.name, "verify.py")
        with open(ledger, "w", encoding="utf-8") as stream:
            stream.write("ledger\n")
        with open(verifier, "w", encoding="utf-8") as stream:
            stream.write("raise SystemExit(1)\n")
        binding = (ledger, verifier,
                   [sys.executable, verifier, ledger])
        secret = "VERIFIER-PRIVATE-OUTPUT-MUST-NOT-PERSIST"

        with mock.patch.object(
                self.sialib, "_chain_cmds",
                return_value={"sekhmet": binding}), \
                mock.patch.object(
                    self.sialib, "_run_bounded_text_process",
                    return_value=subprocess.CompletedProcess(
                        [], 17, secret + "-stdout", secret + "-stderr")), \
                self.assertRaisesRegex(
                    RuntimeError, "keeper exited nonzero") as raised:
            self.sialib.sense_sekhmet({"sekhmet.lines": 0})

        self.assertNotIn(secret, str(raised.exception))

    def test_mutation_after_keeper_success_cannot_project_or_advance(self):
        ledger = os.path.join(self.temp.name, "optional.tsv")
        verifier = os.path.join(self.temp.name, "verify.py")
        with open(verifier, "w", encoding="utf-8") as stream:
            stream.write("raise SystemExit(0)\n")
        valid = (
            "1\t2026-08-30T00:00:00Z\tOUTCOME:restart\tunit\tok\t"
            "digest\t0\tprev\tvalid\n")
        with open(ledger, "w", encoding="utf-8") as stream:
            stream.write(valid)
        binding = (ledger, verifier,
                   [sys.executable, verifier, ledger])
        cursors = {"sekhmet.lines": 0}

        def mutate_after_verify(*_args, **_kwargs):
            with open(ledger, "a", encoding="utf-8") as stream:
                stream.write(
                    "2\t2026-08-30T00:00:01Z\tOUTCOME:restart\tforged\t"
                    "ok\tdigest\t0\tprev\tinvalid\n")
            return subprocess.CompletedProcess([], 0, "", "")

        with mock.patch.object(
                self.sialib, "_chain_cmds",
                return_value={"sekhmet": binding}), \
                mock.patch.object(
                    self.sialib, "_run_bounded_text_process",
                    side_effect=mutate_after_verify):
            with self.assertRaisesRegex(RuntimeError, "changed after keeper"):
                self.sialib.sense_sekhmet(cursors)
        self.assertEqual(cursors, {"sekhmet.lines": 0})

    def test_transient_path_swap_during_tail_cannot_admit_forged_generation(self):
        ledger = os.path.join(self.temp.name, "optional.tsv")
        verified_hold = os.path.join(self.temp.name, "verified-held.tsv")
        forged = os.path.join(self.temp.name, "forged.tsv")
        verifier = os.path.join(self.temp.name, "verify.py")
        verified_row = (
            "1\t2026-08-30T00:00:00Z\tOUTCOME:restart\tverified-unit\tok\t"
            "digest\t0\tprev\tvalid\n")
        forged_rows = (
            "1\t2026-08-30T00:00:00Z\tOUTCOME:restart\tforged-alpha\tok\t"
            "digest\t0\tprev\tinvalid\n"
            "2\t2026-08-30T00:00:01Z\tOUTCOME:restart\tforged-beta\tok\t"
            "digest\t0\tprev\tinvalid\n")
        with open(ledger, "w", encoding="utf-8") as stream:
            stream.write(verified_row)
        with open(forged, "w", encoding="utf-8") as stream:
            stream.write(forged_rows)
        with open(verifier, "w", encoding="utf-8") as stream:
            stream.write(
                "import pathlib,sys\n"
                "raw=pathlib.Path(sys.argv[1]).read_bytes()\n"
                "valid=(b'verified-unit' in raw and b'forged-' not in raw)\n"
                "raise SystemExit(0 if valid else 1)\n")
        binding = (ledger, verifier,
                   [sys.executable, verifier, ledger])
        cursors = {"sekhmet.lines": 0}
        original_attest_rows = self.sialib._attest_rows
        original_matches = self.sialib._chain_generation_matches
        swaps = []

        def swap_only_while_tailing(*args, **kwargs):
            os.replace(ledger, verified_hold)
            os.replace(forged, ledger)
            swaps.append(True)
            try:
                return original_attest_rows(*args, **kwargs)
            finally:
                os.replace(ledger, forged)
                os.replace(verified_hold, ledger)

        def isolate_consumed_generation(record, *, rebind=True):
            if record["path"] == ledger:
                return True
            return original_matches(record, rebind=rebind)

        with mock.patch.object(
                self.sialib, "_chain_cmds",
                return_value={"sekhmet": binding}), \
                mock.patch.object(
                    self.sialib, "_attest_rows",
                    side_effect=swap_only_while_tailing), \
                mock.patch.object(
                    self.sialib, "_chain_generation_matches",
                    side_effect=isolate_consumed_generation):
            events = self.sialib.sense_sekhmet(cursors)

        self.assertEqual(swaps, [True])
        self.assertEqual(len(events), 1)
        self.assertIn("verified-unit", events[0].summary)
        self.assertNotIn("forged-", events[0].summary)
        self.assertEqual(cursors["sekhmet.lines"], 1)
        self.assertEqual(
            cursors["sekhmet.lines.inode"], os.stat(ledger).st_ino)
        with open(ledger, encoding="utf-8") as stream:
            self.assertEqual(stream.read(), verified_row)
        with open(forged, encoding="utf-8") as stream:
            self.assertEqual(stream.read(), forged_rows)


class CorpusOriginLabels(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.sialib = _load("sialib_corpus_origins",
                            os.path.join(BIN, "sialib.py"))
        self.sialib.CORPUS = self.temp.name

    def tearDown(self):
        self.temp.cleanup()

    def _page(self, slug, frontmatter):
        path = os.path.join(self.temp.name, slug + ".md")
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w") as stream:
            stream.write(f"---\n{frontmatter}\n---\nbody\n")

    def test_declared_origins_win_and_legacy_is_conservative(self):
        self._page("thoughts/model", "type: thought\norigin: model")
        self._page("thoughts/derived", "type: thought\norigin: derived")
        self._page("thoughts/legacy", "type: thought")
        self._page("events/day", "type: event-day")
        self._page("thoughts/invalid", "type: thought\norigin: user")
        self._page("events/missing-type", "title: missing")
        self._page("events/duplicate-type",
                   "type: event-day\ntype: thought\norigin: evidence")
        self.assertEqual(self.sialib.corpus_origin("thoughts/model"),
                         "model")
        self.assertEqual(self.sialib.corpus_origin("thoughts/derived"),
                         "derived")
        self.assertEqual(self.sialib.corpus_origin("thoughts/legacy"),
                         "legacy-unlabeled")
        self.assertEqual(self.sialib.corpus_origin("events/day"),
                         "evidence")
        self.assertEqual(self.sialib.corpus_origin("thoughts/invalid"),
                         "legacy-unlabeled")
        self.assertEqual(self.sialib.corpus_origin("events/missing-type",
                                                  "event-day"),
                         "legacy-unlabeled")
        self.assertEqual(self.sialib.corpus_origin("events/duplicate-type",
                                                  "event-day"),
                         "legacy-unlabeled")

    def test_unlabeled_origin_requires_matching_namespace_and_type(self):
        expected = (
            ("sia/cortex", "organ", "evidence"),
            ("organs/journal", "organ", "evidence"),
            ("events/journal/day", "event-day", "evidence"),
            ("epochs/journal/week", "epoch", "evidence"),
            ("units/example", "unit", "evidence"),
            ("packages/example", "package", "evidence"),
            ("projects/example", "project", "evidence"),
            ("skills/example", "skill", "evidence"),
            ("intents/example", "intent", "evidence"),
            ("synthesis/example", "synthesis", "model"),
            ("notes/example", "note", "model"),
            ("thoughts/example", "thought", "legacy-unlabeled"),
            ("takes/example", "take", "legacy-unlabeled"),
        )
        for slug, page_type, origin in expected:
            with self.subTest(slug=slug):
                self._page(slug, f"type: {page_type}")
                self.assertEqual(self.sialib.corpus_origin(slug), origin)

        mismatches = (
            ("unknown/page", "alien"),
            ("unknown/event", "event-day"),
            ("events/wrong-type", "unit"),
            ("sia/not-cortex", "organ"),
        )
        for slug, page_type in mismatches:
            with self.subTest(slug=slug):
                self._page(slug, f"type: {page_type}")
                self.assertEqual(
                    self.sialib.corpus_origin(slug), "legacy-unlabeled")

        self._page(
            "custom/declared", "type: alien\norigin: evidence")
        self.assertEqual(
            self.sialib.corpus_origin("custom/declared"), "evidence")

    def test_legacy_jackal_pages_are_non_evidence_and_false_prose_is_inert(self):
        self._page(
            "events/jackal/2026-08-30",
            "type: event-day\norigin: evidence\ntags: [formal-receipt]")
        self._page(
            "events/jackal/2026-08-31",
            "type: event-day\norigin: derived\n"
            "tags: [unverified-observation]")
        self._page(
            "epochs/jackal/2026-w35",
            "type: epoch\norigin: evidence\ntags: [formal-receipt]")
        self._page(
            "thoughts/legacy-formal",
            "type: thought\norigin: derived")
        thought = os.path.join(
            self.temp.name, "thoughts", "legacy-formal.md")
        with open(thought, "a", encoding="utf-8") as stream:
            stream.write(
                "JACKAL retained a formal receipt today — Lean-checked "
                "mathematics entered my memory.\n")
        self.assertEqual(
            self.sialib.corpus_origin("events/jackal/2026-08-30"),
            "derived")
        self.assertEqual(self.sialib.siamind.origin_class(
            "events/jackal/2026-08-30", "event-day", "evidence"),
            "derived")
        self.assertEqual(
            self.sialib.corpus_origin("epochs/jackal/2026-w35"),
            "derived")
        for slug in ("events/jackal/2026-08-30",
                     "epochs/jackal/2026-w35",
                     "thoughts/legacy-formal"):
            rendered = self.sialib.neutralize_unverified_jackal_recall(
                slug, "apparently formal")
            self.assertEqual(
                rendered, self.sialib.UNVERIFIED_JACKAL_RECALL_NOTICE)
            self.assertNotIn("Lean-checked", rendered)
        self.assertEqual(
            self.sialib.neutralize_unverified_jackal_recall(
                "events/jackal/2026-08-31",
                "unverified result record observed"),
            "unverified result record observed")

    def test_linked_parent_cannot_supply_origin(self):
        outside = os.path.join(self.temp.name, "outside")
        os.makedirs(outside)
        with open(os.path.join(outside, "page.md"), "w") as stream:
            stream.write("---\ntype: thought\norigin: evidence\n---\n")
        os.symlink(outside, os.path.join(self.temp.name, "linked"))
        self.assertEqual(self.sialib.corpus_origin("linked/page"),
                         "legacy-unlabeled")


class EvidenceCursorHealth(unittest.TestCase):
    def setUp(self):
        self.sialib = _load("sialib_cursor_health",
                            os.path.join(BIN, "sialib.py"))
        self.journal_commands = []

    def _journal_process(self, producer, *, returncode=0,
                         cursor_bytes=b"next-cursor", metadata=None):
        real_popen = subprocess.Popen

        def launch(cmd, **kwargs):
            self.journal_commands.append(list(cmd))
            cursor_args = [
                arg for arg in cmd if arg.startswith("--cursor-file=")]
            cursor_path = (cursor_args[0].split("=", 1)[1]
                           if cursor_args else None)
            cursor_write = (
                "" if cursor_path is None or cursor_bytes is None else
                f"open({cursor_path!r}, 'wb').write({cursor_bytes!r})\n")
            selected = producer
            if "--output-fields=__CURSOR" in cmd:
                selected = (metadata if metadata is not None else
                            producer if cursor_bytes is None else
                            "os.write(1, b'{\"__CURSOR\":"
                            "\"next-cursor\"}\\n')")
            program = (
                "import os,sys,time\n"
                f"{cursor_write}"
                f"{selected}\n"
                f"sys.exit({returncode!r})\n")
            return real_popen([sys.executable, "-c", program], **kwargs)

        return mock.patch.object(
            self.sialib.subprocess, "Popen", side_effect=launch)

    def test_cursor_state_missing_bootstraps_but_damage_refuses(self):
        with tempfile.TemporaryDirectory() as state:
            old_path = self.sialib.CURSORS_PATH
            self.sialib.CURSORS_PATH = os.path.join(state, "cursors.json")
            try:
                self.assertEqual(self.sialib.load_cursors(), {})
                with open(self.sialib.CURSORS_PATH, "w") as stream:
                    stream.write("{broken")
                with self.assertRaisesRegex(RuntimeError, "malformed"):
                    self.sialib.load_cursors()
                os.unlink(self.sialib.CURSORS_PATH)
                target = os.path.join(state, "target.json")
                with open(target, "w") as stream:
                    stream.write("{}")
                os.symlink(target, self.sialib.CURSORS_PATH)
                with self.assertRaisesRegex(RuntimeError, "safely"):
                    self.sialib.load_cursors()
            finally:
                self.sialib.CURSORS_PATH = old_path

    def test_cursor_state_refuses_a_path_replaced_during_decode(self):
        with tempfile.TemporaryDirectory() as state:
            cursor_path = os.path.join(state, "cursors.json")
            replacement = os.path.join(state, "replacement.json")
            with open(cursor_path, "w", encoding="utf-8") as stream:
                json.dump({"generation": "opened"}, stream)
            with open(replacement, "w", encoding="utf-8") as stream:
                json.dump({"generation": "named"}, stream)
            strict_loads = self.sialib._strict_json_loads

            def replace_while_decoding(raw):
                os.replace(replacement, cursor_path)
                return strict_loads(raw)

            with mock.patch.object(
                    self.sialib, "_strict_json_loads",
                    side_effect=replace_while_decoding), \
                    self.assertRaisesRegex(
                        RuntimeError, "changed while read"):
                self.sialib.read_state_json(
                    cursor_path, {}, "evidence cursor")

    def test_cursor_state_refuses_a_hardlinked_authority(self):
        with tempfile.TemporaryDirectory() as state:
            cursor_path = os.path.join(state, "cursors.json")
            alias_path = os.path.join(state, "cursor-alias.json")
            with open(cursor_path, "w", encoding="utf-8") as stream:
                json.dump({"generation": "linked"}, stream)
            os.link(cursor_path, alias_path)
            with self.assertRaisesRegex(
                    RuntimeError, "single-link regular file"):
                self.sialib.read_state_json(
                    cursor_path, {}, "evidence cursor")

    def test_cursor_writer_refuses_nonfinite_state_without_replacing_prior(self):
        with tempfile.TemporaryDirectory() as state:
            old_path = self.sialib.CURSORS_PATH
            self.sialib.CURSORS_PATH = os.path.join(state, "cursors.json")
            prior = '{"stable":true}\n'
            with open(self.sialib.CURSORS_PATH, "w", encoding="utf-8") \
                    as stream:
                stream.write(prior)
            try:
                for value in (
                        float("nan"), float("inf"), float("-inf")):
                    with self.subTest(value=value), self.assertRaises(
                            ValueError):
                        self.sialib.save_cursors({"poison": value})
                    with open(self.sialib.CURSORS_PATH, encoding="utf-8") \
                            as stream:
                        self.assertEqual(stream.read(), prior)
            finally:
                self.sialib.CURSORS_PATH = old_path

    def test_negative_line_and_byte_cursors_refuse_without_advancing(self):
        with tempfile.NamedTemporaryFile(mode="w", delete=False) as stream:
            stream.write("first\nsecond\nthird\n")
            path = stream.name
        try:
            for cursor, reader in (({"line": -1}, self.sialib.tail_lines),
                                   ({"byte": -1}, self.sialib.tail_bytes)):
                key = next(iter(cursor))
                with self.assertRaisesRegex(ValueError, "cursor"):
                    reader(path, cursor, key)
                self.assertEqual(cursor[key], -1)
        finally:
            os.unlink(path)

    def test_journal_failure_never_queues_cursor_rename(self):
        with tempfile.TemporaryDirectory() as state:
            cursor = os.path.join(state, "journal.cursor")
            old_pending = list(self.sialib.PENDING_CURSOR_RENAMES)
            self.sialib.PENDING_CURSOR_RENAMES.clear()
            try:
                with self._journal_process(
                        "os.write(2, b'denied')", returncode=1):
                    with self.assertRaisesRegex(RuntimeError, "refused"):
                        self.sialib._journalctl(["-n", "0"], cursor)
                self.assertEqual(self.sialib.PENDING_CURSOR_RENAMES, [])
                self.assertFalse(os.path.lexists(cursor + ".pulse"))
            finally:
                self.sialib.PENDING_CURSOR_RENAMES[:] = old_pending

    def test_journal_newline_free_overflow_binds_cursor_refusal(self):
        with tempfile.TemporaryDirectory() as state:
            cursor = os.path.join(state, "journal.cursor")
            with open(cursor, "wb") as stream:
                stream.write(b"old-cursor")
            with self._journal_process("os.write(1, b'x' * 32)"), \
                    mock.patch.object(
                        self.sialib, "MAX_JOURNAL_RECORD_BYTES", 16), \
                    mock.patch.object(
                        self.sialib, "MAX_JOURNAL_OUTPUT_BYTES", 16):
                records, pending, refusals = self.sialib._journalctl(
                    [], cursor)
            self.assertEqual(records, [])
            self.assertEqual(refusals[0]["reason"],
                             "journal-record-over-aggregate")
            self.assertFalse(refusals[0]["complete"])
            with open(cursor, "rb") as stream:
                self.assertEqual(stream.read(), b"old-cursor")
            with open(pending[0], "rb") as stream:
                self.assertEqual(stream.read(), b"next-cursor")
            os.unlink(pending[0])

    def test_journal_vacuum_cannot_rebind_oversized_later_row(self):
        with tempfile.TemporaryDirectory() as state:
            cursor = os.path.join(state, "journal.cursor")
            with open(cursor, "wb") as stream:
                stream.write(b"old-cursor")
            real_popen = subprocess.Popen

            def launch(cmd, **kwargs):
                cursor_args = [
                    arg for arg in cmd if arg.startswith("--cursor-file=")]
                cursor_write = ""
                if cursor_args:
                    cursor_path = cursor_args[0].split("=", 1)[1]
                    cursor_write = (
                        f"open({cursor_path!r}, 'wb').write(b'cursor-B')\n")
                if "--cursor=cursor-A" in cmd:
                    # A was vacuumed between the catalog and full pass; an
                    # exact query can no longer bind the poison row to A.
                    payload = b'{"__CURSOR":"cursor-B"}\n'
                elif "--output-fields=__CURSOR" in cmd:
                    payload = (
                        b'{"__CURSOR":"cursor-A"}\n'
                        b'{"__CURSOR":"cursor-B"}\n')
                else:
                    payload = (
                        b'{"MESSAGE":"' + b'x' * 64
                        + b'","__CURSOR":"cursor-B"}\n')
                program = (
                    "import os\n" + cursor_write
                    + f"os.write(1, {payload!r})\n")
                return real_popen(
                    [sys.executable, "-c", program], **kwargs)

            with mock.patch.object(
                    self.sialib.subprocess, "Popen", side_effect=launch), \
                    mock.patch.object(
                        self.sialib, "MAX_JOURNAL_RECORD_BYTES", 16), \
                    mock.patch.object(
                        self.sialib, "MAX_JOURNAL_OUTPUT_BYTES", 16):
                with self.assertRaisesRegex(
                        RuntimeError, "poison cursor changed"):
                    self.sialib._journalctl([], cursor)
            with open(cursor, "rb") as stream:
                self.assertEqual(stream.read(), b"old-cursor")
            self.assertFalse(os.path.lexists(cursor + ".pulse"))

    def test_journal_huge_complete_row_signably_advances_one_cursor(self):
        with tempfile.TemporaryDirectory() as state:
            cursor = os.path.join(state, "journal.cursor")
            with open(cursor, "wb") as stream:
                stream.write(b"old-cursor")
            producer = (
                "os.write(1, b'{\"MESSAGE\":\"' + b'x' * 32 + "
                "b'\",\"__CURSOR\":\"next-cursor\"}\\n')")
            with self._journal_process(producer), \
                    mock.patch.object(
                        self.sialib, "MAX_JOURNAL_RECORD_BYTES", 16), \
                    mock.patch.object(
                        self.sialib, "MAX_JOURNAL_OUTPUT_BYTES", 128):
                records, pending, refusals = self.sialib._journalctl(
                    [], cursor)
            self.assertEqual(records, [])
            self.assertEqual(refusals[0]["reason"],
                             "journal-record-over-bound")
            self.assertTrue(refusals[0]["complete"])
            with open(cursor, "rb") as stream:
                self.assertEqual(stream.read(), b"old-cursor")
            with open(pending[0], "rb") as stream:
                self.assertEqual(stream.read(), b"next-cursor")
            os.unlink(pending[0])

    def test_journal_poison_refusal_retries_then_signs_before_cursor(self):
        with tempfile.TemporaryDirectory() as state:
            old_state = self.sialib.STATE
            old_cursors_path = self.sialib.CURSORS_PATH
            old_pending = list(self.sialib.PENDING_CURSOR_RENAMES)
            self.sialib.STATE = state
            self.sialib.CURSORS_PATH = os.path.join(state, "cursors.json")
            self.sialib.PENDING_CURSOR_RENAMES.clear()
            for scope in ("sys", "user"):
                with open(os.path.join(state, f"journal-{scope}.cursor"),
                          "wb") as stream:
                    stream.write(b"old-cursor")
            producer = (
                "os.write(1, b'{\"MESSAGE\":\"' + b'x' * 32 + "
                "b'\",\"__CURSOR\":\"next-cursor\"}\\n')")
            try:
                first_trial = {}
                with self._journal_process(producer), mock.patch.object(
                        self.sialib, "MAX_JOURNAL_RECORD_BYTES", 16), \
                        mock.patch.object(
                            self.sialib, "MAX_JOURNAL_OUTPUT_BYTES", 128):
                    self.assertEqual(
                        self.sialib.sense_journal(first_trial), [])
                first = self.sialib._take_source_record_refusals(
                    first_trial)
                self.sialib._discard_pending_cursor_renames()
                for scope in ("sys", "user"):
                    with open(os.path.join(
                            state, f"journal-{scope}.cursor"), "rb") as stream:
                        self.assertEqual(stream.read(), b"old-cursor")

                retry_trial = {}
                with self._journal_process(producer), mock.patch.object(
                        self.sialib, "MAX_JOURNAL_RECORD_BYTES", 16), \
                        mock.patch.object(
                            self.sialib, "MAX_JOURNAL_OUTPUT_BYTES", 128):
                    self.sialib.sense_journal(retry_trial)
                retry = self.sialib._take_source_record_refusals(
                    retry_trial)
                self.assertEqual(first, retry)
                with mock.patch.object(
                        self.sialib, "durable_ledger_append") as append:
                    self.sialib._settle_source_record_refusals(
                        "sense_journal", retry)
                self.assertEqual(append.call_count, 2)
                rename_errors, save_error = \
                    self.sialib._commit_sense_cursors(retry_trial)
                self.assertEqual(rename_errors, [])
                self.assertIsNone(save_error)
                for scope in ("sys", "user"):
                    with open(os.path.join(
                            state, f"journal-{scope}.cursor"), "rb") as stream:
                        self.assertEqual(stream.read(), b"next-cursor")
            finally:
                self.sialib._discard_pending_cursor_renames()
                self.sialib.STATE = old_state
                self.sialib.CURSORS_PATH = old_cursors_path
                self.sialib.PENDING_CURSOR_RENAMES[:] = old_pending

    def test_journal_aggregate_budget_commits_only_valid_prefix(self):
        with tempfile.TemporaryDirectory() as state:
            cursor = os.path.join(state, "journal.cursor")
            with open(cursor, "wb") as stream:
                stream.write(b"old-cursor")
            rows = [(json.dumps({"MESSAGE": f"row-{index}",
                                 "__CURSOR": f"cursor-{index}"},
                                separators=(",", ":")) + "\n").encode()
                    for index in range(3)]
            metadata_rows = [(json.dumps(
                {"__CURSOR": f"cursor-{index}"}, separators=(",", ":"))
                              + "\n").encode() for index in range(3)]
            producer = f"os.write(1, {b''.join(rows)!r})"
            metadata = f"os.write(1, {b''.join(metadata_rows)!r})"
            budget = sum(len(row) for row in rows[:2])
            with self._journal_process(producer, metadata=metadata), \
                    mock.patch.object(
                        self.sialib, "MAX_JOURNAL_RECORD_BYTES", 128), \
                    mock.patch.object(
                        self.sialib, "MAX_JOURNAL_OUTPUT_BYTES", budget):
                records, pending, refusals = self.sialib._journalctl(
                    [], cursor)
            self.assertEqual([row["MESSAGE"] for row in records],
                             ["row-0", "row-1"])
            self.assertEqual(refusals, [])
            with open(cursor, "rb") as stream:
                self.assertEqual(stream.read(), b"old-cursor")
            with open(pending[0], "rb") as stream:
                self.assertEqual(stream.read(), b"cursor-1")
            os.unlink(pending[0])

    def test_journal_unterminated_valid_json_never_advances_cursor(self):
        with tempfile.TemporaryDirectory() as state:
            cursor = os.path.join(state, "journal.cursor")
            with open(cursor, "wb") as stream:
                stream.write(b"old-cursor")
            with self._journal_process("os.write(1, b'{}')"):
                with self.assertRaisesRegex(RuntimeError, "unterminated"):
                    self.sialib._journalctl([], cursor)
            with open(cursor, "rb") as stream:
                self.assertEqual(stream.read(), b"old-cursor")
            self.assertFalse(os.path.lexists(cursor + ".pulse"))

    def test_journal_success_returns_only_complete_records_and_temp_cursor(self):
        with tempfile.TemporaryDirectory() as state:
            cursor = os.path.join(state, "journal.cursor")
            with open(cursor, "wb") as stream:
                stream.write(b"old-cursor")
            producer = (
                "os.write(1, b'{\"MESSAGE\":\"ok\","
                "\"__CURSOR\":\"next-cursor\"}\\n')")
            with self._journal_process(producer):
                records, pending, refusals = self.sialib._journalctl(
                    [], cursor)
            self.assertEqual(records, [{
                "MESSAGE": "ok", "__CURSOR": "next-cursor"}])
            self.assertEqual(refusals, [])
            self.assertEqual(pending, (cursor + ".pulse", cursor))
            with open(cursor, "rb") as stream:
                self.assertEqual(stream.read(), b"old-cursor")
            with open(cursor + ".pulse", "rb") as stream:
                self.assertEqual(stream.read(), b"next-cursor")

    def test_journal_timeout_kills_process_and_retains_cursor(self):
        with tempfile.TemporaryDirectory() as state:
            cursor = os.path.join(state, "journal.cursor")
            with open(cursor, "wb") as stream:
                stream.write(b"old-cursor")
            with self._journal_process("time.sleep(2)"), \
                    mock.patch.object(
                        self.sialib, "JOURNAL_TIMEOUT_SECONDS", 0.05):
                with self.assertRaisesRegex(RuntimeError, "timed out"):
                    self.sialib._journalctl([], cursor)
            with open(cursor, "rb") as stream:
                self.assertEqual(stream.read(), b"old-cursor")
            self.assertFalse(os.path.lexists(cursor + ".pulse"))

    def test_journal_timeout_kills_descendant_after_parent_exit(self):
        with tempfile.TemporaryDirectory() as state:
            cursor = os.path.join(state, "journal.cursor")
            pid_file = os.path.join(state, "descendant.pid")
            with open(cursor, "wb") as stream:
                stream.write(b"old-cursor")
            producer = (
                "import subprocess; "
                "child=subprocess.Popen([sys.executable,'-c',"
                "'import time; time.sleep(60)']); "
                f"open({pid_file!r},'w').write(str(child.pid)); "
                "sys.exit(0)")
            with self._journal_process(producer), \
                    mock.patch.object(
                        self.sialib, "JOURNAL_TIMEOUT_SECONDS", 0.05):
                with self.assertRaisesRegex(RuntimeError, "timed out"):
                    self.sialib._journalctl([], cursor)
            with open(cursor, "rb") as stream:
                self.assertEqual(stream.read(), b"old-cursor")
            self.assertFalse(os.path.lexists(cursor + ".pulse"))
            with open(pid_file, encoding="utf-8") as stream:
                child_pid = int(stream.read())
            deadline = time.monotonic() + 2
            alive = True
            while time.monotonic() < deadline:
                try:
                    with open(f"/proc/{child_pid}/stat",
                              encoding="utf-8") as stream:
                        status = stream.read().split()[2]
                except FileNotFoundError:
                    alive = False
                    break
                if status == "Z":
                    alive = False
                    break
                time.sleep(0.01)
            self.assertFalse(alive, "journal descendant survived group kill")

    def test_journal_seed_cursor_is_bounded_and_no_follow(self):
        with tempfile.TemporaryDirectory() as state:
            cursor = os.path.join(state, "journal.cursor")
            with open(cursor, "wb") as stream:
                stream.write(b"oversized")
            with mock.patch.object(
                    self.sialib, "MAX_JOURNAL_CURSOR_BYTES", 4), \
                    mock.patch.object(
                        self.sialib.subprocess, "Popen",
                        side_effect=AssertionError(
                            "bounded cursor fixture launched a child")) as launch:
                with self.assertRaisesRegex(RuntimeError, "bounded"):
                    self.sialib._journalctl([], cursor)
                launch.assert_not_called()
            os.unlink(cursor)
            target = os.path.join(state, "target")
            with open(target, "wb") as stream:
                stream.write(b"cursor")
            os.symlink(target, cursor)
            with mock.patch.object(
                    self.sialib.subprocess, "Popen",
                    side_effect=AssertionError(
                        "no-follow cursor fixture launched a child")) as launch:
                with self.assertRaises(OSError):
                    self.sialib._journalctl([], cursor)
                launch.assert_not_called()
            self.assertFalse(os.path.lexists(cursor + ".pulse"))

    def test_journal_catalog_allows_cursor_at_string_bound(self):
        with tempfile.TemporaryDirectory() as state:
            cursor = os.path.join(state, "journal.cursor")
            cursor_bytes = b"at-bound"
            with open(cursor, "wb") as stream:
                stream.write(cursor_bytes)
            row = json.dumps({
                "MESSAGE": "ok", "__CURSOR": cursor_bytes.decode(),
            }, separators=(",", ":")).encode() + b"\n"
            metadata_row = json.dumps({
                "__CURSOR": cursor_bytes.decode(),
            }, separators=(",", ":")).encode() + b"\n"
            with self._journal_process(
                    f"os.write(1, {row!r})",
                    cursor_bytes=cursor_bytes,
                    metadata=f"os.write(1, {metadata_row!r})"), \
                    mock.patch.object(
                        self.sialib, "MAX_JOURNAL_CURSOR_BYTES",
                        len(cursor_bytes)):
                records, pending, refusals = self.sialib._journalctl(
                    [], cursor)
            self.assertEqual(records, [{
                "MESSAGE": "ok", "__CURSOR": cursor_bytes.decode(),
            }])
            self.assertEqual(refusals, [])
            with open(pending[0], "rb") as stream:
                self.assertEqual(stream.read(), cursor_bytes)
            os.unlink(pending[0])

    def test_fresh_nonempty_journal_discards_newest_baseline_row(self):
        with tempfile.TemporaryDirectory() as state:
            old_state = self.sialib.STATE
            old_pending = list(self.sialib.PENDING_CURSOR_RENAMES)
            self.sialib.STATE = state
            self.sialib.PENDING_CURSOR_RENAMES.clear()
            producer = (
                "os.write(1, b'{\"MESSAGE\":\"historical\","
                "\"__CURSOR\":\"baseline\"}\\n')")
            try:
                with self._journal_process(producer):
                    events = self.sialib.sense_journal({})
                self.assertEqual(events, [])
                self.assertEqual(len(self.sialib.PENDING_CURSOR_RENAMES), 2)
                for command in self.journal_commands:
                    self.assertIn("1", command)
                    self.assertNotIn("+300", command)
                for tmp, real in self.sialib.PENDING_CURSOR_RENAMES:
                    self.assertFalse(os.path.lexists(real))
                    with open(tmp, "rb") as stream:
                        self.assertEqual(stream.read(), b"next-cursor")
            finally:
                self.sialib._discard_pending_cursor_renames()
                self.sialib.STATE = old_state
                self.sialib.PENDING_CURSOR_RENAMES[:] = old_pending

    def test_fresh_empty_journal_persists_empty_cursor_then_reads_future(self):
        with tempfile.TemporaryDirectory() as state:
            old_state = self.sialib.STATE
            old_cursors_path = self.sialib.CURSORS_PATH
            old_pending = list(self.sialib.PENDING_CURSOR_RENAMES)
            self.sialib.STATE = state
            self.sialib.CURSORS_PATH = os.path.join(state, "cursors.json")
            self.sialib.PENDING_CURSOR_RENAMES.clear()
            try:
                with self._journal_process("pass", cursor_bytes=None):
                    self.assertEqual(self.sialib.sense_journal({}), [])
                rename_errors, save_error = \
                    self.sialib._commit_sense_cursors({})
                self.assertEqual(rename_errors, [])
                self.assertIsNone(save_error)
                for scope in ("sys", "user"):
                    real = os.path.join(
                        state, f"journal-{scope}.cursor")
                    with open(real, "rb") as stream:
                        self.assertEqual(stream.read(), b"")

                self.journal_commands.clear()
                producer = (
                    "os.write(1, b'{\"MESSAGE\":\"future\","
                    "\"__CURSOR\":\"next-cursor\"}\\n')")
                with self._journal_process(producer):
                    events = self.sialib.sense_journal({})
                self.assertEqual(len(events), 2)
                self.assertTrue(all("future" in event.summary
                                    for event in events))
                self.assertTrue(all("+300" in command
                                    for command in self.journal_commands))
            finally:
                self.sialib._discard_pending_cursor_renames()
                self.sialib.STATE = old_state
                self.sialib.CURSORS_PATH = old_cursors_path
                self.sialib.PENDING_CURSOR_RENAMES[:] = old_pending

    def test_journal_backlog_requests_oldest_pending_batch(self):
        with tempfile.TemporaryDirectory() as state:
            old_state = self.sialib.STATE
            old_pending = list(self.sialib.PENDING_CURSOR_RENAMES)
            self.sialib.STATE = state
            self.sialib.PENDING_CURSOR_RENAMES.clear()
            for scope in ("sys", "user"):
                with open(os.path.join(state, f"journal-{scope}.cursor"),
                          "w") as stream:
                    stream.write("cursor")
            calls = []

            def capture(args, cursor_file, **_kwargs):
                calls.append(list(args))
                return [], (cursor_file + ".pulse", cursor_file), []

            try:
                with mock.patch.object(self.sialib, "_journalctl",
                                       side_effect=capture):
                    self.sialib.sense_journal({})
                self.assertTrue(calls)
                for args in calls:
                    self.assertIn("+300", args)
                    self.assertNotIn("300", args)
            finally:
                self.sialib.STATE = old_state
                self.sialib.PENDING_CURSOR_RENAMES[:] = old_pending

    def test_custom_jsonl_bad_row_is_bound_and_later_row_is_reachable(self):
        with tempfile.NamedTemporaryFile(mode="w", delete=False) as stream:
            stream.write("[]\n{bad json\n{\"message\":\"later\"}\n")
            path = stream.name
        old_config = self.sialib.CONFIG
        cursors = {"custom.fixture": 0}
        self.sialib.CONFIG = {"custom_senses": [{
            "name": "fixture", "path": path, "type": "jsonl",
            "field": "message", "kind": "event", "tags": []}]}
        try:
            events, errors = self.sialib.sense_custom(cursors)
            self.assertEqual(events, [])
            self.assertEqual(errors, [])
            first = self.sialib._take_source_record_refusals(cursors)
            self.assertEqual(first[0]["reason"],
                             "non-object-json-record")
            self.assertEqual(first[0]["ordinal"], 0)
            events, errors = self.sialib.sense_custom(cursors)
            self.assertEqual((events, errors), ([], []))
            second = self.sialib._take_source_record_refusals(cursors)
            self.assertEqual(second[0]["reason"],
                             "malformed-json-record")
            self.assertEqual(second[0]["ordinal"], 1)
            events, errors = self.sialib.sense_custom(cursors)
            self.assertEqual(errors, [])
            self.assertEqual([event.summary for event in events], ["later"])
            self.assertEqual(cursors["custom.fixture"], 3)
        finally:
            self.sialib.CONFIG = old_config
            os.unlink(path)

    def test_custom_jsonl_refuses_ambiguous_and_nonstandard_records(self):
        private = "private-value-must-not-be-selected"
        with tempfile.NamedTemporaryFile(mode="w", delete=False) as stream:
            stream.write(
                '{"message":"safe","message":"' + private + '"}\n')
            stream.write('{"message":NaN}\n')
            stream.write('{"message":"reachable"}\n')
            path = stream.name
        old_config = self.sialib.CONFIG
        cursors = {"custom.fixture": 0}
        self.sialib.CONFIG = {"custom_senses": [{
            "name": "fixture", "path": path, "type": "jsonl",
            "field": "message", "kind": "event", "tags": []}]}
        try:
            for ordinal in range(2):
                events, errors = self.sialib.sense_custom(cursors)
                self.assertEqual((events, errors), ([], []))
                refusal = self.sialib._take_source_record_refusals(cursors)
                self.assertEqual(refusal[0]["reason"],
                                 "malformed-json-record")
                self.assertEqual(refusal[0]["ordinal"], ordinal)
                self.assertNotIn(private, json.dumps(
                    refusal, sort_keys=True))
            events, errors = self.sialib.sense_custom(cursors)
            self.assertEqual(errors, [])
            self.assertEqual([event.summary for event in events],
                             ["reachable"])
        finally:
            self.sialib.CONFIG = old_config
            os.unlink(path)

    def test_custom_sense_unknown_key_refuses_without_reading(self):
        private = "SHOULD-NOT-BE-INGESTED"
        with tempfile.NamedTemporaryFile(mode="w", delete=False) as stream:
            stream.write(private + "\n")
            path = stream.name
        old_config = self.sialib.CONFIG
        cursors = {"custom.disabled-source": 0}
        self.sialib.CONFIG = {"custom_senses": [{
            "_comment": "mistyped disable must remain inert",
            "name": "disabled-source", "organ": "should-be-inert",
            "path": path, "enable": False,
        }]}
        try:
            self.assertNotIn("should-be-inert", self.sialib._build_organs())
            events, errors, successful = self.sialib.sense_custom(
                cursors, include_sources=True)
            self.assertEqual(events, [])
            self.assertEqual(successful, [])
            self.assertIn("unknown keys", errors[0]["error"])
            self.assertEqual(cursors, {"custom.disabled-source": 0})
            self.assertNotIn(private, json.dumps(errors, sort_keys=True))
        finally:
            self.sialib.CONFIG = old_config
            os.unlink(path)

    def test_disable_policy_gates_custom_name_organ_and_native_collision(self):
        with tempfile.NamedTemporaryFile(mode="w", delete=False) as stream:
            stream.write("PRIVATE-DISABLED-ROW\n")
            path = stream.name
        old_config = self.sialib.CONFIG
        old_errors = copy.deepcopy(self.sialib.CONFIG_ERRORS)
        try:
            cases = (
                ("Custom Source", "custom-organ"),
                ("Custom Organ", "custom-organ"),
                ("journal", "journal"),
            )
            for disabled, organ in cases:
                with self.subTest(disabled=disabled, organ=organ):
                    self.sialib.CONFIG_ERRORS.clear()
                    self.sialib.CONFIG = {
                        "senses": {"disable": [disabled]},
                        "custom_senses": [{
                            "name": "custom-source", "organ": organ,
                            "path": path, "type": "lines",
                        }],
                    }
                    self.assertNotIn(organ, self.sialib._build_organs())
                    cursors = {"unrelated": "retained"}
                    with mock.patch.object(
                            self.sialib, "tail_line_records",
                            side_effect=AssertionError("disabled source read")):
                        events, errors, successful = \
                            self.sialib.sense_custom(
                                cursors, include_sources=True)
                    self.assertEqual((events, errors, successful),
                                     ([], [], []))
                    self.assertEqual(cursors, {"unrelated": "retained"})
        finally:
            self.sialib.CONFIG = old_config
            self.sialib.CONFIG_ERRORS[:] = old_errors
            os.unlink(path)

    def test_custom_organ_registry_uses_the_complete_source_schema(self):
        old_config = self.sialib.CONFIG
        self.sialib.CONFIG = {"custom_senses": [{
            "name": "missing-path",
            "organ": "must-not-activate",
        }]}
        try:
            self.assertNotIn("must-not-activate",
                             self.sialib._build_organs())
            events, errors, successful = self.sialib.sense_custom(
                {}, include_sources=True)
            self.assertEqual(events, [])
            self.assertEqual(successful, [])
            self.assertIn("path must be a non-empty string",
                          errors[0]["error"])
        finally:
            self.sialib.CONFIG = old_config

    def test_custom_jsonl_missing_field_refuses_without_exposing_other_fields(self):
        secret = "unrelated-private-value-must-never-render"
        with tempfile.NamedTemporaryFile(mode="w", delete=False) as stream:
            stream.write(json.dumps({"detail": secret}) + "\n")
            stream.write(json.dumps({"message": "reachable"}) + "\n")
            stream.write(json.dumps({"message": "reachable"}) + "\n")
            path = stream.name
        old_config = self.sialib.CONFIG
        cursors = {"custom.fixture": 0}
        self.sialib.CONFIG = {"custom_senses": [{
            "name": "fixture", "path": path, "type": "jsonl",
            "field": "message", "kind": "event", "tags": []}]}
        try:
            events, errors = self.sialib.sense_custom(cursors)
            self.assertEqual((events, errors), ([], []))
            first = self.sialib._take_source_record_refusals(cursors)
            self.assertEqual(len(first), 1)
            self.assertEqual(first[0]["reason"], "missing-json-field")
            self.assertEqual(first[0]["ordinal"], 0)
            self.assertNotIn(secret, json.dumps(first, sort_keys=True))
            self.assertEqual(cursors["custom.fixture"], 1)
            with mock.patch.object(
                    self.sialib, "durable_ledger_append") as append:
                self.sialib._settle_source_record_refusals(
                    "sense_custom:fixture", first)
            self.assertEqual(
                append.call_args.args[:3],
                ("SOURCE:refuse", "sense_custom:fixture",
                 "missing-json-field"))
            self.assertNotIn(secret, append.call_args.args[3])

            events, errors = self.sialib.sense_custom(cursors)
            self.assertEqual(errors, [])
            self.assertEqual([event.summary for event in events],
                             ["reachable", "reachable"])
            self.assertNotEqual(events[0].occurrence, events[1].occurrence)
            self.assertNotIn(secret, "".join(
                event.summary for event in events))
            self.assertEqual(cursors["custom.fixture"], 3)
            self.assertEqual(
                self.sialib._take_source_record_refusals(cursors), [])
        finally:
            self.sialib.CONFIG = old_config
            os.unlink(path)

    def test_custom_invalid_utf8_refusal_retries_exactly_until_signed(self):
        with tempfile.NamedTemporaryFile(mode="wb", delete=False) as stream:
            stream.write(b"\xff\n{\"message\":\"reachable\"}\n")
            path = stream.name
        old_config = self.sialib.CONFIG
        self.sialib.CONFIG = {"custom_senses": [{
            "name": "fixture", "path": path, "type": "jsonl",
            "field": "message", "kind": "event", "tags": []}]}
        base = {"custom.fixture": 0}
        try:
            first_trial = copy.deepcopy(base)
            first_events, first_errors = self.sialib.sense_custom(
                first_trial)
            first = self.sialib._take_source_record_refusals(first_trial)
            retry_trial = copy.deepcopy(base)
            self.sialib.sense_custom(retry_trial)
            retry = self.sialib._take_source_record_refusals(retry_trial)
            self.assertEqual((first_events, first_errors), ([], []))
            self.assertEqual(first, retry)
            self.assertEqual(first[0]["reason"], "invalid-utf8-record")
            with mock.patch.object(
                    self.sialib, "durable_ledger_append") as append:
                self.sialib._settle_source_record_refusals(
                    "sense_custom:fixture", first)
            self.assertEqual(
                append.call_args.args[:3],
                ("SOURCE:refuse", "sense_custom:fixture",
                 "invalid-utf8-record"))
            events, errors = self.sialib.sense_custom(first_trial)
            self.assertEqual(errors, [])
            self.assertEqual([event.summary for event in events],
                             ["reachable"])
        finally:
            self.sialib.CONFIG = old_config
            os.unlink(path)

    def test_custom_json_parser_limits_refuse_per_physical_row(self):
        deep = ('{"message":' + ('[' * 100000) + '0'
                + (']' * 100000) + '}')
        huge_integer = '{"message":' + ('9' * 5000) + '}'
        with tempfile.NamedTemporaryFile(mode="w", delete=False) as stream:
            stream.write(deep + "\n" + huge_integer
                         + '\n{"message":"reachable"}\n')
            path = stream.name
        old_config = self.sialib.CONFIG
        cursors = {"custom.fixture": 0}
        self.sialib.CONFIG = {"custom_senses": [{
            "name": "fixture", "path": path, "type": "jsonl",
            "field": "message", "kind": "event", "tags": []}]}
        try:
            for ordinal in range(2):
                events, errors = self.sialib.sense_custom(cursors)
                self.assertEqual((events, errors), ([], []))
                refusal = self.sialib._take_source_record_refusals(cursors)
                self.assertEqual(refusal[0]["reason"],
                                 "malformed-json-record")
                self.assertEqual(refusal[0]["ordinal"], ordinal)
            events, errors = self.sialib.sense_custom(cursors)
            self.assertEqual(errors, [])
            self.assertEqual([event.summary for event in events],
                             ["reachable"])
        finally:
            self.sialib.CONFIG = old_config
            os.unlink(path)

    def test_custom_match_refuses_regex_and_literal_alternatives_progress(self):
        with tempfile.NamedTemporaryFile(mode="w", delete=False) as stream:
            stream.write(("a" * 100000) + "!\nERROR reachable\n")
            path = stream.name
        old_config = self.sialib.CONFIG
        cursors = {"custom.fixture": 0}
        try:
            self.sialib.CONFIG = {"custom_senses": [{
                "name": "fixture", "path": path,
                "match": "(a+)+$"}]}
            with mock.patch.object(
                    self.sialib.re, "compile",
                    side_effect=AssertionError("custom regex executed")):
                events, errors = self.sialib.sense_custom(cursors)
            self.assertEqual(events, [])
            self.assertIn("literal alternatives only", errors[0]["error"])
            self.assertEqual(cursors, {"custom.fixture": 0})

            self.sialib.CONFIG = {"custom_senses": [{
                "name": "fixture", "path": path,
                "match": "ERROR|FATAL"}]}
            events, errors = self.sialib.sense_custom(cursors)
            self.assertEqual(errors, [])
            self.assertEqual([event.summary for event in events],
                             ["ERROR reachable"])
        finally:
            self.sialib.CONFIG = old_config
            os.unlink(path)

    def test_custom_exclude_is_literal_bounded_and_preserves_cursor_safety(self):
        with tempfile.NamedTemporaryFile(mode="w", delete=False) as stream:
            stream.write("completed\nFAILED integrity\n")
            path = stream.name
        old_config = self.sialib.CONFIG
        cursors = {"custom.fixture": 0}
        try:
            self.sialib.CONFIG = {"custom_senses": [{
                "name": "fixture", "path": path,
                "exclude": "FAILED|FATAL"}]}
            events, errors = self.sialib.sense_custom(cursors)
            self.assertEqual(errors, [])
            self.assertEqual([event.summary for event in events],
                             ["completed"])

            cursors = {"custom.fixture": 0}
            self.sialib.CONFIG = {"custom_senses": [{
                "name": "fixture", "path": path,
                "exclude": "^(?!.*FAILED)"}]}
            with mock.patch.object(
                    self.sialib.re, "compile",
                    side_effect=AssertionError("custom regex executed")):
                events, errors = self.sialib.sense_custom(cursors)
            self.assertEqual(events, [])
            self.assertIn("literal alternatives only", errors[0]["error"])
            self.assertEqual(cursors, {"custom.fixture": 0})
        finally:
            self.sialib.CONFIG = old_config
            os.unlink(path)

    def test_config_parser_and_shapes_degrade_without_import_crash(self):
        old_errors = copy.deepcopy(self.sialib.CONFIG_ERRORS)
        with tempfile.TemporaryDirectory() as root:
            config_path = os.path.join(root, "config.json")
            old_path = self.sialib.CONFIG_PATH
            self.sialib.CONFIG_PATH = config_path
            try:
                for raw, expected in (
                        ('{"n":' + ("9" * 5000) + "}",
                         "config-invalid-json"),
                        ("[]", "config-must-be-object")):
                    with open(config_path, "w", encoding="utf-8") as stream:
                        stream.write(raw)
                    self.assertEqual(self.sialib.load_config(), {})
                    self.assertEqual(
                        self.sialib.CONFIG_ERRORS[0]["error"],
                        expected)
                with open(config_path, "w", encoding="utf-8") as stream:
                    stream.write("{}")
                with mock.patch.object(
                        self.sialib.json, "loads",
                        side_effect=RecursionError("parser depth")):
                    self.assertEqual(self.sialib.load_config(), {})
                self.assertEqual(
                    self.sialib.CONFIG_ERRORS[0]["error"],
                    "config-invalid-json")
            finally:
                self.sialib.CONFIG_PATH = old_path

        old_config = self.sialib.CONFIG
        try:
            self.sialib.CONFIG_ERRORS.clear()
            malformed = {
                "senses": ["not-an-object"],
                "custom_senses": [
                    "not-an-object",
                    {"name": ["not-a-string"], "path": "/tmp/source"},
                    {"name": "bad-description", "path": "/tmp/source",
                     "description": {"not": "text"}},
                ],
            }
            self.sialib.CONFIG = malformed
            organs = self.sialib._build_organs()
            self.assertTrue(
                (set(self.sialib.BASE_ORGANS)
                 | set(self.sialib.OPTIONAL_ORGANS)).isdisjoint(organs))
            self.assertNotIn("bad-description", organs)
            events, errors, successful = self.sialib.sense_custom(
                {}, include_sources=True)
            self.assertEqual(events, [])
            self.assertEqual(successful, [])
            self.assertTrue(any(
                row["error"] == "senses-must-be-object"
                for row in errors))
            self.assertTrue(all(
                any(fragment in row["error"] for row in errors)
                for fragment in (
                    "configuration entry must be an object",
                    "name must be a non-empty string",
                    "description must be a bounded string")))
        finally:
            self.sialib.CONFIG = old_config
            self.sialib.CONFIG_ERRORS[:] = old_errors

    def test_config_policy_refuses_replaced_or_hardlinked_authority(self):
        old_path = self.sialib.CONFIG_PATH
        old_errors = copy.deepcopy(self.sialib.CONFIG_ERRORS)
        with tempfile.TemporaryDirectory() as root:
            config_path = os.path.join(root, "config.json")
            replacement = os.path.join(root, "replacement.json")
            self.sialib.CONFIG_PATH = config_path
            try:
                with open(config_path, "w", encoding="utf-8") as stream:
                    json.dump({"senses": {"disable": []}}, stream)
                with open(replacement, "w", encoding="utf-8") as stream:
                    json.dump({"senses": {"disable": ["journal"]}}, stream)
                strict_loads = self.sialib._strict_json_loads

                def replace_while_decoding(raw):
                    os.replace(replacement, config_path)
                    return strict_loads(raw)

                with mock.patch.object(
                        self.sialib, "_strict_json_loads",
                        side_effect=replace_while_decoding):
                    self.assertEqual(self.sialib.load_config(), {})
                self.assertEqual(
                    self.sialib.CONFIG_ERRORS[0]["error"],
                    "config-changed-or-over-bound")

                alias = os.path.join(root, "config-alias.json")
                os.link(config_path, alias)
                self.assertEqual(self.sialib.load_config(), {})
                self.assertEqual(
                    self.sialib.CONFIG_ERRORS[0]["error"],
                    "config-file-refused")
            finally:
                self.sialib.CONFIG_PATH = old_path
                self.sialib.CONFIG_ERRORS[:] = old_errors

    def test_malformed_disable_policy_cannot_enable_optional_sources(self):
        old_home = self.sialib.HOME
        old_config = self.sialib.CONFIG
        old_errors = copy.deepcopy(self.sialib.CONFIG_ERRORS)
        with tempfile.TemporaryDirectory() as home:
            for relative in (".codex/sessions", ".local/state/jackal"):
                os.makedirs(os.path.join(home, relative))
            self.sialib.HOME = home
            try:
                configs = (
                    {"senses": {"disable": "codex"}},
                    {"senses": {"disable": ["pacman", "codex", 7]}},
                    {"senses": {"disbale": ["custom-source"]}},
                )
                for config in configs:
                    with self.subTest(config=config):
                        self.sialib.CONFIG_ERRORS.clear()
                        self.sialib.CONFIG = {
                            **config,
                            "custom_senses": [{
                                "name": "custom-source",
                                "organ": "custom-organ",
                                "path": "/tmp/private-source",
                            }],
                        }
                        organs = self.sialib._build_organs()
                        self.assertTrue(
                            (set(self.sialib.BASE_ORGANS)
                             | set(self.sialib.OPTIONAL_ORGANS)
                             | {"custom-organ"}).isdisjoint(organs))
                        with mock.patch.object(
                                self.sialib, "tail_line_records",
                                side_effect=AssertionError(
                                    "malformed policy read source")):
                            events, errors, successful = \
                                self.sialib.sense_custom(
                                    {}, include_sources=True)
                        self.assertEqual(events, [])
                        self.assertEqual(successful, [])
                        self.assertTrue(errors)
                        self.assertTrue(self.sialib.CONFIG_ERRORS)
            finally:
                self.sialib.HOME = old_home
                self.sialib.CONFIG = old_config
                self.sialib.CONFIG_ERRORS[:] = old_errors

    def test_fatal_config_load_cannot_activate_optional_sources(self):
        old_home = self.sialib.HOME
        old_path = self.sialib.CONFIG_PATH
        old_config = self.sialib.CONFIG
        old_loaded = self.sialib._LAST_LOADED_CONFIG
        old_valid = self.sialib._LAST_CONFIG_LOAD_VALID
        old_errors = copy.deepcopy(self.sialib.CONFIG_ERRORS)
        with tempfile.TemporaryDirectory() as home:
            config_path = os.path.join(home, "config.json")
            for relative in (".codex/sessions", ".local/state/jackal"):
                os.makedirs(os.path.join(home, relative))
            self.sialib.HOME = home
            self.sialib.CONFIG_PATH = config_path
            try:
                with open(config_path, "w", encoding="utf-8") as stream:
                    stream.write("not-json")
                self.sialib.CONFIG = self.sialib.load_config()

                self.assertFalse(self.sialib._active_config_load_valid())
                config_refusals = [
                    binding for binding in self.sialib._chain_cmds().values()
                    if binding[2]
                    and binding[2][0]
                    == self.sialib.INVALID_CHAIN_SENTINEL
                ]
                self.assertEqual(config_refusals, [("", "", [
                    self.sialib.INVALID_CHAIN_SENTINEL,
                    "active configuration provenance is invalid",
                ])])
                self.assertEqual(
                    self.sialib._configured_skill_root_paths(), [])
                organs = self.sialib._build_organs()
                self.assertTrue(
                    (set(self.sialib.BASE_ORGANS)
                     | set(self.sialib.OPTIONAL_ORGANS)).isdisjoint(organs))

                os.unlink(config_path)
                self.sialib.CONFIG = self.sialib.load_config()
                self.assertTrue(self.sialib._active_config_load_valid())
                defaults = self.sialib._build_organs()
                self.assertIn("codex", defaults)
                self.assertIn("jackal", defaults)
                self.assertIn("skills", defaults)

                with open(config_path, "w", encoding="utf-8") as stream:
                    stream.write("{}")
                self.sialib.CONFIG = self.sialib.load_config()
                self.assertTrue(self.sialib._active_config_load_valid())
                self.assertIn("skills", self.sialib._build_organs())
            finally:
                self.sialib.HOME = old_home
                self.sialib.CONFIG_PATH = old_path
                self.sialib.CONFIG = old_config
                self.sialib._LAST_LOADED_CONFIG = old_loaded
                self.sialib._LAST_CONFIG_LOAD_VALID = old_valid
                self.sialib.CONFIG_ERRORS[:] = old_errors

    def test_unknown_top_level_config_keys_fail_closed(self):
        old_home = self.sialib.HOME
        old_path = self.sialib.CONFIG_PATH
        old_config = self.sialib.CONFIG
        old_loaded = self.sialib._LAST_LOADED_CONFIG
        old_valid = self.sialib._LAST_CONFIG_LOAD_VALID
        old_errors = copy.deepcopy(self.sialib.CONFIG_ERRORS)
        with tempfile.TemporaryDirectory() as home:
            config_path = os.path.join(home, "config.json")
            for relative in (".codex/sessions", ".local/state/jackal"):
                os.makedirs(os.path.join(home, relative))
            self.sialib.HOME = home
            self.sialib.CONFIG_PATH = config_path
            try:
                for malformed in (
                        {"sense": {"disable": ["codex"]}},
                        {"senses": {"disable": ["codex"]},
                         "unexpected": True}):
                    with self.subTest(malformed=malformed):
                        with open(config_path, "w", encoding="utf-8") \
                                as stream:
                            json.dump(malformed, stream)
                        self.sialib.CONFIG = self.sialib.load_config()
                        self.assertEqual(self.sialib.CONFIG, {})
                        self.assertFalse(
                            self.sialib._active_config_load_valid())
                        self.assertEqual(
                            self.sialib.CONFIG_ERRORS,
                            [{"config": "config.json",
                              "error": "config-unknown-key"}])
                        config_refusals = [
                            binding
                            for binding in self.sialib._chain_cmds().values()
                            if binding[2]
                            and binding[2][0]
                            == self.sialib.INVALID_CHAIN_SENTINEL
                        ]
                        self.assertEqual(config_refusals, [("", "", [
                            self.sialib.INVALID_CHAIN_SENTINEL,
                            "active configuration provenance is invalid",
                        ])])
                        organs = self.sialib._build_organs()
                        self.assertTrue(
                            (set(self.sialib.BASE_ORGANS)
                             | set(self.sialib.OPTIONAL_ORGANS))
                            .isdisjoint(organs))

                self.sialib.CONFIG_PATH = os.path.join(
                    REPO, "config.example.json")
                self.sialib.CONFIG = self.sialib.load_config()
                self.assertTrue(self.sialib._active_config_load_valid())
                self.assertEqual(self.sialib.CONFIG_ERRORS, [])
                self.assertEqual(
                    set(self.sialib.CONFIG),
                    self.sialib._CONFIG_TOP_LEVEL_KEYS)
            finally:
                self.sialib.HOME = old_home
                self.sialib.CONFIG_PATH = old_path
                self.sialib.CONFIG = old_config
                self.sialib._LAST_LOADED_CONFIG = old_loaded
                self.sialib._LAST_CONFIG_LOAD_VALID = old_valid
                self.sialib.CONFIG_ERRORS[:] = old_errors

    def test_config_parser_rejects_duplicate_keys_and_constants(self):
        old_errors = copy.deepcopy(self.sialib.CONFIG_ERRORS)
        with tempfile.TemporaryDirectory() as root:
            config_path = os.path.join(root, "config.json")
            old_path = self.sialib.CONFIG_PATH
            self.sialib.CONFIG_PATH = config_path
            try:
                cases = (
                    '{"custom_senses":[],"custom_senses":['
                    '{"name":"accepted","path":"/tmp/private"}]}',
                    '{"custom_senses":[],"_comment":NaN}',
                    '{"custom_senses":[],"_comment":Infinity}',
                    '{"custom_senses":[],"_comment":-Infinity}',
                )
                for raw in cases:
                    with self.subTest(raw=raw):
                        with open(config_path, "w", encoding="utf-8") \
                                as stream:
                            stream.write(raw)
                        self.assertEqual(self.sialib.load_config(), {})
                        self.assertEqual(
                            self.sialib.CONFIG_ERRORS,
                            [{"config": "config.json",
                              "error": "config-invalid-json"}])
            finally:
                self.sialib.CONFIG_PATH = old_path
                self.sialib.CONFIG_ERRORS[:] = old_errors

    def test_over_cap_custom_senses_create_no_registry_or_organ_pages(self):
        old_config = self.sialib.CONFIG
        old_config_path = self.sialib.CONFIG_PATH
        old_loaded = self.sialib._LAST_LOADED_CONFIG
        old_valid = self.sialib._LAST_CONFIG_LOAD_VALID
        old_organs = self.sialib.ORGANS
        old_corpus = self.sialib.CORPUS
        old_errors = copy.deepcopy(self.sialib.CONFIG_ERRORS)
        with tempfile.TemporaryDirectory() as root:
            config_path = os.path.join(root, "config.json")
            corpus = os.path.join(root, "corpus")
            custom = [
                {"name": f"bounded-{index}", "path": "/tmp/source"}
                for index in range(
                    self.sialib.MAX_LEDGER_PENDING_RECORDS + 1)
            ]
            encoded = json.dumps(
                {"custom_senses": custom}, separators=(",", ":"))
            self.assertLessEqual(
                len(encoded.encode()), self.sialib.MAX_CONFIG_BYTES)
            with open(config_path, "w", encoding="utf-8") as stream:
                stream.write(encoded)
            try:
                self.sialib.CONFIG_PATH = config_path
                self.sialib.CONFIG = self.sialib.load_config()
                self.assertIn(
                    {"config": "config.json",
                     "error": "custom-senses-over-bound"},
                    self.sialib.CONFIG_ERRORS)
                organs = self.sialib._build_organs()
                self.assertFalse(any(
                    name.startswith("bounded-") for name in organs))

                self.sialib.ORGANS = organs
                self.sialib.CORPUS = corpus
                with mock.patch.object(
                        self.sialib, "_before_corpus_mutation"):
                    self.sialib.ensure_organs()
                organ_dir = os.path.join(corpus, "organs")
                self.assertFalse(any(
                    name.startswith("bounded-")
                    for name in os.listdir(organ_dir)))
            finally:
                self.sialib.CONFIG = old_config
                self.sialib.CONFIG_PATH = old_config_path
                self.sialib._LAST_LOADED_CONFIG = old_loaded
                self.sialib._LAST_CONFIG_LOAD_VALID = old_valid
                self.sialib.ORGANS = old_organs
                self.sialib.CORPUS = old_corpus
                self.sialib.CONFIG_ERRORS[:] = old_errors

    def test_over_cap_chain_roster_is_one_refusal_without_expansion(self):
        old_config = self.sialib.CONFIG
        old_config_path = self.sialib.CONFIG_PATH
        old_loaded = self.sialib._LAST_LOADED_CONFIG
        old_valid = self.sialib._LAST_CONFIG_LOAD_VALID
        old_errors = copy.deepcopy(self.sialib.CONFIG_ERRORS)
        with tempfile.TemporaryDirectory() as root:
            config_path = os.path.join(root, "config.json")
            configured = [
                {} for _ in range(self.sialib.MAX_CONFIGURED_CHAINS)]
            configured.append({})
            encoded = json.dumps(
                {"chains": configured}, separators=(",", ":"))
            self.assertLessEqual(
                len(encoded.encode()), self.sialib.MAX_CONFIG_BYTES)
            with open(config_path, "w", encoding="utf-8") as stream:
                stream.write(encoded)
            try:
                self.sialib.CONFIG_PATH = config_path
                self.sialib.CONFIG = self.sialib.load_config()
                self.assertIn(
                    {"config": "config.json", "error": "chains-over-bound"},
                    self.sialib.CONFIG_ERRORS)

                registry = self.sialib._chain_cmds()
                refusals = [
                    binding for name, binding in registry.items()
                    if name.startswith("config-error-")]
                self.assertEqual(len(refusals), 1)
                self.assertEqual(
                    refusals[0][2][0], self.sialib.INVALID_CHAIN_SENTINEL)

                at_bound = {
                    name: "pass" for name in
                    ("sia", "custos", "sekhmet", "aegis")}
                at_bound.update({
                    f"configured-{index}": "pass"
                    for index in range(self.sialib.MAX_CONFIGURED_CHAINS)})
                self.assertTrue(self.sialib._status_chains_shape(at_bound))
                at_bound["overflow"] = "pass"
                self.assertFalse(self.sialib._status_chains_shape(at_bound))
            finally:
                self.sialib.CONFIG = old_config
                self.sialib.CONFIG_PATH = old_config_path
                self.sialib._LAST_LOADED_CONFIG = old_loaded
                self.sialib._LAST_CONFIG_LOAD_VALID = old_valid
                self.sialib.CONFIG_ERRORS[:] = old_errors

    def test_memo_json_rejects_ambiguity_and_nonfinite_output(self):
        old_path = self.sialib.MEMO_PATH
        with tempfile.TemporaryDirectory() as root:
            self.sialib.MEMO_PATH = os.path.join(root, "memo.json")
            try:
                for raw in (
                        '{"sync_needed":true,"sync_needed":false}',
                        '{"sync_needed":NaN}',
                        '{"sync_needed":Infinity}',
                        '{"sync_needed":-Infinity}'):
                    with self.subTest(raw=raw):
                        with open(self.sialib.MEMO_PATH, "w") as stream:
                            stream.write(raw)
                        with self.assertRaisesRegex(
                                RuntimeError,
                                "brainstem memo is unreadable or malformed"):
                            self.sialib.load_memo()
                with self.assertRaises(ValueError):
                    self.sialib._memo_text({"sync_needed": float("nan")})
                with open(self.sialib.MEMO_PATH, "wb") as stream:
                    stream.write(
                        '{"sync_needed":true}'.encode("utf-16"))
                with self.assertRaisesRegex(
                        RuntimeError,
                        "brainstem memo is unreadable or malformed"):
                    self.sialib.load_memo()
            finally:
                self.sialib.MEMO_PATH = old_path

    def test_memo_reader_refuses_a_hardlinked_authority(self):
        old_path = self.sialib.MEMO_PATH
        with tempfile.TemporaryDirectory() as root:
            self.sialib.MEMO_PATH = os.path.join(root, "memo.json")
            alias_path = os.path.join(root, "memo-alias.json")
            try:
                with open(self.sialib.MEMO_PATH, "w", encoding="utf-8") \
                        as stream:
                    json.dump({"pulse_seq": 7}, stream)
                os.link(self.sialib.MEMO_PATH, alias_path)
                with self.assertRaisesRegex(
                        RuntimeError, "owned single-link regular file"):
                    self.sialib.load_memo()
            finally:
                self.sialib.MEMO_PATH = old_path

    def test_memo_reader_refuses_a_path_replaced_during_decode(self):
        old_path = self.sialib.MEMO_PATH
        with tempfile.TemporaryDirectory() as root:
            self.sialib.MEMO_PATH = os.path.join(root, "memo.json")
            replacement = os.path.join(root, "replacement.json")
            try:
                with open(self.sialib.MEMO_PATH, "w", encoding="utf-8") \
                        as stream:
                    json.dump({"generation": "opened"}, stream)
                with open(replacement, "w", encoding="utf-8") as stream:
                    json.dump({"generation": "named"}, stream)
                strict_loads = self.sialib._strict_json_loads

                def replace_while_decoding(raw):
                    os.replace(replacement, self.sialib.MEMO_PATH)
                    return strict_loads(raw)

                with mock.patch.object(
                        self.sialib, "_strict_json_loads",
                        side_effect=replace_while_decoding), \
                        self.assertRaisesRegex(
                            RuntimeError, "changed while read"):
                    self.sialib.load_memo()
            finally:
                self.sialib.MEMO_PATH = old_path

    def test_custom_json_surrogate_is_refused_and_next_row_progresses(self):
        with tempfile.NamedTemporaryFile(
                mode="w", encoding="utf-8", delete=False) as stream:
            stream.write('{"message":"\\ud800"}\n')
            stream.write('{"message":"reachable"}\n')
            path = stream.name
        old_config = self.sialib.CONFIG
        old_errors = copy.deepcopy(self.sialib.CONFIG_ERRORS)
        cursors = {"custom.fixture": 0}
        try:
            self.sialib.CONFIG_ERRORS.clear()
            self.sialib.CONFIG = {"custom_senses": [{
                "name": "fixture", "path": path, "type": "jsonl",
                "field": "message"}]}
            events, errors = self.sialib.sense_custom(cursors)
            self.assertEqual((events, errors), ([], []))
            refusal = self.sialib._take_source_record_refusals(cursors)
            self.assertEqual(refusal[0]["reason"],
                             "invalid-utf8-json-field")
            events, errors = self.sialib.sense_custom(cursors)
            self.assertEqual(errors, [])
            self.assertEqual([event.summary for event in events],
                             ["reachable"])
        finally:
            self.sialib.CONFIG = old_config
            self.sialib.CONFIG_ERRORS[:] = old_errors
            os.unlink(path)

    def test_best_effort_json_parser_limits_return_default(self):
        with tempfile.NamedTemporaryFile(mode="w", delete=False) as stream:
            path = stream.name
        try:
            with open(path, "w", encoding="utf-8") as stream:
                stream.write('{"n":' + ("9" * 5000) + "}")
            self.assertEqual(
                self.sialib.read_json(path, {"safe": True}),
                {"safe": True})
            with open(path, "w", encoding="utf-8") as stream:
                stream.write("{}")
            with mock.patch.object(
                    self.sialib.json, "loads",
                    side_effect=RecursionError("parser depth")):
                self.assertEqual(
                    self.sialib.read_json(path, {"safe": True}),
                    {"safe": True})
        finally:
            os.unlink(path)

    def test_best_effort_json_refuses_a_path_replaced_during_decode(self):
        with tempfile.TemporaryDirectory() as state:
            path = os.path.join(state, "status.json")
            replacement = os.path.join(state, "replacement.json")
            with open(path, "w", encoding="utf-8") as stream:
                json.dump({"generation": "opened"}, stream)
            with open(replacement, "w", encoding="utf-8") as stream:
                json.dump({"generation": "named"}, stream)
            strict_loads = self.sialib._strict_json_loads

            def replace_while_decoding(raw):
                os.replace(replacement, path)
                return strict_loads(raw)

            with mock.patch.object(
                    self.sialib, "_strict_json_loads",
                    side_effect=replace_while_decoding):
                self.assertEqual(
                    self.sialib.read_json(path, {"unavailable": True}),
                    {"unavailable": True})

    def test_best_effort_json_refuses_a_hardlinked_snapshot(self):
        with tempfile.TemporaryDirectory() as state:
            path = os.path.join(state, "status.json")
            alias_path = os.path.join(state, "status-alias.json")
            with open(path, "w", encoding="utf-8") as stream:
                json.dump({"generation": "linked"}, stream)
            os.link(path, alias_path)
            self.assertEqual(
                self.sialib.read_json(path, {"unavailable": True}),
                {"unavailable": True})

    def test_authoritative_json_parser_limits_are_named_and_source_free(self):
        with tempfile.TemporaryDirectory() as root:
            corpus = os.path.join(root, "corpus")
            os.makedirs(corpus)
            state_path = os.path.join(root, "state.json")
            inbox_path = os.path.join(root, "inbox.json")
            source_path = os.path.join(root, "source.json")
            memo_path = os.path.join(root, "memo.json")
            recovery_path = os.path.join(root, "recovery.json")
            legacy_path = os.path.join(root, "legacy.json")
            pending_path = os.path.join(root, "pending.json")
            for path, payload in (
                    (state_path, "{}"), (inbox_path, "[]"),
                    (source_path, "{}"), (memo_path, "{}"),
                    (recovery_path, "{}"), (legacy_path, "{}"),
                    (pending_path, "{}")):
                with open(path, "w", encoding="utf-8") as stream:
                    stream.write(payload)
                os.chmod(path, 0o600)
            claim_path = os.path.join(
                root, self.sialib.THOUGHT_RECOVERY_CLAIM_NAME)
            with open(claim_path, "w", encoding="utf-8") as stream:
                stream.write("{}")
            os.chmod(claim_path, 0o600)
            event_id = "a" * 64
            event_path = os.path.join(
                corpus,
                self.sialib._event_index_relative("fixture", event_id))
            os.makedirs(os.path.dirname(event_path))
            with open(event_path, "w", encoding="utf-8") as stream:
                stream.write("{}")

            with mock.patch.object(self.sialib, "CORPUS", corpus), \
                    mock.patch.object(self.sialib, "STATE", root), \
                    mock.patch.object(self.sialib, "MEMO_PATH", memo_path):
                cases = (
                    (lambda: self.sialib.read_state_json(
                        state_path, {}, "cursor"), RuntimeError,
                     "cursor state is unreadable or malformed"),
                    (lambda: self.sialib._read_thought_inbox(inbox_path),
                     ValueError, "thought inbox is malformed"),
                    (lambda: self.sialib._read_bounded_source_json(
                        source_path, "fixture source"), ValueError,
                     "fixture source is malformed"),
                    (self.sialib.load_memo, RuntimeError,
                     "brainstem memo is unreadable or malformed"),
                    (lambda: self.sialib._read_event_index_entry(
                        "fixture", event_id), ValueError,
                     "consolidated event index entry is malformed"),
                    (lambda: self.sialib._read_thought_recovery_record(
                        recovery_path), ValueError,
                     "thought recovery record is malformed"),
                    (self.sialib._read_thought_recovery_claim, ValueError,
                     "thought recovery claim is malformed"),
                    (lambda: self.sialib._read_thought_legacy_index_entry(
                        legacy_path), ValueError,
                     "legacy thought index is malformed"),
                    (lambda: self.sialib._read_pending_record(pending_path),
                     ValueError, "ledger recovery record is malformed"),
                    (lambda: self.sialib._decode_exact_thought_page(
                        "thoughts/fixture", "sia_thought: {}\n"),
                     RuntimeError,
                     "thought recovery metadata is malformed"),
                    (lambda: self.sialib._parse_sia_counts(
                        "{}", "event page"), ValueError,
                     "event page sia_counts is malformed"),
                    (lambda: self.sialib._epoch_json_field(
                        "sia_sources: []", "sia_sources", "epoch page", []),
                     RuntimeError, "epoch page sia_sources is malformed"),
                    (lambda: self.sialib._yaml_scalar('"fixture"'),
                     ValueError, "quoted scalar is malformed"),
                )
                for parser_error in (ValueError, RecursionError):
                    for call, error_type, expected in cases:
                        with self.subTest(parser_error=parser_error.__name__,
                                          expected=expected), \
                                mock.patch.object(
                                    self.sialib.json, "loads",
                                    side_effect=parser_error(
                                        "private source content")), \
                                self.assertRaises(error_type) as raised:
                            call()
                        self.assertEqual(str(raised.exception), expected)

    def test_best_effort_parser_limits_skip_rows_and_expose_truncation(self):
        for parser_error in (ValueError, RecursionError):
            with self.subTest(parser_error=parser_error.__name__), \
                    mock.patch.object(
                        self.sialib, "_stable_bounded_source_tail",
                        return_value=(b"{}\n", False)), \
                    mock.patch.object(
                        self.sialib.json, "loads",
                        side_effect=parser_error("private source content")):
                cursors = {}
                self.assertEqual(self.sialib.sense_jackal(cursors), [])
                self.assertEqual(cursors["jackal.window"]["seen"], [])

        with tempfile.NamedTemporaryFile(mode="w", delete=False) as stream:
            stream.write("{}\n")
            trend_path = stream.name
        try:
            with mock.patch.object(
                    self.sialib.json, "loads",
                    side_effect=RecursionError("private source content")):
                rows, boundary = self.sialib._bench_trend_snapshot(
                    trend_path, include_metadata=True)
            self.assertEqual(rows, [])
            self.assertTrue(boundary["legacy_truncated"])
        finally:
            os.unlink(trend_path)

    def test_custom_organ_roster_uses_canonical_inert_pages(self):
        old_config = self.sialib.CONFIG
        old_organs = self.sialib.ORGANS
        old_errors = copy.deepcopy(self.sialib.CONFIG_ERRORS)
        with tempfile.TemporaryDirectory() as corpus:
            try:
                self.sialib.CONFIG_ERRORS.clear()
                self.sialib.CONFIG = {"custom_senses": [
                    {"name": "dash", "organ": "-", "path": "/tmp/a",
                     "description": "line\n[[forged]]"},
                    {"name": "dot", "organ": ".x", "path": "/tmp/b",
                     "description": "safe"},
                    {"name": "surrogate", "organ": "surrogate",
                     "path": "/tmp/c", "description": "\ud800"},
                ]}
                organs = self.sialib._build_organs()
                self.assertIn("unknown", organs)
                self.assertIn("x", organs)
                self.assertNotIn("surrogate", organs)
                self.sialib.ORGANS = {
                    key: organs[key] for key in ("unknown", "x")}
                with mock.patch.object(self.sialib, "CORPUS", corpus), \
                        mock.patch.object(
                            self.sialib, "_before_corpus_mutation"):
                    self.sialib.ensure_organs()
                self.assertTrue(os.path.isfile(
                    os.path.join(corpus, "organs", "unknown.md")))
                self.assertTrue(os.path.isfile(
                    os.path.join(corpus, "organs", "x.md")))
                self.assertFalse(os.path.lexists(
                    os.path.join(corpus, "organs", "-.md")))
                with open(os.path.join(corpus, "organs", "unknown.md"),
                          encoding="utf-8") as stream:
                    rendered = stream.read()
                self.assertNotIn("[[forged]]", rendered)
                self.assertIn("⟦⟦forged⟧⟧", rendered)
            finally:
                self.sialib.CONFIG = old_config
                self.sialib.ORGANS = old_organs
                self.sialib.CONFIG_ERRORS[:] = old_errors

    def test_notification_pages_publish_only_after_clean_eof(self):
        with tempfile.TemporaryDirectory() as home:
            history = os.path.join(
                home, ".local/state/omarchy/notifications/history")
            os.makedirs(history)
            names = ("alpha.json", "bravo.json")
            for name in names:
                with open(os.path.join(history, name), "w") as stream:
                    json.dump({"app": "fixture", "summary": name}, stream)
            old_home = self.sialib.HOME
            self.sialib.HOME = home
            cursors = {"notify.last": ""}
            try:
                with mock.patch.object(
                        self.sialib, "MAX_SOURCE_SCAN_ENTRIES", 1):
                    first = self.sialib.sense_notify(cursors)
                    first_page = copy.deepcopy(
                        cursors["source.notify.page"])
                    second = self.sialib.sense_notify(cursors)
                    second_page = copy.deepcopy(
                        cursors["source.notify.page"])
                    completed = self.sialib.sense_notify(cursors)
            finally:
                self.sialib.HOME = old_home
            self.assertEqual(first, [])
            self.assertEqual(second, [])
            self.assertEqual(
                {event.summary for event in completed},
                {f"fixture: {name}" for name in names})
            self.assertNotEqual(first_page["cookie"], second_page["cookie"])
            self.assertNotIn("source.notify.page", cursors)
            self.assertIn("notify.generation", cursors)


class ChildModuleBindSeam(unittest.TestCase):
    """bind()'s parent-mirror seam on the sialib -> siagraph/siasenses
    boundary.  One child module instance is shared by every dynamically
    loaded sialib alias; invoke()'s per-call rebind is what isolates the
    aliases, and the branch that tells a delegate façade apart from a test
    monkeypatch is what keeps the child's intra-module calls on its own raw
    implementations instead of routing them back out through the parent
    façade."""

    def setUp(self):
        self.first = _load("sialib_bind_seam_first",
                           os.path.join(BIN, "sialib.py"))
        self.second = _load("sialib_bind_seam_second",
                            os.path.join(BIN, "sialib.py"))
        self.graph = self.first._siagraph
        self.senses = self.first._siasenses
        # The children are process-wide singletons: every export this class
        # poisons goes back before the next test observes the namespace.
        for child in (self.graph, self.senses):
            self.addCleanup(child.__dict__.update,
                            dict(child._ORIGINAL_CHILD_FUNCTIONS))

    def test_bind_restores_child_original_for_delegate_marked_parent(self):
        # sialib publishes one binding façade per child export and marks it
        # _sia_senses_delegate; bind() must reinstate the raw child function
        # rather than mirror the façade back into the module it delegates to.
        facade = self.first.__dict__["_append_graph_failure"]
        self.assertIs(facade.__dict__.get("_sia_senses_delegate"), True)
        self.graph.__dict__["_append_graph_failure"] = "poisoned"
        self.graph.bind(self.first.__dict__)
        mirrored = [name for name in self.graph._EXPORTED_FUNCTIONS
                    if self.graph.__dict__[name]
                    is not self.graph._ORIGINAL_CHILD_FUNCTIONS[name]]
        self.assertEqual(mirrored, [])
        state = {"failed_ops": []}
        self.first._record_graph_failure(state, "delegate-branch")
        self.assertEqual(state["failed_ops"], ["delegate-branch"])

    def test_bind_mirrors_plain_parent_replacement_into_child_calls(self):
        seen = []

        def fake_append(failures, failure):
            seen.append(failure)

        # A monkeypatch carries no delegate marker, so the seam must mirror
        # it: an intra-module call inside the child observes the mock.
        with mock.patch.object(self.first, "_append_graph_failure",
                               fake_append):
            state = {"failed_ops": []}
            self.first._record_graph_failure(state, "mirrored")
            self.assertIs(
                self.graph.__dict__["_append_graph_failure"], fake_append)
        self.assertEqual(seen, ["mirrored"])
        self.assertEqual(state["failed_ops"], [])

    def test_bind_restores_original_when_parent_omits_the_name(self):
        probe = "_sia_bind_seam_probe"
        self.addCleanup(self.graph.__dict__.pop, probe, None)
        self.graph.__dict__["_append_graph_failure"] = "poisoned"
        # A parent namespace that never defined the export leaves the child
        # on its own implementation, never on a stale leftover value.
        self.graph.bind({probe: "bound"})
        self.assertIs(
            self.graph.__dict__["_append_graph_failure"],
            self.graph._ORIGINAL_CHILD_FUNCTIONS["_append_graph_failure"])
        self.assertEqual(self.graph.__dict__[probe], "bound")

    def test_graph_mock_in_one_alias_does_not_leak_into_the_next(self):
        seen = []

        def fake_append(failures, failure):
            seen.append(failure)

        # Both aliases delegate into one child instance, so only the rebind
        # per call keeps the first alias's mock out of the second's calls.
        self.assertIs(self.first._siagraph, self.second._siagraph)
        with mock.patch.object(self.first, "_append_graph_failure",
                               fake_append):
            first_state = {"failed_ops": []}
            self.first._record_graph_failure(first_state, "first-alias")
            second_state = {"failed_ops": []}
            self.second._record_graph_failure(second_state, "second-alias")
        self.assertEqual(seen, ["first-alias"])
        self.assertEqual(first_state["failed_ops"], [])
        self.assertEqual(second_state["failed_ops"], ["second-alias"])

    def test_invoke_calls_the_original_not_a_stale_mirrored_value(self):
        # invoke() resolves its target from the captured originals before it
        # binds, so a stale mirror in the child namespace can never run.
        self.graph.__dict__["_record_graph_failure"] = "poisoned"
        state = {"failed_ops": []}
        self.graph.invoke(self.first.__dict__, "_record_graph_failure",
                          state, "re-entrant")
        self.assertEqual(state["failed_ops"], ["re-entrant"])
        self.assertIs(
            self.graph.__dict__["_record_graph_failure"],
            self.graph._ORIGINAL_CHILD_FUNCTIONS["_record_graph_failure"])
        # A plain parent replacement is mirrored into intra-module calls,
        # but invoke() itself must still enter the child's own function:
        # resolving the target after bind() would run the parent's mock.
        def fake_record(state, failure):
            state["failed_ops"].append("mirrored-into-invoke")

        parent = dict(self.first.__dict__)
        parent["_record_graph_failure"] = fake_record
        state = {"failed_ops": []}
        self.graph.invoke(parent, "_record_graph_failure", state, "direct")
        self.assertEqual(state["failed_ops"], ["direct"])
        with self.assertRaises(AttributeError):
            self.graph.invoke(self.first.__dict__, "no_such_export")

    def test_bind_refuses_non_dict_and_never_rebinds_control_names(self):
        # The seam's own machinery and the module identity stay owned by the
        # child: a parent may not replace them, and a non-namespace refuses.
        for child in (self.graph, self.senses):
            with self.assertRaises(TypeError):
                child.bind([("STATE", "/tmp")])
            guarded = {name: getattr(child, name)
                       for name in child._BIND_CONTROL_NAMES}
            guarded["__name__"] = child.__name__
            guarded["__doc__"] = child.__doc__
            child.bind({name: "hijacked" for name in guarded})
            for name, owned in guarded.items():
                self.assertIs(getattr(child, name), owned)

    def test_sialib_publishes_one_delegate_per_child_export(self):
        # The export tuple is only a contract because sialib turns every
        # name in it into a published delegate.  A break in that loop would
        # remove a public sialib function while the child still defines it.
        for child in (self.graph, self.senses):
            for name in child._EXPORTED_FUNCTIONS:
                with self.subTest(module=child.__name__, export=name):
                    published = self.first.__dict__[name]
                    self.assertIs(
                        published.__dict__.get("_sia_senses_delegate"), True)

    def test_sense_bind_restores_child_originals_for_delegate_parent(self):
        # The sensing child carries the identical seam; assert its delegate
        # branch the same way so neither half can regress unnoticed.
        facade = self.first.__dict__["_skill_name_bytes"]
        self.assertIs(facade.__dict__.get("_sia_senses_delegate"), True)
        self.senses.__dict__["_skill_name_bytes"] = "poisoned"
        self.senses.bind(self.first.__dict__)
        mirrored = [name for name in self.senses._EXPORTED_FUNCTIONS
                    if self.senses.__dict__[name]
                    is not self.senses._ORIGINAL_CHILD_FUNCTIONS[name]]
        self.assertEqual(mirrored, [])
        self.assertEqual(self.first._skill_display_name("plain"), "plain")

    def test_sense_mock_in_one_alias_does_not_leak_into_the_next(self):
        with mock.patch.object(self.first, "_skill_name_bytes",
                               lambda name: b"mirrored"):
            self.assertEqual(
                self.first._skill_display_name("plain"), "mirrored")
            self.assertEqual(
                self.second._skill_display_name("plain"), "plain")
        self.assertEqual(self.first._skill_display_name("plain"), "plain")



class ConsolidationKeepsOutcomes(unittest.TestCase):
    """A gist that keeps the intent and drops the outcome is worse than a
    shorter one: the aggregate counts still assert that something happened
    while no exemplar shows it, so a rigorous reader must abstain on a fact
    the machine really did observe. Measured on the real corpus — SEKHMET's
    four ``OUTCOME:restart_wireplumber  ok`` rows of 2026-08-24 were all
    dropped by positional sampling, and the claim became ungradeable."""

    def setUp(self):
        self.sialib = _load("sialib_epoch_exemplars",
                            os.path.join(BIN, "sialib.py"))
        # The real 2026-08-24 SEKHMET log, in shape: the outcomes sit in the
        # middle, which is exactly where the old rule could not see them.
        self.day = [
            "- 22:13:56Z GENESIS:init sekhmet -",
            "- 22:14:21Z INTENT:restart_wireplumber  wireplumber_down",
            "- 22:14:21Z OUTCOME:restart_wireplumber  ok",
            "- 22:20:00Z OBS:change sekhmet degraded",
            "- 22:29:23Z OUTCOME:restart_wireplumber  ok",
            "- 23:00:00Z BOOT:watch sekhmet -",
            "- 23:06:14Z OBS:change sekhmet ok",
        ]

    def test_every_event_kind_survives_consolidation(self):
        kept = self.sialib._epoch_exemplars(self.day)
        kinds = {line.split()[2].split(":")[0] for line in kept}
        self.assertEqual(
            kinds, {"GENESIS", "INTENT", "OUTCOME", "OBS", "BOOT"},
            "a kind the day recorded must keep at least one exemplar")

    def test_the_outcome_of_a_heal_is_not_dropped_for_its_intent(self):
        kept = self.sialib._epoch_exemplars(self.day)
        self.assertTrue(
            any("OUTCOME:restart_wireplumber" in line for line in kept),
            "the epoch recorded the intent and lost the success")
        # The defect, stated as the old rule, so a revert fails here.
        old_rule = self.day[:2] + self.day[-1:]
        self.assertFalse(
            any("OUTCOME:" in line for line in old_rule),
            "positional sampling is what dropped it")

    def test_an_epoch_stays_a_gist(self):
        long_day = [f"- 0{i}:00:00Z OBS:change sekhmet ok" for i in range(9)]
        self.assertLessEqual(
            len(self.sialib._epoch_exemplars(long_day)),
            self.sialib.MAX_EPOCH_EXEMPLARS)
        self.assertEqual(self.sialib._epoch_exemplars([]), [])

    def test_exemplars_stay_in_order_and_are_real_lines(self):
        kept = self.sialib._epoch_exemplars(self.day)
        self.assertEqual(kept, sorted(kept, key=self.day.index))
        for line in kept:
            self.assertIn(line, self.day)


class GradingAdmitsTheEpochLane(unittest.TestCase):
    """`epochs/` is in the grading evidence allowlist, but the selection
    sorted both lanes into one list by full path and sliced the tail — and
    "epochs" sorts before "events", so an organ with three or more day pages
    never showed the judge its epoch at all. Consolidated history lives
    there, so the lane was allowed and unreachable at the same time."""

    def setUp(self):
        self.siatakes = _load("siatakes_epoch_lane",
                              os.path.join(BIN, "siatakes.py"))

    @staticmethod
    def _select(paths, max_pages=3):
        candidates = [(p, p, None) for p in paths]
        lanes = {}
        for item in candidates:
            lanes.setdefault(item[1].split("/", 1)[0], []).append(item)
        ranked = [sorted(items, key=lambda item: item[0])
                  for _lane, items in sorted(lanes.items())]
        selected = []
        while len(selected) < max_pages and any(ranked):
            progressed = False
            for lane_items in ranked:
                if len(selected) >= max_pages:
                    break
                if lane_items:
                    selected.append(lane_items.pop())
                    progressed = True
            if not progressed:
                break
        return [item[0] for item in sorted(selected, key=lambda i: i[0])]

    def test_the_shipped_selection_is_round_robin_not_a_path_slice(self):
        with open(os.path.join(BIN, "siatakes.py"), encoding="utf-8") as f:
            source = f.read()
        self.assertNotIn(
            "pages = sorted(candidates, key=lambda item: item[0])"
            "[-max_pages:]", source)
        self.assertIn("lanes.setdefault(item[1].split(\"/\", 1)[0]", source)

    def test_an_epoch_is_admitted_beside_the_recent_days(self):
        paths = ["epochs/sekhmet/2026-w35"] + [
            f"events/sekhmet/2026-08-{day}" for day in (27, 28, 29, 30, 31)]
        chosen = self._select(paths)
        self.assertIn("epochs/sekhmet/2026-w35", chosen)
        self.assertEqual(len(chosen), 3)
        # The old rule, pinned so a revert fails here.
        self.assertNotIn("epochs/sekhmet/2026-w35", sorted(paths)[-3:])

    def test_a_single_lane_still_fills_the_budget(self):
        days = [f"events/sekhmet/2026-08-{d}" for d in (27, 28, 29, 30)]
        self.assertEqual(len(self._select(days)), 3)
        self.assertEqual(
            self._select(days),
            ["events/sekhmet/2026-08-28", "events/sekhmet/2026-08-29",
             "events/sekhmet/2026-08-30"],
            "with no epoch lane the most recent days are still chosen")



class GradingExcerptsShowTheEvidence(unittest.TestCase):
    """The organ lane handed the judge a blind 420-character prefix, and a
    page's first bytes are its frontmatter. Measured on the real week-35
    epoch: the ``OUTCOME:restart_wireplumber  ok`` exemplar sits at character
    497 of 1027, so the judge saw the page's metadata — including an aggregate
    ``outcome: 5`` that is a count and not an instance — and none of its
    evidence. It named the page and correctly reported that it showed
    nothing."""

    PAGE = (
        '--- type: epoch title: "SEKHMET — 2026 week 35" '
        'tags: [healing, sekhmet] date: 2026-08-24 '
        'sia_counts: {"boot": 4, "genesis": 1, "intent": 5, "obs": 16, '
        '"outcome": 5} --- # SEKHMET — 2026 week 35 Consolidated from 2 '
        'day-memories (2026-08-24 … 2026-08-25); originals verbatim in '
        'corpus git history. Source: [[organs/sekhmet]] for [[sia/cortex]]. '
        '## Exemplars - 2026-08-24 · 22:13:56Z GENESIS:init sekhmet - '
        '- 2026-08-24 · 22:14:21Z INTENT:restart_wireplumber '
        'wireplumber_down - 2026-08-24 · 22:14:21Z '
        'OUTCOME:restart_wireplumber  ok - 2026-08-24 · 22:20:25Z '
        'BOOT:watch sekhmet - - 2026-08-24 · 23:06:14Z OBS:change sekhmet ok')
    CLAIM = ("SEKHMET successfully restarted wireplumber at least once "
             "during August 2026")

    def setUp(self):
        self.siatakes = _load("siatakes_excerpt",
                              os.path.join(BIN, "siatakes.py"))

    def test_the_excerpt_carries_the_evidence_a_prefix_truncated_away(self):
        excerpt = self.siatakes._evidence_excerpt(self.PAGE, self.CLAIM, 420)
        self.assertIn("OUTCOME:restart_wireplumber", excerpt)
        # The defect, pinned so a revert fails here.
        self.assertNotIn("OUTCOME:restart_wireplumber", self.PAGE[:420])

    def test_frontmatter_is_not_evidence(self):
        excerpt = self.siatakes._evidence_excerpt(self.PAGE, self.CLAIM, 420)
        self.assertNotIn("sia_counts", excerpt)
        self.assertNotIn("type: epoch", excerpt)

    def test_the_excerpt_stays_within_its_budget(self):
        for chars in (120, 220, 420):
            with self.subTest(chars=chars):
                excerpt = self.siatakes._evidence_excerpt(
                    self.PAGE, self.CLAIM, chars)
                self.assertLessEqual(len(excerpt), chars)

    def test_a_short_page_is_returned_whole_without_its_frontmatter(self):
        page = "--- type: epoch --- # T body text here"
        self.assertEqual(
            self.siatakes._evidence_excerpt(page, self.CLAIM, 420),
            "# T body text here")

    def test_a_claim_that_matches_nothing_still_returns_the_head(self):
        excerpt = self.siatakes._evidence_excerpt(
            self.PAGE, "zzzz qqqq", 200)
        self.assertTrue(excerpt.startswith("# SEKHMET"))
        self.assertLessEqual(len(excerpt), 200)



class GradingPrefersTheExcerptThatBearsOnTheClaim(unittest.TestCase):
    """Both retrieval lanes can cite the same page and each brings its own
    excerpt. Taking whichever arrived first meant the semantic lane's short
    positional head silently beat the organ lane's claim-centred window.
    Measured: the week-35 epoch reached the judge as its own title in 220
    characters while the 446-character view carrying
    ``OUTCOME:restart_wireplumber  ok`` was discarded, so the judge abstained
    on a page that was admitted and did contain the answer."""

    PAGE = (
        "# SEKHMET — 2026 week 35 Consolidated from 2 day-memories; "
        "originals verbatim in corpus git history. ## Exemplars "
        "- 2026-08-24 · 22:13:56Z GENESIS:init sekhmet - "
        "- 2026-08-24 · 22:14:21Z INTENT:restart_wireplumber wireplumber_down "
        "- 2026-08-24 · 22:14:21Z OUTCOME:restart_wireplumber  ok "
        "- 2026-08-24 · 23:06:14Z OBS:change sekhmet ok")
    CLAIM = ("SEKHMET successfully restarted wireplumber at least once "
             "during August 2026")

    def setUp(self):
        self.siatakes = _load("siatakes_best_excerpt",
                              os.path.join(BIN, "siatakes.py"))

    def test_the_view_carrying_the_evidence_wins_over_the_earlier_head(self):
        head = self.PAGE[:120]
        bearing = self.PAGE[self.PAGE.index("## Exemplars"):]
        chosen = self.siatakes._best_excerpt(
            [head, bearing], self.PAGE, self.CLAIM)
        self.assertIn("OUTCOME:restart_wireplumber", chosen)
        # The defect, pinned: first-wins picked the head.
        self.assertNotIn("OUTCOME:restart_wireplumber", head)

    def test_a_candidate_absent_from_the_page_is_never_admitted(self):
        self.assertIsNone(self.siatakes._best_excerpt(
            ["a stale excerpt from another generation"], self.PAGE,
            self.CLAIM),
            "choosing among views must not widen what may be admitted")

    def test_selection_is_deterministic_on_a_tie(self):
        first = self.PAGE[:100]
        second = self.PAGE[100:200]
        self.assertEqual(
            self.siatakes._best_excerpt(
                [first, second], self.PAGE, "zzzz"),
            first, "a tie keeps the earlier candidate")

    def test_no_valid_candidate_yields_none(self):
        self.assertIsNone(
            self.siatakes._best_excerpt([], self.PAGE, self.CLAIM))
        self.assertIsNone(
            self.siatakes._best_excerpt([""], self.PAGE, self.CLAIM))


class SkillSenseContainment(unittest.TestCase):
    def test_configured_skill_roots_refuse_home_escape(self):
        sialib = _load("sialib_skill_root_containment",
                       os.path.join(BIN, "sialib.py"))
        with tempfile.TemporaryDirectory() as home, \
                tempfile.TemporaryDirectory() as outside:
            sialib.HOME = home
            for supplied, expected_error in (
                    ("../outside", "skills-roots-outside-home"),
                    (outside, "skills-roots-invalid")):
                with self.subTest(root=supplied):
                    sialib.CONFIG = {"skills": {"roots": [supplied]}}
                    sialib.CONFIG_ERRORS.clear()

                    self.assertEqual(sialib._configured_skill_roots(), [])
                    self.assertEqual(sialib._configured_skill_root_paths(), [])
                    self.assertEqual(sialib.CONFIG_ERRORS, [{
                        "config": "config.json", "error": expected_error}])
                    self.assertNotIn("skills", sialib._build_organs())

    def test_malformed_skill_root_roster_disables_without_defaults(self):
        sialib = _load("sialib_skill_root_malformed",
                       os.path.join(BIN, "sialib.py"))
        with tempfile.TemporaryDirectory() as home:
            sialib.HOME = home
            cases = (
                ({"skills": "not-an-object"}, "skills-must-be-object"),
                ({"skills": {"rooots": [".agents/skills"]}},
                 "skills-unknown-key"),
                ({"skills": {"_comment": ["not-text"]}},
                 "skills-comment-must-be-string"),
                ({"skills": {"roots": ".agents/skills"}},
                 "skills-roots-invalid"),
                ({"skills": {"roots": [""]}}, "skills-roots-invalid"),
            )
            for config, expected_error in cases:
                with self.subTest(config=config):
                    sialib.CONFIG = config
                    sialib.CONFIG_ERRORS.clear()

                    self.assertEqual(sialib._configured_skill_roots(), [])
                    self.assertEqual(sialib.CONFIG_ERRORS, [{
                        "config": "config.json", "error": expected_error}])
                    self.assertNotIn("skills", sialib._build_organs())

            sialib.CONFIG = {"skills": {"roots": []}}
            sialib.CONFIG_ERRORS.clear()
            self.assertEqual(sialib._configured_skill_roots(), [])
            self.assertEqual(sialib.CONFIG_ERRORS, [])
            self.assertNotIn("skills", sialib._build_organs())

    def test_loaded_skill_config_surfaces_unknown_keys_and_bad_comments(self):
        sialib = _load("sialib_skill_load_shape",
                       os.path.join(BIN, "sialib.py"))
        with tempfile.TemporaryDirectory() as home:
            path = os.path.join(home, "config.json")
            old_path = sialib.CONFIG_PATH
            sialib.CONFIG_PATH = path
            try:
                with open(path, "w", encoding="utf-8") as stream:
                    json.dump({"skills": {
                        "rooots": [".agents/skills"],
                        "_comment": ["not-text"],
                    }}, stream)
                loaded = sialib.load_config()
                self.assertEqual(loaded["skills"]["rooots"],
                                 [".agents/skills"])
                self.assertEqual(sialib.CONFIG_ERRORS, [
                    {"config": "config.json",
                     "error": "skills-unknown-key"},
                    {"config": "config.json",
                     "error": "skills-comment-must-be-string"},
                ])
                sialib.CONFIG = loaded
                self.assertEqual(sialib._configured_skill_root_paths(), [])
            finally:
                sialib.CONFIG_PATH = old_path

    def test_configured_non_claude_root_activates_the_skills_organ(self):
        sialib = _load("sialib_skill_configured_activation",
                       os.path.join(BIN, "sialib.py"))
        with tempfile.TemporaryDirectory() as home:
            configured = os.path.join(home, ".agents/skills")
            os.makedirs(configured)
            sialib.HOME = home
            sialib.CONFIG = {
                "skills": {"roots": [".agents/skills"]},
            }

            sialib.SKILL_ROOTS = sialib._configured_skill_roots()
            organs = sialib._build_organs()
            senses = [
                sense for sense in sialib._ALL_SENSES
                if sialib._SENSE_ORGAN.get(sense.__name__, "") in organs]

            self.assertEqual(sialib.SKILL_ROOTS, [configured])
            self.assertIn("skills", organs)
            self.assertIn(sialib.sense_skills, senses)

            os.rmdir(configured)
            self.assertIn(
                "skills", sialib._build_organs(),
                "a restart with all configured roots absent must still "
                "run the sense so prior catalog state can converge")

    def test_sensing_facade_keeps_dynamic_alias_contexts_isolated(self):
        first = _load("sialib_sense_alias_first",
                      os.path.join(BIN, "sialib.py"))
        second = _load("sialib_sense_alias_second",
                       os.path.join(BIN, "sialib.py"))
        with tempfile.TemporaryDirectory() as root:
            first_home = os.path.join(root, "first")
            second_home = os.path.join(root, "second")
            first_log = os.path.join(root, "first.log")
            second_log = os.path.join(root, "second.log")
            with open(first_log, "w", encoding="utf-8") as stream:
                stream.write("first alias evidence\n")
            with open(second_log, "w", encoding="utf-8") as stream:
                stream.write("second alias evidence\n")
            first.HOME, second.HOME = first_home, second_home
            first.CONFIG = {
                "skills": {"roots": ["first-skills"]},
                "custom_senses": [{"name": "first", "path": first_log}],
            }
            second.CONFIG = {
                "skills": {"roots": ["second-skills"]},
                "custom_senses": [{"name": "second", "path": second_log}],
            }
            first_events, first_errors = first.sense_custom({"custom.first": 0})
            second_events, second_errors = second.sense_custom({"custom.second": 0})
            self.assertEqual(first_errors, [])
            self.assertEqual(second_errors, [])
            self.assertIn("first alias evidence", first_events[0].summary)
            self.assertIn("second alias evidence", second_events[0].summary)
            self.assertEqual(first._configured_skill_roots(), [
                os.path.join(first_home, "first-skills")])
            self.assertEqual(second._configured_skill_roots(), [
                os.path.join(second_home, "second-skills")])
            self.assertIs(first.SENSES[-1], first.sense_custom)
            self.assertIs(second.SENSES[-1], second.sense_custom)

    def test_skill_snapshot_replays_once_with_digest_and_description(self):
        sialib = _load("sialib_skill_single_capture",
                       os.path.join(BIN, "sialib.py"))
        with tempfile.TemporaryDirectory() as directory:
            root = os.path.join(directory, "skills")
            skill = os.path.join(root, "stable")
            os.makedirs(skill)
            raw = b"---\ndescription: captured once\n---\n"
            with open(os.path.join(skill, "SKILL.md"), "wb") as stream:
                stream.write(raw)
            sialib.SKILL_ROOTS = [root]
            sialib.CORPUS = os.path.join(directory, "corpus")
            os.makedirs(sialib.CORPUS)
            original = sialib._read_skill_manifest
            calls = []

            def capture_and_replay(capture_root, name):
                calls.append((capture_root, name))
                if len(calls) > 2:
                    raise AssertionError("skill manifest replay exceeded bound")
                return original(capture_root, name)

            with mock.patch.object(
                    sialib, "_read_skill_manifest",
                    side_effect=capture_and_replay):
                events = sialib.sense_skills({"skills.snapshot": {}})
            self.assertEqual(calls, [(root, "stable"), (root, "stable")])
            installed = [event for event in events
                         if event.kind == "installed"]
            self.assertEqual(len(installed), 1)
            self.assertIn("captured once", installed[0].summary)

            cursors = {"skills.snapshot": {}}
            with mock.patch.object(
                    sialib, "_read_skill_manifest", wraps=original):
                sialib.sense_skills(cursors)
            state = cursors["skills.snapshot"]["stable"]
            self.assertEqual(state["description"], "captured once")
            root_row = state["roots"][0]
            self.assertEqual(root_row["description"], "captured once")
            self.assertEqual(
                root_row["manifest"]["head_sha256"],
                hashlib.sha256(raw).hexdigest())
            self.assertEqual(root_row["manifest"]["head_bytes"], len(raw))
            self.assertFalse(root_row["manifest"]["head_truncated"])

            # Entity projection consumes only the already-rendered event; it
            # must not reopen a manifest after the sense boundary.
            with mock.patch.object(
                    sialib, "_read_skill_manifest",
                    side_effect=AssertionError("second manifest open")):
                sialib.ensure_event_entities(installed)

    def test_rewrite_after_root_validation_refuses_then_updates(self):
        sialib = _load("sialib_skill_post_validation_rewrite",
                       os.path.join(BIN, "sialib.py"))
        with tempfile.TemporaryDirectory() as directory:
            root = os.path.join(directory, "skills")
            skill = os.path.join(root, "mutable")
            os.makedirs(skill)
            manifest = os.path.join(skill, "SKILL.md")
            before = "---\ndescription: old capture\n---\n"
            after = "---\ndescription: new capture\n---\n"
            with open(manifest, "w") as stream:
                stream.write(before)
            sialib.SKILL_ROOTS = [root]
            cursors = {"skills.snapshot": {}}
            sialib.sense_skills(cursors)
            prior_state = copy.deepcopy(
                cursors["skills.snapshot"]["mutable"])
            prior_stat = os.stat(manifest)
            original = sialib._skill_root_generation_matches
            rewritten = []

            def rewrite_after_validation(capture_root, generation):
                stable = original(capture_root, generation)
                if stable and not rewritten:
                    rewritten.append(True)
                    with open(manifest, "w") as stream:
                        stream.write(after)
                    os.utime(manifest, ns=(prior_stat.st_atime_ns,
                                           prior_stat.st_mtime_ns))
                return stable

            with mock.patch.object(
                    sialib, "_skill_root_generation_matches",
                    side_effect=rewrite_after_validation):
                first = sialib.sense_skills(cursors)
            self.assertTrue(cursors["skills.partial"])
            self.assertFalse(any(event.kind == "updated" for event in first))
            self.assertTrue(any(event.kind == "source-refused"
                                for event in first))
            self.assertEqual(
                cursors["skills.snapshot"]["mutable"], prior_state)

            second = sialib.sense_skills(cursors)
            updated = [event for event in second if event.kind == "updated"]
            self.assertEqual(len(updated), 1)
            self.assertIn("new capture", updated[0].summary)
            current_state = cursors["skills.snapshot"]["mutable"]
            self.assertEqual(
                current_state["roots"][0]["manifest"]["mtime_ns"],
                prior_state["roots"][0]["manifest"]["mtime_ns"])
            self.assertNotEqual(
                current_state["roots"][0]["manifest"]["head_sha256"],
                prior_state["roots"][0]["manifest"]["head_sha256"])

    def test_manifest_path_replacement_marks_root_partial_and_retains_state(self):
        sialib = _load("sialib_skill_path_replacement",
                       os.path.join(BIN, "sialib.py"))
        with tempfile.TemporaryDirectory() as directory:
            root = os.path.join(directory, "skills")
            skill = os.path.join(root, "resident")
            os.makedirs(skill)
            manifest = os.path.join(skill, "SKILL.md")
            with open(manifest, "wb") as stream:
                stream.write(b"---\ndescription: original\n---\n")
            sialib.SKILL_ROOTS = [root]
            cursors = {}
            sialib.sense_skills(cursors)
            replacement = os.path.join(directory, "replacement")
            with open(replacement, "wb") as stream:
                stream.write(b"---\ndescription: replaced\n---\n")
            real_read = sialib.os.read
            swapped = []

            def replace_after_read(descriptor, count):
                data = real_read(descriptor, count)
                if data and not swapped:
                    swapped.append(True)
                    os.replace(replacement, manifest)
                return data

            with mock.patch.object(
                    sialib.os, "read", side_effect=replace_after_read):
                events = sialib.sense_skills(cursors)
            self.assertTrue(swapped)
            self.assertTrue(cursors["skills.partial"])
            self.assertIn("resident", cursors["skills.snapshot"])
            self.assertFalse(any(event.kind in {"updated", "removed"}
                                 for event in events))
            self.assertTrue(any(event.kind == "source-refused"
                                for event in events))

    def test_in_place_manifest_change_during_read_is_refused(self):
        sialib = _load("sialib_skill_in_place_rewrite",
                       os.path.join(BIN, "sialib.py"))
        with tempfile.TemporaryDirectory() as directory:
            root = os.path.join(directory, "skills")
            skill = os.path.join(root, "mutable")
            os.makedirs(skill)
            manifest = os.path.join(skill, "SKILL.md")
            before = b"---\ndescription: alpha\n---\n"
            after = b"---\ndescription: bravo\n---\n"
            with open(manifest, "wb") as stream:
                stream.write(before)
            real_read = sialib.os.read
            rewritten = []

            def rewrite_after_read(descriptor, count):
                data = real_read(descriptor, count)
                if data and not rewritten:
                    rewritten.append(True)
                    with open(manifest, "r+b") as stream:
                        stream.write(after)
                        stream.truncate()
                        stream.flush()
                        os.fsync(stream.fileno())
                return data

            with mock.patch.object(
                    sialib.os, "read", side_effect=rewrite_after_read):
                with self.assertRaisesRegex(RuntimeError, "changed"):
                    sialib._read_skill_manifest(root, "mutable")
            self.assertTrue(rewritten)

    def test_skill_event_occurrence_is_exact_across_crash_retry(self):
        sialib = _load("sialib_skill_crash_retry",
                       os.path.join(BIN, "sialib.py"))
        with tempfile.TemporaryDirectory() as directory:
            root = os.path.join(directory, "skills")
            skill = os.path.join(root, "retry")
            os.makedirs(skill)
            with open(os.path.join(skill, "SKILL.md"), "w") as stream:
                stream.write("---\ndescription: exact retry\n---\n")
            sialib.SKILL_ROOTS = [root]
            first_cursors = {"skills.snapshot": {}}
            second_cursors = copy.deepcopy(first_cursors)
            first = sialib.sense_skills(first_cursors)
            second = sialib.sense_skills(second_cursors)
            first_event = next(event for event in first
                               if event.kind == "installed")
            second_event = next(event for event in second
                                if event.kind == "installed")
            self.assertEqual(first_event.occurrence, second_event.occurrence)
            self.assertEqual(first_cursors["skills.snapshot"],
                             second_cursors["skills.snapshot"])

    def test_linked_roots_directories_and_manifests_are_not_opened(self):
        sialib = _load("sialib_skill_containment",
                       os.path.join(BIN, "sialib.py"))
        with tempfile.TemporaryDirectory() as directory:
            root = os.path.join(directory, "skills")
            outside = os.path.join(directory, "outside")
            os.makedirs(root)
            os.makedirs(outside)
            real = os.path.join(root, "real")
            os.makedirs(real)
            with open(os.path.join(real, "SKILL.md"), "w") as stream:
                stream.write("---\ndescription: admitted context\n---\n")
            with open(os.path.join(outside, "SKILL.md"), "w") as stream:
                stream.write("---\ndescription: PRIVATE SENTINEL\n---\n")
            os.symlink(outside, os.path.join(root, "linked-directory"))
            linked_file = os.path.join(root, "linked-file")
            os.makedirs(linked_file)
            os.symlink(os.path.join(outside, "SKILL.md"),
                       os.path.join(linked_file, "SKILL.md"))
            linked_root = os.path.join(directory, "linked-root")
            os.symlink(outside, linked_root)
            sialib.SKILL_ROOTS = [root, linked_root]
            cursors = {}
            events = sialib.sense_skills(cursors)

            self.assertEqual(set(cursors["skills.snapshot"]), {"real"})
            rendered = " ".join(event.summary for event in events)
            self.assertIn("real", rendered)
            self.assertNotIn("PRIVATE SENTINEL", rendered)
            self.assertEqual(sialib._skill_description("linked-directory"),
                             "")
            self.assertEqual(sialib._skill_description("linked-file"), "")

    def test_skill_snapshot_is_bounded_and_partial_pages_cannot_remove(self):
        sialib = _load("sialib_skill_bounds",
                       os.path.join(BIN, "sialib.py"))
        with tempfile.TemporaryDirectory() as directory:
            root = os.path.join(directory, "skills")
            os.makedirs(root)
            previous = os.path.join(root, "previous")
            os.makedirs(previous)
            with open(os.path.join(previous, "SKILL.md"), "w") as stream:
                stream.write("---\ndescription: prior\n---\n")
            sialib.SKILL_ROOTS = [root]
            cursors = {}
            sialib.sense_skills(cursors)
            shutil.rmtree(previous)
            for name in ("one", "two", "three"):
                skill = os.path.join(root, name)
                os.makedirs(skill)
                with open(os.path.join(skill, "SKILL.md"), "w") as stream:
                    stream.write("---\ndescription: bounded\n---\n")
            with mock.patch.object(
                    sialib, "MAX_SKILL_SNAPSHOT_ENTRIES", 2):
                events = sialib.sense_skills(cursors)

            self.assertTrue(cursors["skills.truncated"])
            self.assertLessEqual(len(cursors["skills.snapshot"]), 2)
            self.assertFalse(any(event.kind == "removed"
                                 for event in events))

    def test_non_utf8_skill_name_has_safe_stable_identity(self):
        sialib = _load("sialib_skill_non_utf8",
                       os.path.join(BIN, "sialib.py"))
        with tempfile.TemporaryDirectory() as directory:
            root = os.path.join(directory, "skills")
            os.makedirs(root)
            raw_skill = os.path.join(os.fsencode(root), b"agent-\xff")
            os.mkdir(raw_skill)
            with open(os.path.join(raw_skill, b"SKILL.md"), "wb") as stream:
                stream.write(b"---\ndescription: arbitrary bytes\n---\n")
            sialib.SKILL_ROOTS = [root]
            cursors = {}
            first = sialib.sense_skills(cursors)
            second = sialib.sense_skills(cursors)

            self.assertTrue(first)
            self.assertEqual(second, [])
            self.assertEqual(len(cursors["skills.snapshot"]), 1)
            state = next(iter(cursors["skills.snapshot"].values()))
            self.assertIn(r"\xff", state["name"])
            json.dumps(cursors, ensure_ascii=False).encode("utf-8")
            for event in first:
                sialib.event_memory_identity(event)

    def test_missing_root_retains_state_until_two_complete_snapshots(self):
        sialib = _load("sialib_skill_root_coverage",
                       os.path.join(BIN, "sialib.py"))
        with tempfile.TemporaryDirectory() as directory:
            root = os.path.join(directory, "skills")
            hidden = os.path.join(directory, "skills-hidden")
            skill = os.path.join(root, "resident")
            os.makedirs(skill)
            with open(os.path.join(skill, "SKILL.md"), "w") as stream:
                stream.write("---\ndescription: durable\n---\n")
            sialib.SKILL_ROOTS = [root]
            cursors = {}
            sialib.sense_skills(cursors)

            os.rename(root, hidden)
            missing = sialib.sense_skills(cursors)
            self.assertTrue(cursors["skills.partial"])
            self.assertIn("resident", cursors["skills.snapshot"])
            self.assertFalse(any(event.kind == "removed"
                                 for event in missing))
            self.assertTrue(any(event.kind == "source-refused"
                                for event in missing))

            os.rename(hidden, root)
            os.unlink(os.path.join(skill, "SKILL.md"))
            os.rmdir(skill)
            first_complete = sialib.sense_skills(cursors)
            self.assertFalse(cursors["skills.partial"])
            self.assertIn("resident", cursors["skills.snapshot"])
            self.assertFalse(any(event.kind == "removed"
                                 for event in first_complete))

            second_complete = sialib.sense_skills(cursors)
            self.assertTrue(any(event.kind == "removed"
                                for event in second_complete))
            self.assertNotIn("resident", cursors["skills.snapshot"])

    def test_lossy_slug_replacement_has_distinct_cross_generation_identity(self):
        sialib = _load("sialib_skill_cross_generation_identity",
                       os.path.join(BIN, "sialib.py"))
        with tempfile.TemporaryDirectory() as directory:
            root = os.path.join(directory, "skills")
            os.makedirs(root)
            first_path = os.path.join(root, "a+b")
            os.makedirs(first_path)
            with open(os.path.join(first_path, "SKILL.md"), "w") as stream:
                stream.write("---\ndescription: first\n---\n")
            sialib.SKILL_ROOTS = [root]
            cursors = {}
            sialib.sense_skills(cursors)
            first_token = next(iter(cursors["skills.snapshot"]))

            os.unlink(os.path.join(first_path, "SKILL.md"))
            os.rmdir(first_path)
            second_path = os.path.join(root, "a b")
            os.makedirs(second_path)
            with open(os.path.join(second_path, "SKILL.md"), "w") as stream:
                stream.write("---\ndescription: second\n---\n")
            events = sialib.sense_skills(cursors)
            second_token = next(iter(cursors["skills.snapshot"]))

            self.assertNotEqual(first_token, second_token)
            self.assertEqual({event.kind for event in events
                              if event.kind in {"installed", "removed"}},
                             {"installed", "removed"})


class TouchWeighting(unittest.TestCase):
    """World-originated touches count full; system-generated self-reference is
    steeply discounted (no echo chamber)."""

    def test_exo_beats_endo(self):
        now = time.time()
        exo = {"nodes": {}}
        endo = {"nodes": {}}
        for _ in range(5):
            siamind.touch(exo, "p", now, src="organ")
            siamind.touch(endo, "p", now, src="ponder")
        b_exo = siamind.actr_base(exo["nodes"]["p"], now + 60)
        b_endo = siamind.actr_base(endo["nodes"]["p"], now + 60)
        self.assertGreater(b_exo, b_endo,
                           "organ touches must outweigh self-reference")


class EpochMerge(unittest.TestCase):
    """Consolidation is idempotent: re-running against an existing epoch
    page EXTENDS it (sums counts), never atomically overwrites — the
    data-loss regression a reviewer would probe."""

    def test_jackal_consolidation_remains_derived_recall(self):
        sialib = _load("sialib_epoch_jackal_origin",
                       os.path.join(BIN, "sialib.py"))
        with tempfile.TemporaryDirectory() as corpus:
            sialib.CORPUS = corpus
            old_mind_path = sialib.siamind.MIND_PATH
            sialib.siamind.MIND_PATH = os.path.join(corpus, "mind.json")
            self.addCleanup(
                setattr, sialib.siamind, "MIND_PATH", old_mind_path)
            sialib.log = lambda *_args: None
            event_dir = os.path.join(corpus, "events", "jackal")
            os.makedirs(event_dir)
            for day in ("2026-01-05", "2026-01-06"):
                with open(os.path.join(event_dir, day + ".md"), "w",
                          encoding="utf-8") as stream:
                    stream.write(
                        f'---\ntype: event-day\norigin: derived\n'
                        f'title: "JACKAL {day}"\n'
                        f'tags: [jackal, checked]\ndate: {day}\n'
                        'sia_counts: {"checked": 1}\n---\n# JACKAL\n\n'
                        '## Log\n- unverified result observed\n\n'
                        f'## Timeline\n- **{day}** — one observation\n')
            subprocess.run(["git", "init", "-q", corpus], check=True)
            subprocess.run([
                "git", "-C", corpus, "-c", "user.email=t@t",
                "-c", "user.name=t", "add", "-A"], check=True)
            subprocess.run([
                "git", "-C", corpus, "-c", "user.email=t@t",
                "-c", "user.name=t", "commit", "-qm", "fixture"],
                check=True)
            with mock.patch.dict(os.environ, {"SIA_EPISODIC_DAYS": "1"}):
                compacted, epochs, _kept = sialib.consolidate_corpus()
            self.assertGreaterEqual(compacted, 1)
            self.assertGreaterEqual(epochs, 1)
            epoch_paths = []
            for directory, _subdirs, names in os.walk(
                    os.path.join(corpus, "epochs", "jackal")):
                epoch_paths.extend(os.path.join(directory, name)
                                   for name in names if name.endswith(".md"))
            self.assertEqual(len(epoch_paths), 1)
            with open(epoch_paths[0], encoding="utf-8") as stream:
                epoch_text = stream.read()
            self.assertIn("\norigin: derived\n", epoch_text)
            epoch_slug = os.path.relpath(
                epoch_paths[0][:-3], corpus).replace(os.sep, "/")
            self.assertEqual(sialib.corpus_origin(epoch_slug), "derived")

    def test_huge_event_shard_number_refuses_before_range_materialization(self):
        sialib = _load("sialib_epoch_huge_shard",
                       os.path.join(BIN, "sialib.py"))
        with tempfile.TemporaryDirectory() as corpus:
            sialib.CORPUS = corpus
            event_dir = os.path.join(corpus, "events", "org")
            os.makedirs(event_dir)
            with open(os.path.join(event_dir, "2026-01-05.md"), "w") \
                    as stream:
                stream.write("base\n")
            huge = "9" * 40
            with open(os.path.join(
                    event_dir, f"2026-01-05-part-{huge}.md"), "w") \
                    as stream:
                stream.write("overflow\n")

            with self.assertRaisesRegex(
                    ValueError, "invalid or exceeds its bound"):
                sialib._event_day_shards("org", "2026-01-05")

    def test_two_digit_event_shard_number_is_recognized_not_skipped(self):
        sialib = _load("sialib_epoch_two_digit_shard",
                       os.path.join(BIN, "sialib.py"))
        with tempfile.TemporaryDirectory() as corpus:
            sialib.CORPUS = corpus
            event_dir = os.path.join(corpus, "events", "org")
            os.makedirs(event_dir)
            with open(os.path.join(event_dir, "2026-01-05.md"), "w") \
                    as stream:
                stream.write("base\n")
            with open(os.path.join(
                    event_dir, "2026-01-05-part-10.md"), "w") \
                    as stream:
                stream.write("overflow\n")

            # A part-10 shard with no part-2..9 predecessors must be seen and
            # rejected as a genuine contiguity gap, not silently skipped by a
            # parser that only recognized a single leading digit.
            with self.assertRaisesRegex(
                    ValueError, "are not contiguous"):
                sialib._event_day_shards("org", "2026-01-05")

    def test_event_source_regex_admits_multi_digit_parts_and_refuses_invalid_forms(self):
        sialib = _load("sialib_event_source_re_grammar",
                       os.path.join(BIN, "sialib.py"))
        admitted = ("events/org/2026-01-05.md",
                    "events/org/2026-01-05-part-2.md",
                    "events/org/2026-01-05-part-9.md",
                    "events/org/2026-01-05-part-10.md",
                    "events/org/2026-01-05-part-19.md",
                    "events/org/2026-01-05-part-100.md",
                    "events/org/2026-01-05-part-199.md")
        for relative in admitted:
            with self.subTest(relative=relative):
                self.assertIsNotNone(
                    sialib.EVENT_SOURCE_RE.fullmatch(relative))
        refused = ("events/org/2026-01-05-part-0.md",
                   "events/org/2026-01-05-part-1.md",
                   "events/org/2026-01-05-part-01.md",
                   "events/org/2026-01-05-part-1a.md",
                   "events/org/2026-01-05-part-.md",
                   "events/org/2026-01-05-part-ten.md")
        for relative in refused:
            with self.subTest(relative=relative):
                self.assertIsNone(
                    sialib.EVENT_SOURCE_RE.fullmatch(relative))

    def test_event_replay_key_admits_multi_digit_parts_and_refuses_invalid_forms(self):
        sialib = _load("sialib_event_replay_key_grammar",
                       os.path.join(BIN, "sialib.py"))
        event_id = "a" * 64
        admitted = ("events/org/2026-01-05",
                    "events/org/2026-01-05-part-2",
                    "events/org/2026-01-05-part-9",
                    "events/org/2026-01-05-part-10",
                    "events/org/2026-01-05-part-19",
                    "events/org/2026-01-05-part-100",
                    "events/org/2026-01-05-part-199")
        for day_slug in admitted:
            with self.subTest(day_slug=day_slug):
                sialib.siamind._validate_event_replay_key(day_slug, event_id)
        refused = ("events/org/2026-01-05-part-0",
                   "events/org/2026-01-05-part-1",
                   "events/org/2026-01-05-part-01",
                   "events/org/2026-01-05-part-1a",
                   "events/org/2026-01-05-part-",
                   "events/org/2026-01-05-part-ten")
        for day_slug in refused:
            with self.subTest(day_slug=day_slug):
                with self.assertRaisesRegex(
                        ValueError, "event replay identity is invalid"):
                    sialib.siamind._validate_event_replay_key(day_slug, event_id)

    def test_contiguous_shards_through_a_two_digit_part_are_discovered(self):
        sialib = _load("sialib_epoch_contiguous_two_digit_shard",
                       os.path.join(BIN, "sialib.py"))
        with tempfile.TemporaryDirectory() as d:
            sialib.CORPUS = d
            old_mind_path = sialib.siamind.MIND_PATH
            old_window = sialib.siamind.EPISODIC_DAYS
            old_bullets = sialib.MAX_EVENT_BULLETS
            sialib.siamind.MIND_PATH = os.path.join(d, "mind.json")
            sialib.siamind.EPISODIC_DAYS = 1
            sialib.MAX_EVENT_BULLETS = 1
            self.addCleanup(setattr, sialib.siamind, "MIND_PATH",
                            old_mind_path)
            self.addCleanup(setattr, sialib.siamind,
                            "EPISODIC_DAYS", old_window)
            self.addCleanup(setattr, sialib, "MAX_EVENT_BULLETS",
                            old_bullets)
            sialib.log = lambda *a: None
            subprocess.run(["git", "init", "-q", d], check=True)
            stamp = sialib.datetime.datetime(
                2026, 1, 5, 12, tzinfo=sialib.datetime.timezone.utc)
            events = [
                sialib.Event(
                    "org", stamp, "obs", f"observation {number}",
                    occurrence=f"native:two-digit-shard:{number}")
                for number in range(1, 11)
            ]
            # MAX_EVENT_BULLETS=1 forces one event per page: the base page
            # plus part-2 through part-10, so the tenth event lands on the
            # two-digit shard this grammar previously could not admit.
            sialib.update_day_page("org", "2026-01-05", events)
            event_dir = os.path.join(d, "events", "org")
            self.assertTrue(os.path.exists(
                os.path.join(event_dir, "2026-01-05-part-10.md")))

            shards = sialib._event_day_shards("org", "2026-01-05")
            self.assertEqual(len(shards), 10)

    def test_queued_operator_pin_protects_day_before_next_pulse(self):
        sialib = _load("sialib_epoch_queued_pin",
                       os.path.join(BIN, "sialib.py"))
        with tempfile.TemporaryDirectory() as root:
            corpus = os.path.join(root, "corpus")
            state = os.path.join(root, "state")
            os.makedirs(os.path.join(corpus, "events", "journal"))
            os.makedirs(state)
            old_corpus = sialib.siamind.CORPUS
            old_mind_path = sialib.siamind.MIND_PATH
            old_touch_queue = sialib.siamind.TOUCH_QUEUE
            old_window = sialib.siamind.EPISODIC_DAYS
            self.addCleanup(setattr, sialib.siamind, "CORPUS", old_corpus)
            self.addCleanup(
                setattr, sialib.siamind, "MIND_PATH", old_mind_path)
            self.addCleanup(
                setattr, sialib.siamind, "TOUCH_QUEUE", old_touch_queue)
            self.addCleanup(
                setattr, sialib.siamind, "EPISODIC_DAYS", old_window)
            sialib.CORPUS = corpus
            sialib.siamind.CORPUS = corpus
            sialib.siamind.MIND_PATH = os.path.join(state, "mind.json")
            sialib.siamind.TOUCH_QUEUE = os.path.join(
                state, "touch-queue.jsonl")
            sialib.siamind.EPISODIC_DAYS = 1
            sialib.log = lambda *_args: None
            day_slug = "events/journal/2026-01-05"
            day_path = os.path.join(corpus, day_slug + ".md")
            with open(day_path, "w", encoding="utf-8") as stream:
                stream.write(
                    '---\ntype: event-day\ntitle: "journal day"\n'
                    'tags: [journal, observation]\ndate: 2026-01-05\n'
                    'sia_counts: {"observation": 1}\n---\n# journal\n\n'
                    '## Log\n- observed\n\n## Timeline\n- held\n')
            sialib.siamind.save_mind({"nodes": {}, "edges": {}})
            subprocess.run(["git", "init", "-q", corpus], check=True)
            subprocess.run([
                "git", "-C", corpus, "-c", "user.email=t@t",
                "-c", "user.name=t", "add", "-A"], check=True)
            subprocess.run([
                "git", "-C", corpus, "-c", "user.email=t@t",
                "-c", "user.name=t", "commit", "-qm", "x"], check=True)
            self.assertTrue(sialib.siamind.queue_pin(
                day_slug, True, ts=10))

            compacted, epochs, kept = sialib.consolidate_corpus()

            self.assertEqual((compacted, epochs, kept), (0, 0, 1))
            self.assertTrue(os.path.exists(day_path))

    def test_recurring_safety_class_remains_verbatim(self):
        sialib = _load("sialib_epoch_safety",
                       os.path.join(BIN, "sialib.py"))
        with tempfile.TemporaryDirectory() as d:
            sialib.CORPUS = d
            old_mind_path = sialib.siamind.MIND_PATH
            old_window = sialib.siamind.EPISODIC_DAYS
            sialib.siamind.MIND_PATH = os.path.join(d, "mind.json")
            sialib.siamind.EPISODIC_DAYS = 1
            self.addCleanup(setattr, sialib.siamind, "MIND_PATH",
                            old_mind_path)
            self.addCleanup(setattr, sialib.siamind, "EPISODIC_DAYS",
                            old_window)
            sialib.log = lambda *a: None
            subprocess.run(["git", "init", "-q", d], check=True)
            event_dir = os.path.join(d, "events", "journal")
            os.makedirs(event_dir)
            path = os.path.join(event_dir, "2026-01-05.md")
            with open(path, "w", encoding="utf-8") as stream:
                stream.write(
                    '---\ntype: event-day\ntitle: "crash day"\n'
                    'tags: [journal, crash]\ndate: 2026-01-05\n'
                    'sia_counts: {"crash": 1}\n---\n# crash\n\n'
                    '## Log\n- observed\n\n## Timeline\n- held\n')
            # A recurring class remains protected; lifetime frequency does
            # not silently turn a safety-preservation policy into compaction.
            sialib.siamind.save_mind({
                "nodes": {}, "edges": {}, "tagn": {"crash": 1000000}})
            subprocess.run(["git", "-C", d, "-c", "user.email=t@t",
                            "-c", "user.name=t", "add", "-A"], check=True)
            subprocess.run(["git", "-C", d, "-c", "user.email=t@t",
                            "-c", "user.name=t", "commit", "-qm", "x"],
                           check=True)

            compacted, epochs, kept = sialib.consolidate_corpus()
            self.assertEqual((compacted, epochs, kept), (0, 0, 1))
            self.assertTrue(os.path.exists(path))

    def test_merge_extends_not_overwrites(self):
        sialib = _load("sialib_e", os.path.join(BIN, "sialib.py"))
        with tempfile.TemporaryDirectory() as d:
            sialib.CORPUS = d
            old_mind_path = sialib.siamind.MIND_PATH
            sialib.siamind.MIND_PATH = os.path.join(d, "mind.json")
            self.addCleanup(setattr, sialib.siamind, "MIND_PATH",
                            old_mind_path)
            sialib.log = lambda *a: None
            subprocess.run(["git", "init", "-q", d], check=True)
            os.makedirs(os.path.join(d, "events/org"))
            # two old day pages, same ISO week, well past the window
            for day, obs in (("2026-01-05", 4), ("2026-01-06", 3)):
                p = os.path.join(d, f"events/org/{day}.md")
                with open(p, "w") as stream:
                    stream.write(
                        f'---\ntype: event-day\ntitle: "org {day}"\n'
                        f'tags: [org, obs]\ndate: {day}\n'
                        f'sia_counts: {{"obs": {obs}}}\n---\n# org\n\n## Log\n'
                        f'- 01:00:00Z obs thing\n\n## Timeline\n'
                        f'- **{day}** — {obs}\n')
            subprocess.run(["git", "-C", d, "-c", "user.email=t@t",
                            "-c", "user.name=t", "add", "-A"], check=True)
            subprocess.run(["git", "-C", d, "-c", "user.email=t@t",
                            "-c", "user.name=t", "commit", "-qm", "x"],
                           check=True)
            os.environ["SIA_EPISODIC_DAYS"] = "1"
            n1, e1, _ = sialib.consolidate_corpus()
            self.assertGreaterEqual(n1, 2)
            epoch = None
            for root, _, files in os.walk(os.path.join(d, "epochs")):
                for f in files:
                    epoch = os.path.join(root, f)
            self.assertIsNotNone(epoch, "epoch page must exist")
            import re
            with open(epoch) as stream:
                epoch_text = stream.read()
            c1 = json.loads(re.search(r"^sia_counts: (.*)$",
                                      epoch_text, re.M).group(1))
            self.assertEqual(c1["obs"], 7)
            # add another old day for the SAME week, commit, re-consolidate
            p = os.path.join(d, "events/org/2026-01-07.md")
            with open(p, "w") as stream:
                stream.write(
                    '---\ntype: event-day\ntitle: "org 2026-01-07"\n'
                    'tags: [org, obs]\ndate: 2026-01-07\n'
                    'sia_counts: {"obs": 5}\n---\n# org\n\n## Log\n'
                    '- 01:00:00Z obs thing\n\n## Timeline\n'
                    '- **2026-01-07** — 5\n')
            subprocess.run(["git", "-C", d, "-c", "user.email=t@t",
                            "-c", "user.name=t", "add", "-A"], check=True)
            subprocess.run(["git", "-C", d, "-c", "user.email=t@t",
                            "-c", "user.name=t", "commit", "-qm", "y"],
                           check=True)
            sialib.consolidate_corpus()
            with open(epoch) as stream:
                epoch_text = stream.read()
            c2 = json.loads(re.search(r"^sia_counts: (.*)$",
                                      epoch_text, re.M).group(1))
            self.assertEqual(c2["obs"], 12, "merge must sum, not replace")

    def test_partial_source_cleanup_replays_without_double_counting(self):
        sialib = _load("sialib_epoch_replay",
                       os.path.join(BIN, "sialib.py"))
        with tempfile.TemporaryDirectory() as d:
            sialib.CORPUS = d
            old_mind_path = sialib.siamind.MIND_PATH
            sialib.siamind.MIND_PATH = os.path.join(d, "mind.json")
            self.addCleanup(setattr, sialib.siamind, "MIND_PATH",
                            old_mind_path)
            sialib.log = lambda *a: None
            subprocess.run(["git", "init", "-q", d], check=True)
            event_dir = os.path.join(d, "events/org")
            os.makedirs(event_dir)
            for day, obs in (("2026-01-05", 4), ("2026-01-06", 3)):
                path = os.path.join(event_dir, day + ".md")
                with open(path, "w") as stream:
                    stream.write(
                        f'---\ntype: event-day\ntitle: "org {day}"\n'
                        f'tags: [org, obs]\ndate: {day}\n'
                        f'sia_counts: {{"obs": {obs}}}\n---\n# org\n\n'
                        f'## Log\n- 01:00:00Z obs thing\n\n## Timeline\n'
                        f'- **{day}** — {obs}\n')
            subprocess.run(["git", "-C", d, "-c", "user.email=t@t",
                            "-c", "user.name=t", "add", "-A"], check=True)
            subprocess.run(["git", "-C", d, "-c", "user.email=t@t",
                            "-c", "user.name=t", "commit", "-qm", "x"],
                           check=True)

            real_unlink = sialib.os.unlink
            removed = []

            def interrupt_cleanup(path):
                if path.startswith(event_dir + os.sep):
                    if removed:
                        raise OSError("simulated interruption")
                    real_unlink(path)
                    removed.append(path)
                    return
                real_unlink(path)

            with mock.patch.object(sialib.os, "unlink",
                                   side_effect=interrupt_cleanup):
                with self.assertRaisesRegex(OSError,
                                            "simulated interruption"):
                    sialib.consolidate_corpus()

            epoch = next(
                os.path.join(root, filename)
                for root, _dirs, files in os.walk(os.path.join(d, "epochs"))
                for filename in files)
            with open(epoch) as stream:
                interrupted_text = stream.read()
            interrupted_counts = json.loads(re.search(
                r"^sia_counts: (.*)$", interrupted_text, re.M).group(1))

            sialib.consolidate_corpus()
            with open(epoch) as stream:
                recovered_text = stream.read()
            recovered_counts = json.loads(re.search(
                r"^sia_counts: (.*)$", recovered_text, re.M).group(1))
            self.assertEqual(recovered_counts, interrupted_counts)
            self.assertEqual(os.listdir(event_dir), [])
            self.assertRegex(recovered_text, r"(?m)^sia_sources: \[")

    def test_multi_shard_cleanup_recovers_missing_base_and_hole(self):
        for mode in ("missing-base", "missing-middle"):
            with self.subTest(mode=mode), tempfile.TemporaryDirectory() as d:
                sialib = _load(
                    "sialib_epoch_shard_" + mode.replace("-", "_"),
                    os.path.join(BIN, "sialib.py"))
                sialib.CORPUS = d
                old_mind_path = sialib.siamind.MIND_PATH
                old_window = sialib.siamind.EPISODIC_DAYS
                old_bullets = sialib.MAX_EVENT_BULLETS
                sialib.siamind.MIND_PATH = os.path.join(d, "mind.json")
                sialib.siamind.EPISODIC_DAYS = 1
                sialib.MAX_EVENT_BULLETS = 1
                self.addCleanup(setattr, sialib.siamind, "MIND_PATH",
                                old_mind_path)
                self.addCleanup(setattr, sialib.siamind,
                                "EPISODIC_DAYS", old_window)
                self.addCleanup(setattr, sialib, "MAX_EVENT_BULLETS",
                                old_bullets)
                sialib.log = lambda *a: None
                subprocess.run(["git", "init", "-q", d], check=True)
                stamp = sialib.datetime.datetime(
                    2026, 1, 5, 12, tzinfo=sialib.datetime.timezone.utc)
                events = [
                    sialib.Event(
                        "org", stamp, "obs", f"observation {number}",
                        occurrence=f"native:shard:{number}")
                    for number in (1, 2, 3)
                ]
                sialib.update_day_page("org", "2026-01-05", events)
                subprocess.run(
                    ["git", "-C", d, "-c", "user.email=t@t", "-c",
                     "user.name=t", "add", "-A"], check=True)
                subprocess.run(
                    ["git", "-C", d, "-c", "user.email=t@t", "-c",
                     "user.name=t", "commit", "-qm", "sources"],
                    check=True)

                event_dir = os.path.join(d, "events", "org")
                base = os.path.join(event_dir, "2026-01-05.md")
                middle = os.path.join(
                    event_dir, "2026-01-05-part-2.md")
                last = os.path.join(event_dir, "2026-01-05-part-3.md")
                real_unlink = sialib.os.unlink
                removed = []

                def interrupt_cleanup(path):
                    if path.startswith(event_dir + os.sep):
                        if mode == "missing-base" and not removed:
                            real_unlink(path)
                            removed.append(path)
                            return
                        raise OSError("simulated shard cleanup interruption")
                    real_unlink(path)

                with mock.patch.object(
                        sialib.os, "unlink", side_effect=interrupt_cleanup):
                    with self.assertRaisesRegex(
                            OSError, "simulated shard cleanup interruption"):
                        sialib.consolidate_corpus()

                epoch = sialib.corpus_path(
                    sialib._epoch_slug_for_day("org", "2026-01-05"))
                with open(epoch, encoding="utf-8") as stream:
                    epoch_before = stream.read()
                manifest = json.loads(re.search(
                    r"^sia_source_manifest: (.*)$", epoch_before,
                    re.M).group(1))
                self.assertEqual(len(manifest), len(events))
                index_files = [
                    os.path.join(root, filename)
                    for root, _dirs, files in os.walk(
                        os.path.join(d, "event-index"))
                    for filename in files if filename.endswith(".json")
                ]
                self.assertEqual(len(index_files), len(events))

                if mode == "missing-base":
                    self.assertFalse(os.path.exists(base))
                    self.assertTrue(os.path.exists(middle))
                else:
                    real_unlink(middle)
                    self.assertTrue(os.path.exists(base))
                self.assertTrue(os.path.exists(last))

                sialib.consolidate_corpus()
                with open(epoch, encoding="utf-8") as stream:
                    self.assertEqual(stream.read(), epoch_before)
                self.assertEqual(os.listdir(event_dir), [])

    def test_multi_shard_recovery_refuses_lineage_conflict(self):
        sialib = _load("sialib_epoch_shard_conflict",
                       os.path.join(BIN, "sialib.py"))
        with tempfile.TemporaryDirectory() as d:
            sialib.CORPUS = d
            old_mind_path = sialib.siamind.MIND_PATH
            old_window = sialib.siamind.EPISODIC_DAYS
            old_bullets = sialib.MAX_EVENT_BULLETS
            sialib.siamind.MIND_PATH = os.path.join(d, "mind.json")
            sialib.siamind.EPISODIC_DAYS = 1
            sialib.MAX_EVENT_BULLETS = 1
            self.addCleanup(setattr, sialib.siamind, "MIND_PATH",
                            old_mind_path)
            self.addCleanup(setattr, sialib.siamind, "EPISODIC_DAYS",
                            old_window)
            self.addCleanup(setattr, sialib, "MAX_EVENT_BULLETS",
                            old_bullets)
            sialib.log = lambda *a: None
            subprocess.run(["git", "init", "-q", d], check=True)
            stamp = sialib.datetime.datetime(
                2026, 1, 5, 12, tzinfo=sialib.datetime.timezone.utc)
            events = [
                sialib.Event("org", stamp, "obs", f"event {number}",
                             occurrence=f"native:conflict:{number}")
                for number in (1, 2, 3)
            ]
            sialib.update_day_page("org", "2026-01-05", events)
            subprocess.run(
                ["git", "-C", d, "-c", "user.email=t@t", "-c",
                 "user.name=t", "add", "-A"], check=True)
            subprocess.run(
                ["git", "-C", d, "-c", "user.email=t@t", "-c",
                 "user.name=t", "commit", "-qm", "sources"], check=True)

            event_dir = os.path.join(d, "events", "org")
            real_unlink = sialib.os.unlink

            def stop_before_cleanup(path):
                if path.startswith(event_dir + os.sep):
                    raise OSError("simulated pre-cleanup interruption")
                real_unlink(path)

            with mock.patch.object(
                    sialib.os, "unlink", side_effect=stop_before_cleanup):
                with self.assertRaisesRegex(
                        OSError, "simulated pre-cleanup interruption"):
                    sialib.consolidate_corpus()

            middle = os.path.join(event_dir, "2026-01-05-part-2.md")
            with open(middle, "a", encoding="utf-8") as stream:
                stream.write("\nconflicting bytes\n")
            epoch = sialib.corpus_path(
                sialib._epoch_slug_for_day("org", "2026-01-05"))
            with open(epoch, encoding="utf-8") as stream:
                epoch_before = stream.read()

            with self.assertRaisesRegex(
                    RuntimeError, "conflicts with epoch source lineage"):
                sialib.consolidate_corpus()
            with open(epoch, encoding="utf-8") as stream:
                self.assertEqual(stream.read(), epoch_before)
            self.assertEqual(len(os.listdir(event_dir)), len(events))

    def test_over_capacity_week_is_retained_without_partial_mutation(self):
        for mode in ("source-records", "source-bytes", "event-index",
                     "rendered-epoch"):
            with self.subTest(mode=mode), tempfile.TemporaryDirectory() as d:
                sialib = _load(
                    "sialib_epoch_capacity_" + mode.replace("-", "_"),
                    os.path.join(BIN, "sialib.py"))
                sialib.CORPUS = d
                old_mind_path = sialib.siamind.MIND_PATH
                old_window = sialib.siamind.EPISODIC_DAYS
                sialib.siamind.MIND_PATH = os.path.join(d, "mind.json")
                sialib.siamind.EPISODIC_DAYS = 1
                self.addCleanup(setattr, sialib.siamind, "MIND_PATH",
                                old_mind_path)
                self.addCleanup(setattr, sialib.siamind,
                                "EPISODIC_DAYS", old_window)
                sialib.log = lambda *a: None
                subprocess.run(["git", "init", "-q", d], check=True)
                stamp = sialib.datetime.datetime(
                    2026, 1, 5, 12, tzinfo=sialib.datetime.timezone.utc)
                events = [
                    sialib.Event(
                        "org", stamp, "obs", f"capacity event {number}",
                        occurrence=f"native:capacity:{mode}:{number}")
                    for number in (1, 2, 3)
                ]
                if mode == "source-records":
                    sialib.MAX_EVENT_BULLETS = 1
                    sialib.MAX_EPOCH_SOURCE_RECORDS = 2
                sialib.update_day_page("org", "2026-01-05", events)
                if mode == "source-bytes":
                    sialib.MAX_EPOCH_SOURCE_MANIFEST_BYTES = 1
                elif mode == "event-index":
                    sialib.MAX_EVENT_INDEX_RECORDS = 1
                elif mode == "rendered-epoch":
                    sialib.MAX_EPOCH_PAGE_BYTES = 1
                subprocess.run(
                    ["git", "-C", d, "-c", "user.email=t@t", "-c",
                     "user.name=t", "add", "-A"], check=True)
                subprocess.run(
                    ["git", "-C", d, "-c", "user.email=t@t", "-c",
                     "user.name=t", "commit", "-qm", "sources"],
                    check=True)

                result = sialib.consolidate_corpus()
                self.assertEqual(result, (0, 0, 1))
                event_dir = os.path.join(d, "events", "org")
                self.assertTrue(os.listdir(event_dir))
                self.assertFalse(os.path.exists(os.path.join(d, "epochs")))
                self.assertFalse(
                    os.path.exists(os.path.join(d, "event-index")))

    def test_legacy_epoch_metadata_capacity_retains_exact_source(self):
        sialib = _load("sialib_epoch_legacy_capacity",
                       os.path.join(BIN, "sialib.py"))
        with tempfile.TemporaryDirectory() as d:
            sialib.CORPUS = d
            old_mind_path = sialib.siamind.MIND_PATH
            old_window = sialib.siamind.EPISODIC_DAYS
            sialib.siamind.MIND_PATH = os.path.join(d, "mind.json")
            sialib.siamind.EPISODIC_DAYS = 1
            self.addCleanup(setattr, sialib.siamind, "MIND_PATH",
                            old_mind_path)
            self.addCleanup(setattr, sialib.siamind, "EPISODIC_DAYS",
                            old_window)
            sialib.log = lambda *a: None
            subprocess.run(["git", "init", "-q", d], check=True)
            stamp = sialib.datetime.datetime(
                2026, 1, 5, 12, tzinfo=sialib.datetime.timezone.utc)
            event = sialib.Event(
                "org", stamp, "obs", "legacy recovery source",
                occurrence="native:legacy-capacity")
            sialib.update_day_page("org", "2026-01-05", [event])
            relative = "events/org/2026-01-05.md"
            source_path = os.path.join(d, relative)
            with open(source_path, "rb") as stream:
                source_bytes = stream.read()
            source_id = hashlib.sha256(
                relative.encode("utf-8") + b"\0" + source_bytes).hexdigest()
            epoch_slug = sialib._epoch_slug_for_day(
                "org", "2026-01-05")
            sialib.write_page(
                epoch_slug,
                ["type: epoch", sialib.fm_title("legacy epoch"),
                 "tags: [org]", "date: 2026-01-05",
                 "sia_sources: " + json.dumps(
                     [source_id], separators=(",", ":")),
                 'sia_dates: ["2026-01-05"]',
                 'sia_counts: {"obs": 1}'],
                "# legacy epoch\n\n"
                "Consolidated from 1 day-memories "
                "(2026-01-05 … 2026-01-05).\n")
            subprocess.run(
                ["git", "-C", d, "-c", "user.email=t@t", "-c",
                 "user.name=t", "add", "-A"], check=True)
            subprocess.run(
                ["git", "-C", d, "-c", "user.email=t@t", "-c",
                 "user.name=t", "commit", "-qm", "legacy state"],
                check=True)
            epoch_path = sialib.corpus_path(epoch_slug)
            with open(epoch_path, encoding="utf-8") as stream:
                epoch_before = stream.read()
            sialib.MAX_EPOCH_PAGE_BYTES = len(epoch_before.encode("utf-8"))

            self.assertEqual(sialib.consolidate_corpus(), (0, 0, 1))
            self.assertTrue(os.path.exists(source_path))
            with open(epoch_path, encoding="utf-8") as stream:
                self.assertEqual(stream.read(), epoch_before)
            self.assertFalse(
                os.path.exists(os.path.join(d, "event-index")))

    def test_first_event_index_publish_fsyncs_new_directory_links(self):
        sialib = _load("sialib_epoch_index_durability",
                       os.path.join(BIN, "sialib.py"))
        with tempfile.TemporaryDirectory() as d:
            sialib.CORPUS = d
            old_mind_path = sialib.siamind.MIND_PATH
            old_window = sialib.siamind.EPISODIC_DAYS
            sialib.siamind.MIND_PATH = os.path.join(d, "mind.json")
            sialib.siamind.EPISODIC_DAYS = 1
            self.addCleanup(setattr, sialib.siamind, "MIND_PATH",
                            old_mind_path)
            self.addCleanup(setattr, sialib.siamind, "EPISODIC_DAYS",
                            old_window)
            sialib.log = lambda *a: None
            subprocess.run(["git", "init", "-q", d], check=True)
            stamp = sialib.datetime.datetime(
                2026, 1, 5, 12, tzinfo=sialib.datetime.timezone.utc)
            event = sialib.Event(
                "org", stamp, "obs", "durable event index",
                occurrence="native:index-durability")
            sialib.update_day_page("org", "2026-01-05", [event])
            subprocess.run(
                ["git", "-C", d, "-c", "user.email=t@t", "-c",
                 "user.name=t", "add", "-A"], check=True)
            subprocess.run(
                ["git", "-C", d, "-c", "user.email=t@t", "-c",
                 "user.name=t", "commit", "-qm", "source"], check=True)
            real_fsync = sialib.os.fsync
            synced = set()

            def track_fsync(fd):
                try:
                    synced.add(os.path.realpath(
                        os.readlink(f"/proc/self/fd/{fd}")))
                except OSError:
                    pass
                return real_fsync(fd)

            with mock.patch.object(
                    sialib.os, "fsync", side_effect=track_fsync):
                sialib.consolidate_corpus()

            event_id = sialib.event_memory_identity(event)
            index_leaf = os.path.join(
                d, sialib._event_index_relative("org", event_id))
            prefix = os.path.dirname(index_leaf)
            expected = {
                os.path.realpath(d),
                os.path.realpath(os.path.join(d, "event-index")),
                os.path.realpath(os.path.join(d, "event-index", "org")),
                os.path.realpath(prefix),
            }
            self.assertTrue(expected <= synced)
            self.assertTrue(os.path.isfile(index_leaf))

    def test_event_index_directory_retry_repairs_visible_chain(self):
        sialib = _load("sialib_epoch_index_directory_retry",
                       os.path.join(BIN, "sialib.py"))
        with tempfile.TemporaryDirectory() as d:
            sialib.CORPUS = d
            old_mind_path = sialib.siamind.MIND_PATH
            old_window = sialib.siamind.EPISODIC_DAYS
            sialib.siamind.MIND_PATH = os.path.join(d, "mind.json")
            sialib.siamind.EPISODIC_DAYS = 1
            self.addCleanup(setattr, sialib.siamind, "MIND_PATH",
                            old_mind_path)
            self.addCleanup(setattr, sialib.siamind, "EPISODIC_DAYS",
                            old_window)
            sialib.log = lambda *a: None
            subprocess.run(["git", "init", "-q", d], check=True)
            stamp = sialib.datetime.datetime(
                2026, 1, 5, 12, tzinfo=sialib.datetime.timezone.utc)
            event = sialib.Event(
                "org", stamp, "obs", "retry durable event index",
                occurrence="native:index-directory-retry")
            sialib.update_day_page("org", "2026-01-05", [event])
            subprocess.run(
                ["git", "-C", d, "-c", "user.email=t@t", "-c",
                 "user.name=t", "add", "-A"], check=True)
            subprocess.run(
                ["git", "-C", d, "-c", "user.email=t@t", "-c",
                 "user.name=t", "commit", "-qm", "source"], check=True)
            event_id = sialib.event_memory_identity(event)
            index_leaf = os.path.join(
                d, sialib._event_index_relative("org", event_id))
            prefix = os.path.dirname(index_leaf)
            organ_directory = os.path.dirname(prefix)
            source_path = sialib.corpus_path(
                sialib.day_slug("org", "2026-01-05"))
            real_fsync = sialib.os.fsync
            organ_syncs = []

            def fail_last_parent_sync(fd):
                target = os.path.realpath(os.readlink(f"/proc/self/fd/{fd}"))
                if target == os.path.realpath(organ_directory):
                    organ_syncs.append(target)
                    if len(organ_syncs) == 2:
                        raise OSError("simulated event-index parent fsync")
                return real_fsync(fd)

            with mock.patch.object(
                    sialib.os, "fsync", side_effect=fail_last_parent_sync):
                with self.assertRaisesRegex(
                        OSError, "simulated event-index parent fsync"):
                    sialib.consolidate_corpus()
            self.assertTrue(os.path.isdir(prefix))
            self.assertFalse(os.path.exists(index_leaf))
            self.assertTrue(os.path.exists(source_path))

            retry_synced = set()

            def track_retry(fd):
                retry_synced.add(os.path.realpath(
                    os.readlink(f"/proc/self/fd/{fd}")))
                return real_fsync(fd)

            with mock.patch.object(sialib.os, "fsync", side_effect=track_retry):
                sialib.consolidate_corpus()
            self.assertTrue({os.path.realpath(prefix),
                             os.path.realpath(organ_directory)}
                            <= retry_synced)
            self.assertTrue(os.path.isfile(index_leaf))
            self.assertFalse(os.path.exists(source_path))

    def test_consolidated_occurrence_index_suppresses_replay_and_conflict(self):
        sialib = _load("sialib_epoch_event_index",
                       os.path.join(BIN, "sialib.py"))
        with tempfile.TemporaryDirectory() as d:
            sialib.CORPUS = d
            old_mind_path = sialib.siamind.MIND_PATH
            old_window = sialib.siamind.EPISODIC_DAYS
            sialib.siamind.MIND_PATH = os.path.join(d, "mind.json")
            sialib.siamind.EPISODIC_DAYS = 1
            self.addCleanup(setattr, sialib.siamind, "MIND_PATH",
                            old_mind_path)
            self.addCleanup(setattr, sialib.siamind, "EPISODIC_DAYS",
                            old_window)
            sialib.log = lambda *a: None
            subprocess.run(["git", "init", "-q", d], check=True)
            old_stamp = sialib.datetime.datetime(
                2026, 1, 5, 12, tzinfo=sialib.datetime.timezone.utc)
            original = sialib.Event(
                "org", old_stamp, "obs", "source-native observation",
                links=("projects/demo",), tags=("remembered",),
                occurrence="native:stable:one")
            sialib.update_day_page("org", "2026-01-05", [original])
            subprocess.run(
                ["git", "-C", d, "-c", "user.email=t@t", "-c",
                 "user.name=t", "add", "-A"], check=True)
            subprocess.run(
                ["git", "-C", d, "-c", "user.email=t@t", "-c",
                 "user.name=t", "commit", "-qm", "source"], check=True)
            sialib.consolidate_corpus()

            event_id = sialib.event_memory_identity(original)
            entry = sialib._read_event_index_entry("org", event_id)
            self.assertIsNotNone(entry)
            self.assertEqual(entry["semantic_id"],
                             sialib.event_semantic_identity(original))
            self.assertFalse(sialib.page_exists(
                sialib.day_slug("org", "2026-01-05")))

            later_stamp = sialib.datetime.datetime(
                2026, 8, 29, 20, tzinfo=sialib.datetime.timezone.utc)
            replay = sialib.Event(
                "org", later_stamp, "obs", "source-native observation",
                links=("projects/demo",), tags=("remembered",),
                occurrence="native:stable:one")
            _pages, appended, admitted = sialib.update_day_page(
                "org", "2026-08-29", [replay])
            self.assertEqual(appended, [])
            self.assertEqual([slug for _event, slug in admitted],
                             [entry["epoch_slug"]])
            self.assertFalse(sialib.page_exists(
                sialib.day_slug("org", "2026-08-29")))

            conflict = sialib.Event(
                "org", later_stamp, "changed", "changed meaning",
                occurrence="native:stable:one")
            with self.assertRaisesRegex(
                    ValueError, "conflicts with another day page"):
                sialib.update_day_page("org", "2026-08-29", [conflict])

            novel = sialib.Event(
                "org", later_stamp, "obs", "new source observation",
                occurrence="native:stable:two")
            _pages, appended, _admitted = sialib.update_day_page(
                "org", "2026-08-29", [novel])
            self.assertEqual(appended, [novel])
            self.assertTrue(sialib.page_exists(
                sialib.day_slug("org", "2026-08-29")))

    def test_missing_consolidated_event_leaf_refuses_exact_replay(self):
        sialib = _load("sialib_epoch_missing_event_leaf",
                       os.path.join(BIN, "sialib.py"))
        with tempfile.TemporaryDirectory() as d:
            sialib.CORPUS = d
            old_mind_path = sialib.siamind.MIND_PATH
            old_window = sialib.siamind.EPISODIC_DAYS
            sialib.siamind.MIND_PATH = os.path.join(d, "mind.json")
            sialib.siamind.EPISODIC_DAYS = 1
            self.addCleanup(setattr, sialib.siamind, "MIND_PATH",
                            old_mind_path)
            self.addCleanup(setattr, sialib.siamind, "EPISODIC_DAYS",
                            old_window)
            sialib.log = lambda *_args: None
            subprocess.run(["git", "init", "-q", d], check=True)
            stamp = sialib.datetime.datetime(
                2026, 1, 5, 12, tzinfo=sialib.datetime.timezone.utc)
            original = sialib.Event(
                "org", stamp, "obs", "indexed occurrence",
                occurrence="native:completeness:missing")
            sialib.update_day_page("org", "2026-01-05", [original])
            subprocess.run(
                ["git", "-C", d, "-c", "user.email=t@t", "-c",
                 "user.name=t", "add", "-A"], check=True)
            subprocess.run(
                ["git", "-C", d, "-c", "user.email=t@t", "-c",
                 "user.name=t", "commit", "-qm", "source"], check=True)
            sialib.consolidate_corpus()

            event_id = sialib.event_memory_identity(original)
            leaf = os.path.join(
                d, sialib._event_index_relative("org", event_id))
            os.unlink(leaf)
            later = sialib.datetime.datetime(
                2026, 8, 29, 20, tzinfo=sialib.datetime.timezone.utc)
            replay = sialib.Event(
                "org", later, "obs", "indexed occurrence",
                occurrence="native:completeness:missing")

            with self.assertRaisesRegex(
                    ValueError, "consolidated event index leaf is missing"):
                sialib.update_day_page("org", "2026-08-29", [replay])
            self.assertFalse(sialib.page_exists(
                sialib.day_slug("org", "2026-08-29")))

            novel = sialib.Event(
                "org", later, "obs", "genuinely novel occurrence",
                occurrence="native:completeness:novel")
            _pages, appended, _admitted = sialib.update_day_page(
                "org", "2026-08-29", [novel])
            self.assertEqual(appended, [novel])

    def test_manifest_only_epoch_reconstructs_completeness_from_retained_sources(self):
        sialib = _load("sialib_epoch_missing_completeness",
                       os.path.join(BIN, "sialib.py"))
        with tempfile.TemporaryDirectory() as d:
            sialib.CORPUS = d
            old_mind_path = sialib.siamind.MIND_PATH
            old_window = sialib.siamind.EPISODIC_DAYS
            sialib.siamind.MIND_PATH = os.path.join(d, "mind.json")
            sialib.siamind.EPISODIC_DAYS = 1
            self.addCleanup(setattr, sialib.siamind, "MIND_PATH",
                            old_mind_path)
            self.addCleanup(setattr, sialib.siamind, "EPISODIC_DAYS",
                            old_window)
            sialib.log = lambda *_args: None
            subprocess.run(["git", "init", "-q", d], check=True)
            stamp = sialib.datetime.datetime(
                2026, 1, 5, 12, tzinfo=sialib.datetime.timezone.utc)
            original = sialib.Event(
                "org", stamp, "obs", "indexed occurrence",
                occurrence="native:completeness:authority")
            sialib.update_day_page("org", "2026-01-05", [original])
            subprocess.run(
                ["git", "-C", d, "-c", "user.email=t@t", "-c",
                 "user.name=t", "add", "-A"], check=True)
            subprocess.run(
                ["git", "-C", d, "-c", "user.email=t@t", "-c",
                 "user.name=t", "commit", "-qm", "source"], check=True)
            sialib.consolidate_corpus()

            epoch_path = sialib.corpus_path(
                sialib._epoch_slug_for_day("org", "2026-01-05"))
            with open(epoch_path, encoding="utf-8") as stream:
                epoch_text = stream.read()
            epoch_text = re.sub(
                r"(?m)^sia_event_ids: .*\n", "", epoch_text)
            with open(epoch_path, "w", encoding="utf-8") as stream:
                stream.write(epoch_text)
            later = sialib.datetime.datetime(
                2026, 8, 29, 20, tzinfo=sialib.datetime.timezone.utc)
            novel = sialib.Event(
                "org", later, "obs", "genuinely novel occurrence",
                occurrence="native:completeness:unknown")

            # An epoch that declares source lineage but no event roster is
            # the shape every 1.7.x release wrote. Its completeness claim is
            # reconstructed from the exact retained sources (here: the
            # compacted day page in corpus git history), so a novel
            # occurrence is admitted and the consolidated one is not
            # re-admitted as new.
            _pages, appended, _admitted = sialib.update_day_page(
                "org", "2026-08-29", [novel])
            self.assertEqual(appended, [novel])
            self.assertTrue(sialib.page_exists(
                sialib.day_slug("org", "2026-08-29")))
            replayed = sialib.Event(
                "org", stamp, "obs", "indexed occurrence",
                occurrence="native:completeness:authority")
            _pages, appended, _admitted = sialib.update_day_page(
                "org", "2026-01-05", [replayed])
            self.assertEqual(appended, [],
                             "a consolidated occurrence must not be re-admitted")

            # A manifest whose retained source cannot be found by lineage
            # digest still refuses, naming the source, instead of guessing.
            with open(epoch_path, encoding="utf-8") as stream:
                epoch_text = stream.read()
            digests = set(re.findall(r'"sha256":"([0-9a-f]{64})"', epoch_text))
            self.assertEqual(len(digests), 1)
            # The same lineage digest names the source in sia_sources and in
            # the manifest; keep the page self-consistent but point it at a
            # source that was never retained.
            broken = epoch_text.replace(next(iter(digests)), "f" * 64)
            self.assertNotEqual(broken, epoch_text)
            with open(epoch_path, "w", encoding="utf-8") as stream:
                stream.write(broken)
            much_later = sialib.datetime.datetime(
                2026, 8, 30, 20, tzinfo=sialib.datetime.timezone.utc)
            second = sialib.Event(
                "org", much_later, "obs", "second novel occurrence",
                occurrence="native:completeness:second")
            with self.assertRaisesRegex(
                    ValueError,
                    "event-index completeness is unavailable: .*retained "
                    "source events/org/2026-01-05.md with lineage digest "
                    "ffffffffffff is in neither the corpus tree nor its git "
                    "history"):
                sialib.update_day_page("org", "2026-08-30", [second])
            self.assertFalse(sialib.page_exists(
                sialib.day_slug("org", "2026-08-30")))

    def test_pre_index_legacy_epoch_does_not_block_novel_occurrence(self):
        sialib = _load("sialib_epoch_pre_index_compatibility",
                       os.path.join(BIN, "sialib.py"))
        with tempfile.TemporaryDirectory() as d:
            sialib.CORPUS = d
            old_mind_path = sialib.siamind.MIND_PATH
            sialib.siamind.MIND_PATH = os.path.join(d, "mind.json")
            self.addCleanup(setattr, sialib.siamind, "MIND_PATH",
                            old_mind_path)
            legacy_slug = sialib._epoch_slug_for_day(
                "org", "2026-01-05")
            legacy_source = "0" * 64
            sialib.write_page(
                legacy_slug,
                ["type: epoch", sialib.fm_title("legacy epoch"),
                 "tags: [org]", "date: 2026-01-05",
                 "sia_sources: " + json.dumps([legacy_source]),
                 'sia_dates: ["2026-01-05"]',
                 'sia_counts: {"obs": 1}'],
                "# legacy epoch\n\n"
                "Consolidated from 1 day-memories "
                "(2026-01-05 … 2026-01-05).\n")
            stamp = sialib.datetime.datetime(
                2026, 8, 29, 20, tzinfo=sialib.datetime.timezone.utc)
            novel = sialib.Event(
                "org", stamp, "obs", "new after legacy epoch",
                occurrence="native:legacy:novel")

            _pages, appended, _admitted = sialib.update_day_page(
                "org", "2026-08-29", [novel])
            self.assertEqual(appended, [novel])
            self.assertTrue(sialib.page_exists(
                sialib.day_slug("org", "2026-08-29")))

    def test_event_completeness_precedes_leaf_publish_and_source_unlink(self):
        sialib = _load("sialib_epoch_completeness_ordering",
                       os.path.join(BIN, "sialib.py"))
        with tempfile.TemporaryDirectory() as d:
            sialib.CORPUS = d
            old_mind_path = sialib.siamind.MIND_PATH
            old_window = sialib.siamind.EPISODIC_DAYS
            sialib.siamind.MIND_PATH = os.path.join(d, "mind.json")
            sialib.siamind.EPISODIC_DAYS = 1
            self.addCleanup(setattr, sialib.siamind, "MIND_PATH",
                            old_mind_path)
            self.addCleanup(setattr, sialib.siamind, "EPISODIC_DAYS",
                            old_window)
            sialib.log = lambda *_args: None
            subprocess.run(["git", "init", "-q", d], check=True)
            stamp = sialib.datetime.datetime(
                2026, 1, 5, 12, tzinfo=sialib.datetime.timezone.utc)
            event = sialib.Event(
                "org", stamp, "obs", "ordered completeness",
                occurrence="native:completeness:ordering")
            sialib.update_day_page("org", "2026-01-05", [event])
            subprocess.run(
                ["git", "-C", d, "-c", "user.email=t@t", "-c",
                 "user.name=t", "add", "-A"], check=True)
            subprocess.run(
                ["git", "-C", d, "-c", "user.email=t@t", "-c",
                 "user.name=t", "commit", "-qm", "source"], check=True)
            source_path = sialib.corpus_path(
                sialib.day_slug("org", "2026-01-05"))
            epoch_path = sialib.corpus_path(
                sialib._epoch_slug_for_day("org", "2026-01-05"))
            event_id = sialib.event_memory_identity(event)
            real_publish = sialib._publish_event_index_entries
            observed = []

            def inspect_epoch_then_publish(entries):
                self.assertTrue(os.path.isfile(source_path))
                with open(epoch_path, encoding="utf-8") as stream:
                    epoch_text = stream.read()
                ids = json.loads(re.search(
                    r"^sia_event_ids: (.*)$", epoch_text,
                    re.M).group(1))
                self.assertEqual(ids, [event_id])
                observed.append(event_id)
                return real_publish(entries)

            with mock.patch.object(
                    sialib, "_publish_event_index_entries",
                    side_effect=inspect_epoch_then_publish):
                sialib.consolidate_corpus()

            self.assertEqual(observed, [event_id])
            self.assertFalse(os.path.exists(source_path))

    def test_event_completeness_capacity_retains_new_source_and_old_epoch(self):
        sialib = _load("sialib_epoch_completeness_capacity",
                       os.path.join(BIN, "sialib.py"))
        with tempfile.TemporaryDirectory() as d:
            sialib.CORPUS = d
            old_mind_path = sialib.siamind.MIND_PATH
            old_window = sialib.siamind.EPISODIC_DAYS
            sialib.siamind.MIND_PATH = os.path.join(d, "mind.json")
            sialib.siamind.EPISODIC_DAYS = 1
            self.addCleanup(setattr, sialib.siamind, "MIND_PATH",
                            old_mind_path)
            self.addCleanup(setattr, sialib.siamind, "EPISODIC_DAYS",
                            old_window)
            sialib.log = lambda *_args: None
            subprocess.run(["git", "init", "-q", d], check=True)
            stamp = sialib.datetime.datetime(
                2026, 1, 5, 12, tzinfo=sialib.datetime.timezone.utc)
            first = sialib.Event(
                "org", stamp, "obs", "first indexed occurrence",
                occurrence="native:completeness:capacity:first")
            sialib.update_day_page("org", "2026-01-05", [first])
            subprocess.run(
                ["git", "-C", d, "-c", "user.email=t@t", "-c",
                 "user.name=t", "add", "-A"], check=True)
            subprocess.run(
                ["git", "-C", d, "-c", "user.email=t@t", "-c",
                 "user.name=t", "commit", "-qm", "first"], check=True)
            sialib.consolidate_corpus()

            epoch_path = sialib.corpus_path(
                sialib._epoch_slug_for_day("org", "2026-01-05"))
            with open(epoch_path, encoding="utf-8") as stream:
                epoch_before = stream.read()
            event_ids = json.loads(re.search(
                r"^sia_event_ids: (.*)$", epoch_before, re.M).group(1))
            later = sialib.datetime.datetime(
                2026, 1, 6, 12, tzinfo=sialib.datetime.timezone.utc)
            second = sialib.Event(
                "org", later, "obs", "second indexed occurrence",
                occurrence="native:completeness:capacity:second")
            sialib.update_day_page("org", "2026-01-06", [second])
            second_source = sialib.corpus_path(
                sialib.day_slug("org", "2026-01-06"))
            subprocess.run(
                ["git", "-C", d, "-c", "user.email=t@t", "-c",
                 "user.name=t", "add", "-A"], check=True)
            subprocess.run(
                ["git", "-C", d, "-c", "user.email=t@t", "-c",
                 "user.name=t", "commit", "-qm", "second"], check=True)

            with mock.patch.object(
                    sialib, "MAX_EPOCH_EVENT_IDS", len(event_ids)):
                self.assertEqual(sialib.consolidate_corpus(), (0, 0, 1))

            with open(epoch_path, encoding="utf-8") as stream:
                self.assertEqual(stream.read(), epoch_before)
            self.assertTrue(os.path.isfile(second_source))
            second_leaf = os.path.join(
                d, sialib._event_index_relative(
                    "org", sialib.event_memory_identity(second)))
            self.assertFalse(os.path.exists(second_leaf))

    def test_pre_index_epoch_extension_retains_source_without_full_evidence(self):
        sialib = _load("sialib_epoch_legacy_extension",
                       os.path.join(BIN, "sialib.py"))
        with tempfile.TemporaryDirectory() as d:
            sialib.CORPUS = d
            old_mind_path = sialib.siamind.MIND_PATH
            old_window = sialib.siamind.EPISODIC_DAYS
            sialib.siamind.MIND_PATH = os.path.join(d, "mind.json")
            sialib.siamind.EPISODIC_DAYS = 1
            self.addCleanup(setattr, sialib.siamind, "MIND_PATH",
                            old_mind_path)
            self.addCleanup(setattr, sialib.siamind, "EPISODIC_DAYS",
                            old_window)
            sialib.log = lambda *_args: None
            subprocess.run(["git", "init", "-q", d], check=True)
            legacy_slug = sialib._epoch_slug_for_day(
                "org", "2026-01-05")
            sialib.write_page(
                legacy_slug,
                ["type: epoch", sialib.fm_title("legacy epoch"),
                 "tags: [org]", "date: 2026-01-05",
                 "sia_sources: " + json.dumps(["0" * 64]),
                 'sia_dates: ["2026-01-05"]',
                 'sia_counts: {"obs": 1}'],
                "# legacy epoch\n\n"
                "Consolidated from 1 day-memories "
                "(2026-01-05 … 2026-01-05).\n")
            stamp = sialib.datetime.datetime(
                2026, 1, 6, 12, tzinfo=sialib.datetime.timezone.utc)
            event = sialib.Event(
                "org", stamp, "obs", "new exact source",
                occurrence="native:legacy:extension")
            sialib.update_day_page("org", "2026-01-06", [event])
            source_path = sialib.corpus_path(
                sialib.day_slug("org", "2026-01-06"))
            subprocess.run(
                ["git", "-C", d, "-c", "user.email=t@t", "-c",
                 "user.name=t", "add", "-A"], check=True)
            subprocess.run(
                ["git", "-C", d, "-c", "user.email=t@t", "-c",
                 "user.name=t", "commit", "-qm", "legacy and source"],
                check=True)
            epoch_path = sialib.corpus_path(legacy_slug)
            with open(epoch_path, encoding="utf-8") as stream:
                epoch_before = stream.read()

            self.assertEqual(sialib.consolidate_corpus(), (0, 0, 1))

            with open(epoch_path, encoding="utf-8") as stream:
                self.assertEqual(stream.read(), epoch_before)
            self.assertTrue(os.path.isfile(source_path))
            self.assertFalse(os.path.exists(os.path.join(d, "event-index")))

    def test_malformed_counts_refuse_consolidation_and_day_rewrite(self):
        sialib = _load("sialib_epoch_malformed",
                       os.path.join(BIN, "sialib.py"))
        with tempfile.TemporaryDirectory() as d:
            sialib.CORPUS = d
            old_mind_path = sialib.siamind.MIND_PATH
            sialib.siamind.MIND_PATH = os.path.join(d, "mind.json")
            self.addCleanup(setattr, sialib.siamind, "MIND_PATH",
                            old_mind_path)
            sialib.log = lambda *a: None
            subprocess.run(["git", "init", "-q", d], check=True)
            event_dir = os.path.join(d, "events/org")
            os.makedirs(event_dir)
            path = os.path.join(event_dir, "2026-01-05.md")
            damaged = (
                '---\ntype: event-day\ntitle: "damaged"\n'
                'tags: [org]\ndate: 2026-01-05\n'
                'sia_counts: {broken\n---\n# org\n\n## Log\n- held\n')
            with open(path, "w") as stream:
                stream.write(damaged)
            subprocess.run(["git", "-C", d, "-c", "user.email=t@t",
                            "-c", "user.name=t", "add", "-A"], check=True)
            subprocess.run(["git", "-C", d, "-c", "user.email=t@t",
                            "-c", "user.name=t", "commit", "-qm", "x"],
                           check=True)

            with self.assertRaisesRegex(ValueError,
                                        "sia_counts is malformed"):
                sialib.consolidate_corpus()
            with open(path) as stream:
                self.assertEqual(stream.read(), damaged)

            event = sialib.Event("org", sialib.utcnow(), "obs", "new")
            with self.assertRaisesRegex(ValueError,
                                        "sia_counts is malformed"):
                sialib.update_day_page("org", "2026-01-05", [event])
            with open(path) as stream:
                self.assertEqual(stream.read(), damaged)


    def test_bounded_scan_cursor_never_deletes_from_a_partial_page(self):
        sialib = _load(
            "sialib_epoch_bounded_cursor", os.path.join(BIN, "sialib.py"))
        with tempfile.TemporaryDirectory() as d:
            sialib.CORPUS = d
            old_mind_path = sialib.siamind.MIND_PATH
            old_window = sialib.siamind.EPISODIC_DAYS
            sialib.siamind.MIND_PATH = os.path.join(d, "mind.json")
            sialib.siamind.EPISODIC_DAYS = 1
            self.addCleanup(
                setattr, sialib.siamind, "MIND_PATH", old_mind_path)
            self.addCleanup(
                setattr, sialib.siamind, "EPISODIC_DAYS", old_window)
            subprocess.run(["git", "init", "-q", d], check=True)
            event_dir = os.path.join(d, "events", "org")
            os.makedirs(event_dir)
            source = os.path.join(event_dir, "2026-01-05.md")
            with open(source, "w", encoding="utf-8") as stream:
                stream.write(
                    '---\ntype: event-day\ntitle: "bounded"\n'
                    'tags: [org]\ndate: 2026-01-05\n'
                    'sia_counts: {"obs": 1}\n---\n# org\n\n'
                    '## Log\n- observed\n\n## Timeline\n- held\n')
            sialib.siamind.save_mind({"nodes": {}, "edges": {}})
            subprocess.run(
                ["git", "-C", d, "-c", "user.email=t@t", "-c",
                 "user.name=t", "add", "-A"], check=True)
            subprocess.run(
                ["git", "-C", d, "-c", "user.email=t@t", "-c",
                 "user.name=t", "commit", "-qm", "source"], check=True)
            with mock.patch.object(sialib, "MAX_SOURCE_SCAN_ENTRIES", 1):
                self.assertEqual(sialib.consolidate_corpus(), (0, 0, 0))
                self.assertTrue(os.path.exists(source))
                self.assertIn("pending", sialib._consolidation_scan_debt())
                for _attempt in range(20):
                    sialib.consolidate_corpus()
                    if not os.path.exists(source):
                        break
            self.assertFalse(os.path.exists(source))

    def test_consolidation_cursor_refuses_unknown_or_partial_state(self):
        sialib = _load(
            "sialib_epoch_cursor_shape", os.path.join(BIN, "sialib.py"))
        fresh = sialib._fresh_consolidation_scan(sialib.today())
        extra = copy.deepcopy(fresh)
        extra["unexpected"] = False
        with self.assertRaisesRegex(RuntimeError, "scan state is invalid"):
            sialib._canonical_consolidation_scan(extra)
        with tempfile.TemporaryDirectory() as directory:
            _entries, _complete, _inspected, page = \
                sialib._bounded_source_entries(directory)
        page.pop("device")
        partial = copy.deepcopy(fresh)
        next(iter(partial["queue"]))["page"] = page
        with self.assertRaisesRegex(RuntimeError, "scan cursor is invalid"):
            sialib._canonical_consolidation_scan(partial)

    def test_consolidation_cursor_rejects_self_certifying_states(self):
        sialib = _load(
            "sialib_epoch_cursor_invariants", os.path.join(BIN, "sialib.py"))
        wrong_depth = sialib._fresh_consolidation_scan("2026-08-30")
        wrong_depth["queue"][0]["levels"] = 0
        duplicate_path = sialib._fresh_consolidation_scan("2026-08-30")
        duplicate_path["queue"].append(
            copy.deepcopy(duplicate_path["queue"][0]))
        empty_scan = sialib._fresh_consolidation_scan("2026-08-30")
        empty_scan["queue"] = []
        persisted_reset = sialib._fresh_consolidation_scan("2026-08-30")
        persisted_reset["queue"][0]["page"] = {
            "device": 0, "inode": 0, "cookie": 0, "size": 0,
            "mtime_ns": 0, "ctime_ns": 0, "reset": True,
        }
        for label, state in (
                ("wrong-depth", wrong_depth),
                ("duplicate-path", duplicate_path),
                ("scan-empty", empty_scan),
                ("persisted-reset", persisted_reset)):
            with self.subTest(label=label), self.assertRaisesRegex(
                    RuntimeError, "consolidation scan"):
                sialib._canonical_consolidation_scan(state)

    def test_consolidation_refuses_special_organ_namespace_entry(self):
        sialib = _load(
            "sialib_epoch_special_organ", os.path.join(BIN, "sialib.py"))
        with tempfile.TemporaryDirectory() as root:
            corpus = os.path.join(root, "corpus")
            events = os.path.join(corpus, "events")
            hidden = os.path.join(root, "hidden-organ")
            os.makedirs(events)
            os.makedirs(hidden)
            with open(os.path.join(hidden, "2026-01-05.md"), "w"):
                pass
            os.symlink(hidden, os.path.join(events, "linked-organ"))
            sialib.CORPUS = corpus
            state = sialib._fresh_consolidation_scan("2026-08-30")
            with self.assertRaisesRegex(
                    RuntimeError, "consolidation organ path"):
                sialib._advance_consolidation_scan(state)

    def test_pulses_resume_marker_free_scan_debt_until_readiness_returns(self):
        sialib = _load(
            "sialib_epoch_pulse_scan", os.path.join(BIN, "sialib.py"))
        with tempfile.TemporaryDirectory() as corpus:
            sialib.CORPUS = corpus
            event_dir = os.path.join(corpus, "events", "org")
            os.makedirs(event_dir)
            for day in ("2999-01-05", "2999-01-06"):
                with open(os.path.join(event_dir, day + ".md"), "w",
                          encoding="utf-8") as stream:
                    stream.write("future event\n")
            empty_mind = {"nodes": {}, "edges": {}}
            with mock.patch.object(
                    sialib, "MAX_SOURCE_SCAN_ENTRIES", 1), \
                    mock.patch.object(
                        sialib, "corpus_commit", return_value="clean"), \
                    mock.patch.object(
                        sialib.siamind, "load_mind",
                        return_value=empty_mind), \
                    mock.patch.object(
                        sialib.siamind, "pending_user_pin_slugs",
                        return_value=set()):
                # DREAM owns consolidation mutations, but one bounded pass is
                # intentionally insufficient to finish this directory tree.
                self.assertEqual(sialib.consolidate_corpus(), (0, 0, 0))
            self.assertIn("pending", sialib._consolidation_scan_debt())

            memo = {"ready": {
                "v": 1, "completed_at": "2026-08-30T12:00:00Z",
                "kind": "recovery", "identity": "0" * 32}}
            store = {"v": 1, "thoughts": []}

            def recover_once():
                return sialib._recover_before_pulse(memo, store)

            recovery_patches = (
                mock.patch.object(
                    sialib, "_recover_pending_thought_projection"),
                mock.patch.object(
                    sialib, "recover_ledger_transitions",
                    return_value=([], [])),
                mock.patch.object(
                    sialib, "_settle_pending_dream_unit",
                    return_value=None),
                mock.patch.object(sialib, "_complete_pending_dream_cycle"),
                mock.patch.object(
                    sialib.siatakes, "recover_natural_history_transactions",
                    return_value=([], [])),
                mock.patch.object(
                    sialib.siatakes, "recover_grade_transactions",
                    return_value=([], [])),
                mock.patch.object(
                    sialib.siatakes, "migrate_legacy_take_pages",
                    return_value=([], [])),
                mock.patch.object(
                    sialib.siatakes, "advance_intent_history",
                    return_value=([], [])),
                mock.patch.object(
                    sialib.siamind, "load_mind", return_value={}),
                mock.patch.object(
                    sialib.siamind, "pending_user_pin_slugs",
                    return_value=set()),
                mock.patch.object(sialib, "MAX_SOURCE_SCAN_ENTRIES", 1),
                mock.patch.object(
                    sialib, "corpus_commit", return_value="clean"),
                mock.patch.object(sialib, "_write_memo"),
                mock.patch.object(
                    sialib, "queue_ledger_transition",
                    return_value="pending"),
                mock.patch.object(sialib, "_settle_ledger_transition"),
            )
            with contextlib.ExitStack() as stack:
                for patcher in recovery_patches:
                    stack.enter_context(patcher)
                before_crash = sialib.read_state_json(
                    sialib._consolidation_scan_path(), {},
                    "consolidation scan")
                save_scan = sialib._save_consolidation_scan

                def save_then_crash(value):
                    saved = save_scan(value)
                    raise RuntimeError("crash after consolidation checkpoint")

                with mock.patch.object(
                        sialib, "_save_consolidation_scan",
                        side_effect=save_then_crash):
                    with self.assertRaisesRegex(
                            RuntimeError, "after consolidation checkpoint"):
                        recover_once()
                after_crash = sialib.read_state_json(
                    sialib._consolidation_scan_path(), {},
                    "consolidation scan")
                self.assertNotEqual(after_crash, before_crash)

                previous = json.dumps(after_crash, sort_keys=True)
                for _attempt in range(sialib.MAX_EVENT_LOOKUP_PAGES):
                    if not sialib._consolidation_scan_debt():
                        break
                    recover_once()
                    current = json.dumps(sialib.read_state_json(
                        sialib._consolidation_scan_path(), {},
                        "consolidation scan"), sort_keys=True)
                    self.assertNotEqual(current, previous)
                    previous = current
            self.assertEqual(sialib._consolidation_scan_debt(), "")

            readiness_patches = (
                mock.patch.object(
                    sialib, "corpus_owner",
                    side_effect=lambda: contextlib.nullcontext()),
                mock.patch.object(
                    sialib, "_cortex_boundary_status",
                    return_value=(True, "")),
                mock.patch.object(sialib, "load_memo", return_value=memo),
                mock.patch.object(
                    sialib, "_thought_recovery_debt", return_value=""),
                mock.patch.object(
                    sialib, "_graph_projection_debt", return_value=""),
                mock.patch.object(
                    sialib, "read_json",
                    return_value=_empty_graph_snapshot()),
                mock.patch.object(
                    sialib.siamind, "load_mind", return_value={}),
                mock.patch.object(
                    sialib.siatakes, "natural_history_recovery_required",
                    return_value=False),
                mock.patch.object(
                    sialib.siatakes, "grade_recovery_required",
                    return_value=False),
                mock.patch.object(
                    sialib.siatakes, "take_migration_required",
                    return_value=False),
                mock.patch.object(
                    sialib.siatakes, "intent_history_required",
                    return_value=False),
            )
            with contextlib.ExitStack() as stack:
                for patcher in readiness_patches:
                    stack.enter_context(patcher)
                self.assertEqual(sialib.memory_readiness(), (True, ""))

    def test_originating_dream_marker_spans_old_day_claim_batches(self):
        sialib = _load(
            "sialib_epoch_claim_pulses", os.path.join(BIN, "sialib.py"))
        with tempfile.TemporaryDirectory() as corpus:
            sialib.CORPUS = corpus
            event_dir = os.path.join(corpus, "events", "org")
            os.makedirs(event_dir)
            sources = []
            for day in ("2026-01-05", "2026-01-06"):
                path = os.path.join(event_dir, day + ".md")
                with open(path, "w", encoding="utf-8") as stream:
                    stream.write(
                        '---\ntype: event-day\ntitle: "claim batch"\n'
                        f'tags: [org]\ndate: {day}\n'
                        'sia_counts: {"obs": 1}\n---\n# org\n\n'
                        f'## Log\n- {day}\n\n## Timeline\n- held\n')
                sources.append(path)
            subprocess.run(["git", "init", "-q", corpus], check=True)
            subprocess.run(
                ["git", "-C", corpus, "-c", "user.email=t@t", "-c",
                 "user.name=t", "add", "-A"], check=True)
            subprocess.run(
                ["git", "-C", corpus, "-c", "user.email=t@t", "-c",
                 "user.name=t", "commit", "-qm", "old sources"],
                check=True)

            memo = {"ready": {
                "v": 1, "completed_at": "2026-08-30T12:00:00Z",
                "kind": "recovery", "identity": "0" * 32}}
            store = {"v": 1, "thoughts": []}
            settled = []
            fixed_now = datetime.datetime(
                2026, 8, 30, tzinfo=datetime.timezone.utc)
            recovery_patches = (
                mock.patch.object(sialib, "_write_memo"),
                mock.patch.object(
                    sialib, "queue_ledger_transition",
                    return_value="pending"),
                mock.patch.object(
                    sialib, "_settle_ledger_transition",
                    side_effect=lambda path: settled.append(path)),
                mock.patch.object(sialib, "MAX_SOURCE_SCAN_ENTRIES", 1),
                mock.patch.object(
                    sialib, "MAX_CONSOLIDATION_DAYS_PER_RUN", 1),
                mock.patch.object(sialib, "utcnow", return_value=fixed_now),
                mock.patch.object(
                    sialib.siamind, "load_mind",
                    return_value={"nodes": {}, "edges": {}}),
                mock.patch.object(
                    sialib.siamind, "pending_user_pin_slugs",
                    return_value=set()),
                mock.patch.object(
                    sialib, "_recover_pending_thought_projection"),
                mock.patch.object(
                    sialib, "recover_ledger_transitions",
                    return_value=([], [])),
                mock.patch.object(
                    sialib, "_settle_pending_dream_unit",
                    return_value=None),
                mock.patch.object(sialib, "_complete_pending_dream_cycle"),
                mock.patch.object(
                    sialib.siatakes, "recover_natural_history_transactions",
                    return_value=([], [])),
                mock.patch.object(
                    sialib.siatakes, "recover_grade_transactions",
                    return_value=([], [])),
                mock.patch.object(
                    sialib.siatakes, "migrate_legacy_take_pages",
                    return_value=([], [])),
                mock.patch.object(
                    sialib.siatakes, "advance_intent_history",
                    return_value=([], [])),
                mock.patch.object(sialib, "_settle_pending_publication"),
            )
            with contextlib.ExitStack() as stack:
                for patcher in recovery_patches:
                    stack.enter_context(patcher)
                marker = sialib._mark_consolidation_pending(memo)
                sialib._bind_consolidation_ledger(
                    memo, "DREAM:consolidate", f"id={marker['id']}",
                    "completed")

                # The originating DREAM performs one bounded unit and leaves
                # its exact ledger identity pending, not falsely completed.
                sialib._recover_pending_consolidation(memo)
                pending = sialib._pending_consolidation_marker(memo)
                self.assertIsInstance(pending, dict)
                self.assertNotIn("applied_at", pending)
                self.assertIn("pending", sialib._consolidation_scan_debt())
                self.assertEqual(settled, [])

                saw_one_removed_while_pending = False
                saw_all_removed_while_pending = False
                for _attempt in range(sialib.MAX_EVENT_LOOKUP_PAGES):
                    if sialib._pending_consolidation_marker(memo) is None:
                        break
                    sialib._recover_before_pulse(memo, store)
                    still_pending = \
                        sialib._pending_consolidation_marker(memo) is not None
                    live = [os.path.exists(path) for path in sources]
                    if still_pending and live in ([False, True], [True, False]):
                        saw_one_removed_while_pending = True
                    if still_pending and live == [False, False]:
                        saw_all_removed_while_pending = True
                    if still_pending:
                        self.assertNotIn(
                            "applied_at",
                            sialib._pending_consolidation_marker(memo))

            self.assertTrue(saw_one_removed_while_pending)
            self.assertTrue(saw_all_removed_while_pending)
            self.assertFalse(any(os.path.exists(path) for path in sources))
            self.assertIsNone(sialib._pending_consolidation_marker(memo))
            self.assertEqual(sialib._consolidation_scan_debt(), "")
            self.assertEqual(settled, ["pending"])
            epoch = sialib.corpus_path(
                sialib._epoch_slug_for_day("org", "2026-01-05"))
            with open(epoch, encoding="utf-8") as stream:
                epoch_text = stream.read()
            self.assertIn("2026-01-05", epoch_text)
            self.assertIn("2026-01-06", epoch_text)

            readiness_patches = (
                mock.patch.object(
                    sialib, "corpus_owner",
                    side_effect=lambda: contextlib.nullcontext()),
                mock.patch.object(
                    sialib, "_cortex_boundary_status",
                    return_value=(True, "")),
                mock.patch.object(sialib, "load_memo", return_value=memo),
                mock.patch.object(
                    sialib, "_thought_recovery_debt", return_value=""),
                mock.patch.object(
                    sialib, "_graph_projection_debt", return_value=""),
                mock.patch.object(
                    sialib, "read_json",
                    return_value=_empty_graph_snapshot()),
                mock.patch.object(
                    sialib.siamind, "load_mind", return_value={}),
                mock.patch.object(
                    sialib.siatakes, "natural_history_recovery_required",
                    return_value=False),
                mock.patch.object(
                    sialib.siatakes, "grade_recovery_required",
                    return_value=False),
                mock.patch.object(
                    sialib.siatakes, "take_migration_required",
                    return_value=False),
                mock.patch.object(
                    sialib.siatakes, "intent_history_required",
                    return_value=False),
            )
            with contextlib.ExitStack() as stack:
                for patcher in readiness_patches:
                    stack.enter_context(patcher)
                self.assertEqual(sialib.memory_readiness(), (True, ""))

    def test_cutoff_rollover_waits_for_incomplete_generation_suffix(self):
        sialib = _load(
            "sialib_epoch_cutoff_rollover", os.path.join(BIN, "sialib.py"))
        with tempfile.TemporaryDirectory() as d:
            sialib.CORPUS = d
            old_mind_path = sialib.siamind.MIND_PATH
            old_window = sialib.siamind.EPISODIC_DAYS
            sialib.siamind.MIND_PATH = os.path.join(d, "mind.json")
            sialib.siamind.EPISODIC_DAYS = 1
            self.addCleanup(
                setattr, sialib.siamind, "MIND_PATH", old_mind_path)
            self.addCleanup(
                setattr, sialib.siamind, "EPISODIC_DAYS", old_window)
            subprocess.run(["git", "init", "-q", d], check=True)
            event_dir = os.path.join(d, "events", "org")
            os.makedirs(event_dir)
            sources = []
            for day in ("2026-01-05", "2026-01-06"):
                path = os.path.join(event_dir, day + ".md")
                with open(path, "w", encoding="utf-8") as stream:
                    stream.write(
                        f'---\ntype: event-day\ntitle: "{day}"\n'
                        f'tags: [org]\ndate: {day}\n'
                        'sia_counts: {"obs": 1}\n---\n# org\n\n'
                        f'## Log\n- {day}\n\n## Timeline\n- held\n')
                sources.append(path)
            sialib.siamind.save_mind({"nodes": {}, "edges": {}})
            subprocess.run(
                ["git", "-C", d, "-c", "user.email=t@t", "-c",
                 "user.name=t", "add", "-A"], check=True)
            subprocess.run(
                ["git", "-C", d, "-c", "user.email=t@t", "-c",
                 "user.name=t", "commit", "-qm", "sources"], check=True)
            before_rollover = datetime.datetime(
                2026, 8, 30, tzinfo=datetime.timezone.utc)
            after_rollover = datetime.datetime(
                2026, 8, 31, tzinfo=datetime.timezone.utc)
            before_cutoff = (before_rollover - datetime.timedelta(
                days=sialib.siamind.EPISODIC_DAYS)).strftime("%Y-%m-%d")
            after_cutoff = (after_rollover - datetime.timedelta(
                days=sialib.siamind.EPISODIC_DAYS)).strftime("%Y-%m-%d")
            with mock.patch.object(sialib, "MAX_SOURCE_SCAN_ENTRIES", 1), \
                    mock.patch.object(
                        sialib, "utcnow", return_value=before_rollover):
                self.assertEqual(sialib.consolidate_corpus(), (0, 0, 0))
            state = sialib._load_consolidation_scan(before_cutoff)
            generation = state["generation"]
            self.assertEqual(state["phase"], "scan")
            self.assertTrue(state["queue"])
            self.assertTrue(all(os.path.exists(path) for path in sources))

            # The new day's wider cutoff must not discard the durable suffix.
            pinned = sialib._load_consolidation_scan(after_cutoff)
            self.assertEqual(pinned["generation"], generation)
            self.assertEqual(pinned["cutoff"], before_cutoff)
            self.assertEqual(pinned["queue"], state["queue"])
            self.assertTrue(all(os.path.exists(path) for path in sources))

            with mock.patch.object(sialib, "MAX_SOURCE_SCAN_ENTRIES", 1), \
                    mock.patch.object(
                        sialib, "utcnow", return_value=after_rollover):
                for _attempt in range(sialib.MAX_EVENT_LOOKUP_PAGES):
                    sialib.consolidate_corpus()
                    if not any(os.path.exists(path) for path in sources):
                        break
            self.assertFalse(any(os.path.exists(path) for path in sources))
            epoch = sialib.corpus_path(
                sialib._epoch_slug_for_day("org", "2026-01-05"))
            self.assertTrue(os.path.exists(epoch))
            with open(epoch, encoding="utf-8") as stream:
                text = stream.read()
            self.assertIn("2026-01-05", text)
            self.assertIn("2026-01-06", text)

            # Finish the deletion-triggered conservative rescan at its pinned
            # cutoff, then (and only then) admit the later cutoff generation.
            with mock.patch.object(sialib, "MAX_SOURCE_SCAN_ENTRIES", 1), \
                    mock.patch.object(
                        sialib, "utcnow", return_value=before_rollover):
                for _attempt in range(sialib.MAX_EVENT_LOOKUP_PAGES):
                    sialib.consolidate_corpus()
                    completed = sialib._load_consolidation_scan(
                        before_cutoff)
                    if completed["phase"] == "complete" \
                            and not completed["pending_days"] \
                            and not completed["claims"]:
                        break
            self.assertEqual(completed["phase"], "complete")
            completed_generation = completed["generation"]
            rolled = sialib._load_consolidation_scan(after_cutoff)
            self.assertNotEqual(rolled["generation"], completed_generation)
            self.assertEqual(rolled["cutoff"], after_cutoff)
            self.assertEqual(rolled["phase"], "scan")


class HealHoldRate(unittest.TestCase):
    """Auto-proposed take confidence is arithmetic over the corpus's own
    heal history — thin history falls to the prior, never a model."""

    def _mk(self, d, days):
        droot = os.path.join(d, "events/sekhmet")
        os.makedirs(droot, exist_ok=True)
        for day in days:
            with open(os.path.join(droot, day + ".md"), "w") as stream:
                stream.write(
                    "# sekhmet\n- 01:00Z outcome OUTCOME:restart_wireplumber "
                    "- ok\n")

    def test_hold_rate_arithmetic(self):
        st = _load("siatakes_h", os.path.join(BIN, "siatakes.py"))
        with tempfile.TemporaryDirectory() as d:
            # heal 01-05 repeats on 01-08 (broken); the other three hold
            self._mk(d, ["2026-01-05", "2026-01-08", "2026-02-01",
                         "2026-03-01"])
            conf, judged, held = st.heal_hold_rate("restart_wireplumber",
                                                   corpus=d)
            self.assertEqual((judged, held), (4, 3))
            self.assertAlmostEqual(conf, 0.75)

    def test_thin_history_prior(self):
        st = _load("siatakes_h2", os.path.join(BIN, "siatakes.py"))
        with tempfile.TemporaryDirectory() as d:
            self._mk(d, ["2026-01-05"])
            conf, judged, held = st.heal_hold_rate("restart_wireplumber",
                                                   corpus=d)
            self.assertEqual(conf, st.HEAL_PRIOR)


class AutoPropose(unittest.TestCase):
    """Heals become PROPOSALS in the queue — never committed takes — and
    the same action is not proposed twice while one is pending."""

    class Ev:
        def __init__(self, organ, summary):
            self.organ, self.summary = organ, summary

    def test_propose_and_dedup(self):
        st = _load("siatakes_a", os.path.join(BIN, "siatakes.py"))
        with tempfile.TemporaryDirectory() as d:
            st.CORPUS = d
            st.TAKES_DIR = os.path.join(d, "takes")
            state = os.path.join(d, "state")
            os.makedirs(state)
            evs = [self.Ev("sekhmet", "OUTCOME:restart_wireplumber - ok"),
                   self.Ev("pacman", "OUTCOME:not_a_heal ok"),
                   self.Ev("sekhmet", "INTENT:restart_wireplumber - -")]
            p1 = st.auto_propose_heals(evs, state)
            self.assertEqual(len(p1), 1)
            self.assertIn("`restart_wireplumber`", p1[0]["claim"])
            self.assertTrue(p1[0]["proposed"].startswith("auto:heal-hold"))
            # queued now -> second pulse with same heal proposes nothing
            p2 = st.auto_propose_heals(evs, state)
            self.assertEqual(p2, [])
            # queue holds exactly one; no take page was minted
            with open(os.path.join(state, "take-proposals.json")) as stream:
                q = json.load(stream)
            self.assertEqual(len(q), 1)
            self.assertFalse(os.path.isdir(st.TAKES_DIR))

    def test_hyphenated_action_never_truncates(self):
        st = _load("siatakes_a2", os.path.join(BIN, "siatakes.py"))
        with tempfile.TemporaryDirectory() as d:
            st.CORPUS = d
            st.TAKES_DIR = os.path.join(d, "takes")
            state = os.path.join(d, "state")
            os.makedirs(state)
            # "ok" inside the action name must not truncate the capture
            p = st.auto_propose_heals(
                [self.Ev("sekhmet", "OUTCOME:probe-ok-net unit ok")],
                state)
            self.assertEqual(len(p), 1)
            self.assertIn("`probe-ok-net`", p[0]["claim"])

    def test_locked_proposals_serializes(self):
        st = _load("siatakes_l", os.path.join(BIN, "siatakes.py"))
        with tempfile.TemporaryDirectory() as d:
            def proposal(claim):
                return {"claim": claim, "confidence": 0.7,
                        "deadline": "2030-01-01", "domain": "test",
                        "source": "sia/cortex", "proposed": "unit"}
            st.locked_proposals(d, lambda cur: cur + [proposal("a")])
            out = st.locked_proposals(
                d, lambda cur: cur + [proposal("b")])
            self.assertEqual([p["claim"] for p in out], ["a", "b"])


def _intent_page(st):
    for name in os.listdir(st.INTENTS_DIR):
        if name.endswith(".md"):
            return os.path.join(st.INTENTS_DIR, name)
    raise AssertionError("no intent page")


class Intents(unittest.TestCase):
    """Dated intents: create, surface by deadline, close on the
    operator's word only."""

    def test_lifecycle(self):
        st = _load("siatakes_i", os.path.join(BIN, "siatakes.py"))
        with tempfile.TemporaryDirectory() as d:
            st.CORPUS = d
            st.INTENTS_DIR = os.path.join(d, "intents")
            it = st.create_intent("rotate ledger keys", "2099-01-01")
            self.assertEqual(it["status"], "open")
            opened = st.open_intents()
            self.assertEqual(len(opened), 1)
            self.assertGreater(opened[0]["days_left"], 0)
            done = st.close_intent(it["id"][:6], "rotated")
            self.assertEqual(done["status"], "done")
            self.assertEqual(st.open_intents(), [])
            with open(_intent_page(st)) as stream:
                body = stream.read()
            self.assertIn("tags: [intent, done]", body)

    def test_bad_date_raises(self):
        st = _load("siatakes_i2", os.path.join(BIN, "siatakes.py"))
        with tempfile.TemporaryDirectory() as d:
            st.CORPUS = d
            st.INTENTS_DIR = os.path.join(d, "intents")
            with self.assertRaises(ValueError):
                st.create_intent("x", "not-a-date")

    def test_non_ascii_and_backslash_survive_close(self):
        # regression: re.sub once treated the JSON as a template — em
        # dashes crashed the close and backslashes were silently halved
        st = _load("siatakes_i3", os.path.join(BIN, "siatakes.py"))
        with tempfile.TemporaryDirectory() as d:
            st.CORPUS = d
            st.INTENTS_DIR = os.path.join(d, "intents")
            it = st.create_intent("réviser — clean C:\\temp \\d dir",
                                  "2099-01-01")
            done = st.close_intent(it["id"][:6], "done — rotated ☑")
            self.assertEqual(done["status"], "done")
            self.assertEqual(done["text"], "réviser — clean C:\\temp \\d dir")
            # page must round-trip: reload sees the closed intent intact
            loaded = st.load_intents()
            self.assertEqual(len(loaded), 1)
            self.assertEqual(loaded[0]["text"], done["text"])
            self.assertEqual(loaded[0]["note"], "done — rotated ☑")


class Coincidence(unittest.TestCase):
    """Two sources exceeding bands in one pass is an observation; the
    generated entry states the coincidence and occurrence count, no cause."""

    def test_pairs_counted(self):
        sialib = _load("sialib_c", os.path.join(BIN, "sialib.py"))
        mind = {}
        f1 = [("journal", "spike", "x"), ("pacman", "spike", "y"),
              ("jackal", "absence", "z")]
        out = sialib.coincidence_findings(mind, f1, now=1000.0)
        self.assertEqual(len(out), 1)
        self.assertIn("first recorded occurrence", out[0][0])
        self.assertIn("no cause is inferred", out[0][0])
        self.assertEqual(sorted(out[0][1]),
                         ["organs/journal", "organs/pacman"])
        out2 = sialib.coincidence_findings(mind, f1, now=2000.0)
        self.assertIn("2nd recorded occurrence", out2[0][0])
        self.assertEqual(mind["coincide"]["journal|pacman"]["n"], 2)

    def test_single_organ_none(self):
        sialib = _load("sialib_c2", os.path.join(BIN, "sialib.py"))
        self.assertEqual(sialib.coincidence_findings(
            {}, [("journal", "spike", "x")], now=1.0), [])


class DomainEdgeInference(unittest.TestCase):
    """SIA's schema-pack regexes type explicit domain wikilinks without
    depending on gbrain's person/company gazetteer."""

    def setUp(self):
        self.sialib = _load("sialib_edges", os.path.join(BIN, "sialib.py"))
        self.tmp = tempfile.TemporaryDirectory()
        self.sialib.CORPUS = self.tmp.name
        pack = os.path.join(REPO, "schema-pack", "pack.yaml")
        self.rules, self.entity_types = \
            self.sialib.load_domain_edge_spec(pack)

    def tearDown(self):
        self.tmp.cleanup()

    def _page(self, slug, page_type, body, tags=None, origin=None):
        path = os.path.join(self.tmp.name, slug + ".md")
        os.makedirs(os.path.dirname(path), exist_ok=True)
        tag_line = f"tags: [{', '.join(tags)}]\n" if tags else ""
        origin_line = f"origin: {origin}\n" if origin else ""
        with open(path, "w") as f:
            f.write(f"---\ntype: {page_type}\ntitle: test\n"
                    f"{tag_line}{origin_line}---\n{body}")

    def _edges(self, source):
        return [e for e in self.sialib.corpus_edges(
            self.rules, self.entity_types, [source])
                if e["from_slug"] == source]

    def test_every_declared_rule_types_its_record(self):
        self.assertEqual([name for name, _ in self.rules], [
            "verified_by", "healed", "crashed", "upgraded", "refused"])
        self._page("events/domain", "event-day", """# domain

- chain evidence pass [[organs/aegis]]
- OUTCOME:restart_audio ok [[units/audio]]
- process dumped core [[units/worker]]
- installed: [[packages/widget]]
- declined to answer [[organs/jackal]]
- ordinary observation [[organs/journal]]
""")
        got = {e["to_slug"]: e["link_type"]
               for e in self._edges("events/domain")}
        self.assertEqual(got, {
            "organs/aegis": "verified_by",
            "units/audio": "healed",
            "units/worker": "crashed",
            "packages/widget": "upgraded",
            "organs/jackal": "refused",
            "organs/journal": "mentions",
        })

    def test_link_names_cannot_mint_relations_or_leak_across_records(self):
        self._page("events/scoped", "event-day", """# scoped

- cataloged [[skills/diagnose-crash]] [[packages/refusal-kit]]
- process dumped core [[units/failed-worker]]
- ordinary observation [[units/plain-worker]]
""")
        got = {e["to_slug"]: e["link_type"]
               for e in self._edges("events/scoped")}
        self.assertEqual(got["skills/diagnose-crash"], "mentions")
        self.assertEqual(got["packages/refusal-kit"], "mentions")
        self.assertEqual(got["units/failed-worker"], "crashed")
        self.assertEqual(got["units/plain-worker"], "mentions")

    def test_link_only_evidence_line_inherits_preceding_prose(self):
        self._page("thoughts/crash", "thought", """# crash

The worker dumped core.

[[organs/journal]] [[units/systemd-coredump]]
""", tags=["thought", "crash"], origin="derived")
        self.assertEqual(
            {e["link_type"] for e in self._edges("thoughts/crash")},
            {"crashed"})

    def test_model_and_legacy_safety_thoughts_stay_neutral(self):
        for suffix, origin in (("model", "model"), ("legacy", None)):
            slug = f"thoughts/{suffix}-integrity"
            self._page(
                slug, "thought",
                "chain verified by [[organs/aegis]]\n",
                tags=["thought", "integrity"], origin=origin)
            self.assertEqual(
                {edge["link_type"] for edge in self._edges(slug)},
                {"mentions"})

    def test_entity_descriptions_stay_neutral(self):
        self._page("organs/sekhmet", "organ",
                   "Self-healing fabric. Source adapter for [[sia/cortex]].\n")
        self._page("skills/diagnose-crash", "skill",
                   "Agent skill installed here. Watched by [[organs/skills]].\n")
        self.assertIn("skill", self.entity_types)
        for source in ("organs/sekhmet", "skills/diagnose-crash"):
            self.assertEqual(
                {e["link_type"] for e in self._edges(source)}, {"mentions"})

    def test_model_and_commitment_pages_cannot_mint_typed_relations(self):
        for page_type in ("note", "synthesis", "take", "intent"):
            slug = f"{page_type}s/untrusted"
            self._page(slug, page_type,
                       "A model says this crashed [[units/critical]].\n")
            self.assertEqual(
                {e["link_type"] for e in self._edges(slug)}, {"mentions"})

    def test_take_grade_links_never_enter_the_graph(self):
        self._page("takes/legacy", "take", """# take

Operator-approved context [[organs/sekhmet]].

## Grade · 2026-08-30T12:00:00Z

**TRUE** — model-assisted.

Legacy model prose [[units/forged]].
""")
        self.assertEqual(
            {(edge["to_slug"], edge["link_type"])
             for edge in self._edges("takes/legacy")},
            {("organs/sekhmet", "mentions")})

    def test_quoted_missing_and_unknown_types_fail_closed(self):
        path = os.path.join(self.tmp.name, "notes", "quoted.md")
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w") as stream:
            stream.write('---\ntype: "note"\n---\n'
                         'crashed [[units/quoted]]\n')
        for slug, frontmatter in (
                ("unknown/page", "type: alien"),
                ("missing/page", "title: no type")):
            target = os.path.join(self.tmp.name, slug + ".md")
            os.makedirs(os.path.dirname(target), exist_ok=True)
            with open(target, "w") as stream:
                stream.write(f"---\n{frontmatter}\n---\n"
                             "healed [[units/target]]\n")
        for source in ("notes/quoted", "unknown/page", "missing/page"):
            self.assertEqual(
                {edge["link_type"] for edge in self._edges(source)},
                {"mentions"})

    def test_snapshot_preserves_distinct_relations_for_same_pair(self):
        old_graph = self.sialib.GRAPH_PATH
        self.sialib.GRAPH_PATH = os.path.join(self.tmp.name, "graph.json")
        pages = [
            {"slug": "events/day", "type": "event-day", "title": "day",
             "updated_at": "2099-01-01T00:00:00Z"},
            {"slug": "units/x", "type": "unit", "title": "x",
             "updated_at": "2099-01-01T00:00:00Z"},
        ]
        old_list = self.sialib.gbrain_all_pages
        old_edges = self.sialib.corpus_edges
        self.sialib.gbrain_all_pages = lambda: (pages, True, None)
        self.sialib.corpus_edges = lambda *_args: [
            {"from_slug": "events/day", "to_slug": "units/x",
             "link_type": "crashed", "context": "crashed"},
            {"from_slug": "events/day", "to_slug": "units/x",
             "link_type": "healed", "context": "healed"},
            {"from_slug": "events/day", "to_slug": "units/x",
             "link_type": "mentions", "context": "generic"},
        ]
        try:
            self.sialib.export_graph()
            with open(self.sialib.GRAPH_PATH) as stream:
                graph = json.load(stream)
            self.assertEqual({edge["t"] for edge in graph["edges"]},
                             {"crashed", "healed"})
        finally:
            self.sialib.gbrain_all_pages = old_list
            self.sialib.corpus_edges = old_edges
            self.sialib.GRAPH_PATH = old_graph

    def test_unreadable_corpus_page_marks_graph_snapshot_partial(self):
        self._page("events/unreadable", "event-day",
                   "observed [[organs/journal]]\n")
        path = os.path.join(self.tmp.name, "events", "unreadable.md")
        old_graph = self.sialib.GRAPH_PATH
        self.sialib.GRAPH_PATH = os.path.join(self.tmp.name, "graph.json")
        pages = [{"slug": "events/unreadable", "type": "event-day",
                  "title": "unreadable",
                  "updated_at": "2099-01-01T00:00:00Z"}]
        real_read = self.sialib._read_graph_corpus_page

        def refuse(slug):
            if slug == "events/unreadable":
                raise OSError("simulated read refusal")
            return real_read(slug)

        try:
            with mock.patch.object(self.sialib, "gbrain_all_pages",
                                   return_value=(pages, True, None)), \
                    mock.patch.object(
                        self.sialib, "_read_graph_corpus_page",
                        side_effect=refuse):
                self.sialib.export_graph(require_complete=False)
            with open(self.sialib.GRAPH_PATH) as stream:
                graph = json.load(stream)
            self.assertFalse(graph["snapshot"]["complete"])
            self.assertIn("corpus_edges", graph["snapshot"]["failed_ops"])
            self.assertEqual(graph["edges"], [])
        finally:
            self.sialib.GRAPH_PATH = old_graph

        for kind in ("note", "ponder", "grade", "take", "intent",
                     "association"):
            slug = f"thoughts/untrusted-{kind}"
            self._page(slug, "thought",
                       "A derived statement says this crashed "
                       "[[units/critical]].\n",
                       tags=["thought", kind])
            self.assertEqual(
                {e["link_type"] for e in self._edges(slug)}, {"mentions"})

    def test_substituted_edge_provider_non_mapping_fails_closed(self):
        old_graph = self.sialib.GRAPH_PATH
        self.sialib.GRAPH_PATH = os.path.join(self.tmp.name, "graph.json")
        pages = [{"slug": "organs/example", "type": "organ",
                  "title": "example",
                  "updated_at": "2026-01-01T00:00:00Z"}]
        try:
            with mock.patch.object(
                    self.sialib, "gbrain_all_pages",
                    return_value=(pages, True, None)), \
                    mock.patch.object(
                        self.sialib, "corpus_edges", return_value=[None]):
                self.sialib.export_graph(require_complete=False)
            with open(self.sialib.GRAPH_PATH) as stream:
                graph = json.load(stream)
            self.assertFalse(graph["snapshot"]["complete"])
            self.assertIn(
                "corpus_edge_shape", graph["snapshot"]["failed_ops"])
            self.assertEqual(graph["edges"], [])
        finally:
            self.sialib.GRAPH_PATH = old_graph

    def test_substituted_edge_provider_unsafe_omission_count_refuses(self):
        old_graph = self.sialib.GRAPH_PATH
        self.sialib.GRAPH_PATH = os.path.join(self.tmp.name, "graph.json")
        pages = [{"slug": "organs/example", "type": "organ",
                  "title": "example",
                  "updated_at": "2026-01-01T00:00:00Z"}]
        try:
            with mock.patch.object(
                    self.sialib, "gbrain_all_pages",
                    return_value=(pages, True, None)), \
                    mock.patch.object(
                        self.sialib, "corpus_edges",
                        return_value=([], 9007199254740992)):
                self.sialib.export_graph(require_complete=False)
            with open(self.sialib.GRAPH_PATH) as stream:
                graph = json.load(stream)
            self.assertFalse(graph["snapshot"]["complete"])
            self.assertIn("corpus_edges", graph["snapshot"]["failed_ops"])
            self.assertEqual(graph["snapshot"]["omitted_edges"], 0)
        finally:
            self.sialib.GRAPH_PATH = old_graph

    def test_substituted_edge_omission_requires_a_full_window(self):
        old_graph = self.sialib.GRAPH_PATH
        self.sialib.GRAPH_PATH = os.path.join(self.tmp.name, "graph.json")
        pages = [{"slug": "organs/example", "type": "organ",
                  "title": "example",
                  "updated_at": "2026-01-01T00:00:00Z"}]
        try:
            with mock.patch.object(
                    self.sialib, "gbrain_all_pages",
                    return_value=(pages, True, None)), \
                    mock.patch.object(
                        self.sialib, "corpus_edges",
                        return_value=([], 1)):
                self.sialib.export_graph(require_complete=False)
            with open(self.sialib.GRAPH_PATH) as stream:
                graph = json.load(stream)
            self.assertFalse(graph["snapshot"]["complete"])
            self.assertIn("corpus_edges", graph["snapshot"]["failed_ops"])
            self.assertEqual(graph["snapshot"]["omitted_edges"], 0)
        finally:
            self.sialib.GRAPH_PATH = old_graph

    def test_substituted_edge_provider_cannot_exceed_edge_window(self):
        old_graph = self.sialib.GRAPH_PATH
        self.sialib.GRAPH_PATH = os.path.join(self.tmp.name, "graph.json")
        pages = [{"slug": "organs/example", "type": "organ",
                  "title": "example",
                  "updated_at": "2026-01-01T00:00:00Z"}]
        oversized = [
            {"from_slug": "organs/example", "to_slug": "organs/example",
             "link_type": f"relation-{index}", "context": "context"}
            for index in range(4097)]
        try:
            with mock.patch.object(
                    self.sialib, "gbrain_all_pages",
                    return_value=(pages, True, None)), \
                    mock.patch.object(
                        self.sialib, "corpus_edges",
                        return_value=oversized):
                self.sialib.export_graph(require_complete=False)
            with open(self.sialib.GRAPH_PATH) as stream:
                graph = json.load(stream)
            self.assertFalse(graph["snapshot"]["complete"])
            self.assertIn("corpus_edges", graph["snapshot"]["failed_ops"])
            self.assertEqual(graph["edges"], [])
        finally:
            self.sialib.GRAPH_PATH = old_graph

    def test_typed_occurrence_suppresses_generic_duplicate(self):
        self._page("events/packages", "event-day", """# packages

See [[packages/widget]].
- installed: [[packages/widget]]
""")
        matches = [e for e in self._edges("events/packages")
                   if e["to_slug"] == "packages/widget"]
        self.assertEqual([edge["link_type"] for edge in matches],
                         ["upgraded"])

    def test_distinct_typed_relations_survive_mention_suppression(self):
        self._page("events/lifecycle", "event-day", """# lifecycle

- process dumped core [[units/worker]]
- OUTCOME:restart_worker ok [[units/worker]]
- ordinary observation [[units/worker]]
""")
        matches = [e for e in self._edges("events/lifecycle")
                   if e["to_slug"] == "units/worker"]
        self.assertEqual({edge["link_type"] for edge in matches},
                         {"crashed", "healed"})

    def test_unsafe_pack_regex_fails_closed(self):
        pack = os.path.join(self.tmp.name, "unsafe.yaml")
        with open(pack, "w") as f:
            f.write("""api_version: gbrain-schema-pack-v1
name: unsafe
page_types: []
link_types:
  - name: bad
    inference:
      regex: "(a+)+$"
""")
        with self.assertRaisesRegex(ValueError, "unsafe domain regex"):
            self.sialib.load_domain_edge_spec(pack)

    def test_schema_pack_relation_names_match_the_graph_envelope(self):
        for label, name in (
                ("spaces", "Not Canonical"),
                ("hidden-format", "hidden\U000e0001relation")):
            with self.subTest(label=label):
                pack = os.path.join(
                    self.tmp.name, "unsafe-name-" + label + ".yaml")
                with open(pack, "w", encoding="utf-8") as stream:
                    stream.write(
                        "link_types:\n"
                        f"  - name: {name}\n"
                        "    inference:\n"
                        "      regex: refused\n")
                with self.assertRaisesRegex(
                        ValueError, "name is not canonical"):
                    self.sialib.load_domain_edge_spec(pack)

    def test_ambiguous_alternation_repeat_bypass_fails_closed(self):
        pack = os.path.join(self.tmp.name, "ambiguous-repeat.yaml")
        with open(pack, "w") as f:
            f.write("""api_version: gbrain-schema-pack-v1
name: unsafe
page_types: []
link_types:
  - name: bad
    inference:
      regex: "(a|aa)+$"
""")
        with self.assertRaisesRegex(ValueError, "unsafe domain regex"):
            self.sialib.load_domain_edge_spec(pack)

    def test_schema_pack_symlink_is_refused_without_following(self):
        target = os.path.join(self.tmp.name, "pack-target.yaml")
        with open(target, "w", encoding="utf-8") as stream:
            stream.write("link_types:\n")
        link = os.path.join(self.tmp.name, "pack-link.yaml")
        os.symlink(target, link)
        with self.assertRaises(OSError):
            self.sialib.load_domain_edge_spec(link)

    def test_schema_pack_hardlink_is_refused_as_aliased_policy(self):
        pack = os.path.join(self.tmp.name, "pack.yaml")
        shutil.copyfile(
            os.path.join(REPO, "schema-pack", "pack.yaml"), pack)
        alias = pack + ".alias"
        os.link(pack, alias)
        try:
            with self.assertRaisesRegex(ValueError, "single-link"):
                self.sialib.load_domain_edge_spec(pack)
        finally:
            os.unlink(alias)

    def test_schema_pack_newline_free_byte_overflow_is_refused(self):
        pack = os.path.join(self.tmp.name, "oversize.yaml")
        with open(pack, "wb") as stream:
            stream.write(b"x" * (self.sialib.MAX_SCHEMA_PACK_BYTES + 1))
        with self.assertRaisesRegex(ValueError, "bounded regular file"):
            self.sialib.load_domain_edge_spec(pack)

    def test_schema_pack_physical_line_aggregate_is_bounded(self):
        pack = os.path.join(self.tmp.name, "many-lines.yaml")
        with open(pack, "wb") as stream:
            stream.write(
                b"\n" * (self.sialib.MAX_SCHEMA_PACK_LINES + 1))
        with self.assertRaisesRegex(ValueError, "line limit"):
            self.sialib.load_domain_edge_spec(pack)

    def test_schema_pack_rule_aggregate_is_bounded(self):
        pack = os.path.join(self.tmp.name, "many-rules.yaml")
        with open(pack, "w", encoding="utf-8") as stream:
            stream.write("page_types: []\nlink_types:\n")
            for index in range(self.sialib.MAX_DOMAIN_EDGE_RULES + 1):
                stream.write(
                    f"  - name: relation{index}\n"
                    "    inference:\n"
                    "      regex: ok\n")
        with self.assertRaisesRegex(ValueError, "inference-rule limit"):
            self.sialib.load_domain_edge_spec(pack)

    def test_schema_pack_entity_aggregate_is_bounded(self):
        pack = os.path.join(self.tmp.name, "many-entities.yaml")
        with open(pack, "w", encoding="utf-8") as stream:
            stream.write("page_types:\n")
            for index in range(self.sialib.MAX_DOMAIN_ENTITY_TYPES + 1):
                stream.write(
                    f"  - name: entity{index}\n"
                    "    primitive: entity\n")
            stream.write(
                "link_types:\n"
                "  - name: relation\n"
                "    inference:\n"
                "      regex: ok\n")
        with self.assertRaisesRegex(ValueError, "entity-type limit"):
            self.sialib.load_domain_edge_spec(pack)

    def test_refused_schema_pack_keeps_mentions_and_marks_partial(self):
        invalid = os.path.join(self.tmp.name, "invalid-pack.yaml")
        with open(invalid, "wb") as stream:
            stream.write(b"\xff")
        self._page("events/day", "event-day",
                   "crashed [[units/worker]]\n")
        self._page("units/worker", "unit", "worker\n")
        old_graph = self.sialib.GRAPH_PATH
        self.sialib.GRAPH_PATH = os.path.join(self.tmp.name, "graph.json")
        pages = [
            {"slug": "events/day", "type": "event-day", "title": "day",
             "updated_at": "2099-01-01T00:00:00Z"},
            {"slug": "units/worker", "type": "unit", "title": "worker",
             "updated_at": "2099-01-01T00:00:00Z"},
        ]
        try:
            with mock.patch.dict(
                    os.environ, {"SIA_SCHEMA_PACK": invalid}), \
                    mock.patch.object(
                        self.sialib, "gbrain_all_pages",
                        return_value=(pages, True, None)):
                self.sialib.export_graph(require_complete=False)
            with open(self.sialib.GRAPH_PATH, encoding="utf-8") as stream:
                graph = json.load(stream)
            self.assertFalse(graph["snapshot"]["complete"])
            self.assertIn(
                "domain_link_rules", graph["snapshot"]["failed_ops"])
            self.assertEqual(
                [(edge["s"], edge["d"], edge["t"])
                 for edge in graph["edges"]],
                [("events/day", "units/worker", "mentions")])
        finally:
            self.sialib.GRAPH_PATH = old_graph

    def test_brain_sync_keeps_gazetteer_ner_lane(self):
        calls = []

        class Result:
            returncode = 0
            stdout = stderr = ""

        def fake_gbrain(args, timeout=None, json_out=False):
            calls.append(args)
            return Result()

        self.sialib.gbrain = fake_gbrain
        self.assertEqual(self.sialib.brain_sync(), (True, ""))
        self.assertEqual(calls[0], ["sync", "--source", "sia"])
        self.assertIn("--stale", calls[1])
        self.assertIn("--by-mention", calls[2])
        self.assertIn("--ner", calls[2])
        self.assertEqual(calls[2][calls[2].index("--source-id") + 1], "sia")

        calls.clear()
        with mock.patch.dict(
                os.environ, {"SIA_RESTORE_FULL_SYNC": "1"}):
            self.assertEqual(self.sialib.brain_sync(), (True, ""))
        self.assertEqual(calls[0], ["sync", "--source", "sia", "--full"])


class BoundedGraphProjection(unittest.TestCase):
    """The resident graph advances bounded durable pages and fails closed."""

    def setUp(self):
        self.sialib = _load(
            "sialib_bounded_graph", os.path.join(BIN, "sialib.py"))
        self.tmp = tempfile.TemporaryDirectory()
        self.corpus = os.path.join(self.tmp.name, "corpus")
        self.state = os.path.join(self.tmp.name, "state")
        os.makedirs(os.path.join(self.corpus, "events", "journal"))
        os.makedirs(self.state)
        self.sialib.STATE = self.state
        self.sialib.CORPUS = self.corpus
        self.sialib.GRAPH_PATH = os.path.join(self.state, "graph.json")
        self.sialib.LIFECYCLE_LOCK = os.path.join(
            self.state, "lifecycle.lock")
        self.sialib.LIFECYCLE_TOMBSTONE = os.path.join(
            self.state, "lifecycle-removed")

    def tearDown(self):
        self.tmp.cleanup()

    def _page(self, slug, title="page", page_type="event-day", body=None):
        path = os.path.join(self.corpus, slug + ".md")
        os.makedirs(os.path.dirname(path), exist_ok=True)
        if body is None:
            body = "[[sia/cortex]]\n"
        with open(path, "w", encoding="utf-8") as stream:
            stream.write(
                f"---\ntype: {page_type}\ntitle: "
                f"{json.dumps(title)}\n---\n{body}")

    def _graph(self):
        with open(self.sialib.GRAPH_PATH, encoding="utf-8") as stream:
            return json.load(stream)

    def test_graph_reader_refuses_hardlinked_corpus_authority(self):
        slug = "events/journal/hardlinked"
        self._page(slug)
        path = os.path.join(self.corpus, slug + ".md")
        alias = path + ".alias"
        os.link(path, alias)
        try:
            with self.assertRaisesRegex(RuntimeError, "single-link"):
                self.sialib._read_graph_corpus_page(slug)
        finally:
            os.unlink(alias)

    def test_directory_cookie_resumes_without_whole_corpus_materialization(self):
        self._page("events/journal/first")
        self._page("events/journal/second")
        pages, complete, failure = self.sialib.gbrain_all_pages(batch_size=1)
        self.assertFalse(complete)
        self.assertEqual(failure, "graph_projection_pending")
        self.assertLessEqual(len(pages), self.sialib.MAX_GRAPH_NODES)
        for _attempt in range(20):
            pages, complete, failure = self.sialib.gbrain_all_pages(
                batch_size=1)
            if complete:
                break
        self.assertTrue(complete, failure)
        self.assertEqual({page["slug"] for page in pages}, {
            "events/journal/first", "events/journal/second"})

    def test_root_genesis_readme_is_repository_metadata_not_a_page(self):
        with open(os.path.join(self.corpus, "README.md"), "w",
                  encoding="utf-8") as stream:
            stream.write("# SIA memory corpus\n")
        self._page("events/journal/first")

        for _attempt in range(20):
            pages, complete, failure = self.sialib.gbrain_all_pages(
                batch_size=1)
            if complete:
                break
        self.assertTrue(complete, failure)
        self.assertEqual(
            [page["slug"] for page in pages], ["events/journal/first"])

        state = self.sialib._load_graph_projection_state()
        state["failed_ops"] = [self.sialib.LEGACY_GRAPH_README_FAILURE]
        self.sialib._save_graph_projection_state(state)
        migrated = self.sialib._load_graph_projection_state()
        self.assertEqual(migrated["failed_ops"], [])
        with open(self.sialib._graph_projection_state_path(),
                  encoding="utf-8") as stream:
            self.assertEqual(json.load(stream)["failed_ops"], [])

    def test_reserved_graph_namespace_special_node_is_refusal_debt(self):
        for reserved in (".git", "event-index"):
            with self.subTest(reserved=reserved):
                path = os.path.join(self.corpus, reserved)
                os.symlink(self.state, path)
                try:
                    self.sialib._mark_graph_projection_dirty()
                    _pages, complete, failure = \
                        self.sialib.gbrain_all_pages()
                finally:
                    os.unlink(path)
                self.assertFalse(complete)
                self.assertEqual(
                    failure,
                    "graph_reserved_directory_refused:" + reserved)

    def test_navigable_graph_namespace_special_node_is_refusal_debt(self):
        events = os.path.join(self.corpus, "events")
        held = os.path.join(self.tmp.name, "events-held")
        os.replace(events, held)
        os.symlink(held, events)
        try:
            self.sialib._mark_graph_projection_dirty()
            _pages, complete, failure = self.sialib.gbrain_all_pages()
        finally:
            os.unlink(events)
            os.replace(held, events)
        self.assertFalse(complete)
        self.assertEqual(failure, "graph_nonregular_entry:events")

    def test_supported_mutation_restarts_projection_before_page_write(self):
        self._page("events/journal/first")
        for _attempt in range(20):
            _pages, complete, _failure = \
                self.sialib.gbrain_all_pages(batch_size=1)
            if complete:
                break
        self.assertTrue(complete)
        with self.sialib.corpus_mutation_barrier(lambda: None):
            self.sialib.write_page(
                "events/journal/second",
                ["type: event-day", self.sialib.fm_title("second")],
                "[[sia/cortex]]\n")
        state = self.sialib._load_graph_projection_state()
        self.assertEqual(state["phase"], "scan")
        self.assertEqual(state["candidates"], [])

    def test_stale_ready_projection_restarts_when_page_bytes_differ(self):
        slug = "events/journal/changed-after-ready"
        self._page(slug, body="before\n")
        for _attempt in range(20):
            _pages, complete, _failure = self.sialib.gbrain_all_pages(
                batch_size=1)
            if complete:
                break
        self.assertTrue(complete)

        self._page(slug, body="after\n")
        self.sialib.export_graph(require_complete=False)

        graph = self._graph()
        self.assertFalse(graph["snapshot"]["complete"])
        self.assertIn("corpus_edges", graph["snapshot"]["failed_ops"])
        state = self.sialib._load_graph_projection_state()
        self.assertEqual(state["phase"], "scan")
        self.assertEqual(state["candidates"], [])

    def test_projection_failure_and_metadata_state_are_bounded(self):
        state = self.sialib._fresh_graph_projection_state()
        with mock.patch.object(self.sialib, "MAX_GRAPH_SCAN_ENTRIES", 2):
            state["failed_ops"] = ["first", "second"]
            self.sialib._record_graph_failure(state, "third")
            self.assertEqual(len(state["failed_ops"]), 2)
            self.assertIn("graph_failure_capacity", state["failed_ops"])
        long_title = "x" * (self.sialib.MAX_SOURCE_NAME_CHARS + 1)
        self._page("events/journal/title", title=long_title)
        record, _frontmatter, _body = \
            self.sialib._read_graph_corpus_page("events/journal/title")
        self.assertLessEqual(
            len(record["title"]), self.sialib.MAX_SOURCE_NAME_CHARS)
        self._page(
            "events/journal/type", page_type=
            "x" * (self.sialib.MAX_SOURCE_NAME_CHARS + 1))
        with self.assertRaisesRegex(RuntimeError, "type is invalid"):
            self.sialib._read_graph_corpus_page("events/journal/type")
        origin_path = os.path.join(
            self.corpus, "events", "journal", "origin.md")
        with open(origin_path, "w", encoding="utf-8") as stream:
            stream.write(
                "---\ntype: event-day\norigin: evidence\n"
                "origin: model\n---\n[[sia/cortex]]\n")
        with self.assertRaisesRegex(RuntimeError, "origin is ambiguous"):
            self.sialib._read_graph_corpus_page("events/journal/origin")

        record, _frontmatter, _body = \
            self.sialib._read_graph_corpus_page("events/journal/title")
        safe_record = copy.deepcopy(record)
        record["title"] = "hidden\U000e0001title"
        extra = self.sialib._fresh_graph_projection_state()
        extra["unexpected"] = True
        impossible_counts = self.sialib._fresh_graph_projection_state()
        impossible_counts["pages_seen"] = 0
        impossible_counts["eligible_seen"] = 1
        hidden_failure = self.sialib._fresh_graph_projection_state()
        hidden_failure["failed_ops"] = ["hidden\U000e0001failure"]
        hidden_title = self.sialib._fresh_graph_projection_state()
        hidden_title["candidates"] = [record]
        hidden_title["pages_seen"] = 1
        hidden_title["eligible_seen"] = 1
        impossible_candidates = self.sialib._fresh_graph_projection_state()
        impossible_candidates["candidates"] = [safe_record]
        empty_scan = self.sialib._fresh_graph_projection_state()
        empty_scan["queue"] = []
        future_candidate = self.sialib._fresh_graph_projection_state()
        future_record = copy.deepcopy(safe_record)
        future_record["updated_at"] = "2999-01-01T00:00:00Z"
        future_candidate["candidates"] = [future_record]
        future_candidate["pages_seen"] = 1
        future_candidate["eligible_seen"] = 1
        future_started = self.sialib._fresh_graph_projection_state()
        future_started["started_at"] = "2999-01-01T00:00:00Z"
        wrong_cutoff = self.sialib._fresh_graph_projection_state()
        wrong_cutoff["cutoff"] = wrong_cutoff["started_at"]
        underflow_cutoff = self.sialib._fresh_graph_projection_state()
        underflow_cutoff["started_at"] = "0001-01-01T00:00:00Z"
        underflow_cutoff["cutoff"] = "0001-01-01T00:00:00Z"
        duplicate_cursor = self.sialib._fresh_graph_projection_state()
        duplicate_cursor["queue"].append(
            copy.deepcopy(duplicate_cursor["queue"][0]))
        wrong_cursor_depth = self.sialib._fresh_graph_projection_state()
        wrong_cursor_depth["queue"][0]["levels"] = 0
        open_cursor_page = self.sialib._fresh_graph_projection_state()
        open_cursor_page["queue"][0]["page"] = {"unexpected": True}
        partial_cursor_page = self.sialib._fresh_graph_projection_state()
        partial_cursor_page["queue"][0]["page"] = {"cookie": 0}
        for label, malformed, reason in (
                ("extra-key", extra, "projection state"),
                ("impossible-counts", impossible_counts,
                 "projection state"),
                ("hidden-failure", hidden_failure,
                 "projection failure"),
                ("hidden-title", hidden_title, "candidate"),
                ("impossible-candidates", impossible_candidates,
                 "projection state"),
                ("empty-scan", empty_scan, "projection state"),
                ("future-candidate", future_candidate, "candidate"),
                ("future-started", future_started,
                 "projection state"),
                ("wrong-cutoff", wrong_cutoff, "projection state"),
                ("underflow-cutoff", underflow_cutoff,
                 "projection state"),
                ("duplicate-cursor", duplicate_cursor, "cursor"),
                ("wrong-cursor-depth", wrong_cursor_depth, "cursor"),
                ("open-cursor-page", open_cursor_page, "cursor"),
                ("partial-cursor-page", partial_cursor_page, "cursor")):
            with self.subTest(label=label):
                with self.assertRaisesRegex(RuntimeError, reason):
                    self.sialib._canonical_graph_projection_state(malformed)

        self._page("events/journal/future", title="future")
        future_path = os.path.join(
            self.corpus, "events", "journal", "future.md")
        future = time.time() + 3600
        os.utime(future_path, (future, future))
        with self.assertRaisesRegex(RuntimeError, "future timestamp"):
            self.sialib._read_graph_corpus_page("events/journal/future")

    def test_fresh_projection_uses_one_clock_observation(self):
        instant = datetime.datetime.strptime(
            "2026-09-04T12:00:00Z", "%Y-%m-%dT%H:%M:%SZ").replace(
                tzinfo=datetime.timezone.utc)
        with mock.patch.object(
                self.sialib, "utcnow", side_effect=[instant]):
            state = self.sialib._fresh_graph_projection_state()
        self.sialib._canonical_graph_projection_state(state)

    def test_recent_node_cap_is_complete_with_explicit_nonabsence_boundary(self):
        for index in range(self.sialib.MAX_GRAPH_NODES + 1):
            self._page(f"events/journal/recent-{index:04d}")

        pages, complete, failure = self.sialib.gbrain_all_pages()
        self.assertTrue(complete, failure)
        self.assertEqual(len(pages), self.sialib.MAX_GRAPH_NODES)
        self.assertEqual(self.sialib._graph_projection_debt(), "")

        nodes, _edges, pages_total = self.sialib.export_graph()
        graph = self._graph()
        self.assertEqual(nodes, self.sialib.MAX_GRAPH_NODES)
        self.assertGreater(pages_total, nodes)
        self.assertTrue(graph["snapshot"]["complete"])
        self.assertGreater(graph["snapshot"]["truncated"], 0)
        self.assertEqual(graph["snapshot"]["omitted_nodes"],
                         graph["snapshot"]["truncated"])
        self.assertEqual(graph["snapshot"]["omitted_edges"], 0)
        self.assertFalse(
            graph["snapshot"]["omissions_imply_absence"])
        self.assertEqual(graph["snapshot"]["failed_ops"], [])
        self.assertEqual(self.sialib._graph_projection_debt(), "")
        # The display omission does not delete or rename the source page; the
        # corpus/PGLite lane remains the authoritative recall surface.
        displayed = {node["id"] for node in graph["nodes"]}
        omitted = [slug for slug in (
            f"events/journal/recent-{index:04d}"
            for index in range(self.sialib.MAX_GRAPH_NODES + 1))
                   if slug not in displayed]
        self.assertTrue(omitted)
        self.assertTrue(os.path.isfile(
            os.path.join(self.corpus, omitted[0] + ".md")))

    def test_elapsed_window_adds_disjoint_aged_out_classes(self):
        pages = [
            {"slug": "events/journal/was-recent", "type": "event-day",
             "title": "was recent",
             "updated_at": "2000-01-01T00:00:00Z"},
        ]
        projection = {
            "candidates": [{"slug": "events/journal/was-recent"}],
            "pages_seen": 2,
            "eligible_seen": 1,
            "failed_ops": [],
        }
        with mock.patch.object(
                self.sialib, "gbrain_all_pages",
                return_value=(pages, True, None)), \
                mock.patch.object(
                    self.sialib, "corpus_edges", return_value=([], 0)), \
                mock.patch.object(
                    self.sialib, "_load_graph_projection_state",
                    return_value=projection):
            self.sialib.export_graph()
        graph = self._graph()
        self.assertEqual(graph["snapshot"]["aged_out"], 2)
        self.assertEqual(
            len(graph["nodes"]),
            graph["pages_total"] - graph["snapshot"]["aged_out"]
            - graph["snapshot"]["truncated"])

    def test_dense_valid_edge_window_caps_without_publication_debt(self):
        slugs = [f"events/journal/dense-{index:04d}"
                 for index in range(self.sialib.MAX_GRAPH_NODES)]
        bodies = {slug: [] for slug in slugs}
        admitted = 0
        for source in slugs:
            for target in slugs:
                if source == target:
                    continue
                bodies[source].append(f"[[{target}]]")
                admitted += 1
                if admitted > self.sialib.MAX_GRAPH_EDGES:
                    break
            if admitted > self.sialib.MAX_GRAPH_EDGES:
                break
        self.assertGreater(admitted, self.sialib.MAX_GRAPH_EDGES)
        for slug in slugs:
            self._page(slug, body="\n".join(bodies[slug]) + "\n")

        pages, complete, failure = self.sialib.gbrain_all_pages()
        self.assertTrue(complete, failure)
        self.assertEqual(len(pages), self.sialib.MAX_GRAPH_NODES)
        _nodes, edges, _pages_total = self.sialib.export_graph()
        graph = self._graph()
        self.assertTrue(graph["snapshot"]["complete"])
        self.assertEqual(edges, self.sialib.MAX_GRAPH_EDGES)
        self.assertGreater(graph["snapshot"]["omitted_edges"], 0)
        self.assertEqual(graph["snapshot"]["omitted_nodes"], 0)
        self.assertFalse(
            graph["snapshot"]["omissions_imply_absence"])
        self.assertEqual(graph["snapshot"]["failed_ops"], [])
        self.assertEqual(self.sialib._graph_projection_debt(), "")

    def test_duplicate_and_aged_out_links_cannot_exhaust_display_edge_cap(self):
        aged_body = "\n".join(
            f"[[external/aged-{index:05d}]]"
            for index in range(self.sialib.MAX_GRAPH_EDGES + 1)) + "\n"
        duplicate_body = (
            "[[events/journal/target-a]]\n"
            * (self.sialib.MAX_GRAPH_EDGES + 1)
            + "[[events/journal/target-b]]\n")
        self._page("events/journal/aged", body=aged_body)
        self._page("events/journal/source", body=duplicate_body)
        self._page("events/journal/target-a", body="no links\n")
        self._page("events/journal/target-b", body="no links\n")
        pages = [
            {"slug": "events/journal/aged", "type": "event-day",
             "title": "aged", "updated_at": "2000-01-01T00:00:00Z"},
            {"slug": "events/journal/source", "type": "event-day",
             "title": "source", "updated_at": "2099-01-01T00:00:00Z"},
            {"slug": "events/journal/target-a", "type": "event-day",
             "title": "target a", "updated_at": "2099-01-01T00:00:00Z"},
            {"slug": "events/journal/target-b", "type": "event-day",
             "title": "target b", "updated_at": "2099-01-01T00:00:00Z"},
        ]
        with mock.patch.object(
                self.sialib, "gbrain_all_pages",
                return_value=(pages, True, None)):
            self.sialib.export_graph()
        graph = self._graph()
        self.assertTrue(graph["snapshot"]["complete"])
        self.assertEqual(graph["snapshot"]["omitted_edges"], 0)
        self.assertEqual(
            {(edge["s"], edge["d"]) for edge in graph["edges"]},
            {("events/journal/source", "events/journal/target-a"),
             ("events/journal/source", "events/journal/target-b")})
        self.assertNotIn(
            "events/journal/aged",
            {node["id"] for node in graph["nodes"]})

    def test_graph_publication_drains_pending_but_not_permanent_or_churning_state(self):
        pending = self.sialib.GraphProjectionPending("pending")
        scanning = self.sialib._fresh_graph_projection_state()
        with mock.patch.object(
                self.sialib, "export_graph",
                side_effect=[pending, pending, (1, 2, 3)]) as export, \
                mock.patch.object(
                    self.sialib, "_load_graph_projection_state",
                    return_value=scanning):
            self.assertEqual(
                self.sialib._export_graph_publication(), (1, 2, 3))
            self.assertEqual(export.call_count, 3)
        permanent = dict(scanning, phase="ready", queue=[],
                         failed_ops=["refused"])
        with mock.patch.object(
                self.sialib, "export_graph", side_effect=pending), \
                mock.patch.object(
                    self.sialib, "_load_graph_projection_state",
                    return_value=permanent), \
                self.assertRaises(self.sialib.GraphProjectionPending):
            self.sialib._export_graph_publication()
        with mock.patch.object(self.sialib, "MAX_EVENT_LOOKUP_PAGES", 2), \
                mock.patch.object(
                    self.sialib, "export_graph", side_effect=pending), \
                mock.patch.object(
                    self.sialib, "_load_graph_projection_state",
                    return_value=scanning), \
                self.assertRaisesRegex(
                    self.sialib.GraphProjectionPending,
                    "generation ceiling"):
            self.sialib._export_graph_publication()

    def test_first_light_converges_legacy_memory_authority(self):
        take_pending = mock.Mock(side_effect=[True, False])
        intent_pending = mock.Mock(return_value=False)
        with mock.patch.dict(os.environ, {"SIA_BACKFILL": "1"}), \
                mock.patch.object(
                    self.sialib.siatakes, "migrate_legacy_take_pages",
                    return_value=([], [])) as take_advance, \
                mock.patch.object(
                    self.sialib.siatakes, "advance_intent_history",
                    return_value=([], [])) as intent_advance, \
                mock.patch.object(
                    self.sialib.siatakes, "take_migration_required",
                    take_pending), \
                mock.patch.object(
                    self.sialib.siatakes, "intent_history_required",
                    intent_pending):
            self.sialib._reconcile_legacy_memory_authority({})
        self.assertEqual(take_advance.call_count, 2)
        self.assertEqual(intent_advance.call_count, 2)

    def test_first_light_legacy_authority_has_a_generation_ceiling(self):
        with mock.patch.dict(os.environ, {"SIA_BACKFILL": "1"}), \
                mock.patch.object(
                    self.sialib, "MAX_EVENT_LOOKUP_PAGES", 2), \
                mock.patch.object(
                    self.sialib.siatakes, "migrate_legacy_take_pages",
                    return_value=([], [])) as take_advance, \
                mock.patch.object(
                    self.sialib.siatakes, "advance_intent_history",
                    return_value=([], [])), \
                mock.patch.object(
                    self.sialib.siatakes, "take_migration_required",
                    return_value=True), \
                self.assertRaisesRegex(
                    RuntimeError, "backfill exceeded its generation ceiling"):
            self.sialib._reconcile_legacy_memory_authority({})
        self.assertEqual(take_advance.call_count, 2)

class ProcessWideOsPatches(unittest.TestCase):
    """`mock.patch.object(<module>.os, ...)` reaches the whole process.

    Every module in bin/ does a plain `import os`, so `sialib.os` IS the
    stdlib module object: the patch is not scoped to the module named in
    the target, it replaces that attribute for everything running in the
    interpreter until the block exits. Under the single-threaded
    unittest runner that is safe, and at most of these sites it is the
    only way to fail one exact syscall at one exact moment while the
    real one still answers every other call. It stops being safe the day
    any of this runs in parallel — xdist-style workers, a thread, an
    async runner — because an unrelated test then picks up the injected
    failure and reports it as its own defect.

    So the inventory is frozen rather than forbidden: a new site has to
    be added below on purpose, with its reason, instead of arriving in a
    diff that reads as ordinary mocking. Where a test only needs a
    tripwire ("this call must never happen"), the module-local form
    `mock.patch.object(sialib, "os", <shim>)` rebinds one module's own
    name and leaves the stdlib module alone — prefer it.
    """

    # (test file, patched expression, attribute). A leading "self." is
    # normalised away: `self.sialib.os` and `sialib.os` are the same
    # object, and which one a test writes is only style.
    ACCEPTED = frozenset({
        # Crash injection mid-commit. The durable write must really
        # happen up to the chosen call and fail exactly there, so the
        # recovery path is exercised against a real half-written tree.
        ("test_sia.py", "sialib.os", "fsync"),
        ("test_sia.py", "sialib.os", "unlink"),
        ("test_thought_recovery.py", "sialib.os", "unlink"),
        # Swap the file out from under a check (TOCTOU). Both stats have
        # to be answered for real; only the moment between them moves.
        ("test_calibration_benchmark.py", "siatakes.os", "stat"),
        ("test_dream.py", "sialib.os", "lstat"),
        ("test_release.py", "os", "fstat"),
        ("test_release.py", "os", "stat"),
        ("test_sia.py", "sialib.os", "read"),
        ("test_staging_recovery.py", "siaqueue.os", "lstat"),
        # Surveillance: record every path opened to prove a note body is
        # never read, which needs the real open underneath each call.
        ("test_sia.py", "sialib.os", "open"),
        # Tripwires — the call must never be reached at all. These four
        # need nothing underneath and could move to the module-local
        # shim form; they are accepted, not endorsed.
        ("test_calibration_benchmark.py", "siabench.os", "walk"),
        ("test_calibration_benchmark.py", "siatakes.os", "listdir"),
        ("test_ledger_recovery.py", "sialib.os", "listdir"),
        ("test_sia.py", "sialib.os", "listdir"),
        # A kernel and an owner the test host cannot supply otherwise.
        ("test_ledger_init_recovery.py", "KEEPER.os", "O_TMPFILE"),
        ("test_ledger_init_recovery.py", "KEEPER.os", "geteuid"),
    })

    ADVICE = ("patch a module-local shim — mock.patch.object(<module>, "
              "'os', shim) — or add the site to "
              "ProcessWideOsPatches.ACCEPTED with its reason")

    @staticmethod
    def _expression(node):
        """Render an attribute chain back into dotted source text."""
        parts = []
        while isinstance(node, ast.Attribute):
            parts.append(node.attr)
            node = node.value
        parts.append(node.id if isinstance(node, ast.Name) else "<expr>")
        text = ".".join(reversed(parts))
        return text[len("self."):] if text.startswith("self.") else text

    def _patched_os_attributes(self):
        found = set()
        tests = os.path.join(REPO, "tests")
        for name in sorted(os.listdir(tests)):
            if not name.endswith(".py"):
                continue
            with open(os.path.join(tests, name), encoding="utf-8") as src:
                tree = ast.parse(src.read(), filename=name)
            for node in ast.walk(tree):
                if not isinstance(node, ast.Call) or not node.args:
                    continue
                call = self._expression(node.func)
                target = self._expression(node.args[0])
                if call.endswith("patch.object"):
                    if target != "os" and not target.endswith(".os"):
                        continue
                    # A computed attribute name is unreadable here, so it
                    # is reported rather than guessed at.
                    attribute = "<computed>"
                    if len(node.args) > 1 \
                            and isinstance(node.args[1], ast.Constant):
                        attribute = node.args[1].value
                    found.add((name, target, attribute))
                elif call == "patch" or call.endswith(".patch"):
                    # A string target reaches the same module attribute
                    # by another road; it must not be a way around this.
                    literal = node.args[0]
                    if isinstance(literal, ast.Constant) \
                            and isinstance(literal.value, str) \
                            and ".os." in literal.value:
                        module, _, attribute = literal.value.rpartition(".")
                        found.add((name, module, attribute))
        return found

    def test_no_unlisted_process_wide_os_patch(self):
        unlisted = self._patched_os_attributes() - self.ACCEPTED
        self.assertEqual(
            unlisted, set(),
            f"process-wide os patch not accepted anywhere: {self.ADVICE}")

    def test_accepted_sites_all_still_exist(self):
        # A list that has drifted from the tests stops being a guard and
        # starts being folklore, so a removed site is a failure too.
        stale = self.ACCEPTED - self._patched_os_attributes()
        self.assertEqual(
            stale, set(),
            "ProcessWideOsPatches.ACCEPTED lists sites that are gone; "
            "delete these entries")


if __name__ == "__main__":
    unittest.main(verbosity=2)

"""Fixed-history refusal controls; no successor or general recovery authority."""
import errno
import os
import unittest
from unittest import mock

import receipt_candidate as candidate
import test_recovery_latch


class ReplayRefusal(unittest.TestCase):
    def setUp(self):
        self.fixture = test_recovery_latch.RecoveryLatch()
        self.fixture.setUp()
        self.addCleanup(self.fixture.doCleanups)
        self.root = self.fixture.root
        self.ledger = self.fixture.ledger

    def test_exact_retired_or_decision_refuses_even_empty_or_malformed(self):
        for prefix in ('retired-', 'decision-'):
            for data in (b'', b'{', b'{"status":"COMPLETE"}'):
                with self.subTest(prefix=prefix, data=data):
                    path = self.ledger / (prefix + '4' * 64 + '.json')
                    path.write_bytes(data)
                    errors = self.fixture.refused()
                    self.assertEqual(errors[0]['stage'], 'check-retired-manifest')
                    self.assertEqual(path.read_bytes(), data)
                    self.assertFalse((self.ledger / 'pending.json').exists())
                    path.unlink()  # Disposable test fixture only.

    def test_dangling_symlink_also_refuses_without_following(self):
        path = self.ledger / ('retired-' + '4' * 64 + '.json')
        path.symlink_to(self.root / 'absent-target')
        self.assertEqual(self.fixture.refused()[0]['stage'], 'check-retired-manifest')
        self.assertTrue(path.is_symlink())
        self.assertFalse((self.root / 'absent-target').exists())
        self.assertFalse((self.ledger / 'pending.json').exists())

    def test_directory_at_exact_decision_name_also_refuses(self):
        path = self.ledger / ('decision-' + '4' * 64 + '.json')
        path.mkdir()
        # A new subdirectory changes the pinned ledger link count and is
        # correctly rejected earlier. The direct lookup also rejects its name.
        self.assertEqual(self.fixture.refused()[0]['stage'], 'check-ledger')
        descriptor = os.open(self.ledger, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
        try:
            with self.assertRaisesRegex(ValueError, 'replay refused'):
                candidate.refuse_retired(descriptor, '4' * 64)
        finally:
            os.close(descriptor)
        self.assertTrue(path.is_dir())
        self.assertFalse((self.ledger / 'pending.json').exists())

    def test_other_manifest_never_clears_pending_or_changes_history(self):
        history = self.ledger / ('retired-' + '5' * 64 + '.json')
        history.write_bytes(b'keep-history')
        self.fixture.claim()
        before = (self.ledger / 'pending.json').read_bytes()
        self.fixture.refused()
        self.assertEqual((self.ledger / 'pending.json').read_bytes(), before)
        self.assertEqual(history.read_bytes(), b'keep-history')

    def test_lookup_error_refuses_without_creating_pending(self):
        lookup = os.stat
        def fail(path, *args, **kwargs):
            if isinstance(path, str) and path.startswith('retired-'):
                raise OSError(errno.EIO, 'history lookup failed')
            return lookup(path, *args, **kwargs)
        with mock.patch.object(candidate.os, 'stat', side_effect=fail):
            errors = self.fixture.refused()
        self.assertEqual(errors[0]['stage'], 'check-retired-manifest')
        self.assertEqual(errors[0]['errno'], errno.EIO)
        self.assertFalse((self.ledger / 'pending.json').exists())

    def test_invalid_digest_never_performs_history_lookup(self):
        with mock.patch.object(candidate, 'refuse_retired') as history:
            for digest in ('../x', '', 'g' * 64, 'a' * 63):
                with self.subTest(digest=digest), self.assertRaises(ValueError):
                    candidate.reserve_pending(self.fixture.config, self.fixture.binding,
                                              self.fixture.lock, digest)
        history.assert_not_called()

    def test_main_retired_manifest_prevents_execute_and_popen(self):
        helper, manifest = self.fixture.main_fixture()
        path = self.ledger / ('retired-' + manifest + '.json')
        path.write_bytes(b'prior-completed-manifest')
        with mock.patch.object(candidate.sys, 'argv', ['proof_wrapper.py', manifest]), \
                mock.patch.object(candidate, 'helpers', return_value=helper), \
                mock.patch.object(candidate, 'verify_host'), \
                mock.patch.object(candidate, 'verify_inputs'), \
                mock.patch.object(candidate, 'execute') as execute, \
                mock.patch.object(candidate.subprocess, 'Popen') as popen:
            with self.assertRaises(RuntimeError):
                candidate.main()
        execute.assert_not_called()
        popen.assert_not_called()
        self.assertEqual(path.read_bytes(), b'prior-completed-manifest')
        self.assertFalse((self.ledger / 'pending.json').exists())


if __name__ == '__main__':
    unittest.main(verbosity=2)

"""Unexpected admission marker only; no useful work or external effects."""
import os
from pathlib import Path

with Path('/tmp/out/payload-entered.json').open('x') as stream:
    written = stream.write('UNEXPECTED_PAYLOAD_ADMISSION\n')
    if written != len('UNEXPECTED_PAYLOAD_ADMISSION\n'):
        raise OSError('short marker write')
    stream.flush()
    os.fsync(stream.fileno())
raise SystemExit(1)

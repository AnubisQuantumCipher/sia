"""Instrument the exact ordinary main path at durable active/before-prove."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import signal

ROOT = Path(__file__).resolve().parent


def install_cut(module):
    original = module.save
    def stop_after_active(name, value):
        original(name, value)
        if name == 'active.json':
            os.kill(os.getpid(), signal.SIGSTOP)
            raise RuntimeError('cut must never resume or admit payload')
    module.save = stop_after_active


def main():
    manifest = json.loads((ROOT / 'execution-source.json').read_text())
    for name in ('observer_driver.py', 'proof_wrapper.py'):
        if hashlib.sha256((ROOT / name).read_bytes()).hexdigest() != manifest[name]:
            raise ValueError('instrumented source changed')
    spec = importlib.util.spec_from_file_location('cut_wrapper', ROOT / 'proof_wrapper.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    install_cut(module)
    module.main()


if __name__ == '__main__':
    main()

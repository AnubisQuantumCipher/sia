"""Candidate-only controls; original reuse and current-admission tests remain."""
import contextvars
import hashlib
import json
import time
import unittest
from unittest import mock

import siaeventplan as pages
from tests.test_retained_image_memo import RetainedImageMemo


class DecodeBoundary(unittest.TestCase):
    def test_revocation_after_memo_check_keeps_local_reference(self):
        raw, hint = b"one", "0" * 64
        memo = pages._UTF8Memo()
        memo.decode(raw, hint)
        memo.frozen = True
        scope = pages._UTF8Scope(memo)
        original_type = type

        def revoke_at_check(value):
            kind = original_type(value)
            if value is memo:
                scope.active = False
                scope.memo = None
            return kind

        with mock.patch.object(pages, "type", revoke_at_check, create=True):
            self.assertEqual(pages._decode_utf8(raw, hint, scope), "one")
        self.assertFalse(scope.active)
        self.assertIsNone(scope.memo)

    def test_equal_hint_cannot_substitute_different_bytes(self):
        memo = pages._UTF8Memo()
        self.assertEqual(memo.decode(b"one", "0" * 64), "one")
        memo.frozen = True
        self.assertEqual(memo.decode(b"two", "0" * 64), "two")
        self.assertEqual(len(memo.entries), 1)

    def test_invalid_utf8_is_not_retained(self):
        memo = pages._UTF8Memo()
        for _ in range(2):
            with self.assertRaises(UnicodeDecodeError):
                memo.decode(b"\xff", "0" * 64)
        self.assertEqual(memo.entries, {})
        self.assertEqual(memo.retained_bytes, 0)

    def test_bytes_subclass_keeps_original_decode_behavior(self):
        calls = []

        class Changing(bytes):
            def decode(self, encoding="utf-8", errors="strict"):
                calls.append((encoding, errors))
                return str(len(calls))

        memo = pages._UTF8Memo()
        raw = Changing(b"same")
        self.assertEqual(memo.decode(raw, "0" * 64), "1")
        self.assertEqual(memo.decode(raw, "0" * 64), "2")
        self.assertEqual(memo.entries, {})

    def test_capacity_falls_back_without_refusal(self):
        memo = pages._UTF8Memo()
        with mock.patch.object(pages, "_UTF8_MAX_RETAINED_BYTES", 1):
            self.assertEqual(memo.decode(b"content", "0" * 64), "content")
        self.assertEqual(memo.entries, {})
        for index in range(pages._UTF8_MAX_ENTRIES + 2):
            raw = str(index).encode()
            self.assertEqual(memo.decode(raw, hashlib.sha256(raw).hexdigest()), str(index))
        self.assertEqual(len(memo.entries), pages._UTF8_MAX_ENTRIES)
        self.assertLessEqual(memo.retained_bytes, pages._UTF8_MAX_RETAINED_BYTES)

    def test_context_is_revoked_on_exception_and_nested_scope_restores(self):
        outer, inner = pages._UTF8Memo(), pages._UTF8Memo()
        with pages._utf8_scope(outer):
            scope = pages._UTF8_CONTEXT.get()
            copied = contextvars.copy_context()
            with self.assertRaisesRegex(RuntimeError, "fixture"):
                with pages._utf8_scope(inner):
                    raise RuntimeError("fixture")
            self.assertIs(pages._UTF8_CONTEXT.get(), scope)
        self.assertIsNone(pages._UTF8_CONTEXT.get())
        self.assertFalse(scope.active)
        self.assertIsNone(scope.memo)
        inherited = copied.get(pages._UTF8_CONTEXT)
        self.assertEqual(pages._decode_utf8(b"later", "0" * 64, inherited), "later")
        self.assertEqual(outer.entries, {})

    def test_hash_temporary_released_before_subclass_decode(self):
        trace = []

        class HashText(str):
            def __del__(self):
                trace.append("hash-released")

        class Raw(bytes):
            def decode(self, encoding="utf-8", errors="strict"):
                trace.append("decode")
                return super().decode(encoding, errors)

        encoder = mock.Mock()
        raw = Raw(b"one")
        encoder.b64decode.return_value = raw
        encoder.b64encode.return_value = b"b25l"
        owner = {"base64": encoder, "MAX_EVENT_PAGE_BYTES": 32}
        value = {"raw_utf8_base64": "b25l", "raw_bytes": 3, "raw_sha256": "0" * 64}
        with mock.patch.object(pages, "_hash", side_effect=lambda *_: HashText("0" * 64)):
            self.assertIs(pages._decode(owner, value), raw)
        self.assertEqual(trace, ["hash-released", "decode"])


class TraceOwner(dict):
    def __init__(self, owner):
        super().__init__(owner)
        self.trace = []

    def __getitem__(self, key):
        self.trace.append(("getitem", key))
        return super().__getitem__(key)

    def get(self, key, default=None):
        self.trace.append(("get", key))
        return super().get(key, default)


class CompleteValidation(RetainedImageMemo):
    def test_actual_decoding_reuse_keeps_owner_trace_and_public_prepare(self):
        with self.idle.completed() as (case, retained, _commit, _status, _generation):
            owner = TraceOwner(case.lib.__dict__)
            pin = retained["batch_sha256"]
            self.source._VALIDATED_BATCHES.clear()
            uncached = pages._uncached_utf8
            samples = []
            with mock.patch.object(pages, "_uncached_utf8", wraps=uncached) as decode, \
                    mock.patch.object(self.source._intake, "prepare",
                                      wraps=self.source._intake.prepare) as prepare:
                for mode in ("cold", "warm"):
                    owner.trace.clear()
                    decode.reset_mock()
                    prepare.reset_mock()
                    started = time.perf_counter_ns()
                    self.assertIsNone(self.source.validate_batch(owner, retained, pin))
                    elapsed = time.perf_counter_ns() - started
                    samples.append(dict(mode=mode, elapsed_ns=elapsed,
                                        decoded_calls=decode.call_count,
                                        decoded_bytes=sum(len(c.args[0]) for c in decode.call_args_list),
                                        prepare_calls=prepare.call_count,
                                        trace=list(owner.trace)))
            self.assertGreater(samples[0]["decoded_calls"], 0)
            self.assertLess(samples[1]["decoded_calls"], samples[0]["decoded_calls"])
            self.assertEqual(samples[0]["trace"], samples[1]["trace"])
            self.assertEqual(samples[0]["prepare_calls"], samples[1]["prepare_calls"])
            self.assertGreater(samples[1]["prepare_calls"], 0)
            for item in samples:
                item["owner_reads"] = len(item.pop("trace"))
            print(json.dumps({"utf8_reuse_single_observation": samples,
                              "performance_qualification": False}))


if __name__ == "__main__":
    unittest.main()

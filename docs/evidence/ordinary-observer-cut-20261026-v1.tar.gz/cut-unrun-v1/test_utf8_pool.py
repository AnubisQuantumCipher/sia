"""Deterministic pool exhaustion, stale lease and in-flight consumer controls."""
import concurrent.futures
import contextvars
import hashlib
import json
import threading
import unittest
from unittest import mock

import siaeventplan as pages
from tests import test_retained_image_memo as fixtures


def key(index):
    digest = hashlib.sha256(str(index).encode()).hexdigest()
    return digest, digest, 1024, "fixture"


def projection():
    raw = b"bounded fixture"
    digest = hashlib.sha256(raw).hexdigest()
    identity = dict(subject="fixture", origin="evidence", source_sha256=digest,
                    content_sha256=digest)
    wire = json.dumps(identity, sort_keys=True, separators=(",", ":"),
                      ensure_ascii=False, allow_nan=False).encode()
    version = dict(identity, content=raw.decode(),
                   version_sha256=hashlib.sha256(wire).hexdigest())
    page = dict(slug="fixture", origin="evidence", raw_sha256=digest)
    return raw, page, version


class PoolControls(unittest.TestCase):
    def test_fixed_pool_counts_builders_without_overflow_memo(self):
        pool = pages._UTF8Pool()
        identities = tuple(id(slot.memo) for slot in pool._slots)
        leases = [pool.acquire(key(index)) for index in range(pages._UTF8_POOL_CAPACITY)]
        self.assertTrue(all(lease is not None for lease in leases))
        with mock.patch.object(pages, "_UTF8Memo", side_effect=AssertionError("overflow")):
            self.assertIsNone(pool.acquire(key(99)))
            pool.clear()
            self.assertIsNone(pool.acquire(key(100)))
            for lease in leases:
                pool.release(lease)
            replacement = pool.acquire(key(101))
            self.assertIsNotNone(replacement)
            pool.release(replacement)
        self.assertEqual(tuple(id(slot.memo) for slot in pool._slots), identities)

    def test_clear_during_build_prevents_late_publication(self):
        pool = pages._UTF8Pool(1)
        lease = pool.acquire(key(1))
        memo = pool.pin(lease)
        self.assertEqual(memo.decode(b"old", "0" * 64), "old")
        pool.unpin(lease)
        pool.clear()
        pool.publish(lease)
        pool.release(lease)
        replacement = pool.acquire(key(1))
        self.assertTrue(replacement.cold)
        self.assertIsNone(pool.pin(lease))
        memo = pool.pin(replacement)
        self.assertEqual(memo.entries, {})
        pool.unpin(replacement)
        pool.release(replacement)

    def test_stale_scope_cannot_touch_recycled_slot_or_release_new_consumer(self):
        pool = pages._UTF8Pool(1)
        old = pool.acquire(key(1))
        stale = pages._UTF8Scope(old)
        pool.release(old)
        new = pool.acquire(key(2))
        memo = pool.pin(new)
        self.assertEqual(memo.decode(b"new", "0" * 64), "new")
        entries = dict(memo.entries)
        with pages._utf8_consumer(stale) as retained:
            self.assertIsNone(retained)
        pool.unpin(old)
        pool.publish(old)
        pool.release(old)
        self.assertIsNone(pool.pin(new), "stale release must not unpin a new consumer")
        self.assertIsNone(pool.acquire(key(3)))
        self.assertEqual(memo.entries, entries)
        pool.unpin(new)
        pool.release(new)

    def test_returned_validation_keeps_paused_consumer_reserved(self):
        pool = pages._UTF8Pool(1)
        lease = pool.acquire(key(1))
        raw, page, version = projection()
        entered, proceed = threading.Event(), threading.Event()

        def projector(**_arguments):
            entered.set()
            if not proceed.wait(5):
                raise RuntimeError("fixture synchronization deadline")
            return version

        owner = {"_corpus_page_version_from_bytes": projector}
        with concurrent.futures.ThreadPoolExecutor(max_workers=1) as executor:
            try:
                with pages._utf8_scope(lease):
                    scope = pages._UTF8_CONTEXT.get()
                    context = contextvars.copy_context()
                    pending = executor.submit(context.run, pages._checked_version,
                                              owner, page, raw, scope=scope)
                    self.assertTrue(entered.wait(5))
                self.assertFalse(scope.active)
                pool.release(lease)
                pool.clear()
                self.assertIsNone(pool.acquire(key(2)))
            finally:
                proceed.set()
            self.assertIs(pending.result(timeout=5), version)
        replacement = pool.acquire(key(2))
        self.assertIsNotNone(replacement)
        self.assertTrue(replacement.cold)
        pool.release(replacement)

    def test_simultaneous_consumer_falls_back_and_exception_unpins(self):
        pool = pages._UTF8Pool(1)
        lease = pool.acquire(key(1))
        scope = pages._UTF8Scope(lease)
        with self.assertRaisesRegex(RuntimeError, "fixture"):
            with pages._utf8_consumer(scope) as memo:
                self.assertIsNotNone(memo)
                with pages._utf8_consumer(scope) as second:
                    self.assertIsNone(second)
                self.assertIsNone(pool.pin(lease))
                raise RuntimeError("fixture")
        self.assertIsNotNone(pool.pin(lease))
        pool.unpin(lease)
        pool.release(lease)

    def test_generation_exhaustion_never_wraps(self):
        pool = pages._UTF8Pool(1)
        pool._slots[0].generation = pages._UTF8_MAX_GENERATION - 1
        lease = pool.acquire(key(1))
        self.assertEqual(lease.generation, pages._UTF8_MAX_GENERATION)
        memo = pool.pin(lease)
        self.assertEqual(memo.decode(b"last", "0" * 64), "last")
        pool.unpin(lease)
        pool.publish(lease)
        pool.release(lease)
        self.assertIsNone(pool.acquire(key(1)))
        self.assertIsNone(pool.acquire(key(2)))
        pool.clear()
        self.assertIsNone(pool.acquire(key(1)))

    def test_nonnative_key_cannot_call_equality_under_lock(self):
        class Hostile:
            __hash__ = None

            def __eq__(self, _other):
                raise AssertionError("untrusted equality")

        pool = pages._UTF8Pool(1)
        lease = pool.acquire(key(1))
        memo = pool.pin(lease)
        self.assertEqual(memo.decode(b"seed", "0" * 64), "seed")
        pool.unpin(lease)
        pool.publish(lease)
        pool.release(lease)
        self.assertIsNone(pool.acquire((Hostile(), "0" * 64, 1024, "fixture")))
        retained = pool.acquire(key(1))
        self.assertFalse(retained.cold)
        pool.release(retained)

    def test_decode_exception_releases_consumer_pin(self):
        pool = pages._UTF8Pool(1)
        lease = pool.acquire(key(1))
        _raw, page, version = projection()
        owner = {"_corpus_page_version_from_bytes": mock.Mock(return_value=version)}
        with self.assertRaises(UnicodeDecodeError):
            pages._checked_version(owner, page, b"\xff", scope=pages._UTF8Scope(lease))
        owner["_corpus_page_version_from_bytes"].assert_not_called()
        self.assertIsNotNone(pool.pin(lease))
        pool.unpin(lease)
        pool.release(lease)

    def test_hash_exception_releases_consumer_pin(self):
        pool = pages._UTF8Pool(1)
        lease = pool.acquire(key(1))
        raw, page, version = projection()
        owner = {"_corpus_page_version_from_bytes": mock.Mock(return_value=version)}
        with mock.patch.object(pages.hashlib, "sha256", side_effect=RuntimeError("fixture")):
            with self.assertRaisesRegex(RuntimeError, "fixture"):
                pages._checked_version(owner, page, raw, scope=pages._UTF8Scope(lease))
        owner["_corpus_page_version_from_bytes"].assert_not_called()
        self.assertIsNotNone(pool.pin(lease))
        pool.unpin(lease)
        pool.release(lease)

    def test_projector_exception_releases_consumer_pin(self):
        pool = pages._UTF8Pool(1)
        lease = pool.acquire(key(1))
        raw, page, _version = projection()
        owner = {"_corpus_page_version_from_bytes": mock.Mock(side_effect=RuntimeError("fixture"))}
        with self.assertRaisesRegex(RuntimeError, "fixture"):
            pages._checked_version(owner, page, raw, scope=pages._UTF8Scope(lease))
        owner["_corpus_page_version_from_bytes"].assert_called_once()
        self.assertIsNotNone(pool.pin(lease))
        pool.unpin(lease)
        pool.release(lease)


class CompleteValidation(unittest.TestCase):
    def setUp(self):
        self.fixture = fixtures.RetainedImageMemo(methodName="runTest")
        self.fixture.setUp()
        self.addCleanup(self.fixture.doCleanups)

    def test_pool_exhaustion_masks_inherited_memo_and_validates_uncached(self):
        with self.fixture.idle.completed() as (case, retained, _commit, _status, _generation):
            pool = pages._UTF8Pool(1)
            occupied = pool.acquire(key(1))
            source = self.fixture.source
            outer = pages._UTF8Memo()
            try:
                with mock.patch.object(source, "_VALIDATED_BATCHES", pool), \
                        mock.patch.object(pages, "_uncached_utf8",
                                          wraps=pages._uncached_utf8) as decode:
                    with pages._utf8_scope(outer):
                        scope = pages._UTF8_CONTEXT.get()
                        self.assertIsNone(source.validate_batch(case.lib.__dict__, retained,
                                                                retained["batch_sha256"]))
                        self.assertIs(pages._UTF8_CONTEXT.get(), scope)
                        self.assertGreater(decode.call_count, 0)
                self.assertEqual(outer.entries, {})
            finally:
                pool.release(occupied)
            lease = pool.acquire(key(2))
            self.assertIsNotNone(lease)
            pool.release(lease)


if __name__ == "__main__":
    unittest.main()

"""One bounded, uninstalled compiler-plugin build; never product acceptance."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path(__file__).parent
HEADERS = Path('/usr/lib/gcc/aarch64-unknown-linux-gnu/16.1.1/plugin/include')


def digest(path):
    value = hashlib.sha256()
    with path.open('rb') as stream:
        for _ in range(4096):
            chunk = stream.read(1048576)
            if not chunk:
                return value.hexdigest()
            value.update(chunk)
    raise ValueError('identity input exceeds capacity')


def identities():
    paths = [Path(__file__), ROOT / 'checked_memset_model.cc',
             Path('/usr/bin/g++'), Path('/usr/bin/as'), Path('/usr/bin/ld'),
             HEADERS.parent.parent / 'cc1plus']
    for directory, directories, files in os.walk(HEADERS):
        if len(directories) > 64 or len(files) > 2048:
            raise ValueError('header directory capacity')
        paths.extend(Path(directory) / name for name in files)
        if len(paths) > 4096:
            raise ValueError('header input capacity')
    return {str(path): digest(path) for path in sorted(paths)}


def command(run):
    return ['/usr/bin/flock', '-F', '-n', '-E', '75',
            '/home/sicarii/.worldline-heavy.lock', '/usr/bin/prlimit',
            '--as=2147483648:2147483648', '--fsize=16777216:16777216',
            '--core=0:0', '--', '/usr/bin/timeout', '--kill-after=5s', '30s',
            '/usr/bin/g++', '-std=gnu++17', '-O2', '-fPIC', '-shared',
            '-fno-rtti', '-fno-exceptions', '-Wall', '-Wextra', '-Wpedantic',
            '-Werror', '-Wconversion', '-Wsign-conversion', '-Wshadow',
            '-Wformat=2', '-Wundef', '-Wswitch-enum', '-Wnon-virtual-dtor',
            '-Woverloaded-virtual', '-I', str(HEADERS), '-MD', '-MF',
            str(run / 'dependencies.d'), str(ROOT / 'checked_memset_model.cc'),
            '-o', str(run / 'checked_memset_model.so')]


def main():
    run = ROOT / 'build'
    run.mkdir()
    for name in ('home', 'tmp'):
        (run / name).mkdir()
    free = os.statvfs(ROOT).f_bavail * os.statvfs(ROOT).f_frsize
    if free < 10067108864:
        raise ValueError('reserve plus bounded diagnostic allocation')
    before = identities()
    args = command(run)
    env = dict(PATH='/usr/bin:/bin', HOME=str(run / 'home'),
               TMPDIR=str(run / 'tmp'), LANG='C', LC_ALL='C', TZ='UTC')
    started = time.monotonic_ns()
    with (run / 'stdout').open('xb') as out, (run / 'stderr').open('xb') as err:
        result = subprocess.run(args, cwd=run, env=env, stdout=out, stderr=err,
                                timeout=40, check=False)
    after = identities()
    record = dict(command=args, environment=env, exit=result.returncode,
                  elapsed_ns=time.monotonic_ns() - started, free_bytes=free,
                  before=before, after=after, inputs_unchanged=before == after,
                  scope='Uninstalled diagnostic plugin; qualification incomplete',
                  product_acceptance=False)
    with (run / 'result.json').open('x') as stream:
        json.dump(record, stream, indent=2)
        stream.write('\n')
    print(json.dumps({key: record[key] for key in
                      ('exit', 'elapsed_ns', 'inputs_unchanged', 'scope')}))


if __name__ == '__main__':
    main()

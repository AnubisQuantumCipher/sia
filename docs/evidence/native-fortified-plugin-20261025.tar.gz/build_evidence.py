"""Build or reproduce the explicit, bounded non-final evidence package."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import sys
import tarfile

ROOT = Path(__file__).parent
PUBLISHER = Path('/home/sicarii/Work/sia-assurance-checkpoint-20261023')
ARCHIVE = PUBLISHER / 'docs/evidence/native-fortified-plugin-20261025.tar.gz'
METADATA = PUBLISHER / 'docs/NATIVE-FORTIFIED-PLUGIN-20261025.json'
NAMES = ('build_evidence.py', 'FINDING.md', 'checked_memset_model.initial.cc', 'checked_memset_model.cc', 'run_build.py', 'finding.json', 'build/result.json', 'build/stdout', 'build/stderr', 'build/dependencies.d', 'runner-static-result.json', 'runner-static.stdout', 'runner-static.stderr', 'independent-source-review.txt', 'storage-preflight.json', 'storage-pin-readback.json')


def package():
    manifest, content, total = {}, {}, 0
    for name in NAMES:
        with (ROOT / name).open('rb') as stream:
            raw = stream.read(2097153)
        total += len(raw)
        if len(raw) > 2097152 or total > 8388608:
            raise ValueError('evidence byte capacity')
        content[name] = raw
        manifest[name] = dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())
    content['MANIFEST.json'] = (json.dumps(manifest, indent=2, sort_keys=True) + '\n').encode()
    output = io.BytesIO()
    with gzip.GzipFile(filename='', mode='wb', fileobj=output, mtime=0) as zipped:
        with tarfile.open(fileobj=zipped, mode='w', format=tarfile.USTAR_FORMAT) as archive:
            for name, raw in sorted(content.items()):
                entry = tarfile.TarInfo(name)
                entry.mode, entry.size = 0o644, len(raw)
                archive.addfile(entry, io.BytesIO(raw))
    return output.getvalue(), manifest


def main():
    if sys.argv[1:] not in ([], ['--check']):
        raise ValueError('only --check is supported')
    archive, manifest = package()
    metadata = dict(
        status='FAILED_STRICT_PLUGIN_BUILD_NOT_ADOPTED',
        carrier_base='d7740bd79bc7ebed69071a82fc246f98b54b5a4f',
        compiler_source='301eb08fa2c5b6f3045260bf1294c2e2bacbcd90',
        compiler_result='exit1: installed GCC header diagnostics under strict warnings',
        controls='UNRUN; no shared library produced',
        static='Frozen167-rule partial profile exit0 for runner; no whole-tree claim',
        archive=ARCHIVE.name, archive_bytes=len(archive),
        archive_sha256=hashlib.sha256(archive).hexdigest(), members=manifest,
        review='ActualGPT6.1 read-only source/raw review; no independent execution',
        limitations='No plugin loaded, compiler qualification, full SIA convergence, installation or release; original plugin-free gate unchanged.')
    encoded = (json.dumps(metadata, indent=2, sort_keys=True) + '\n').encode()
    if sys.argv[1:]:
        if ARCHIVE.read_bytes() != archive or METADATA.read_bytes() != encoded:
            raise ValueError('package reproduction mismatch')
    else:
        with ARCHIVE.open('xb') as stream:
            stream.write(archive)
        with METADATA.open('xb') as stream:
            stream.write(encoded)
    print(json.dumps({'status': 'MATCH' if sys.argv[1:] else 'CREATED',
                      'archive_sha256': metadata['archive_sha256']}))


if __name__ == '__main__':
    main()

/* Isolated GCC analyzer experiment. NOT an admitted SIA compiler profile.
   Fill operation follows GCC kf.cc, GPL-3.0-or-later; copyright FSF 2020-2026.
   Capacity dispatch and registration below are experimental. */
#include "analyzer/common.h"
#include "gcc-plugin.h"
#include "plugin-version.h"
#include "context.h"
#include "channels.h"
#include "analyzer/region-model.h"
#include "analyzer/call-details.h"

int plugin_is_GPL_compatible;

namespace {

bool supported_call(const ana::call_details &cd)
{
    tree fn = gimple_call_fndecl(&cd.get_call_stmt());
    return fn != nullptr && fndecl_built_in_p(fn, BUILT_IN_MEMSET_CHK)
        && cd.num_args() == 4U && cd.arg_is_pointer_p(0U)
        && cd.arg_is_integral_p(1U) && cd.arg_is_size_p(2U)
        && cd.arg_is_size_p(3U) && DECL_STRUCT_FUNCTION(fn) == nullptr;
}

tristate capacity_sufficient(const ana::call_details &cd)
{
    return cd.get_model()->eval_condition(cd.get_arg_svalue(2U), LE_EXPR,
                                          cd.get_arg_svalue(3U));
}

void fill_returning_call(const ana::call_details &cd)
{
    const ana::svalue *dest = cd.get_arg_svalue(0U);
    ana::region_model *model = cd.get_model();
    ana::region_model_manager *manager = cd.get_manager();
    const ana::region *region = model->deref_rvalue(dest, cd.get_arg_tree(0U),
                                                  cd.get_ctxt());
    const ana::svalue *value = manager->get_or_create_cast(
        unsigned_char_type_node, cd.get_arg_svalue(1U));
    const ana::region *sized = manager->get_sized_region(
        region, NULL_TREE, cd.get_arg_svalue(2U));
    model->fill_region(sized, value, cd.get_ctxt());
    (void)cd.maybe_set_lhs(dest);
}

class checked_memset final : public ana::builtin_known_function {
public:
    enum built_in_function builtin_code() const override
    {
        return BUILT_IN_MEMSET_CHK;
    }

    bool matches_call_types_p(const ana::call_details &cd) const override
    {
        if (!supported_call(cd)) return false;
        const tristate sufficient = capacity_sufficient(cd);
        return sufficient.is_true() || sufficient.is_false();
    }

    void impl_call_pre(const ana::call_details &cd) const override
    {
        if (capacity_sufficient(cd).is_true()) {
            fill_returning_call(cd);
            return;
        }
        error_at(cd.get_location(), "diagnostic checked memset capacity failure");
        if (cd.get_ctxt() != nullptr) cd.get_ctxt()->terminate_path();
    }
};

class listener final : public gcc::topics::analyzer_events::subscriber {
public:
    void on_message(const gcc::topics::analyzer_events::on_ana_init &event) override
    {
        if (registered) {
            error("diagnostic checked memset model initialized twice");
            return;
        }
        registered = true;
        event.register_known_function("__builtin___memset_chk",
                                      std::make_unique<checked_memset>());
        event.register_known_function("__memset_chk",
                                      std::make_unique<checked_memset>());
    }
private:
    bool registered = false;
};

listener observer;

} // namespace

extern "C" int plugin_init(struct plugin_name_args *info,
                           struct plugin_gcc_version *version);

extern "C" int plugin_init(struct plugin_name_args *info,
                           struct plugin_gcc_version *version)
{
    if (!plugin_default_version_check(version, &gcc_version)) {
        error("diagnostic plugin compiler version mismatch");
        return 1;
    }
    if (info->argc != 0) {
        error("diagnostic plugin accepts no arguments");
        return 1;
    }
    (void)g->get_channels().analyzer_events_channel.add_subscriber(observer);
    return 0;
}

"""Isolate a test proof obligation without changing its source or caps."""
import importlib.util
import json
from pathlib import Path
import shutil

ROOT = Path(__file__).parent
SUPPORT = ROOT / 'run-continuity-checkpoint-wire-development-v1.py'


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main():
    helper = load('checkpoint_helper', SUPPORT)
    driver = load('driver', helper.DRIVER)
    driver.CHANGED = helper.CHANGED
    output = ROOT / 'continuity-checkpoint-canonical-diagnostic-v2'
    output.mkdir()
    helper.storage(output, 'storage-preflight.json')
    receipt = driver.snapshot(output)
    receipt['scope'] = 'DIAGNOSTIC_ONLY: Check_Zero_And_Canonical; no whole-harness or full-project claim'
    receipt['runner_dependencies'] = {}
    for path in (Path(__file__), SUPPORT, helper.DRIVER):
        receipt['runner_dependencies'][str(path)] = helper.digest(path)
        shutil.copyfile(path, output / path.name)
    source = Path(receipt['cwd'])
    receipt['source_files'] = {str(p.relative_to(source)): helper.digest(p)
                              for p in sorted((source / 'spark').rglob('*')) if p.is_file()}
    test = source / 'spark/tests/continuity_checkpoint_wire_tests.adb'
    candidates = [i for i, line in enumerate(test.read_text().splitlines(), 1)
                  if line.strip() == 'procedure Check_Zero_And_Canonical']
    if len(candidates) != 1:
        raise ValueError('ambiguous proof target')
    passed = driver.check(output, receipt, 'canonical-proof', '120s', [
        'gnatprove', '-P', 'spark/sia_assurance.gpr', '-u',
        'continuity_checkpoint_wire_tests.adb',
        '--limit-subp=continuity_checkpoint_wire_tests.adb:' + str(candidates[0]),
        '--mode=all', '--assumptions', '--no-inlining', '--memlimit=512', '--timeout=10'])
    helper.retain_raw(output, receipt, 'canonical-proof')
    receipt['proof_tools_after'] = driver.proof_tools()
    receipt['tools_unchanged'] = receipt['proof_tools_before'] == receipt['proof_tools_after']
    (output / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    helper.storage(output, 'storage-after.json')
    return 0 if passed and receipt['tools_unchanged'] else 1


if __name__ == '__main__':
    raise SystemExit(main())

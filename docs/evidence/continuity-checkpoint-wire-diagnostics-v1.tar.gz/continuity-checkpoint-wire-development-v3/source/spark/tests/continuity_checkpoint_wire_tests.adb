with SIA_Policy;
with SIA_Continuity;
with SIA_Continuity_Checkpoint_Wire;

procedure Continuity_Checkpoint_Wire_Tests with SPARK_Mode is
   use SIA_Policy;
   use SIA_Continuity;
   use SIA_Continuity_Checkpoint_Wire;
   States : constant array (Coverage_Code) of Coverage_State :=
     [Not_Observed, Unavailable, Observed_Empty, Partial, Complete];

   procedure Check_Zero_And_Canonical
     with Global => null, Always_Terminates
   is
      Bytes : Checkpoint_Bytes := [others => 0];
      Item : Checkpoint;
      Accepted : Boolean;
   begin
      Decode (Bytes, Accepted, Item);
      pragma Assert (Accepted and then Item.Count = 0);
      pragma Assert (Item /= Empty_Checkpoint);
      pragma Assert
        (for all I in Claim_Index => Item.Claims (I).From = Source_Record
         and then Item.Claims (I).Speaker = User);
      for I in Claim_Index loop
         Bytes ((320 + (I - 1) * 128) + 106) := 3;
         Bytes ((320 + (I - 1) * 128) + 107) := 2;
         pragma Loop_Invariant
           (for all J in Claim_Index =>
              (if J <= I then
                  Bytes ((320 + (J - 1) * 128) + 106) = 3 and then
                  Bytes ((320 + (J - 1) * 128) + 107) = 2));
      end loop;
      Decode (Bytes, Accepted, Item);
      pragma Assert (Accepted and then Item = Empty_Checkpoint);
   end Check_Zero_And_Canonical;

   procedure Check_Header with Global => null, Always_Terminates is
      Bytes : Checkpoint_Bytes := [257 => 127, 258 .. 264 => 255,
        265 => 1, 266 => 2, 267 => 3, 268 => 4,
        269 => 5, 270 => 6, 271 => 7, 272 => 8, 280 => 9, others => 0];
      Item : Checkpoint;
      Accepted : Boolean;
   begin
      for I in Digest'Range loop
         Bytes := (Bytes with delta
           I => 1, 32 + I => 2, 64 + I => 3, 96 + I => 4,
           128 + I => 5, 160 + I => 6, 192 + I => 7, 224 + I => 8);
         pragma Loop_Invariant
           (for all J in 1 .. I =>
              Bytes (J) = 1 and then Bytes (32 + J) = 2 and then
              Bytes (64 + J) = 3 and then Bytes (96 + J) = 4 and then
              Bytes (128 + J) = 5 and then Bytes (160 + J) = 6 and then
              Bytes (192 + J) = 7 and then Bytes (224 + J) = 8);
      end loop;
      Decode (Bytes, Accepted, Item);
      pragma Assert (Accepted);
      pragma Assert
        (Item.Scope = Context'(Task_Id => [others => 1],
         Session_Id => [others => 2], Repository => [others => 3],
         Revision => [others => 4], Dirty => [others => 5]));
      pragma Assert (Item.Identity = Digest'[others => 6] and then
                     Item.Previous = Digest'[others => 7] and then
                     Item.Capture = Digest'[others => 8]);
      pragma Assert (Item.Epoch = Generation'Last and then
                     Item.Through = 16#0102_0304_0506_0708# and then
                     Item.Retention_Epoch = 9);
   end Check_Header;

   procedure Check_Coverage with Global => null, Always_Terminates is
      Bytes : Checkpoint_Bytes;
      Item : Checkpoint;
      Accepted : Boolean;
   begin
      for Kind in Claim_Kind loop
         for Code in Digest_Byte loop
            Bytes := [others => 0];
            Bytes (281 + Claim_Kind'Pos (Kind)) := Code;
            Decode (Bytes, Accepted, Item);
            pragma Assert (Accepted = (Code <= 4));
            pragma Assert
              (if Accepted then Item.Coverage (Kind) = States (Code)
               else Item = Empty_Checkpoint);
         end loop;
      end loop;
   end Check_Coverage;

   procedure Check_Counts with Global => null, Always_Terminates is
      Bytes : Checkpoint_Bytes;
      Item : Checkpoint;
      Accepted : Boolean;
   begin
      for Code in Digest_Byte loop
         Bytes := [294 => Code, others => 0];
         Decode (Bytes, Accepted, Item);
         pragma Assert (Accepted = (Code <= 64));
         pragma Assert (if Accepted then Item.Count = Natural (Code)
                        else Item = Empty_Checkpoint);
         Bytes := [295 => Code, others => 0];
         Decode (Bytes, Accepted, Item);
         pragma Assert (Accepted = (Code <= 16));
         pragma Assert (if Accepted then Item.Operations_Count = Natural (Code)
                        else Item = Empty_Checkpoint);
      end loop;
   end Check_Counts;

   procedure Check_Header_Refusals
     with Global => null, Always_Terminates
   is
      Bytes : Checkpoint_Bytes;
      Item : Checkpoint;
      Accepted : Boolean;
   begin
      for I in 296 .. 320 loop
         Bytes := [others => 0];
         Bytes (I) := 1;
         Decode (Bytes, Accepted, Item);
         pragma Assert (not Accepted and then Item = Empty_Checkpoint);
      end loop;
      for Field in 0 .. 2 loop
         for Code in Digest_Byte loop
            Bytes := [others => 0];
            Bytes (257 + Field * 8) := Code;
            Decode (Bytes, Accepted, Item);
            pragma Assert (Accepted = (Code <= 127));
            pragma Assert (if not Accepted then Item = Empty_Checkpoint);
         end loop;
      end loop;
   end Check_Header_Refusals;

   procedure Check_Inactive_Claims
     with Global => null, Always_Terminates
   is
      Bytes : Checkpoint_Bytes;
      Item : Checkpoint;
      Accepted : Boolean;
   begin
      for I in Claim_Index loop
         Bytes := [others => 0];
         Bytes ((320 + (I - 1) * 128) + 105) := 13;
         Decode (Bytes, Accepted, Item);
         pragma Assert (not Accepted and then Item = Empty_Checkpoint);
         Bytes := [others => 0];
         Bytes ((320 + (I - 1) * 128) + 128) := 1;
         Decode (Bytes, Accepted, Item);
         pragma Assert (not Accepted and then Item = Empty_Checkpoint);
         Bytes := [others => 0];
         Bytes ((320 + (I - 1) * 128) + 97) := 128;
         Decode (Bytes, Accepted, Item);
         pragma Assert (not Accepted and then Item = Empty_Checkpoint);
      end loop;
   end Check_Inactive_Claims;

   procedure Check_Inactive_Operations
     with Global => null, Always_Terminates
   is
      Bytes : Checkpoint_Bytes;
      Item : Checkpoint;
      Accepted : Boolean;
   begin
      for I in Operation_Index loop
         Bytes := [others => 0];
         Bytes ((8512 + (I - 1) * 144) + 129) := 5;
         Decode (Bytes, Accepted, Item);
         pragma Assert (not Accepted and then Item = Empty_Checkpoint);
         Bytes := [others => 0];
         Bytes ((8512 + (I - 1) * 144) + 130) := 2;
         Decode (Bytes, Accepted, Item);
         pragma Assert (not Accepted and then Item = Empty_Checkpoint);
         Bytes := [others => 0];
         Bytes ((8512 + (I - 1) * 144) + 144) := 1;
         Decode (Bytes, Accepted, Item);
         pragma Assert (not Accepted and then Item = Empty_Checkpoint);
      end loop;
   end Check_Inactive_Operations;

   procedure Check_Policy_Invalid_Preservation
     with Global => null, Always_Terminates
   is
      Bytes : constant Checkpoint_Bytes :=
        [8385 => 42, 8489 => 11, 8490 => 2, 8491 => 1, 8492 => 64,
         10673 => 43, 10801 => 4, others => 0];
      Item : Checkpoint;
      Accepted : Boolean;
   begin
      Decode (Bytes, Accepted, Item);
      pragma Assert (Accepted and then Item.Count = 0
                     and then Item.Operations_Count = 0);
      pragma Assert (Item.Claims (64).Identity (1) = 42 and then
                     Item.Claims (64).Kind = Permission_Reference and then
                     Item.Claims (64).From = Model_Record and then
                     Item.Claims (64).Speaker = Assistant and then
                     Item.Claims (64).Replaces = 64);
      pragma Assert (not Valid_Claim (Item.Claims (64)));
      pragma Assert (Item.Operations (16).Identity (1) = 43 and then
                     Item.Operations (16).Stage = Acknowledged and then
                     not Item.Operations (16).Has_Result);
      pragma Assert (not Valid_Operation (Item.Operations (16)));
      pragma Assert (not Valid (Item));
   end Check_Policy_Invalid_Preservation;
begin
   Check_Zero_And_Canonical;
   Check_Header;
   Check_Coverage;
   Check_Counts;
   Check_Header_Refusals;
   Check_Inactive_Claims;
   Check_Inactive_Operations;
   Check_Policy_Invalid_Preservation;
end Continuity_Checkpoint_Wire_Tests;

"""Retain bounded I/O diagnostics and failures; never whole-system acceptance."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import subprocess
import sys
import tarfile

ROOT = Path(__file__).parent
REPO = Path('/home/sicarii/Work/sia-assurance-kernel-20261019')
RUN = ROOT / 'continuity-io-development-v2'
WITNESS = ROOT / 'continuity-io-resource-witness-v2'
DEST = REPO / 'docs/CONTINUITY-IO-EVIDENCE-20261021.json'
BUNDLE = REPO / 'docs/evidence/continuity-io-diagnostics-v1.tar.gz'


def read(path):
    with path.open('rb') as stream:
        value = stream.read(4_194_305)
    if len(value) > 4_194_304:
        raise ValueError('evidence input byte cap')
    return value


def sha(path):
    return hashlib.sha256(read(path)).hexdigest()


def validate(receipt):
    if receipt['base'] != '9d30f73168c34fbad97943217e7bfde892c6cf59':
        raise ValueError('unexpected diagnostic baseline')
    names = ['strict-probe-build', 'continuity-io-tests', 'original-transport-build',
             'all-transport-support-tests', 'strict-policy-build', 'policy-runtime',
             'transaction-runtime', 'request_wire-runtime', 'request_admission-runtime',
             'grant_lifetime-runtime', 'retraction-runtime', 'consolidation-runtime',
             'continuity-runtime', 'continuity_transition-runtime',
             'continuity_record_wire-runtime', 'continuity_observation_wire-runtime',
             'continuity_checkpoint_wire-runtime', 'continuity_current_wire-runtime',
             'continuity_frame_wire-runtime', 'continuity_response_wire-runtime']
    if [entry['name'] for entry in receipt['checks']] != names or not receipt['passed']:
        raise ValueError('missing or failed original control')
    for entry in receipt['checks']:
        duration = '120s' if entry['name'].endswith('build') else '30s'
        if entry['exit'] != 0 or entry['command'][:3] != ['timeout', '--kill-after=5s', duration]:
            raise ValueError('command result or cap mismatch')
    if (len(receipt['proof_tools_before']) != 10 or not receipt['tools_unchanged']
            or receipt['proof_tools_before'] != receipt['proof_tools_after']):
        raise ValueError('tool identity mismatch')
    for name, expected in receipt['source_files'].items():
        if sha(RUN / 'source' / name) != expected or sha(REPO / name) != expected:
            raise ValueError('source mismatch: ' + name)
    for name, expected in receipt['runner_dependencies'].items():
        if sha(RUN / Path(name).name) != expected:
            raise ValueError('retained runner changed')
    if sha(RUN / 'source/spark/bin/continuity_probe') != receipt['binary_sha256']:
        raise ValueError('compiled binary mismatch')
    for name, row in receipt['compiler_stack'].items():
        if sha(RUN / 'compiler-stack' / name) != row['sha256']:
            raise ValueError('compiler stack report mismatch')


def validate_witness(receipt):
    value = json.loads(read(WITNESS / 'receipt.json'))
    if value['source_receipt_sha256'] != sha(RUN / 'receipt.json'):
        raise ValueError('resource witness source mismatch')
    for label in ('restore', 'transition'):
        result = value[label]
        if (result['terminal_exit'] != 0
                or result['binary_sha256'] != receipt['binary_sha256']
                or result['usage_sha256'] != sha(WITNESS / (label + '-usage.log'))):
            raise ValueError('resource witness mismatch')
    for path, expected in value['tools_sha256'].items():
        if sha(Path(path)) != expected:
            raise ValueError('resource tool mismatch')
    return value


def pure_source_bindings(receipt):
    values = {}
    for name, expected in receipt['source_files'].items():
        if not name.startswith('spark/src/'):
            continue
        raw = subprocess.check_output(['git', 'show',
            '74efd05673719ce5a740d83510c652c5a956c930:' + name], cwd=REPO, timeout=10)
        if hashlib.sha256(raw).hexdigest() != expected:
            raise ValueError('pure source changed relative to prior scoped evidence')
        values[name] = expected
    return values


def bundle_paths():
    paths = [Path(__file__), ROOT / 'continuity-io-source-review-v3.txt',
             ROOT / 'continuity-io-source-inventory-v2.json',
             ROOT / 'continuity-io-resource-witness-v1-failure.json',
             ROOT / 'continuity-io-resource-witness-v1.py',
             ROOT / 'continuity-io-resource-witness-v2.py',
             ROOT / 'continuity-resource-observer-v1.py']
    for version in ('v1', 'v2'):
        run = ROOT / ('continuity-io-development-' + version)
        receipt = json.loads(read(run / 'receipt.json'))
        paths += [run / 'receipt.json', run / 'base.tar']
        paths += [run / (entry['name'] + '.log') for entry in receipt['checks']]
        paths += [run / 'source' / name for name in receipt['files']]
        paths += list((run / 'compiler-stack').glob('*.su'))
        paths += list(run.glob('run-*.py'))
    paths += list(WITNESS.glob('*.log')) + [WITNESS / 'receipt.json']
    return sorted(set(paths))


def package(paths):
    if len(paths) > 128:
        raise ValueError('artifact count cap')
    payload, artifacts, total = io.BytesIO(), [], 0
    with gzip.GzipFile(fileobj=payload, mode='wb', mtime=0) as zipped:
        with tarfile.open(fileobj=zipped, mode='w|', format=tarfile.USTAR_FORMAT) as archive:
            for path in paths:
                raw = read(path)
                total += len(raw)
                if total > 16 * 1024 * 1024:
                    raise ValueError('aggregate artifact cap')
                name = str(path.relative_to(ROOT))
                info = tarfile.TarInfo(name)
                info.size, info.mode = len(raw), path.stat().st_mode & 0o777
                archive.addfile(info, io.BytesIO(raw))
                artifacts.append({'path': name, 'sha256': hashlib.sha256(raw).hexdigest()})
    return payload.getvalue(), artifacts


def main():
    if sys.argv[1:] not in ([], ['--check']):
        raise ValueError('optional --check only')
    receipt = json.loads(read(RUN / 'receipt.json'))
    validate(receipt)
    witness = validate_witness(receipt)
    unchanged = pure_source_bindings(receipt)
    bundle, artifacts = package(bundle_paths())
    value = {'kind': 'TESTED disposable I/O, not installed or whole-system acceptance',
             'receipt': receipt, 'resource_witness': witness,
             'pure_sources_unchanged_from': '74efd05673719ce5a740d83510c652c5a956c930',
             'unchanged_pure_sources': unchanged, 'artifacts': artifacts,
             'bundle': {'path': str(BUNDLE.relative_to(REPO)),
                        'sha256': hashlib.sha256(bundle).hexdigest()},
             'limits': ['No new proof; complete harness/full-project proofs remain incomplete.',
                        'V1 passing tests did not establish safe cleanup; review failures retained.',
                        'Resource witnesses cover two target workloads, not worst-case memory or timing.',
                        'Single owner/no external reapers; no hostile-process or generic descendant guarantee.',
                        'No authenticated evidence, installed hooks, universal recall or certification.']}
    raw = (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()
    if sys.argv[1:] == ['--check']:
        if read(DEST) != raw or read(BUNDLE) != bundle:
            raise ValueError('retained evidence mismatch')
    else:
        BUNDLE.write_bytes(bundle) if not BUNDLE.exists() else sys.exit('bundle exists')
        with DEST.open('xb') as stream:
            stream.write(raw)
    print('I/O diagnostics retained and exact source bindings checked')


if __name__ == '__main__':
    main()

"""Fixed harmless post-exec leader and one child; no timer or EOF exit."""
import array
import json
import os
from pathlib import Path
import signal
import socket


def observation(role):
    with Path('/proc/self/status').open('rb') as stream:
        raw = stream.read(8193)
    if len(raw) > 8192:
        raise ValueError('proc status bound')
    fields = dict(line.split(':', 1) for line in raw.decode().splitlines() if ':' in line)
    return dict(role=role, phase='POST_EXEC_SENTINEL', uid=list(os.getresuid()), gid=list(os.getresgid()),
                groups=os.getgroups(), proc_uid=[int(x) for x in fields['Uid'].split()],
                proc_gid=[int(x) for x in fields['Gid'].split()],
                namespaces={key: os.readlink('/proc/self/ns/' + key) for key in ('pid', 'user', 'net')},
                caps={key: fields[key].strip() for key in
                      ('CapInh', 'CapPrm', 'CapEff', 'CapBnd', 'CapAmb', 'NoNewPrivs')})


def announce(connection, role):
    descriptor = os.pidfd_open(os.getpid())
    try:
        raw = json.dumps(observation(role)).encode()
        if len(raw) > 8192:
            raise ValueError('entry record bound')
        count = connection.sendmsg([raw], [(socket.SOL_SOCKET, socket.SCM_RIGHTS,
                                           array.array('i', [descriptor]))])
        if count != len(raw):
            raise ValueError('short entry announcement')
    finally:
        os.close(descriptor)


def connect(role):
    connection = socket.socket(socket.AF_UNIX, socket.SOCK_SEQPACKET)
    try:
        # Only the initial announcement is bounded; it must complete before the cut.
        connection.settimeout(5)
        connection.connect('/tmp/out/post.sock')
        announce(connection, role)
        connection.settimeout(None)
        return connection
    except (OSError, ValueError):
        connection.close()
        raise


def hold():
    # Intended nontermination of this fixed fixture. No socket reads, deadlines,
    # voluntary exit, or external work. The observed kernel intervention ends it.
    while True:
        signal.pause()


def main():
    with connect('leader') as connection:
        pid = os.fork()
        if pid == 0:
            connection.close()
            with connect('descendant'):
                hold()
        else:
            hold()


if __name__ == '__main__':
    main()

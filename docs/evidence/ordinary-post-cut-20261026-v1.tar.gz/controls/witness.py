"""One actual post-admission observer cut, with independent entry announcements."""
from contextlib import ExitStack
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import signal
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
ROLES = {'observer', 'launcher', 'init', 'leader', 'descendant'}


def bootstrap():
    source = ROOT / 'execution-source.json'
    if len(sys.argv) != 2 or hashlib.sha256(source.read_bytes()).hexdigest() != sys.argv[1]:
        raise ValueError('fixed post-admission manifest required')
    manifest = json.loads(source.read_text())
    if not {'witness.py', 'witness_base.py', 'post_protocol.py', 'observer_driver.py',
            'payload_sentinel.py', 'proof_wrapper.py'} <= set(manifest):
        raise ValueError('bootstrap files missing')
    for name, expected in manifest.items():
        if hashlib.sha256((ROOT / name).read_bytes()).hexdigest() != expected:
            raise ValueError('source changed before import: ' + name)
    return manifest


def load(name):
    if name not in ('witness_base', 'post_protocol'):
        raise ValueError('fixed observer module required')
    spec = importlib.util.spec_from_file_location(name, ROOT / (name + '.py'))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def acquire(base, protocol, wrapper, helper, config, binding, child, stack, handles, server, result):
    base.wait_stopped(child)
    active = json.loads((ROOT / 'active.json').read_text())
    result['lineage'] = base.acquire_chain(helper, child, stack, handles, active, config)
    result['post_exec'] = protocol.acquire(base, helper, config, server, stack, handles, result['lineage'])
    if set(handles) != ROLES:
        raise ValueError('incomplete tracked post-admission lineage')
    result['payload_entered'] = True
    result['pending_binding'] = base.pending_binding(wrapper, helper, config, binding)
    result['pending_before'] = result['pending_binding']['sha256']
    result['active_sha256'] = wrapper.sha(ROOT / 'active.json')


def intervene(base, wrapper, helper, child, handles, result):
    result['intervention'] = helper.signal_owned(handles['observer'])
    result['observer_wait'] = child.wait(timeout=5)
    result['before_cleanup'] = helper.wait_terminal(handles, 5)
    result['pending_after'] = wrapper.sha(wrapper.LEDGER / 'pending.json')
    base.save(wrapper, 'witness-before-cleanup.json', result)
    if result['observer_wait'] != -signal.SIGKILL or result['intervention'] != 'SIGKILL_SENT' \
            or result['pending_before'] != result['pending_after'] \
            or not all(row['terminal'] and row['reaped'] for row in result['before_cleanup'].values()):
        raise ValueError('post-admission cut failed before cleanup')
    result['status'] = 'TESTED_INSTRUMENTED_POST_ADMISSION_CUT'


def run_cut(base, protocol, wrapper, helper, config, binding, stack, result):
    server = protocol.server_for(ROOT / 'out', stack)
    stdout = stack.enter_context((ROOT / 'observer.stdout').open('xb'))
    stderr = stack.enter_context((ROOT / 'observer.stderr').open('xb'))
    command = ['/usr/bin/python3', '-I', '-B', str(ROOT / 'observer_driver.py'), sys.argv[1]]
    child = subprocess.Popen(command, stdout=stdout, stderr=stderr)
    handles = {}
    try:
        result['creation'] = dict(pid=child.pid, command=command, disposition='DIRECT_CHILD_CREATED')
        descriptor = helper.owned_pidfd(child)
        stack.callback(os.close, descriptor)
        handles['observer'] = descriptor
        acquire(base, protocol, wrapper, helper, config, binding, child, stack, handles, server, result)
        intervene(base, wrapper, helper, child, handles, result)
    finally:
        result['acquired_roles'] = sorted(handles)
        result['unacquired_roles_unknown'] = sorted(ROLES - set(handles))
        result['cleanup'] = helper.cleanup(child, handles)
        result['cleanup_was_after_observation'] = 'before_cleanup' in result
        if result['unacquired_roles_unknown'] or result['cleanup'].get('signals') \
                or result['cleanup'].get('errors') or not result['cleanup'].get('complete'):
            result['status'] = 'FAILED_OR_UNKNOWN'


def main():
    manifest = bootstrap()
    base, protocol = load('witness_base'), load('post_protocol')
    wrapper = base.load_wrapper()
    config = json.loads((ROOT / 'config.json').read_text())
    helper = wrapper.helpers(config)
    base.preflight(wrapper, config, helper, manifest)
    binding = json.loads((ROOT / 'source-binding.json').read_text())
    result = dict(status='FAILED_OR_UNKNOWN', authority='NONE', manifest=sys.argv[1],
                  cut='AFTER_PROVE_SEND_AND_INDEPENDENT_POST_EXEC_ENTRIES', instrumented=True,
                  payload_entered=False, replay_authorized=False, successor_admitted=False)
    base.save(wrapper, 'witness-entry.json', result)
    with ExitStack() as stack:
        try:
            run_cut(base, protocol, wrapper, helper, config, binding, stack, result)
            wrapper.verify_inputs(config, binding)
            wrapper.verify_manifest(manifest)
            helper.validate_tools(config)
            result['post_source_and_tools_verified'] = True
        except (OSError, ValueError, RuntimeError, subprocess.TimeoutExpired) as error:
            result['status'] = 'FAILED_OR_UNKNOWN'
            result['error'] = wrapper.receipt_error('post-admission-cut', error)
    base.save(wrapper, 'witness-result.json', result)
    print(json.dumps(result), flush=True)
    if result['status'] != 'TESTED_INSTRUMENTED_POST_ADMISSION_CUT':
        raise SystemExit(1)


if __name__ == '__main__':
    main()

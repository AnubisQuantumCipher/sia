"""Nonlaunching failure/attribution controls plus local self-pidfd transport."""
import array
from contextlib import ExitStack
import io
import json
import os
from pathlib import Path
import signal
import socket
import tempfile
import unittest
from unittest import mock

import observer_driver
import payload_sentinel
import post_protocol
import witness


def record(role):
    return dict(role=role, phase='POST_EXEC_SENTINEL', uid=[1000] * 3, gid=[1000] * 3,
                groups=[1000], proc_uid=[1000] * 4, proc_gid=[1000] * 4,
                namespaces=dict(pid='pid:[2]', user='user:[1]', net='net:[2]'),
                caps=dict(CapInh='0', CapPrm='0', CapEff='0', CapBnd='0', CapAmb='0', NoNewPrivs='1'))


class DriverControls(unittest.TestCase):
    def test_only_wait_seam_changes_and_continuation_refuses(self):
        module = mock.Mock()
        original_save, original_execute = module.save, module.execute
        observer_driver.install_cut(module)
        with mock.patch.object(observer_driver.os, 'kill') as stop:
            with self.assertRaisesRegex(RuntimeError, 'must never resume'):
                module.wait_with_capacity(object(), 0)
        stop.assert_called_once_with(os.getpid(), signal.SIGSTOP)
        self.assertIs(module.save, original_save)
        self.assertIs(module.execute, original_execute)


class EntrySchema(unittest.TestCase):
    def test_valid_closed_records(self):
        for role in ('leader', 'descendant'):
            post_protocol.validate_record(record(role))

    def test_nonobjects_and_missing_extra_fields_refuse(self):
        for value in (None, [], 'leader', 1, {}, dict(record('leader'), extra=True)):
            with self.subTest(value=value), self.assertRaises(ValueError):
                post_protocol.validate_record(value)

    def test_roles_phase_vectors_and_nested_maps_refuse(self):
        for field, value in (('role', []), ('role', 'observer'), ('phase', 'BEFORE_EXEC'),
                             ('uid', [True]), ('gid', []), ('groups', [0] * 33),
                             ('proc_uid', '1000'), ('proc_gid', [-1]), ('caps', []),
                             ('caps', {}), ('namespaces', dict(pid='x', net='y', user=7)),
                             ('namespaces', dict(pid='x' * 129, net='y', user='z'))):
            candidate = record('leader')
            candidate[field] = value
            with self.subTest(field=field, value=value), self.assertRaises(ValueError):
                post_protocol.validate_record(candidate)


class EntryBinding(unittest.TestCase):
    def setUp(self):
        self.base, self.helper = mock.Mock(), mock.Mock()
        self.lineage = dict(pids=dict(observer=10, launcher=20, init=30, leader=40),
                            observations={role: self.observation(pid) for role, pid in
                                          dict(observer=10, launcher=20, init=30, leader=40).items()})
        self.handles = dict(observer=110, launcher=120, init=130, leader=140)
        self.records = {}
        self.helper.validate_payload.side_effect = lambda _cfg, _peer, value, _fd, _parent: \
            40 if value['role'] == 'leader' else 50
        self.helper.events.return_value = 0
        self.helper.descriptor_pid.side_effect = {110: 10, 120: 20, 130: 30, 140: 40, 150: 50}.__getitem__
        self.base.process_observation.side_effect = lambda _helper, pid: self.observation(pid)

    @staticmethod
    def observation(pid):
        return dict(pid=pid, start_ticks=pid, namespaces=record('leader')['namespaces'])

    def message(self, role):
        pid = 40 if role == 'leader' else 50
        return object(), (pid, 1000, 1000), record(role), [140 if role == 'leader' else 150]

    def adopt(self, message):
        with mock.patch.object(post_protocol, 'verify_executable'):
            post_protocol.adopt(self.base, self.helper, {}, message, self.handles, self.lineage, self.records)

    def test_both_roles_bind_to_expected_parents(self):
        for role in ('leader', 'descendant'):
            self.adopt(self.message(role))
        self.assertEqual(set(self.records), {'leader', 'descendant'})
        self.assertEqual(self.handles['descendant'], 150)
        self.assertEqual([call.args[-1] for call in self.helper.validate_payload.call_args_list], [30, 40])

    def test_duplicate_or_wrong_descriptor_count_refuses(self):
        self.adopt(self.message('leader'))
        with self.assertRaisesRegex(ValueError, 'exact post-exec record'):
            self.adopt(self.message('leader'))
        for descriptors in ([], [150, 151]):
            message = (*self.message('descendant')[:3], descriptors)
            with self.subTest(descriptors=descriptors), self.assertRaises(ValueError):
                self.adopt(message)

    def test_wrong_leader_or_aliased_descendant_refuses(self):
        for role, pid in (('leader', 99), ('descendant', 40)):
            self.helper.validate_payload.side_effect = None
            self.helper.validate_payload.return_value = pid
            with self.subTest(role=role), self.assertRaises(ValueError):
                self.adopt(self.message(role))
        self.assertEqual(self.records, {})

    def test_namespace_and_start_replacement_refuse(self):
        for key, value in (('namespaces', {}), ('start_ticks', 99)):
            observed = self.observation(40)
            observed[key] = value
            self.base.process_observation.side_effect = None
            self.base.process_observation.return_value = observed
            with self.subTest(key=key), self.assertRaises(ValueError):
                self.adopt(self.message('leader'))

    def test_early_terminal_or_wrong_pidfd_refuses_acquisition(self):
        for method, value in (('events', 17), ('descriptor_pid', 99)):
            self.setUp()
            getattr(self.helper, method).side_effect = None
            getattr(self.helper, method).return_value = value
            self.helper.receive.side_effect = [self.message('leader'), self.message('descendant')]
            with self.subTest(method=method), mock.patch.object(post_protocol, 'verify_executable'), \
                    self.assertRaisesRegex(ValueError, 'no longer live'):
                post_protocol.acquire(self.base, self.helper, {}, object(), object(), self.handles, self.lineage)

    def test_bad_command_and_interpreter_refuse(self):
        config = dict(tools={'/usr/bin/python3': 'expected'})
        for raw, digest in ((b'wrong\0', 'expected'),
                            (b'/usr/bin/python3\0-I\0-B\0/tmp/payload_sentinel.py\0', 'wrong')):
            self.helper.digest.return_value = digest
            with self.subTest(raw=raw, digest=digest), \
                    mock.patch.object(post_protocol.Path, 'open', return_value=io.BytesIO(raw)), \
                    self.assertRaisesRegex(ValueError, 'command or interpreter'):
                post_protocol.verify_executable(self.helper, config, 40)


class ObservationBeforeCleanup(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        self.root = Path(temporary.name)
        self.base, self.protocol, self.wrapper, self.helper = (mock.Mock() for _ in range(4))
        self.wrapper.LEDGER = self.root / 'ledger'
        self.wrapper.sha.return_value = 'fixed'
        self.child = mock.Mock(pid=123)
        self.child.wait.return_value = -signal.SIGKILL
        self.helper.owned_pidfd.return_value = 99
        self.trace = []
        self.helper.signal_owned.side_effect = self.signal
        self.helper.wait_terminal.side_effect = self.observe
        self.helper.cleanup.side_effect = self.cleanup
        self.base.save.side_effect = lambda *_args: self.trace.append('save-before-cleanup')
        self.terminal = True
        self.cleanup_signals = {}
        self.acquisition_error = None

    def signal(self, _descriptor):
        self.trace.append('kill-observer')
        return 'SIGKILL_SENT'

    def observe(self, handles, _seconds):
        self.trace.append('observe')
        return {role: dict(mask=17 if self.terminal else 0, terminal=self.terminal, reaped=self.terminal)
                for role in handles}

    def cleanup(self, _child, _handles):
        self.trace.append('cleanup')
        return dict(complete=True, errors=[], signals=self.cleanup_signals)

    def acquired(self, _base, _protocol, _wrapper, _helper, _config, _binding, _child,
                 _stack, handles, _server, result):
        self.trace.append('entry-records')
        if self.acquisition_error:
            raise self.acquisition_error
        handles.update(launcher=100, init=101, leader=102, descendant=103)
        result.update(payload_entered=True, pending_before='fixed')

    def exercise(self, result):
        with mock.patch.object(witness, 'ROOT', self.root), \
                mock.patch.object(witness.sys, 'argv', ['witness.py', 'fixed']), \
                mock.patch.object(witness.subprocess, 'Popen', return_value=self.child), \
                mock.patch.object(witness.os, 'close'), \
                mock.patch.object(witness, 'acquire', side_effect=self.acquired), ExitStack() as stack:
            witness.run_cut(self.base, self.protocol, self.wrapper, self.helper, {}, {}, stack, result)

    def test_entries_and_observation_precede_cleanup(self):
        result = dict(status='FAILED_OR_UNKNOWN')
        self.exercise(result)
        self.assertEqual(self.trace, ['entry-records', 'kill-observer', 'observe', 'save-before-cleanup', 'cleanup'])
        self.assertEqual(result['status'], 'TESTED_INSTRUMENTED_POST_ADMISSION_CUT')
        self.assertEqual(result['acquired_roles'], sorted(witness.ROLES))

    def test_successful_cleanup_cannot_rescue_early_nontermination(self):
        self.terminal = False
        result = dict(status='FAILED_OR_UNKNOWN')
        with self.assertRaisesRegex(ValueError, 'failed before cleanup'):
            self.exercise(result)
        self.assertEqual(result['status'], 'FAILED_OR_UNKNOWN')
        self.assertTrue(result['cleanup']['complete'])
        self.assertTrue(result['cleanup_was_after_observation'])

    def test_cleanup_signal_invalidates_otherwise_passing_result(self):
        self.cleanup_signals = {'descendant': 'SIGKILL_SENT'}
        result = dict(status='FAILED_OR_UNKNOWN')
        self.exercise(result)
        self.assertEqual(result['status'], 'FAILED_OR_UNKNOWN')

    def test_readiness_timeout_cleans_without_intervention_or_pass(self):
        self.acquisition_error = TimeoutError('entry deadline')
        result = dict(status='FAILED_OR_UNKNOWN')
        with self.assertRaises(TimeoutError):
            self.exercise(result)
        self.assertEqual(self.trace, ['entry-records', 'cleanup'])
        self.assertFalse(result['cleanup_was_after_observation'])
        self.assertEqual(result['unacquired_roles_unknown'], sorted(witness.ROLES - {'observer'}))

    def test_initial_handle_failure_retains_creation_and_unknown_roles(self):
        self.helper.owned_pidfd.side_effect = RuntimeError('fallback recorded')
        result = dict(status='FAILED_OR_UNKNOWN')
        with self.assertRaisesRegex(RuntimeError, 'fallback recorded'):
            self.exercise(result)
        self.assertEqual(self.trace, ['cleanup'])
        self.assertEqual(result['creation']['pid'], 123)
        self.assertEqual(result['unacquired_roles_unknown'], sorted(witness.ROLES))


class SentinelControls(unittest.TestCase):
    def test_real_self_pidfd_and_entry_record_transfer(self):
        left, right = socket.socketpair(socket.AF_UNIX, socket.SOCK_SEQPACKET)
        with left, right:
            payload_sentinel.announce(left, 'leader')
            raw, ancillary, flags, _ = right.recvmsg(8192, socket.CMSG_SPACE(array.array('i').itemsize),
                                                    socket.MSG_CMSG_CLOEXEC)
            descriptors = array.array('i')
            for level, kind, data in ancillary:
                self.assertEqual((level, kind), (socket.SOL_SOCKET, socket.SCM_RIGHTS))
                descriptors.frombytes(data)
            try:
                self.assertEqual(flags & (socket.MSG_TRUNC | socket.MSG_CTRUNC), 0)
                self.assertEqual(len(descriptors), 1)
                self.assertEqual(json.loads(raw)['phase'], 'POST_EXEC_SENTINEL')
                info = Path('/proc/self/fdinfo', str(descriptors[0])).read_text()
                self.assertIn('Pid:\t' + str(os.getpid()) + '\n', info)
            finally:
                for descriptor in descriptors:
                    os.close(descriptor)

    def test_short_announcement_closes_self_handle(self):
        connection = mock.Mock()
        connection.sendmsg.return_value = 0
        with mock.patch.object(payload_sentinel.os, 'pidfd_open', return_value=99), \
                mock.patch.object(payload_sentinel.os, 'close') as close:
            with self.assertRaisesRegex(ValueError, 'short entry'):
                payload_sentinel.announce(connection, 'leader')
        close.assert_called_once_with(99)

    def test_connection_clears_announcement_timeout_before_hold(self):
        connection = mock.MagicMock()
        with mock.patch.object(payload_sentinel.socket, 'socket', return_value=connection), \
                mock.patch.object(payload_sentinel, 'announce'):
            self.assertIs(payload_sentinel.connect('leader'), connection)
        self.assertEqual(connection.settimeout.call_args_list, [mock.call(5), mock.call(None)])

    def test_fork_failure_does_not_enter_hold(self):
        with mock.patch.object(payload_sentinel, 'connect', return_value=mock.MagicMock()), \
                mock.patch.object(payload_sentinel.os, 'fork', side_effect=OSError('fork refused')), \
                mock.patch.object(payload_sentinel, 'hold') as hold:
            with self.assertRaises(OSError):
                payload_sentinel.main()
        hold.assert_not_called()


if __name__ == '__main__':
    unittest.main(verbosity=2)

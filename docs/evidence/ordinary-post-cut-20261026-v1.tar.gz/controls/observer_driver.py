"""Stop the actual observer only after its original admission send completed."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import signal

ROOT = Path(__file__).resolve().parent


def install_cut(module):
    def stop_after_dispatch(_child, _reserve):
        os.kill(os.getpid(), signal.SIGSTOP)
        raise RuntimeError('post-admission cut must never resume')
    module.wait_with_capacity = stop_after_dispatch


def main():
    manifest = json.loads((ROOT / 'execution-source.json').read_text())
    for name in ('observer_driver.py', 'proof_wrapper.py'):
        if hashlib.sha256((ROOT / name).read_bytes()).hexdigest() != manifest[name]:
            raise ValueError('instrumented source changed')
    spec = importlib.util.spec_from_file_location('cut_wrapper', ROOT / 'proof_wrapper.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    install_cut(module)
    module.main()


if __name__ == '__main__':
    main()

"""Fixed two-record post-exec admission observation; never grant workload authority."""
import os
from pathlib import Path
import socket

FIELDS = {'role', 'phase', 'uid', 'gid', 'groups', 'proc_uid', 'proc_gid', 'namespaces', 'caps'}


def server_for(out, stack):
    descriptor = os.open(out, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC)
    stack.callback(os.close, descriptor)
    server = stack.enter_context(socket.socket(socket.AF_UNIX, socket.SOCK_SEQPACKET))
    server.bind('/proc/self/fd/' + str(descriptor) + '/post.sock')
    os.chown(out / 'post.sock', 1000, 1000, follow_symlinks=False)
    os.chmod(out / 'post.sock', 0o600)
    server.listen(2)
    server.settimeout(5)
    return server


def verify_executable(helper, config, pid):
    with Path('/proc', str(pid), 'cmdline').open('rb') as stream:
        command = stream.read(4097)
    expected = ['/usr/bin/python3', '-I', '-B', '/tmp/payload_sentinel.py']
    if command != b'\0'.join(os.fsencode(part) for part in expected) + b'\0' \
            or helper.digest(Path('/proc', str(pid), 'exe')) != config['tools']['/usr/bin/python3']:
        raise ValueError('post-exec command or interpreter mismatch')


def validate_record(value):
    if type(value) is not dict or set(value) != FIELDS:
        raise ValueError('exact post-exec record required')
    if type(value['role']) is not str or value['role'] not in ('leader', 'descendant') \
            or value['phase'] != 'POST_EXEC_SENTINEL':
        raise ValueError('post-exec role or phase')
    for key in ('uid', 'gid', 'groups', 'proc_uid', 'proc_gid'):
        vector = value[key]
        if type(vector) is not list or not 1 <= len(vector) <= 32 \
                or any(type(number) is not int or number < 0 for number in vector):
            raise ValueError('post-exec credential vector')
    for key, fields in (('namespaces', {'pid', 'user', 'net'}),
                        ('caps', {'CapInh', 'CapPrm', 'CapEff', 'CapBnd', 'CapAmb', 'NoNewPrivs'})):
        mapping = value[key]
        if type(mapping) is not dict or set(mapping) != fields \
                or any(type(item) is not str or len(item) > 128 for item in mapping.values()):
            raise ValueError('post-exec bounded mapping')


def adopt(base, helper, config, message, handles, lineage, records):
    _connection, peer, value, descriptors = message
    validate_record(value)
    role = value['role']
    if role in records or len(descriptors) != 1:
        raise ValueError('exact post-exec record required')
    parent = lineage['pids']['init' if role == 'leader' else 'leader']
    pid = helper.validate_payload(config, peer, value, descriptors[0], parent)
    if role == 'leader' and pid != lineage['pids']['leader']:
        raise ValueError('post-exec leader identity changed')
    if role == 'descendant' and pid in lineage['pids'].values():
        raise ValueError('descendant aliases existing role')
    verify_executable(helper, config, pid)
    observed = base.process_observation(helper, pid)
    if observed['namespaces'] != lineage['observations']['leader']['namespaces']:
        raise ValueError('post-exec namespace changed')
    if role == 'leader' and observed['start_ticks'] != lineage['observations']['leader']['start_ticks']:
        raise ValueError('post-exec leader start identity changed')
    if role == 'descendant':
        handles[role] = descriptors[0]
        lineage['pids'][role] = pid
        lineage['observations'][role] = observed
    records[role] = dict(peer=peer, value=value, observation=observed)


def acquire(base, helper, config, server, stack, handles, lineage):
    records = {}
    for _ in range(2):
        adopt(base, helper, config, helper.receive(server, stack), handles, lineage, records)
    if set(records) != {'leader', 'descendant'} or set(handles) != set(lineage['pids']):
        raise ValueError('post-exec lineage incomplete')
    for role, descriptor in handles.items():
        pid = lineage['pids'][role]
        if helper.events(descriptor) or helper.descriptor_pid(descriptor) != pid \
                or base.process_observation(helper, pid)['start_ticks'] != lineage['observations'][role]['start_ticks']:
            raise ValueError('post-exec lineage no longer live')
    return records

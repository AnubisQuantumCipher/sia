# Fixed post-admission observer cut

Status: prepared; execution requires the recorded final source review and fresh admission below. This is a disposable, instrumented custody fixture under the operator's standing authorization to complete necessary work. It grants no installation, service, firewall, provider, replay, or release authority.

## Exact scope

Execution manifest: `e7d616e7b9e3e590d25b35cf3d3e985fcfcee5af3de3057f8f2eb83f532e986a`, covering the 26 files in `execution-source.json`. `source-binding.json` separately binds the 478-file snapshot and canonical inputs. The publication carrier is `28fb59d441db57e1277e490058f55b724d628892`; the carried baseline source is older and remains explicitly identified in the binding. No claim is made that this fixture tests every file in the current carrier.

The existing wrapper retains its actual admission send and durable active-record path. Only its capacity-wait seam is replaced by a permanent SIGSTOP. The independently executed sentinel announces its own process descriptor, forks one child, and the child independently announces its descriptor. Both then wait indefinitely without EOF or timer exits. The witness validates credentials, parentage, interpreter, command, namespaces, process start identities and five live descriptors before killing only the observer. A surviving witness is an explicit assumption.

The fixed host is the currently designated tryomarchy VM, identified by config machine hash `b8063cf4e7dc0667bfcf5598e196623e07c2672452356d5be5af2696d2930093` and boot hash `245fcf877525e2b26663b47120443e2a3c4e2c932f5b0449a107fce23089cb53`. Its observed hostname is `83`; host naming does not override these bindings. Exact installed executable and helper hashes are in `config.json`. Python, bubblewrap, setpriv, sudo, prlimit and the existing helpers are used; no tool installation or proof workload is included.

## Admission and command

Before execution, verify the 27-test raw result and exact tested source, final actual GPT-6.1 review, manifest, snapshot, helpers, tools, machine/boot identity, free space and empty disposable output directories. The fixed root witness additionally checks the five predecessor ledger records under the existing heavy lock before creation. The wrapper checks its root ledger identity and epoch and acquires the same lock for execution. A mismatch refuses; it does not update expectations.

Run once:

```
/usr/bin/python3 -I -B /home/sicarii/Work/sia-assurance-evidence-20261019/ownership-transfer-20261024/ordinary-post-cut-20261026-v1/invoke.py e7d616e7b9e3e590d25b35cf3d3e985fcfcee5af3de3057f8f2eb83f532e986a
```

The invoker runs only the pinned witness through `sudo /usr/bin/prlimit --core=0:0 -- /usr/bin/python3 -I -B .../witness.py <manifest>`. Any credential is entered only through the masked terminal. Root establishes namespaces and observes/cleans up; the payload is UID/GID1000 with its recorded groups, no capabilities and no-new-privileges. Its network namespace is private. The six writable disposable directories are `obj`, `bin`, `home`, `tmp`, `cache`, and `out` beneath this case. Source and tool mounts are read-only.

There is one heavy job and one fixed leader/child pair. Engineering time and storage caps remain removed; the unchanged physical reserve is 10000000000 bytes and cores are disabled. Five-second protocol/observation bounds classify this fixed fixture; they are not proof-job timeouts. The payload's intended nontermination ends only through the observed containment mechanism or explicit emergency cleanup, which cannot count as a passing cut.

## Required result and failure disposition

Require actual tool exit and invoker readback, independent leader and descendant entry, all five tracked roles terminal and reaped before cleanup, observer SIGKILL attribution, unchanged pending record, no cleanup signals/errors, and unchanged source/tool hashes. Preserve preliminary and final raw receipts. A nonzero exit, missing record, acquisition gap, cleanup intervention, source change or unexplained effect is FAILED/UNKNOWN. Do not rerun the cut or remove its pending record.

After a passing cut, prepare one fresh-output refusal with the unchanged wrapper; expected outcome is create-pending EEXIST17 before process creation. Require a separate privileged read of the same pending bytes. This is a negative control, not successor admission. Its relocated config and exact command receive a separate source binding before execution.

Rollback is containment of this exact disposable lineage through owned descriptors, preserving all evidence and the persistent pending marker. It does not restore or alter the installed product. No automatic reconciliation or clearing of the marker is authorized by success. Unexpected survivors require a specific retained disposition before further execution. Witness loss, hostile root, arbitrary descendants and pre-entry custody remain unqualified.

Existing source-specific SPARK proofs, original pre-admission cut/refusal and exact interrupted-fixture reconciliation remain historical evidence for their own sources and transitions. They do not cover this new post-exec seam. Fresh actual execution, refusal, independent result review and source-bound publication are required here. This check does not close native compaction continuity, R05, Astra judge qualification, complete assurance, installed acceptance or marketplace publication.

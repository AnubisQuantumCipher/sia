"""Prepare one fixed post-admission cut; no root or workload execution."""
import hashlib
import json
from pathlib import Path
import shutil

BASE = Path(__file__).resolve().parent
PREVIOUS = BASE / 'ordinary-observer-cut-20261026-v2'
SOURCE = BASE / 'ordinary-post-cut-source-20261026-v1'
DEST = BASE / 'ordinary-post-cut-20261026-v1'


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def create_files():
    if shutil.disk_usage(BASE).free < 10050000000:
        raise ValueError('physical reserve and fixed preparation space required')
    result = json.loads((SOURCE / 'TEST-RESULT.json').read_text())
    if result['status'] != 'PASS' or result['tests'] != 27 \
            or result['failures'] or result['errors'] or result['skipped']:
        raise ValueError('component controls required')
    for name, digest in result['source'].items():
        if sha(SOURCE / name) != digest:
            raise ValueError('component source changed')
    DEST.mkdir(mode=0o700)
    shutil.copytree(PREVIOUS / 'source', DEST / 'source')
    for name in ('obj', 'bin', 'home', 'tmp', 'cache', 'out'):
        (DEST / name).mkdir(mode=0o700)
    original = json.loads((PREVIOUS / 'execution-source.json').read_text())
    for name, digest in original.items():
        if sha(PREVIOUS / name) != digest:
            raise ValueError('predecessor execution source changed')
        if name not in ('config.json', 'observer_driver.py', 'witness.py', 'payload_sentinel.py', 'test_cut.py'):
            shutil.copy2(PREVIOUS / name, DEST / name)
    for name in result['source']:
        shutil.copy2(SOURCE / name, DEST / name)


def create_config():
    config = json.loads((PREVIOUS / 'config.json').read_text().replace(str(PREVIOUS), str(DEST)))
    config['candidate_phase'] = 'instrumented-actual-observer-death-after-post-exec-entry'
    config['cases'] = ['actual-observer-after-post-exec-entry']
    post = json.loads((BASE / 'ordinary-cut-reconciliation-20261026-v2/readback.stdout').read_text())
    if post['status'] != 'EXACT_INTERRUPTED_FIXTURE_READBACK' or not post['pending_absent'] \
            or post['directory'] != config['recovery_ledger']['identity'] or len(post['rows']) != 5:
        raise ValueError('fixed reconciled ledger required')
    config['cut'] = dict(lock_identity=[64768, 457925, 33188, 1000, 1000, 1],
                         ledger_files={name: row['sha256'] for name, row in post['rows'].items()},
                         predecessor='EXACT_INTERRUPTED_FIXTURE_RECONCILIATION_PASS',
                         authority='NONE', successor_admitted=False,
                         entry_socket='post.sock', entry_roles=['leader', 'descendant'],
                         observation_roles=['observer', 'launcher', 'init', 'leader', 'descendant'])
    with (DEST / 'config.json').open('x') as stream:
        json.dump(config, stream, indent=2, sort_keys=True)
        stream.write('\n')


def main():
    create_files()
    create_config()
    manifest = {path.name: sha(path) for path in sorted(DEST.iterdir()) if path.is_file()}
    with (DEST / 'execution-source.json').open('x') as stream:
        json.dump(manifest, stream, indent=2, sort_keys=True)
        stream.write('\n')
    print(json.dumps(dict(status='PREPARED_NOT_ADMITTED_OR_EXECUTED', path=str(DEST),
                          manifest_sha256=sha(DEST / 'execution-source.json'), files=len(manifest))))


if __name__ == '__main__':
    main()

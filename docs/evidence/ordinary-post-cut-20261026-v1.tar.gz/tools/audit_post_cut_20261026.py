"""Exact recorded post-admission cut only; no native continuity claim."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent / 'ordinary-post-cut-20261026-v1'
ROLES = {'observer', 'launcher', 'init', 'leader', 'descendant'}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(name):
    return json.loads((ROOT / name).read_text())


def check(condition, message):
    if not condition:
        raise ValueError(message)


def sources():
    for name, expected in read('execution-source.json').items():
        check(sha(ROOT / name) == expected, 'execution file changed: ' + name)
    binding = read('source-binding.json')
    for name, row in binding['files'].items():
        path = ROOT / 'source' / name
        check(sha(path) == row['sha256'] and path.stat().st_size == row['bytes'] and
              sha(Path(binding['canonical']) / name) == row['canonical_sha256'], 'source row changed')
    config = read('config.json')
    for roster in ('tools', 'proof_tools'):
        for name, expected in config[roster].items():
            check(sha(Path(name)) == expected, 'tool changed')
    for name, expected in config['helper_hashes'].items():
        check(sha(Path(config['helper_root']) / name) == expected, 'helper changed')
    return binding, config


def observations(result, before):
    check(before['status'] == 'FAILED_OR_UNKNOWN', 'before record must remain preliminary')
    for key in before:
        if key != 'status':
            check(before[key] == result[key], 'observation changed: ' + key)
    check(set(result['before_cleanup']) == ROLES, 'missing observed role')
    check(result['acquired_roles'] == sorted(ROLES) and not result['unacquired_roles_unknown'], 'partial handles')
    for row in result['before_cleanup'].values():
        check(row == dict(mask=17, terminal=True, reaped=True), 'pre-cleanup nontermination')
    cleanup = result['cleanup']
    check(cleanup['complete'] and not cleanup['signals'] and not cleanup['errors'] and
          cleanup['waited'] == -9 and cleanup['observations'] == result['before_cleanup'], 'cleanup mismatch')
    check(result['cleanup_was_after_observation'] and result['observer_wait'] == -9 and
          result['intervention'] == 'SIGKILL_SENT' and result['payload_entered'], 'cut outcome')


def lineage(result, config):
    observed, pids = result['lineage']['observations'], result['lineage']['pids']
    check(set(observed) == set(pids) == ROLES, 'identity roster')
    for role, row in observed.items():
        check(row['pid'] == pids[role] and int(row['stat'].rsplit(') ', 1)[1].split()[19]) ==
              row['start_ticks'], 'start identity mismatch')
    leader = observed['leader']
    for field, key in (('Uid', 'proc_uid'), ('Gid', 'proc_gid'), ('Groups', 'groups')):
        check([int(x) for x in leader['status'][field].split()] == config['expected'][key], 'credentials')
    for key in ('CapInh', 'CapPrm', 'CapEff', 'CapBnd', 'CapAmb'):
        check(int(leader['status'][key], 16) == 0, 'payload capabilities')
    check(leader['status']['NoNewPrivs'] == '1', 'payload new privileges')
    for child, parent in (('descendant', 'leader'), ('leader', 'init'), ('init', 'launcher'), ('launcher', 'observer')):
        check(int(observed[child]['status']['PPid']) == pids[parent], 'parent chain')
    check(observed['observer']['status']['State'] == 'T (stopped)', 'cut stop')
    check(observed['init']['namespaces'] == leader['namespaces'], 'init namespace')
    for key in ('pid', 'net'):
        check(leader['namespaces'][key] != config['expected']['namespaces'][key], 'isolation')


def post_entries(result, config):
    entries = result['post_exec']
    check(set(entries) == {'leader', 'descendant'}, 'post-exec entry roster')
    pids = result['lineage']['pids']
    check(len(set(pids.values())) == 5, 'aliased roles')
    for role, entry in entries.items():
        value, observed = entry['value'], entry['observation']
        check(entry['peer'] == [pids[role], 1000, 1000] and value['role'] == role and
              value['phase'] == 'POST_EXEC_SENTINEL', 'entry identity')
        for key in ('uid', 'gid', 'groups', 'proc_uid', 'proc_gid'):
            check(value[key] == config['expected'][key], 'entry credentials')
        check(value['caps']['NoNewPrivs'] == '1', 'entry new privileges')
        for key in ('CapInh', 'CapPrm', 'CapEff', 'CapBnd', 'CapAmb'):
            check(int(value['caps'][key], 16) == 0, 'entry capabilities')
        previous = result['lineage']['observations'][role]
        check(observed['pid'] == previous['pid'] and observed['start_ticks'] == previous['start_ticks']
              and observed['namespaces'] == previous['namespaces'] == value['namespaces'], 'entry binding')
        check(observed['namespaces'] == result['lineage']['observations']['leader']['namespaces'],
              'entry namespace')
    check(result['active_sha256'] == sha(ROOT / 'active.json'), 'active record binding')


def main():
    binding, config = sources()
    outer, result, before = read('outer-result.json'), read('witness-result.json'), read('witness-before-cleanup.json')
    check(outer['actual_exit'] == 0 and outer['manifest_sha256'] == sha(ROOT / 'execution-source.json') and
          outer['stdout_sha256'] == sha(ROOT / 'outer.stdout') and read('outer.stdout') == result and
          outer['wrapper_sha256'] == sha(ROOT / 'witness.py'), 'actual acknowledgment')
    check(result['status'] == 'TESTED_INSTRUMENTED_POST_ADMISSION_CUT' and
          result['post_source_and_tools_verified'] and not result['replay_authorized'] and
          not result['successor_admitted'], 'result scope')
    observations(result, before)
    post_entries(result, config)
    lineage(result, config)
    pending = result['pending_binding']['value']
    encoded = (json.dumps(pending, indent=2, sort_keys=True) + '\n').encode()
    check(hashlib.sha256(encoded).hexdigest() == result['pending_before'] == result['pending_after'] ==
          result['pending_binding']['sha256'], 'pending bytes changed')
    check(pending['bindings']['manifest'] == sha(ROOT / 'execution-source.json') and
          pending['bindings']['epoch'] == config['recovery_ledger']['epoch_sha256'] and
          pending['lock_identity'] == config['cut']['lock_identity'] and
          pending['source_head'] == binding['head'] and
          pending['output_path_sha256'] == hashlib.sha256(bytes(ROOT)).hexdigest(), 'pending binding')
    check(not (ROOT / 'out/payload-entered.json').exists() and not (ROOT / 'execution-result.json').exists(),
          'unexpected payload or observer final receipt')
    record = dict(status='ACTUAL_INSTRUMENTED_POST_ADMISSION_CUT_PASS', authority='NONE',
                  source_rows=len(binding['files']), manifest_sha256=sha(ROOT / 'execution-source.json'),
                  pending_sha256=result['pending_after'],
                  evidence_sha256={p.name: sha(p) for p in sorted(ROOT.iterdir()) if p.is_file()},
                  limits=['Tracked five-role post-admission fixed sentinel only; no arbitrary descendants or real proof workload',
                          'Instrumented driver and external witness; witness loss remains UNKNOWN',
                          'Unresolved intent remains; no automatic retirement, retry or successor authority',
                          'No native harness lifecycle, C14, whole-system or installed acceptance'])
    with (ROOT / 'OWNER-AUDIT.json').open('x') as stream:
        json.dump(record, stream, indent=2, sort_keys=True)
        stream.write('\n')
    print(json.dumps(dict(status=record['status'], manifest=record['manifest_sha256'],
                         pending=record['pending_sha256'])))


if __name__ == '__main__':
    main()

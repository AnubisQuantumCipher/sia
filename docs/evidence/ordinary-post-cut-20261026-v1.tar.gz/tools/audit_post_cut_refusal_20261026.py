"""Audit the one retained refusal; never execute or retire the pending operation."""
import hashlib
import json
from pathlib import Path

BASE = Path(__file__).resolve().parent
ROOT = BASE / 'ordinary-post-cut-refusal-20261026-v1'
CUT = BASE / 'ordinary-post-cut-20261026-v1'


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def read(path):
    return json.loads(path.read_text())


def check(condition, message):
    if not condition:
        raise ValueError(message)


def sources():
    manifest = read(ROOT / 'execution-source.json')
    check(len(manifest) == 26, 'execution roster changed')
    for name, expected in manifest.items():
        check(Path(name).name == name and sha(ROOT / name) == expected, 'execution bytes changed')
    binding = read(ROOT / 'source-binding.json')
    check(len(binding['files']) == 478, 'source roster changed')
    for name, row in binding['files'].items():
        path = ROOT / 'source' / name
        check(not Path(name).is_absolute() and '..' not in Path(name).parts, 'source path')
        check(sha(path) == row['sha256'] and path.stat().st_size == row['bytes'] and
              sha(Path(binding['canonical']) / name) == row['canonical_sha256'], 'source changed')
    config = read(ROOT / 'config.json')
    for roster in ('tools', 'proof_tools'):
        for name, expected in config[roster].items():
            check(sha(Path(name)) == expected, 'tool changed')
    for name, expected in config['helper_hashes'].items():
        check(sha(Path(config['helper_root']) / name) == expected, 'helper changed')
    return binding, manifest


def refusal():
    outer = read(ROOT / 'outer-result.json')
    note = read(ROOT / 'TOOL-EXIT-OBSERVATION.json')
    check(outer['actual_exit'] == note['invocation']['exit_code'] == 1, 'actual exit')
    check(outer['manifest_sha256'] == sha(ROOT / 'execution-source.json') and
          outer['wrapper_sha256'] == sha(ROOT / 'proof_wrapper.py') and
          outer['stdout_sha256'] == sha(ROOT / 'outer.stdout') and
          (ROOT / 'outer.stdout').stat().st_size == 0, 'outer binding')
    expected = dict(status='UNCERTAIN_DO_NOT_RETRY', errors=[dict(stage='create-pending',
                    type='FileExistsError', errno=17, message="[Errno 17] File exists: 'pending.json'")])
    check(note['invocation']['exception_value'] == expected, 'wrong refusal stage')
    check(note['readback']['exit_code'] == 0 and
          note['status'] == 'UNSIGNED_MODEL_RECORDED_TOOL_OBSERVATION', 'readback or scope')
    check(read(ROOT / 'entry.json')['manifest'] == read(ROOT / 'execution-source.json'), 'entry source')
    for name in ('active.json', 'execution-result.json', 'proof.stdout', 'proof.stderr',
                 'witness-result.json', 'witness-before-cleanup.json', 'observer.stdout', 'observer.stderr'):
        check(not (ROOT / name).exists(), 'unexpected downstream artifact: ' + name)
    for name in ('obj', 'bin', 'home', 'tmp', 'cache', 'out'):
        check(not any((ROOT / name).iterdir()), 'unexpected payload output: ' + name)


def main():
    binding, manifest = sources()
    refusal()
    previous = read(CUT / 'witness-result.json')
    pending = ROOT / 'pending-after.json'
    check(sha(pending) == previous['pending_before'] == previous['pending_after'] and
          read(pending) == previous['pending_binding']['value'], 'pending changed')
    check(read(pending)['status'] == 'UNRESOLVED_DO_NOT_RETRY', 'uncertainty weakened')
    record = dict(status='ACTUAL_PENDING_REFUSAL_PASS', authority='NONE',
                  source_rows=len(binding['files']), execution_files=len(manifest),
                  manifest_sha256=sha(ROOT / 'execution-source.json'), pending_sha256=sha(pending),
                  cut_result_sha256=sha(CUT / 'witness-result.json'),
                  evidence_sha256={p.name: sha(p) for p in sorted(ROOT.iterdir()) if p.is_file()},
                  limits=['One existing unresolved record blocks one fresh-output invocation before execution.',
                          'Exact exception is an unsigned tool observation, not a platform-signed receipt.',
                          'No semantic replay guarantee, retirement, successor, C14 or installed acceptance.'])
    with (ROOT / 'OWNER-AUDIT.json').open('x') as stream:
        json.dump(record, stream, indent=2, sort_keys=True)
        stream.write('\n')
    print(json.dumps(dict(status=record['status'], manifest=record['manifest_sha256'],
                         pending=record['pending_sha256'])))


if __name__ == '__main__':
    main()

#!/usr/bin/env python3
"""Retain isolated continuity-policy development checks; not a release receipt."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import time

ROOT = Path("/home/sicarii/Work/sia-assurance-kernel-20261019")
EVIDENCE = Path("/home/sicarii/Work/sia-assurance-evidence-20261019")
CHANGED = (
    'spark/sia_assurance.gpr', 'spark/verify-policy.sh',
    'spark/src/sia_continuity_observation_wire.ads',
    'spark/src/sia_continuity_observation_wire.adb',
    'spark/tests/continuity_observation_wire_tests.adb',
)


def proof_tools():
    prior = json.loads((ROOT / 'docs/PROOF-WARNING-COMMITTED-EVIDENCE.json').read_text())
    names = prior['proof_tools_sha256']
    if len(names) != 10:
        raise ValueError('unexpected tool roster')
    values = {}
    for name in names:
        with Path(name).open('rb') as stream:
            values[name] = hashlib.file_digest(stream, 'sha256').hexdigest()
    return values



def snapshot(output):
    source = output / "source"
    source.mkdir()
    base = subprocess.check_output(
        ["git", "rev-parse", "HEAD"], cwd=ROOT, text=True, timeout=10).strip()
    subprocess.run(
        ["git", "archive", "-o", str(output / "base.tar"), base, "spark"],
        cwd=ROOT, check=True, timeout=30)
    subprocess.run(["tar", "-xf", str(output / "base.tar"), "-C", str(source)],
                   check=True, timeout=30)
    for name in CHANGED:
        shutil.copyfile(ROOT / name, source / name)
    return {"base": base, "cwd": str(source), "proof_tools_before": proof_tools(), "files": {
        name: hashlib.sha256((source / name).read_bytes()).hexdigest()
        for name in CHANGED}, "checks": []}


def check(output, receipt, name, duration, command):
    argv = ["timeout", "--kill-after=5s", duration, *command]
    is_proof = name.endswith("-proof")
    summary = Path(receipt["cwd"]) / "spark/obj/gnatprove/gnatprove.out"
    if is_proof:
        # The preceding proof was already copied into its retained evidence.
        # A later timeout must not relabel that summary as a fresh result.
        summary.unlink(missing_ok=True)
    started = time.monotonic()
    with (output / (name + ".log")).open("wb") as stream:
        result = subprocess.run(argv, cwd=receipt["cwd"],
                                stdout=stream, stderr=subprocess.STDOUT)
    if name.endswith("-proof"):
        products = {}
        for product in ("gnatprove.out", "sia_continuity_record_wire.spark",
                        "sia_continuity_observation_wire.spark",
                        "continuity_observation_wire_tests.spark"):
            raw = Path(receipt["cwd"]) / "spark/obj/gnatprove" / product
            if raw.is_file():
                saved = output / (name + "-" + product)
                shutil.copyfile(raw, saved)
                products[product] = hashlib.sha256(saved.read_bytes()).hexdigest()
        receipt.setdefault("proof_outputs", {})[name] = products
    receipt["checks"].append({"name": name, "command": argv,
                              "exit": result.returncode,
                              "fresh_proof_summary": summary.is_file() if is_proof else None,
                              "elapsed_seconds": time.monotonic() - started})
    (output / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(name, result.returncode, flush=True)
    return result.returncode == 0 and (not is_proof or summary.is_file())


def main():
    if len(sys.argv) != 2 or not sys.argv[1].startswith("continuity-observation-wire-development-v"):
        raise ValueError("expected new continuity development directory name")
    output = EVIDENCE / sys.argv[1]
    if output.parent != EVIDENCE:
        raise ValueError("invalid output name")
    output.mkdir()
    status = subprocess.run(
        ["python3", "/home/sicarii/.codex/skills/project-vault/scripts/storage_status.py"],
        capture_output=True, check=True, timeout=20)
    (output / "storage-preflight.json").write_bytes(status.stdout)
    storage = json.loads(status.stdout)
    if (storage["local_disk_bytes"]["free"] <
            storage["configured_local_reserve_bytes"] + 1_000_000_000):
        raise RuntimeError("insufficient measured capacity for bounded policy build")
    if str(EVIDENCE) not in storage["pins"]:
        raise RuntimeError("evidence parent is not pinned")
    receipt = snapshot(output)
    receipt["scope"] = "DIAGNOSTIC_ONLY: observation codecs and harness; not full project proof or acceptance"
    plan = [
        ("build", "120s", ["gprbuild", "-p", "-P", "spark/sia_assurance.gpr"]),
        ("policy-tests", "30s", ["spark/bin/policy_tests"]),
        ("transaction-tests", "30s", ["spark/bin/transaction_tests"]),
        ("request-wire-tests", "30s", ["spark/bin/request_wire_tests"]),
        ("request-admission-tests", "30s", ["spark/bin/request_admission_tests"]),
        ("grant-lifetime-tests", "30s", ["spark/bin/grant_lifetime_tests"]),
        ("retraction-tests", "30s", ["spark/bin/retraction_tests"]),
        ("consolidation-tests", "30s", ["spark/bin/consolidation_tests"]),
        ("continuity-tests", "30s", ["spark/bin/continuity_tests"]),
        ("continuity-transition-tests", "30s", ["spark/bin/continuity_transition_tests"]),
        ("continuity-record-wire-tests", "30s", ["spark/bin/continuity_record_wire_tests"]),
        ("continuity-observation-wire-tests", "30s", ["spark/bin/continuity_observation_wire_tests"]),
        ("core-proof", "120s", ["gnatprove", "-P", "spark/sia_assurance.gpr",
                          "-u", "sia_continuity_observation_wire.adb",
                          "--mode=all", "--assumptions", "--no-inlining",
                          "--memlimit=512", "--timeout=10"]),
        ("harness-proof", "120s", ["gnatprove", "-P", "spark/sia_assurance.gpr",
                          "-u", "continuity_observation_wire_tests.adb",
                          "--mode=all", "--assumptions", "--no-inlining",
                          "--memlimit=512", "--timeout=10"]),
    ]
    passed = True
    for name, duration, command in plan:
        if not check(output, receipt, name, duration, command):
            passed = False
            break
    receipt['proof_tools_after'] = proof_tools()
    receipt['tools_unchanged'] = (receipt['proof_tools_before'] == receipt['proof_tools_after'])
    (output / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    return 0 if passed and receipt['tools_unchanged'] else 1


if __name__ == "__main__":
    sys.exit(main())

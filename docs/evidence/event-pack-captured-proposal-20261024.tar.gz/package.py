"""Retain source-bound inactive proposal evidence, including failed candidates."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import sys
import tarfile


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def gather(evidence):
    names = ["package.py", "regression_case.py", "generation_negative_case.py",
             "final-source-pins.json", "preserved-contracts.json", "static-v6.json",
             "review-final.json"]
    for label in ("v1-tests", "v6-tests", "original-build", "original-runtime",
                  "negative-generation", "v2-build", "v3-build", "v4-build",
                  "v5-build", "v6-build"):
        names.extend(label + suffix for suffix in (".json", ".stdout", ".stderr"))
    for directory in ("candidate", "v1", "v6", "stage-v2", "stage-v3", "stage-v4",
                      "stage-v5", "stage-v6", "stage-runtime"):
        names.extend(str(p.relative_to(evidence)) for p in (evidence / directory).rglob("*")
                     if p.is_file() and p.suffix in (".ads", ".adb", ".gpr", ".adc", ".py", ".yml", ".md"))
    names.extend(("stage-v6/spark/pack-proposal-bin/pack_proposal_probe",
                  "stage-runtime/spark/pack-plan-bin/pack_plan_wire_tests"))
    if len(names) > 512 or len(names) != len(set(names)):
        raise ValueError("unexpected evidence inventory")
    files = {name: (evidence / name).read_bytes() for name in sorted(names)}
    if sum(map(len, files.values())) > 16777216:
        raise ValueError("evidence payload capacity")
    return files


def archive(files):
    output = io.BytesIO()
    with gzip.GzipFile(fileobj=output, mode="wb", filename="", mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode="w", format=tarfile.USTAR_FORMAT) as tar:
            for name, raw in files.items():
                item = tarfile.TarInfo(name)
                item.size, item.mode = len(raw), 0o644
                tar.addfile(item, io.BytesIO(raw))
    return output.getvalue()


def main():
    evidence, repo = Path(sys.argv[1]), Path(sys.argv[2])
    files = gather(evidence)
    pins = json.loads(files["final-source-pins.json"])
    for name, expected in pins.items():
        if digest((repo / name).read_bytes()) != expected:
            raise ValueError("repository source drift")
    tests = json.loads(files["v6-tests.json"])
    if tests["exit"] != 0 or tests["before"] != tests["after"]:
        raise ValueError("test source/result mismatch")
    raw = files["v6-tests.stderr"].decode()
    if "Ran 367 tests in 42.459s\n\nOK\n" not in raw or ") ... skipped" in raw:
        raise ValueError("complete test outcome mismatch")
    packed = archive(files)
    if packed != archive(files):
        raise ValueError("archive reproduction mismatch")
    summary = {"status": "TESTED_INACTIVE_NOT_SYSTEM_ACCEPTANCE",
               "base_commit": "2c8c387d40f72f393cd7e3c8e327f5dad2eefb1f",
               "source_sha256": pins, "tests": "367 PASS; native probe executed; no skips",
               "original_ada_runtime": "188 retirement and19508wire PASS",
               "native_probe_sha256": tests["binary_sha256"],
               "negative": "coherent generation substitution produces required oracle FAILURE",
               "failures_retained": "v2-v4 unused updated file state; v5 redundant imports",
               "proof": "No fresh GNATprove; production Ada source unchanged",
               "review": "actual GPT-6.1 read-only; no independent execution",
               "archive": {"path": "docs/evidence/event-pack-captured-proposal-20261024.tar.gz",
                           "sha256": digest(packed), "bytes": len(packed)},
               "members": {name: digest(raw) for name, raw in files.items()},
               "limits": "No authentication, protected producer/effects, production IPC, installed migration or release acceptance. All original gates and caps remain."}
    (repo / summary["archive"]["path"]).write_bytes(packed)
    path = repo / "docs/EVENT-PACK-CAPTURED-PROPOSAL-EVIDENCE-20261024.json"
    path.write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n")
    print(json.dumps({"archive": summary["archive"], "members": len(files),
                      "summary_sha256": digest(path.read_bytes())}))


if __name__ == "__main__":
    main()

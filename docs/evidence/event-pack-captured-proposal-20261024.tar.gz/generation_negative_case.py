"""Coherent producer hash mutation must fail the unchanged independent oracle."""
import unittest
from unittest import mock

from tests import test_event_pack_proposal as fixture

original = fixture.joined._original_generations


def substituted(*args, **kwargs):
    rows = original(*args, **kwargs)
    if not rows:
        raise ValueError("negative control needs a represented original")
    return tuple((present, bytes([digest[0] ^ 1]) + digest[1:])
                 for present, digest in rows)


suite = unittest.defaultTestLoader.loadTestsFromName(
    "tests.test_event_pack_proposal.CapturedProposal."
    "test_complete_nonuniform_source_and_frame_correspondence")
with mock.patch.object(fixture.joined, "_original_generations", substituted):
    result = unittest.TextTestRunner(verbosity=2).run(suite)
if result.testsRun != 1 or len(result.failures) != 1 or result.errors or result.skipped:
    raise SystemExit("wrong negative outcome")
if "self.assertEqual(frame, bytes(expected))" not in result.failures[0][1]:
    raise SystemExit("oracle failed at the wrong boundary")
print("EXPECTED_FAILURE: coherent generation substitution rejected by independent frame oracle")

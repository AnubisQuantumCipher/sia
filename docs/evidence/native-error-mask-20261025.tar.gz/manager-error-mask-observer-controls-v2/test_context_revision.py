"""Reject unauthorized contextual projection; no real input mutation or launch."""
import copy
import time
import unittest

import test_observer_controls as base


class ContextRevision(unittest.TestCase):
    def setUp(self):
        self.fixture = base.RevisionControls('test_complete_current_closure')
        self.fixture.setUp()
        self.previous, self.plan = self.fixture.previous_closure_fixture()
        self.memory = self.fixture.memory

    def check(self):
        return self.fixture.namespace['checked_current_closure'](
            self.fixture.revision, self.plan, self.fixture.history, self.previous)

    def test_valid_projection_leaves_literal_predecessor_unchanged(self):
        before = copy.deepcopy(self.previous)
        self.assertEqual(self.check(), self.fixture.revision['inputs'])
        self.assertEqual(self.previous, before)

    def test_wrong_predecessor_memory(self):
        self.fixture.revision['predecessor_memory']['sha256'] = '0' * 64
        with self.assertRaisesRegex(ValueError, 'authenticated predecessor contextual row'):
            self.check()

    def test_unauthenticated_predecessor_refused_by_loader(self):
        path = base.BASE / 'ownership-transfer-20261024/manager-send-lifetime-compiler-preparation-v1/CURRENT-INPUTS.json'
        with self.assertRaisesRegex(ValueError, 'fixture/source binding failed'):
            base.bounded_bytes(path, '0' * 64)

    def test_noncontext_change(self):
        name = next(name for name in self.fixture.history if name != self.memory)
        self.previous[name]['sha256'] = '0' * 64
        with self.assertRaisesRegex(ValueError, 'join disagreement'):
            self.check()

    def test_second_projected_path(self):
        self.plan['context_revision']['second_path'] = '/mock/source.c'
        with self.assertRaisesRegex(ValueError, 'exact contextual revision schema'):
            self.check()

    def test_changed_projected_path(self):
        self.plan['context_revision']['path'] = '/mock/source.c'
        with self.assertRaisesRegex(ValueError, 'only fixed context path projected'):
            self.check()

    def test_missing_memory_in_inner_plan(self):
        del self.plan['inputs'][self.memory]
        with self.assertRaisesRegex(ValueError, 'context input retained'):
            self.check()

    def test_stale_inner_plan_memory(self):
        self.plan['inputs'][self.memory] = copy.deepcopy(self.previous[self.memory])
        with self.assertRaisesRegex(ValueError, 'single current context'):
            self.check()

    def test_conflicting_current_row(self):
        self.plan['context_revision']['current']['sha256'] = '0' * 64
        with self.assertRaisesRegex(ValueError, 'single current context'):
            self.check()

    def test_same_count_substitution(self):
        self.plan['inputs']['/mock/context'] = self.plan['inputs'].pop(self.memory)
        with self.assertRaisesRegex(ValueError, 'context input retained'):
            self.check()

    def test_drift_between_snapshots(self):
        row = copy.deepcopy(self.fixture.revision['current_memory'])
        expected = {self.memory: copy.deepcopy(row)}
        namespace = self.fixture.namespace
        namespace['time'] = time
        namespace['row'] = lambda _name: row
        deadline = time.monotonic_ns() + 1000000000
        self.assertEqual(namespace['snapshot'](expected, deadline), expected)
        row['identity']['st_mtime_ns'] += 1
        with self.assertRaisesRegex(ValueError, 'input endpoint mismatch'):
            namespace['snapshot'](expected, deadline)

    def test_projection_does_not_remove_map_bound(self):
        for index in range(513):
            self.plan['inputs']['/mock/' + str(index)] = self.previous[self.memory]
        with self.assertRaisesRegex(ValueError, 'fixed construction map bound'):
            self.check()


if __name__ == '__main__':
    unittest.main(verbosity=2)

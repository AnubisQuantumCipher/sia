"""SOURCE ONLY: fixed single C4 IO frontend batch; root admission still required."""
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess
import sys
import time

BASE = Path('/home/sicarii/Work/sia-assurance-evidence-20261019')
PREP = BASE / 'ownership-transfer-20261024/manager-error-mask-compiler-preparation-v2'
FIELDS = ('st_dev', 'st_ino', 'st_mode', 'st_nlink', 'st_uid', 'st_gid',
          'st_size', 'st_mtime_ns', 'st_ctime_ns')
FILE_CAP = 536870912
JSON_CAP = 8388608
METADATA_CAP = 16777216
SNAPSHOT_KEYS = ('sdk_files', 'sdk_aliases', 'sdk_parents', 'sdk_absent',
                 'extra_absent', 'source', 'source_parents', 'lookup_rows',
                 'tools', 'private')


def identity(path):
    value = Path(path).lstat()
    return {field: getattr(value, field) for field in FIELDS}


def normal_pin(path, cap=FILE_CAP):
    path = Path(path)
    before = identity(path)
    resolved = path.resolve(strict=True)
    endpoint = identity(resolved)
    if not stat.S_ISREG(endpoint['st_mode']) or endpoint['st_size'] > cap:
        raise ValueError('regular bounded pin required: ' + str(path))
    digest = hashlib.sha256()
    count = 0
    with resolved.open('rb') as stream:
        for _ in range(8193):
            block = stream.read(65536)
            if not block:
                break
            count += len(block)
            if count > cap:
                raise ValueError('pin read cap: ' + str(path))
            digest.update(block)
        else:
            raise ValueError('pin read loop exhausted')
    if (before != identity(path) or endpoint != identity(resolved) or
            count != endpoint['st_size']):
        raise ValueError('pin changed while read: ' + str(path))
    return {'bytes': count, 'sha256': digest.hexdigest(), 'identity': before,
            'resolved': str(resolved)}


def document(path, expected=None):
    path = Path(path)
    before = normal_pin(path, JSON_CAP)
    if expected is not None and before != expected:
        raise ValueError('pinned preparation input changed: ' + str(path))
    raw = path.read_bytes()
    if len(raw) > JSON_CAP or hashlib.sha256(raw).hexdigest() != before['sha256']:
        raise ValueError('JSON input changed')
    result = json.loads(raw)
    if before != normal_pin(path, JSON_CAP):
        raise ValueError('JSON metadata changed')
    return result


def absent(names):
    if len(names) > 32768:
        raise ValueError('negative cohort bound')
    for name in names:
        try:
            Path(name).lstat()
        except FileNotFoundError:
            continue
        raise ValueError('negative lookup now exists: ' + name)
    return list(names)


def sdk_files(inventory):
    if len(inventory['files']) != 1524:
        raise ValueError('SDK cohort changed')
    observed = {}
    total = 0
    for name, expected in inventory['files'].items():
        row = normal_pin(name, 8388608)
        row['actual_identity'] = identity(row['resolved'])
        total += row['bytes']
        if total > FILE_CAP or row != expected:
            raise ValueError('SDK endpoint drift: ' + name)
        observed[name] = row
    return observed


def alias_rows(expected):
    if len(expected) > 32768:
        raise ValueError('alias cohort bound')
    observed = {}
    for name, row in expected.items():
        actual = {'identity': identity(name), 'link': os.readlink(name),
                  'resolved': str(Path(name).resolve(strict=True))}
        if actual != row:
            raise ValueError('SDK alias drift: ' + name)
        observed[name] = actual
    return observed


def parent_rows(expected):
    if len(expected) > 32768:
        raise ValueError('parent cohort bound')
    observed = {}
    for name, row in expected.items():
        actual = identity(name)
        if actual != row:
            raise ValueError('SDK parent drift: ' + name)
        observed[name] = actual
    return observed


def lookup_rows(expected):
    observed = {}
    for name, row in expected.items():
        actual = {'identity': identity(name)}
        if 'link' in row:
            actual['link'] = os.readlink(name)
            actual['resolved'] = str(Path(name).resolve(strict=True))
        if 'sha256' in row:
            actual['sha256'] = normal_pin(name)['sha256']
        if actual != row:
            raise ValueError('lookup parent/alias drift: ' + name)
        observed[name] = actual
    return observed


def candidate_source_rows(plan):
    source = Path(plan['candidate_source_dir'])
    manifest = document(plan['candidate_manifest'], plan['inputs'][plan['candidate_manifest']])
    names = ('commission.h', 'witness.h', 'witness_io.c')
    if sorted(manifest['files']) != list(names):
        raise ValueError('candidate fixed three-file roster')
    observed_names = []
    for item in source.iterdir():
        if len(observed_names) >= 3:
            raise ValueError('candidate source namespace bound')
        observed_names.append(item.name)
    if sorted(observed_names) != list(names):
        raise ValueError('candidate source namespace changed')
    observed = {}
    for name in names:
        actual = normal_pin(source / name, JSON_CAP)
        if (actual != manifest['files'][name] or actual['resolved'] != str(source / name)
                or not stat.S_ISREG(actual['identity']['st_mode'])):
            raise ValueError('candidate source drift/type/alias')
        if name != 'witness_io.c':
            original = normal_pin(Path(plan['source_dir']) / name, JSON_CAP)
            if (actual['bytes'], actual['sha256']) != (original['bytes'], original['sha256']):
                raise ValueError('candidate header bytes changed')
        observed[name] = actual
    return observed


def source_rows(plan):
    source = Path(plan['source_dir'])
    children = ('history-v4', 'diffs')
    if not stat.S_ISDIR(identity(source)['st_mode']):
        raise ValueError('C4 source root directory required')
    manifest = document(plan['source_manifest'], plan['inputs'][plan['source_manifest']])
    names = sorted([*manifest['files'], 'SOURCE-MANIFEST.json'])
    if len(manifest['files']) != 47 or len(names) > 64:
        raise ValueError('C4 fixed whole-source file bound')
    for name in names:
        parts = name.split('/')
        if (any(part in ('', '.', '..') for part in parts) or
                len(parts) not in (1, 2) or
                (len(parts) == 2 and parts[0] not in children)):
            raise ValueError('C4 finite relative source name refused')
    expected_root = sorted([name for name in names if '/' not in name] + list(children))
    actual_root = []
    for item in source.iterdir():
        if len(actual_root) >= 64:
            raise ValueError('C4 root namespace entry bound')
        actual_root.append(item.name)
    if sorted(actual_root) != expected_root:
        raise ValueError('C4 source root namespace changed')
    for child in children:
        directory = source / child
        if not stat.S_ISDIR(identity(directory)['st_mode']):
            raise ValueError('C4 source child directory required')
        expected_child = sorted(name.split('/')[1] for name in names
                                if name.startswith(child + '/'))
        actual_child = []
        for item in directory.iterdir():
            if len(actual_child) >= 64:
                raise ValueError('C4 child namespace entry bound')
            actual_child.append(item.name)
        if sorted(actual_child) != expected_child:
            raise ValueError('C4 source child namespace changed')
    observed = {}
    for name, row in manifest['files'].items():
        actual = normal_pin(source / name, JSON_CAP)
        for field in ('bytes', 'sha256', 'identity'):
            if actual[field] != row[field]:
                raise ValueError('C4 source drift: ' + name)
        if actual['resolved'] != str(source / name):
            raise ValueError('C4 source alias refused')
        observed[name] = actual
    observed['SOURCE-MANIFEST.json'] = normal_pin(source / 'SOURCE-MANIFEST.json')
    observed['candidate'] = candidate_source_rows(plan)
    return observed


def fresh_parents(plan):
    observed = {}
    for name in plan['fresh_source_parent_paths']:
        row = identity(name)
        if not stat.S_ISDIR(row['st_mode']) or row['st_mode'] & 0o022:
            raise ValueError('source parent is writable/incorrect: ' + name)
        if row['st_uid'] not in (0, os.getuid()):
            raise ValueError('source parent owner refused')
        observed[name] = row
    return observed


def private_rows(plan):
    observed = {}
    for name in ('HOME', 'TMPDIR'):
        path = Path(plan['environment'][name])
        row = identity(path)
        entries = sorted(item.name for item in path.iterdir())
        if not stat.S_ISDIR(row['st_mode']) or stat.S_IMODE(row['st_mode']) != 0o700:
            raise ValueError('private directory profile')
        if row['st_uid'] != os.getuid() or entries:
            raise ValueError('private directory reused/incorrect owner')
        observed[name] = {'identity': row, 'entries': entries}
    return observed


def snapshot(plan, inventory, old_admission, output):
    # Independent categories still run if an earlier one refuses. Python keeps
    # all raised exceptions in the genuine cause/context chain; none is green.
    try:
        output['sdk_files'] = sdk_files(inventory)
    finally:
        try:
            output['sdk_aliases'] = alias_rows(inventory['links'])
        finally:
            try:
                output['sdk_parents'] = parent_rows(inventory['parents'])
            finally:
                try:
                    output['sdk_absent'] = absent(inventory['absent'])
                    output['extra_absent'] = absent(plan['extra_absent'])
                finally:
                    try:
                        output['source'] = source_rows(plan)
                        output['source_parents'] = fresh_parents(plan)
                    finally:
                        try:
                            output['lookup_rows'] = lookup_rows(plan['static_lookup_rows'])
                        finally:
                            try:
                                output['tools'] = {name: normal_pin(name)
                                                  for name in old_admission['tools_before']}
                                if output['tools'] != old_admission['tools_before']:
                                    raise ValueError('tool pin drift')
                            finally:
                                output['private'] = private_rows(plan)


def save_metadata(run, name, data, budget):
    raw = (json.dumps(data, indent=2, sort_keys=True) + '\n').encode()
    if len(raw) > JSON_CAP or budget[0] + len(raw) > METADATA_CAP:
        raise ValueError('metadata total/individual cap')
    budget[0] += len(raw)
    with (run / name).open('xb') as stream:
        if stream.write(raw) != len(raw):
            raise OSError('short metadata write')


def capacity(run, plan):
    value = os.statvfs(run)
    free = value.f_bavail * value.f_frsize
    required = plan['storage']['required_free_bytes']
    if required != 15402263552 or free < required:
        raise ValueError('fresh capacity reservation refused')
    return {'available_bytes': free, 'required_bytes': required,
            'reserve_bytes': 10000000000, 'backup_health': 'NOT_ASSESSED',
            'iPad_access': 'NOT_PROBED', 'capacity_is_not_WCET_or_custody': True}


def artifact_rows(run, plan):
    observed = {}
    for name in plan['storage']['compiler_roster']:
        path = run / name
        try:
            path.lstat()
        except FileNotFoundError:
            observed[name] = {'exists': False}
            continue
        row = normal_pin(path)
        if not stat.S_ISREG(row['identity']['st_mode']) or row['resolved'] != str(path):
            raise ValueError('artifact alias/type refused')
        observed[name] = {'exists': True, **row}
    return observed


def dependencies(run, inventory, plan):
    path = run / 'witness_io.d'
    try:
        path.lstat()
    except FileNotFoundError:
        return {'status': 'MISSING_NONPASS'}
    if path.stat().st_size > JSON_CAP:
        raise ValueError('dependency file bound')
    words = path.read_bytes().replace(b'\\\n', b' ').decode('ascii').split()
    if not words or words[0] != str(run / 'witness_io.s') + ':':
        raise ValueError('closed fixed dependency target grammar')
    source = plan['candidate_source_dir']
    required = {source + '/' + name for name in ('witness_io.c', 'witness.h', 'commission.h')}
    allowed = set(inventory['files']) | required
    if len(words) > 32768 or not required.issubset(words[1:]):
        raise ValueError('dependency count/required-source refusal')
    if any(name not in allowed for name in words[1:]):
        raise ValueError('dependency outside admitted BEFORE cohort')
    return {'status': 'OBSERVED_FIXED_MD_CLOSURE_ONLY', 'paths': words[1:],
            'ceiling': 'Not complete reads/negative lookups/provider/custody proof.'}


def launch(run, plan, result):
    result['capacity_immediately_before_launch'] = capacity(run, plan)
    start = time.monotonic_ns()
    with (run / 'stdout').open('xb') as out, (run / 'stderr').open('xb') as err:
        done = subprocess.run(plan['command'], cwd=run, env=plan['environment'],
                              stdin=subprocess.DEVNULL, stdout=out, stderr=err, check=False)
    result['elapsed_ns'] = time.monotonic_ns() - start
    result['exit'] = done.returncode


def observations(result, before, after, artifacts):
    complete = set(before) == set(SNAPSHOT_KEYS) == set(after)
    result['all_before_after_equal'] = complete and before == after
    result['exception_active'] = sys.exception() is not None
    required = ('witness_io.s', 'witness_io.d', 'witness_io.c.analyzer.txt')
    result['required_outputs_present'] = all(
        artifacts.get(name, {}).get('exists') is True and
        artifacts[name].get('bytes', 0) > 0 for name in required)
    result['observed_within_target'] = 0 <= result.get('elapsed_ns', -1) <= 30 * 1000000000
    good = (result['all_before_after_equal'] and result.get('exit') == 0 and
            result['observed_within_target'] and result['required_outputs_present'] and
            not result['exception_active'])
    result['status'] = 'OBSERVED_FRONTEND_RESULT_ONLY_NO_ACCEPTANCE' if good else 'INCOMPLETE_NONPASS'
    result['artifacts'] = artifacts


def main():
    if len(sys.argv) != 1:
        raise ValueError('fixed controller takes no arguments')
    plan = document(PREP / 'PIN-PLAN.json')
    for name, pin in plan['inputs'].items():
        if normal_pin(name, JSON_CAP) != pin:
            raise ValueError('fixed preparation input drift: ' + name)
    inventory = document(plan['sdk_inventory'], plan['inputs'][plan['sdk_inventory']])
    old_admission = document(plan['original_admission'], plan['inputs'][plan['original_admission']])
    run = Path(plan['run_dir'])
    run.mkdir(mode=0o700)  # Exclusive creation refuses every reused stage.
    (run / 'home').mkdir(mode=0o700)
    (run / 'tmp').mkdir(mode=0o700)
    absent([str(run / name) for name in plan['output_names']])
    before, after, artifacts = {}, {}, {}
    result = {'status': 'INCOMPLETE_NONPASS', 'acceptance': False, 'authority': 'NONE',
              'loaded_provider_mappings': 'UNOBSERVED', 'command': plan['command'],
              'cwd': str(run), 'environment': plan['environment'],
              'analyzer_pass': 'UNASSESSED_REQUIRE_INDEPENDENT_FULL_DUMP'}
    budget = [0]
    try:
        snapshot(plan, inventory, old_admission, before)
        save_metadata(run, 'before.json', before, budget)
        launch(run, plan, result)
    finally:
        try:
            snapshot(plan, inventory, old_admission, after)
        finally:
            try:
                artifacts.update(artifact_rows(run, plan))
                result['dependencies'] = dependencies(run, inventory, plan)
            finally:
                observations(result, before, after, artifacts)
                try:
                    save_metadata(run, 'after.json', after, budget)
                finally:
                    if sys.exception() is not None:
                        result['exception_active'] = True
                        result['status'] = 'INCOMPLETE_NONPASS'
                    save_metadata(run, 'result.json', result, budget)
    if result['status'] != 'OBSERVED_FRONTEND_RESULT_ONLY_NO_ACCEPTANCE':
        raise ValueError('frontend failure or endpoint mismatch; no retry')


if __name__ == '__main__':
    main()

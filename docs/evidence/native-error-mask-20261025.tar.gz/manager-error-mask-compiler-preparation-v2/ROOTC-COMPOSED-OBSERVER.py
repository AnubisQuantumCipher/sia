"""Root host administrative observer: ONE original strict C IO frontend attempt only."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import resource
import signal
import stat
import subprocess
import time

B = Path('/home/sicarii/Work/sia-assurance-evidence-20261019')
N = B / 'takeover-linux-manager-witness-c5-clock-predicates-v6-first-static-preparation-v1'
CURRENT = B / 'ownership-transfer-20261024/manager-error-mask-compiler-preparation-v2'
EXT = CURRENT / 'C-root-external-v1'
F = ('st_dev', 'st_ino', 'st_mode', 'st_nlink', 'st_uid', 'st_gid', 'st_size', 'st_mtime_ns', 'st_ctime_ns')


def require(value, message):
    if not value:
        raise ValueError(message)


def identity(value):
    return {key: getattr(value, key) for key in F}


def row(name):
    path = Path(name)
    initial = path.lstat()
    endpoint = path.resolve(strict=True)
    allowed_alias = path == Path('/usr/bin/python3')
    if allowed_alias:
        require(stat.S_ISLNK(initial.st_mode) and initial.st_nlink == 1, 'fixed Python launch alias')
        require(endpoint == Path('/usr/bin/python3.14'), 'fixed Python resolved endpoint')
    else:
        require(stat.S_ISREG(initial.st_mode) and initial.st_nlink == 1 and endpoint == path, 'known regular endpoint')
    target = endpoint.lstat()
    require(stat.S_ISREG(target.st_mode) and target.st_nlink == 1, 'regular loaded endpoint')
    require(target.st_size <= 67108864, 'original static hash input cap')
    digest = hashlib.sha256()
    used = 0
    with endpoint.open('rb') as stream:
        first = os.fstat(stream.fileno())
        for _ in range(1024):
            block = stream.read(65536)
            if not block:
                break
            used += len(block)
            digest.update(block)
        else:
            require(stream.read(1) == b'', 'bounded complete file')
        last = os.fstat(stream.fileno())
    final = path.lstat()
    require(identity(initial) == identity(final), 'unstable original path')
    require(identity(target) == identity(first) == identity(last) == identity(endpoint.lstat()), 'unstable loaded endpoint')
    require(endpoint == path.resolve(strict=True) and used == target.st_size, 'changed resolved/size')
    return {'bytes': used, 'identity': identity(final), 'resolved': str(endpoint), 'sha256': digest.hexdigest()}


def load(path, expected):
    require(row(path)['sha256'] == expected, 'fixed governing SHA')
    with path.open('rb') as stream:
        raw = stream.read(1048577)
    require(len(raw) <= 1048576, 'original JSON bound')
    require(hashlib.sha256(raw).hexdigest() == expected, 'governing read hash')
    return json.loads(raw)


def merge(target, rows):
    require(type(rows) is dict and len(rows) <= 512, 'fixed construction map bound')
    for name, item in rows.items():
        require(set(item) == {'bytes', 'identity', 'resolved', 'sha256'}, 'row schema')
        require(set(item['identity']) == set(F), 'full9 schema')
        require(all(type(value) is int for value in item['identity'].values()), 'native integer metadata')
        require(name not in target or target[name] == item, 'join disagreement')
        target[name] = item
    require(len(target) <= 512, 'fixed total host map bound')


def snapshot(expected, deadline):
    result = {}
    for name, item in expected.items():
        require(time.monotonic_ns() < deadline, 'original120 shared work deadline')
        actual = row(name)
        require(actual == item, 'input endpoint mismatch: ' + name)
        result[name] = actual
    return result


def aliases():
    result = {}
    for name in ('/usr/bin/python3',):
        path = Path(name)
        first = path.lstat()
        resolved = str(path.resolve(strict=True))
        require(stat.S_ISLNK(first.st_mode), 'expected launch alias')
        target = os.readlink(path)
        require(identity(first) == identity(path.lstat()) and str(path.resolve(strict=True)) == resolved, 'alias changed')
        result[name] = {'identity': identity(first), 'resolved': resolved, 'target': target}
    return result


def pch_absent():
    sources = (B / 'takeover-linux-manager-image-witness-source-v6-clock-predicates-v1',
               B / 'ownership-transfer-20261024/manager-wait4-compiler-source-v1',
               B / 'ownership-transfer-20261024/manager-descriptor-flag-compiler-source-v1',
               B / 'ownership-transfer-20261024/manager-bounded-summary-compiler-source-v1',
               B / 'ownership-transfer-20261024/manager-loop-or-compiler-source-v1',
               B / 'ownership-transfer-20261024/manager-send-lifetime-source-v1/source',
               B / 'ownership-transfer-20261024/manager-error-mask-v1/source')
    result = {}
    for source in sources:
        for name in ('witness.h.gch', 'commission.h.gch'):
            path = source / name
            try:
                path.lstat()
            except FileNotFoundError:
                result[str(path)] = 'ENOENT'
            else:
                raise ValueError('unexpected source PCH entry: ' + str(path))
    return result


def save(name, value):
    raw = (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()
    require(len(raw) <= 2097152, 'original receipt bound')
    descriptor = os.open(EXT / name, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o444)
    with os.fdopen(descriptor, 'wb') as destination:
        require(destination.write(raw) == len(raw), 'short receipt write')
        destination.flush()
        os.fsync(destination.fileno())


def execute(command, environment, cwd, deadline):
    code = None
    error = None
    with (EXT / 'controller.stdout').open('xb') as out:
        with (EXT / 'controller.stderr').open('xb') as err:
            process = subprocess.Popen(command, cwd=cwd, env=environment, stdout=out, stderr=err, start_new_session=True)
            try:
                left = (deadline - time.monotonic_ns()) / 1000000000
                require(left > 0, 'overall deadline exhausted before child wait')
                code = process.wait(timeout=left)
            except (subprocess.TimeoutExpired, ValueError) as failure:
                error = {'class': type(failure).__name__, 'detail': str(failure)}
                try:
                    os.killpg(process.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                code = process.poll()
    return code, error


def prepare_inputs():
    prep = load(N / 'PREPARATION-MANIFEST.json', '726d76d41a41e1ba4b1a85063ad16ac433e5c4ca2e82e5cc8ec147b7a5e63d39')
    review_path = B / 'takeover-linux-manager-witness-c5-clock-predicates-v6-first-static-preparation-independent-source-review-v1-gpt61.json'
    review = load(review_path, '01f602a1fa83a0c60dd85b1b54d21a5e49a4e3591fd4e74fd738544aa95d239b')
    plan = load(N / 'STATIC-PLAN.json', '53188d31ed17744bae7ae67261b4a3cb94c0d31bf6a5c310f2e6726d06bcdae2')
    qualification_path = B / 'takeover-linux-manager-witness-c5-clock-predicates-v6-preparation-root-readback-v1.json'
    qualification = load(qualification_path, 'ffcd4b8121f87116100f1f6de194155141a9fd1f71ed0abaac422c682920caf2')
    outer = plan['outer_root_static_composition_required']
    source = load(Path(outer['full_review_input_map']), outer['full_review_sha256'])
    require(source['schema'] == 'sia.c5.clock-predicates.v6.root-exact-source-readback.v1', 'root source schema')
    require(outer['review_input_map'] == source['complete_current_input_map'] and len(source['complete_current_input_map']) == 195, 'full195 literal join')
    require(outer['original142_literal_subset'] == source['original142_literal_subset'] and len(outer['original142_literal_subset']) == 142, 'original142 literal join')
    require(all(source['complete_current_input_map'][key] == value for key, value in outer['original142_literal_subset'].items()), 'original142 full-map coverage')
    require(review['findings'] == [], 'preparation source blockers')
    require(len(outer['original83_literal_subset']) == 83, 'original83 retained')
    require(all(source['complete_current_input_map'][key] == value for key, value in outer['original83_literal_subset'].items()), 'original83 literal coverage')
    expected = {}
    merge(expected, review['input_map'])
    merge(expected, prep['input_map'])
    merge(expected, {str(N / key): value for key, value in prep['files'].items()})
    merge(expected, source['complete_current_input_map'])
    merge(expected, qualification['inputs'])
    for name in plan['prospective_input_paths']:
        merge(expected, {name: row(name)})
    for path in (N / 'PREPARATION-MANIFEST.json', review_path, Path(__file__).resolve(), qualification_path):
        merge(expected, {str(path): row(path)})
    policy = load(Path(plan['policy']), plan['policy_sha256'])
    require(row(Path(policy['ruff_command'][3]))['sha256'] == policy['ruff_executable_sha256'], 'Ruff tool pin')
    require(len(plan['prospective_input_paths']) == 30, 'declared internal30 roster')
    static_qualification_path = B / 'takeover-linux-manager-witness-c5-clock-predicates-v6-python-static-root-qualification-v1.json'
    qualified = load(static_qualification_path, '38f552c96e03a9fa8c4eb7db1be3e7155b1f74fc7022958e09d445cc1744a6c1')
    require(qualified['status'] == 'QUALIFIED_ORIGINAL167_AND_SYNTAX_ONLY', 'Pythonstatic qualification')
    raw_audit_path = B / 'takeover-linux-manager-witness-c5-clock-predicates-v6-python-static-independent-raw-audit-v1-gpt61.json'
    audited = load(raw_audit_path, '62782a517b6364ac70d79b7fd9a3babc213f5d5a22a648fa4ac6b9b6d452235f')
    require(audited['findings'] == [] and audited['status'] == 'TESTED_STATIC_ONLY_RAW_AUDIT_QUALIFIED', 'qualified actual static audit')
    merge(expected, audited['input_map'])
    merge(expected, qualified['inputs'])
    for path in (static_qualification_path, raw_audit_path):
        merge(expected, {str(path): row(path)})
    return expected, plan, source['complete_current_input_map'], outer['original142_literal_subset']


def current_revision(expected, revision, authenticated_history):
    require(revision['schema'] == 'sia.wait4.current-admission.v1', 'current admission schema')
    memory = '/home/sicarii/.codex/memories/MEMORY.md'
    require(revision['memory_path'] == memory, 'only reviewed contextual path')
    require(expected[memory] == revision['historical_memory'], 'historical contextual join')
    require(revision['historical_run_map'][memory] == expected[memory], 'historical355 context')
    require(revision['historical_memory_comparison'] == 'FAILED_RETAINED_NOT_REBASED', 'historical refusal retained')
    require(revision['current_memory'] == revision['inputs'][memory], 'current contextual join')
    require(revision['current_memory'] != revision['historical_memory'], 'explicit distinct revision')
    current = dict(expected)
    current[memory] = revision['current_memory']
    merge(current, revision['inputs'])
    historical = revision['historical_run_map']
    require(historical == authenticated_history, 'exact authenticated historical355 roster')
    require(type(historical) is dict and len(historical) == 355, 'original355 roster')
    for name, item in historical.items():
        required = revision['current_memory'] if name == memory else item
        require(name in current and current[name] == required, 'original355 scope and noncontext preservation')
    return current



def checked_current_closure(revision, plan, history, predecessor):
    required = dict(history)
    required[revision['memory_path']] = revision['current_memory']
    require(type(predecessor) is dict and len(predecessor) == 492,
            'exact previous current dependency roster')
    memory = '/home/sicarii/.codex/memories/MEMORY.md'
    context = plan['context_revision']
    require(type(context) is dict and set(context) == {'path', 'previous', 'current'},
            'exact contextual revision schema')
    require(context['path'] == memory, 'only fixed context path projected')
    require(memory in predecessor and memory in plan['inputs'], 'context input retained')
    require(revision['predecessor_memory'] == predecessor[memory] == context['previous'],
            'authenticated predecessor contextual row')
    require(context['current'] == revision['current_memory'] == plan['inputs'][memory],
            'single current context across inner and outer maps')
    require(context['current'] != context['previous'], 'explicit distinct contextual revision')
    projected = dict(predecessor)
    projected[memory] = context['current']
    merge(required, projected)
    merge(required, plan['inputs'])
    evidence = ('/home/sicarii/Work/sia-assurance-evidence-20261019/ownership-transfer-20261024/prepare_manager_error_mask_compiler_v2.py', '/home/sicarii/Work/sia-assurance-evidence-20261019/ownership-transfer-20261024/prepare_manager_error_mask_v1.py', '/home/sicarii/Work/sia-assurance-evidence-20261019/ownership-transfer-20261024/manager-error-mask-compiler-preparation-v2/controller.py', '/home/sicarii/Work/sia-assurance-evidence-20261019/ownership-transfer-20261024/manager-error-mask-compiler-preparation-v2/PIN-PLAN.json', '/home/sicarii/Work/sia-assurance-evidence-20261019/ownership-transfer-20261024/manager-send-lifetime-compiler-preparation-v1/CURRENT-INPUTS.json', '/home/sicarii/Work/sia-assurance-evidence-20261019/ownership-transfer-20261024/manager-send-lifetime-compiler-preparation-v1/ROOTC-COMPOSED-OBSERVER.py', '/home/sicarii/Work/sia-assurance-evidence-20261019/ownership-transfer-20261024/manager-send-lifetime-compiler-preparation-v1/C-root-external-v1/admission.json', '/home/sicarii/Work/sia-assurance-evidence-20261019/ownership-transfer-20261024/manager-error-mask-v1/witness_io.diff', '/home/sicarii/Work/sia-assurance-evidence-20261019/ownership-transfer-20261024/manager-error-mask-v1/algebra-and-review.json', '/home/sicarii/Work/sia-assurance-evidence-20261019/ownership-transfer-20261024/manager-error-mask-v1/errno-source-binding.json', '/home/sicarii/Work/sia-assurance-evidence-20261019/ownership-transfer-20261024/manager-error-mask-v1/branch-disposition.json', '/home/sicarii/Work/sia-assurance-evidence-20261019/ownership-transfer-20261024/manager-error-mask-v1/v2-context-revision.json', '/home/sicarii/Work/sia-assurance-evidence-20261019/ownership-transfer-20261024/manager-error-normalization-compiler-preparation-v1/CURRENT-INPUTS.json', '/home/sicarii/Work/sia-assurance-evidence-20261019/ownership-transfer-20261024/manager-error-normalization-compiler-preparation-v1/C-root-external-v1/result.json')
    for name in evidence:
        require(name in revision['inputs'], 'omitted operative evidence dependency')
        merge(required, {name: revision['inputs'][name]})
    require(required == revision['inputs'], 'exact bounded current dependency closure')
    return required


def main():
    resource.setrlimit(resource.RLIMIT_AS, (2147483648, 2147483648))
    resource.setrlimit(resource.RLIMIT_FSIZE, (536870912, 536870912))
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
    begin = time.monotonic_ns()
    work = begin + 120000000000
    overall = begin + 125000000000
    expected, static_plan, source_rows, original142 = prepare_inputs()
    revision = load(CURRENT / 'CURRENT-INPUTS.json', '4e05fc6022988aca67547bc8d95b39aeb502f9371df90ec3bcac3be5cb22608c')
    authenticated_history = load(N / 'C-root-external-v1/admission.json', '7645ec40f8a8aaa108faf9a9ed6a04ad480d33df50987bc02878e9d6b51b2e6b')['before']
    expected = current_revision(expected, revision, authenticated_history)
    merge(expected, {str(CURRENT / 'CURRENT-INPUTS.json'): row(CURRENT / 'CURRENT-INPUTS.json')})
    plan = load(CURRENT / 'PIN-PLAN.json', 'bcdf7f353d4976ebbc758dfe40bb97ad3812a968747a3ee8ec4b0527d034beab')
    previous = load(B / 'ownership-transfer-20261024/manager-send-lifetime-compiler-preparation-v1/CURRENT-INPUTS.json', '0bbaa9272075119d9e0b8c00bee0e9b405158e56a7c938e185f82e0c11bebd2b')
    checked_current_closure(revision, plan, authenticated_history, previous['inputs'])
    command = list(static_plan['outer_root_static_composition_required']['command'])
    require(command[-1] == str(N / 'static-wrapper.py'), 'exact prior outer command')
    command[-1] = str(CURRENT / 'controller.py')
    environment = {'HOME': str(EXT), 'LANG': 'C', 'LC_ALL': 'C', 'PATH': '/usr/bin:/bin',
                   'PYTHONDONTWRITEBYTECODE': '1', 'TMPDIR': str(EXT), 'TZ': 'UTC'}
    require(not Path(plan['run_dir']).exists(), 'fresh C run required')
    before = snapshot(expected, work)
    alias_before = aliases()
    pch_before = pch_absent()
    free = os.statvfs(CURRENT)
    available = free.f_bavail * free.f_frsize
    require(available >= plan['storage']['required_free_bytes'] == 15402263552, 'fresh original C capacity')
    save('admission.json', {'schema': 'sia.root.error-mask-current-admission.v1', 'historical355': revision['historical_run_map'], 'historical142': original142, 'historical195': source_rows, 'context_revision': {'old': revision['historical_memory'], 'current': revision['current_memory'], 'old_literal_comparison': 'FAILED_RETAINED_NOT_REBASED'}, 'acceptance': False, 'authority': 'ONE_ORIGINAL_STRICT_IO_FRONTEND_ATTEMPT_ONLY', 'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'before': before, 'current142_before': {key: before[key] for key in original142}, 'current195_before': {key: before[key] for key in source_rows}, 'alias_before': alias_before, 'PCH_before': pch_before, 'command': command, 'C_command': plan['command'], 'C_environment': plan['environment'], 'environment': environment, 'cwd': str(CURRENT), 'begin_ns': begin, 'work_deadline_ns': work, 'overall_deadline_ns': overall, 'free_bytes': available, 'required_bytes': 15402263552, 'owned_helpers': 'Root separately verifies all evidence/source-parent writers quiescent before invocation; root writes only under precreated CURRENT during this window.', 'scope': 'ONE original strict IO cc1 frontend only. Historical original maps and old refusal retained. Current endpoint map explicitly revises contextual MEMORY only and adds pinned candidate inputs. All noncontext original355, previous492 endpoints and explicit current dependencies retained; predecessor-only endpoints classified in authenticated historical evidence; controller SDK1524/6/89/4524, original and new PCH negatives, tool/parent/output/MD/resource checks remain required. Current-source static qualification and source-bound external admission are separate prerequisites. All3TUs and commission/noLTO remain mandatory. No automatic retry/native/SDKprobe/GNAT/install/Git.'})
    code, error = execute(command, environment, CURRENT, overall)
    after = {}
    alias_after = {}
    pch_after = {}
    try:
        after = snapshot(expected, work)
        alias_after = aliases()
        pch_after = pch_absent()
    except (OSError, ValueError) as failure:
        error = {'class': type(failure).__name__, 'detail': str(failure), 'phase': 'after'}
    elapsed = time.monotonic_ns() - begin
    equal = before == after and alias_before == alias_after and pch_before == pch_after
    passed = code == 0 and error is None and equal and elapsed < 120000000000
    save('result.json', {'schema': 'sia.root.error-mask-current-result.v1', 'historical355': revision['historical_run_map'], 'historical142': original142, 'historical195': source_rows, 'context_revision': {'old': revision['historical_memory'], 'current': revision['current_memory'], 'old_literal_comparison': 'FAILED_RETAINED_NOT_REBASED'}, 'acceptance': False, 'authority': 'NONE', 'status': 'OBSERVED_FRONTEND_CHILD_ONLY_PENDING_INDEPENDENT_FULL_RAW_AUDIT' if passed else 'NONPASS', 'exit': code, 'error': error, 'elapsed_ns': elapsed, 'within_original_work': elapsed < 120000000000, 'before': before, 'after': after, 'current142_before': {key: before[key] for key in original142}, 'current195_before': {key: before[key] for key in source_rows}, 'current142_after': {key: after[key] for key in original142 if key in after}, 'current195_after': {key: after[key] for key in source_rows if key in after}, 'alias_before': alias_before, 'alias_after': alias_after, 'PCH_before': pch_before, 'PCH_after': pch_after, 'pins_equal': equal, 'streams': {key: row(EXT / ('controller.' + key)) for key in ('stdout', 'stderr')}, 'remaining_ceilings': 'Wrapper child exit/endpoint observations only. No analyzer acceptance before full independent raw/MD/diagnostic/terminal audit; no source/native/SDK/proof/product acceptance. Timeout/kill/reap failure paths unexercised and cannot accept.'})
    print(json.dumps({'passed': passed, 'exit': code, 'error': error, 'elapsed_ns': elapsed, 'pins_equal': equal, 'all142': len(original142), 'all195': len(source_rows), 'all_current_inputs': len(before)}))
    return 0 if passed else 1


raise SystemExit(main())

/* SOURCE ONLY. Analyze helpers with unknown extern data, no LTO. */
#ifndef SIA_COMMISSION_V4_H
#define SIA_COMMISSION_V4_H
#include <stdint.h>
struct commission {
 uint32_t enabled, operator_uid, manager_pid;
 uint64_t manager_start, exe_dev, exe_ino, exe_size;
 int64_t exe_mtime_sec, exe_ctime_sec;
 uint32_t exe_mtime_nsec, exe_ctime_nsec;
 uint64_t pid_ns_dev, pid_ns_ino, cgroup_ns_dev, cgroup_ns_ino;
 uint64_t user_ns_dev, user_ns_ino;
 char generation[65], boot_id[37], user_unit_invocation[33];
 char original_bus_owner[256], manager_cgroup[128], exe_sha256[65];
};
extern const struct commission COMMISSION;
#endif

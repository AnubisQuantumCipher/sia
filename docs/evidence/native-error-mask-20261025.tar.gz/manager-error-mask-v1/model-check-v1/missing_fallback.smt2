; Manual 32-bit model, not a verified translation of C or compiled code.
; error spans every bit pattern; fallback spans positive signed int values.
(set-logic QF_BV)
(declare-const error (_ BitVec 32))
(declare-const fallback (_ BitVec 32))
(assert (bvsgt fallback #x00000000))
(define-fun nonzero () (_ BitVec 32)
  (bvlshr (bvor error (bvneg error)) #x0000001f))
(define-fun zero_mask () (_ BitVec 32)
  #x00000000)
(define-fun addend () (_ BitVec 32) (bvand zero_mask fallback))
(define-fun candidate () (_ BitVec 32) (bvadd error addend))
(define-fun original () (_ BitVec 32)
  (ite (= error #x00000000) fallback error))
; A counterexample is unequal output, an unrepresentable signed cast, or
; signed addition whose widened result differs from its signed 32-bit result.
(assert (or
  (not (= candidate original))
  (bvslt addend #x00000000)
  (not (= (bvadd ((_ sign_extend 32) error)
                 ((_ zero_extend 32) addend))
          ((_ sign_extend 32) candidate)))))
(check-sat)

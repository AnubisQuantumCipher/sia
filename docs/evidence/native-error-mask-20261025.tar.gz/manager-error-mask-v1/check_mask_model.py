"""Bounded diagnostic of a manual bit-vector model; no native acceptance."""
import hashlib
import json
import os
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'model-check-v1'
FIELDS = ('st_dev', 'st_ino', 'st_mode', 'st_nlink', 'st_uid', 'st_gid',
          'st_size', 'st_mtime_ns', 'st_ctime_ns')
TOOLS = ('/usr/bin/flock', '/usr/bin/prlimit', '/usr/bin/timeout', '/usr/bin/z3')
CASES = (
    ('original', None, None, 'unsat'),
    ('wrong_shift', '#x0000001f', '#x0000001e', 'sat'),
    ('missing_fallback', '(bvsub nonzero #x00000001)', '#x00000000', 'sat'),
    ('missing_range', '(assert (bvsgt fallback #x00000000))', '', 'sat'),
)


def pin(path):
    before = path.stat()
    if not path.is_file() or before.st_size > 67108864:
        raise ValueError('bounded regular input required')
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for _ in range(1024):
            block = stream.read(65536)
            if not block:
                break
            digest.update(block)
        else:
            if stream.read(1):
                raise ValueError('hash input bound exceeded')
    identity = {k: getattr(before, k) for k in FIELDS}
    if identity != {k: getattr(path.stat(), k) for k in FIELDS}:
        raise ValueError('input changed')
    return {'sha256': digest.hexdigest(), 'identity': identity,
            'resolved': str(path.resolve(strict=True))}


def save(path, raw):
    if len(raw) > 1048576:
        raise ValueError('receipt bound exceeded')
    with path.open('xb') as stream:
        if stream.write(raw) != len(raw):
            raise OSError('short write')
        stream.flush()
        os.fsync(stream.fileno())


def run_case(source, case):
    name, old, new, expected = case
    revised = source
    if old is not None:
        if source.count(old) != 1:
            raise ValueError('unique model mutation required')
        revised = source.replace(old, new, 1)
    path = OUT / (name + '.smt2')
    save(path, revised.encode())
    command = [TOOLS[0], '-F', '-n', '-E', '75',
               '/home/sicarii/.worldline-heavy.lock', TOOLS[1],
               '--as=536870912:536870912', '--fsize=1048576:1048576',
               '--core=0:0', '--', TOOLS[2], '--kill-after=1s', '5s',
               TOOLS[3], '-T:5', '-memory:128', str(path)]
    with (OUT / (name + '.stdout')).open('xb') as stdout:
        with (OUT / (name + '.stderr')).open('xb') as stderr:
            completed = subprocess.run(command, stdin=subprocess.DEVNULL,
                stdout=stdout, stderr=stderr, timeout=8, check=False,
                env={'PATH': '/usr/bin:/bin', 'LANG': 'C', 'LC_ALL': 'C'},
                cwd=OUT)
    observed = (OUT / (name + '.stdout')).read_bytes()
    errors = (OUT / (name + '.stderr')).read_bytes()
    return {'name': name, 'expected': expected, 'stdout': observed.decode(),
            'stderr': errors.decode(), 'exit': completed.returncode,
            'passed': completed.returncode == 0 and not errors
                      and observed == (expected + '\n').encode(),
            'command': command, 'source': pin(path)}


def main():
    source_path = ROOT / 'mask-model.smt2'
    inputs = [source_path, Path(__file__).resolve(),
              ROOT / 'source/witness_io.c', *(Path(p) for p in TOOLS)]
    before = {str(path): pin(path) for path in inputs}
    source = source_path.read_text()
    if len(source.encode()) > 8192:
        raise ValueError('model source bound exceeded')
    OUT.mkdir(mode=0o700)
    results = [run_case(source, case) for case in CASES]
    after = {str(path): pin(path) for path in inputs}
    passed = before == after and all(item['passed'] for item in results)
    report = {'status': 'MODEL_CHECKED' if passed else 'FAILED',
              'acceptance': False, 'before': before, 'after': after,
              'results': results, 'ceiling': 'Manual bit-vector model only; '
              'C translation, compiler, solver and runtime are not proved.'}
    save(OUT / 'result.json', (json.dumps(report, indent=2) + '\n').encode())
    print(json.dumps({'status': report['status'], 'pins_equal': before == after,
                      'cases': [(r['name'], r['passed']) for r in results]}))
    return 0 if passed else 1


if __name__ == '__main__':
    raise SystemExit(main())

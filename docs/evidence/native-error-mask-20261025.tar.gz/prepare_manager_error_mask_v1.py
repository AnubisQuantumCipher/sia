"""Prepare bounded source only; no compiler invocation or execution admission."""
import difflib
import hashlib
import json
import os
import stat
from pathlib import Path

BASE = Path('/home/sicarii/Work/sia-assurance-evidence-20261019')
TRANSFER = BASE / 'ownership-transfer-20261024'
PREVIOUS = TRANSFER / 'manager-send-lifetime-source-v1/source'
DEST = TRANSFER / 'manager-error-mask-v1'
FIELDS = ('st_dev', 'st_ino', 'st_mode', 'st_nlink', 'st_uid', 'st_gid',
          'st_size', 'st_mtime_ns', 'st_ctime_ns')
ROSTER = ('witness_io.c', 'witness.h', 'commission.h')
OLD = 'bool mw_fail(struct mw_state *s, enum mw_fault phase, int error)\n{\n    if (s->faults[phase]==0)\n        s->faults[phase]=error!=0 ? error : EIO;\n    return false;\n}'
NEW = 'bool mw_fail(struct mw_state *s, enum mw_fault phase, int error)\n{\n    _Static_assert(UINT_MAX==UINT32_MAX, "32-bit unsigned zero mask");\n    _Static_assert(EIO>0 && EIO<=INT_MAX, "positive int error fallback");\n    if (s->faults[phase]==0) {\n        const unsigned int bits=(unsigned int)error;\n        /* Nonzero bits or their unsigned negation have the high bit set. */\n        const unsigned int nonzero=(bits | (0U-bits)) >> 31;\n        const unsigned int zero_mask=nonzero-1U;\n        /* Add EIO only for zero; nonzero signed errors remain unchanged. */\n        s->faults[phase]=error+(int)(zero_mask & (unsigned int)EIO);\n    }\n    return false;\n}'


def read_pin(path):
    before = path.lstat()
    if not stat.S_ISREG(before.st_mode) or path.resolve(strict=True) != path:
        raise ValueError('regular unaliased source required')
    if before.st_size > 8388608:
        raise ValueError('source byte bound')
    with path.open('rb') as stream:
        opened = os.fstat(stream.fileno())
        raw = stream.read(8388609)
        finished = os.fstat(stream.fileno())
    initial = {key: getattr(before, key) for key in FIELDS}
    for observed in (opened, finished, path.lstat()):
        if initial != {key: getattr(observed, key) for key in FIELDS}:
            raise ValueError('source identity changed')
    if len(raw) != before.st_size:
        raise ValueError('source size changed')
    return raw, {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(),
                 'identity': initial, 'resolved': str(path)}


def save(path, raw):
    if len(raw) > 8388608:
        raise ValueError('output byte bound')
    with path.open('xb') as stream:
        if stream.write(raw) != len(raw):
            raise OSError('short preparation write')
        stream.flush()
        os.fchmod(stream.fileno(), 0o444)
        os.fsync(stream.fileno())


def encode(value):
    return (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()


def original_sources():
    raw, manifest_pin = read_pin(PREVIOUS / 'SOURCE-MANIFEST.json')
    if manifest_pin['sha256'] != 'f9b075a94c55c77bd8f3ca1fe82d46cda40de0901324bcf296cb4ca749f7bcdc':
        raise ValueError('original manifest mismatch')
    manifest = json.loads(raw)
    if len(manifest['files']) != 47:
        raise ValueError('original full source roster mismatch')
    for name, expected in manifest['files'].items():
        parts = name.split('/')
        if (len(parts) not in (1, 2) or any(p in ('', '.', '..') for p in parts)
                or (len(parts) == 2 and parts[0] not in ('history-v4', 'diffs'))):
            raise ValueError('source namespace mismatch')
        if read_pin(PREVIOUS / name)[1] != expected:
            raise ValueError('original full source pin mismatch')
    return manifest, manifest_pin


def main():
    original, manifest_pin = original_sources()
    DEST.mkdir(mode=0o700)
    source = DEST / 'source'
    source.mkdir(mode=0o700)
    changes = []
    for name in ROSTER:
        raw, before = read_pin(PREVIOUS / name)
        revised = raw
        if name == 'witness_io.c':
            if raw.count(OLD.encode()) != 1:
                raise ValueError('unique exact substitution required')
            revised = raw.replace(OLD.encode(), NEW.encode(), 1)
            if revised.count(NEW.encode()) != 1 or revised.replace(NEW.encode(), OLD.encode(), 1) != raw:
                raise ValueError('inverse reconstruction failed')
            changes = list(difflib.unified_diff(raw.decode().splitlines(True),
                           revised.decode().splitlines(True),
                           fromfile='previous/witness_io.c', tofile='candidate/witness_io.c'))
        save(source / name, revised)
        if read_pin(PREVIOUS / name)[1] != before:
            raise ValueError('predecessor drift during copy')
    if original_sources() != (original, manifest_pin):
        raise ValueError('predecessor full namespace drift')
    files = {name: read_pin(source / name)[1] for name in ROSTER}
    save(DEST / 'witness_io.diff', ''.join(changes).encode())
    save(DEST / 'SOURCE-MANIFEST.json', encode({
        'status': 'SOURCE_ONLY_UNCOMPILED_UNPROVEN_NOT_ADOPTED',
        'acceptance': False, 'compiler_execution_admitted': False,
        'files': files, 'original_manifest': manifest_pin,
        'original_source_directory': str(PREVIOUS),
        'all_original_47_source_pins_rechecked': True,
        'inverse_restores_original_translation_unit': True,
        'old': OLD, 'new': NEW,
        'unchanged_header_bytes': ['witness.h', 'commission.h'],
        'obligation': 'Retain old whole namespace checks plus this exact three-file namespace; no cap or flag change.'}))
    source.chmod(0o555)
    print(json.dumps({'status': 'SOURCE_ONLY_UNCOMPILED_UNPROVEN_NOT_ADOPTED',
                      'destination': str(DEST), 'files': files}))


if __name__ == '__main__':
    main()

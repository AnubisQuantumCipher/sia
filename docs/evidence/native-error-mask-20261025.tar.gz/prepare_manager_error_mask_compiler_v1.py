"""Prepare exact error-mask frontend packet; never launch a compiler."""
import difflib
import hashlib
import json
import os
import stat
from pathlib import Path

B = Path('/home/sicarii/Work/sia-assurance-evidence-20261019')
T = B / 'ownership-transfer-20261024'
OLD = T / 'manager-send-lifetime-compiler-preparation-v1'
DRAFT = T / 'manager-error-mask-v1'
DEST = T / 'manager-error-mask-compiler-preparation-v1'
FIELDS = ('st_dev', 'st_ino', 'st_mode', 'st_nlink', 'st_uid', 'st_gid',
          'st_size', 'st_mtime_ns', 'st_ctime_ns')


def read_pin(path):
    before = path.lstat()
    if not stat.S_ISREG(before.st_mode) or path.resolve(strict=True) != path:
        raise ValueError('regular unaliased preparation input required')
    if before.st_size > 8388608:
        raise ValueError('preparation input bound')
    with path.open('rb') as stream:
        opened = os.fstat(stream.fileno())
        raw = stream.read(8388609)
        finished = os.fstat(stream.fileno())
    identity = {key: getattr(before, key) for key in FIELDS}
    for item in (opened, finished, path.lstat()):
        if identity != {key: getattr(item, key) for key in FIELDS}:
            raise ValueError('preparation input changed')
    if len(raw) != before.st_size:
        raise ValueError('preparation size changed')
    return raw, {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(),
                 'identity': identity, 'resolved': str(path)}


def save(name, raw):
    if len(raw) > 1048576:
        raise ValueError('original preparation document bound')
    with (DEST / name).open('xb') as stream:
        if stream.write(raw) != len(raw):
            raise OSError('short preparation write')
        stream.flush()
        os.fchmod(stream.fileno(), 0o444)
        os.fsync(stream.fileno())


def encode(value):
    return (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()


def replaced(source, old, new):
    if source.count(old) != 1:
        raise ValueError('unique transformation frontier required: ' + old[:80])
    return source.replace(old, new, 1)


def merge(target, rows):
    if len(rows) > 512:
        raise ValueError('original map input bound')
    for name, item in rows.items():
        if name in target and target[name] != item:
            raise ValueError('input pin conflict')
        target[name] = item
    if len(target) > 512:
        raise ValueError('original total map bound')


CANDIDATE_CHECK = '''def candidate_source_rows(plan):
    source = Path(plan['candidate_source_dir'])
    manifest = document(plan['candidate_manifest'], plan['inputs'][plan['candidate_manifest']])
    names = ('commission.h', 'witness.h', 'witness_io.c')
    if sorted(manifest['files']) != list(names):
        raise ValueError('candidate fixed three-file roster')
    observed_names = []
    for item in source.iterdir():
        if len(observed_names) >= 3:
            raise ValueError('candidate source namespace bound')
        observed_names.append(item.name)
    if sorted(observed_names) != list(names):
        raise ValueError('candidate source namespace changed')
    observed = {}
    for name in names:
        actual = normal_pin(source / name, JSON_CAP)
        if (actual != manifest['files'][name] or actual['resolved'] != str(source / name)
                or not stat.S_ISREG(actual['identity']['st_mode'])):
            raise ValueError('candidate source drift/type/alias')
        if name != 'witness_io.c':
            original = normal_pin(Path(plan['source_dir']) / name, JSON_CAP)
            if (actual['bytes'], actual['sha256']) != (original['bytes'], original['sha256']):
                raise ValueError('candidate header bytes changed')
        observed[name] = actual
    return observed


'''


def controller():
    raw, _ = read_pin(OLD / 'controller.py')
    old = raw.decode()
    new = replaced(old, "PREP = BASE / 'ownership-transfer-20261024/" + OLD.name + "'",
                   "PREP = BASE / 'ownership-transfer-20261024/" + DEST.name + "'")
    new = replaced(new, 'def source_rows(plan):\n', CANDIDATE_CHECK + 'def source_rows(plan):\n')
    frontier = "    observed['SOURCE-MANIFEST.json'] = normal_pin(source / 'SOURCE-MANIFEST.json')\n"
    new = replaced(new, frontier, frontier + "    observed['candidate'] = candidate_source_rows(plan)\n")
    new = replaced(new, "    source = plan['source_dir']\n", "    source = plan['candidate_source_dir']\n")
    save('controller.py', new.encode())
    save('CONTROLLER.diff', ''.join(difflib.unified_diff(old.splitlines(True), new.splitlines(True),
         fromfile='previous/controller.py', tofile='candidate/controller.py')).encode())


def candidate_plan(previous):
    plan = json.loads(json.dumps(previous))
    source = DRAFT / 'source'
    old_translation = str(Path(previous['source_dir']) / 'witness_io.c')
    plan['command'] = [value.replace(str(OLD), str(DEST)) if value != old_translation
                       else str(source / 'witness_io.c') for value in previous['command']]
    plan['environment'] = {key: value.replace(str(OLD), str(DEST))
                           for key, value in previous['environment'].items()}
    plan['run_dir'] = str(DEST / 'run')
    plan['candidate_source_dir'] = str(source)
    plan['candidate_manifest'] = str(DRAFT / 'SOURCE-MANIFEST.json')
    plan['extra_absent'] += [str(source / name) for name in ('witness.h.gch', 'commission.h.gch')]
    plan['fresh_source_parent_paths'] += [str(DRAFT), str(source)]
    manifest = json.loads(read_pin(DRAFT / 'SOURCE-MANIFEST.json')[0])
    if set(manifest['files']) != {'witness_io.c', 'witness.h', 'commission.h'}:
        raise ValueError('candidate source roster mismatch')
    for name, expected in manifest['files'].items():
        actual = read_pin(source / name)[1]
        if actual != expected:
            raise ValueError('candidate source drift')
        merge(plan['inputs'], {str(source / name): actual})
    merge(plan['inputs'], {str(DRAFT / 'SOURCE-MANIFEST.json'): read_pin(DRAFT / 'SOURCE-MANIFEST.json')[1]})
    return plan


def evidence_paths():
    return (Path(__file__).resolve(), T / 'prepare_manager_error_mask_v1.py',
            DEST / 'controller.py', DEST / 'PIN-PLAN.json',
            OLD / 'CURRENT-INPUTS.json', OLD / 'ROOTC-COMPOSED-OBSERVER.py',
            OLD / 'C-root-external-v1/admission.json', DRAFT / 'witness_io.diff',
            DRAFT / 'algebra-and-review.json', DRAFT / 'errno-source-binding.json',
            DRAFT / 'branch-disposition.json',
            T / 'manager-error-normalization-compiler-preparation-v1/CURRENT-INPUTS.json',
            T / 'manager-error-normalization-compiler-preparation-v1/C-root-external-v1/result.json')


def closure(previous, plan):
    revision = json.loads(json.dumps(previous))
    merge(revision['inputs'], plan['inputs'])
    for path in evidence_paths():
        merge(revision['inputs'], {str(path): read_pin(path)[1]})
    save('CURRENT-INPUTS.json', encode(revision))
    return revision


def observer(plan_sha, revision_sha):
    raw, _ = read_pin(OLD / 'ROOTC-COMPOSED-OBSERVER.py')
    old = raw.decode()
    new = replaced(old, "CURRENT = B / 'ownership-transfer-20261024/" + OLD.name + "'",
                   "CURRENT = B / 'ownership-transfer-20261024/" + DEST.name + "'")
    new = replaced(new, '0bbaa9272075119d9e0b8c00bee0e9b405158e56a7c938e185f82e0c11bebd2b', revision_sha)
    new = replaced(new, '94bd4690c6e3f5154d5a409346f86195a30d5508d8fb5a4eadcf51c80a660ab5', plan_sha)
    new = replaced(new, 'len(predecessor) == 422', 'len(predecessor) == 492')
    start = new.index('    evidence = (', new.index('def checked_current_closure('))
    stop = new.index('    for name in evidence:', start)
    new = new[:start] + '    evidence = ' + repr(tuple(str(p) for p in evidence_paths())) + '\n' + new[stop:]
    previous = "    previous = load(B / 'ownership-transfer-20261024/manager-loop-or-compiler-preparation-v1/CURRENT-INPUTS.json', '55080ee42525f06282731cb80ac5ce4b3c126d6af2cf7e117ece328f3d0c750f')"
    replacement = "    previous = load(B / 'ownership-transfer-20261024/manager-send-lifetime-compiler-preparation-v1/CURRENT-INPUTS.json', '0bbaa9272075119d9e0b8c00bee0e9b405158e56a7c938e185f82e0c11bebd2b')"
    new = replaced(new, previous, replacement)
    frontier = "               B / 'ownership-transfer-20261024/manager-send-lifetime-source-v1/source')"
    new = replaced(new, frontier, frontier[:-1] + ",\n               B / 'ownership-transfer-20261024/manager-error-mask-v1/source')")
    new = new.replace('sia.root.send-lifetime-current-', 'sia.root.error-mask-current-')
    new = new.replace('previous422 endpoints', 'previous492 endpoints')
    save('ROOTC-COMPOSED-OBSERVER.py', new.encode())
    save('OUTER.diff', ''.join(difflib.unified_diff(old.splitlines(True), new.splitlines(True),
         fromfile='previous/observer.py', tofile='candidate/observer.py')).encode())


def main():
    raw, old_plan_pin = read_pin(OLD / 'PIN-PLAN.json')
    if old_plan_pin['sha256'] != '94bd4690c6e3f5154d5a409346f86195a30d5508d8fb5a4eadcf51c80a660ab5':
        raise ValueError('predecessor plan pin mismatch')
    previous_plan = json.loads(raw)
    raw, old_revision_pin = read_pin(OLD / 'CURRENT-INPUTS.json')
    if old_revision_pin['sha256'] != '0bbaa9272075119d9e0b8c00bee0e9b405158e56a7c938e185f82e0c11bebd2b':
        raise ValueError('predecessor closure pin mismatch')
    previous_revision = json.loads(raw)
    if len(previous_revision['inputs']) != 492:
        raise ValueError('predecessor closure size mismatch')
    DEST.mkdir(mode=0o700)
    controller()
    plan = candidate_plan(previous_plan)
    save('PIN-PLAN.json', encode(plan))
    revision = closure(previous_revision, plan)
    observer(read_pin(DEST / 'PIN-PLAN.json')[1]['sha256'],
             read_pin(DEST / 'CURRENT-INPUTS.json')[1]['sha256'])
    if any(revision['inputs'].get(name) != row for name, row in previous_revision['inputs'].items()):
        raise ValueError('predecessor full closure not preserved')
    print(json.dumps({'status': 'SOURCE_ONLY_UNQUALIFIED_NO_EXECUTION',
                      'current_closure_inputs': len(revision['inputs']),
                      'inner_plan_inputs': len(plan['inputs']),
                      'all_previous_492_pins_preserved': True,
                      'destination': str(DEST)}))


if __name__ == '__main__':
    main()

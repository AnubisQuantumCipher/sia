"""Observe current closure without invoking main, execute or compiler."""
import ast
import hashlib
import json
import time
from pathlib import Path

B = Path('/home/sicarii/Work/sia-assurance-evidence-20261019')
T = B / 'ownership-transfer-20261024'
P = T / 'manager-error-mask-compiler-preparation-v1'
OUT = T / 'manager-error-mask-observer-controls-v1'
ORIGINAL = B / 'takeover-linux-manager-witness-c5-clock-predicates-v6-first-static-preparation-v1'


def observer_definitions():
    path = P / 'ROOTC-COMPOSED-OBSERVER.py'
    raw = path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != 'f308e14571f04d5dbe70d17c14f3b99b77cb663aac8271067b602fc51a4902a3':
        raise ValueError('Reviewed observer changed')
    parsed = ast.parse(raw, filename=str(path))
    if ast.dump(parsed.body[-1]) != ast.dump(ast.parse('raise SystemExit(main())').body[0]):
        raise ValueError('Unexpected dispatch statement')
    parsed.body.pop()
    namespace = {'__file__': str(path), '__name__': 'readback_only'}
    exec(compile(parsed, str(path), 'exec', dont_inherit=True), namespace)
    return namespace


def save(name, value):
    raw = (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()
    if len(raw) > 2097152:
        raise ValueError('Original receipt bound')
    with (OUT / name).open('xb') as stream:
        if stream.write(raw) != len(raw):
            raise OSError('Short readback receipt')


def command_scope(ns, plan):
    original = ns['load'](ORIGINAL / 'PIN-PLAN.json',
                         '67144f044125ce7516ec206f66ecb5becb8198d2954cb8238579d90cca32f857')
    def rebind(value):
        return value.replace(str(ORIGINAL), str(P)).replace(original['source_dir'], plan['candidate_source_dir'])
    expected_command = [rebind(value) for value in original['command']]
    expected_environment = {key: rebind(value) for key, value in original['environment'].items()}
    checks = {'command_only_source_output_paths_changed': expected_command == plan['command'],
              'environment_only_output_paths_changed': expected_environment == plan['environment'],
              'storage_unchanged': original['storage'] == plan['storage'],
              'original_negatives_retained': set(original['extra_absent']).issubset(plan['extra_absent']),
              'original_parents_retained': set(original['fresh_source_parent_paths']).issubset(plan['fresh_source_parent_paths']),
              'output_names_unchanged': original['output_names'] == plan['output_names']}
    if not all(checks.values()):
        raise ValueError('Command scope drift')
    save('command-scope-readback.json', {'checks': checks, 'command': plan['command'],
                                       'environment': plan['environment'], 'acceptance': False})


def main():
    start = time.monotonic_ns()
    ns = observer_definitions()
    expected, _, source, original142 = ns['prepare_inputs']()
    revision = ns['load'](P / 'CURRENT-INPUTS.json',
                          'ea7b55519f8f368a6353570e74bfc2894bda12d7eaa7ee2128b002c012d47862')
    history = ns['load'](ORIGINAL / 'C-root-external-v1/admission.json',
                         '7645ec40f8a8aaa108faf9a9ed6a04ad480d33df50987bc02878e9d6b51b2e6b')['before']
    plan = ns['load'](P / 'PIN-PLAN.json',
                      '786770c02f8348952683804fa00033645f5ff0fac5e903ffd365c81c1075c7e4')
    previous = ns['load'](B / 'ownership-transfer-20261024/manager-send-lifetime-compiler-preparation-v1/CURRENT-INPUTS.json',
                          '0bbaa9272075119d9e0b8c00bee0e9b405158e56a7c938e185f82e0c11bebd2b')
    ns['checked_current_closure'](revision, plan, history, previous['inputs'])
    expected = ns['current_revision'](expected, revision, history)
    ns['merge'](expected, {str(P / 'CURRENT-INPUTS.json'): ns['row'](P / 'CURRENT-INPUTS.json')})
    before = ns['snapshot'](expected, start + 60000000000)
    alias_before, pch_before = ns['aliases'](), ns['pch_absent']()
    command_scope(ns, plan)
    after = ns['snapshot'](expected, start + 60000000000)
    alias_after, pch_after = ns['aliases'](), ns['pch_absent']()
    equal = before == after and alias_before == alias_after and pch_before == pch_after
    save('live-map-readback.json', {
        'status': 'TESTED_ENDPOINT_READBACK_ONLY', 'acceptance': False, 'equal': equal,
        'before': before, 'after': after, 'alias_before': alias_before, 'alias_after': alias_after,
        'pch_before': pch_before, 'pch_after': pch_after, 'original195_count': len(source),
        'original142_count': len(original142), 'historical355_count': len(history),
        'current_count': len(before), 'elapsed_ns': time.monotonic_ns() - start,
        'not_executed': ['observer main', 'execute', 'controller', 'compiler'],
        'ceiling': 'Read-only endpoint sampling; not native custody or exhaustive read capture.'})
    if not equal:
        raise ValueError('Endpoint drift')
    print(json.dumps({'equal': equal, 'current': len(before), 'original195': len(source),
                      'original142': len(original142), 'historical355': len(history)}))


if __name__ == '__main__':
    main()

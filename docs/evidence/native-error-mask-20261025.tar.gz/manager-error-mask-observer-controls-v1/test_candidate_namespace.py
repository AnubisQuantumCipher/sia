"""Source-bound candidate namespace controls, without observer/compiler launch."""
import ast
import copy
import hashlib
import json
import stat
import tempfile
import unittest
from pathlib import Path

ROOT = Path('/home/sicarii/Work/sia-assurance-evidence-20261019/ownership-transfer-20261024')
PREP = ROOT / 'manager-error-mask-compiler-preparation-v1'
FIELDS = ('st_dev', 'st_ino', 'st_mode', 'st_nlink', 'st_uid', 'st_gid',
          'st_size', 'st_mtime_ns', 'st_ctime_ns')


def source_functions():
    path = PREP / 'controller.py'
    raw = path.read_bytes()
    plan = json.loads((PREP / 'CURRENT-INPUTS.json').read_text())
    if hashlib.sha256(raw).hexdigest() != plan['inputs'][str(path)]['sha256']:
        raise ValueError('candidate controller binding')
    names = {'identity', 'normal_pin', 'document', 'candidate_source_rows', 'dependencies'}
    selected = [node for node in ast.parse(raw).body
                if isinstance(node, ast.FunctionDef) and node.name in names]
    if len(selected) != len(names):
        raise ValueError('extracted function roster')
    namespace = {'Path': Path, 'hashlib': hashlib, 'json': json, 'stat': stat,
                 'FIELDS': FIELDS, 'FILE_CAP': 536870912, 'JSON_CAP': 8388608}
    exec(compile(ast.Module(body=selected, type_ignores=[]), str(path), 'exec'), namespace)
    return namespace


class CandidateNamespace(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.source = self.root / 'source'
        self.original = self.root / 'original'
        self.source.mkdir()
        self.original.mkdir()
        self.ns = source_functions()
        for name in ('commission.h', 'witness.h', 'witness_io.c'):
            raw = ('fixture ' + name).encode()
            self.assertEqual((self.source / name).write_bytes(raw), len(raw))
            self.assertEqual((self.original / name).write_bytes(raw), len(raw))
        self.manifest = self.root / 'manifest.json'
        self.plan = {'candidate_source_dir': str(self.source),
                     'candidate_manifest': str(self.manifest),
                     'source_dir': str(self.original), 'inputs': {}}
        self.rebind()

    def rebind(self):
        files = {name: self.ns['normal_pin'](self.source / name)
                 for name in ('commission.h', 'witness.h', 'witness_io.c')}
        raw = json.dumps({'files': files}).encode()
        self.assertEqual(self.manifest.write_bytes(raw), len(raw))
        self.plan['inputs'][str(self.manifest)] = self.ns['normal_pin'](self.manifest)

    def observe(self):
        return self.ns['candidate_source_rows'](self.plan)

    def test_valid_three_files(self):
        self.assertEqual(set(self.observe()), {'commission.h', 'witness.h', 'witness_io.c'})

    def test_extra_file_refused(self):
        (self.source / 'extra').touch()
        with self.assertRaisesRegex(ValueError, 'namespace bound'):
            self.observe()

    def test_missing_header_refused(self):
        (self.source / 'witness.h').unlink()
        with self.assertRaisesRegex(ValueError, 'namespace changed'):
            self.observe()

    def test_same_count_wrong_name_refused(self):
        (self.source / 'witness.h').rename(self.source / 'wrong.h')
        with self.assertRaisesRegex(ValueError, 'namespace changed'):
            self.observe()

    def test_source_mutation_refused(self):
        self.assertEqual((self.source / 'witness_io.c').write_bytes(b'changed'), 7)
        with self.assertRaisesRegex(ValueError, 'source drift'):
            self.observe()

    def test_header_mutation_with_rebound_manifest_refused(self):
        self.assertEqual((self.source / 'witness.h').write_bytes(b'changed'), 7)
        self.rebind()
        with self.assertRaisesRegex(ValueError, 'header bytes changed'):
            self.observe()

    def test_header_alias_with_rebound_manifest_refused(self):
        (self.source / 'witness.h').unlink()
        (self.source / 'witness.h').symlink_to(self.original / 'witness.h')
        self.rebind()
        with self.assertRaisesRegex(ValueError, 'source drift/type/alias'):
            self.observe()

    def test_manifest_changed_after_pin_refused(self):
        raw = b'{}'
        self.assertEqual(self.manifest.write_bytes(raw), len(raw))
        with self.assertRaisesRegex(ValueError, 'pinned preparation input changed'):
            self.observe()

    def test_manifest_wrong_roster_refused(self):
        data = json.loads(self.manifest.read_bytes())
        data['files']['other.c'] = data['files'].pop('witness_io.c')
        raw = json.dumps(data).encode()
        self.assertEqual(self.manifest.write_bytes(raw), len(raw))
        self.plan['inputs'][str(self.manifest)] = self.ns['normal_pin'](self.manifest)
        with self.assertRaisesRegex(ValueError, 'fixed three-file roster'):
            self.observe()

    def test_full_previous_namespace_still_selected(self):
        plan = json.loads((PREP / 'PIN-PLAN.json').read_bytes())
        old = json.loads((ROOT / 'manager-send-lifetime-compiler-preparation-v1/PIN-PLAN.json').read_bytes())
        for name in ('source_dir', 'source_manifest', 'source_namespace'):
            self.assertEqual(plan[name], old[name])
        self.assertTrue(set(old['extra_absent']).issubset(plan['extra_absent']))
        for name in ('witness.h.gch', 'commission.h.gch'):
            self.assertIn(plan['candidate_source_dir'] + '/' + name, plan['extra_absent'])

    def test_candidate_result_is_independent_mapping(self):
        before = copy.deepcopy(self.plan)
        observed = self.observe()
        self.assertEqual(self.plan, before)
        self.assertEqual(observed, self.observe())

    def test_drift_after_successful_before_snapshot(self):
        self.assertEqual(set(self.observe()), {'commission.h', 'witness.h', 'witness_io.c'})
        self.assertEqual((self.source / 'witness_io.c').write_bytes(b'changed'), 7)
        with self.assertRaisesRegex(ValueError, 'source drift'):
            self.observe()

    def dependency_file(self, sources):
        raw = str(self.root / 'witness_io.s') + ': ' + ' '.join(sources) + '\n'
        encoded = raw.encode('ascii')
        self.assertEqual((self.root / 'witness_io.d').write_bytes(encoded), len(encoded))

    def dependency_result(self):
        return self.ns['dependencies'](self.root, {'files': {}}, self.plan)

    def test_dependency_new_three_paths(self):
        names = [str(self.source / name) for name in ('witness_io.c', 'witness.h', 'commission.h')]
        self.dependency_file(names)
        self.assertEqual(self.dependency_result()['paths'], names)

    def test_dependency_missing_file_is_nonpass(self):
        self.assertEqual(self.dependency_result(), {'status': 'MISSING_NONPASS'})

    def test_dependency_old_source_path_refused(self):
        names = [str(self.original / 'witness_io.c'), str(self.source / 'witness.h'),
                 str(self.source / 'commission.h')]
        self.dependency_file(names)
        with self.assertRaisesRegex(ValueError, 'required-source refusal'):
            self.dependency_result()

    def test_dependency_extra_path_refused(self):
        names = [str(self.source / name) for name in ('witness_io.c', 'witness.h', 'commission.h')]
        self.dependency_file(names + ['/mock/foreign.h'])
        with self.assertRaisesRegex(ValueError, 'outside admitted BEFORE cohort'):
            self.dependency_result()


if __name__ == '__main__':
    unittest.main(verbosity=2)

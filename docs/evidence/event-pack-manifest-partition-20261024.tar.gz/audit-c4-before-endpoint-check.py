"""Exact focused packet audit; not a general Ada parser or system acceptance."""
import hashlib
import importlib.util
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parent
REPO = Path('/home/sicarii/Work/sia-assurance-checkpoint-20261023')
STAGE = ROOT / 'stage-c4'
PROOF = STAGE / 'spark/pack-manifest-obj/gnatprove'
UNITS = {'sia_policy': 7, 'sia_pack_retirement': 16,
         'sia_pack_manifest_wire': 18, 'sia_pack_partition': 16,
         'pack_retirement_tests': 0, 'pack_retirement_test_support': 0,
         'pack_manifest_tests': 0}
DETAIL = re.compile(
    r'  ([A-Za-z][A-Za-z0-9_.]*) at ([a-z][a-z0-9_]*\.ads):([1-9][0-9]{0,5}) '
    r'flow analyzed \(0 errors, 0 checks, 0 warnings and 0 pragma Assume statements\) '
    r'and proved \([0-9]{1,6} checks\)')


def load(name):
    return json.loads((ROOT / name).read_text())


def pin(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def source():
    files = load('c4-proof.result.json')['before']
    if len(files) != 14:
        raise ValueError('unexpected source roster')
    for name, expected in files.items():
        if pin(STAGE / name) != expected:
            raise ValueError('source mismatch')
    for phase in ('build', 'runtime', 'retirement', 'proof'):
        result = load('c4-' + phase + '.result.json')
        if result['exit'] != 0 or not result['unchanged'] or result['before'] != files:
            raise ValueError('incomplete positive evidence')
    for name, expected in load('base.json')['copied'].items():
        if files[name] != expected or pin(REPO / name) != expected:
            raise ValueError('original dependency changed')
    negative = load('negative6-runtime.result.json')
    if negative['exit'] != 1 or not negative['unchanged']:
        raise ValueError('unexpected negative outcome')
    if load('negative6-build.result.json')['exit'] != 0:
        raise ValueError('negative did not compile')
    for name in files:
        actual = (ROOT / 'stage-negative6' / name).read_bytes()
        expected = (STAGE / name).read_bytes()
        if name == 'spark/src/sia_pack_manifest_wire.ads':
            expected = expected.replace(b'Digest (Data (33 .. 64))', b'Digest (Data (1 .. 32))')
        if actual != expected:
            raise ValueError('negative source delta mismatch')
    if (ROOT / 'negative6-runtime.stderr').read_text().strip() != \
            'raised PROGRAM_ERROR : Python producer first complete record':
        raise ValueError('wrong semantic refusal')
    return files


def declarations():
    """Public flat declarations plus the two explicitly reviewed private records."""
    result = set()
    pattern = re.compile(r'^(?:package|   function|   procedure) ([A-Za-z][A-Za-z0-9_]*)\b')
    private_records = {'sia_pack_manifest_wire': 'Cursor', 'sia_pack_partition': 'Partition_State'}
    for unit, count in UNITS.items():
        if count == 0:
            continue
        path = STAGE / 'spark/src' / (unit + '.ads')
        private = False
        for line_number, line in enumerate(path.read_text().splitlines(), 1):
            private = private or line == 'private'
            match = pattern.match(line) if not private else None
            if match:
                short = match.group(1)
                qualified = short if line.startswith('package ') else unit + '.' + short
                result.add((qualified.lower(), path.name, line_number))
            elif private and line == '   type ' + private_records.get(unit, '') + ' is record':
                result.add((unit + '.' + private_records[unit].lower(), path.name, line_number))
    return result


def checker():
    spec = importlib.util.spec_from_file_location('original_checker', REPO / 'spark/check-proof-summary.py')
    if spec is None or spec.loader is None:
        raise ValueError('checker import unavailable')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def report_checks(lines):
    gate = checker()
    gate.check_totals(lines)
    expected = declarations()
    seen = set()
    units = set()
    current = None
    for line in lines:
        if line.startswith('in unit '):
            match = gate.UNIT.fullmatch(line)
            if match is None:
                raise ValueError('malformed unit')
            current, analyzed, available = match.groups()
            if current in units or current not in UNITS or \
                    int(analyzed) != UNITS[current] or analyzed != available:
                raise ValueError('unit scope mismatch')
            units.add(current)
        elif ' at ' in line or 'flow analyzed' in line or 'pragma Assume' in line:
            match = DETAIL.fullmatch(line)
            if match is None:
                raise ValueError('unclean detail')
            name, filename, number = match.groups()
            key = (name.lower(), filename, int(number))
            if Path(filename).stem != current or key not in expected or key in seen:
                raise ValueError('unbound or duplicate declaration')
            seen.add(key)
    if seen != expected or units != set(UNITS):
        raise ValueError('incomplete declaration or unit coverage')
    return sorted(seen)


def raw_checks():
    names = {row[0] for row in declarations()}
    for unit, count in UNITS.items():
        if count == 0:
            continue
        raw = json.loads((PROOF / (unit + '.spark')).read_text())
        if raw['progress'] != 'PROGRESS_PROOF' or raw['stop_reason'] != 'STOP_REASON_NONE':
            raise ValueError('incomplete raw analysis')
        for field in ('pragma_assume', 'skip_proof', 'skip_flow_proof'):
            if raw.get(field) != []:
                raise ValueError('assumed or excluded production proof')
        for field in ('warn_error', 'flow', 'proof'):
            rows = raw.get(field)
            if not isinstance(rows, list) or len(rows) > 4096 or \
                    any(row.get('severity') != 'info' for row in rows):
                raise ValueError('missing or noninformational diagnostics')
        if len(raw['spark']) != count or any(value != 'all' for value in raw['spark'].values()):
            raise ValueError('partial SPARK scope')
        for claim in raw['assumptions']:
            for reference in [claim['claim'], *claim['assumptions']]:
                entity = raw['entities'][f" {reference['arg']}"]
                if entity['name'].lower() not in names:
                    raise ValueError('dependency outside analyzed source')
    if re.search(r'\b(warning|medium|high|error):', (ROOT / 'c4-proof.stderr').read_text()):
        raise ValueError('unclean proof stderr')


def controls(lines):
    """Retained finite fault controls on report admission, not parser completeness."""
    detail = next(line for line in lines if DETAIL.fullmatch(line))
    faults = [lines + [detail], [line for line in lines if line != detail],
              [line.replace('0 pragma Assume', '1 pragma Assume') for line in lines],
              [line.replace('18 subprograms and packages out of 18',
                            '17 subprograms and packages out of 18') for line in lines],
              [line for line in lines if not line.startswith('in unit sia_policy,')]]
    for number, changed in enumerate(faults, 1):
        try:
            report_checks(changed)
        except (ValueError, SystemExit):
            continue
        raise ValueError(f'audit negative {number} was admitted')
    return len(faults)


def main():
    files = source()
    lines = (PROOF / 'gnatprove.out').read_text().splitlines()
    coverage = report_checks(lines)
    raw_checks()
    result = {'status': 'FOCUSED_EXACT_SOURCE_CHECKS_DISCHARGED', 'source': files,
              'entities': coverage, 'audit_negative_controls': controls(lines),
              'report_sha256': pin(PROOF / 'gnatprove.out'),
              'checker_sha256': pin(REPO / 'spark/check-proof-summary.py'),
              'binary_sha256': pin(STAGE / 'spark/pack-manifest-bin/pack_manifest_tests'),
              'scope': 'Modular manifest decoding and per-step partition contracts; no authentication or effect authority',
              'full_system_acceptance': 'OPEN'}
    with (ROOT / 'integrity-audit-c4.json').open('x') as handle:
        json.dump(result, handle, indent=2)
    print(result['status'])


if __name__ == '__main__':
    main()

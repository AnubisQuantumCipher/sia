# Preserved failures and limited scope

- C1 strict build failed: the test encoder used ambiguous unqualified Magic declarations. C2 qualifies the manifest constant; no suppression.
- C2 strict build, runtime and focused proof passed, but independent review found missing specification guarantees for completion and refused-prefix preservation. C3 strengthens contracts and adds direct controls; executable bodies and input domains unchanged.
- C4 retains C3 production source, adding a nonuniform vector actually emitted by the existing Python manifest producer. Final evidence applies to C4 only.
- Negative9 is the C3 coherent content/identity decoding mutant: strict build succeeds and unchanged tests refuse complete record correspondence. Negative6 repeats the same mutation on C4 and must fail the actual Python vector oracle.
- Stage-negative is a prepared C2 mutation, not executed; it supplies no result.
- Initial toolchain inventory assumed bundled cvc5 was on PATH. It was not, so inventory refused; subsequent explicit GNATprove-reported bundled executable paths were rehashed. No unresolved tool version inferred from PATH.
- A diff-whitespace command was initially issued from the evidence directory, which is not a Git repository. It failed without checking the source; the explicit publisher-directory check succeeded later.
- These are conditional modular contracts, not a full trace-history theorem, authentication or effects. Tests are outside SPARK. The focused auditor is pinned to this source layout, not a general Ada parser or proof-run authenticator.
- Native send-lifetime compiler qualification still FAILED at the original file cap. No supported next native variant. R05 PENDING, protected activation, complete runtime/proof, recovery and installed/release/marketplace gates remain OPEN. No caps or original acceptance workloads changed.

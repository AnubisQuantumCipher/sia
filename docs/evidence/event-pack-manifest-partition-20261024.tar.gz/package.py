"""Archive the bounded inactive campaign with raw failures and exact source."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile

ROOT = Path(__file__).resolve().parent
REPO = Path('/home/sicarii/Work/sia-assurance-checkpoint-20261023')


def load(name):
    return json.loads((ROOT / name).read_text())


def pin(path):
    return {'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
            'bytes': path.stat().st_size}


def members():
    result = set()
    for pattern in ('c[1-9]-*.*', 'negative*.*', 'audit*.py', 'integrity-audit*.json',
                    'static-*.*', 'REVIEW*.txt'):
        result.update(ROOT.glob(pattern))
    names = ('run.py', 'package.py', 'FAILURES.md', 'base.json',
             'toolchain.json', 'toolchain-discovery-failure.txt', 'arithmetic-oracle.json',
             'python-manifest-vector.json', 'independent-source-review.json')
    result.update(ROOT / name for name in names)
    source = load('integrity-audit-c4.json')['source']
    stages = sorted(ROOT.glob('stage-*'))
    if not stages or len(stages) > 16:
        raise ValueError('stage capacity')
    for stage in stages:
        result.update(stage / name for name in source)
        proof = stage / 'spark/pack-manifest-obj/gnatprove'
        for pattern in ('gnatprove.out', '*.spark', '*.adb.stdout', '*.adb.stderr'):
            result.update(proof.glob(pattern))
    if not result or len(result) > 512:
        raise ValueError('archive member capacity')
    return sorted(result)


def archive(paths):
    target = REPO / 'docs/evidence/event-pack-manifest-partition-20261024.tar.gz'
    inventory = {}
    total = 0
    with target.open('wb') as output, gzip.GzipFile(fileobj=output, mode='wb', mtime=0, filename='') as compressed:
        with tarfile.open(fileobj=compressed, mode='w|') as tar:
            for path in paths:
                if path.is_symlink() or not path.is_file():
                    raise ValueError('nonregular member')
                size = path.stat().st_size
                total += size
                if size > 4 * 1024 * 1024 or total > 16 * 1024 * 1024:
                    raise ValueError('archive byte capacity')
                raw = path.read_bytes()
                name = str(path.relative_to(ROOT))
                info = tarfile.TarInfo(name)
                info.size, info.mode, info.mtime = len(raw), 0o644, 0
                tar.addfile(info, io.BytesIO(raw))
                inventory[name] = {'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)}
    seen = set()
    with tarfile.open(target, 'r:gz') as tar:
        for member in tar:
            handle = tar.extractfile(member)
            if member.name in seen or handle is None or \
                    hashlib.sha256(handle.read()).hexdigest() != inventory[member.name]['sha256']:
                raise ValueError('archive readback mismatch')
            seen.add(member.name)
    if seen != set(inventory):
        raise ValueError('incomplete archive')
    return {'path': str(target.relative_to(REPO)), **pin(target), 'members': inventory}


def validate():
    audit = load('integrity-audit-c4.json')
    for name, expected in audit['source'].items():
        if pin(REPO / name)['sha256'] != expected:
            raise ValueError('source drift')
    static = load('static-final.result.json')
    if static['exit'] != 0 or (ROOT / 'static-final.stdout').read_text().strip() != '[]' or \
            (ROOT / 'static-final.stderr').read_text():
        raise ValueError('static diagnostics')
    for name, expected in static['source'].items():
        if pin(ROOT / name)['sha256'] != expected:
            raise ValueError('driver drift')
    return audit


def main():
    audit = validate()
    artifact = archive(members())
    summary = {'status': 'MODULAR_MANIFEST_PARTITION_CONTRACTS_PROVED_TESTED_INACTIVE',
               'base_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO,
                                                      text=True, timeout=10).strip(),
               'audit': audit, 'archive': artifact,
               'runtime': (ROOT / 'c4-runtime.stdout').read_text().strip(),
               'retirement': (ROOT / 'c4-retirement.stdout').read_text().strip(),
               'proof_result': load('c4-proof.result.json'),
               'negative_result': load('negative6-runtime.result.json'),
               'producer_vector': load('python-manifest-vector.json'),
               'toolchain': load('toolchain.json'),
               'review': (ROOT / 'REVIEW-c4-final.txt').read_text(),
               'failures': (ROOT / 'FAILURES.md').read_text(),
               'boundary': 'No authenticated stream custody, protected admission/effects, runtime activation, R05 waiver, full-system acceptance or release.'}
    target = REPO / 'docs/EVENT-PACK-MANIFEST-PARTITION-EVIDENCE-20261024.json'
    target.write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps({'summary': pin(target), 'archive': pin(REPO / artifact['path']),
                      'members': len(artifact['members'])}))


if __name__ == '__main__':
    main()

"""Reproduce the checkpoint core from committed bytes, retaining limited scope."""
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess

ROOT = Path(__file__).parent
EXPECTED = 'ac0a35857180381ff07feff7eef5046ed25789e3'


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main():
    helper_path = ROOT / 'run-continuity-checkpoint-wire-development-v1.py'
    helper = load('helper', helper_path)
    driver = load('driver', helper.DRIVER)
    status = subprocess.check_output(['git', 'status', '--porcelain'], cwd=driver.ROOT,
                                     text=True, timeout=10)
    if status:
        raise ValueError('committed reproduction requires a clean checkout')
    driver.CHANGED = ()
    output = ROOT / 'checkpoint-committed-reproduction-v1'
    output.mkdir()
    helper.storage(output, 'storage-preflight.json')
    receipt = driver.snapshot(output)
    if receipt['base'] != EXPECTED:
        raise ValueError('source commit changed before snapshot')
    receipt['scope'] = 'COMMITTED SCOPED REPRODUCTION: all twelve runtimes and checkpoint core only'
    receipt['archive_sha256'] = helper.digest(output / 'base.tar')
    receipt['runner_dependencies'] = {}
    for path in (Path(__file__), helper_path, helper.DRIVER):
        receipt['runner_dependencies'][str(path)] = helper.digest(path)
        shutil.copyfile(path, output / path.name)
    source = Path(receipt['cwd'])
    receipt['source_files'] = {str(p.relative_to(source)): helper.digest(p)
                              for p in sorted((source / 'spark').rglob('*')) if p.is_file()}
    passed = True
    for name, duration, command in helper.make_plan():
        if name == 'harness-proof':
            break
        passed = driver.check(output, receipt, name, duration, command)
        if name.endswith('-proof'):
            helper.retain_raw(output, receipt, name)
        if not passed:
            break
    receipt['proof_tools_after'] = driver.proof_tools()
    receipt['tools_unchanged'] = receipt['proof_tools_before'] == receipt['proof_tools_after']
    receipt['complete_harness_proof'] = 'UNPROVEN: unchanged source already timed out at 120 seconds'
    receipt['full_project_proof'] = 'UNRUN for this commit; earlier full-project 600-second failure remains open'
    (output / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    helper.storage(output, 'storage-after.json')
    return 0 if passed and receipt['tools_unchanged'] else 1


if __name__ == '__main__':
    raise SystemExit(main())

"""Package the complete SDK fixture observation without changing its sources."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import re
import tarfile

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent
REPO = Path('/home/sicarii/Work/sia-assurance-checkpoint-20261023')
DIRECTORIES = {'source': 'sdk-loop-finally-v8',
               'baseline': 'sdk-fixtures-constant-clock-v1',
               'previous': 'sdk-scratch-sweep-v4'}
CURRENT = ('run.py', 'admission.json', 'process.json', 'result.json',
           'full.stdout', 'full.stderr', 'static.json', 'static.stdout',
           'static.stderr', 'REPORT.md', 'review.md', 'build_public.py',
           'builder-static.json')


def read(path):
    with path.open('rb') as stream:
        raw = stream.read(2097153)
    if len(raw) > 2097152:
        raise ValueError('forensic member decode capacity')
    return raw


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def payloads(result):
    members = {name: read(OUT / name) for name in CURRENT}
    members['AUTHORIZATION.md'] = read(ROOT / 'execution-policy-20261025-v1/AUTHORIZATION.md')
    for label, directory in DIRECTORIES.items():
        manifest = read(ROOT / directory / 'OWN-SOURCE.json')
        members[label + '/OWN-SOURCE.json'] = manifest
        files = json.loads(manifest)['files']
        if set(files) != set(result['before'][label]) or len(files) > 256:
            raise ValueError('declared source roster changed')
        for name, entry in files.items():
            if Path(name).name != name:
                raise ValueError('source filename is not flat')
            raw = read(ROOT / directory / name)
            if digest(raw) != entry['sha256'] or digest(raw) != result['before'][label][name]:
                raise ValueError('source changed since execution')
            members[label + '/' + name] = raw
    for name in ('full-result.json', 'full.stdout', 'full.stderr', 'static-full.json'):
        members['historical/' + name] = read(ROOT / DIRECTORIES['source'] / name)
    pins = {name: digest(raw) for name, raw in members.items()}
    members['SHA256.json'] = (json.dumps(pins, indent=2, sort_keys=True) + '\n').encode()
    return members


def archive(members):
    target = io.BytesIO()
    with gzip.GzipFile(fileobj=target, mode='wb', filename='', mtime=0) as zipped:
        with tarfile.open(fileobj=zipped, mode='w', format=tarfile.USTAR_FORMAT) as tar:
            for name, raw in sorted(members.items()):
                entry = tarfile.TarInfo(name)
                entry.size, entry.mode = len(raw), 0o644
                tar.addfile(entry, io.BytesIO(raw))
    return target.getvalue()


def validated_result():
    result = json.loads(read(OUT / 'result.json'))
    output = read(OUT / 'full.stderr')
    footer = re.search(rb'\nRan (\d+) tests in ([\d.]+)s\n\nOK\n\Z', output)
    if footer is None or int(footer[1]) != 182 or result['exit'] != 0:
        raise ValueError('complete successful roster missing')
    if not result['unchanged'] or result['before'] != result['after']:
        raise ValueError('source correspondence failed')
    if result['tools_before'] != result['tools_after']:
        raise ValueError('tool correspondence failed')
    if digest(output) != result['stderr_sha256']:
        raise ValueError('output correspondence failed')
    if digest(read(OUT / 'full.stdout')) != result['stdout_sha256']:
        raise ValueError('stdout correspondence failed')
    return result, {'count': int(footer[1]), 'seconds': footer[2].decode(), 'skips': 0}


def main():
    result, tests = validated_result()
    members = payloads(result)
    raw = archive(members)
    if archive(members) != raw:
        raise ValueError('archive reproduction failed')
    relative = 'docs/evidence/sdk-full-resource-policy-20261025.tar.gz'
    report = {'schema': 'sia.sdk-complete-fixture-evidence.v1', 'authority': 'NONE',
              'status': 'COMPLETE_FIXTURE_PASS_UNDER_REVISED_ENGINEERING_POLICY',
              'tests': tests, 'exit': result['exit'], 'elapsed_ns': result['elapsed_ns'],
              'max_rss_kib': result['max_rss_kib'], 'unchanged': result['unchanged'],
              'source_maps': result['before'], 'native_admission': False,
              'installed_admission': False, 'whole_system_acceptance': False,
              'archive': {'path': relative, 'sha256': digest(raw), 'bytes': len(raw),
                          'members': len(members), 'reproduced': True},
              'prior_result': 'Original capped failure retained, not relabeled',
              'scope': 'Complete unchanged private v8 fixture roster; forensic archive'}
    with (REPO / relative).open('xb') as stream:
        stream.write(raw)
    with (REPO / 'docs/SDK-FULL-RESOURCE-POLICY-20261025.json').open('x') as stream:
        json.dump(report, stream, indent=2, sort_keys=True)
        stream.write('\n')
    with (REPO / 'docs/SDK-FULL-RESOURCE-POLICY-20261025.md').open('xb') as stream:
        stream.write(read(OUT / 'REPORT.md'))
    print(json.dumps({'tests': tests, 'archive': report['archive']}))


if __name__ == '__main__':
    main()

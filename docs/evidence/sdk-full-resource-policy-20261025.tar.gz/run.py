"""Run the unchanged SDK fixture roster under the revised engineering policy."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import resource
import shutil
import subprocess
import time

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent
WORK = ROOT / 'sdk-loop-finally-v8'
DIRECTORIES = (
    ('source', WORK),
    ('baseline', ROOT / 'sdk-fixtures-constant-clock-v1'),
    ('previous', ROOT / 'sdk-scratch-sweep-v4'),
)
POLICY = ROOT / 'execution-policy-20261025-v1/AUTHORIZATION.md'


def read_json(path):
    with path.open('rb') as stream:
        raw = stream.read(2097153)
    if len(raw) > 2097152:
        raise ValueError('receipt input capacity')
    return json.loads(raw)


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def pins(directory):
    declared = read_json(directory / 'OWN-SOURCE.json')['files']
    if len(declared) > 256:
        raise ValueError('source inventory capacity')
    actual = {}
    for name, entry in declared.items():
        path = directory / name
        info = path.stat()
        if any(getattr(info, key) != value for key, value in entry['identity'].items()):
            raise ValueError('source identity changed: ' + name)
        actual[name] = sha(path)
        if actual[name] != entry['sha256']:
            raise ValueError('source digest changed: ' + name)
    if {p.name for p in directory.glob('*.py')} != set(declared):
        raise ValueError('undeclared Python source')
    return actual


def prepare():
    prior = read_json(WORK / 'full-result.json')
    command = list(prior['command'])
    prefix = ['/usr/bin/flock', '-F', '-n', '-E', '75',
              '/home/sicarii/.worldline-heavy.lock', '/usr/bin/prlimit',
              '--as=536870912', '--fsize=536870912', '--core=0', '--',
              '/usr/bin/timeout', '--signal=TERM', '--kill-after=5s', '120s']
    if command[:len(prefix)] != prefix or command[len(prefix)] != '/usr/bin/bwrap':
        raise ValueError('prior engineering envelope mismatch')
    revised = prefix[:7] + ['--core=0', '--'] + command[len(prefix):]
    before = {label: pins(directory) for label, directory in DIRECTORIES}
    for label, _directory in DIRECTORIES:
        if before[label] != prior[label + '_before']:
            raise ValueError('historical source correspondence changed')
    paths = [Path(__file__), POLICY, WORK / 'full-result.json']
    paths.extend(directory / 'OWN-SOURCE.json' for _label, directory in DIRECTORIES)
    paths.extend(Path(name) for name in revised if name.startswith('/usr/bin/'))
    tools = {str(path): sha(path) for path in paths}
    return revised, prior['environment'], before, tools


def write_json(name, value):
    with (OUT / name).open('x') as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write('\n')


def main():
    command, environment, before, tools = prepare()
    record = {'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'command': command, 'environment': environment, 'before': before,
              'tools_before': tools, 'owner_pid': os.getpid(),
              'free_disk_bytes': shutil.disk_usage(OUT).free,
              'inherited_as_limit': resource.getrlimit(resource.RLIMIT_AS),
              'inherited_file_limit': resource.getrlimit(resource.RLIMIT_FSIZE),
              'policy': str(POLICY), 'source_scope': 'Unchanged complete SDK v8 fixture roster',
              'not_claimed': 'Old envelope, loaded-code custody, installed or native admission'}
    write_json('admission.json', record)
    started = time.monotonic_ns()
    with (OUT / 'full.stdout').open('xb') as stdout, (OUT / 'full.stderr').open('xb') as stderr:
        child = subprocess.Popen(command, env=environment, stdout=stdout, stderr=stderr)
        write_json('process.json', {'pid': child.pid, 'owner_pid': os.getpid(),
                                   'started_monotonic_ns': started, 'command': command})
        code = child.wait()
    after = {label: pins(directory) for label, directory in DIRECTORIES}
    after_tools = {path: sha(Path(path)) for path in tools}
    record.update(exit=code, elapsed_ns=time.monotonic_ns() - started, after=after,
                  tools_after=after_tools, unchanged=before == after and tools == after_tools,
                  max_rss_kib=resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,
                  stdout_sha256=sha(OUT / 'full.stdout'), stderr_sha256=sha(OUT / 'full.stderr'))
    write_json('result.json', record)
    print(json.dumps({key: record[key] for key in ('exit', 'elapsed_ns', 'unchanged', 'max_rss_kib')}))
    return code if record['unchanged'] else 1


if __name__ == '__main__':
    raise SystemExit(main())

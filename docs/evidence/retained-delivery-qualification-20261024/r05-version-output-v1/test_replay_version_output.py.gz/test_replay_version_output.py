"""Replay must bind current projector output to supplied source bytes."""

import json
import unittest
from unittest import mock

import siaeventintake as replay
from tests import test_event_live_intake as fixtures


class ReplayVersionOutput(unittest.TestCase):
    def setUp(self):
        self.case = fixtures.EventLiveIntakeProjection(methodName="runTest")
        self.case.setUp()
        self.addCleanup(self.case.doCleanups)
        self.request = self.case.request([
            self.case.entry({"sense_custom:alpha": [self.case.event()]})])
        self.case.assert_projection(self.case.project(self.request), self.request)

    def refuse_changed_output(self, field, value, *, after_member=False):
        projector = self.case.lib._corpus_page_version_from_bytes
        member = replay._member
        ready = [not after_member]
        changed = []

        def projected(**arguments):
            version = projector(**arguments)
            if ready[0]:
                version[field] = value
                changed.append(field)
            return version

        def admitted(*arguments):
            result = member(*arguments)
            ready[0] = True
            return result

        before = self.case.fixture.snapshot()
        with mock.patch.object(self.case.lib, "_corpus_page_version_from_bytes", projected), \
                mock.patch.object(replay, "_member", admitted):
            with self.assertRaises((ValueError, RuntimeError)) as caught:
                self.case.project(self.request)
        error = caught.exception
        chain = []
        for _ in range(8):
            chain.append({"type": type(error).__name__, "message": str(error),
                          "reason": getattr(error, "reason", None),
                          "upstream_reason": getattr(error, "upstream_reason", None)})
            if error.__cause__ is None:
                break
            error = error.__cause__
        else:
            self.fail("exception chain exceeds diagnostic capacity")
        print(json.dumps({"field": field, "after_member": after_member, "chain": chain}))
        self.assertTrue(changed, "the actual projector callback did not run")
        self.assertEqual(self.case.fixture.snapshot(), before)

    def test_content_must_match_original_raw_bytes(self):
        self.refuse_changed_output("content", "invented page contents\n")

    def test_subject_must_match_original_slug(self):
        self.refuse_changed_output("subject", "events/other/2026-01-06")

    def test_source_digest_must_match_original_bytes(self):
        self.refuse_changed_output("source_sha256", "f" * 64)

    def test_content_digest_must_match_original_bytes(self):
        self.refuse_changed_output("content_sha256", "e" * 64)

    def test_later_callback_cannot_change_origin_under_the_same_version(self):
        self.refuse_changed_output("origin", "model", after_member=True)


if __name__ == "__main__":
    unittest.main()

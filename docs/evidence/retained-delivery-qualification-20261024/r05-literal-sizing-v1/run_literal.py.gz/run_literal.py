"""Run one bounded private workload probe and retain exact input identities."""
import hashlib
import json
from pathlib import Path
import subprocess
import time

ROOT = Path(__file__).parent
REPOSITORY = Path('/home/sicarii/Work/sia-note-boundary-checkpoint-20261024')


def hashes(paths):
    if len(paths) > 2048:
        raise ValueError('source inventory capacity')
    return {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in sorted(paths)}


def main():
    if (ROOT / 'workload-result.json').exists():
        raise ValueError('existing result')
    template = json.loads((ROOT.parent / 'r05-page-sizing-iterative-v1' /
                           'profile-baseline-result.json').read_bytes())
    command = template['command']
    position = command.index('/tmp/validation-profile.py')
    del command[position-2:position+1]
    point = command.index('--unshare-net')
    for source, target in (('sialiveloop.py', '/tmp/sia-review-source/bin/sialiveloop.py'),
                           ('test_literal_sizing.py', '/tmp/test_literal_sizing.py'),
                           ('original-sialiveloop.py.txt', '/tmp/original-sialiveloop.py.txt')):
        command[point:point] = ['--ro-bind', str(ROOT / source), target]
    command[-1] = ('import sys,unittest; sys.path[:0]=["/tmp/sia-review-source/bin","/tmp"]; '
                   'from tests import sia_test_home; '
                   'suite=unittest.defaultTestLoader.loadTestsFromNames('
                   '["test_literal_sizing","tests.test_json_size_fast_path","tests.test_ascii_page_sizing","tests.test_unicode_sizing_admission","tests.test_json_key_step"]); '
                   'result=unittest.TextTestRunner(verbosity=2).run(suite); '
                   'raise SystemExit(0 if result.wasSuccessful() else 1)')
    names = subprocess.check_output(['git', 'ls-files', '-z', 'bin', 'tests'],
                                    cwd=REPOSITORY, timeout=10).decode().split('\0')
    paths = {REPOSITORY / name for name in names if name and name.endswith('.py')}
    paths |= {ROOT / 'sialiveloop.py', ROOT / 'test_literal_sizing.py', ROOT / 'original-sialiveloop.py.txt', Path(__file__)}
    before = hashes(paths)
    receipt = {'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'],
                   cwd=REPOSITORY, timeout=10, text=True).strip(),
               'command': command, 'environment': template['environment'], 'before': before}
    (ROOT / 'workload-inputs.json').write_text(json.dumps(receipt, indent=2) + '\n')
    started = time.monotonic_ns()
    with (ROOT / 'workload.stdout').open('xb') as out, (ROOT / 'workload.stderr').open('xb') as err:
        result = subprocess.run(command, env=template['environment'], stdout=out,
                                stderr=err, check=False)
    receipt.update(after=hashes(paths), exit=result.returncode,
                   elapsed_ns=time.monotonic_ns() - started)
    receipt['unchanged'] = receipt['before'] == receipt['after']
    receipt['output_hashes'] = hashes({ROOT / 'workload.stdout', ROOT / 'workload.stderr'})
    (ROOT / 'workload-result.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps({key: receipt[key] for key in ('head', 'exit', 'unchanged', 'elapsed_ns')}))


if __name__ == '__main__':
    main()

"""Preserve original add/refusal traces while eliminating fixed-literal sizing."""
import ast
from pathlib import Path
import unittest

import sialiveloop as live


def original():
    source = Path('/tmp/original-sialiveloop.py.txt').read_bytes()
    if len(source) > 1024 * 1024:
        raise ValueError('reference capacity')
    tree = ast.parse(source)
    nodes = [node for node in tree.body if isinstance(node, ast.FunctionDef)
             and node.name == '_count_ascii_json_string']
    if len(nodes) != 1:
        raise ValueError('reference function identity')
    space = dict(vars(live))
    exec(compile(ast.Module(body=nodes, type_ignores=[]), '<retained-original>', 'exec'), space)
    return space['_count_ascii_json_string']


def observed(operation, text, ascii_only, refusal=None):
    trace = []
    sentinel = RuntimeError('add refusal')

    def add(amount):
        trace.append(amount)
        if len(trace) > 128:
            raise AssertionError('trace capacity')
        if len(trace) == refusal:
            raise sentinel

    try:
        value = operation(text, add, ascii_only=ascii_only)
    except RuntimeError as error:
        if error is not sentinel:
            raise
        return trace, 'refused'
    return trace, value


class LiteralSizing(unittest.TestCase):
    def test_add_and_each_refusal_frontier_match_original(self):
        reference = original()
        samples = ('', 'plain', ''.join(chr(i) for i in range(128)),
                   'quote" slash\\ newline\n', 'é😀', 'a' * 4097 + 'é', '\ud800')
        for text in samples:
            for ascii_only in (False, True):
                expected = observed(reference, text, ascii_only)
                self.assertEqual(observed(live._count_ascii_json_string, text, ascii_only), expected)
                for index in range(1, len(expected[0]) + 1):
                    with self.subTest(length=len(text), mode=ascii_only, cut=index):
                        self.assertEqual(observed(live._count_ascii_json_string, text, ascii_only, index),
                                         observed(reference, text, ascii_only, index))

    def test_first_add_still_precedes_item_length(self):
        class Text(str):
            def __len__(self):
                raise AssertionError('length read too early')

        for operation in (original(), live._count_ascii_json_string):
            self.assertEqual(observed(operation, Text('plain'), False, 1), ([2], 'refused'))

"""Retain and reproduce the bounded fresh-admission checkpoint manifest."""
import gzip
import hashlib
import json
from pathlib import Path
import sys

BASE = Path(__file__).parent
REPO = Path('/home/sicarii/Work/sia-note-boundary-checkpoint-20261024')
DEST = REPO / 'docs/evidence/retained-delivery-qualification-20261024'
SOURCES = ('bin/siasourcebatch.py', 'bin/siasourcecheckpoint.py',
           'bin/sialiveloop.py', 'bin/siaeventplan.py')
GROUPS = {'r05-fresh-full-roster-v1': ('run_roster.py',
                              'workload-result.json',
                              'workload.stdout',
                              'workload.stderr'),
 'r05-version-output-v1': ('test_replay_version_output.py',),
 'r05-workload-reconstruction-v3': ('workload_probe.py',),
 'r05-fresh-compact-public-v1': ('compact_probe.py',
                                 'run_workload.py',
                                 'workload-result.json',
                                 'workload.stdout',
                                 'workload.stderr',
                                 'static-result.json',
                                 'static.stdout',
                                 'workload-artifacts/legacy-batch.json',
                                 'workload-artifacts/parent-checkpoint.json',
                                 'workload-artifacts/compact-image.json',
                                 'workload-artifacts/compact-comparison.json'),
 'r05-fresh-delivery-capture-v1': ('run_roster.py',
                                   'workload-result.json',
                                   'workload.stdout',
                                   'workload.stderr'),
 'r05-delivery-baseline-v1': ('run_roster.py',
                              'siasourcebatch.py',
                              'siasourcecheckpoint.py',
                              'workload-result.json',
                              'workload.stdout',
                              'workload.stderr'),
 'r05-delivery-profile-v1': ('profile_case.py',
                             'run_profile.py',
                             'workload-result.json',
                             'workload.stdout',
                             'workload.stderr',
                             'static-result.json',
                             'static.stdout',
                             'COST-DISPOSITION.md'),
 'r05-fresh-resident-v1': ('run_roster.py',
                           'workload-result.json',
                           'workload.stdout',
                           'workload.stderr'),
 'r05-literal-sizing-v1': ('sialiveloop.py',
                           'original-sialiveloop.py.txt',
                           'test_literal_sizing.py',
                           'run_literal.py',
                           'DESIGN.md',
                           'workload-result.json',
                           'workload.stdout',
                           'workload.stderr',
                           'static-result.json',
                           'static.stdout'),
 'r05-literal-delivery-v1': ('run_roster.py',
                             'sialiveloop.py',
                             'workload-result.json',
                             'workload.stdout',
                             'workload.stderr')}


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def publish(path, raw, check):
    if check:
        if path.read_bytes() != raw:
            raise ValueError('evidence mismatch: ' + str(path))
    else:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(raw)


def members():
    result = [BASE / group / name for group, names in GROUPS.items() for name in names]
    result.extend(BASE / 'r05-fresh-compact-public-v1/workload-artifacts' / f'load{i:03d}.txt' for i in range(104))
    result.append(Path(__file__))
    if len(result) > 256:
        raise ValueError('member capacity')
    return result


def main():
    if sys.argv[1:] not in ([], ['--check']):
        raise ValueError('unsupported arguments')
    check = bool(sys.argv[1:])
    records = []
    total = 0
    for source in members():
        raw = source.read_bytes()
        total += len(raw)
        if len(raw) > 8 * 1024 * 1024 or total > 16 * 1024 * 1024:
            raise ValueError('evidence byte capacity')
        name = str(source.relative_to(BASE)) + '.gz'
        packed = gzip.compress(raw, mtime=0)
        publish(DEST / name, packed, check)
        records.append({'path': str((DEST / name).relative_to(REPO)), 'sha256': digest(packed),
                        'original_sha256': digest(raw), 'original_bytes': len(raw)})
    data = {'schema': 'sia-delivery-qualification-evidence-v1', 'status': 'FAILED_INTEGRATION_DEADLINES',
            'base_commit': '8a84b06ec4c8a06c072513c57af93c669e21d5f7',
            'source_sha256': {name: digest((REPO / name).read_bytes()) for name in SOURCES},
            'members': records, 'limits': 'Original runtime caps unchanged; no release authority.'}
    publish(REPO / 'docs/RETAINED-DELIVERY-QUALIFICATION-20261024.json',
            (json.dumps(data, indent=2) + '\n').encode(), check)
    print(json.dumps({'check': check, 'members': len(records), 'uncompressed_bytes': total}))


if __name__ == '__main__':
    main()

"""Synthetic compact public-admission probe; no root or publication authority."""
import copy
import hashlib
import json
import time

import siaeventcheckpoint as checkpoints
import siasourcebatch as batches
import siasourcecheckpoint as compact
import workload_base as base


def entry(owner, image):
    return {'source_returns': image['source_returns'],
            'expected_source_returns_sha256': image['source_returns']['returns_sha256'],
            'event_batches': batches._validate_closure(owner, image['event_closure'], image['source_returns'])}


def checkpoint_request(owner, image):
    epoch = image['epoch']
    history = copy.deepcopy(epoch['history'])
    history['entries'].append(entry(owner, image))
    result = {name: epoch[name] for name in compact._DOC_KEYS}
    result.update(history=history, expected_history_sha256=batches._component_sha(owner, history),
                  observed_at=image['observed_at'])
    return result


def no_op_cursor(owner, proposal, source_ids):
    result = copy.deepcopy(proposal)
    result['after'] = copy.deepcopy(result['before_value'])
    pin = batches.native_sha(owner, result['after'])
    result['after_sha256'] = pin
    result['steps'] = [{'source_id': source, 'removed_keys': [], 'set_values': {},
                       'after_sha256': pin} for source in source_ids]
    return result


def synthetic_next(owner, original, parent):
    """Construct diagnostic data, never attest that its next events occurred."""
    clock = original['observed_at']
    committed = {name: '0' * 64 for name in compact._COMMIT_KEYS}
    epoch = compact.prepare_epoch(owner, checkpoint=parent,
        expected_checkpoint_sha256=batches.native_sha(owner, parent), committed=committed,
        root_sha256='0' * 64, observed_at=clock)
    returns = copy.deepcopy(original['source_returns'])
    returns['batch_id'] = 'synthetic-empty-next'
    returns['runs'] = [{'source_id': run['source_id'], 'events': []} for run in returns['runs']]
    returns['returns_sha256'] = batches._component_sha(owner, {
        name: value for name, value in returns.items() if name != 'returns_sha256'})
    projected = compact.project_capture_entry(owner, epoch=epoch,
        expected_epoch_sha256=batches.native_sha(owner, epoch), checkpoint=parent,
        returns=returns, closure=None, observed_at=clock)
    result = copy.deepcopy(original)
    result.update(schema='sia-controller-source-checkpoint-capture-v1',
        batch_id=returns['batch_id'], epoch=epoch, epoch_sha256=batches.native_sha(owner, epoch),
        parent_checkpoint=parent, source_returns=returns, event_closure=None,
        intake_projection=projected, non_claims=list(compact.CAPTURE_NON_CLAIMS),
        cursor_proposal=no_op_cursor(owner, original['cursor_proposal'],
                                    [run['source_id'] for run in returns['runs']]))
    result['batch_sha256'] = batches.native_sha(owner, {
        name: value for name, value in result.items() if name != 'batch_sha256'})
    return result


def measure(owner, image):
    started = time.monotonic_ns()
    try:
        result = compact.validate_capture(owner, image, image['batch_sha256'])
    except batches.SourceBatchRefusal as error:
        outcome = {'status': 'refused', 'reason': error.reason}
    else:
        if result is not None:
            raise AssertionError('unexpected validation result')
        outcome = {'status': 'accepted'}
    return {'elapsed_ns': time.monotonic_ns() - started, 'outcome': outcome}


def compare(owner, image):
    compact._VALIDATED_CAPTURES.clear()
    cold = measure(owner, image)
    warm = measure(owner, image)
    changed = dict(owner, MAX_SOURCE_REPLAY_SOURCES=1)
    warm_changed = measure(changed, image)
    compact._VALIDATED_CAPTURES.clear()
    cold_changed = measure(changed, image)
    if cold['outcome'] != {'status': 'accepted'} or warm['outcome'] != cold['outcome']:
        raise AssertionError('ordinary compact admission failed')
    if cold_changed['outcome']['status'] != 'refused':
        raise AssertionError('ineffective current-capacity control')
    return {'cold': cold, 'warm': warm, 'warm_changed': warm_changed,
            'cold_changed': cold_changed,
            'equivalent_after_change': warm_changed['outcome'] == cold_changed['outcome']}


def run(case):
    sources = base.provision(case)
    before = case.inert_before()
    base.emit('actual_legacy_capture_started')
    legacy = case.capture()
    owner = vars(case.lib)
    case.assert_inert(before)
    counts = {run['source_id']: len(run['events']) for run in legacy['source_returns']['runs']}
    for source in sources:
        if counts[source['source_id']] != source['requested_events']:
            raise AssertionError('incomplete synthetic collector roster')
    base.save('legacy-batch.json', batches.native_bytes(owner, legacy))
    request = checkpoint_request(owner, legacy)
    base.emit('bootstrap_episodes_started', counts=counts)
    started = time.monotonic_ns()
    parent = checkpoints.bootstrap_episodes(owner, request=request,
        expected_request_sha256=batches.native_sha(owner, request))
    bootstrap_ns = time.monotonic_ns() - started
    base.save('parent-checkpoint.json', batches.native_bytes(owner, parent))
    if parent['intake'] != legacy['intake_projection']['intake']:
        raise AssertionError('bootstrap intake mismatch')
    base.emit('synthetic_empty_next_started', bootstrap_ns=bootstrap_ns)
    image = synthetic_next(owner, legacy, parent)
    raw = batches.native_bytes(owner, image)
    artifact = base.save('compact-image.json', raw)
    case.assert_inert(before)
    compact._VALIDATED_CAPTURES.clear()
    base.emit('public_compact_comparison_started', image=artifact)
    measured = compare(owner, image)
    if batches.native_bytes(owner, image) != raw or compact._VALIDATED_CAPTURES:
        raise AssertionError('input or memo mutation')
    case.assert_inert(before)
    report = {'status': 'TESTED_PASS' if measured['equivalent_after_change'] else 'FAILED_STALE_ADMISSION',
              'image': artifact, 'bootstrap_ns': bootstrap_ns, 'measurements': measured,
              'parent_event_count': len(parent['episode_records']), 'current_event_count': 0,
              'scope': 'Actual private collector predecessor; synthetic empty next-entry image. '
                       'Zero predecessor/root pins are fixture data, not witnessed authority. '
                       'No root capture, idle/delivery processing, publication, original historical '
                       'workload reconstruction, maximum load, WCET or useful cache is established. '
                       'Individual timings are observations, not bounds; endpoint maps are not loaded-code custody.'}
    receipt = base.save('compact-comparison.json', (json.dumps(report, indent=2) + '\n').encode())
    base.emit('completed', result=receipt, input_sha256=hashlib.sha256(raw).hexdigest())
    if not measured['equivalent_after_change']:
        raise AssertionError('stale compact admission')


def main():
    case = base.ControllerSourceCapture(methodName='runTest')
    try:
        case.setUp()
        run(case)
    finally:
        case.doCleanups()
        batches._VALIDATED_BATCHES.clear()
        compact._VALIDATED_CAPTURES.clear()


if __name__ == '__main__':
    main()

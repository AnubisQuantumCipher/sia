"""Observe selected installed SDK origins under the existing read-only route.

Launch this runner under the existing exclusive heavy lock. No candidate or
worker dispatch, service operations, network calls or installation are requested.
Trusted installed imports and endpoint stability are premises, not custody proof.
"""
import datetime
import hashlib
import json
import os
from pathlib import Path
import resource
import shutil
import subprocess
import time

OUT = Path(__file__).resolve().parent
FIELDS = ('st_dev', 'st_ino', 'st_mode', 'st_nlink', 'st_uid', 'st_gid',
          'st_size', 'st_mtime_ns', 'st_ctime_ns')
ENV = {'HOME': str(OUT / 'private/home'), 'TMPDIR': str(OUT / 'private/tmp'),
       'PATH': '/usr/bin:/bin', 'LANG': 'C', 'LC_ALL': 'C', 'TZ': 'UTC',
       'PYTHONDONTWRITEBYTECODE': '1'}


def read_json(path):
    with path.open('rb') as stream:
        raw = stream.read(8388609)
    if len(raw) > 8388608:
        raise ValueError('runner receipt input capacity')
    return json.loads(raw)


def row(path):
    before = path.stat()
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    after = path.stat()
    if before != after:
        raise ValueError('runner endpoint changed while hashing')
    return {'identity': {name: getattr(after, name) for name in FIELDS}, 'sha256': digest}


def write_json(name, value):
    with (OUT / name).open('x') as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write('\n')


def check_inputs():
    preparation = read_json(OUT / 'preparation.json')
    expected = dict(preparation['references'])
    expected.update({str(OUT / name): pin for name, pin in preparation['prepared'].items()})
    for name, pin in expected.items():
        if row(Path(name)) != pin:
            raise ValueError('prospective source or predecessor changed: ' + name)
    expected.update({str(path): row(path) for path in (
        Path(__file__), Path('/usr/bin/python3.14'), Path('/usr/bin/prlimit'),
        OUT / 'preparation.json', OUT / 'static-repaired-result.json')})
    static = read_json(OUT / 'static-repaired-result.json')
    if not static['expected_only']:
        raise ValueError('prospective static diagnostics not admitted')
    for name, digest in static['sources'].items():
        if row(Path(name))['sha256'] != digest:
            raise ValueError('analyzed source changed')
    return expected


def child_run(label, command):
    started = time.monotonic_ns()
    with (OUT / (label + '.stdout')).open('xb') as stdout:
        with (OUT / (label + '.stderr')).open('xb') as stderr:
            child = subprocess.Popen(command, env=ENV, cwd=OUT / 'private',
                                     stdout=stdout, stderr=stderr)
            try:
                write_json(label + '-process.json', {'pid': child.pid, 'owner_pid': os.getpid(),
                           'started_ns': started, 'command': command})
            finally:
                code = child.wait()
    return {'exit': code, 'elapsed_ns': time.monotonic_ns() - started,
            'stdout': row(OUT / (label + '.stdout')), 'stderr': row(OUT / (label + '.stderr'))}


def main():
    os.umask(0o077)
    before = check_inputs()
    prefix = ['/usr/bin/prlimit', '--core=0', '--', '/usr/bin/python3', '-I', '-B', '-Werror']
    record = {'schema': 'sia.sdk-v8-installed-origin-observation.v1',
              'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'before': before, 'environment': ENV, 'cwd': str(OUT / 'private'),
              'uid': os.getuid(), 'gid': os.getgid(), 'groups': os.getgroups(),
              'available_bytes': shutil.disk_usage(OUT).free,
              'uname': list(os.uname()), 'boot_id': Path('/proc/sys/kernel/random/boot_id').read_text().strip(),
              'inherited_AS': resource.getrlimit(resource.RLIMIT_AS),
              'inherited_FSIZE': resource.getrlimit(resource.RLIMIT_FSIZE),
              'acceptance': False, 'runtime_admission': False,
              'premises': ['Trusted installed interpreter/loader/provider imports',
                           'Sequential endpoint checks are not continuous custody',
                           'Approved exact BLE001 exception remains a raw NONPASS',
                           'Internal source bounds/deadlines retained; no outer engineering caps']}
    write_json('admission.json', record)
    preflight = child_run('preflight', prefix + [str(OUT / 'preflight.py')])
    write_json('preflight-result.json', preflight)
    if preflight['exit'] != 0:
        write_json('result.json', dict(record, status='PREFLIGHT_FAILED', preflight=preflight))
        return 1
    if read_json(OUT / 'preflight.stdout')['status'] != 'OBSERVED_ENDPOINT_MATCH':
        raise ValueError('preflight returned no endpoint match')
    begin = time.monotonic_ns()
    work, total = begin + 120000000000, begin + 125000000000
    command = prefix + [str(OUT / 'origin_probe.py'), str(work), str(total)]
    write_json('observation-admission.json', {'begin_ns': begin, 'work_ns': work,
               'total_ns': total, 'command': command})
    result = child_run('observation', command)
    after = {name: row(Path(name)) for name in before}
    record.update(status='OBSERVED' if result['exit'] == 0 else 'OBSERVATION_FAILED',
                  preflight=preflight, observation=result, after=after,
                  unchanged=before == after, max_rss_kib=resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss)
    if not record['unchanged']:
        record['status'] = 'SOURCE_BINDING_CHANGED'
    write_json('result.json', record)
    print(json.dumps({key: record[key] for key in ('status', 'unchanged', 'max_rss_kib')}))
    return result['exit'] if record['unchanged'] else 1


if __name__ == '__main__':
    raise SystemExit(main())

"""Read-only current SDK endpoint check; never grants runtime admission."""

import hashlib
import json
import os
from pathlib import Path
import stat
import sys
import time


ROOT = Path('/home/sicarii/Work/sia-assurance-evidence-20261019/ownership-transfer-20261024/sdk-origin-observation-v8-v1')
FIELDS = ('st_dev', 'st_ino', 'st_mode', 'st_nlink', 'st_uid', 'st_gid',
          'st_size', 'st_mtime_ns', 'st_ctime_ns')
COHORT_SHA = '42b76728dbedb47bc5444eec4a783ea7eb8c8cf32f3ed60f50ad9a424fe1ac2c'


def identity(value):
    return {field: getattr(value, field) for field in FIELDS}


def tick(state):
    if time.monotonic_ns() >= state['deadline']:
        raise TimeoutError('preflight deadline')


def file_read(state, path, limit, retain=False):
    """Fixed chunk/byte bounds, regular/no-follow endpoint, stable full identity."""
    tick(state)
    before = os.lstat(path)
    if not stat.S_ISREG(before.st_mode) or not 0 <= before.st_size <= limit:
        raise ValueError('preflight regular file/size: ' + str(path))
    digest, data, total = hashlib.sha256(), bytearray(), 0
    number = os.open(path, os.O_RDONLY | os.O_CLOEXEC | os.O_NOFOLLOW | os.O_NONBLOCK)
    try:
        if identity(os.fstat(number)) != identity(before):
            raise ValueError('preflight opened identity changed')
        for _ in range(limit // 65536 + 1):
            tick(state)
            block = os.read(number, min(65536, limit - total + 1))
            if not block:
                break
            total += len(block)
            state['bytes_read'] += len(block)
            if total > limit or state['bytes_read'] > 536870912:
                raise ValueError('preflight byte budget')
            digest.update(block)
            if retain:
                data.extend(block)
        else:
            raise ValueError('preflight missing EOF within chunk bound')
        if total != before.st_size or identity(os.fstat(number)) != identity(before):
            raise ValueError('preflight file changed while reading')
    finally:
        os.close(number)
    if identity(os.lstat(path)) != identity(before):
        raise ValueError('preflight path changed after reading')
    return {'identity': identity(before), 'sha256': digest.hexdigest()}, data


def directory_names(state, path):
    names = []
    with os.scandir(path) as entries:
        for index, entry in enumerate(entries):
            tick(state)
            if index >= 8192 or len(entry.name) > 4096:
                raise ValueError('preflight directory bound')
            names.append(entry.name)
    return sorted(names)


def verify_files(state, rows, maximum):
    if type(rows) is not dict or len(rows) > maximum:
        raise ValueError('preflight file roster bound')
    for path, expected in rows.items():
        actual, _ = file_read(state, path, 67108864)
        if actual != expected:
            raise ValueError('preflight file mismatch: ' + path)
        state['files_checked'] += 1


def verify_directories(state, rows):
    if type(rows) is not dict or len(rows) > 4096:
        raise ValueError('preflight directory roster bound')
    for path, expected in rows.items():
        tick(state)
        before = os.lstat(path)
        if not stat.S_ISDIR(before.st_mode) or identity(before) != expected['identity']:
            raise ValueError('preflight directory identity: ' + path)
        if 'names' in expected and directory_names(state, path) != expected['names']:
            raise ValueError('preflight directory names: ' + path)
        if identity(os.lstat(path)) != identity(before):
            raise ValueError('preflight directory changed: ' + path)
        state['directories_checked'] += 1


def verify_aliases(state, rows):
    if type(rows) is not dict or len(rows) > 8192:
        raise ValueError('preflight alias roster bound')
    for path, expected in rows.items():
        tick(state)
        before = os.lstat(path)
        actual = {'identity': identity(before), 'link': os.readlink(path),
                  'resolved': os.path.realpath(path)}
        if actual != expected or identity(os.lstat(path)) != identity(before):
            raise ValueError('preflight alias mismatch: ' + path)
        state['aliases_checked'] += 1


def verify_negative(state, rows):
    if type(rows) is not dict or len(rows) > 8192:
        raise ValueError('preflight negative roster bound')
    for path, expected in rows.items():
        tick(state)
        if expected == {'state': 'ENOENT'}:
            try:
                os.lstat(path)
            except FileNotFoundError:
                pass
            else:
                raise ValueError('preflight negative path exists: ' + path)
        else:
            if expected['predicate'] != '*.pth or sitecustomize*/usercustomize*':
                raise ValueError('preflight unknown negative predicate')
            names = directory_names(state, expected['directory'])
            special = [n for n in names if n.endswith('.pth')
                       or n.startswith(('sitecustomize', 'usercustomize'))]
            if special != expected['names']:
                raise ValueError('preflight startup customization changed')
        state['negative_checked'] += 1


def check(state):
    row, data = file_read(state, ROOT / 'SELECTED-COHORTS.json', 8388608, True)
    if row['sha256'] != COHORT_SHA:
        raise ValueError('preflight cohort source changed')
    cohort = json.loads(data)
    if cohort['errors']:
        raise ValueError('preflight cohort contains unresolved errors')
    verify_files(state, cohort['files'], 8192)
    verify_files(state, cohort['launcher_tools'], 16)
    verify_files(state, {str(ROOT / 'origin_probe.py'): cohort['probe_source']}, 1)
    verify_directories(state, cohort['directories'])
    verify_aliases(state, cohort['aliases'])
    verify_negative(state, cohort['negative_lookup'])
    tick(state)
    return {'status': 'OBSERVED_ENDPOINT_MATCH', 'authority': 'NONE',
            'scope': 'Current file bytes/full9, directory identities and supplied name lists, '
                     'aliases and negative lookups. '
                     'Not atomic custody, loaded ABI, runtime admission or full source review.',
            'cohort_sha256': row['sha256'], 'observations': state}


def main():
    state = {'deadline': time.monotonic_ns() + 30000000000, 'bytes_read': 0,
             'files_checked': 0, 'directories_checked': 0, 'aliases_checked': 0,
             'negative_checked': 0}
    try:
        result = check(state)
    except (OSError, ValueError, TypeError, KeyError) as error:
        print(json.dumps({'status': 'FAILED', 'authority': 'NONE',
                          'error': str(error), 'observations': state}))
        return 1
    print(json.dumps(result))
    return 0


if __name__ == '__main__':
    sys.exit(main())

"""Atime-only reads must not conceal real source identity changes."""
import importlib.util
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parent


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class EndpointIdentityTests(unittest.TestCase):
    def setUp(self):
        self.storage = tempfile.TemporaryDirectory()
        self.addCleanup(self.storage.cleanup)
        self.path = Path(self.storage.name) / 'output'
        self.path.write_bytes(b'receipt\n')
        self.original = load('original', ROOT.parent / 'sdk-origin-observation-v8-v1/run.py')
        self.runner = load('repaired', ROOT / 'run.py')
        self.preparer = load('prepare', ROOT / 'prepare.py')

    def observations(self, changed=None):
        first = {name: getattr(self.path.stat(), name) for name in self.runner.FIELDS}
        first['st_atime_ns'] = 1
        second = dict(first, st_atime_ns=2)
        if changed is not None:
            second[changed] += 1
        return [SimpleNamespace(**first), SimpleNamespace(**second)]

    def test_original_rejects_atime_only_change(self):
        observations = self.observations()
        with patch.object(Path, 'stat', side_effect=observations):
            with self.assertRaisesRegex(ValueError, 'endpoint changed'):
                self.original.row(self.path)

    def test_repaired_accepts_atime_only_change(self):
        observations = self.observations()
        with patch.object(Path, 'stat', side_effect=observations):
            result = self.runner.row(self.path)
        self.assertEqual(result['identity']['st_size'], len(b'receipt\n'))

    def test_repaired_rejects_each_declared_identity_change(self):
        for field in self.runner.FIELDS:
            with self.subTest(field=field):
                observations = self.observations(field)
                with patch.object(Path, 'stat', side_effect=observations):
                    with self.assertRaisesRegex(ValueError, 'endpoint changed'):
                        self.runner.row(self.path)

    def test_preparer_uses_same_identity_contract(self):
        observations = self.observations()
        with patch.object(Path, 'lstat', side_effect=observations):
            self.preparer.row(self.path)
        for field in self.preparer.FIELDS:
            with self.subTest(field=field):
                observations = self.observations(field)
                with patch.object(Path, 'lstat', side_effect=observations):
                    with self.assertRaisesRegex(ValueError, 'input changed'):
                        self.preparer.row(self.path)


if __name__ == '__main__':
    unittest.main()

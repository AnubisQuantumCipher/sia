"""Package the scoped SDK observation and its failed predecessor reproducibly."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent
REPO = Path('/home/sicarii/Work/sia-assurance-checkpoint-20261023')
CURRENT = ('prepare.py', 'run.py', 'test_endpoint_identity.py', 'origin_probe.py',
           'preflight.py', 'SELECTED-COHORTS.json', 'preparation.json',
           'probe.diff', 'preflight.diff', 'preparation-static.json',
           'static-repaired-result.json', 'controls-result.json',
           'controls.stdout', 'controls.stderr', 'admission.json',
           'preflight-process.json', 'preflight-result.json',
           'preflight.stdout', 'preflight.stderr', 'observation-admission.json',
           'observation-process.json', 'observation.stdout', 'observation.stderr',
           'result.json', 'root-readback.json', 'review.md', 'REPORT.md',
           'build_public.py', 'builder-static.json')
FAILED = ('prepare.py', 'run.py', 'run.initial.py', 'origin_probe.py', 'preflight.py',
          'SELECTED-COHORTS.json', 'preparation.json', 'probe.diff', 'preflight.diff',
          'preparation-static.json', 'static-result.json', 'static-repaired-result.json',
          'exception-binding.stdout', 'exception-binding.stderr', 'admission.json',
          'preflight-process.json', 'preflight.stdout', 'preflight.stderr', 'FAILURE.json')


def read(path):
    with path.open('rb') as stream:
        raw = stream.read(8388609)
    if len(raw) > 8388608:
        raise ValueError('forensic member input bound')
    return raw


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def validated_result():
    result = json.loads(read(OUT / 'result.json'))
    raw = json.loads(read(OUT / 'observation.stdout'))
    check = json.loads(read(OUT / 'root-readback.json'))
    if not result['unchanged'] or result['before'] != result['after']:
        raise ValueError('run endpoints differ')
    for label in ('preflight', 'observation'):
        if result[label]['exit'] != 0:
            raise ValueError('child did not succeed')
        for stream in ('stdout', 'stderr'):
            if digest(read(OUT / (label + '.' + stream))) != result[label][stream]['sha256']:
                raise ValueError('raw output hash mismatch')
    if not all(check['checks'].values()) or raw['acceptance'] or raw['authority'] != 'NONE':
        raise ValueError('readback or authority ceiling mismatch')
    for name, expected in result['after'].items():
        if digest(read(Path(name))) != expected['sha256']:
            raise ValueError('bound source/reference changed')
    return result, check


def payloads():
    members = {'current/' + name: read(OUT / name) for name in CURRENT}
    old = ROOT / 'sdk-origin-observation-v8-v1'
    members.update({'failed/' + name: read(old / name) for name in FAILED})
    members['AUTHORIZATION.md'] = read(ROOT / 'execution-policy-20261025-v1/AUTHORIZATION.md')
    pins = {name: digest(raw) for name, raw in members.items()}
    members['SHA256.json'] = (json.dumps(pins, indent=2, sort_keys=True) + '\n').encode()
    return members


def archive(members):
    target = io.BytesIO()
    with gzip.GzipFile(fileobj=target, mode='wb', filename='', mtime=0) as zipped:
        with tarfile.open(fileobj=zipped, mode='w', format=tarfile.USTAR_FORMAT) as tar:
            for name, raw in sorted(members.items()):
                entry = tarfile.TarInfo(name)
                entry.size, entry.mode = len(raw), 0o644
                tar.addfile(entry, io.BytesIO(raw))
    return target.getvalue()


def main():
    result, check = validated_result()
    members = payloads()
    raw = archive(members)
    if archive(members) != raw:
        raise ValueError('archive reproduction failed')
    relative = 'docs/evidence/sdk-installed-observation-20261025.tar.gz'
    report = {'schema': 'sia.selected-installed-sdk-evidence.v1',
              'status': check['status'], 'authority': 'NONE',
              'source_sha256': result['before'][str(OUT / 'origin_probe.py')]['sha256'],
              'preflight': result['preflight'], 'observation': result['observation'],
              'modules': check['modules'], 'mapped_origins': check['regular_mapped_origins'],
              'unchanged': result['unchanged'], 'runtime_admission': False,
              'whole_system_acceptance': False, 'historical_failure_retained': True,
              'archive': {'path': relative, 'sha256': digest(raw), 'bytes': len(raw),
                          'members': len(members), 'reproduced': True}}
    with (REPO / relative).open('xb') as stream:
        stream.write(raw)
    with (REPO / 'docs/SDK-INSTALLED-OBSERVATION-20261025.json').open('x') as stream:
        json.dump(report, stream, indent=2, sort_keys=True)
        stream.write('\n')
    with (REPO / 'docs/SDK-INSTALLED-OBSERVATION-20261025.md').open('xb') as stream:
        stream.write(read(OUT / 'REPORT.md'))
    print(json.dumps({'status': check['status'], 'archive': report['archive']}))


if __name__ == '__main__':
    main()

"""Rebind only the qualified probe's input root; retain original evidence."""
import difflib
import hashlib
import json
import os
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent
OLD = ROOT.parent / 'takeover-selected-sdk-derived-origin-source-v7'
WORK = ROOT / 'sdk-loop-finally-v8'
FIELDS = ('st_dev', 'st_ino', 'st_mode', 'st_nlink', 'st_uid', 'st_gid',
          'st_size', 'st_mtime_ns', 'st_ctime_ns')


def read(path):
    with path.open('rb') as stream:
        raw = stream.read(8388609)
    if len(raw) > 8388608:
        raise ValueError('preparation input capacity')
    return raw


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def row(path):
    before = path.lstat()
    raw = read(path)
    after = path.lstat()
    if (any(getattr(before, key) != getattr(after, key) for key in FIELDS)
            or len(raw) != before.st_size):
        raise ValueError('preparation input changed')
    return {'identity': {name: getattr(after, name) for name in FIELDS},
            'sha256': sha(raw)}


def write(name, raw):
    with (OUT / name).open('xb') as stream:
        if stream.write(raw) != len(raw):
            raise OSError('incomplete preparation write')


def write_json(name, value):
    write(name, (json.dumps(value, indent=2, sort_keys=True) + '\n').encode())


def replace_once(raw, before, after):
    if raw.count(before) != 1 or after in raw:
        raise ValueError('replacement is not unique')
    changed = raw.replace(before, after)
    if changed.replace(after, before) != raw:
        raise ValueError('inverse delta did not reproduce original')
    return changed


def check_predecessors():
    run_path = ROOT / 'sdk-full-resource-policy-20261025-v1/result.json'
    run = json.loads(read(run_path))
    if run['exit'] != 0 or not run['unchanged']:
        raise ValueError('complete fixture evidence missing')
    original = read(WORK / 'origin_probe.py')
    if sha(original) != run['before']['source']['origin_probe.py']:
        raise ValueError('probe differs from complete tested source')
    binding = ROOT / 'sdk-exception-reconciliation-v8-v1/binding.json'
    files = json.loads(read(binding))['files']
    if len(files) != 32:
        raise ValueError('approved exception binding inventory changed')
    for entry in files:
        if sha(read(Path(entry['path']))) != entry['sha256']:
            raise ValueError('approved exception evidence changed')
    cohort_raw = read(OLD / 'SELECTED-COHORTS.json')
    prior = json.loads(read(ROOT / 'sdk-origin-observation-v7-v1/admission.json'))
    if sha(cohort_raw) != prior['cohort']['cohort_sha256']:
        raise ValueError('historical dependency cohort changed')
    return original, cohort_raw, [run_path, binding, OLD / 'SELECTED-COHORTS.json']


def main():
    os.umask(0o077)
    original, cohort_raw, references = check_predecessors()
    old_line = b"OUT = BASE + 'takeover-selected-sdk-derived-origin-source-v7/'"
    new_line = ('OUT = ' + repr(str(OUT) + '/')).encode()
    changed = replace_once(original, old_line, new_line)
    write('origin_probe.py', changed)
    (OUT / 'origin_probe.py').chmod(0o400)
    cohort = json.loads(cohort_raw)
    old_probe = cohort['probe_source']
    cohort['probe_source'] = row(OUT / 'origin_probe.py')
    write_json('SELECTED-COHORTS.json', cohort)
    (OUT / 'SELECTED-COHORTS.json').chmod(0o400)
    original_preflight = ROOT / 'sdk-current-cohort-preflight-v1/preflight.py'
    preflight = read(original_preflight)
    old_root = ("ROOT = Path('/home/sicarii/Work/sia-assurance-evidence-20261019/'\n"
                "            'takeover-selected-sdk-derived-origin-source-v7')").encode()
    revised = replace_once(preflight, old_root, ('ROOT = Path(' + repr(str(OUT)) + ')').encode())
    revised = replace_once(revised, sha(cohort_raw).encode(),
                           sha(read(OUT / 'SELECTED-COHORTS.json')).encode())
    write('preflight.py', revised)
    (OUT / 'preflight.py').chmod(0o400)
    for name in ('private', 'private/home', 'private/tmp'):
        (OUT / name).mkdir(mode=0o700)
    for name, old, new in [('probe', original, changed), ('preflight', preflight, revised)]:
        delta = ''.join(difflib.unified_diff(old.decode().splitlines(True),
                       new.decode().splitlines(True), fromfile=name + '-original',
                       tofile=name + '-prospective'))
        write(name + '.diff', delta.encode())
    restored = dict(cohort)
    restored['probe_source'] = old_probe
    if restored != json.loads(cohort_raw):
        raise ValueError('dependency cohort changed beyond probe identity')
    references += [WORK / 'origin_probe.py', original_preflight, Path(__file__)]
    write_json('preparation.json', {
        'schema': 'sia.sdk-prospective-output-rebind.v1', 'acceptance': False,
        'probe_delta': 'Only OUT constant; inverse bytes exactly qualified v8',
        'cohort_delta': 'Only probe_source identity and digest; installed pins unchanged',
        'preflight_delta': 'Only ROOT and cohort digest; original algorithm unchanged',
        'references': {str(path): row(path) for path in references},
        'prepared': {name: row(OUT / name) for name in
                     ('origin_probe.py', 'SELECTED-COHORTS.json', 'preflight.py')},
        'limitations': 'Source correspondence only; current endpoint and actual observation UNRUN'})
    print(json.dumps({'status': 'PREPARED_ONLY', 'probe_sha256': sha(changed)}))


if __name__ == '__main__':
    main()

"""Prospective installed SDK origin observation only; never candidate imports."""
import hashlib
import json
import os
import stat
import types

# BEGIN EXACT PRODUCTION CHECKER BLOCK
# Bounded producer-derived relationship checker; source only, nonauthorizing.
import sys
import time

__doc__ = 'Bounded producer-derived relationship checker; source only, nonauthorizing.'

DERIVED_SO = '/usr/lib/python3.14/lib-dynload/pyexpat.cpython-314-aarch64-linux-gnu.so'
DERIVED_PY = '/usr/lib/python3.14/xml/parsers/expat.py'
DERIVED_PYC = '/usr/lib/python3.14/xml/parsers/__pycache__/expat.cpython-314.pyc'
DERIVED_SPEC_KEYS = ('name', 'loader', 'origin', 'loader_state',
                     'submodule_search_locations', '_uninitialized_submodules',
                     '_set_fileattr', '_cached', '_initializing')
DERIVED_EXPORTS = (('ModuleSpec', 'ModuleSpec'), ('FrozenImporter', 'FrozenImporter'))
DERIVED_EXTERNAL = (('FileLoader', 'FileLoader'), ('SourceLoader', 'SourceLoader'),
                    ('LoaderBasics', '_LoaderBasics'),
                    ('SourceFileLoader', 'SourceFileLoader'),
                    ('ExtensionFileLoader', 'ExtensionFileLoader'))


def new_reference_array(bound):
    return [None] * bound


def new_derived_refs():
    return DerivedRefs()


def new_roster_row():
    return {'name': None, 'origin': None, '_module': None, '_checked': False}


def retire_reference_cell(sequence, index):
    if type(sequence) is list:
        sequence[index] = None
    else:
        list.__setitem__(sequence, index, None)


def retire_reference_array(sequence, guard):
    """Attempt every fixed slot, resuming after a recorded cell failure.

    Successful fixed-guard entry/exit is inert. Each attempted retirement
    records its loop index in finally; cell errors never retry or skip a later cell.
    This does not qualify asynchronous interruption between those statements.
    """
    last_index = -1
    for _attempt in range(8192):
        with guard:
            index = last_index
            try:
                for index in range(last_index + 1, 8192):
                    retire_reference_cell(sequence, index)
            finally:
                last_index = index
        if last_index == 8191:
            return
    with guard:
        raise RuntimeError('derived scratch sweep incomplete')


def retire_owned_attribute(value, field):
    object.__setattr__(value, field, None)


def retire_roster_module(row):
    if '_module' in row:
        dict.__setitem__(row, '_module', None)


class DerivedRefs:
    """Exactly32 persistent identity fields, no dynamic namespace."""

    __slots__ = ('sys_actual', 'type_intrinsic', 'member_get_intrinsic',
                 'dict_intrinsic', 'module_type', 'getset_descriptor_type',
                 'mappingproxy_type', 'module_namespace_descriptor',
                 'type_namespace_descriptor', 'type_bases_descriptor',
                 'getset_get_intrinsic', 'object_getattribute_intrinsic',
                 'bootstrap_module', 'external_module', 'ModuleSpec',
                 'FileLoader', 'SourceLoader', 'LoaderBasics', 'SourceFileLoader',
                 'ExtensionFileLoader', 'FrozenImporter', 'spec_namespace_descriptor',
                 'fileloader_namespace_descriptor', 'P', 'W', 'E', 'M',
                 'S_P', 'S_W', 'L_P', 'L_W', 'modules_dict')

    def __init__(self):
        for field in DerivedRefs.__slots__:
            object.__setattr__(self, field, None)


class DerivedClearGuard:
    """Fixed cleanup phase; retain actual errors before independent attempts."""

    __slots__ = ('state', 'phase')

    def __init__(self, state, phase):
        self.state, self.phase = state, phase

    def __enter__(self):
        return self

    def __exit__(self, kind, error, traceback):
        if error is not None:
            state = self.state
            if state.used < 64:
                state.raw[state.used], state.phases[state.used] = error, self.phase
                state.used += 1
            else:
                state.overflow = True
        return error is not None


class DerivedChecker:
    """One scratch and bounded strong roster; no filesystem or provider imports."""

    __slots__ = ('state', 'refs', 'keys', 'values', 'count', 'pair',
                 'current_key', 'current_value', 'rows', 'row_count',
                 'scratch_guard', 'row_guard', 'refs_guard', 'prepare_guard')

    def __init__(self, state, preparation_guard=None):
        self.state = state
        self.refs, self.keys, self.values, self.rows = None, None, None, None
        self.count, self.row_count = 0, 0
        self.pair, self.current_key, self.current_value = None, None, None
        self.scratch_guard, self.row_guard, self.refs_guard = None, None, None
        self.prepare_guard = preparation_guard
        if self.prepare_guard is None:
            self.prepare_guard = DerivedClearGuard(state, 'checker-prepare')
        initial = state.used
        with self.prepare_guard:
            self.scratch_guard = DerivedClearGuard(state, 'scratch-clear')
            self.row_guard = DerivedClearGuard(state, 'roster-reference-clear')
            self.refs_guard = DerivedClearGuard(state, 'selected-reference-clear')
            self.refs = new_derived_refs()
            self.keys = new_reference_array(8192)
            self.values = new_reference_array(8192)
            self.rows = new_reference_array(8192)
            for index in range(8192):
                self.rows[index] = new_roster_row()
            self.seed_intrinsics()
        if state.used != initial or state.overflow:
            raise state.failure

    def seed_intrinsics(self):
        """Trusted interpreter capsule, NOT inference from candidate namespaces."""
        refs = self.refs
        refs.sys_actual, refs.type_intrinsic = sys, type
        refs.dict_intrinsic, refs.module_type = dict, type(sys)
        refs.module_namespace_descriptor = type(sys).__dict__['__dict__']
        refs.type_namespace_descriptor = type.__dict__['__dict__']
        refs.type_bases_descriptor = type.__dict__['__bases__']
        refs.getset_descriptor_type = type(refs.type_namespace_descriptor)
        refs.mappingproxy_type = type(type.__dict__)
        refs.getset_get_intrinsic = refs.getset_descriptor_type.__dict__['__get__']
        member_kind = type(refs.module_namespace_descriptor)
        refs.member_get_intrinsic = member_kind.__dict__['__get__']
        refs.object_getattribute_intrinsic = object.__getattribute__
        # These native seeds are the explicit trusted installed-interpreter premise.
        # Mutable exports/tautological type checks do not independently attest them.

    def tick(self, stage=None):
        if stage is not None:
            self.state.stage = stage
        if time.monotonic_ns() >= self.state.work:
            raise TimeoutError('derived original work deadline')

    def text(self, value, points=256, byte_limit=1024, empty=True):
        if type(value) is not str or len(value) > points or (not empty and not value):
            raise ValueError('derived exact text prelength')
        self.tick()
        size = len(value)
        if size > (536870912 - self.state.read_bytes) // 4:
            raise ValueError('derived aggregate text budget')
        self.state.read_bytes += 4 * size
        encoded = 0
        for start in range(0, size, 1024):
            self.tick()
            chunk = value[start:start + 1024].encode('utf-8', 'strict')
            encoded += len(chunk)
            if encoded > byte_limit:
                raise ValueError('derived UTF8 byte bound')
            self.tick()
        return value

    def same_text(self, value, expected, points=256, byte_limit=1024):
        self.text(value, points, byte_limit)
        self.text(expected, points, byte_limit)
        self.tick()
        mismatch = value != expected
        self.tick()
        if mismatch:
            raise ValueError('derived exact text mismatch')

    def clear_scratch(self):
        guard = self.scratch_guard if self.scratch_guard is not None else self.prepare_guard
        for field in ('pair', 'current_key', 'current_value'):
            with guard:
                retire_owned_attribute(self, field)
        if self.keys is not None:
            retire_reference_array(self.keys, guard)
        if self.values is not None:
            retire_reference_array(self.values, guard)
        self.count = 0

    def snapshot(self, namespace, bound=8192):
        initial = self.state.used
        self.clear_scratch()
        if self.state.used != initial or self.state.overflow:
            raise self.state.failure
        previous_stage = self.state.stage
        self.tick('KEYS')
        if type(bound) is not int or not 0 <= bound <= 8192:
            raise ValueError('derived exact namespace limit')
        kind = type(namespace)
        if kind is not dict and kind is not self.refs.mappingproxy_type:
            raise ValueError('derived native namespace type')
        length = len(namespace)
        if length > bound:
            raise ValueError('derived namespace count bound')
        iterator = iter(namespace.items())
        try:
            for _ in range(8193):
                self.tick()
                self.pair = next(iterator, None)
                self.tick()
                if self.pair is None:
                    break
                if type(self.pair) is not tuple or len(self.pair) != 2:
                    raise ValueError('derived native pair shape')
                if self.count >= bound:
                    raise ValueError('derived namespace excess before capture')
                self.current_key, self.current_value = self.pair
                self.keys[self.count] = self.current_key
                self.values[self.count] = self.current_value
                self.count += 1
                self.pair, self.current_key, self.current_value = None, None, None
            else:
                raise ValueError('derived native iterator missing EOF')
            if len(namespace) != length or self.count != length:
                raise ValueError('derived namespace changed during capture')
            for index in range(self.count):
                key = self.text(self.keys[index], empty=False)
                if '\x00' in key:
                    raise ValueError('derived key NUL')
        finally:
            self.pair, self.current_key, self.current_value = None, None, None
            iterator = None
        self.state.stage = previous_stage

    def field(self, name, required=True):
        """ONLY owned paired arrays; never reindex a foreign namespace."""
        self.text(name)
        found, value = False, None
        for index in range(self.count):
            self.tick()
            key = self.text(self.keys[index], empty=False)
            self.text(name)
            if key == name:
                if found:
                    raise ValueError('derived duplicate field')
                found, value = True, self.values[index]
        if required and not found:
            raise ValueError('derived missing required field')
        return found, value

    def required(self, name):
        return self.field(name)[1]

    def remember(self, field, value, recheck):
        if recheck:
            if object.__getattribute__(self.refs, field) is not value:
                raise ValueError('derived selected first identity changed')
        else:
            object.__setattr__(self.refs, field, value)
        return value

    def native(self, role, descriptor, receiver, owner, name):
        refs = self.refs
        if role == 'MODULE_NAMESPACE':
            expected_kind = type(refs.module_namespace_descriptor)
            operation = refs.member_get_intrinsic
            if type(receiver) is not refs.module_type:
                raise ValueError('derived exact module receiver')
        else:
            expected_kind = refs.getset_descriptor_type
            operation = refs.getset_get_intrinsic
            if role in ('TYPE_NAMESPACE', 'TYPE_BASES'):
                if type(receiver) is not refs.type_intrinsic:
                    raise ValueError('derived exact class receiver')
            elif role == 'SPEC_NAMESPACE':
                if type(receiver) is not refs.ModuleSpec:
                    raise ValueError('derived exact spec receiver')
            elif role == 'LOADER_NAMESPACE':
                if (type(receiver) is not refs.SourceFileLoader
                        and type(receiver) is not refs.ExtensionFileLoader):
                    raise ValueError('derived exact loader receiver')
            else:
                raise ValueError('derived fixed native role')
        if type(descriptor) is not expected_kind:
            raise ValueError('derived native descriptor kind')
        get = refs.object_getattribute_intrinsic
        self.tick()
        actual_owner = get(descriptor, '__objclass__')
        self.tick()
        if actual_owner is not owner:
            raise ValueError('derived native descriptor owner')
        self.tick()
        actual_name = get(descriptor, '__name__')
        self.tick()
        self.same_text(actual_name, name)
        self.tick()
        result = operation(descriptor, receiver, type(receiver))
        self.tick()
        expected = dict
        if role == 'TYPE_NAMESPACE':
            expected = refs.mappingproxy_type
        elif role == 'TYPE_BASES':
            expected = tuple
        if type(result) is not expected:
            raise ValueError('derived native descriptor output')
        self.tick()
        return result

    def module_namespace(self, module):
        return self.native('MODULE_NAMESPACE', self.refs.module_namespace_descriptor,
                           module, self.refs.module_type, '__dict__')

    def class_namespace(self, value):
        return self.native('TYPE_NAMESPACE', self.refs.type_namespace_descriptor,
                           value, self.refs.type_intrinsic, '__dict__')

    def bases(self, value):
        return self.native('TYPE_BASES', self.refs.type_bases_descriptor,
                           value, self.refs.type_intrinsic, '__bases__')

    def module_descriptor_export(self):
        self.snapshot(self.class_namespace(self.refs.module_type), 256)
        if self.required('__dict__') is not self.refs.module_namespace_descriptor:
            raise ValueError('derived intrinsic module descriptor export')

    def bind_actual_sys(self, recheck=False):
        self.module_descriptor_export()
        self.snapshot(self.module_namespace(self.refs.sys_actual))
        modules = self.required('modules')
        self.bind_modules(modules, recheck)

    def bind_modules(self, modules, recheck=False):
        if type(modules) is not dict:
            raise ValueError('derived modules exact dict')
        first = self.refs.modules_dict
        if first is None and not recheck:
            self.refs.modules_dict = modules
        elif first is not modules:
            raise ValueError('derived actual sys modules first identity changed')

    def capture_exports(self, provider, exports, recheck):
        self.snapshot(self.module_namespace(provider))
        for field, export in exports:
            candidate = self.required(export)
            if type(candidate) is not self.refs.type_intrinsic:
                raise ValueError('derived exact anchor metaclass')
            self.remember(field, candidate, recheck)

    def checked_descriptor(self, cls, field, recheck):
        self.snapshot(self.class_namespace(cls), 256)
        descriptor = self.required('__dict__')
        if type(descriptor) is not self.refs.getset_descriptor_type:
            raise ValueError('derived heap dictionary descriptor kind')
        get = self.refs.object_getattribute_intrinsic
        self.tick()
        actual_owner = get(descriptor, '__objclass__')
        self.tick()
        if actual_owner is not cls:
            raise ValueError('derived heap dictionary descriptor owner')
        self.tick()
        actual_name = get(descriptor, '__name__')
        self.tick()
        self.same_text(actual_name, '__dict__')
        self.remember(field, descriptor, recheck)

    def base_one(self, anchor, expected):
        actual = self.bases(anchor)
        if len(actual) != 1 or actual[0] is not expected:
            raise ValueError('derived exact single base identity')

    def base_two(self, anchor, first, second):
        actual = self.bases(anchor)
        if len(actual) != 2 or actual[0] is not first or actual[1] is not second:
            raise ValueError('derived exact double base identity')

    def intrinsic_distinct(self, anchor, canonical):
        refs = self.refs
        if (anchor is refs.type_intrinsic or anchor is canonical
                or anchor is refs.module_type or anchor is refs.getset_descriptor_type
                or anchor is refs.mappingproxy_type):
            raise ValueError('derived anchor intrinsic collision')

    def anchor_distinct(self):
        r = self.refs
        if (r.ModuleSpec is r.FileLoader or r.ModuleSpec is r.SourceLoader
                or r.ModuleSpec is r.LoaderBasics or r.ModuleSpec is r.SourceFileLoader
                or r.ModuleSpec is r.ExtensionFileLoader or r.ModuleSpec is r.FrozenImporter
                or r.FileLoader is r.SourceLoader or r.FileLoader is r.LoaderBasics
                or r.FileLoader is r.SourceFileLoader or r.FileLoader is r.ExtensionFileLoader
                or r.FileLoader is r.FrozenImporter or r.SourceLoader is r.LoaderBasics
                or r.SourceLoader is r.SourceFileLoader or r.SourceLoader is r.ExtensionFileLoader
                or r.SourceLoader is r.FrozenImporter or r.LoaderBasics is r.SourceFileLoader
                or r.LoaderBasics is r.ExtensionFileLoader or r.LoaderBasics is r.FrozenImporter
                or r.SourceFileLoader is r.ExtensionFileLoader
                or r.SourceFileLoader is r.FrozenImporter
                or r.ExtensionFileLoader is r.FrozenImporter):
            raise ValueError('derived anchor distinctness')

    def anchor_bases(self):
        refs = self.refs
        actual = self.bases(refs.type_intrinsic)
        if len(actual) != 1 or type(actual[0]) is not type:
            raise ValueError('derived intrinsic object relation')
        canonical = actual[0]
        actual = None
        self.anchor_distinct()
        self.intrinsic_distinct(refs.ModuleSpec, canonical)
        self.intrinsic_distinct(refs.FileLoader, canonical)
        self.intrinsic_distinct(refs.SourceLoader, canonical)
        self.intrinsic_distinct(refs.LoaderBasics, canonical)
        self.intrinsic_distinct(refs.SourceFileLoader, canonical)
        self.intrinsic_distinct(refs.ExtensionFileLoader, canonical)
        self.intrinsic_distinct(refs.FrozenImporter, canonical)
        self.base_one(refs.ModuleSpec, canonical)
        self.base_one(refs.FileLoader, canonical)
        self.base_one(refs.LoaderBasics, canonical)
        self.base_one(refs.FrozenImporter, canonical)
        self.base_one(refs.SourceLoader, refs.LoaderBasics)
        self.base_two(refs.SourceFileLoader, refs.FileLoader, refs.SourceLoader)
        self.base_two(refs.ExtensionFileLoader, refs.FileLoader, refs.LoaderBasics)

    def closed_keys(self, allowed, optional=None):
        expected = len(allowed)
        if optional is None and self.count != expected:
            raise ValueError('derived exact closed key count')
        if optional is not None and self.count not in (expected, expected + 1):
            raise ValueError('derived bootstrap key count')
        for index in range(self.count):
            key, found = self.keys[index], False
            for literal in allowed:
                self.text(key)
                self.text(literal)
                if key == literal:
                    found = True
            if optional is not None:
                self.text(key)
                self.text(optional)
                if key == optional:
                    found = True
            if not found:
                raise ValueError('derived unknown closed key')
        for literal in allowed:
            self.required(literal)

    def spec_namespace(self, spec):
        return self.native('SPEC_NAMESPACE', self.refs.spec_namespace_descriptor,
                           spec, self.refs.ModuleSpec, '__dict__')

    def bootstrap_spec(self, module, canonical):
        self.snapshot(self.module_namespace(module))
        spec = self.required('__spec__')
        self.snapshot(self.spec_namespace(spec))
        self.closed_keys(DERIVED_SPEC_KEYS[:-1], '_initializing')
        self.same_text(self.required('name'), canonical)
        self.same_text(self.required('origin'), 'frozen')
        if self.required('loader') is not self.refs.FrozenImporter:
            raise ValueError('derived bootstrap loader identity')
        if self.required('_cached') is not None or self.required('_set_fileattr') is not False:
            raise ValueError('derived bootstrap cache/location')
        empty = self.required('_uninitialized_submodules')
        if type(empty) is not list or len(empty) != 0:
            raise ValueError('derived bootstrap empty list')
        found, value = self.field('_initializing', False)
        if found and value is not False:
            raise ValueError('derived bootstrap initialization')
        # loader_state/search_locations are required but explicitly OPAQUE_UNUSED.

    def bootstrap(self, recheck):
        refs = self.refs
        self.module_descriptor_export()
        self.snapshot(refs.modules_dict)
        boot = self.remember('bootstrap_module', self.required('_frozen_importlib'), recheck)
        external = self.remember('external_module', self.required('_frozen_importlib_external'), recheck)
        if (self.required('importlib._bootstrap') is not boot
                or self.required('importlib._bootstrap_external') is not external
                or boot is external):
            raise ValueError('derived frozen module alias')
        self.capture_exports(boot, DERIVED_EXPORTS, recheck)
        self.capture_exports(external, DERIVED_EXTERNAL, recheck)
        self.checked_descriptor(refs.ModuleSpec, 'spec_namespace_descriptor', recheck)
        self.checked_descriptor(refs.FileLoader, 'fileloader_namespace_descriptor', recheck)
        self.anchor_bases()
        self.bootstrap_spec(boot, '_frozen_importlib')
        self.bootstrap_spec(external, '_frozen_importlib_external')
        self.snapshot(refs.modules_dict)
        machinery = self.required('importlib.machinery')
        self.snapshot(self.module_namespace(machinery))
        for field in ('ModuleSpec', 'SourceFileLoader', 'ExtensionFileLoader'):
            if self.required(field) is not object.__getattribute__(refs, field):
                raise ValueError('derived machinery export alias')

    def doc(self):
        value = self.required('__doc__')
        if value is not None:
            self.text(value, 65536, 65536)

    def absent(self, name):
        if self.field(name, False)[0]:
            raise ValueError('derived forbidden present field')

    def optional_none(self, name):
        if self.field(name, False)[1] is not None:
            raise ValueError('derived optional None field')

    def role(self, value, name):
        self.snapshot(self.module_namespace(value))
        self.same_text(self.required('__name__'), name)
        self.doc()
        for field in ('__package__', '__loader__', '__spec__'):
            if self.required(field) is not None:
                raise ValueError('derived synthetic required None')
        self.optional_none('__file__')
        self.optional_none('__cached__')
        self.absent('__path__')

    def loader(self, value, cls, canonical, path):
        if type(value) is not cls:
            raise ValueError('derived exact loader type')
        namespace = self.native('LOADER_NAMESPACE', self.refs.fileloader_namespace_descriptor,
                                value, self.refs.FileLoader, '__dict__')
        self.snapshot(namespace)
        self.closed_keys(('name', 'path'))
        self.same_text(self.required('name'), canonical)
        self.same_text(self.required('path'), path, 4096, 4096)

    def file_spec(self, spec, loader, canonical, path, cached):
        self.snapshot(self.spec_namespace(spec))
        self.closed_keys(DERIVED_SPEC_KEYS)
        self.same_text(self.required('name'), canonical)
        self.same_text(self.required('origin'), path, 4096, 4096)
        if self.required('loader') is not loader:
            raise ValueError('derived spec loader identity')
        for field in ('loader_state', 'submodule_search_locations'):
            if self.required(field) is not None:
                raise ValueError('derived spec required None')
        empty = self.required('_uninitialized_submodules')
        if type(empty) is not list or len(empty) != 0:
            raise ValueError('derived spec empty list')
        if (self.required('_set_fileattr') is not True
                or self.required('_initializing') is not False):
            raise ValueError('derived exact spec booleans')
        actual = self.required('_cached')
        if cached is None:
            if actual is not None:
                raise ValueError('derived producer spec cache')
        else:
            self.same_text(actual, cached, 4096, 4096)

    def file_module(self, module, canonical, path, package, cached, recheck):
        self.snapshot(self.module_namespace(module))
        self.same_text(self.required('__name__'), canonical)
        self.same_text(self.required('__package__'), package)
        self.same_text(self.required('__file__'), path, 4096, 4096)
        self.doc()
        self.absent('__path__')
        suffix = 'P' if canonical == 'pyexpat' else 'W'
        spec = self.remember('S_' + suffix, self.required('__spec__'), recheck)
        loader = self.remember('L_' + suffix, self.required('__loader__'), recheck)
        if cached is None:
            self.optional_none('__cached__')
        else:
            self.same_text(self.required('__cached__'), cached, 4096, 4096)
        if self.required('errors') is not self.refs.E or self.required('model') is not self.refs.M:
            raise ValueError('derived module role exports')
        if suffix == 'W' and self.required('sys') is not self.refs.sys_actual:
            raise ValueError('derived wrapper actual sys export')
        cls = self.refs.ExtensionFileLoader if suffix == 'P' else self.refs.SourceFileLoader
        self.loader(loader, cls, canonical, path)
        self.file_spec(spec, loader, canonical, path, cached)

    def graph(self, recheck=False):
        self.tick('RECHECK' if recheck else 'ANCHORS')
        self.bind_actual_sys(recheck=self.refs.modules_dict is not None)
        self.bootstrap(recheck)
        self.snapshot(self.refs.modules_dict)
        for field, key in (('P', 'pyexpat'), ('W', 'xml.parsers.expat'),
                           ('E', 'pyexpat.errors'), ('M', 'pyexpat.model')):
            self.remember(field, self.required(key), recheck)
        if (self.required('xml.parsers.expat.errors') is not self.refs.E
                or self.required('xml.parsers.expat.model') is not self.refs.M):
            raise ValueError('derived wrapper child aliases')
        allowed = ('pyexpat.errors', 'pyexpat.model',
                   'xml.parsers.expat.errors', 'xml.parsers.expat.model')
        for index in range(self.count):
            name = self.text(self.keys[index])
            if name.startswith(('pyexpat.', 'xml.parsers.expat.')):
                matched = False
                for literal in allowed:
                    self.text(name)
                    self.text(literal)
                    if name == literal:
                        matched = True
                if not matched:
                    raise ValueError('derived extra registered child')
        roles = (self.refs.P, self.refs.W, self.refs.E, self.refs.M)
        for index in range(4):
            if type(roles[index]) is not self.refs.module_type:
                raise ValueError('derived exact role module')
            for earlier in range(index):
                if roles[index] is roles[earlier]:
                    raise ValueError('derived role distinctness')
            if roles[index] is self.refs.bootstrap_module or roles[index] is self.refs.external_module:
                raise ValueError('derived role bootstrap collision')
        self.tick('METADATA')
        self.role(self.refs.E, 'pyexpat.errors')
        self.role(self.refs.M, 'pyexpat.model')
        self.file_module(self.refs.P, 'pyexpat', DERIVED_SO, '', None, recheck)
        self.file_module(self.refs.W, 'xml.parsers.expat', DERIVED_PY,
                         'xml.parsers', DERIVED_PYC, recheck)

    def start_roster(self):
        self.bind_actual_sys(recheck=True)
        self.snapshot(self.refs.modules_dict)
        for index in range(self.count):
            if type(self.values[index]) is not self.refs.module_type:
                raise ValueError('derived census exact ModuleType')
        for index in range(self.count):
            name = self.keys[index]
            for earlier in range(index):
                self.text(name)
                self.text(self.rows[earlier]['name'])
                if name == self.rows[earlier]['name']:
                    raise ValueError('CENSUS_COVERAGE')
            row = self.rows[index]
            row['name'], row['_module'] = name, self.values[index]
            self.row_count += 1
        self.clear_scratch()

    def generic_fields(self, module):
        self.snapshot(self.module_namespace(module))
        path = self.field('__file__', False)[1]
        cached = self.field('__cached__', False)[1]
        spec = self.field('__spec__', False)[1]
        origin = None
        if spec is not None:
            self.snapshot(self.spec_namespace(spec))
            origin = self.field('origin', False)[1]
            if origin is not None:
                self.text(origin, 4096, 4096)
        return path, cached, origin

    def path(self, value):
        self.text(value, 4096, 4096, False)
        if not value.startswith('/') or '\x00' in value:
            raise ValueError('derived absolute path shape')
        for part in value.split('/'):
            self.text(part, 4096, 4096)
            if part == '.' or part == '..':
                raise ValueError('derived path dot component')

    def builtin_marker(self, origin):
        for literal in ('built-in', 'frozen'):
            self.text(origin, 4096, 4096)
            self.text(literal)
            if origin == literal:
                return True
        return False

    def inspect_row(self, row, origin_check, cache_exists):
        if row['_checked']:
            raise ValueError('CENSUS_VISIT')
        module = row['_module']
        path, cached, origin = self.generic_fields(module)
        if path is not None:
            self.path(path)
            actual = origin_check(path)
            if cached is not None:
                self.path(cached)
                exists = cache_exists(cached)
                if type(exists) is not bool:
                    raise ValueError('derived cache exists exact bool')
                if exists:
                    origin_check(cached)
        elif type(origin) is str and self.builtin_marker(origin):
            actual = origin
        elif module is self.refs.E or module is self.refs.M:
            actual = 'DERIVED_PINNED_PYEXPAT_RELATIONSHIP'
        else:
            self.state.refusal_seen = True
            name = row['name']
            if type(name) is str and len(name) <= 256:
                self.state.refusal_name, self.state.refusal_name_complete = name, True
            raise ValueError('unknown namespace or nonregular module origin')
        self.text(actual, 4096, 4096)
        row['origin'], row['_checked'] = actual, True

    def census(self, origin_check, cache_exists):
        self.start_roster()
        for index in range(self.row_count):
            self.tick('METADATA')
            self.inspect_row(self.rows[index], origin_check, cache_exists)
        self.final_roster()

    def final_roster(self):
        self.tick('RECHECK')
        self.bind_actual_sys(recheck=True)
        self.snapshot(self.refs.modules_dict)
        self.tick('RECHECK')
        if self.count != self.row_count:
            raise ValueError('CENSUS_COVERAGE')
        for index in range(self.count):
            name, module = self.keys[index], self.values[index]
            if type(module) is not self.refs.module_type:
                raise ValueError('derived census final exact ModuleType')
            matches = 0
            for earlier in range(index):
                self.text(name)
                self.text(self.keys[earlier])
                if name == self.keys[earlier]:
                    raise ValueError('CENSUS_COVERAGE')
            for position in range(self.row_count):
                row = self.rows[position]
                self.text(name)
                self.text(row['name'])
                if name == row['name']:
                    matches += 1
                    if not row['_checked']:
                        raise ValueError('CENSUS_VISIT')
                    if module is not row['_module']:
                        raise ValueError('CENSUS_STRONG_IDENTITY')
            if matches != 1:
                raise ValueError('CENSUS_COVERAGE')
        self.clear_scratch()

    def scalar_rows(self):
        for index in range(self.row_count):
            row = self.rows[index]
            if row['_module'] is not None or not row['_checked']:
                raise ValueError('derived roster not retired before serialization')
            del row['_module']
            del row['_checked']
        return self.rows[:self.row_count]

    def clear(self):
        self.clear_scratch()
        guard = self.row_guard if self.row_guard is not None else self.prepare_guard
        if self.rows is not None:
            for index in range(8192):
                with guard:
                    row = self.rows[index]
                    if row is not None:
                        retire_roster_module(row)
        guard = self.refs_guard if self.refs_guard is not None else self.prepare_guard
        if self.refs is not None:
            for field in DerivedRefs.__slots__:
                with guard:
                    retire_owned_attribute(self.refs, field)
        with guard:
            if time.monotonic_ns() >= self.state.total:
                raise TimeoutError('derived total deadline after independent clearing')


def build_checker(state):
    """Preallocate partial-owner guard before object/arrays; caller owns success."""
    guard = DerivedClearGuard(state, 'checker-prepare')
    checker = object.__new__(DerivedChecker)
    try:
        DerivedChecker.__init__(checker, state, guard)
    except BaseException:
        # Initial exact slots precede fallible preparation; cleanup is independent.
        checker.clear()
        raise
    return checker
# END EXACT PRODUCTION CHECKER BLOCK
__doc__ = 'Prospective installed SDK origin observation only; never candidate imports.'

BASE = '/home/sicarii/Work/sia-assurance-evidence-20261019/'
OUT = '/home/sicarii/Work/sia-assurance-evidence-20261019/ownership-transfer-20261024/sdk-origin-observation-v8-v2/'
FIELDS = ('st_dev', 'st_ino', 'st_mode', 'st_nlink', 'st_uid', 'st_gid',
          'st_size', 'st_mtime_ns', 'st_ctime_ns')

SDK_TYPES_DEPENDENCY = types

class ProbeState:
    """One invocation owns fixed ledgers, counters, deadlines and failure marker."""

    __slots__ = ('raw', 'phases', 'used', 'overflow', 'read_bytes',
                 'work', 'total', 'failure', 'refusal_seen',
                 'refusal_name', 'refusal_name_complete', 'stage',
                 'diagnostic_refs', 'diagnostic_used', 'diagnostic_overflow', 'capsule')

    def __init__(self):
        self.capsule = None
        self.raw = [None] * 64
        self.phases = [None] * 64
        self.used = 0
        self.overflow = False
        self.read_bytes = 0
        self.work = 0
        self.total = 0
        self.stage = 'PREPARE'
        self.diagnostic_refs = [None] * 192
        self.diagnostic_used, self.diagnostic_overflow = 0, False
        self.refusal_seen = False
        self.refusal_name = None
        self.refusal_name_complete = False
        self.failure = RuntimeError('SDK origin observation NONPASS; raw failures retained')


class Capture:
    """Retain raw exceptions before independent cleanup; no decoration here."""

    __slots__ = ('state', 'phase')

    def __init__(self, state, phase):
        self.state = state
        self.phase = phase

    def __enter__(self):
        return self

    def __exit__(self, kind, error, traceback):
        state = self.state
        if error is not None:
            if state.used < 64:
                phase = state.stage if self.phase == 'origin-probe' else self.phase
                state.raw[state.used], state.phases[state.used] = error, phase
                state.used += 1
            else:
                state.overflow = True
        return error is not None


def timely(deadline):
    if time.monotonic_ns() >= deadline:
        raise TimeoutError('original absolute SDK probe deadline')


def identity(value):
    return {name: getattr(value, name) for name in FIELDS}


def read_budget(state, block):
    if type(block) is not bytes:
        raise ValueError('SDK read must return exact bytes')
    state.read_bytes += len(block)
    if state.read_bytes > 536870912:
        raise ValueError('SDK aggregate read bound')


def checked_close(number):
    if os.close(number) is not None:
        raise ValueError('unexpected SDK descriptor close return')


def read_complete(state, number, limit, steps, chunks):
    """Short reads never imply completion; only an explicit empty read is EOF."""
    used, size, eof = 0, 0, False
    for _ in steps:
        timely(state.total)
        block = os.read(number, min(65536, limit + 1 - size))
        timely(state.total)
        read_budget(state, block)
        if not block:
            eof = True
            break
        size += len(block)
        if size > limit:
            raise ValueError('SDK read overflow')
        chunks[used] = block
        used += 1
    if not eof:
        raise ValueError('SDK read loop exhausted without EOF')
    return used, size


def read_bounded(state, path, limit, virtual=False):
    """Stable regular JSON differs from proc virtual size0; both require EOF."""
    path_text(path)
    if type(limit) is not int or not 0 < limit <= 8388608:
        raise ValueError('SDK bounded input byte limit')
    if type(virtual) is not bool or (virtual and path != '/proc/self/maps'):
        raise ValueError('fixed proc maps virtual-read scope')
    read_guard, close_guard = Capture(state, 'read'), Capture(state, 'read-close')
    chunks, steps = [None] * 129, range(129)
    initial, used = state.used, 0
    number = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
    with read_guard:
        value = os.fstat(number)
        first = identity(value)
        if not stat.S_ISREG(value.st_mode) or (not virtual and value.st_size > limit):
            raise ValueError('SDK regular input kind/size bound')
        used, size = read_complete(state, number, limit, steps, chunks)
        if not virtual and (size != value.st_size or identity(os.fstat(number)) != first
                            or identity(os.lstat(path)) != first):
            raise ValueError('regular SDK JSON endpoint changed or incomplete')
    with close_guard:
        checked_close(number)
    if state.used != initial or state.overflow:
        raise state.failure
    return b''.join(chunks[:used])


def hash_complete(state, number, value, digest, steps):
    used, eof = 0, False
    for _ in steps:
        timely(state.total)
        block = os.read(number, min(65536, value.st_size + 1 - used))
        timely(state.total)
        read_budget(state, block)
        if not block:
            eof = True
            break
        used += len(block)
        if used > value.st_size:
            raise ValueError('SDK hash grew past admitted size')
        digest.update(block)
    if not eof or used != value.st_size:
        raise ValueError('SDK hash loop exhausted or size mismatch')


def file_row(state, path):
    """All fallible preparation precedes acquisition; every owned close is once."""
    path_text(path)
    guard, close_guard = Capture(state, 'hash'), Capture(state, 'hash-close')
    digest, steps = hashlib.sha256(), range(1025)
    initial, first = state.used, None
    number = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
    with guard:
        value = os.fstat(number)
        first = identity(value)
        if not stat.S_ISREG(value.st_mode) or not 0 <= value.st_size <= 67108864:
            raise ValueError('SDK regular file bound')
        hash_complete(state, number, value, digest, steps)
        if identity(os.fstat(number)) != first or identity(os.lstat(path)) != first:
            raise ValueError('SDK input endpoint changed during hash')
    with close_guard:
        checked_close(number)
    if state.used != initial or state.overflow:
        raise state.failure
    return {'identity': first, 'sha256': digest.hexdigest()}


def path_text(value):
    if (type(value) is not str or not 1 <= len(value) <= 4096
            or not value.startswith('/') or '\x00' in value
            or any(part in ('.', '..') for part in value.split('/'))):
        raise ValueError('SDK absolute path shape/bound')


def leaf_text(value):
    if (type(value) is not str or not 1 <= len(value) <= 255
            or '/' in value or '\x00' in value or value in ('.', '..')
            or len(value.encode('utf-8')) > 255):
        raise ValueError('SDK namespace entry shape/bound')


def exact_map(value, bound):
    if type(value) is not dict or len(value) > bound:
        raise ValueError('SDK map type/count bound')


def validate_identity(value):
    exact_map(value, 9)
    if set(value) != set(FIELDS):
        raise ValueError('SDK full9 identity keys')
    for item in value.values():
        if type(item) is not int or not -(1 << 128) <= item < (1 << 128):
            raise ValueError('SDK identity exact bounded integer')


def validate_file_row(row):
    exact_map(row, 2)
    if set(row) != {'identity', 'sha256'}:
        raise ValueError('SDK file row keys')
    validate_identity(row['identity'])
    digest = row['sha256']
    if (type(digest) is not str or len(digest) != 64
            or any(c not in '0123456789abcdef' for c in digest)):
        raise ValueError('SDK SHA256 exact text')


def validate_names(names):
    if type(names) is not list or len(names) > 8192:
        raise ValueError('SDK namespace list type/count')
    for name in names:
        leaf_text(name)


def validate_directories(cohort):
    exact_map(cohort['directories'], 4096)
    for path, row in cohort['directories'].items():
        path_text(path)
        exact_map(row, 2)
        if set(row) not in ({'identity'}, {'identity', 'names'}):
            raise ValueError('SDK directory row keys')
        validate_identity(row['identity'])
        if 'names' in row:
            validate_names(row['names'])
    exact_map(cohort['aliases'], 8192)
    for path, row in cohort['aliases'].items():
        path_text(path)
        exact_map(row, 3)
        if set(row) != {'identity', 'link', 'resolved'}:
            raise ValueError('SDK alias row keys')
        validate_identity(row['identity'])
        path_text(row['resolved'])
        if type(row['link']) is not str or not 1 <= len(row['link']) <= 4096:
            raise ValueError('SDK alias link bound')


def validate_negative(cohort):
    exact_map(cohort['negative_lookup'], 8192)
    for path, row in cohort['negative_lookup'].items():
        exact_map(row, 3)
        if set(row) == {'state'} and row['state'] == 'ENOENT':
            path_text(path)
        elif path == 'site_top_level_special' and set(row) == {'directory', 'names', 'predicate'}:
            path_text(row['directory'])
            validate_names(row['names'])
            if row['predicate'] != '*.pth or sitecustomize*/usercustomize*':
                raise ValueError('SDK startup predicate mismatch')
        else:
            raise ValueError('SDK negative lookup row shape')


def validate_cohort(cohort):
    exact_map(cohort, 32)
    if type(cohort['errors']) is not list or cohort['errors']:
        raise ValueError('prospective SDK closure incomplete')
    exact_map(cohort['files'], 8192)
    aggregate = 0
    for path, row in cohort['files'].items():
        path_text(path)
        validate_file_row(row)
        size = row['identity']['st_size']
        if not 0 <= size <= 67108864:
            raise ValueError('SDK cohort per-file bound')
        aggregate += size
        if aggregate > 536870912:
            raise ValueError('SDK cohort aggregate bound')
    validate_file_row(cohort['probe_source'])
    exact_map(cohort['excluded_origins'], 8192)
    for path in cohort['excluded_origins']:
        path_text(path)
    validate_directories(cohort)
    validate_negative(cohort)


def bounded_names(state, path):
    """Prebudget before scandir; excess refuses before append or sort."""
    path_text(path)
    scan_guard, close_guard = Capture(state, 'namespace-read'), Capture(state, 'namespace-close')
    names, steps = [None] * 8192, range(8193)
    initial, used = state.used, 0
    iterator = os.scandir(path)
    with scan_guard:
        for _ in steps:
            timely(state.total)
            entry = next(iterator, None)
            timely(state.total)
            if entry is None:
                break
            if used == 8192:
                raise ValueError('SDK namespace exceeds fixed entry budget')
            name = entry.name
            leaf_text(name)
            names[used] = name
            used += 1
        else:
            raise ValueError('SDK namespace enumeration bound')
    with close_guard:
        if iterator.close() is not None:
            raise ValueError('unexpected namespace iterator close return')
    if state.used != initial or state.overflow:
        raise state.failure
    result = sorted(names[:used])
    timely(state.total)
    return result


def verify_namespace(state, cohort):
    for path, row in cohort['directories'].items():
        timely(state.total)
        if identity(os.lstat(path)) != row['identity']:
            raise ValueError('SDK directory endpoint changed')
        if 'names' in row and bounded_names(state, path) != row['names']:
            raise ValueError('SDK directory namespace changed')
        if identity(os.lstat(path)) != row['identity']:
            raise ValueError('SDK directory changed around namespace observation')
    for path, row in cohort['aliases'].items():
        timely(state.total)
        if (identity(os.lstat(path)) != row['identity'] or os.readlink(path) != row['link']
                or os.path.realpath(path) != row['resolved']):
            raise ValueError('SDK alias changed')
    for path, row in cohort['negative_lookup'].items():
        timely(state.total)
        if row.get('state') == 'ENOENT':
            if os.path.lexists(path):
                raise ValueError('SDK negative lookup changed')
        else:
            names = bounded_names(state, row['directory'])
            special = [n for n in names if n.endswith('.pth')
                       or n.startswith(('sitecustomize', 'usercustomize'))]
            if special != row['names']:
                raise ValueError('SDK startup customization changed')


def verify_cohort(state, cohort):
    for path, expected in cohort['files'].items():
        timely(state.total)
        if file_row(state, path) != expected:
            raise ValueError('prospectively pinned SDK origin changed')
    verify_namespace(state, cohort)


def admitted_origin(state, path, cohort):
    if type(path) is not str or not path.startswith('/') or len(path) > 4096:
        raise ValueError('unknown/nonregular module origin')
    actual = os.path.realpath(path)
    if actual in cohort['excluded_origins']:
        raise ValueError('explicitly excluded SDK provider loaded')
    expected = cohort['files'].get(actual)
    if actual == os.path.realpath(__file__):
        expected = cohort['probe_source']
    if expected is None or file_row(state, actual) != expected:
        raise ValueError('observed SDK origin was not prospectively pinned')
    return actual


def modules(state, cohort, checker):
    """Complete strong roster; dependency callbacks only perform original file IO."""
    def origin_check(path):
        return admitted_origin(state, path, cohort)
    checker.census(origin_check, os.path.exists)


def maps(state, cohort):
    raw = read_bounded(state, '/proc/self/maps', 8388608, virtual=True)
    rows = raw.decode('utf-8', 'strict').splitlines()
    if len(rows) > 8192:
        raise ValueError('SDK mapped row bound')
    origins = set()
    producer_executable = False
    for line in rows:
        fields = line.split(None, 5)
        if len(fields) not in (5, 6):
            raise ValueError('SDK maps row shape')
        if len(fields) == 6 and fields[5].startswith('/'):
            actual = admitted_origin(state, fields[5], cohort)
            expected = cohort['files'][actual]['identity']
            device = fields[3].split(':')
            if (len(device) != 2 or int(fields[4]) != expected['st_ino']
                    or (int(device[0], 16), int(device[1], 16))
                    != (os.major(expected['st_dev']), os.minor(expected['st_dev']))):
                raise ValueError('actual mapped device/inode differs from prospective file')
            if actual == DERIVED_SO and 'x' in fields[1]:
                producer_executable = True
            origins.add(actual)
        elif len(fields) == 6 and not fields[5].startswith('['):
            raise ValueError('unknown nonregular mapped origin')
    if not producer_executable:
        raise ValueError('pinned producer has no observed executable mapping')
    return {'raw_utf8': raw.decode('utf-8'), 'regular_origins': sorted(origins)}


def import_selected():
    """Provider imports only; no connection, namespace primitive or candidate."""
    import array
    import ctypes
    import dbus
    import dbus.bus
    import dbus.exceptions
    import fcntl
    import select
    import socket
    import struct
    import unittest
    if (array.array('i').itemsize != 4 or ctypes.sizeof(ctypes.c_int) != 4
            or dbus.bus is None or dbus.exceptions is None or fcntl is None
            or select is None or socket is None or struct is None or unittest is None):
        raise ValueError('selected provider imports unavailable')


def observe(state):
    cleanup_guard = Capture(state, 'checker-clear')
    checker, result = None, None
    try:
        checker = build_checker(state)
        prepare_diagnostics(state, checker)
        cohort = json.loads(read_bounded(state, OUT + 'SELECTED-COHORTS.json', 8388608))
        validate_cohort(cohort)
        verify_cohort(state, cohort)
        expected = ['/usr/lib/python314.zip', '/usr/lib/python3.14',
                    '/usr/lib/python3.14/lib-dynload', '/usr/lib/python3.14/site-packages']
        if sys.path != expected or not sys.flags.isolated or not sys.dont_write_bytecode:
            raise ValueError('unexpected selected isolated startup resolution')
        if os.path.realpath(sys.executable) != '/usr/bin/python3.14':
            raise ValueError('unexpected selected interpreter')
        timely(state.work)
        import_selected()
        timely(state.work)
        checker.graph()
        for path in (DERIVED_SO, DERIVED_PY, DERIVED_PYC):
            admitted_origin(state, path, cohort)
        mapping = maps(state, cohort)
        checker.graph(recheck=True)
        modules(state, cohort, checker)
        verify_cohort(state, cohort)
        for path in (DERIVED_SO, DERIVED_PY, DERIVED_PYC):
            admitted_origin(state, path, cohort)
        checker.graph(recheck=True)
        checker.final_roster()
        timely(state.work)
        result = {'maps': mapping, 'sys_path': sys.path,
                  'builtin_names': list(sys.builtin_module_names),
                  'trusted_installed_sdk_premise': 'ASSUMED_NOT_PROVED',
                  'derived_ceiling': 'RELATIONSHIP_NOT_CREATOR_ABI_OR_AUTHORITY'}
    finally:
        if checker is not None:
            with cleanup_guard:
                checker.clear()
    if state.used or state.overflow:
        raise state.failure
    result['modules'] = checker.scalar_rows()
    timely(state.total)
    return result



def error_class_tag(error):
    """Exact closed type identity only; no class names or metaclass equality."""
    kind = type(error)
    tags = ((ValueError, 'ValueError'), (RuntimeError, 'RuntimeError'),
            (OSError, 'OSError'), (FileNotFoundError, 'FileNotFoundError'),
            (PermissionError, 'PermissionError'), (TimeoutError, 'TimeoutError'))
    for known, literal in tags:
        if kind is known:
            return literal
    return None

def diagnostic_step(state, deadline):
    """Conservative fixed inspection reserve; not native allocation/WCET proof."""
    timely(deadline)
    charge(state, 32)
    timely(deadline)


def diagnostic_text(state, value, deadline):
    timely(deadline)
    if type(value) is not str or len(value) > 256:
        raise ValueError('diagnostic exact native descriptor name')
    charge(state, 4 * len(value))
    timely(deadline)
    raw = value.encode('utf-8', 'strict')
    if len(raw) > 1024:
        raise ValueError('diagnostic native descriptor UTF8 bound')
    timely(deadline)
    return value


class DiagnosticCapsule:
    """Nine held native routes; invocation state is passed, never retained."""

    __slots__ = ('kind', 'get', 'attribute', 'base', 'mro_descriptor',
                 'args_descriptor', 'dict_descriptor', 'cause_descriptor',
                 'context_descriptor')

    def __init__(self):
        for field in DiagnosticCapsule.__slots__:
            object.__setattr__(self, field, None)

    def capture(self, state, checker):
        diagnostic_step(state, state.work)
        self.kind = checker.refs.getset_descriptor_type
        self.get = checker.refs.getset_get_intrinsic
        self.attribute = checker.refs.object_getattribute_intrinsic
        self.base = BaseException
        checker.snapshot(checker.class_namespace(type), 256)
        self.mro_descriptor = checker.required('__mro__')
        checker.snapshot(checker.class_namespace(BaseException), 256)
        self.args_descriptor = checker.required('args')
        self.dict_descriptor = checker.required('__dict__')
        self.cause_descriptor = checker.required('__cause__')
        self.context_descriptor = checker.required('__context__')
        self.check_descriptor(state, self.mro_descriptor, type, '__mro__', state.work)
        self.check_descriptor(state, self.args_descriptor, BaseException, 'args', state.work)
        self.check_descriptor(state, self.dict_descriptor, BaseException, '__dict__', state.work)
        self.check_descriptor(state, self.cause_descriptor, BaseException, '__cause__', state.work)
        self.check_descriptor(state, self.context_descriptor, BaseException, '__context__', state.work)
        checker.clear_scratch()
        diagnostic_step(state, state.work)

    def check_descriptor(self, state, descriptor, owner, name, deadline=None):
        deadline = state.total if deadline is None else deadline
        diagnostic_step(state, deadline)
        if type(descriptor) is not self.kind:
            raise ValueError('diagnostic exact native descriptor kind')
        diagnostic_step(state, deadline)
        actual_owner = self.attribute(descriptor, '__objclass__')
        diagnostic_step(state, deadline)
        if actual_owner is not owner:
            raise ValueError('diagnostic exact native descriptor owner')
        diagnostic_step(state, deadline)
        actual = self.attribute(descriptor, '__name__')
        diagnostic_step(state, deadline)
        diagnostic_text(state, actual, deadline)
        diagnostic_text(state, name, deadline)
        diagnostic_step(state, deadline)
        if actual != name:
            raise ValueError('diagnostic exact native descriptor name')
        diagnostic_step(state, deadline)

    def receiver(self, state, value, deadline=None):
        deadline = state.total if deadline is None else deadline
        self.check_descriptor(state, self.mro_descriptor, type, '__mro__', deadline)
        diagnostic_step(state, deadline)
        cls = type(value)
        diagnostic_step(state, deadline)
        lineage = self.get(self.mro_descriptor, cls, type(cls))
        diagnostic_step(state, deadline)
        if type(lineage) is not tuple or not 0 < len(lineage) <= 8192:
            raise ValueError('diagnostic native MRO output')
        found = False
        for ancestor in lineage:
            diagnostic_step(state, deadline)
            if ancestor is self.base:
                found = True
            diagnostic_step(state, deadline)
        if not found:
            raise ValueError('diagnostic native exception receiver')
        diagnostic_step(state, deadline)

    def read(self, state, descriptor, error, name, expected, deadline=None):
        deadline = state.total if deadline is None else deadline
        self.check_descriptor(state, descriptor, self.base, name, deadline)
        self.receiver(state, error, deadline)
        diagnostic_step(state, deadline)
        result = self.get(descriptor, error, type(error))
        diagnostic_step(state, deadline)
        if expected is not None and type(result) is not expected:
            raise ValueError('diagnostic native descriptor output')
        if expected is None and result is not None:
            self.receiver(state, result, deadline)
        diagnostic_step(state, deadline)
        return result


def new_diagnostic_capsule():
    return DiagnosticCapsule()


def prepare_diagnostics(state, checker):
    state.capsule = object.__new__(DiagnosticCapsule)
    DiagnosticCapsule.__init__(state.capsule)
    state.capsule.capture(state, checker)


def clear_diagnostics(state, guard):
    """Every cell is attempted independently, even after retirement failures."""
    for index in range(192):
        with guard:
            retire_reference_cell(state.diagnostic_refs, index)
    if state.capsule is not None:
        for field in DiagnosticCapsule.__slots__:
            with guard:
                retire_owned_attribute(state.capsule, field)


def charge(state, amount):
    timely(state.total)
    if type(amount) is not int or amount < 0 or amount > 536870912 - state.read_bytes:
        raise ValueError('SDK aggregate preparation/text/output bound')
    state.read_bytes += amount


def diagnostic_reference(state, value):
    if value is None:
        return None
    for index in range(state.diagnostic_used):
        if value is state.diagnostic_refs[index]:
            return index
    if state.diagnostic_used == 192:
        state.diagnostic_overflow = True
        raise ValueError('direct diagnostic endpoint slots overflow')
    position = state.diagnostic_used
    state.diagnostic_refs[position] = value
    state.diagnostic_used += 1
    return position


def diagnostic_arguments(state, args):
    if type(args) is not tuple:
        return [], False
    complete = len(args) <= 4
    values = []
    for index in range(min(4, len(args))):
        timely(state.total)
        item = args[index]
        if type(item) is str and len(item) <= 256:
            charge(state, 4 * len(item))
            values.append(item)
        elif item is None or (type(item) is int and -(1 << 64) <= item < (1 << 64)):
            charge(state, 32)
            values.append(item)
        else:
            complete = False
    return values, complete


def diagnostics(state):
    """Raw64 roots plus immediate links only; no recursive graph or audited id."""
    if state.capsule is None:
        raise ValueError('diagnostic native capsule unavailable')
    charge(state, 64 * 256)
    rows, initial = [], state.used
    for index in range(initial):
        diagnostic_reference(state, state.raw[index])
    for index in range(initial):
        timely(state.total)
        error, capsule = state.raw[index], state.capsule
        args = capsule.read(state, capsule.args_descriptor, error, 'args', tuple)
        values, complete = diagnostic_arguments(state, args)
        attributes = capsule.read(state, capsule.dict_descriptor, error, '__dict__', dict)
        cause = capsule.read(state, capsule.cause_descriptor, error, '__cause__', None)
        context = capsule.read(state, capsule.context_descriptor, error, '__context__', None)
        class_tag = error_class_tag(error)
        rows.append({'phase': state.phases[index],
                     'process_local_reference': diagnostic_reference(state, error),
                     'class_tag': class_tag, 'args': values,
                     'complete': complete and class_tag is not None
                                 and not attributes and cause is None and context is None,
                     'cause_reference': diagnostic_reference(state, cause),
                     'context_reference': diagnostic_reference(state, context)})
    return {'errors': rows, 'overflow': state.overflow,
            'reference_kind': 'PROCESS_LOCAL_IS_ALIAS_NOT_NATIVE_ADDRESS',
            'endpoint_scope': 'RAW64_ROOTS_IMMEDIATE_CAUSE_CONTEXT_ONLY',
            'reference_overflow': state.diagnostic_overflow}


def new_output_buffer():
    return bytearray(8388608)


def new_record(state, observation, projection):
    return {'schema': 'sia.selected-sdk-derived-origin-observation.v2',
            'acceptance': False, 'authority': 'NONE',
            'status': 'NONPASS' if state.used or state.overflow else
            'OBSERVED_SELECTED_SDK_ORIGINS_PENDING_ROOT_READBACK',
            'observation': observation, 'diagnostics': projection,
            'refusal_seen': state.refusal_seen, 'refusal_name': state.refusal_name,
            'refusal_name_complete': state.refusal_name_complete,
            'whole_sdk_abi_correctness': 'UNPROVEN', 'candidate_import': 'NOT_PERFORMED'}


class Output:
    """Fixed schema serializer, no recursive object traversal or user dispatch."""

    __slots__ = ('state', 'buffer', 'used')

    def __init__(self, state):
        self.state, self.buffer, self.used = state, None, 0

    def prepare(self):
        charge(self.state, 8388608)
        self.buffer = new_output_buffer()

    def put(self, raw):
        timely(self.state.total)
        if type(raw) is not bytes or len(raw) > 8388608 - self.used:
            raise ValueError('SDK bounded output preallocation')
        charge(self.state, len(raw))
        self.buffer[self.used:self.used + len(raw)] = raw
        self.used += len(raw)
        timely(self.state.total)

    def text(self, value, bound=4096):
        if type(value) is not str or len(value) > bound:
            raise ValueError('SDK output exact text prelength')
        self.put(b'"')
        for start in range(0, len(value), 1024):
            size = min(1024, len(value) - start)
            # Charge codepoint slice, UTF8 validation, encoder worst case and slice.
            charge(self.state, 4 * size)
            charge(self.state, 4 * size)
            charge(self.state, 12 * size + 2)
            charge(self.state, 12 * size)
            charge(self.state, 12 * size)
            if 12 * size + 2 > 8388608 - self.used:
                raise ValueError('SDK output encoder preallocation bound')
            chunk = value[start:start + 1024]
            chunk.encode('utf-8', 'strict')
            raw = json.dumps(chunk, ensure_ascii=True)[1:-1].encode('ascii')
            self.put(raw)
        self.put(b'"')

    def scalar(self, value):
        if value is None:
            self.put(b'null')
        elif type(value) is bool:
            self.put(b'true' if value else b'false')
        elif type(value) is int and -(1 << 64) <= value < (1 << 64):
            charge(self.state, 128)
            self.put(json.dumps(value).encode('ascii'))
        elif type(value) is str:
            self.text(value)
        else:
            raise ValueError('SDK closed scalar output')

    def field(self, name, value, first=False):
        if not first:
            self.put(b',')
        self.text(name, 256)
        self.put(b':')
        self.scalar(value)

    def strings(self, values, bound):
        if type(values) is not list or len(values) > 8192:
            raise ValueError('SDK output string list bound')
        self.put(b'[')
        for index in range(len(values)):
            if index:
                self.put(b',')
            self.text(values[index], bound)
        self.put(b']')

    def mapping(self, value):
        self.put(b'{"raw_utf8":')
        self.text(value['raw_utf8'], 8388608)
        self.put(b',"regular_origins":')
        self.strings(value['regular_origins'], 4096)
        self.put(b'}')

    def module_rows(self, rows):
        if type(rows) is not list or len(rows) > 8192:
            raise ValueError('SDK output module list bound')
        self.put(b'[')
        for index in range(len(rows)):
            if index:
                self.put(b',')
            row = rows[index]
            self.put(b'{')
            self.field('name', row['name'], True)
            self.field('origin', row['origin'])
            self.put(b'}')
        self.put(b']')

    def observation(self, value):
        if value is None:
            self.put(b'null')
            return
        self.put(b'{"maps":')
        self.mapping(value['maps'])
        self.put(b',"sys_path":')
        self.strings(value['sys_path'], 4096)
        self.put(b',"builtin_names":')
        self.strings(value['builtin_names'], 256)
        self.put(b',"modules":')
        self.module_rows(value['modules'])
        self.field('trusted_installed_sdk_premise', value['trusted_installed_sdk_premise'])
        self.field('derived_ceiling', value['derived_ceiling'])
        self.put(b'}')

    def diagnostic_rows(self, rows):
        if type(rows) is not list or len(rows) > 64:
            raise ValueError('SDK diagnostic output rows bound')
        self.put(b'[')
        for index in range(len(rows)):
            row = rows[index]
            if index:
                self.put(b',')
            self.put(b'{')
            self.field('phase', row['phase'], True)
            for name in ('process_local_reference', 'class_tag', 'complete',
                         'cause_reference', 'context_reference'):
                self.field(name, row[name])
            self.put(b',"args":[')
            if type(row['args']) is not list or len(row['args']) > 4:
                raise ValueError('SDK diagnostic argument output bound')
            for position in range(len(row['args'])):
                if position:
                    self.put(b',')
                self.scalar(row['args'][position])
            self.put(b']}')
        self.put(b']')

    def projection(self, value):
        if value is None:
            self.put(b'null')
            return
        self.put(b'{"errors":')
        self.diagnostic_rows(value['errors'])
        for name in ('overflow', 'reference_kind', 'endpoint_scope', 'reference_overflow'):
            self.field(name, value[name])
        self.put(b'}')

    def record(self, value):
        self.put(b'{')
        self.field('schema', value['schema'], True)
        for name in ('acceptance', 'authority', 'status', 'refusal_seen',
                     'refusal_name', 'refusal_name_complete',
                     'whole_sdk_abi_correctness', 'candidate_import'):
            self.field(name, value[name])
        self.put(b',"observation":')
        self.observation(value['observation'])
        self.put(b',"diagnostics":')
        self.projection(value['diagnostics'])
        self.put(b'}\n')


def write_output(state, output, stream):
    """Borrowed stream; exact counts, no retry, independent explicit flush."""
    guard, flush_guard = Capture(state, 'stdout-write'), Capture(state, 'stdout-flush')
    with guard:
        for start in range(0, output.used, 1024):
            timely(state.total)
            size = min(1024, output.used - start)
            charge(state, size)
            charge(state, 4 * size)
            raw = bytes(output.buffer[start:start + size]).decode('ascii')
            returned = stream.write(raw)
            if type(returned) is not int or returned != len(raw):
                raise ValueError('SDK stdout exact complete write return')
            timely(state.total)
    with flush_guard:
        timely(state.total)
        if stream.flush() is not None:
            raise ValueError('SDK stdout flush return')
        timely(state.total)


def initialize_deadlines(state):
    if len(sys.argv) != 3 or any(not s.isdigit() for s in sys.argv[1:]):
        raise ValueError('root supplies original absolute work/overall only')
    state.work, state.total = int(sys.argv[1]), int(sys.argv[2])
    if not 0 < state.work < state.total <= (1 << 64) - 1 or state.work + 5000000000 != state.total:
        raise ValueError('original120/125 shared5 relationship required')
    timely(state.work)


def finalize_main(state):
    """All late allocation and IO faults remain raw/NONPASS, never retrogreen."""
    result, projection, record, output = None, None, None, None
    main_guard = Capture(state, 'origin-probe')
    prepare_guard = Capture(state, 'output-prepare')
    diagnostics_guard = Capture(state, 'diagnostics')
    render_guard = Capture(state, 'serializer')
    reference_guard = Capture(state, 'diagnostic-reference-clear')
    fallback_guard = Capture(state, 'bounded-fallback')
    fallback = b'{"acceptance":false,"authority":"NONE","status":"NONPASS","diagnostics_complete":false}\n'
    fallback_ready = False
    with main_guard:
        initialize_deadlines(state)
    with prepare_guard:
        timely(state.total)
        charge(state, len(fallback))
        fallback_ready = True
        output = Output(state)
        output.prepare()
    if not state.used and output is not None:
        with main_guard:
            result = observe(state)
    projected_used = state.used
    with diagnostics_guard:
        projection = diagnostics(state)
    if state.used or state.overflow or projection is None:
        result = None
    try:
        with render_guard:
            if output is None:
                raise ValueError('SDK output preparation incomplete')
            record = new_record(state, result, projection)
            output.record(record)
    finally:
        clear_diagnostics(state, reference_guard)
    complete = (state.used == projected_used and not state.overflow
                and not state.diagnostic_overflow and projection is not None)
    if not complete:
        with fallback_guard:
            timely(state.total)
            if not fallback_ready or output is None or output.buffer is None:
                raise ValueError('SDK bounded fallback unavailable')
            output.used = 0
            output.put(fallback)
    if not complete and (not fallback_ready or output is None):
        return 1
    if output is not None and output.buffer is not None and output.used:
        write_output(state, output, sys.stdout)
    with fallback_guard:
        timely(state.total)
    return 0 if complete and not state.used and not state.overflow else 1


def run_main(state):
    """Last raw boundary also covers guard preparation, before owned IO exists."""
    try:
        return finalize_main(state)
    except BaseException as error:
        if state.used < 64:
            state.raw[state.used], state.phases[state.used] = error, 'late-finalization'
            state.used += 1
        else:
            state.overflow = True
        # Owned IO and graph cleanup have their independent inner boundaries.
        # No unbounded secondary renderer or new output retry is attempted here.
        return 1


def main():
    return run_main(ProbeState())


if __name__ == '__main__':
    raise SystemExit(main())

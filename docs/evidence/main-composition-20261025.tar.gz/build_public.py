"""Build deterministic, explicitly incomplete composition evidence."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

OUT = Path(__file__).parent
REPO = Path('/home/sicarii/Work/sia-assurance-checkpoint-20261023')
NAMES = (
    'run.py', 'build_public.py', 'merge.json', 'preview.json', 'merged.status',
    'merge.stdout', 'merge.stderr', 'merge-preview.stdout', 'merge-preview.stderr',
    'ack-equality.stdout', 'ack-equality.stderr', 'affected-inputs.json',
    'affected-result.json', 'affected.stdout', 'affected.stderr',
    'runner-static.json', 'runner-static.stdout', 'runner-static.stderr',
    'product-static.json', 'product-static.stdout', 'product-static.stderr',
    'installer-syntax.json', 'installer-syntax.stdout', 'installer-syntax.stderr',
    'main-static.stdout', 'main-static.stderr', 'carrier-static.stdout',
    'carrier-static.stderr', 'static-baseline-comparison.json', 'review.md',
)


def payloads():
    result = {}
    for name in NAMES:
        path = OUT / name
        if path.stat().st_size > 2097152:
            raise ValueError('evidence member capacity')
        result[name] = path.read_bytes()
    manifest = {name: hashlib.sha256(raw).hexdigest()
                for name, raw in result.items()}
    result['SHA256.json'] = (json.dumps(manifest, sort_keys=True, indent=2)
                            + '\n').encode()
    return result


def archive(members):
    target = io.BytesIO()
    with gzip.GzipFile(fileobj=target, mode='wb', filename='', mtime=0) as zipped:
        with tarfile.open(fileobj=zipped, mode='w', format=tarfile.USTAR_FORMAT) as tar:
            for name, raw in sorted(members.items()):
                entry = tarfile.TarInfo(name)
                entry.size = len(raw)
                entry.mode = 0o644
                tar.addfile(entry, io.BytesIO(raw))
    value = target.getvalue()
    if len(value) > 2097152:
        raise ValueError('archive capacity')
    return value


def main():
    members = payloads()
    raw = archive(members)
    if raw != archive(members):
        raise ValueError('archive not reproducible')
    relative = 'docs/evidence/main-composition-20261025.tar.gz'
    with (REPO / relative).open('xb') as stream:
        stream.write(raw)
    result = json.loads((OUT / 'affected-result.json').read_text())
    report = {
        'status': 'TESTED_SELECTED_COMPOSITION; FULL_ACCEPTANCE_INCOMPLETE',
        'carrier_parent': result['base_commit'],
        'main_parent': json.loads((OUT / 'merge.json').read_text())['merged_main'],
        'tested_tree': result['source_tree'],
        'scope': 'Exact executable composition before evidence-only additions',
        'tests': {'count': 57, 'unittest_seconds': '43.389', 'exit': result['exit'],
                  'skips': 0, 'outer_elapsed_ns': result['elapsed_ns']},
        'endpoint_pins': {'count': len(result['before']), 'unchanged': result['unchanged'],
                         'limit': 'Selected endpoints, not continuous loaded-code custody'},
        'static': {'runner_exit': 0, 'installer_syntax_exit': 0,
                   'product_exit': 1, 'findings': 10, 'new_against_parents': 0,
                   'limit': 'Unresolved findings; no waiver or whole-tree zero-warning claim'},
        'archive': {'path': relative, 'sha256': hashlib.sha256(raw).hexdigest(),
                    'bytes': len(raw), 'members': len(members), 'reproduced': True},
        'review': 'Actual GPT-6.1 source/raw review; no independent execution',
        'remaining': 'All original A/G/C/P/R/EP controls including R05 BOTH, full proofs, '
                     'SDK/native, actual compaction, off-host recovery, retrieval, judge, '
                     'installed lifecycle, full composition and release/marketplace gates',
    }
    with (REPO / 'docs/MAIN-COMPOSITION-20261025.json').open('x') as stream:
        json.dump(report, stream, sort_keys=True, indent=2)
        stream.write('\n')
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()

"""Per-method cost observation; original discovery and work cap remain fixed."""
import json
from pathlib import Path
import sys
import time
import unittest

WORK = Path(__file__).resolve().parent.parent / 'sdk-loop-finally-v8'
sys.path.insert(0, str(WORK))


class TimedResult(unittest.TextTestResult):
    started = None
    emitted = 0

    def startTest(self, test):
        if self.emitted >= 512 or self.started is not None:
            raise ValueError('timing record state/capacity')
        name = test.id()
        if type(name) is not str or len(name) > 512:
            raise ValueError('timing test identity bound')
        self.started = (name, time.perf_counter_ns())
        print(json.dumps({'phase': 'start', 'test': name}), flush=True)
        super().startTest(test)

    def stopTest(self, test):
        ended = time.perf_counter_ns()
        if self.started is None or self.started[0] != test.id():
            raise ValueError('timing test pairing')
        print(json.dumps({'phase': 'stop', 'test': self.started[0],
                          'elapsed_ns': ended - self.started[1]}), flush=True)
        self.emitted += 1
        self.started = None
        super().stopTest(test)


def main():
    suite = unittest.defaultTestLoader.discover(str(WORK))
    count = suite.countTestCases()
    if not 1 <= count <= 512:
        raise ValueError('original discovery count bound')
    print(json.dumps({'phase': 'discovered', 'tests': count,
                      'scope': 'Instrumented diagnostic, no timing acceptance'}), flush=True)
    result = unittest.TextTestRunner(verbosity=2, resultclass=TimedResult).run(suite)
    return 0 if result.wasSuccessful() else 1


if __name__ == '__main__':
    raise SystemExit(main())

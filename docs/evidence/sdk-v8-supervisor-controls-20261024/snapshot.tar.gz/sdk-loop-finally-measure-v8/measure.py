"""Bounded cost diagnostic; not semantic or complete-suite acceptance."""
import importlib.util
import json
from pathlib import Path
import sys
import time
from unittest.mock import patch

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / 'sdk-loop-finally-v8'))


def baseline():
    path = ROOT / 'sdk-last-index-v7/production_checker.py'
    spec = importlib.util.spec_from_file_location('before_loop_finally', path)
    if spec is None or spec.loader is None:
        raise RuntimeError('baseline loader unavailable')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def measure(module, probe):
    state = probe.ProbeState()
    state.work, state.total = 1, 5000000001
    checker = module.build_checker(state)
    try:
        started = time.perf_counter_ns()
        for _ in range(256):
            checker.clear_scratch()
        elapsed = time.perf_counter_ns() - started
        if state.used or state.overflow or any(checker.keys) or any(checker.values):
            raise RuntimeError('clearing diagnostic failed')
        return elapsed
    finally:
        checker.clear()


def main():
    from test_support import CHECKER, PROBE, zero_clock
    original = baseline()
    with patch.object(CHECKER.time, 'monotonic_ns', zero_clock):
        for order in ((original, CHECKER), (CHECKER, original)):
            for module in order:
                print(json.dumps({'module': module.__name__, 'sweeps': 256,
                                  'elapsed_ns': measure(module, PROBE)}), flush=True)


if __name__ == '__main__':
    main()

# Owner disposition: injected controls pass; real dispatch remains closed

Reviewed worker HEAD `fac4b86d79daa4a481e908557ed1fa601923c94d`, tree
`81a7f2a09652715c23808b9de555e2054c9a4958`. The checkout was clean immediately
before the owner run. Supervisor SHA256:
`a92c3a3633ed8b2cc3a7405b7b15e520eb9935042eefbf4c3f4866fc43fa68d6`.

## Executed evidence

Owner ran only `test_supervisor_controls.py` through the retained runner
`run_continuity_supervisor_injected_fac4b86_v1.py`. All 18 injected controls
passed (unittest reports 0.016s); exit 0; source hashes and recorded metadata
unchanged. Raw command/environment/admission/result/stdout/stderr are retained
in `continuity-supervisor-injected-fac4b86-v1/`. Original 30-second work limit,
one five-second grace, resource limits and shared lock were preserved.

These tests mock process creation, signals, identity observations and reaping.
They do not establish real-process cleanup, unseen descendant containment,
host import qualification or adapter continuity. The expected terminal-record
failure diagnostic remains in stderr, followed by that control's successful
assertion. A passing negative control does not mean the simulated operation
succeeded. No configured stage, formatter or complete suite was dispatched.

## Required preserving source repairs

1. Before launch, validate the SIGCHLD disposition required by the unreaped
   direct-child PID fallback. A comment asserting default disposition does not
   establish it; inherited SIG_IGN can defeat PID reservation. Keep exclusive
   reaping an explicit environmental premise. Reject unsupported disposition
   before Popen, and retain the typed reason. Do not silently normalize the
   signal policy or infer the premise from a passing pidfd mock.
2. In enroll(), retain both the primary identity/revalidation failure and an
   acquired-handle close failure. Current os.close can replace the primary
   exception and lose the handle's unresolved state. Retain enough bounded
   recovery data for the external observer. Do not blindly retry a failed
   close: the descriptor may already have been released and reused.
3. In inventory(), attempt iterator cleanup and descriptor cleanup independently
   on both exhaustion and exceptional unwinding. An iterator.close failure must
   not skip the descriptor attempt. Preserve the primary traversal failure plus
   cleanup errors, distinguish attempted from confirmed cleanup, and avoid
   repeating ambiguous closes of a potentially reused descriptor.
4. Add deterministic controls for nondefault SIGCHLD (no launch), revalidation
   plus handle-close failure, and iterator-close failure on exhausted and
   exceptional traversal. Verify both retained failure identities and the
   independently attempted cleanup. Preserve all existing controls and caps.

Keep corrections inside the existing reserved stage/evidence/documentation
paths; keep adapter, providers and original formatter sources unchanged.
Regenerate pins, preserve rejected source and raw receipts, and run the same
strict analysis on changed sources and held inline commands. No new exception
waiver or enlarged resource allowance follows from this disposition.

## Following boundary

After exact source readback, source review and admitted injected controls,
define the external terminal observer and its failed-record recovery evidence.
Only then consider one current preflight stage; original and adapted formatter
stages require separate qualification. No full92, native/actor execution,
private transcript capture, spending, privileged operation, install, merge or
release is authorized by this narrow stage decision. All mission gates remain.

Parent may relay this durable disposition to the existing worker. No tool
message was sent to parent or worker; no competing writer was introduced.

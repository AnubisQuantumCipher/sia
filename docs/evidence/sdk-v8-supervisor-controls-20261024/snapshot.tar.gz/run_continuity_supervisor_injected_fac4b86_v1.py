"""One injected supervisor-control run; never execute configured stages."""
import datetime
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'continuity-supervisor-injected-fac4b86-v1'
SOURCE = Path('/home/sicarii/Documents/Codex/2026-10-24/task/sia-codex-adapter/docs/evidence/codex-continuity-adapter-20261024/stage-packet-v1')
NAMES = ('supervise.py', 'test_supervisor_controls.py')
FIELDS = ('st_dev', 'st_ino', 'st_mode', 'st_uid', 'st_gid', 'st_nlink', 'st_size', 'st_mtime_ns', 'st_ctime_ns')


def pins():
    return {name: {'sha256': hashlib.sha256((SOURCE / name).read_bytes()).hexdigest(),
                   'identity': {key: getattr((SOURCE / name).stat(), key) for key in FIELDS}}
            for name in NAMES}


def main():
    if (OUT / 'admission.json').exists():
        raise FileExistsError('preserve existing observation')
    command = ['/usr/bin/flock', '-F', '-n', '-E', '75', '/home/sicarii/.worldline-heavy.lock',
               '/usr/bin/prlimit', '--as=2147483648:2147483648', '--fsize=536870912:536870912', '--core=0:0', '--',
               '/usr/bin/timeout', '--signal=TERM', '--kill-after=5s', '30s', '/usr/bin/bwrap',
               '--ro-bind', '/', '/', '--tmpfs', '/tmp', '--tmpfs', '/home', '--ro-bind', str(SOURCE), str(SOURCE),
               '--tmpfs', '/run', '--proc', '/proc', '--dev', '/dev', '--dir', '/home/audit',
               '--unshare-net', '--unshare-pid', '--die-with-parent', '--new-session', '--chdir', str(SOURCE),
               '/usr/bin/python3.14', '-I', '-B', '-Werror', '-m', 'unittest', 'discover',
               '-s', str(SOURCE), '-p', 'test_supervisor_controls.py', '-v']
    environment = {'HOME': '/home/audit', 'LANG': 'C', 'LC_ALL': 'C', 'PATH': '/usr/bin:/bin',
                   'PYTHONDONTWRITEBYTECODE': '1', 'TMPDIR': '/tmp', 'TZ': 'UTC'}
    record = {'utc': datetime.datetime.now(datetime.UTC).isoformat(), 'command': command,
              'environment': environment, 'source_before': pins(),
              'scope': 'Injected controls only; processes, signals and reaping mocked. No real stage dispatch.',
              'runner_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              'outer_observation_seconds': 40}
    (OUT / 'admission.json').write_text(json.dumps(record, indent=2) + '\n')
    try:
        result = subprocess.run(command, env=environment, capture_output=True, timeout=40, check=False)
        stdout, stderr, code = result.stdout, result.stderr, result.returncode
    except subprocess.TimeoutExpired as error:
        stdout, stderr, code = error.stdout or b'', error.stderr or b'', 124
    (OUT / 'stdout').write_bytes(stdout)
    (OUT / 'stderr').write_bytes(stderr)
    record.update(exit=code, source_after=pins(), stdout_sha256=hashlib.sha256(stdout).hexdigest(),
                  stderr_sha256=hashlib.sha256(stderr).hexdigest())
    record['source_unchanged'] = record['source_before'] == record['source_after']
    (OUT / 'result.json').write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps({'exit': code, 'source_unchanged': record['source_unchanged'], 'stderr': stderr.decode()}))
    return code if record['source_unchanged'] else 1


if __name__ == '__main__':
    raise SystemExit(main())

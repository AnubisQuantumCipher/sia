"""UNRUN injected source controls. No real process qualification is implied."""
import importlib.util
from pathlib import Path
import unittest
import tempfile
import json
from contextlib import ExitStack
from unittest.mock import Mock
from unittest.mock import patch

SPEC = importlib.util.spec_from_file_location('stage_supervisor', Path(__file__).with_name('supervise.py'))
SUP = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(SUP)


class SupervisorControls(unittest.TestCase):
    def run_terminal(self, *, launch_error=False, identity_error=False,
                     inventory_error=False, receipt_error=False, clock=0, live_states=None, times=None, interrupted=False, descendant=False, vanished=False, sigchld=None):
        with tempfile.TemporaryDirectory() as directory, ExitStack() as stack:
            plan = {'output': str(Path(directory) / 'output'), 'command': ['inert'],
                    'cwd': directory, 'environment': {}}
            child = Mock(pid=101)
            child.wait.return_value = 0
            limits = {SUP.resource.RLIMIT_AS: (2147483648, 2147483648),
                      SUP.resource.RLIMIT_FSIZE: (536870912, 536870912),
                      SUP.resource.RLIMIT_CORE: (0, 0)}
            stack.enter_context(patch.object(SUP.resource, 'getrlimit', side_effect=limits.__getitem__))
            stack.enter_context(patch.object(SUP.sys, 'flags', Mock(isolated=True)))
            stack.enter_context(patch.object(SUP.sys, 'dont_write_bytecode', True))
            stack.enter_context(patch.object(SUP.sys, 'warnoptions', ['error']))
            stack.enter_context(patch.object(SUP.sys, 'argv', ['supervise', 'root-profile']))
            stack.enter_context(patch.object(SUP.sys, 'stdout', Mock()))
            stack.enter_context(patch.object(SUP, 'admission', return_value=plan))
            stack.enter_context(patch.object(SUP.time, 'monotonic', side_effect=times if times is not None else [0] + [clock] * 100))
            launch = stack.enter_context(patch.object(SUP.subprocess, 'Popen',
                side_effect=OSError if launch_error else None, return_value=child))
            stack.enter_context(patch.object(SUP.os, 'pidfd_open',
                side_effect=OSError if identity_error else [7, 9]))
            stack.enter_context(patch.object(SUP.signal, 'getsignal',
                return_value=SUP.signal.SIG_DFL if sigchld is None else sigchld))
            stack.enter_context(patch.object(SUP.os, 'close'))
            signaling = stack.enter_context(patch.object(SUP.signal, 'pidfd_send_signal',
                side_effect=ProcessLookupError if vanished else None))
            stack.enter_context(patch.object(SUP.time, 'sleep'))
            kill = stack.enter_context(patch.object(SUP.os, 'kill'))
            stack.enter_context(patch.object(SUP, 'proc', return_value={'pid': 101, 'ppid': 1, 'starttime': 2}))
            def observation(known, deadline):
                if interrupted:
                    raise KeyboardInterrupt
                if descendant:
                    known[202] = {'pid': 202, 'ppid': 101, 'starttime': 3, 'handle': 8}
            descendant_readiness = iter([True, False])
            def readiness(handle):
                if handle == 8:
                    return next(descendant_readiness)
                return False
            stack.enter_context(patch.object(SUP, 'observe', side_effect=observation))
            stack.enter_context(patch.object(SUP, 'live',
                side_effect=readiness if descendant else live_states, return_value=False))
            stack.enter_context(patch.object(SUP, 'inventory',
                side_effect=ValueError if inventory_error else None, return_value={}))
            if receipt_error:
                stack.enter_context(patch.object(SUP, 'save', side_effect=OSError))
            result = SUP.main()
            terminal = Path(directory) / 'output-terminal-outcome.json'
            self.outcome = json.loads(terminal.read_text()) if terminal.exists() else None
            self.signals = signaling.call_args_list
            return result, launch.call_count, kill.call_count, child.wait.call_count

    def test_normal_exit(self):
        self.assertEqual(self.run_terminal(), (0, 1, 0, 1))

    def test_launch_failure(self):
        self.assertEqual(self.run_terminal(launch_error=True), (1, 1, 0, 0))

    def test_initial_identity_failure_retains_unreaped_child(self):
        self.assertEqual(self.run_terminal(identity_error=True), (1, 1, 1, 1))

    def test_terminal_deadline_prevents_launch(self):
        self.assertEqual(self.run_terminal(clock=35), (1, 0, 0, 0))

    def test_inventory_failure_nonpass(self):
        self.assertEqual(self.run_terminal(inventory_error=True)[0], 1)

    def test_receipt_failure_nonpass(self):
        self.assertEqual(self.run_terminal(receipt_error=True)[0], 1)

    def test_leader_exit_with_observed_child(self):
        self.assertEqual(self.run_terminal(descendant=True), (1, 1, 0, 1))
        self.assertEqual(self.signals[0].args, (8, SUP.signal.SIGKILL))
        self.assertIn('owned identity remained after stage', self.outcome['errors'])
        self.assertEqual(self.outcome['recovery_debt'], [])

    def test_disappearance_during_cleanup(self):
        self.assertEqual(self.run_terminal(descendant=True, vanished=True), (1, 1, 0, 1))
        self.assertEqual(self.signals[0].args, (8, SUP.signal.SIGKILL))
        self.assertIn('cleanup:ProcessLookupError', self.outcome['errors'])
        self.assertEqual(self.outcome['recovery_debt'], [{'pid': 202, 'starttime': 3}])

    def test_work_deadline_exhaustion(self):
        self.assertEqual(self.run_terminal(times=[0, 0] + [30] * 100)[0], 1)

    def test_interruption_records_nonpass(self):
        self.assertEqual(self.run_terminal(interrupted=True)[0], 1)

    def test_ignored_sigchld_refuses_without_reset_or_launch(self):
        with patch.object(SUP.signal, 'signal', side_effect=AssertionError('reset policy')):
            self.assertEqual(self.run_terminal(sigchld=SUP.signal.SIG_IGN), (1, 0, 0, 0))
        self.assertIn('startup/work:SignalDispositionError', self.outcome['errors'])

    def test_custom_sigchld_refuses(self):
        self.assertEqual(self.run_terminal(sigchld=Mock()), (1, 0, 0, 0))

    def test_revalidation_and_handle_close_failure_retained(self):
        row = {'pid': 101, 'ppid': 1, 'starttime': 2}
        known = {}
        with patch.object(SUP.os, 'pidfd_open', return_value=7), \
                patch.object(SUP, 'proc', side_effect=ValueError('read shape')), \
                patch.object(SUP.os, 'close', side_effect=OSError('ambiguous')) as close:
            with self.assertRaises(SUP.OwnershipError) as raised:
                SUP.enroll(known, row)
        self.assertEqual(raised.exception.row, row)
        self.assertEqual(raised.exception.recovery['primary'], {'type': 'ValueError'})
        self.assertEqual(raised.exception.recovery['cleanup'], [
            {'kind': 'descriptor', 'descriptor': 7, 'attempted': True,
             'confirmed': False, 'error': 'OSError'}])
        close.assert_called_once_with(7)
        self.assertEqual(known, {})

    def inventory_close_failure(self, traversal_error):
        iterator = Mock()
        iterator.__next__ = Mock(side_effect=traversal_error)
        iterator.close.side_effect = OSError('iterator close')
        with patch.object(SUP.os, 'open', return_value=3), \
                patch.object(SUP.os, 'scandir', return_value=iterator), \
                patch.object(SUP.os, 'close') as close, \
                patch.object(SUP.time, 'monotonic', return_value=0):
            with self.assertRaises(SUP.InventoryError) as raised:
                SUP.inventory(Path('/unused'), 35)
        iterator.close.assert_called_once()
        close.assert_called_once_with(3)
        self.assertEqual(raised.exception.detail['cleanup'], [
            {'kind': 'iterator', 'descriptor': 3, 'attempted': True,
             'confirmed': False, 'error': 'OSError'},
            {'kind': 'descriptor', 'descriptor': 3, 'attempted': True,
             'confirmed': True, 'error': None}])
        return raised.exception.detail

    def test_exhausted_iterator_close_still_closes_descriptor(self):
        self.assertEqual(self.inventory_close_failure(StopIteration)['primary'],
                         {'type': 'ValueError'})

    def test_traversal_failure_preserved_through_iterator_close(self):
        self.assertEqual(self.inventory_close_failure(RuntimeError('traversal'))['primary'],
                         {'type': 'RuntimeError'})

    def test_exact_capacity_duplicate(self):
        known = {n: {'pid': n, 'starttime': n, 'handle': n} for n in range(64)}
        with patch.object(SUP.os, 'pidfd_open', side_effect=AssertionError('new handle')):
            SUP.enroll(known, {'pid': 1, 'starttime': 1})
        self.assertEqual(len(known), 64)

    def test_pid_reuse_preserves_old_handle(self):
        known = {1: {'pid': 1, 'starttime': 2, 'handle': 3}}
        with self.assertRaises(ValueError):
            SUP.enroll(known, {'pid': 1, 'starttime': 4})
        self.assertEqual(known[1]['handle'], 3)

    def test_new_identity_at_capacity_refused(self):
        known = {n: {'pid': n, 'starttime': n, 'handle': n} for n in range(64)}
        with self.assertRaises(ValueError):
            SUP.enroll(known, {'pid': 100, 'starttime': 1})

    def test_handle_acquisition_failure(self):
        known = {}
        with patch.object(SUP.os, 'pidfd_open', side_effect=OSError), self.assertRaises(SUP.OwnershipError):
            SUP.enroll(known, {'pid': 1, 'starttime': 2})
        self.assertEqual(known, {})

    def test_deadline_is_absolute(self):
        with patch.object(SUP.time, 'monotonic', return_value=35), self.assertRaises(ValueError):
            SUP.expired(35)

    def test_vanished_kernel_handle(self):
        with patch.object(SUP.select, 'select', return_value=([3], [], [])):
            self.assertFalse(SUP.live(3))

    def test_inventory_expiry_before_enumeration(self):
        with patch.object(SUP.os, 'open', return_value=3), patch.object(SUP.os, 'close'), \
                patch.object(SUP.os, 'scandir') as scan, \
                patch.object(SUP.time, 'monotonic', return_value=35), self.assertRaises(ValueError):
            SUP.inventory(Path('/unused'), 35)
        scan.return_value.__next__.assert_not_called()

    def test_receipt_failure_propagates(self):
        with patch.object(Path, 'open', side_effect=OSError), self.assertRaises(OSError):
            SUP.save(Path('/unused'), {'status': 'NONPASS'})


if __name__ == '__main__':
    unittest.main()

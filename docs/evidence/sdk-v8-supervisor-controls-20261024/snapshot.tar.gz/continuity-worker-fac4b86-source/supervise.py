"""UNRUN stage supervisor design. Requires separate exact owner admission.

Adapted sampled PID/starttime lineage from retained outer-dispatch reference.
No hostile descendant containment or continuous custody claim. No auto-next.
"""
from pathlib import Path
import hashlib
import json
import os
import signal
import select
import resource
import stat
import subprocess
import sys
import time

PACKET = Path(__file__).resolve().parent


def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


def proc(pid):
    with (Path('/proc') / str(pid) / 'stat').open('rb') as stream:
        raw = stream.read(4097)
    if len(raw) > 4096:
        raise ValueError('proc bound')
    end = raw.rfind(b')')
    fields = raw[end + 2:].split()
    if end < 0 or len(fields) < 20:
        raise ValueError('proc shape')
    return {'pid': pid, 'ppid': int(fields[1]), 'starttime': int(fields[19])}


def expired(deadline):
    if time.monotonic() >= deadline:
        raise ValueError('terminal deadline')


def live(handle):
    return not select.select([handle], [], [], 0)[0]


class OwnershipError(ValueError):
    def __init__(self, reason, row, recovery=None):
        super().__init__(reason)
        self.row = row
        self.recovery = recovery


def enroll(known, row):
    old = known.get(row['pid'])
    if old is not None:
        if old['starttime'] == row['starttime']:
            return
        # Never discard the previous kernel identity to make room for reuse.
        raise OwnershipError('PID reuse: retained identity and recovery debt', row)
    if len(known) >= 64:
        raise OwnershipError('owned lineage bound', row)
    try:
        handle = os.pidfd_open(row['pid'])
    except OSError as error:
        raise OwnershipError('handle acquisition failure', row) from error
    try:
        if proc(row['pid']) != row:
            raise OwnershipError('identity changed during handle acquisition', row)
        known[row['pid']] = dict(row, handle=handle)
    except (OSError, ValueError) as error:
        cleanup = []
        close_once(handle, None, cleanup)
        raise OwnershipError('identity acquisition reconciliation failure', row,
                             {'primary': failure(error), 'cleanup': cleanup}) from error


def observe(known, deadline):
    for parent in tuple(known.values()):
        expired(deadline)
        if not live(parent['handle']):
            continue
        pid = parent['pid']
        try:
            with (Path('/proc') / str(pid) / 'task' / str(pid) / 'children').open('rb') as stream:
                raw = stream.read(4097)
            if len(raw) > 4096:
                raise ValueError('child roster bound')
            for token in raw.split():
                expired(deadline)
                child = proc(int(token))
                if child['ppid'] != pid:
                    raise ValueError('lineage changed')
                enroll(known, child)
        except (FileNotFoundError, ProcessLookupError):
            continue


class InventoryError(ValueError):
    def __init__(self, primary, cleanup):
        super().__init__('inventory traversal/cleanup failure')
        self.detail = {'primary': primary, 'cleanup': cleanup}


class SignalDispositionError(ValueError):
    pass


def failure(error):
    if isinstance(error, InventoryError):
        return error.detail
    return {'type': type(error).__name__}


def close_once(descriptor, iterator, records):
    # Each owned resource is removed from its owner before calling this helper.
    # A failed close is ambiguous: never retry it, even during unwinding.
    for kind, action in (('iterator', None if iterator is None else iterator.close),
                         ('descriptor', None)):
        if kind == 'iterator' and action is None:
            continue
        row = {'kind': kind, 'descriptor': descriptor, 'attempted': True,
               'confirmed': False, 'error': None}
        records.append(row)
        try:
            if kind == 'descriptor':
                os.close(descriptor)
            else:
                action()
            row['confirmed'] = True
        except (OSError, ValueError) as error:
            row['error'] = type(error).__name__


def inventory(root, deadline):
    rows, total = {}, 0
    # Streaming scandir: check before next(), never accumulate directory lists.
    # Depth and open descriptor count have the same explicit bound.
    root_fd = os.open(root, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    stack, cleanup = [], []
    primary = None
    try:
        try:
            root_iterator = os.scandir(root_fd)
        except BaseException:
            close_once(root_fd, None, cleanup)
            raise
        stack.append((root_fd, root_iterator, ''))
        while stack:
            expired(deadline)
            directory_fd, iterator, prefix = stack[-1]
            try:
                entry = next(iterator)
            except StopIteration:
                stack.pop()
                close_once(directory_fd, iterator, cleanup)
                if any(not row['confirmed'] for row in cleanup):
                    raise ValueError('inventory exhausted resource cleanup')
                cleanup.clear()
                continue
            if len(rows) >= 20000:
                raise ValueError('inventory node bound')
            name = entry.name
            relative = prefix + name
            info = os.stat(name, dir_fd=directory_fd, follow_symlinks=False)
            if not (stat.S_ISDIR(info.st_mode) or stat.S_ISREG(info.st_mode)):
                raise ValueError('inventory nonregular object')
            row = {'mode': info.st_mode, 'bytes': info.st_size}
            rows[relative] = row
            descriptor = os.open(name, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK,
                                 dir_fd=directory_fd)
            try:
                opened = os.fstat(descriptor)
                if (opened.st_dev, opened.st_ino, opened.st_mode, opened.st_size) != (info.st_dev, info.st_ino, info.st_mode, info.st_size):
                    raise ValueError('inventory source replaced')
                if stat.S_ISDIR(info.st_mode):
                    if len(stack) >= 64:
                        raise ValueError('inventory descriptor/depth bound')
                    iterator_new = os.scandir(descriptor)
                    stack.append((descriptor, iterator_new, relative + '/'))
                    descriptor = None
                else:
                    if info.st_size > 536870912 - total:
                        raise ValueError('inventory aggregate byte bound')
                    digest, consumed = hashlib.sha256(), 0
                    while consumed < info.st_size:
                        expired(deadline)
                        data = os.read(descriptor, min(65536, info.st_size - consumed))
                        if not data:
                            raise ValueError('inventory short read')
                        consumed += len(data)
                        digest.update(data)
                    after = os.fstat(descriptor)
                    if (opened.st_size, opened.st_mtime_ns, opened.st_ctime_ns) != (after.st_size, after.st_mtime_ns, after.st_ctime_ns):
                        raise ValueError('inventory changed')
                    total += consumed
                    row['sha256'] = digest.hexdigest()
            finally:
                if descriptor is not None:
                    close_once(descriptor, None, cleanup)
                    if sys.exception() is None and any(not row['confirmed'] for row in cleanup):
                        raise ValueError('inventory file cleanup')
                    if sys.exception() is None:
                        cleanup.clear()
    except BaseException as error:
        primary = error
    finally:
        while stack:
            descriptor, iterator, _ = stack.pop()
            close_once(descriptor, iterator, cleanup)
    if primary is not None or any(not row['confirmed'] for row in cleanup):
        raise InventoryError(None if primary is None else failure(primary), cleanup) from primary
    return rows


def bounded_json(path):
    with path.open('rb') as stream:
        raw = stream.read(262145)
    if len(raw) > 262144:
        raise ValueError('plan/admission byte bound')
    return raw, json.loads(raw)


def admission(stage):
    raw, stages = bounded_json(PACKET / 'stages.json')
    _, approved = bounded_json(PACKET / 'owner-admission.json')
    if stage not in ('root-profile', 'child-profile', 'formatter-profile',
                     'original-formatter', 'adapted-formatter'):
        raise ValueError('stage unavailable')
    if type(stages) is not dict or type(stages.get('stages')) is not dict:
        raise ValueError('plan shape')
    plan = stages['stages'][stage]
    if type(plan) is not dict:
        raise ValueError('selected shape')
    command, environment = plan.get('command'), plan.get('environment')
    if (type(command) is not list or not 1 <= len(command) <= 64 or
            any(type(v) is not str or len(v) > 65536 for v in command) or
            type(environment) is not dict or len(environment) > 32 or
            any(type(k) is not str or type(v) is not str or len(k) > 128 or len(v) > 4096
                for k, v in environment.items()) or
            any(type(plan.get(k)) is not str or len(plan[k]) > 4096 for k in ('cwd', 'output')) or
            any(type(plan.get(k)) is not int or plan[k] != v for k, v in
                (('work_seconds', 30), ('supervisor_seconds', 35), ('kill_reap_grace_seconds', 5)))):
        raise ValueError('selected field shape')
    if (type(approved) is not dict or set(approved) != {'stage', 'stages_sha256', 'selected'} or
            approved['stage'] != stage or approved['stages_sha256'] != hashlib.sha256(raw).hexdigest() or
            approved['selected'] != {k: plan[k] for k in ('command', 'environment', 'cwd')}):
        raise ValueError('exact admission required')
    return plan


def main():
    started = time.monotonic()
    work_deadline, deadline = started + 30, started + 35
    errors, known = [], {}
    child, direct_handle, code, root = None, None, None, None
    created = False
    outcome = {'status': 'NONPASS', 'acceptance': False, 'errors': errors,
               'recovery_debt': [], 'exit': None}
    try:
        for kind, ceiling in ((resource.RLIMIT_AS, 2147483648),
                              (resource.RLIMIT_FSIZE, 536870912), (resource.RLIMIT_CORE, 0)):
            if resource.getrlimit(kind) != (ceiling, ceiling):
                raise ValueError('supervisor resource limits')
        if not sys.flags.isolated or not sys.dont_write_bytecode or sys.warnoptions != ['error']:
            raise ValueError('supervisor interpreter flags')
        if len(sys.argv) != 2:
            raise ValueError('stage argument')
        plan = admission(sys.argv[1])
        root = Path(plan['output'])
        root.mkdir(mode=0o700, exist_ok=False)
        created = True
        for leaf in ('home', 'tmp', 'cache', 'config', 'data', 'runtime', 'state'):
            (root / leaf).mkdir(mode=0o700)
        with (root / 'stdout.raw').open('xb') as out, (root / 'stderr.raw').open('xb') as err:
            expired(work_deadline)
            if signal.getsignal(signal.SIGCHLD) != signal.SIG_DFL:
                raise SignalDispositionError('unsupported inherited SIGCHLD disposition')
            child = subprocess.Popen(plan['command'], cwd=plan['cwd'], env=plan['environment'],
                stdin=subprocess.DEVNULL, stdout=out, stderr=err, close_fds=True, start_new_session=True)
            # Single reaper: never poll()/wait() until reconciliation is over.
            # Unreaped direct child reserves PID even if initial pidfd/proc fails.
            direct_handle = os.pidfd_open(child.pid)
            enroll(known, proc(child.pid))
            while time.monotonic() < work_deadline:
                observe(known, work_deadline)
                if not live(direct_handle):
                    break
                time.sleep(min(0.1, max(0, work_deadline - time.monotonic())))
            else:
                errors.append('work deadline exhausted')
    except (OSError, ValueError, KeyError, TypeError, subprocess.SubprocessError, KeyboardInterrupt) as error:
        errors.append('startup/work:' + type(error).__name__)
        if isinstance(error, OwnershipError):
            outcome['recovery_debt'].append(error.row)
            if error.recovery is not None:
                outcome['recovery_debt'].append(error.recovery)
    finally:
        # All signaling uses pidfds except the unreaped direct-child fallback.
        # No Popen poll/kill: those can reap implicitly. No SIGCHLD handler or
        # competing reaper is allowed by this single-threaded process contract.
        for row in known.values():
            try:
                expired(deadline)
                if live(row['handle']):
                    errors.append('owned identity remained after stage')
                    signal.pidfd_send_signal(row['handle'], signal.SIGKILL)
            except (OSError, ValueError) as error:
                errors.append('cleanup:' + type(error).__name__)
                outcome['recovery_debt'].append({k: row[k] for k in ('pid', 'starttime')})
        if child is not None:
            try:
                expired(deadline)
                if direct_handle is None:
                    os.kill(child.pid, signal.SIGKILL)  # Unreaped exclusive direct-child identity.
                elif live(direct_handle):
                    signal.pidfd_send_signal(direct_handle, signal.SIGKILL)
                for row in known.values():
                    while live(row['handle']):
                        expired(deadline)
                        time.sleep(min(0.01, max(0, deadline - time.monotonic())))
                code = child.wait(timeout=max(0, deadline - time.monotonic()))
            except (OSError, ValueError, subprocess.SubprocessError) as error:
                errors.append('reconciliation:' + type(error).__name__)
                outcome['recovery_debt'].append({'direct_child': child.pid, 'identity': 'unreaped child or retained pidfd'})
        outcome['exit'] = code
        outcome['observed_owned'] = [{k: row[k] for k in ('pid', 'ppid', 'starttime')} for row in known.values()]
        for handle in [row['handle'] for row in known.values()] + ([] if direct_handle is None else [direct_handle]):
            try:
                os.close(handle)
            except OSError as error:
                errors.append('handle close:' + type(error).__name__)
        try:
            expired(deadline)
            if created:
                save(root / 'receipt.json', outcome)
                outcome['inventory'] = inventory(root, deadline)
        except (OSError, ValueError, TypeError) as error:
            errors.append('receipt/inventory:' + type(error).__name__)
            if isinstance(error, InventoryError):
                outcome['recovery_debt'].append(error.detail)
        if not errors and code == 0:
            outcome['status'] = 'RAW_REQUIRES_POSTFLIGHT_AUDIT'
        # One terminal protocol, including admission failures. The caller MUST
        # capture raw stdout/stderr and externally record missing/truncated JSON,
        # signal exit, deadline/record failure as NONPASS with recovery debt.
        try:
            expired(deadline)
            raw = json.dumps(outcome, sort_keys=True).encode() + b'\n'
            if len(raw) > 8388608:
                raise ValueError('terminal record bound')
            if created:
                with root.with_name(root.name + '-terminal-outcome.json').open('xb') as stream:
                    stream.write(raw)
            expired(deadline)
            sys.stdout.buffer.write(raw)
            sys.stdout.buffer.flush()
        except (OSError, ValueError, TypeError) as error:
            # External observer owns final record if this channel also fails.
            errors.append('terminal record:' + type(error).__name__)
            try:
                os.write(2, b'NONPASS terminal record unavailable; external recovery required\n')
            except OSError:
                pass
    return 1 if errors or code != 0 else 0


if __name__ == '__main__':
    raise SystemExit(main())

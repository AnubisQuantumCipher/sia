"""Bounded coarse phase observation; instrumentation is not acceptance."""
from contextlib import ExitStack
import json
from pathlib import Path
import sys
import time
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parent.parent
SELECTOR = ('test_graph_additions.GraphAdditions.'
            'test_persistent_late_insert_replace_both_keys_every_frontier')
sys.path.insert(0, str(ROOT / 'sdk-loop-finally-v8'))


def timed(original, row):
    def invoke(*args, **kwargs):
        if row['calls'] >= 262144:
            raise ValueError('phase observation call bound')
        row['calls'] += 1
        start = time.perf_counter_ns()
        try:
            return original(*args, **kwargs)
        finally:
            row['inclusive_ns'] += time.perf_counter_ns() - start
    return invoke


def main():
    suite = unittest.defaultTestLoader.loadTestsFromName(SELECTOR)
    if suite.countTestCases() != 1:
        raise ValueError('fixed diagnostic selector')
    support = sys.modules['test_support']
    cases = sys.modules['test_graph_additions']
    bindings = ((support.Harness, '__init__'), (support.Harness, 'positive'),
                (support.Harness, 'close'), (cases.GraphAdditions, 'late_case'),
                (support.CHECKER.DerivedChecker, 'clear_scratch'))
    rows = []
    with ExitStack() as stack:
        for owner, name in bindings:
            row = {'phase': owner.__name__ + '.' + name,
                   'calls': 0, 'inclusive_ns': 0}
            rows.append(row)
            stack.enter_context(patch.object(owner, name, timed(getattr(owner, name), row)))
        result = unittest.TextTestRunner(verbosity=2).run(suite)
    report = {'selector': SELECTOR, 'tests': result.testsRun,
              'successful': result.wasSuccessful(), 'rows': rows,
              'scope': 'Five temporary method wrappers call the captured originals. '
                       'All original cases run. Inclusive nested intervals overlap; '
                       'do not sum them. Instrumentation and callbacks affect timing; '
                       'not full-suite, native, semantic or WCET acceptance.'}
    payload = json.dumps(report, indent=2)
    if len(payload.encode()) > 65536:
        raise ValueError('phase report byte bound')
    print(payload)
    return 0 if result.wasSuccessful() else 1


if __name__ == '__main__':
    raise SystemExit(main())

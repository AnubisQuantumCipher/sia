"""Instrument one unchanged frontier fixture; diagnostic, not acceptance."""
import cProfile
import json
from pathlib import Path
import sys
import unittest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / 'sdk-loop-finally-v8'))
SELECTOR = ('test_graph_additions.GraphAdditions.'
            'test_persistent_late_insert_replace_both_keys_every_frontier')


def rows(profile):
    entries = profile.getstats()
    if len(entries) > 4096:
        raise ValueError('profile entry capacity')
    output = []
    for entry in entries:
        code = entry.code
        if type(code) is str:
            name, filename, line = code, 'builtin', 0
        else:
            name, filename, line = code.co_name, code.co_filename, code.co_firstlineno
        if len(name) > 1024 or len(filename) > 4096:
            raise ValueError('profile label capacity')
        output.append({'name': name, 'file': filename, 'line': line,
                       'calls': entry.callcount, 'recursive_calls': entry.reccallcount,
                       'total_seconds': entry.totaltime, 'own_seconds': entry.inlinetime})
    return sorted(output, key=lambda row: row['own_seconds'], reverse=True)


def main():
    suite = unittest.defaultTestLoader.loadTestsFromName(SELECTOR)
    if suite.countTestCases() != 1:
        raise ValueError('fixed diagnostic selector')
    profile = cProfile.Profile()
    profile.enable()
    try:
        result = unittest.TextTestRunner(verbosity=2).run(suite)
    finally:
        profile.disable()
    report = {'selector': SELECTOR, 'successful': result.wasSuccessful(),
              'tests': result.testsRun, 'rows': rows(profile),
              'scope': 'Instrumented complete frontier method only; profiler overhead included. '
                       'Not full-suite timing, WCET, native or semantic qualification.'}
    payload = json.dumps(report, indent=2)
    if len(payload.encode()) > 1048576:
        raise ValueError('profile report capacity')
    print(payload)
    return 0 if result.wasSuccessful() else 1


if __name__ == '__main__':
    raise SystemExit(main())

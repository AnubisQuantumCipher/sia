"""All-call sweep preservation, including finalizer-driven changes."""
import importlib.util
from pathlib import Path
import sys
import unittest

from test_support import CHECKER, PROBE


def baseline():
    path = Path(__file__).parent.parent / 'sdk-scratch-sweep-v4/production_checker.py'
    spec = importlib.util.spec_from_file_location('before_empty_noop', path)
    if spec is None or spec.loader is None:
        raise RuntimeError('baseline loader unavailable')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


ORIGINAL = baseline()


def mutated_cell(sequence, index):
    raise OSError('mutated retirement', index)


class EmptyRetirement(unittest.TestCase):
    def observe(self, module, effect):
        sequence, calls, released = [None] * 8192, [], []
        state = PROBE.ProbeState()
        original = module.retire_reference_cell
        code = original.__code__

        def replacement(array, index):
            calls.append(index)
            original(array, index)
            if index == 9:
                module.retire_reference_cell = original

        class Retired:
            def __del__(self):
                released.append(sequence[4] is None)
                if effect == 'helper-restore':
                    module.retire_reference_cell = replacement
                elif effect == 'code':
                    original.__code__ = mutated_cell.__code__
                elif effect == 'shrink':
                    sequence.clear()
                elif effect == 'later':
                    sequence[8191] = 'late'
                elif effect == 'earlier':
                    sequence[0] = 'earlier'
                else:
                    raise AssertionError('unknown test effect')

        sequence[4] = Retired()
        try:
            module.retire_reference_array(sequence, module.DerivedClearGuard(state, 'scratch-clear'))
        finally:
            module.retire_reference_cell = original
            original.__code__ = code
        self.assertEqual(released, [True])
        return {'sequence': tuple(sequence), 'calls': calls, 'used': state.used,
                'overflow': state.overflow,
                'errors': [(state.phases[i], type(state.raw[i]).__name__, state.raw[i].args)
                           for i in range(state.used)]}

    def compare(self, effect):
        expected = self.observe(ORIGINAL, effect)
        for module in (CHECKER, PROBE):
            with self.subTest(module=module.__name__):
                self.assertEqual(self.observe(module, effect), expected)
        return expected

    def test_finalizer_replaces_helper_then_restores_eligibility(self):
        result = self.compare('helper-restore')
        self.assertEqual(result['calls'], [5, 6, 7, 8, 9])
        self.assertFalse(result['overflow'])
        self.assertEqual(result['used'], 0)

    def test_finalizer_mutates_code_and_retains_error_overflow(self):
        result = self.compare('code')
        self.assertEqual(result['used'], 64)
        self.assertTrue(result['overflow'])
        self.assertEqual(result['errors'][0], ('scratch-clear', 'OSError', ('mutated retirement', 5)))

    def test_finalizer_shrinks_list_and_keeps_assignment_errors(self):
        result = self.compare('shrink')
        self.assertEqual(result['sequence'], ())
        self.assertEqual(result['used'], 64)
        self.assertTrue(result['overflow'])
        self.assertEqual(result['errors'][0][1], 'IndexError')

    def test_finalizer_repopulates_later_empty_slot(self):
        result = self.compare('later')
        self.assertTrue(all(value is None for value in result['sequence']))

    def test_earlier_repopulation_remains_original_limitation(self):
        result = self.compare('earlier')
        self.assertEqual(result['sequence'][0], 'earlier')
        self.assertEqual(result['used'], 0)

    def counted_empty_calls(self, module):
        count = [0]
        code = module.retire_reference_cell.__code__
        state = PROBE.ProbeState()
        sequence = [None] * 8192

        def profile(frame, event, _argument):
            if event == 'call' and frame.f_code is code:
                count[0] += 1

        prior = sys.getprofile()
        sys.setprofile(profile)
        try:
            module.retire_reference_array(sequence, module.DerivedClearGuard(state, 'scratch-clear'))
        finally:
            sys.setprofile(prior)
        self.assertEqual(state.used, 0)
        self.assertFalse(state.overflow)
        self.assertTrue(all(value is None for value in sequence))
        return count[0]

    def test_empty_path_preserves_all_cell_calls(self):
        # A benign observation of path selection, not arbitrary tracing equivalence.
        self.assertEqual(self.counted_empty_calls(ORIGINAL), 8192)
        for module in (CHECKER, PROBE):
            self.assertEqual(self.counted_empty_calls(module), 8192)


if __name__ == '__main__':
    unittest.main()

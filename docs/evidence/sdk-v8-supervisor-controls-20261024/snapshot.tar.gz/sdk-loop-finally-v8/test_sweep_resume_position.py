"""Synthetic range-failure seam; not native allocator-failure qualification."""
import unittest
from unittest.mock import patch

from test_empty_retirement import ORIGINAL
from test_support import CHECKER, PROBE


class SweepResumePosition(unittest.TestCase):
    def observe(self, module, mode):
        calls, errors, starts = [], [], []
        sequence = [None] * 8192
        sequence[0], sequence[4096], sequence[8191] = object(), object(), object()
        state = PROBE.ProbeState()
        original = module.retire_reference_cell
        failed = [False]

        def cell(array, index):
            calls.append(index)
            original(array, index)

        class InterruptedRange:
            def __init__(self, start, end):
                self.cursor = iter(range(start, end))

            def __iter__(self):
                return self

            def __next__(self):
                value = next(self.cursor)
                if mode == 'iteration' and value == 4096 and not failed[0]:
                    failed[0] = True
                    error = MemoryError('synthetic next result unavailable')
                    errors.append(error)
                    raise error
                return value

        def ranges(*arguments):
            if len(arguments) == 1:
                return range(*arguments)
            starts.append(arguments[0])
            if mode == 'no-progress' or (mode == 'construction' and not failed[0]):
                failed[0] = True
                error = MemoryError('synthetic range unavailable')
                if len(errors) < 64:
                    errors.append(error)
                raise error
            return InterruptedRange(*arguments)

        with patch.object(module, 'range', ranges, create=True), \
                patch.object(module, 'retire_reference_cell', cell):
            module.retire_reference_array(sequence, module.DerivedClearGuard(state, 'scratch-clear'))
        for index, error in enumerate(errors):
            self.assertIs(state.raw[index], error)
            self.assertEqual(state.phases[index], 'scratch-clear')
        return calls, starts, state.used, state.overflow, all(value is None for value in sequence)

    def test_range_construction_failure_retries_first_unattempted_slot(self):
        for module in (ORIGINAL, CHECKER, PROBE):
            with self.subTest(module=module.__name__):
                calls, starts, used, overflow, cleared = self.observe(module, 'construction')
                self.assertEqual(calls, list(range(8192)))
                self.assertEqual(starts, [0, 0])
                self.assertEqual((used, overflow, cleared), (1, False, True))

    def test_iteration_failure_retries_unobtained_index(self):
        for module in (ORIGINAL, CHECKER, PROBE):
            with self.subTest(module=module.__name__):
                calls, starts, used, overflow, cleared = self.observe(module, 'iteration')
                self.assertEqual(calls, list(range(8192)))
                self.assertEqual(starts, [0, 4096])
                self.assertEqual((used, overflow, cleared), (1, False, True))

    def test_repeated_no_progress_exhausts_bound_without_cleanup_success(self):
        for module in (ORIGINAL, CHECKER, PROBE):
            with self.subTest(module=module.__name__):
                calls, starts, used, overflow, cleared = self.observe(module, 'no-progress')
                self.assertEqual(calls, [])
                self.assertEqual(starts, [0] * 8192)
                self.assertEqual((used, overflow, cleared), (64, True, False))


if __name__ == '__main__':
    unittest.main()

"""Retain bounded reproducible evidence for the test-only integration repair."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import re
import tarfile

OUT = Path(__file__).parent
REPO = Path('/home/sicarii/Work/sia-assurance-checkpoint-20261023')
SOURCES = {
    'original60': ('integration-test-scope-20261025-v1', (
        'run.py', 'candidate.json', 'candidate.patch', 'affected-inputs.json',
        'affected-result.json', 'affected.stdout', 'affected.stderr',
        'static.json', 'static.stdout', 'static.stderr', 'source-review.md',
        'final-consistency-review.md')),
    'tail60': ('integration-test-tail-diagnostic-20261025-v1', (
        'run.py', 'candidate.json', 'admission.json', 'tail-inputs.json',
        'tail-result.json', 'tail.stdout', 'tail.stderr', 'static.json',
        'static.stdout', 'static.stderr', 'review.md')),
    'approved120': ('integration-test-scope-20261025-v2', (
        'run.py', 'candidate.json', 'approval.json', 'admission.json',
        'affected-inputs.json', 'affected-result.json', 'affected.stdout',
        'affected.stderr', 'static.stdout', 'static.stderr', 'review.md',
        'REPORT.md', 'build_public.py', 'builder-static.json')),
}


def read(path):
    with path.open('rb') as stream:
        value = stream.read(2097153)
    if len(value) > 2097152:
        raise ValueError('member capacity')
    return value


def payloads():
    members = {}
    for prefix, (directory, names) in SOURCES.items():
        for name in names:
            members[prefix + '/' + name] = read(OUT.parent / directory / name)
    if len(members) > 64:
        raise ValueError('member count')
    pins = {name: hashlib.sha256(raw).hexdigest() for name, raw in members.items()}
    members['SHA256.json'] = (json.dumps(pins, indent=2, sort_keys=True) + '\n').encode()
    return members


def archive(members):
    target = io.BytesIO()
    with gzip.GzipFile(fileobj=target, mode='wb', filename='', mtime=0) as zipped:
        with tarfile.open(fileobj=zipped, mode='w', format=tarfile.USTAR_FORMAT) as tar:
            for name, raw in sorted(members.items()):
                entry = tarfile.TarInfo(name)
                entry.size, entry.mode = len(raw), 0o644
                tar.addfile(entry, io.BytesIO(raw))
    value = target.getvalue()
    if len(value) > 2097152:
        raise ValueError('archive capacity')
    return value


def main():
    members = payloads()
    raw = archive(members)
    if archive(members) != raw:
        raise ValueError('nonreproducible archive')
    result = json.loads(read(OUT / 'affected-result.json'))
    output = read(OUT / 'affected.stderr').decode()
    footer = re.search(r'\nRan (\d+) tests in ([\d.]+)s\n\nOK\n\Z', output)
    if footer is None or int(footer[1]) != 61 or result['exit'] != 0 or not result['unchanged']:
        raise ValueError('complete approved result missing')
    relative = 'docs/evidence/integration-test-scope-20261025.tar.gz'
    report = {
        'status': 'SELECTED_TEST_REPAIR_PASS_FULL_ASSURANCE_INCOMPLETE',
        'base_commit': result['base_commit'], 'tested_tree': result['source_tree'],
        'scope': 'Exact executable tree before three evidence-only additions',
        'tests': {'count': int(footer[1]), 'seconds': footer[2], 'exit': result['exit'],
                  'skips': 0, 'wrapper_ns': result['elapsed_ns']},
        'endpoint_pins': {'count': len(result['before']), 'unchanged': result['unchanged'],
                         'limit': 'Selected endpoints, not continuous loaded-code custody'},
        'static': 'Selected frozen 167-rule profile: zero findings; full-repository warnings not closed',
        'prior_results': 'Original 60s timeout retained; separate two-case diagnostic pass',
        'approval': 'Direct one-run 120s approval consumed; all other budgets unchanged',
        'archive': {'path': relative, 'sha256': hashlib.sha256(raw).hexdigest(),
                    'bytes': len(raw), 'members': len(members), 'reproduced': True},
        'review': 'Actual GPT-6.1 source/raw review; no independent execution',
        'remaining': 'All original A/G/C/P/R/EP obligations beyond this test-file repair, '
                     'including R05 BOTH, full proofs, custody, SDK, compaction, recovery, '
                     'retrieval, judge, installed qualification and release/marketplace',
    }
    with (REPO / relative).open('xb') as stream:
        stream.write(raw)
    with (REPO / 'docs/INTEGRATION-TEST-SCOPE-20261025.json').open('x') as stream:
        json.dump(report, stream, indent=2, sort_keys=True)
        stream.write('\n')
    with (REPO / 'docs/INTEGRATION-TEST-SCOPE-20261025.md').open('xb') as stream:
        stream.write(read(OUT / 'REPORT.md'))
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()

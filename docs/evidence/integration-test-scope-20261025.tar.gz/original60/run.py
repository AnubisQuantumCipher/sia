"""Verify strict test-scope repairs in the unchanged isolation envelope."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import time

OUT = Path(__file__).parent
SOURCE = Path('/home/sicarii/Work/sia-assurance-checkpoint-20261023')
HEAD = 'dc195aee736db59680c824f56a4c7f19c1306384'
TREE = 'abb5e13c3850eac98264d50ea3a903556d545a50'
ROSTERS = {'affected': ['tests.test_ollama_account_guard', 'tests.test_release.ReleaseContract.test_lifecycle_lease_blocks_install_and_uninstall', 'tests.test_release.ReleaseContract.test_managed_root_symlinks_are_refused_before_external_mutation', 'tests.test_release.ReleaseContract.test_installer_guard_refusal_precedes_state_mutation', 'tests.test_release.ReleaseContract.test_installer_refuses_nonempty_unowned_corpus', 'tests.test_marketplace_first_light.MarketplaceFirstLightTests.test_cockpit_discloses_guided_install_effects_and_downgrade_refusal', 'tests.test_install_memo_admission', 'tests.test_installer_bootstrap', 'tests.test_release.ReleaseContract.test_operator_docs_state_installer_and_removal_boundaries', 'tests.test_release.ReleaseContract.test_restore_supervisor_refuses_foreign_effective_unit_before_stop', 'tests.test_release.ReleaseContract.test_corpus_bootstrap_is_crash_resumable_and_no_clobber', 'tests.test_release.ReleaseContract.test_uninstall_archives_are_generation_bound_and_preserve_writers']}


def read_json(path):
    with path.open('rb') as stream:
        raw = stream.read(2097153)
    if len(raw) > 2097152:
        raise ValueError('receipt capacity')
    return json.loads(raw)


def hashes(paths):
    if len(paths) > 2048:
        raise ValueError('inventory capacity')
    result = {}
    for path in sorted(paths):
        if path.stat().st_size > 134217728:
            raise ValueError('input capacity')
        with path.open('rb') as stream:
            result[str(path)] = hashlib.file_digest(stream, 'sha256').hexdigest()
    return result


def prepare(mode):
    receipt_path = OUT.parent / 'r05-fresh-delivery-capture-v1/workload-result.json'
    receipt = read_json(receipt_path)
    command = list(receipt['command'])
    old = '/home/sicarii/Work/sia-note-boundary-checkpoint-20261024'
    if command.count(old) != 1 or command.count('60s') != 1:
        raise ValueError('unexpected original envelope')
    command[command.index(old)] = str(SOURCE)
    prefix, suffix = command[-1].split('loadTestsFromNames(', 1)
    _old_roster, ending = suffix.split('); result=', 1)
    command[-1] = prefix + 'loadTestsFromNames(' + repr(ROSTERS[mode]) + '); result=' + ending
    tracked = subprocess.check_output(['/usr/bin/git', '-C', str(SOURCE),
        'ls-files', '-z', '--', 'bin', 'tests', 'scripts', 'VERSION', 'install.sh', 'uninstall.sh',
        'systemd', 'Cockpit.qml', 'Model.js', 'README.md', 'SECURITY.md', 'docs/MANUAL.md',
        'docs/OLLAMA-ACCOUNT-GUARD.md'], timeout=10)
    paths = {SOURCE / name.decode() for name in tracked.split(b'\0') if name}
    paths.update({OUT / 'run.py', OUT / 'candidate.json', receipt_path})
    paths.update(Path(name) for name in command if name.startswith('/usr/bin/'))
    paths.add(Path('/home/sicarii/Documents/sia-repository-audit-20261024/git-review-executable'))
    return command, receipt['environment'], paths


def main():
    if len(sys.argv) != 2 or sys.argv[1] not in ROSTERS:
        raise ValueError('one declared mode required')
    mode = sys.argv[1]
    command, environment, paths = prepare(mode)
    head = subprocess.check_output(['/usr/bin/git', '-C', str(SOURCE),
                                    'rev-parse', 'HEAD'], timeout=10).decode().strip()
    if head != HEAD or shutil.disk_usage(OUT).free < 11073741824:
        raise ValueError('source or storage admission failed')
    tree = subprocess.check_output(['/usr/bin/git', '-C', str(SOURCE),
        'write-tree'], timeout=10).decode().strip()
    unstaged = subprocess.check_output(['/usr/bin/git', '-C', str(SOURCE),
        'diff', '--name-only'], timeout=10)
    if tree != TREE or unstaged:
        raise ValueError('composition changed')
    before = hashes(paths)
    record = dict(command=command, environment=environment, base_commit=head,
                  before=before, source_tree=tree, scope='Endpoint pins, not loaded-code custody')
    with (OUT / (mode + '-inputs.json')).open('x') as stream:
        json.dump(record, stream, indent=2)
        stream.write('\n')
    started = time.monotonic_ns()
    with (OUT / (mode + '.stdout')).open('xb') as stdout, \
            (OUT / (mode + '.stderr')).open('xb') as stderr:
        completed = subprocess.run(command, env=environment, stdout=stdout,
                                   stderr=stderr, check=False)
    after = hashes(paths)
    record.update(after=after, unchanged=before == after, exit=completed.returncode,
                  elapsed_ns=time.monotonic_ns() - started,
                  output_hashes=hashes({OUT / (mode + '.stdout'), OUT / (mode + '.stderr')}))
    with (OUT / (mode + '-result.json')).open('x') as stream:
        json.dump(record, stream, indent=2)
        stream.write('\n')
    print(json.dumps({key: record[key] for key in ('unchanged', 'exit', 'elapsed_ns')}))
    if not record['unchanged'] or completed.returncode:
        raise SystemExit(1)


if __name__ == '__main__':
    main()

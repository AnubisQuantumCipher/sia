"""Bounded compile-only restriction diagnostics; no runtime compliance claim."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess


def run_control(work, compiler, case, variant):
    root = work / 'controls-v3' / case['unit']
    name = 'restriction_control' if variant == 'positive' else case['unit']
    source = root / (name + '.adb')
    config = root / ('baseline.adc' if variant == 'baseline' else 'restricted.adc')
    args = [str(compiler), '-c', '-gnat2022', '-gnatwae', '-gnatVa',
            '-gnata', '-gnatf', '-gnatec=' + str(config), str(source)]
    result = subprocess.run(
        ['timeout', '--kill-after=5s', '5s', *args], cwd=root / variant,
        capture_output=True, check=False)
    (root / (variant + '.stdout')).write_bytes(result.stdout)
    (root / (variant + '.stderr')).write_bytes(result.stderr)
    expected = result.returncode == 0 and not result.stdout and not result.stderr
    if variant == 'negative':
        line = next(index for index, text in enumerate(
            source.read_text().splitlines(), 1) if 'new ' in text)
        marker = (source.name + ':' + str(line) + ':').encode()
        message = ('violation of restriction "' +
                   case['restriction'].lower() + '"').encode()
        expected = result.returncode == 1 and any(
            marker in entry and message in entry.lower()
            for entry in result.stderr.splitlines())
    return {'unit': case['unit'], 'variant': variant, 'argv': args,
            'returncode': result.returncode,
            'source_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
            'config_sha256': hashlib.sha256(config.read_bytes()).hexdigest(),
            'expected_result_observed': expected}


def main():
    work = Path(__file__).resolve().parent
    compiler = Path(shutil.which('gcc')).resolve(strict=True)
    results = []
    for case in json.loads((work / 'control-roster.json').read_text()):
        for variant in ('positive', 'negative', 'baseline'):
            if case['unit'] == 'anonymous_allocator' and variant == 'baseline':
                continue
            row = run_control(work, compiler, case, variant)
            results.append(row)
            (work / 'control-results-v3.json').write_text(
                json.dumps(results, indent=2) + '\n')
            print(row['unit'], variant, row['returncode'],
                  row['expected_result_observed'], flush=True)
            if not row['expected_result_observed']:
                raise SystemExit(1)


if __name__ == '__main__':
    main()

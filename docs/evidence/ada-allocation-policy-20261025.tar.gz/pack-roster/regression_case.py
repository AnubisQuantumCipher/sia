"""Original full regression plus composed-stream integration controls."""
import runpy
import unittest

NAMES = ['tests.test_event_pack_proposal', 'tests.test_event_pack_capture', 'tests.test_event_pack_plan', 'tests.test_consolidation_index_barrier', 'tests.test_event_pack_roster', 'tests.test_event_pack_group', 'tests.test_event_pack_replay', 'tests.test_event_page_plan', 'tests.test_epoch_module_ownership', 'tests.test_event_pack_reader', 'tests.test_event_pack', 'tests.test_event_epoch_admission_integrity', 'tests.test_sia.EpochMerge', 'tests.test_event_pack_consumers', 'tests.test_event_index_delta', 'tests.test_consolidation_outcomes', 'tests.test_consolidation_delivery_execution', 'tests.test_consolidation_executor', 'tests.test_event_page_batch', 'tests.test_event_page_closure', 'tests.test_event_checkpoint_delta', 'tests.test_event_checkpoint', 'tests.test_event_live_intake']
suite = unittest.defaultTestLoader.loadTestsFromNames(NAMES)
if suite.countTestCases() != 367:
    raise AssertionError("original regression roster changed")
namespace = runpy.run_path("/tmp/newtests.py")
suite.addTests(unittest.defaultTestLoader.loadTestsFromTestCase(namespace["CapturedAdmission"]))
result = unittest.TextTestRunner(verbosity=2).run(suite)
raise SystemExit(0 if result.wasSuccessful() and not result.skipped else 1)

procedure Positive is
begin
   null;
end Positive;

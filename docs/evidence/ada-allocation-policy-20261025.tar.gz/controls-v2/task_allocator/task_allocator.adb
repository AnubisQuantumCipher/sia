procedure Task_Allocator is
   task type Worker;
   task body Worker is
   begin
      null;
   end Worker;
   type Worker_Reference is access Worker;
   Item : constant Worker_Reference := new Worker;
begin
   if Item = null then
      raise Program_Error;
   end if;
end Task_Allocator;

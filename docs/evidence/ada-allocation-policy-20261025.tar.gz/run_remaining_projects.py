"""Build affected project configurations; probes require separate protocol tests."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import time


def execute(work, label, argv, limit):
    started = time.monotonic_ns()
    result = subprocess.run(
        ['timeout', '--kill-after=5s', str(limit) + 's', *argv],
        stdin=subprocess.DEVNULL, capture_output=True, check=False)
    (work / (label + '.stdout')).write_bytes(result.stdout)
    (work / (label + '.stderr')).write_bytes(result.stderr)
    row = {'label': label, 'argv': argv, 'returncode': result.returncode,
           'elapsed_ns': time.monotonic_ns() - started,
           'stderr_empty': not result.stderr}
    if len(argv) == 1:
        row['binary_sha256'] = hashlib.sha256(Path(argv[0]).read_bytes()).hexdigest()
    return row


def main():
    work = Path(__file__).resolve().parent
    spark = work / 'source/spark'
    projects = sorted(spark.glob('*.gpr')) + sorted((spark / 'transport').glob('*.gpr'))
    if len(projects) > 16:
        raise RuntimeError('project count capacity')
    results = []
    for project in projects:
        if project.name == 'sia_assurance.gpr':
            continue  # This unchanged source/configuration already completed.
        label = project.stem
        row = execute(work, label + '-build',
                      ['gprbuild', '-q', '-p', '-j1', '-P', str(project)], 60)
        results.append(row)
        (work / 'remaining-project-results.json').write_text(
            json.dumps(results, indent=2) + '\n')
        print(row['label'], row['returncode'], flush=True)
        if row['returncode'] != 0 or not row['stderr_empty']:
            raise SystemExit(1)
        text = project.read_text()
        mains = re.search(r'for Main use\s*\((.*?)\);', text, re.S)
        directory = re.search(r'for Exec_Dir use "([^"]+)";', text)
        if mains is None or directory is None:
            raise RuntimeError('project executable roster unavailable')
        for name in re.findall(r'"([a-z_]+_tests)\.adb"', mains.group(1)):
            executable = (project.parent / directory.group(1) / name).resolve(strict=True)
            row = execute(work, label + '-' + name, [str(executable)], 5)
            results.append(row)
            (work / 'remaining-project-results.json').write_text(
                json.dumps(results, indent=2) + '\n')
            print(row['label'], row['returncode'], flush=True)
            if row['returncode'] != 0 or not row['stderr_empty']:
                raise SystemExit(1)


if __name__ == '__main__':
    main()

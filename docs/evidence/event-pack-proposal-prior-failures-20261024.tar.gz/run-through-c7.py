"""Bounded isolated verification with source and negative-result retention."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
SOURCE = Path('/home/sicarii/Work/sia-assurance-checkpoint-20261023')
FILES = ('spark/pack_proposal.gpr', 'spark/restrictions.adc', 'spark/src/sia_continuity.adb', 'spark/src/sia_continuity.ads', 'spark/src/sia_continuity_record_wire.adb', 'spark/src/sia_continuity_record_wire.ads', 'spark/src/sia_pack_manifest_wire.adb', 'spark/src/sia_pack_manifest_wire.ads', 'spark/src/sia_pack_partition.adb', 'spark/src/sia_pack_partition.ads', 'spark/src/sia_pack_plan_wire.adb', 'spark/src/sia_pack_plan_wire.ads', 'spark/src/sia_pack_proposal.adb', 'spark/src/sia_pack_proposal.ads', 'spark/src/sia_pack_retirement.adb', 'spark/src/sia_pack_retirement.ads', 'spark/src/sia_policy.adb', 'spark/src/sia_policy.ads', 'spark/tests/pack_manifest_tests.adb', 'spark/tests/pack_plan_wire_test_support.adb', 'spark/tests/pack_plan_wire_test_support.ads', 'spark/tests/pack_plan_wire_tests.adb', 'spark/tests/pack_proposal_tests.adb', 'spark/tests/pack_retirement_test_support.adb', 'spark/tests/pack_retirement_test_support.ads', 'spark/tests/pack_retirement_tests.adb')
COMMANDS = {
    'build': ('60s', ['gprbuild', '-p', '-P', 'spark/pack_proposal.gpr', '-j1']),
    'runtime': ('60s', ['spark/pack-proposal-bin/pack_proposal_tests']),
    'retirement': ('60s', ['spark/pack-proposal-bin/pack_retirement_tests']),
    'wire': ('60s', ['spark/pack-proposal-bin/pack_plan_wire_tests']),
    'manifest': ('60s', ['spark/pack-proposal-bin/pack_manifest_tests']),
    'proof': ('120s', ['gnatprove', '-P', 'spark/pack_proposal.gpr', '-U',
                     '--mode=all', '--assumptions', '--no-inlining',
                     '--memlimit=512', '--timeout=10', '-j1']),
}


def hashes(stage):
    return {name: hashlib.sha256((stage / name).read_bytes()).hexdigest()
            for name in FILES}


def prepare(stage):
    stage.mkdir()
    for name in FILES:
        destination = stage / name
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes((SOURCE / name).read_bytes())


def main():
    if len(sys.argv) != 3 or sys.argv[1] not in ('c1', 'c2', 'c3', 'c4', 'c5', 'c6', 'c7', 'c8', 'c9', 'negative', 'negative6', 'negative7', 'negative9'):
        raise ValueError('explicit bounded candidate and phase required')
    candidate, phase = sys.argv[1:]
    stage = ROOT / ('stage-' + candidate)
    if phase == 'prepare':
        prepare(stage)
        return
    if phase not in COMMANDS:
        raise ValueError('unknown phase')
    seconds, arguments = COMMANDS[phase]
    command = ['flock', '-n', '-F', '/home/sicarii/.worldline-heavy.lock',
               'timeout', '--kill-after=5s', seconds, 'bash', '-c',
               'ulimit -c 0; ulimit -f 524288; ulimit -v 2097152; '
               'source /home/sicarii/opt/gnat/env.sh; exec "$@"', 'bash'] + arguments
    prefix = ROOT / (candidate + '-' + phase)
    record = {'command': command, 'cwd': str(stage), 'before': hashes(stage)}
    with prefix.with_suffix('.inputs.json').open('x') as handle:
        json.dump(record, handle, indent=2)
    started = time.monotonic_ns()
    with prefix.with_suffix('.stdout').open('xb') as out, \
            prefix.with_suffix('.stderr').open('xb') as err:
        result = subprocess.run(command, cwd=stage, stdout=out, stderr=err,
                                check=False, timeout=130)
    record.update(exit=result.returncode, elapsed_ns=time.monotonic_ns()-started,
                  after=hashes(stage))
    record['unchanged'] = record['before'] == record['after']
    with prefix.with_suffix('.result.json').open('x') as handle:
        json.dump(record, handle, indent=2)
    print(json.dumps({key: record[key] for key in ('exit', 'elapsed_ns', 'unchanged')}))


if __name__ == '__main__':
    main()

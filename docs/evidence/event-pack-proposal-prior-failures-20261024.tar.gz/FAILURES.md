# Proposal admission campaign: FAILED full proof / UNQUALIFIED

The final candidate is c8. No source was integrated, committed, pushed, installed
or released in this campaign. Publisher remains 3c6fa09da234d303043d17e791ace82851bef93f.
The existing full completion contract, every original workload and cap, failed
native gate and pending R05 obligations remain binding.

- c1: strict build exit4, private Partition_State equality visibility missing.
- c2: explicit use-type repairs visibility; build and runtime pass. Proof UNRUN.
- c3: added safe non-greedy trace, partition-vs-proposal counterexample and
  trailing-data refusals. All runtimes pass; full proof timeout124.
- c4: pure conjunct order and target-helper parameter narrowed. Tests pass;
  full proof timeout124. No obligation removed.
- c5: five scoped expression-body context annotations. Tests pass; full proof
  timeout124. Raw proposal result exposes missing represented-position bridge.
- c6: strengthens Partition.Take successful discriminator contract; all bodies
  unchanged. New-unit raw proof complete/clean, but full proof timeout124.
- c7: strict Boolean conjunction in four total wrapper contexts, retaining
  guard-dependent short-circuiting. Tests pass; full proof timeout124.
- c8: guarded strict conjunction inside plan-wire Decoded_As and Roster_Decoded.
  Original outer guards, fields, bodies and tests retained. Tests pass; full
  proof timeout124. First preparation attempt refused an incorrect end marker;
  no build ran on that partial stage, and its copied dependencies were checked.

All full proof attempts used the original complete project, -U, proof warnings,
120-second process bound, 10-second prover setting, one worker, 512-MiB prover
memory limit and existing process/file limits. No unchanged retry, disabled
warning, skipped production unit, new assumed lemma or increased cap was used.
Unknown reachability attempts are not arithmetic counterexamples. Tool attempt
limits differ by strategy: early CVC5 attempts were one second; later raw
attempts can use ten seconds. The actual logs remain authoritative.

Final strict build and runtime suites passed with unchanged source endpoints:
proposal 394361, original retirement 188, original wire 19508 (also invokes
retirement 188), original manifest 787650. These are executed check counts,
not coverage percentages or exhaustive domain proofs. Full-domain maximal
mixed and fallback-only traces remain present.

Coherent target-to-represented exclusion mutants on c4, c6, c7 and c8 build then
fail the unchanged `fallback target identity refuses` oracle. The prepared
c3-based negative9 is UNRUN, not a passing or failing control.

C8 raw results exist for proposal, partition, manifest, retirement and continuity
record wire, plus six test units outside SPARK. The plan-wire, continuity and
policy results and complete report are missing for this composition. There is
no full proof count or qualification claim. Both c6 and c8 auditors refuse
incomplete positive evidence. Packagers and positive-only auditors are drafts,
not successful acceptance artifacts; no proposed public archive was generated.

Actual GPT-6.1 review inspected source changes and raw diagnostics. It did not
independently execute the campaign. Full exact-composition independent execution
and acceptance remain open. Contract evaluation structure can affect runtime
work; unchanged operational limits and executed tests are not a WCET proof.

Next: inspect the retained plan-wire roster correspondence and reconstruction
obligations with their exact generated verification conditions. Identify a
specific sound contract/representation repair before another full attempt.
Do not repeat c8 unchanged, raise budgets, narrow -U scope, or reuse an older
successful dependency report as proof of this composed source.

A standards addendum was retained separately in the existing mission. The local
Power-of-Ten PDF matches its supplied hash; the local Ada/SPARK guidelines PDF
has a different hash and is not substituted. Exact modern/Ada95 references and
rule-to-obligation reconciliation remain pending. No parallel standards lane or
new authority was created.

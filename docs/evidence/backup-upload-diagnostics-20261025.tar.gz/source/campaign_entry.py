"""File-based unittest entrypoint; preserves __main__.__file__ for fixtures."""
import sys
from pathlib import Path
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parent))
unittest.main(module=None)

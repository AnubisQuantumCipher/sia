"""Bounded, isolated source-only backup diagnostic campaign."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "source"
ROSTERS = {
    "focused": ["tests.test_backup_upload_diagnostics.UploadDiagnostics"],
    "original": ["tests.test_continuity", "tests.test_backup_restore"],
}


def pins():
    return {str(path.relative_to(SOURCE)): hashlib.sha256(path.read_bytes()).hexdigest()
            for part in ("bin", "tests") for path in sorted((SOURCE / part).rglob("*"))
            if path.is_file()}


def main():
    if len(sys.argv) != 2 or sys.argv[1] not in ROSTERS:
        raise ValueError("one closed test roster required")
    name = sys.argv[1]
    destination = ROOT / (name + "-c1")
    destination.mkdir(exist_ok=False)
    command = ["/usr/bin/flock", "-F", "-n", "-E", "75",
               "/home/sicarii/.worldline-heavy.lock", "/usr/bin/prlimit",
               "--as=2147483648", "--fsize=536870912", "--core=0", "--",
               "/usr/bin/timeout", "--signal=TERM", "--kill-after=5s", "60s",
               "/usr/bin/bwrap", "--ro-bind", "/", "/", "--tmpfs", "/home",
               "--ro-bind", str(SOURCE), str(SOURCE), "--tmpfs", "/tmp",
               "--tmpfs", "/run", "--proc", "/proc", "--dev", "/dev",
               "--dir", "/home/audit", "--unshare-net", "--unshare-pid",
               "--die-with-parent", "--new-session", "--chdir", str(SOURCE),
               "/usr/bin/python3", "-I", "-B", "-Werror", "-c",
               "import sys,unittest;sys.path.insert(0,sys.argv.pop(1));"
               "unittest.main(module=None)", str(SOURCE), "-v", *ROSTERS[name]]
    environment = {"HOME": "/home/audit", "LANG": "C", "LC_ALL": "C",
                   "PATH": "/usr/bin:/bin", "TMPDIR": "/tmp", "TZ": "UTC"}
    before = pins()
    record = {"command": command, "environment": environment, "before": before,
              "runner_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    (destination / "admission.json").write_text(json.dumps(record, indent=2) + "\n")
    start = time.monotonic_ns()
    with (destination / "stdout").open("xb") as out, (destination / "stderr").open("xb") as err:
        completed = subprocess.run(command, env=environment, stdout=out, stderr=err, check=False)
    record.update(exit=completed.returncode, elapsed_ns=time.monotonic_ns() - start,
                  after=pins())
    record["source_unchanged"] = record["before"] == record["after"]
    (destination / "result.json").write_text(json.dumps(record, indent=2) + "\n")
    print(json.dumps({key: record[key] for key in ("exit", "elapsed_ns", "source_unchanged")}))
    return completed.returncode


if __name__ == "__main__":
    raise SystemExit(main())

# Upload failure diagnostics candidate

Source base: 07cec7671fa445029a3b9ea9939c20f3017d5535. Not installed or accepted.

The retained October 24 upload failure has no surviving phase evidence. This
candidate cannot retrospectively identify its cause. It adds closed diagnostic
codes to the existing status detail without changing the status schema or
granting readiness. Request identity remains in the existing operation record.

Track capture, capsule validation, uploading-status publication, repository
invocation, response decoding, repository check, off-path verification, result
construction and capsule cleanup. Crossing the repository-invocation boundary
means outcome-unknown, even if an internal preflight may have prevented dispatch.
A syntactically valid snapshot response means snapshot-reported, not durability,
integrity, or successful recovery. No diagnostics authorize retry.

Keep the original exception as the cause of a typed upload failure, and retain
an independent cleanup exception in memory. Preserve BlockedError classification
and fatal BaseException propagation. Emit only closed phase/outcome/error codes;
never exception messages, argv, repository URLs, environment or stderr. Successful
upload flow and existing cleanup calls must remain. Failure status publication
can itself fail; crash-time diagnostics are not guaranteed by this change.

Acceptance: unchanged original backup/continuity fixtures; injected failures at
every phase; success and scheduled paths; cleanup failure paired with a primary
failure; blocked and fatal failures; hostile exception text; no false readiness;
bounded output and exact-source static/runtime evidence. Independent review and
off-host recovery remain separate. No original gate or resource cap is waived.

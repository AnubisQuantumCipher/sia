"""Reproducible forensic bundle; exact source pins are derived from bytes."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

ROOT = Path(__file__).resolve().parent
PUBLISHER = Path('/home/sicarii/Work/sia-assurance-checkpoint-20261023')
ARCHIVE = 'docs/evidence/backup-upload-diagnostics-20261025.tar.gz'


def members():
    selected = [path for path in ROOT.iterdir()
                if path.is_file() and (path.suffix in {'.py', '.txt', '.md'}
                or path.name.startswith(('baseline-source', 'source-readback', 'static-')))]
    for name in ('focused-c1', 'original-c1', 'focused-c2', 'focused-c3',
                 'original-c3', 'combined-c4', 'combined-c5',
                 'focused-negative-c4', 'focused-negative-c5',
                 'c1-source', 'c2-source', 'c3-source', 'c4-source'):
        selected.extend(path for path in (ROOT / name).rglob('*') if path.is_file())
    for relative in ('source/bin/siabackup.py',
                     'source/tests/test_backup_upload_diagnostics.py',
                     'source/campaign_entry.py', 'source/install.sh',
                     'negative-source/bin/siabackup.py',
                     'negative-source/tests/test_backup_upload_diagnostics.py'):
        selected.append(ROOT / relative)
    if len(selected) > 256:
        raise ValueError('forensic member budget exceeded')
    return sorted(set(selected))


def bundle(paths):
    output = io.BytesIO()
    with gzip.GzipFile(fileobj=output, mode='wb', filename='', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as archive:
            for path in paths:
                content = path.read_bytes()
                if len(content) > 2_097_152:
                    raise ValueError('forensic member byte budget exceeded')
                info = tarfile.TarInfo(str(path.relative_to(ROOT)))
                info.size, info.mode, info.mtime = len(content), 0o644, 0
                archive.addfile(info, io.BytesIO(content))
    return output.getvalue()


def main():
    paths = members()
    payload = bundle(paths)
    if payload != bundle(paths):
        raise ValueError('forensic regeneration mismatch')
    (PUBLISHER / ARCHIVE).write_bytes(payload)
    final = json.loads((ROOT / 'combined-c5/result.json').read_text())
    record = {'status': 'NON_FINAL_NOT_INSTALLED', 'authority': 'NONE',
              'base_commit': '07cec7671fa445029a3b9ea9939c20f3017d5535',
              'archive': ARCHIVE, 'archive_sha256': hashlib.sha256(payload).hexdigest(),
              'archive_bytes': len(payload), 'combined_exit': final['exit'],
              'combined_elapsed_ns': final['elapsed_ns'],
              'source_unchanged': final['source_unchanged'],
              'independent_execution': 'UNRUN', 'full_module_static': 'FAILED_15_INHERITED_FINDINGS',
              'source_files': {name: hashlib.sha256((ROOT / 'source' / name).read_bytes()).hexdigest()
                               for name in ('bin/siabackup.py', 'tests/test_backup_upload_diagnostics.py')},
              'members': {str(path.relative_to(ROOT)): hashlib.sha256(path.read_bytes()).hexdigest()
                          for path in paths}}
    (PUBLISHER / 'docs/BACKUP-UPLOAD-DIAGNOSTICS-EVIDENCE-20261025.json').write_text(
        json.dumps(record, indent=2, sort_keys=True) + '\n')
    print(json.dumps({key: record[key] for key in ('archive_sha256', 'archive_bytes', 'combined_exit')}))


if __name__ == '__main__':
    main()

# Scoped continuity response-harness repair evidence

The original literal-result helper passed its limited diagnostic. The original
unused-family helper timed out at its unchanged 120-second command limit with
exit 124 and no fresh summary or raw .spark report. That failure stays FAILED.

The repair extracts exactly the former nested-loop body into a statically called
helper over arbitrary Restoration and Transition_Result values. Every original
statement, assertion, loop/domain and fixture remains. The source-comparison
record independently reconstructs that exact extraction from the retained base.
It is bounded text correspondence, not a general Ada semantic-equivalence proof.

The repaired overlay passed the focused helper proof (reported total 9), strict
project build, all fifteen original runtime harnesses, and complete response-unit
proof (reported total 90, all nine source declarations). Raw assumptions and
reports preserve ordinary modular dependencies. Full-project proof, clean
committed reproduction and installed continuity acceptance remain OPEN.

This bundle contains only explicitly selected source archives, source/patch,
review, commands, logs, exits, receipts, reports, identities and inspections.
Build objects, binaries, solver sessions and broad storage inventories are absent.
The source archives contain the committed spark subtree, with no generated output.

To reproduce packaging, keep the tar.gz and JSON sidecar beside the files extracted
from the tar.gz, then run `python3 -B retainer.py --check`. That read-only mode
reproduces and compares the complete tar.gz and manifest bytes; it runs no build,
test, proof, installed command or external service. The retainer is Python
orchestration with explicit bounds, not a verified authority core or a new proof
acceptance policy. Historical and scoped statuses must remain distinct.

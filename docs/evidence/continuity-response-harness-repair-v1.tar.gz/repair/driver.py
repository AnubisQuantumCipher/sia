from pathlib import Path
import hashlib
import json
import os
import platform
import re
import shlex
import shutil
import subprocess
import time

OUT=Path(__file__).resolve().parent
REPO=Path('/home/sicarii/Work/sia-assurance-kernel-20261019')
PIN='b947dbdd41f3a36f2e9a35cca8fa5dd3955e6ff7'
TARGET='spark/tests/continuity_response_wire_tests.adb'
OVERLAY_SHA='cf2ebb5c07b90a3c2cacc5829ef29a31be25b2fe83598e587755e5727a11dace'
RESERVE=10_000_000_000
RUNTIMES=('policy','transaction','request_wire','request_admission','grant_lifetime','retraction','consolidation','continuity','continuity_transition','continuity_record_wire','continuity_observation_wire','continuity_checkpoint_wire','continuity_current_wire','continuity_frame_wire','continuity_response_wire')

def save(path,value):
    path.write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')

def digest(path):
    if path.stat().st_size > 536_870_912:
        raise RuntimeError('hash byte budget')
    result=hashlib.sha256()
    with path.open('rb') as stream:
        for unused in range(8193):
            block=stream.read(65536)
            if not block:
                return result.hexdigest()
            result.update(block)
    raise RuntimeError('hash iteration budget')

def roster(directory):
    result={}
    for count,(current,directories,files) in enumerate(os.walk(directory,followlinks=False)):
        if count >= 1024 or len(result)+len(files)>4096:
            raise RuntimeError('inventory bound')
        directories.sort()
        for name in sorted(files):
            path=Path(current)/name
            if path.is_symlink():
                raise RuntimeError('unexpected symlink')
            result[str(path.relative_to(directory))]=digest(path)
    return result

def small(args,label,cwd=REPO):
    value=subprocess.run(args,cwd=cwd,capture_output=True,timeout=30)
    (OUT/(label+'.stdout')).write_bytes(value.stdout)
    (OUT/(label+'.stderr')).write_bytes(value.stderr)
    save(OUT/(label+'.command.json'),args)
    (OUT/(label+'.exit')).write_text(str(value.returncode)+'\n')
    if value.returncode:
        raise RuntimeError('preparation failed: '+label)
    return value.stdout

def prepare():
    if small(['git','rev-parse','HEAD'],'head').decode().strip()!=PIN:
        raise RuntimeError('HEAD mismatch')
    changed=small(['git','diff','--name-only',PIN,'--','spark'],'changed-files').decode().splitlines()
    if changed != [TARGET] or digest(REPO/TARGET)!=OVERLAY_SHA:
        raise RuntimeError('overlay mismatch')
    pre=json.loads(small(['python3','/home/sicarii/.codex/skills/project-vault/scripts/storage_status.py'],'storage-preflight'))
    save(OUT/'storage-preflight.json',pre)
    if not any(OUT.is_relative_to(Path(p)) for p in pre['pins']):
        raise RuntimeError('missing evidence pin')
    if shutil.disk_usage(OUT).free<max(RESERVE,pre['configured_local_reserve_bytes']):
        raise RuntimeError('insufficient reserve')
    archive=OUT/'source.tar'
    small(['git','archive','--format=tar','--output='+str(archive),PIN,'spark'],'archive')
    source=OUT/'source'
    source.mkdir()
    small(['tar','-xf',str(archive),'-C',str(source)],'extract')
    save(OUT/'committed-source-hashes.json',roster(source))
    overlay=OUT/'overlay'/TARGET
    overlay.parent.mkdir(parents=True)
    shutil.copyfile(REPO/TARGET,overlay)
    if digest(overlay)!=OVERLAY_SHA:
        raise RuntimeError('overlay changed while copying')
    patch=small(['git','diff','--binary',PIN,'--',TARGET],'overlay-patch')
    (OUT/'overlay.patch').write_bytes(patch)
    shutil.copyfile(overlay,source/TARGET)
    save(OUT/'source-hashes-before.json',roster(source))
    manifest=json.loads(small(['git','show',PIN+':docs/CONTINUITY-IO-COMMITTED-EVIDENCE-20261021.json'],'prior-tool-roster'))
    resolved={n:str(Path(shutil.which(n)).resolve()) for n in ('gnatprove','gprbuild','gnatls','gcc','timeout','git','python3','tar','flock')}
    paths=sorted(set(list(manifest['receipt']['proof_tools_before'])+list(resolved.values())))
    before={p:digest(Path(p)) for p in paths}
    save(OUT/'tool-paths.json',resolved)
    save(OUT/'tool-hashes-before.json',before)
    for name in ('gnatprove','gprbuild','gnatls','gcc'):
        small([resolved[name],'--version'],name+'-version',source)
    save(OUT/'source-binding.json',{'commit':PIN,'archive_sha256':digest(archive),'overlay_file':TARGET,'overlay_sha256':digest(overlay),'patch_sha256':digest(OUT/'overlay.patch'),'gnat_env_sha256':digest(Path('/home/sicarii/opt/gnat/env.sh')),'platform':platform.platform(),'lock':'flock -n -E 75 /home/sicarii/.worldline-heavy.lock'})
    return source,resolved,paths,before

def unique_pairs(pairs):
    result={}
    for key,value in pairs:
        if key in result:
            raise ValueError('duplicate report key')
        result[key]=value
    return result

def inspect_scope(stage):
    summary=stage/'raw/gnatprove.out'
    if not summary.is_file():
        return {'status':'MISSING_SUMMARY','passed':False}
    total=[line for line in summary.read_text().splitlines() if line.startswith('Total ')]
    if len(total)!=1 or re.sub(r'\([0-9]+%\)','',total[0]).split()[-2:]!=['.','.']:
        return {'status':'SUMMARY_NOT_CLEAN','passed':False}
    reports=list((stage/'raw').glob('*.spark'))
    findings={}
    for path in reports:
        data=json.loads(path.read_text(),object_pairs_hook=unique_pairs)
        diagnostics={key:[v for v in data[key] if not isinstance(v,dict) or v.get('severity') not in ('info','information')] for key in ('warn_error','flow','proof')}
        exclusions={key:data[key] for key in ('pragma_assume','skip_proof','skip_flow_proof')}
        findings[path.name]={'non_information_diagnostics':diagnostics,'exclusions':exclusions,'stop_reason':data['stop_reason'],'assumptions':data['assumptions']}
        if any(diagnostics.values()) or any(exclusions.values()) or data['stop_reason']!='STOP_REASON_NONE':
            return {'status':'RAW_REPORT_REFUSAL','passed':False,'reports':findings}
    return {'status':'SCOPED_REPORT_INSPECTION_ONLY','passed':bool(reports),'total_row':total[0],'reports':findings,'limit':'Not the full-project coverage checker or system acceptance'}

def run_stage(source,resolved,name,command,seconds,proof=False):
    stage=OUT/name
    stage.mkdir()
    args=[resolved['timeout'],'--kill-after=5s',seconds]+command
    save(stage/'command.json',args)
    (stage/'command').write_text(shlex.join(args)+'\n')
    if shutil.disk_usage(OUT).free<RESERVE:
        raise RuntimeError('reserve before '+name)
    report=source/'spark/obj/gnatprove'
    if proof and (report/'gnatprove.out').exists():
        (report/'gnatprove.out').unlink()
    started=time.monotonic()
    with (stage/'stdout').open('wb') as stdout,(stage/'stderr').open('wb') as stderr:
        value=subprocess.run(args,cwd=source,stdout=stdout,stderr=stderr)
    result={'name':name,'command':args,'exit':value.returncode,'elapsed_seconds':time.monotonic()-started,'passed':value.returncode==0}
    (stage/'exit').write_text(str(value.returncode)+'\n')
    if proof:
        raw=stage/'raw'
        raw.mkdir()
        for path in list(report.glob('*.spark'))+list(report.glob('gnatprove.out')):
            shutil.copyfile(path,raw/path.name)
        inspected=inspect_scope(stage)
        save(stage/'inspection.json',inspected)
        result['scope_inspection']=inspected['status']
        result['fresh_summary_present']=(raw/'gnatprove.out').exists()
        result['passed']=result['passed'] and inspected['passed']
    save(stage/'result.json',result)
    print(json.dumps(result),flush=True)
    return result

def sequence(source,resolved):
    common=[resolved['gnatprove'],'-P','spark/sia_assurance.gpr','-u','continuity_response_wire_tests.adb','--mode=all','--assumptions','--no-inlining','--memlimit=512','--timeout=10','-j1']
    results=[run_stage(source,resolved,'focused-helper',common+['--limit-subp=continuity_response_wire_tests.adb:69'],'120s',True)]
    if not results[-1]['passed']:
        return results
    results.append(run_stage(source,resolved,'strict-build',[resolved['gprbuild'],'-p','-P','spark/sia_assurance.gpr'],'120s'))
    if not results[-1]['passed']:
        return results
    for name in RUNTIMES:
        results.append(run_stage(source,resolved,name+'-runtime',['spark/bin/'+name+'_tests'],'30s'))
        if not results[-1]['passed']:
            return results
    results.append(run_stage(source,resolved,'complete-response-harness',common,'120s',True))
    return results

def main():
    source,resolved,paths,before=prepare()
    (OUT/'source-review.txt').write_text('Actual GPT-6.1 independent source review: no concrete blocker found. Compared b947dbdd41f3a36f2e9a35cca8fa5dd3955e6ff7 with candidate cf2ebb5c07b90a3c2cacc5829ef29a31be25b2fe83598e587755e5727a11dace. Every former loop-body statement/assertion/order is preserved in the parameterized helper; both nested loop domains and surrounding harness are unchanged. Bytes is assigned before read; Decode has out Accepted/Item with explicit dependency contracts, so per-call locals do not preserve cross-iteration state. No domain, fixture, production contract, warning, or resource-bound weakening found. This is a source assessment, not execution or full-project acceptance.\n')
    results=sequence(source,resolved)
    after={p:digest(Path(p)) for p in paths}
    save(OUT/'tool-hashes-after.json',after)
    initial=json.loads((OUT/'source-hashes-before.json').read_text())
    final={p:digest(source/p) for p in initial}
    save(OUT/'source-hashes-after.json',final)
    save(OUT/'source-output-hashes.json',roster(source))
    receipt={'commit':PIN,'overlay_file':TARGET,'overlay_sha256':OVERLAY_SHA,'checks':results,'tool_rosters_equal':before==after,'archived_overlay_sources_unchanged':initial==final,'worktree_overlay_still_matches':digest(REPO/TARGET)==OVERLAY_SHA,'free_after_bytes':shutil.disk_usage(OUT).free,'full_project_proof':'UNRUN; prior failure retained','scope':'Single reviewed test-harness refactor; focused helper then strict build/original runtimes/complete response harness, stopping at first failed gate; no full-project or installed acceptance'}
    save(OUT/'receipt.json',receipt)
    print(json.dumps(receipt,indent=2),flush=True)

if __name__=='__main__':
    main()

#!/usr/bin/env python3
"""Repack explicitly selected SIA evidence; no proof or installed action is run."""
from pathlib import Path
import argparse
import gzip
import hashlib
import io
import json
import re
import stat
import tarfile

ROOT=Path(__file__).resolve().parent
BUNDLE='continuity-response-harness-repair-v1.tar.gz'
MANIFEST='CONTINUITY-RESPONSE-HARNESS-REPAIR-EVIDENCE-V1.json'
MAX_MEMBERS=256
MAX_FILE_BYTES=16_777_216
MAX_INPUT_BYTES=33_554_432
ORIGINAL_COMMIT='1b3829d84002037e329a61c1ecff6ac3909c0210'
REPAIR_BASE='b947dbdd41f3a36f2e9a35cca8fa5dd3955e6ff7'
OVERLAY_SHA='cf2ebb5c07b90a3c2cacc5829ef29a31be25b2fe83598e587755e5727a11dace'
TARGET='spark/tests/continuity_response_wire_tests.adb'
CORE=('driver.py','preparation.json','proof.command','proof.command.json','proof.exit','proof.stdout','proof.stderr','receipt.json','inspection.json','source-hashes-before.json','source-hashes-after.json','tool-hashes-before.json','tool-hashes-after.json','tool-paths.json')
VERSIONS=tuple(tool+'-version'+suffix for tool in ('gnatprove','gprbuild','gnatls','gcc') for suffix in ('.command.json','.exit','.stderr','.stdout'))
REPAIR_CORE=('driver.py','source-binding.json','source-review.txt','overlay.patch','committed-source-hashes.json','source-hashes-before.json','source-hashes-after.json','tool-hashes-before.json','tool-hashes-after.json','tool-paths.json','coverage-inspection.json','receipt.json','archive.command.json','archive.exit','archive.stderr','archive.stdout','head.command.json','head.exit','head.stderr','head.stdout')
RUNTIMES=('policy','transaction','request_wire','request_admission','grant_lifetime','retraction','consolidation','continuity','continuity_transition','continuity_record_wire','continuity_observation_wire','continuity_checkpoint_wire','continuity_current_wire','continuity_frame_wire','continuity_response_wire')
STAGES=('focused-helper','strict-build')+tuple(name+'-runtime' for name in RUNTIMES)+('complete-response-harness',)


def require(condition,message):
    if not condition:
        raise ValueError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def encoded(value):
    return (json.dumps(value,indent=2,sort_keys=True,ensure_ascii=True)+'\n').encode()


def unique_pairs(pairs):
    result={}
    for key,value in pairs:
        require(key not in result,'duplicate JSON key')
        result[key]=value
    return result


def decoded(data):
    def refuse_constant(value):
        raise ValueError('non-JSON numeric constant: '+value)
    return json.loads(data,object_pairs_hook=unique_pairs,parse_constant=refuse_constant)


def selected_inputs():
    names=[]
    for label in ('helper','unused'):
        names.extend('original/'+label+'/'+name for name in CORE+VERSIONS)
    names.extend(('original/helper/raw/gnatprove.out','original/helper/raw/continuity_response_wire_tests.spark','original/source.tar'))
    names.extend('repair/'+name for name in REPAIR_CORE+VERSIONS)
    names.append('repair/source.tar')
    for stage in STAGES:
        names.extend('repair/'+stage+'/'+name for name in ('command','command.json','exit','result.json','stdout','stderr'))
    for stage in ('focused-helper','complete-response-harness'):
        names.append('repair/'+stage+'/inspection.json')
        names.extend('repair/'+stage+'/raw/'+name for name in ('gnatprove.out','continuity_response_wire_tests.spark'))
    names.extend(('source/repaired-response-harness.adb','source/original-response-harness.adb'))
    require(len(names)==len(set(names)) and len(names)<MAX_MEMBERS,'invalid fixed selection')
    return sorted(names)


def read_member(name):
    path=ROOT/name
    require(not Path(name).is_absolute() and '..' not in Path(name).parts,'unsafe member path')
    for part in (path,)+tuple(path.parents):
        if part==ROOT.parent:
            break
        require(not part.is_symlink(),'symlink member or parent')
    before=path.stat()
    require(stat.S_ISREG(before.st_mode) and before.st_size<=MAX_FILE_BYTES,'input type/byte budget')
    data=path.read_bytes()
    after=path.stat()
    require((before.st_ino,before.st_size,before.st_mtime_ns,before.st_ctime_ns)==(after.st_ino,after.st_size,after.st_mtime_ns,after.st_ctime_ns),'input changed during read')
    require(len(data)==before.st_size,'input length changed')
    return data


def load_members():
    selected=selected_inputs()
    require(decoded(read_member('selected-members.json'))==selected,'selection record differs from fixed inputs')
    result={}
    total=0
    for name in selected+['retainer.py','selected-members.json','README.md']:
        data=read_member(name)
        total+=len(data)
        require(total<=MAX_INPUT_BYTES,'aggregate input byte budget')
        result[name]=data
    return result


def source_comparison(members):
    old=members['source/original-response-harness.adb'].decode()
    new=members['source/repaired-response-harness.adb'].decode()
    require(len(old)<65536 and len(new)<65536,'source comparison budget')
    start='   procedure Check_Unused_Families with Global => null, Always_Terminates is\n'
    end='   end Check_Unused_Families;\n'
    require(old.count(start)==1 and old.count(end)==1,'original anchors not unique')
    first=old.index(start)
    last=old.index(end,first)+len(end)
    block=old[first:last]
    lines=block.splitlines()
    begin=lines.index('   begin')
    locals_=lines[1:begin]
    require(locals_==['      Accepted : Boolean;','      Item : Frame_Decision;','      Bytes : Response_Bytes;'],'local declarations differ')
    body_first=lines.index('            Bytes := Encode ((Malformed, R, T));')
    body_last=lines.index('         end loop;')
    body=lines[body_first:body_last]
    require(all(line.startswith('      ') for line in body),'body indentation mismatch')
    moved='\n'.join(line[6:] for line in body)+'\n'
    helper='   procedure Check_Unused_Values (R : Restoration; T : Transition_Result)\n   with Global => null, Always_Terminates is\n'+'\n'.join(locals_)+'\n   begin\n'+moved+'   end Check_Unused_Values;\n\n'
    outer=block.replace('\n'.join(locals_)+'\n','',1)
    outer=outer.replace('\n'.join(body),'            Check_Unused_Values (R, T);',1)
    require(old[:first]+helper+outer+old[last:]==new,'candidate differs from exact body-extraction transform')
    assertions=lambda text:[' '.join(value.split()) for value in re.findall(r'pragma Assert \([\s\S]*?;',text)]
    loops=lambda text:[value.strip() for value in re.findall(r'^\s*for [^\n]+ loop$',text,re.M)]
    require(assertions(old)==assertions(new),'assertion tokens/order differ')
    require(loops(old)==loops(new),'loop headers/domains/order differ')
    return {'kind':'Exact bounded text correspondence, not a general Ada semantic proof','original_sha256':sha(old.encode()),'repaired_sha256':sha(new.encode()),'whole_file_equals_exact_extraction_transform':True,'normalized_moved_body_sha256':sha(moved.encode()),'assertion_tokens_and_order_preserved':True,'all_loop_headers_domains_and_order_preserved':True,'loop_headers':loops(old),'helper_formals':'R : Restoration; T : Transition_Result','locals_preserved':locals_,'authority_or_production_contract_change':False,'semantic_scope':'Independent source review separately confirms every local is overwritten before read and no result escapes; modular proof and runtimes remain separate evidence'}


def archive_source(data):
    found=None
    with tarfile.open(fileobj=io.BytesIO(data),mode='r:') as archive:
        for count,member in enumerate(archive):
            require(count<512,'source archive member budget')
            require((member.name.startswith('spark/') or (member.name=='spark' and member.isdir())) and '..' not in Path(member.name).parts,'source archive path')
            require('/obj/' not in member.name and '/bin/' not in member.name and 'why3' not in member.name,'generated output in source archive')
            require(member.isdir() or member.isfile(),'unexpected source archive entry type')
            require(member.size<=MAX_FILE_BYTES,'source archive member byte budget')
            if member.name==TARGET:
                require(found is None,'duplicate harness in source archive')
                found=archive.extractfile(member).read()
    require(found is not None,'source archive omits harness')
    return found


def scope_report(members,prefix):
    data=decoded(members[prefix+'/continuity_response_wire_tests.spark'])
    summary=members[prefix+'/gnatprove.out'].decode()
    totals=[line for line in summary.splitlines() if line.startswith('Total ')]
    require(len(totals)==1,'missing/duplicate total row')
    fields=re.sub(r'\([0-9]+%\)','',totals[0]).split()
    require(fields[-2:]==['.','.'],'nonzero justified/unproved report')
    require(data['stop_reason']=='STOP_REASON_NONE','incomplete raw report')
    for key in ('pragma_assume','skip_proof','skip_flow_proof'):
        require(data[key]==[],'declared assumption/exclusion')
    for channel in ('warn_error','flow','proof'):
        require(all(isinstance(item,dict) and item.get('severity') in ('info','information') for item in data[channel]),'non-information diagnostic')
    covered=[]
    for key,state in data['spark'].items():
        require(state=='all','partial entity coverage')
        item=data['entities'][key]
        require(len(item['sloc'])==1,'ambiguous entity source location')
        covered.append({'name':item['name'],'source_location':item['sloc'][0]})
    return {'reported_total':int(fields[1]),'total_row':totals[0],'justified':0,'unproved':0,'covered_entities':covered,'raw_diagnostics':'No non-information entries in warn_error/flow/proof','pragma_assume':[],'skip_proof':[],'skip_flow_proof':[],'assumptions':'Ordinary modular dependencies retained verbatim in raw report and summary'}


def validate_inputs(members):
    binding=decoded(members['repair/source-binding.json'])
    require(binding['commit']==REPAIR_BASE and binding['overlay_file']==TARGET,'repair source binding mismatch')
    require(binding['overlay_sha256']==OVERLAY_SHA==sha(members['source/repaired-response-harness.adb']),'overlay hash mismatch')
    require(binding['archive_sha256']==sha(members['repair/source.tar']),'repair archive hash mismatch')
    require(binding['patch_sha256']==sha(members['repair/overlay.patch']),'patch hash mismatch')
    require(archive_source(members['repair/source.tar'])==members['source/original-response-harness.adb'],'repair archive harness mismatch')
    original=archive_source(members['original/source.tar'])
    require(original==members['source/original-response-harness.adb'],'original harness differs from repair base')
    for label,status in (('helper',0),('unused',124)):
        prefix='original/'+label+'/'
        receipt=decoded(members[prefix+'receipt.json'])
        require(receipt['commit']==ORIGINAL_COMMIT and receipt['exit']==status,'historical receipt mismatch')
        require(receipt['archive_sha256']==sha(members['original/source.tar']),'historical archive mismatch')
        require(int(members[prefix+'proof.exit'])==status,'historical raw exit mismatch')
        require(decoded(members[prefix+'proof.command.json'])==receipt['command'],'historical command mismatch')
        require(receipt['tool_rosters_equal'] and receipt['archived_sources_unchanged'],'historical provenance mismatch')
    failed=decoded(members['original/unused/inspection.json'])
    require(not failed['summary_present'] and failed['raw_spark_reports']==[],'historical absence record mismatch')
    receipt=decoded(members['repair/receipt.json'])
    require(receipt['commit']==REPAIR_BASE and receipt['overlay_sha256']==OVERLAY_SHA,'repair receipt mismatch')
    require([row['name'] for row in receipt['checks']]==list(STAGES),'repair check roster mismatch')
    require(receipt['tool_rosters_equal'] and receipt['archived_overlay_sources_unchanged'] and receipt['worktree_overlay_still_matches'],'repair provenance mismatch')
    for name,row in zip(STAGES,receipt['checks']):
        prefix='repair/'+name+'/'
        require(row==decoded(members[prefix+'result.json']),'stage/receipt mismatch')
        require(row['exit']==0 and row['passed'] and int(members[prefix+'exit'])==0,'repair stage failed')
        require(decoded(members[prefix+'command.json'])==row['command'],'repair command mismatch')
    for prefix in ('original/helper','original/unused','repair'):
        require(decoded(members[prefix+'/tool-hashes-before.json'])==decoded(members[prefix+'/tool-hashes-after.json']),'tool roster changed')
        require(decoded(members[prefix+'/source-hashes-before.json'])==decoded(members[prefix+'/source-hashes-after.json']),'source bytes changed')
    return binding,receipt


def verify_complete_coverage(members,report):
    source=members['source/repaired-response-harness.adb'].decode()
    expected=[]
    for line,text in enumerate(source.splitlines(),1):
        match=re.match(r'\s*procedure\s+(\w+)',text)
        if match:
            short=match.group(1)
            name=short if short=='Continuity_Response_Wire_Tests' else 'Continuity_Response_Wire_Tests.'+short
            expected.append((name,line))
    covered=[(row['name'],row['source_location']['line']) for row in report['covered_entities']]
    require(sorted(expected)==sorted(covered),'source/raw complete-unit coverage mismatch')
    recorded=decoded(members['repair/coverage-inspection.json'])
    require(recorded['declarations_match_exactly'] and recorded['overlay_changed_files']==[TARGET],'recorded coverage mismatch')
    return {'unit':'continuity_response_wire_tests','source_declaration_count':len(expected),'reported_entity_count':len(covered),'exact_declaration_location_match':True,'full_project_coverage':'NOT ESTABLISHED'}


def compressed_tar(members):
    require(len(members)<=MAX_MEMBERS,'bundle member budget')
    buffer=io.BytesIO()
    with tarfile.open(fileobj=buffer,mode='w',format=tarfile.USTAR_FORMAT) as archive:
        for name,data in sorted(members.items()):
            require(len(name.encode())<=100,'USTAR name budget')
            entry=tarfile.TarInfo(name)
            entry.size=len(data)
            entry.mode=0o644
            entry.uid=entry.gid=entry.mtime=0
            entry.uname=entry.gname=''
            archive.addfile(entry,io.BytesIO(data))
    require(buffer.tell()<=MAX_INPUT_BYTES+1_048_576,'tar output budget')
    zipped=io.BytesIO()
    with gzip.GzipFile(filename='',mode='wb',fileobj=zipped,compresslevel=9,mtime=0) as stream:
        stream.write(buffer.getvalue())
    return zipped.getvalue()


def derived_manifest(members,bundle,binding,receipt,comparison):
    focused=scope_report(members,'repair/focused-helper/raw')
    complete=scope_report(members,'repair/complete-response-harness/raw')
    original=scope_report(members,'original/helper/raw')
    coverage=verify_complete_coverage(members,complete)
    failed=decoded(members['original/unused/receipt.json'])
    return {'schema_version':1,'kind':'SCOPED DEVELOPMENT RESPONSE-HARNESS REPAIR; not full-project or installed acceptance','source':binding,'members':[{'path':name,'bytes':len(data),'sha256':sha(data)} for name,data in sorted(members.items())],'bundle':{'path':'docs/evidence/'+BUNDLE,'bytes':len(bundle),'sha256':sha(bundle)},'source_correspondence':comparison,'historical_evidence':{'literal_helper':{'scope':'Check_Literal_Results only','exit':0,'proof':original},'unused_families':{'status':'FAILED_TIMEOUT; never relabeled by later success','exit':124,'command_limit':'120s','fresh_summary_present':False,'elapsed_seconds':failed['elapsed_seconds'],'command':failed['command']}},'repair_checks':receipt['checks'],'focused_helper_proof':focused,'complete_response_harness_proof':complete,'complete_response_harness_coverage':coverage,'full_project_proof':'UNRUN for repaired overlay; inherited all-unit failure remains OPEN','committed_source_reproduction':'OPEN; these are committed base plus exact single-file development overlay results','installed_continuity_and_protected_authority':'OPEN; no installed effect or authority grant','scope_limits':['Conditional on ordinary modular contracts, toolchain and runtime assumptions.','No source/fixture/domain/assertion/warning/resource-cap weakening is accepted.','Source review is model assessment; command results are retained execution evidence.','This retainer verifies correspondence and deterministic packaging; it does not replay proofs or authenticate the toolchain.','Original normative Power of Ten remains authoritative; this scoped repair is not whole-system compliance or certification.'],'retainer':{'member':'retainer.py','command':'python3 -B retainer.py --check','selection':'Fixed explicit names and bounded regular-file inputs; no directory crawl','tar':'USTAR; sorted names; mode0644; uid/gid/mtime0; empty owner names','gzip':'level9; mtime0; empty filename'},'storage':{'retention':'External pinned evidence root; no objects/binaries/solver sessions/storage inventories bundled'}}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    mode=parser.add_mutually_exclusive_group(required=True)
    mode.add_argument('--write',action='store_true')
    mode.add_argument('--check',action='store_true')
    args=parser.parse_args()
    members=load_members()
    binding,receipt=validate_inputs(members)
    comparison=source_comparison(members)
    comparison_bytes=encoded(comparison)
    compare_path=ROOT/'source-comparison.json'
    if args.write:
        with compare_path.open('xb') as stream:
            stream.write(comparison_bytes)
    else:
        require(read_member('source-comparison.json')==comparison_bytes,'source comparison does not reproduce')
    members['source-comparison.json']=comparison_bytes
    bundle=compressed_tar(members)
    manifest=encoded(derived_manifest(members,bundle,binding,receipt,comparison))
    if args.write:
        with (ROOT/BUNDLE).open('xb') as stream:
            stream.write(bundle)
        with (ROOT/MANIFEST).open('xb') as stream:
            stream.write(manifest)
    else:
        require(read_member(BUNDLE)==bundle,'bundle bytes do not reproduce')
        require(read_member(MANIFEST)==manifest,'manifest bytes do not reproduce')
    print(json.dumps({'status':'REPRODUCED_BYTES' if args.check else 'WROTE_SCOPED_EVIDENCE','bundle':str(ROOT/BUNDLE),'bundle_sha256':sha(bundle),'manifest':str(ROOT/MANIFEST),'manifest_sha256':sha(manifest),'members':len(members),'full_project_acceptance':False},sort_keys=True))

if __name__=='__main__':
    main()

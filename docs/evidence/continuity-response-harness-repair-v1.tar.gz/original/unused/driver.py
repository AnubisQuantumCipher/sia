from pathlib import Path
import hashlib
import json
import os
import platform
import shlex
import shutil
import subprocess
import time

OUT = Path(__file__).resolve().parent
REPO = Path('/home/sicarii/Work/sia-assurance-kernel-20261019')
PIN = '1b3829d84002037e329a61c1ecff6ac3909c0210'
RESERVE = 10_000_000_000

def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')

def digest(path):
    path = Path(path)
    if path.stat().st_size > 536_870_912:
        raise RuntimeError('hash input exceeds fixed byte budget: ' + str(path))
    value = hashlib.sha256()
    with path.open('rb') as stream:
        for unused in range(8193):
            data = stream.read(65536)
            if not data:
                return value.hexdigest()
            value.update(data)
    raise RuntimeError('hash iteration budget exhausted')

def file_roster(directory):
    found = {}
    visited = 0
    for current, directories, files in os.walk(directory, followlinks=False):
        visited += 1
        if visited > 1024 or len(found) + len(files) > 4096:
            raise RuntimeError('inventory budget exceeded')
        directories.sort()
        for name in sorted(files):
            path = Path(current) / name
            if path.is_symlink():
                raise RuntimeError('unexpected output symlink: ' + str(path))
            found[str(path.relative_to(directory))] = digest(path)
    return found

def small(args, label, cwd=REPO):
    result = subprocess.run(args, cwd=cwd, capture_output=True, timeout=30)
    (OUT / (label + '.stdout')).write_bytes(result.stdout)
    (OUT / (label + '.stderr')).write_bytes(result.stderr)
    save(label + '.command.json', args)
    (OUT / (label + '.exit')).write_text(str(result.returncode) + '\n')
    if result.returncode:
        raise RuntimeError('preparation command failed: ' + label)
    return result.stdout

def tools_snapshot(paths):
    return {str(path): digest(path) for path in paths}

def main():
    observed = small(['git', 'rev-parse', 'HEAD'], 'head').decode().strip()
    if observed != PIN:
        raise RuntimeError('HEAD mismatch')
    preflight = json.loads(small(['python3', '/home/sicarii/.codex/skills/project-vault/scripts/storage_status.py'], 'storage-preflight'))
    save('storage-preflight.json', preflight)
    if not any(OUT.is_relative_to(Path(pin)) for pin in preflight['pins']):
        raise RuntimeError('evidence directory is not covered by an existing pin')
    if shutil.disk_usage(OUT).free < max(RESERVE, preflight['configured_local_reserve_bytes']):
        raise RuntimeError('local reserve unavailable')
    archive = OUT / 'source.tar'
    small(['git', 'archive', '--format=tar', '--output=' + str(archive), PIN, 'spark'], 'archive')
    source = OUT / 'source'
    source.mkdir()
    small(['tar', '-xf', str(archive), '-C', str(source)], 'extract')
    initial = file_roster(source)
    save('source-hashes-before.json', initial)
    manifest = json.loads(small(['git', 'show', PIN + ':docs/CONTINUITY-IO-COMMITTED-EVIDENCE-20261021.json'], 'prior-tool-roster'))
    paths = list(manifest['receipt']['proof_tools_before'])
    resolved = {name: str(Path(shutil.which(name)).resolve()) for name in ('gnatprove', 'gprbuild', 'gnatls', 'gcc', 'timeout', 'git', 'python3', 'tar', 'flock')}
    paths = sorted(set(paths + list(resolved.values())))
    before = tools_snapshot(paths)
    save('tool-paths.json', resolved)
    save('tool-hashes-before.json', before)
    for name in ('gnatprove', 'gprbuild', 'gnatls', 'gcc'):
        small([resolved[name], '--version'], name + '-version', cwd=source)
    command = [resolved['timeout'], '--kill-after=5s', '120s', resolved['gnatprove'], '-P', 'spark/sia_assurance.gpr', '-u', 'continuity_response_wire_tests.adb', '--limit-subp=continuity_response_wire_tests.adb:69', '--mode=all', '--assumptions', '--no-inlining', '--memlimit=512', '--timeout=10', '-j1']
    save('proof.command.json', command)
    (OUT / 'proof.command').write_text(shlex.join(command) + '\n')
    save('preparation.json', {'commit': PIN, 'archive_sha256': digest(archive), 'cwd': str(source), 'gnat_env_sha256': digest('/home/sicarii/opt/gnat/env.sh'), 'lock': 'flock -n -E 75 /home/sicarii/.worldline-heavy.lock', 'platform': platform.platform(), 'source_scope': 'git archive committed spark subtree; no overlay', 'reserve_bytes': RESERVE})
    free_before = shutil.disk_usage(OUT).free
    if free_before < max(RESERVE, preflight['configured_local_reserve_bytes']):
        raise RuntimeError('local reserve unavailable immediately before proof')
    started = time.monotonic()
    with (OUT / 'proof.stdout').open('wb') as stdout, (OUT / 'proof.stderr').open('wb') as stderr:
        result = subprocess.run(command, cwd=source, stdout=stdout, stderr=stderr)
    elapsed = time.monotonic() - started
    (OUT / 'proof.exit').write_text(str(result.returncode) + '\n')
    after = tools_snapshot(paths)
    save('tool-hashes-after.json', after)
    final_sources = {name: digest(source / name) for name in initial}
    save('source-hashes-after.json', final_sources)
    summary = source / 'spark/obj/gnatprove/gnatprove.out'
    if summary.exists():
        shutil.copyfile(summary, OUT / 'gnatprove-summary.txt')
    save('source-output-hashes.json', file_roster(source))
    receipt = {'commit': PIN, 'archive_sha256': digest(archive), 'command': command, 'cwd': str(source), 'exit': result.returncode, 'elapsed_seconds': elapsed, 'fresh_summary_present': summary.exists(), 'tool_rosters_equal': before == after, 'archived_sources_unchanged': initial == final_sources, 'free_before_bytes': free_before, 'free_after_bytes': shutil.disk_usage(OUT).free, 'scope': 'DIAGNOSTIC ONLY: Check_Unused_Families at continuity_response_wire_tests.adb:69; not full unit/project proof or runtime acceptance'}
    save('receipt.json', receipt)
    print(json.dumps(receipt, indent=2))

if __name__ == '__main__':
    main()

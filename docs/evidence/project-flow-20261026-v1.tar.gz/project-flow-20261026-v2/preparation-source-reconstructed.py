"""Stage exact published Ada inputs for one ordinary whole-project flow check."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

ROOT = Path(__file__).resolve().parent
BASE = ROOT / 'recovery-boundaries-harness-20261026-v10'
DEST = ROOT / 'project-flow-20261026-v2'
PUBLISHED = Path('/home/sicarii/Work/sia-assurance-checkpoint-20261023')
HEAD = 'ddfe2690256a475b5164a6489efa85acca36a9d8'


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def save(name, value):
    with (DEST / name).open('x') as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write('\n')


def snapshot():
    old = json.loads((BASE / 'source-binding.json').read_text())
    names = set(old['files'])
    actual = {str(path.relative_to(PUBLISHED)) for folder in ('src', 'tests')
              for path in (PUBLISHED / 'spark' / folder).iterdir()
              if path.is_file() and path.suffix in ('.ads', '.adb')}
    actual.update(('spark/sia_assurance.gpr', 'spark/restrictions.adc'))
    if names != actual:
        raise ValueError('published source roster differs from retained complete snapshot')
    rows = {}
    for name in sorted(names):
        source = PUBLISHED / name
        if source.is_symlink() or sha(source) != old['files'][name]['sha256']:
            raise ValueError('published source differs from final selected proof: ' + name)
        target = DEST / 'source' / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, target)
        target.chmod(0o444)
        rows[name] = dict(bytes=target.stat().st_size, sha256=sha(target),
                          canonical_sha256=sha(source))
    save('source-binding.json', dict(canonical=str(PUBLISHED), head=HEAD,
        status='PUBLISHED_SOURCE_NEW_FLOW_SCOPE_UNRUN', files=rows,
        source_note='All retained final proof inputs match published bytes; no source edit.'))
    return rows


def configuration():
    config = json.loads((BASE / 'config.json').read_text())
    for key in ('command', 'namespace_prefix'):
        config[key] = [value.replace(str(BASE), str(DEST)) for value in config[key]]
    config['proof_command'] = [config['proof_command'][0], '-P',
        '/tmp/source/spark/sia_assurance.gpr', '-U', '--mode=flow',
        '--assumptions', '--no-inlining', '--memlimit=512', '--timeout=10', '-j1']
    config['candidate_phase'] = 'whole_project_flow'
    config['status'] = 'SOURCE_PREPARATION_NOT_EXECUTED'
    config['recovery_ledger'] = json.loads(
        (ROOT / 'ordinary-post-cut-20261026-v1/config.json').read_text())['recovery_ledger']
    for path, expected in config['proof_tools'].items():
        if sha(Path(path)) != expected:
            raise ValueError('proof tool changed: ' + path)
    for name, expected in config['helper_hashes'].items():
        if sha(Path(config['helper_root']) / name) != expected:
            raise ValueError('helper changed: ' + name)
    save('config.json', config)


def main():
    revision = subprocess.run(['git', '-C', str(PUBLISHED), 'rev-parse', 'HEAD'],
        check=True, capture_output=True, text=True).stdout.strip()
    status = subprocess.run(['git', '-C', str(PUBLISHED), 'status', '--porcelain'],
        check=True, capture_output=True, text=True).stdout
    if revision != HEAD or status or shutil.disk_usage(ROOT).free < 10_000_000_000:
        raise ValueError('published source or physical reserve precondition')
    DEST.mkdir()
    for name in ('obj', 'bin', 'home', 'tmp', 'cache', 'out'):
        (DEST / name).mkdir(mode=0o700)
    rows = snapshot()
    configuration()
    shutil.copyfile(BASE / 'proof_payload.py', DEST / 'proof_payload.py')
    shutil.copyfile(ROOT / 'ordinary-replay-refusal-20261026-v2/receipt_candidate.py',
                    DEST / 'proof_wrapper.py')
    names = ('proof_wrapper.py', 'proof_payload.py', 'config.json', 'source-binding.json')
    save('execution-source.json', {name: sha(DEST / name) for name in names})
    save('preparation.json', dict(source_head=HEAD, source_rows=len(rows),
        manifest_sha256=sha(DEST / 'execution-source.json'),
        execution='UNRUN', free_bytes=shutil.disk_usage(ROOT).free,
        scope='Whole-project flow only, not deductive proof or custody acceptance'))
    print((DEST / 'preparation.json').read_text(), end='')


if __name__ == '__main__':
    main()

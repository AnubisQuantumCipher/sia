"""Deterministic evidence package for a flow-only checkpoint, never a release."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import sys
import tarfile

ROOT = Path(__file__).resolve().parent
OUTPUT = ROOT / 'project-flow-package-20261026-v1'
PUBLISHED = Path('/home/sicarii/Work/sia-assurance-checkpoint-20261023')
NAME = 'project-flow-20261026-v1.tar.gz'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def sources():
    rows = {}
    folders = ('project-flow-20261026-v1', 'project-flow-20261026-v2',
               'project-flow-20261026-v3', 'flow-setup-reconciliation-20261026-v1')
    for folder in folders:
        for path in (ROOT / folder).iterdir():
            if path.is_file() and not path.is_symlink():
                rows[str(path.relative_to(ROOT))] = path.read_bytes()
    run = ROOT / folders[2]
    binding = json.loads((run / 'source-binding.json').read_text())
    for name in binding['files']:
        rows[folders[2] + '/source/' + name] = (run / 'source' / name).read_bytes()
    report = run / 'obj/gnatprove'
    rows[folders[2] + '/obj/gnatprove/gnatprove.out'] = (report / 'gnatprove.out').read_bytes()
    for path in report.glob('*.spark'):
        rows[str(path.relative_to(ROOT))] = path.read_bytes()
    config = json.loads((run / 'config.json').read_text())
    for name in config['helper_hashes']:
        rows['execution-helpers/' + name] = (Path(config['helper_root']) / name).read_bytes()
    for name in ('prepare_project_flow_20261026.py', 'audit_project_flow_20261026.py',
                 'NATIVE-PATH-DECISION-20261026.json', Path(__file__).name):
        rows[name] = (ROOT / name).read_bytes()
    return rows


def archive(rows):
    output = io.BytesIO()
    with gzip.GzipFile(fileobj=output, mode='wb', filename='', mtime=0) as zipped:
        with tarfile.open(fileobj=zipped, mode='w', format=tarfile.USTAR_FORMAT) as bundle:
            for name, raw in sorted(rows.items()):
                info = tarfile.TarInfo(name)
                info.size = len(raw)
                info.mode = 0o644
                bundle.addfile(info, io.BytesIO(raw))
    return output.getvalue()


def outputs(rows):
    raw = archive(rows)
    audit = json.loads(rows['project-flow-20261026-v3/OWNER-FLOW-AUDIT.json'])
    value = dict(status='FLOW_SCOPE_PASS_NO_DEDUCTIVE_PROOF',
        source_head=audit['source_head'], archive=dict(name=NAME, sha256=sha(raw), bytes=len(raw)),
        members={name: dict(sha256=sha(data), bytes=len(data)) for name, data in sorted(rows.items())},
        scope='All 50 declared Ada units in sia_assurance.gpr; 1522 flow checks; no deductive proof.',
        remaining=['Separate transport/allocation projects', 'Whole-project deductive proof',
                   'Current pending reconciliation', 'Native custody and original record joins',
                   'Repeated real compaction', 'R05 BOTH', 'Astra judge', 'Installed/release/marketplace'],
        provenance='Owner-recorded execution and GPT-6.1 independent readback; unsigned artifacts',
        non_claims=['No source-code change in this checkpoint', 'No whole-system assurance or certification'])
    manifest = (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()
    return {OUTPUT / NAME: raw, OUTPUT / 'manifest.json': manifest,
        PUBLISHED / 'docs/evidence' / NAME: raw,
        PUBLISHED / 'docs/PROJECT-FLOW-EVIDENCE-20261026.json': manifest}


def main():
    if sys.argv[1:] not in ([], ['--check']):
        raise ValueError('unsupported arguments')
    for path, raw in outputs(sources()).items():
        if sys.argv[1:]:
            if path.read_bytes() != raw:
                raise ValueError('package differs: ' + str(path))
        else:
            path.parent.mkdir(exist_ok=True)
            path.write_bytes(raw)
    print('CHECK_MATCH' if sys.argv[1:] else 'PACKAGE_WRITTEN')


if __name__ == '__main__':
    main()

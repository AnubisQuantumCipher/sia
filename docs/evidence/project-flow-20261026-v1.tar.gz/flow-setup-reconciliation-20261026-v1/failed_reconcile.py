"""Disposition of one failed setup; neither completion nor successor authority."""
from contextlib import ExitStack
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
ATTEMPT = ROOT.parent / 'project-flow-20261026-v2'
MANIFEST = '1d28f81de14b9b691958edd9b06a817cc62bd984c607f50a11dc8b981fb58bf4'
PENDING = '487eeb6af7321dbd1d8169ccf3a97fe93ddb152d113cad67942a6c48e040b8a4'
SCOPE = 'ABORTED_SETUP_BEFORE_PROOF_ADMISSION'
ERROR = b"bwrap: Can't create file /tmp/source/spark/obj: Read-only file system\n"
EVIDENCE = ('config.json', 'source-binding.json', 'execution-source.json',
    'proof_wrapper.py', 'proof_payload.py', 'entry.json', 'execution-result.json',
    'proof.stdout', 'proof.stderr', 'TOOL-EXIT-OBSERVATION.json', 'PENDING-READBACK.json')
SOURCES = ('failed_reconcile.py', 'normal_reconcile.py', 'candidate.py',
           'readback.py', 'test_normal.py', 'test_failure.py', 'decision.json')


def digest(path):
    if path.is_symlink() or not path.is_file() or path.stat().st_size > 1048576:
        raise ValueError('bounded regular input required')
    with path.open('rb') as stream:
        raw = stream.read(1048577)
    if len(raw) > 1048576:
        raise ValueError('input grew')
    return hashlib.sha256(raw).hexdigest()


def load_module(name):
    spec = importlib.util.spec_from_file_location(name, ROOT / (name + '.py'))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def source_argument():
    if len(sys.argv) != 2 or digest(ROOT / 'source.json') != sys.argv[1]:
        raise ValueError('fixed source argument required')
    expected = json.loads((ROOT / 'source.json').read_text())
    if set(expected) != set(SOURCES):
        raise ValueError('closed source roster required')
    for name, wanted in expected.items():
        if digest(ROOT / name) != wanted:
            raise ValueError('source changed')


def check_result(result, acknowledgment):
    if result['execution_status'] != 'FAILED_OR_INCOMPLETE' \
            or result['proof_dispatched'] is not False or result['peers'] != [] \
            or result['error'] != dict(type='TimeoutError', message='timed out'):
        raise ValueError('different failure phase')
    cleanup = result['cleanup']
    if cleanup != dict(complete=True, errors=[], signals={}, waited=1,
                       observations={'launcher': dict(mask=17, reaped=True, terminal=True)}):
        raise ValueError('launcher termination evidence mismatch')
    if acknowledgment['exit_code'] != 1 or acknowledgment['reported_result'] != result \
            or acknowledgment['session_id'] != 16088 or acknowledgment['tool_chunk'] != '69ea64':
        raise ValueError('outer acknowledgment mismatch')


def verify_failure(decision):
    if decision['scope'] != SCOPE or decision['operation_manifest'] != MANIFEST \
            or decision['pending_sha256'] != PENDING or decision['successor_admitted'] \
            or decision['replay_authorized'] or decision['authority'] != 'NONE':
        raise ValueError('exact failed-attempt disposition only')
    if set(decision['evidence_sha256']) != set(EVIDENCE):
        raise ValueError('closed evidence roster')
    for name, wanted in decision['evidence_sha256'].items():
        if digest(ATTEMPT / name) != wanted:
            raise ValueError('failure evidence changed')
    config = json.loads((ATTEMPT / 'config.json').read_text())
    entry = json.loads((ATTEMPT / 'entry.json').read_text())
    if entry['command'] != config['command'] or entry['manifest'] != json.loads(
            (ATTEMPT / 'execution-source.json').read_text()) \
            or digest(ATTEMPT / 'execution-source.json') != MANIFEST:
        raise ValueError('execution binding mismatch')
    check_result(json.loads((ATTEMPT / 'execution-result.json').read_text()),
                 json.loads((ATTEMPT / 'TOOL-EXIT-OBSERVATION.json').read_text()))
    if (ATTEMPT / 'proof.stderr').read_bytes() != ERROR \
            or (ATTEMPT / 'proof.stdout').read_bytes() != b'':
        raise ValueError('unexpected setup output')
    for name in ('active.json', 'obj/gnatprove', 'obj/gnatprove/gnatprove.out'):
        if os.path.lexists(ATTEMPT / name):
            raise ValueError('unexpected admission or proof artifact')


def ledger_before(candidate, reader, decision):
    names = set()
    with os.scandir(candidate.LEDGER) as entries:
        for entry in entries:
            if len(names) >= 8:
                raise ValueError('extra ledger record')
            names.add(entry.name)
    if names != set(decision['ledger_before']):
        raise ValueError('ledger roster changed')
    for name, wanted in decision['ledger_before'].items():
        _, row = reader.read_file(name)
        if row['sha256'] != wanted:
            raise ValueError('ledger record changed')
        if name == 'pending.json' and row['identity'] != decision['pending_identity']:
            raise ValueError('pending identity changed')


def main():
    source_argument()
    decision = json.loads((ROOT / 'decision.json').read_text())
    verify_failure(decision)
    candidate, normal, reader = (load_module(name) for name in
                                  ('candidate', 'normal_reconcile', 'readback'))
    candidate.ROOT = ATTEMPT
    normal.PENDING_SHA = PENDING
    normal.RETIRED = 'retired-' + MANIFEST + '.json'
    normal.DECISION = 'decision-' + MANIFEST + '.json'
    config = json.loads((ATTEMPT / 'config.json').read_text())
    helper = candidate.helpers(config)
    with ExitStack() as stack:
        lock = helper.hold_lock(stack)
        source_argument()
        verify_failure(decision)
        candidate.verify_host(config, helper)
        helper.validate_tools(config)
        candidate.verify_manifest(json.loads((ATTEMPT / 'execution-source.json').read_text()))
        candidate.verify_inputs(config, json.loads((ATTEMPT / 'source-binding.json').read_text()))
        if candidate.metadata(lock) != decision['lock_identity'] \
                or candidate.metadata(helper.LOCK.lstat()) != decision['lock_identity'] \
                or candidate.metadata(ATTEMPT.lstat()) != decision['output_identity']:
            raise ValueError('lock or output identity changed')
        ledger_before(candidate, reader, decision)
        result = normal.reconcile_once(candidate, config['recovery_ledger'], decision)
    result['status'] = SCOPE
    result['observation_scope'] = 'Launcher terminal only; generic descendants unqualified'
    print(json.dumps(result), flush=True)


if __name__ == '__main__':
    main()

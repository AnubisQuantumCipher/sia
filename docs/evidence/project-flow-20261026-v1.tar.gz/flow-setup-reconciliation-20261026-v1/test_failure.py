"""Exact failed-setup predicates; no production ledger access."""
import copy
import json
from pathlib import Path
import unittest
from unittest import mock

import failed_reconcile as subject

ROOT = Path(__file__).resolve().parent


class FailedSetup(unittest.TestCase):
    def setUp(self):
        self.result = json.loads((subject.ATTEMPT / 'execution-result.json').read_text())
        self.tool = json.loads((subject.ATTEMPT / 'TOOL-EXIT-OBSERVATION.json').read_text())
        self.decision = json.loads((ROOT / 'decision.json').read_text())

    def refused(self, result=None, tool=None):
        with self.assertRaises(ValueError):
            subject.check_result(result or self.result, tool or self.tool)

    def test_exact_failed_setup_is_consistent_only(self):
        subject.check_result(self.result, self.tool)
        subject.verify_failure(self.decision)
        self.assertFalse(self.decision['successor_admitted'])
        self.assertEqual(self.decision['authority'], 'NONE')

    def test_successful_execution_does_not_fit_failed_disposition(self):
        self.result['execution_status'] = 'TERMINAL_REPORTS_REQUIRE_AUDIT'
        self.refused()

    def test_dispatched_or_non_boolean_refuses(self):
        for value in (True, 0, None):
            with self.subTest(value=value):
                self.result['proof_dispatched'] = value
                self.refused()

    def test_peer_entry_refuses(self):
        self.result['peers'] = [{'role': 'leader'}]
        self.refused()

    def test_other_failure_refuses(self):
        self.result['error'] = dict(type='OSError', message='different')
        self.refused()

    def test_unreaped_or_signaled_launcher_refuses(self):
        for key, value in (('complete', False), ('errors', ['error']),
                           ('signals', {'launcher': 'SIGKILL'}), ('waited', 0)):
            changed = copy.deepcopy(self.result)
            changed['cleanup'][key] = value
            with self.subTest(key=key):
                self.refused(result=changed)

    def test_missing_or_extra_observation_refuses(self):
        self.result['cleanup']['observations']['leader'] = dict(mask=17, reaped=True, terminal=True)
        self.refused()

    def test_outer_exit_and_session_mismatch_refuse(self):
        for key, value in (('exit_code', 0), ('session_id', 1), ('tool_chunk', 'different')):
            changed = copy.deepcopy(self.tool)
            changed[key] = value
            with self.subTest(key=key):
                self.refused(tool=changed)

    def test_outer_report_mismatch_refuses(self):
        self.tool['reported_result'] = {}
        self.refused()

    def test_scope_and_replay_or_successor_refuse(self):
        for key, value in (('scope', 'COMPLETED'), ('replay_authorized', True),
                           ('successor_admitted', True), ('authority', 'ALLOW')):
            changed = copy.deepcopy(self.decision)
            changed[key] = value
            with self.subTest(key=key), self.assertRaises(ValueError):
                subject.verify_failure(changed)

    def test_mismatched_and_missing_evidence_refuse(self):
        for mode in ('missing', 'changed'):
            changed = copy.deepcopy(self.decision)
            if mode == 'missing':
                del changed['evidence_sha256']['proof.stderr']
            else:
                changed['evidence_sha256']['proof.stderr'] = '0' * 64
            with self.subTest(mode=mode), self.assertRaises(ValueError):
                subject.verify_failure(changed)

    def test_unexpected_admission_record_refuses(self):
        with mock.patch.object(subject.os.path, 'lexists', return_value=True), \
                self.assertRaises(ValueError):
            subject.verify_failure(self.decision)


if __name__ == '__main__':
    unittest.main()

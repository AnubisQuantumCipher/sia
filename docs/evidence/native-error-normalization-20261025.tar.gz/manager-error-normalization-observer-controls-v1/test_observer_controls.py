"""Extracted-function and synthetic-PCH controls; never launch the observer."""
import ast
import copy
import hashlib
import json
from pathlib import Path
import types
import tempfile
import unittest


BASE = Path('/home/sicarii/Work/sia-assurance-evidence-20261019')
CURRENT = BASE / 'ownership-transfer-20261024/manager-error-normalization-compiler-preparation-v1'
OLD = BASE / 'takeover-linux-manager-witness-c5-clock-predicates-v6-first-static-preparation-v1'
FIELDS = ('st_dev', 'st_ino', 'st_mode', 'st_nlink', 'st_uid', 'st_gid',
          'st_size', 'st_mtime_ns', 'st_ctime_ns')


def bounded_bytes(path, digest):
    with path.open('rb') as stream:
        raw = stream.read(1048577)
    if len(raw) > 1048576 or hashlib.sha256(raw).hexdigest() != digest:
        raise ValueError('fixture/source binding failed: ' + str(path))
    return raw


def functions_only():
    path = CURRENT / 'ROOTC-COMPOSED-OBSERVER.py'
    raw = bounded_bytes(path, 'de799893330d1fd3d42046aea1ed0d7e1c207e8209fa7abb5fb1c453f4c4b2c7')
    parsed = ast.parse(raw, filename=str(path))
    names = {'require', 'merge', 'current_revision', 'snapshot', 'pch_absent', 'checked_current_closure', 'load'}
    selected = [node for node in parsed.body
                if isinstance(node, ast.FunctionDef) and node.name in names]
    if len(selected) != len(names) or {node.name for node in selected} != names:
        raise ValueError('function extraction roster mismatch')
    module = ast.Module(body=selected, type_ignores=[])
    namespace = {'F': FIELDS, 'hashlib': hashlib, 'json': json}
    exec(compile(module, str(path), 'exec', dont_inherit=True), namespace)
    return namespace


class RevisionControls(unittest.TestCase):
    def setUp(self):
        self.namespace = functions_only()
        raw = bounded_bytes(CURRENT / 'CURRENT-INPUTS.json',
                            'd46509021674de5dfa96e433ad126b5a091cdff5d6e638437a4414169240b8a1')
        self.revision = json.loads(raw)
        raw = bounded_bytes(OLD / 'C-root-external-v1/admission.json',
                            '7645ec40f8a8aaa108faf9a9ed6a04ad480d33df50987bc02878e9d6b51b2e6b')
        self.history = json.loads(raw)['before']
        self.expected = copy.deepcopy(self.history)
        self.memory = self.revision['memory_path']

    def current(self):
        return self.namespace['current_revision'](
            self.expected, self.revision, self.history)

    def refuse(self, message):
        with self.assertRaisesRegex(ValueError, message):
            self.current()

    def test_valid_revision_preserves_originals(self):
        before = copy.deepcopy(self.history)
        current = self.current()
        self.assertEqual(self.history, before)
        self.assertEqual(self.expected, before)
        self.assertEqual(current[self.memory], self.revision['current_memory'])
        for name, item in self.history.items():
            if name != self.memory:
                self.assertEqual(current[name], item)

    def test_wrong_schema(self):
        self.revision['schema'] = 'wrong'
        self.refuse('current admission schema')

    def test_wrong_context_path(self):
        self.revision['memory_path'] = '/mock/other-context'
        self.refuse('only reviewed contextual path')

    def test_wrong_historical_context(self):
        self.revision['historical_memory']['sha256'] = '0' * 64
        self.refuse('historical contextual join')

    def test_wrong_historical_map_context(self):
        self.revision['historical_run_map'][self.memory]['sha256'] = '0' * 64
        self.refuse('historical355 context')

    def test_erased_historical_failure(self):
        self.revision['historical_memory_comparison'] = 'PASS'
        self.refuse('historical refusal retained')

    def test_current_context_disagreement(self):
        self.revision['current_memory']['sha256'] = '0' * 64
        self.refuse('current contextual join')

    def test_old_context_replayed_as_current(self):
        self.revision['current_memory'] = copy.deepcopy(self.history[self.memory])
        self.revision['inputs'][self.memory] = copy.deepcopy(self.history[self.memory])
        self.refuse('explicit distinct revision')

    def test_noncontext_conflict(self):
        name = next(name for name in self.revision['inputs']
                    if name in self.history and name != self.memory)
        self.revision['inputs'][name]['sha256'] = '0' * 64
        self.refuse('join disagreement')

    def test_historical_row_omitted(self):
        name = next(name for name in self.history if name != self.memory)
        del self.revision['historical_run_map'][name]
        self.refuse('exact authenticated historical355 roster')

    def test_historical_row_substituted_same_count(self):
        name = next(name for name in self.history if name != self.memory)
        replacement = next(name for name in self.revision['inputs']
                           if name not in self.history)
        del self.revision['historical_run_map'][name]
        self.revision['historical_run_map'][replacement] = self.revision['inputs'][replacement]
        self.assertEqual(len(self.revision['historical_run_map']), len(self.history))
        self.refuse('exact authenticated historical355 roster')

    def test_missing_noncontext_original(self):
        name = next(name for name in self.history if name != self.memory)
        del self.expected[name]
        self.revision['inputs'].pop(name, None)
        self.refuse('original355 scope and noncontext preservation')

    def test_missing_metadata_field(self):
        name = next(name for name in self.revision['inputs'] if name not in self.history)
        del self.revision['inputs'][name]['identity']['st_gid']
        self.refuse('full9 schema')

    def test_boolean_metadata_refused(self):
        name = next(name for name in self.revision['inputs'] if name not in self.history)
        self.revision['inputs'][name]['identity']['st_uid'] = True
        self.refuse('native integer metadata')

    def test_oversized_input_map(self):
        row = copy.deepcopy(self.revision['current_memory'])
        for index in range(513):
            self.revision['inputs']['/mock/input-' + str(index)] = row
        self.refuse('fixed construction map bound')

    def test_oversized_merged_map(self):
        row = copy.deepcopy(self.history[self.memory])
        for index in range(513):
            self.expected['/mock/expected-' + str(index)] = row
        self.refuse('fixed total host map bound')

    def closed(self):
        plan = json.loads(bounded_bytes(CURRENT / 'PIN-PLAN.json',
            '4431ca5ccddd34db8461cb2a82820b886c9a086aca9abd16c0811b1abcdd0e42'))
        previous = json.loads(bounded_bytes(BASE / 'ownership-transfer-20261024/manager-send-lifetime-compiler-preparation-v1/CURRENT-INPUTS.json',
            '0bbaa9272075119d9e0b8c00bee0e9b405158e56a7c938e185f82e0c11bebd2b'))
        return self.namespace['checked_current_closure'](self.revision, plan, self.history, previous['inputs'])

    def test_complete_current_closure(self):
        self.assertEqual(self.closed(), self.revision['inputs'])

    def previous_closure_fixture(self):
        previous = json.loads(bounded_bytes(BASE / 'ownership-transfer-20261024/manager-send-lifetime-compiler-preparation-v1/CURRENT-INPUTS.json',
            '0bbaa9272075119d9e0b8c00bee0e9b405158e56a7c938e185f82e0c11bebd2b'))
        plan = json.loads(bounded_bytes(CURRENT / 'PIN-PLAN.json',
            '4431ca5ccddd34db8461cb2a82820b886c9a086aca9abd16c0811b1abcdd0e42'))
        return previous['inputs'], plan

    def test_omitted_previous_map_row(self):
        previous, plan = self.previous_closure_fixture()
        previous.pop(next(iter(previous)))
        with self.assertRaisesRegex(ValueError, 'exact previous current dependency roster'):
            self.namespace['checked_current_closure'](self.revision, plan, self.history, previous)

    def test_substituted_previous_map_row(self):
        previous, plan = self.previous_closure_fixture()
        name = next(name for name in previous if name not in self.history and name not in plan['inputs'])
        previous['/mock/changed-dependency'] = previous.pop(name)
        with self.assertRaisesRegex(ValueError, 'exact bounded current dependency closure'):
            self.namespace['checked_current_closure'](self.revision, plan, self.history, previous)

    def test_conflicting_previous_original_row(self):
        previous, plan = self.previous_closure_fixture()
        name = next(name for name in self.history if name != self.memory)
        previous[name]['sha256'] = '0' * 64
        with self.assertRaisesRegex(ValueError, 'join disagreement'):
            self.namespace['checked_current_closure'](self.revision, plan, self.history, previous)

    def test_all_previous_inputs_remain_current(self):
        previous, _plan = self.previous_closure_fixture()
        current = self.closed()
        for name, row in previous.items():
            with self.subTest(path=name):
                self.assertEqual(current[name], row)

    def test_candidate_pch_negatives_are_additive(self):
        with tempfile.TemporaryDirectory() as directory:
            self.namespace['B'] = Path(directory)
            rows = self.namespace['pch_absent']()
            candidate = [name for name in rows if 'manager-send-lifetime-source-v1/source/' in name]
            self.assertEqual(len(candidate), 2)
            self.assertEqual({Path(name).name for name in candidate}, {'witness.h.gch', 'commission.h.gch'})

    def test_omitted_current_source_dependency(self):
        name = next(name for name in self.revision['inputs']
                    if 'manager-send-lifetime-source-v1/source/witness_io.c' in name)
        del self.revision['inputs'][name]
        with self.assertRaisesRegex(ValueError, 'exact bounded current dependency closure'):
            self.closed()

    def test_omitted_current_controller(self):
        del self.revision['inputs'][str(CURRENT / 'controller.py')]
        with self.assertRaisesRegex(ValueError, 'omitted operative evidence dependency'):
            self.closed()

    def test_omitted_historical_receipt(self):
        name = next(name for name in self.revision['inputs']
                    if 'manager-descriptor-flag-compiler-preparation-v1/C-root-external-v1/admission.json' in name)
        del self.revision['inputs'][name]
        with self.assertRaisesRegex(ValueError, 'exact bounded current dependency closure'):
            self.closed()

    def test_original_admission_is_operative(self):
        name = str(OLD / 'C-root-external-v1/admission.json')
        self.assertIn(name, self.closed())
        self.assertEqual(self.closed()[name]['sha256'],
            '7645ec40f8a8aaa108faf9a9ed6a04ad480d33df50987bc02878e9d6b51b2e6b')

    def test_original_admission_omitted(self):
        del self.revision['inputs'][str(OLD / 'C-root-external-v1/admission.json')]
        with self.assertRaisesRegex(ValueError, 'exact bounded current dependency closure'):
            self.closed()

    def test_original_admission_substitution_refused(self):
        digest = '7645ec40f8a8aaa108faf9a9ed6a04ad480d33df50987bc02878e9d6b51b2e6b'
        self.namespace['row'] = lambda name: {'sha256': '0' * 64}
        with self.assertRaisesRegex(ValueError, 'fixed governing SHA'):
            self.namespace['load'](OLD / 'C-root-external-v1/admission.json', digest)

    def test_extra_unclassified_dependency(self):
        self.revision['inputs']['/mock/unclassified'] = copy.deepcopy(self.revision['current_memory'])
        with self.assertRaisesRegex(ValueError, 'exact bounded current dependency closure'):
            self.closed()

    def test_mutated_historical_record_refused(self):
        current = self.closed()
        observed = copy.deepcopy(current)
        name = next(name for name in observed
                    if 'manager-descriptor-flag-compiler-preparation-v1/C-root-external-v1/admission.json' in name)
        observed[name]['sha256'] = '0' * 64
        self.install_snapshot_fixture(observed)
        with self.assertRaisesRegex(ValueError, 'input endpoint mismatch'):
            self.namespace['snapshot'](current, 1)

    def test_changed_original_pin_rejected_by_closure(self):
        name = next(name for name in self.history if name != self.memory)
        self.revision['inputs'][name]['sha256'] = '0' * 64
        with self.assertRaisesRegex(ValueError, 'exact bounded current dependency closure|join disagreement'):
            self.closed()

    def test_governing_json_modified_after_pin_refused(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'record.json'
            raw = b'{"status":"original"}'
            with path.open('xb') as stream:
                self.assertEqual(stream.write(raw), len(raw))
            digest = hashlib.sha256(raw).hexdigest()
            self.namespace['row'] = lambda name: {'sha256': digest}
            self.assertEqual(self.namespace['load'](path, digest), {'status': 'original'})
            with path.open('wb') as stream:
                changed = b'{"status":"mutated"}'
                self.assertEqual(stream.write(changed), len(changed))
            with self.assertRaisesRegex(ValueError, 'governing read hash'):
                self.namespace['load'](path, digest)

    def test_json_load_original_cap(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'record.json'
            raw = b' ' * 1048577
            with path.open('xb') as stream:
                self.assertEqual(stream.write(raw), len(raw))
            digest = hashlib.sha256(raw).hexdigest()
            self.namespace['row'] = lambda name: {'sha256': digest}
            with self.assertRaisesRegex(ValueError, 'original JSON bound'):
                self.namespace['load'](path, digest)

    def test_synthetic_all_five_pch_roots_absent(self):
        with tempfile.TemporaryDirectory() as directory:
            self.namespace['B'] = Path(directory)
            rows = self.namespace['pch_absent']()
            self.assertEqual(len(rows), 14)
            self.assertTrue(all(value == 'ENOENT' for value in rows.values()))
            self.assertTrue(any('manager-loop-or-compiler-source-v1' in name
                                for name in rows))
            self.assertTrue(any('manager-bounded-summary-compiler-source-v1' in name
                                for name in rows))

    def test_each_synthetic_pch_presence_refused(self):
        with tempfile.TemporaryDirectory() as directory:
            self.namespace['B'] = Path(directory)
            names = self.namespace['pch_absent']()
            for name in names:
                with self.subTest(path=name):
                    path = Path(name)
                    path.parent.mkdir(parents=True, exist_ok=True)
                    data = b'synthetic PCH'
                    with path.open('xb') as stream:
                        self.assertEqual(stream.write(data), len(data))
                    try:
                        with self.assertRaisesRegex(ValueError, 'unexpected source PCH entry'):
                            self.namespace['pch_absent']()
                    finally:
                        path.unlink()

    def install_snapshot_fixture(self, current):
        self.namespace['row'] = lambda name: copy.deepcopy(current[name])
        self.namespace['time'] = types.SimpleNamespace(monotonic_ns=lambda: 0)

    def test_valid_before_after_snapshots(self):
        current = self.current()
        self.install_snapshot_fixture(current)
        before = self.namespace['snapshot'](current, 1)
        after = self.namespace['snapshot'](current, 1)
        self.assertEqual(before, current)
        self.assertEqual(before, after)

    def test_drift_before_snapshot(self):
        current = self.current()
        observed = copy.deepcopy(current)
        observed[self.memory]['sha256'] = '0' * 64
        self.install_snapshot_fixture(observed)
        with self.assertRaisesRegex(ValueError, 'input endpoint mismatch'):
            self.namespace['snapshot'](current, 1)

    def test_drift_after_successful_before_snapshot(self):
        current = self.current()
        observed = copy.deepcopy(current)
        self.install_snapshot_fixture(observed)
        self.assertEqual(self.namespace['snapshot'](current, 1), current)
        observed[self.memory]['identity']['st_mtime_ns'] += 1
        with self.assertRaisesRegex(ValueError, 'input endpoint mismatch'):
            self.namespace['snapshot'](current, 1)

    def test_old_memory_replay_at_snapshot(self):
        current = self.current()
        observed = copy.deepcopy(current)
        observed[self.memory] = copy.deepcopy(self.history[self.memory])
        self.install_snapshot_fixture(observed)
        with self.assertRaisesRegex(ValueError, 'input endpoint mismatch'):
            self.namespace['snapshot'](current, 1)

    def test_expired_snapshot_deadline(self):
        current = self.current()
        self.install_snapshot_fixture(current)
        with self.assertRaisesRegex(ValueError, 'original120 shared work deadline'):
            self.namespace['snapshot'](current, 0)


if __name__ == '__main__':
    unittest.main(verbosity=2)

/* SOURCE ONLY. Protocol4 C/D/T ownership; SAVED_UNRUN. */
#include "witness.h"
#include <errno.h>
#include <fcntl.h>
#include <limits.h>
#include <poll.h>
#include <string.h>
#include <time.h>
#include <sys/random.h>
#include <unistd.h>


_Static_assert(sizeof(int)==4U, "selected descriptor ABI");
_Static_assert(CHAR_BIT==8 && sizeof(uint32_t)==4U && sizeof(uint64_t)==8U,
    "wire octet and unsigned scalar budgets");
_Static_assert(MW_RX_FDS>=MW_CONTROL/sizeof(int), "TOTAL control capacity");
_Static_assert(MW_FDS==9 && MW_RX_FDS==64 && MW_FAULTS==24 && MW_CLOSE==10,
    "literal block coverage extents");
_Static_assert(MW_REQUEST==176 && MW_POLLS==160,
    "fixed request reset and private poll coverage");
_Static_assert(sizeof(int)*MW_FDS<=64U, "fixed borrowed snapshot budget");

enum poll_outcome {
    MPO_PENDING, MPO_READY, MPO_INITIAL_CLOCK, MPO_EXPIRED,
    MPO_SYSCALL_ERROR, MPO_BAD_READY, MPO_POST_CLOCK
};
struct poll_observation {
    enum poll_outcome outcome;
    int error;
};
enum send_outcome { MSO_ERROR, MSO_NONNEGATIVE };
struct send_observation {
    enum send_outcome outcome;
    ssize_t count;
    int error;
};
_Static_assert(sizeof(struct poll_observation)<=16U, "poll record budget");
_Static_assert(sizeof(struct send_observation)<=32U, "send record budget");
_Static_assert(sizeof(enum poll_outcome)<=8U && sizeof(enum send_outcome)<=8U,
    "closed observation tag budgets");
_Static_assert(sizeof(struct timespec)<=32U, "clock local budget");
_Static_assert(sizeof(struct pollfd)<=16U, "poll local budget");
_Static_assert(sizeof(struct cmsghdr)<=32U, "ancillary header budget");
_Static_assert(sizeof(struct ucred)<=32U, "credential local budget");
_Static_assert(sizeof(struct iovec)<=32U && sizeof(struct msghdr)<=64U,
    "transport object budgets");
_Static_assert(sizeof(void *)<=16U && sizeof(size_t)<=16U &&
    sizeof(ssize_t)<=16U && sizeof(bool)<=4U && sizeof(short)<=4U &&
    sizeof(enum mw_fault)<=8U && sizeof(enum mw_request)<=8U &&
    sizeof(enum mw_phase)<=8U,
    "source scalar budget premises");

static void zero4(unsigned char *destination)
{
    destination[0]=0U;
    destination[1]=0U;
    destination[2]=0U;
    destination[3]=0U;
}

static void zero_request176(unsigned char *request)
{
    zero4(request+0U);
    zero4(request+4U);
    zero4(request+8U);
    zero4(request+12U);
    zero4(request+16U);
    zero4(request+20U);
    zero4(request+24U);
    zero4(request+28U);
    zero4(request+32U);
    zero4(request+36U);
    zero4(request+40U);
    zero4(request+44U);
    zero4(request+48U);
    zero4(request+52U);
    zero4(request+56U);
    zero4(request+60U);
    zero4(request+64U);
    zero4(request+68U);
    zero4(request+72U);
    zero4(request+76U);
    zero4(request+80U);
    zero4(request+84U);
    zero4(request+88U);
    zero4(request+92U);
    zero4(request+96U);
    zero4(request+100U);
    zero4(request+104U);
    zero4(request+108U);
    zero4(request+112U);
    zero4(request+116U);
    zero4(request+120U);
    zero4(request+124U);
    zero4(request+128U);
    zero4(request+132U);
    zero4(request+136U);
    zero4(request+140U);
    zero4(request+144U);
    zero4(request+148U);
    zero4(request+152U);
    zero4(request+156U);
    zero4(request+160U);
    zero4(request+164U);
    zero4(request+168U);
    zero4(request+172U);
}

static void copy32(unsigned char *destination, const unsigned char *source)
{
    destination[0U]=source[0U];
    destination[1U]=source[1U];
    destination[2U]=source[2U];
    destination[3U]=source[3U];
    destination[4U]=source[4U];
    destination[5U]=source[5U];
    destination[6U]=source[6U];
    destination[7U]=source[7U];
    destination[8U]=source[8U];
    destination[9U]=source[9U];
    destination[10U]=source[10U];
    destination[11U]=source[11U];
    destination[12U]=source[12U];
    destination[13U]=source[13U];
    destination[14U]=source[14U];
    destination[15U]=source[15U];
    destination[16U]=source[16U];
    destination[17U]=source[17U];
    destination[18U]=source[18U];
    destination[19U]=source[19U];
    destination[20U]=source[20U];
    destination[21U]=source[21U];
    destination[22U]=source[22U];
    destination[23U]=source[23U];
    destination[24U]=source[24U];
    destination[25U]=source[25U];
    destination[26U]=source[26U];
    destination[27U]=source[27U];
    destination[28U]=source[28U];
    destination[29U]=source[29U];
    destination[30U]=source[30U];
    destination[31U]=source[31U];
}

static bool same32(const unsigned char *left, const unsigned char *right)
{
    for (size_t i=0U; i<32U; ++i) if (left[i]!=right[i]) return false;
    return true;
}

bool mw_fail(struct mw_state *s, enum mw_fault phase, int error)
{
    if (s->faults[phase]==0)
        s->faults[phase]=error + EIO * (error == 0);
    return false;
}

bool mw_clean(const struct mw_state *s)
{
    unsigned int errors=0U;
    for (size_t i=0U; i<MW_FAULTS; ++i) errors|=(unsigned int)s->faults[i];
    for (size_t i=0U; i<MW_CLOSE; ++i) errors|=(unsigned int)s->closes[i];
    for (size_t i=0U; i<MW_RX_FDS; ++i) errors|=(unsigned int)s->received_closes[i];
    return errors==0U;
}

static int read_clock(uint64_t *result)
{
    struct timespec value={0,0};
    if (clock_gettime(CLOCK_MONOTONIC,&value)!=0)
        return errno!=0 ? errno : EIO;
    bool bad_seconds=value.tv_sec<0;
    bool bad_nanoseconds=value.tv_nsec<0;
    bool large_nanoseconds=value.tv_nsec>=1000000000L;
    bool large_seconds=(uint64_t)value.tv_sec>
        (UINT64_MAX-UINT64_C(999999999))/UINT64_C(1000000000);
    if (((unsigned int)bad_seconds|(unsigned int)bad_nanoseconds|
         (unsigned int)large_nanoseconds|(unsigned int)large_seconds)!=0U)
        return ERANGE;
    *result=(uint64_t)value.tv_sec*UINT64_C(1000000000)+(uint64_t)value.tv_nsec;
    return 0;
}

bool mw_now(struct mw_state *s, uint64_t *result)
{
    uint64_t observed=0U;
    int error=read_clock(&observed);
    if (error==0) *result=observed;
    return error==0 || mw_fail(s,MF_DEADLINE,error);
}

bool mw_timely(struct mw_state *s, uint64_t deadline)
{
    uint64_t now=0U;
    return mw_now(s,&now) && (now<=deadline || mw_fail(s,MF_DEADLINE,ETIMEDOUT));
}

static void observe_poll(int fd, short events, uint64_t deadline,
                          struct poll_observation *observed)
{
    uint64_t now=0U;
    observed->outcome=MPO_INITIAL_CLOCK;
    observed->error=read_clock(&now);
    if (observed->error!=0) return;
    if (now>=deadline) {
        observed->outcome=MPO_EXPIRED;
        observed->error=ETIMEDOUT;
        return;
    }
    uint64_t milliseconds=(deadline-now)/UINT64_C(1000000);
    if (milliseconds==0U) {
        observed->outcome=MPO_EXPIRED;
        observed->error=ETIMEDOUT;
        return;
    }
    if (milliseconds>50U) milliseconds=50U;
    struct pollfd entry={.fd=fd,.events=events,.revents=0};
    int result=poll(&entry,1U,(int)milliseconds);
    if (result<0) {
        observed->outcome=MPO_SYSCALL_ERROR;
        observed->error=errno;
        return;
    }
    if (result==0) { observed->outcome=MPO_PENDING; return; }
    if (result!=1 || entry.revents!=events) {
        observed->outcome=MPO_BAD_READY;
        observed->error=EIO;
        return;
    }
    observed->outcome=MPO_POST_CLOCK;
    observed->error=read_clock(&now);
    if (observed->error==0 && now>deadline) observed->error=ETIMEDOUT;
    if (observed->error==0) observed->outcome=MPO_READY;
}

static void observe_wait4(short events, uint64_t deadline,
                          struct poll_observation *observed)
{
    for (size_t attempt=0U; attempt<4U; ++attempt) {
        observe_poll(STDIN_FILENO,events,deadline,observed);
        if (attempt==3U) return; /* Preserve the final-call no-read frontier. */
        if (observed->outcome!=MPO_PENDING) return;
    }
}

static void observe_wait16(short events, uint64_t deadline,
                          struct poll_observation *observed)
{
    for (size_t attempt=0U; attempt<4U; ++attempt) {
        observe_wait4(events,deadline,observed);
        if (attempt==3U) return; /* Preserve the final-call no-read frontier. */
        if (observed->outcome!=MPO_PENDING) return;
    }
}

static void observe_wait(short events, uint64_t deadline,
                          struct poll_observation *observed)
{
    for (size_t attempt=0U; attempt<10U; ++attempt) {
        observe_wait16(events,deadline,observed);
        if (attempt==9U) return; /* Preserve the final-call no-read frontier. */
        if (observed->outcome!=MPO_PENDING) return;
    }
}

static int commit_poll_phase(struct mw_state *s, enum mw_fault phase, int error)
{
    s->poll_error=error;
    (void)mw_fail(s,phase,error);
    return -1;
}

static int commit_poll(struct mw_state *s, enum mw_fault phase,
                        const struct poll_observation *observed)
{
    switch (observed->outcome) {
    case MPO_PENDING:
    case MPO_READY:
        if (observed->error!=0) break;
        s->poll_error=0;
        return observed->outcome==MPO_READY ? 1 : 0;
    case MPO_INITIAL_CLOCK:
    case MPO_POST_CLOCK:
        if (observed->error==0) break;
        s->poll_error=EIO;
        (void)mw_fail(s,MF_DEADLINE,observed->error);
        if (observed->outcome==MPO_POST_CLOCK) (void)mw_fail(s,phase,EIO);
        return -1;
    case MPO_EXPIRED:
        if (observed->error==ETIMEDOUT)
            return commit_poll_phase(s,phase,observed->error);
        break;
    case MPO_SYSCALL_ERROR:
        return commit_poll_phase(s,phase,observed->error);
    case MPO_BAD_READY:
        if (observed->error==EIO) return commit_poll_phase(s,phase,EIO);
        break;
    default:
        break;
    }
    (void)mw_fail(s,MF_INTERNAL,EPROTO);
    return commit_poll_phase(s,phase,EIO);
}

int mw_poll(struct mw_state *s, int fd, short events, uint64_t deadline,
            enum mw_fault phase)
{
    struct poll_observation observed={0};
    s->poll_error=0;
    observe_poll(fd,events,deadline,&observed); /* Exactly ONE slice. */
    return commit_poll(s,phase,&observed);
}

void mw_close(struct mw_state *s, enum mw_slot slot)
{
    int value=s->fd[slot];
    s->fd[slot]=-1;
    if (value>=0 && close(value)!=0 && s->closes[slot]==0)
        s->closes[slot]=errno!=0 ? errno : EIO;
}

void mw_close_all(struct mw_state *s)
{
    for (size_t i=0U; i<MW_FDS; ++i) mw_close(s,(enum mw_slot)i);
}

bool mw_read(struct mw_state *s, struct mw_data *d, int descriptor, enum mw_fault phase, size_t *length)
{
    ssize_t count=read(descriptor,d->text,MW_TEXT-1U);
    int saved=errno;
    if (count<=0 || (size_t)count>=MW_TEXT-1U)
        return mw_fail(s,phase,count<0 ? saved : EOVERFLOW);
    char extra='\0';
    ssize_t tail=read(descriptor,&extra,1U);
    saved=errno;
    if (tail!=0) return mw_fail(s,phase,tail<0 ? saved : EOVERFLOW);
    d->text[(size_t)count]='\0';
    *length=(size_t)count;
    uint64_t deadline=s->cleanup_started ? s->cleanup_deadline : s->work_deadline;
    return mw_timely(s,deadline);
}

bool mw_leaf(struct mw_state *s, struct mw_data *d, int parent, const char *leaf,
             enum mw_fault phase, size_t *length)
{
    s->fd[MS_TEMP]=openat(parent,leaf,O_RDONLY|O_NOFOLLOW|O_CLOEXEC);
    if (s->fd[MS_TEMP]<0) return mw_fail(s,phase,errno);
    bool result=mw_read(s,d,s->fd[MS_TEMP],phase,length);
    mw_close(s,MS_TEMP);
    return result && s->closes[MS_TEMP]==0;
}

static bool decimal(const char *text, size_t first, size_t end, uint64_t *value)
{
    uint64_t number=0U;
    if (first>=end || end>MW_TEXT) return false;
    for (size_t i=first; i<end; ++i) {
        if (text[i]<'0' || text[i]>'9') return false;
        uint64_t digit=(uint64_t)(unsigned char)(text[i]-'0');
        if (number>(UINT64_MAX-digit)/10U) return false;
        number=number*10U+digit;
    }
    *value=number;
    return true;
}

bool mw_start(const char *text, size_t length, uint64_t *start, uint64_t *threads)
{
    size_t right=length;
    if (length>=MW_TEXT) return false;
    for (size_t i=0U; i<length; ++i) if (text[i]==')') right=i;
    if (right>=length || right+2U>=length || text[right+1U]!=' ') return false;
    size_t cursor=right+2U;
    for (size_t field=0U; field<20U; ++field) {
        size_t first=cursor;
        for (size_t step=0U; step<length && cursor<length; ++step) {
            if (text[cursor]==' ' || text[cursor]=='\n') break;
            ++cursor;
        }
        if (cursor==first || cursor>=length) return false;
        if (field==17U && !decimal(text,first,cursor,threads)) return false;
        if (field==19U) return decimal(text,first,cursor,start) && *start>0U;
        if (text[cursor]!=' ') return false;
        ++cursor;
    }
    return false;
}

static uint32_t get32(const unsigned char *p)
{
    return (((uint32_t)p[0]<<24U)|((uint32_t)p[1]<<16U))|
           (((uint32_t)p[2]<<8U)|(uint32_t)p[3]);
}

static uint64_t get64(const unsigned char *p)
{
    uint32_t high=get32(p), low=get32(p+4U);
    return ((uint64_t)high<<32U)|(uint64_t)low;
}

static void put32(unsigned char *p, uint32_t value)
{
    p[0]=(unsigned char)(value>>24U); p[1]=(unsigned char)(value>>16U);
    p[2]=(unsigned char)(value>>8U); p[3]=(unsigned char)value;
}

static void put64(unsigned char *p, uint64_t value)
{
    p[0]=(unsigned char)(value>>56U); p[1]=(unsigned char)(value>>48U);
    p[2]=(unsigned char)(value>>40U); p[3]=(unsigned char)(value>>32U);
    p[4]=(unsigned char)(value>>24U); p[5]=(unsigned char)(value>>16U);
    p[6]=(unsigned char)(value>>8U); p[7]=(unsigned char)value;
}

static unsigned int conflict4(const int *slots, int value)
{
    unsigned int conflict=0U;
    for (size_t slot=0U; slot<4U; ++slot) {
        conflict|=(unsigned int)(slots[slot]==value);
    }
    return conflict;
}

static unsigned int conflict16(const int *slots, int value)
{
    unsigned int conflict=0U;
    for (size_t group=0U; group<4U; ++group) {
        conflict|=(unsigned int)(conflict4(slots+group*4U,value)!=0U);
    }
    return conflict;
}

static bool disjoint_received(const int *borrowed, const int *received, int value)
{
    unsigned int own=0U;
    for (size_t group=0U; group<2U; ++group) {
        own|=(unsigned int)(conflict4(borrowed+group*4U,value)!=0U);
    }
    own|=(unsigned int)(borrowed[8]==value);
    unsigned int retained=0U;
    for (size_t group=0U; group<4U; ++group) {
        /* Evaluate every chunk even after a conflict; preserve required reads. */
        retained|=(unsigned int)(conflict16(received+group*16U,value)!=0U);
    }
    unsigned int conflict=(unsigned int)(value<3)|own|retained;
    return conflict==0U;
}

static bool retain_at(const int *borrowed, int *received, size_t *used,
                      const unsigned char *data, size_t count, size_t index)
{
    if (index>=MW_RX_FDS) return false;
    if (index>=count) return true;
    int value=-1;
    memcpy(&value,data+index*sizeof(int),sizeof value);
    if (!disjoint_received(borrowed,received,value) || *used>=MW_RX_FDS)
        return false;
    /* Validated kernel SCM_RIGHTS payload establishes NEW ownership.
     * Register before fallible FD validation; never infer it from data frames. */
    received[*used]=value;
    ++*used;
    int flags=fcntl(value,F_GETFD);
    if (value>=8 || flags<0 || (flags&FD_CLOEXEC)==0) return false;
    return true;
}

static bool retain4(const int *borrowed, int *received, size_t *used,
                   const unsigned char *data, size_t count, size_t base)
{
    if (base>MW_RX_FDS-4U) return false;
    bool good=true;
    bool block=retain_at(borrowed,received,used,data,count,base);
    good=(bool)((unsigned int)good&(unsigned int)block);
    block=retain_at(borrowed,received,used,data,count,base+1U);
    good=(bool)((unsigned int)good&(unsigned int)block);
    block=retain_at(borrowed,received,used,data,count,base+2U);
    good=(bool)((unsigned int)good&(unsigned int)block);
    block=retain_at(borrowed,received,used,data,count,base+3U);
    good=(bool)((unsigned int)good&(unsigned int)block);
    return good;
}

static bool retain16(const int *borrowed, int *received, size_t *used,
                   const unsigned char *data, size_t count, size_t base)
{
    if (base>MW_RX_FDS-16U) return false;
    bool good=true;
    bool block=retain4(borrowed,received,used,data,count,base);
    good=(bool)((unsigned int)good&(unsigned int)block);
    block=retain4(borrowed,received,used,data,count,base+4U);
    good=(bool)((unsigned int)good&(unsigned int)block);
    block=retain4(borrowed,received,used,data,count,base+8U);
    good=(bool)((unsigned int)good&(unsigned int)block);
    block=retain4(borrowed,received,used,data,count,base+12U);
    good=(bool)((unsigned int)good&(unsigned int)block);
    return good;
}

static bool retain_rights(const int *borrowed, int *received, size_t *used,
                          const unsigned char *data, size_t bytes)
{
    bool good=bytes%sizeof(int)==0U;
    size_t count=bytes/sizeof(int);
    if (count>MW_RX_FDS) good=false;
    bool block=retain16(borrowed,received,used,data,count,0U);
    good=(bool)((unsigned int)good&(unsigned int)block);
    block=retain16(borrowed,received,used,data,count,16U);
    good=(bool)((unsigned int)good&(unsigned int)block);
    block=retain16(borrowed,received,used,data,count,32U);
    good=(bool)((unsigned int)good&(unsigned int)block);
    block=retain16(borrowed,received,used,data,count,48U);
    good=(bool)((unsigned int)good&(unsigned int)block);
    return good;
}

static bool ancillary(const int *borrowed, int *received, size_t *used,
                      const struct ucred *peer, const unsigned char *control,
                      size_t length)
{
    size_t offset=0U, credentials=0U;
    bool good=length<=MW_CONTROL;
    if (length>MW_CONTROL) length=MW_CONTROL;
    struct ucred sender={0,0,0};
    for (size_t iteration=0U; iteration<MW_CONTROL/sizeof(struct cmsghdr); ++iteration) {
        if (offset>=length || length-offset<sizeof(struct cmsghdr)) break;
        struct cmsghdr header;
        memcpy(&header,control+offset,sizeof header);
        if (header.cmsg_len<CMSG_LEN(0U) || header.cmsg_len>length-offset) {
            good=false;
            break; /* Kernel-constructed header bounds, never caller integers. */
        }
        size_t payload=header.cmsg_len-CMSG_LEN(0U);
        const unsigned char *data=control+offset+CMSG_LEN(0U);
        if (header.cmsg_level==SOL_SOCKET && header.cmsg_type==SCM_RIGHTS) {
            if (!retain_rights(borrowed,received,used,data,payload)) good=false;
            good=false; /* Rights are forbidden, but ALWAYS drain every header. */
        } else if (header.cmsg_level==SOL_SOCKET && header.cmsg_type==SCM_CREDENTIALS) {
            ++credentials;
            if (payload==sizeof sender) memcpy(&sender,data,sizeof sender);
            else good=false;
        } else good=false;
        size_t step=CMSG_ALIGN(header.cmsg_len);
        if (step>length-offset) { offset=length; break; }
        offset+=step;
    }
    if (credentials!=1U || sender.uid!=peer->uid || sender.gid!=peer->gid ||
        sender.pid!=peer->pid) good=false;
    return good;
}

static bool dispose_one(int *slot, int *saved_error)
{
    int value=*slot;
    *slot=-1;
    if (value>=0 && close(value)!=0) {
        if (*saved_error==0) *saved_error=errno!=0 ? errno : EIO;
        return false;
    }
    return true;
}

static bool dispose4(int *slots, int *errors)
{
    bool a=dispose_one(slots,errors);
    bool b=dispose_one(slots+1U,errors+1U);
    bool c=dispose_one(slots+2U,errors+2U);
    bool d=dispose_one(slots+3U,errors+3U);
    return (bool)((unsigned int)a&(unsigned int)b&
                  (unsigned int)c&(unsigned int)d);
}

static bool dispose16(int *slots, int *errors)
{
    bool a=dispose4(slots,errors);
    bool b=dispose4(slots+4U,errors+4U);
    bool c=dispose4(slots+8U,errors+8U);
    bool d=dispose4(slots+12U,errors+12U);
    return (bool)((unsigned int)a&(unsigned int)b&
                  (unsigned int)c&(unsigned int)d);
}

static bool dispose_received(int *slots, int *errors)
{
    bool a=dispose16(slots,errors);
    bool b=dispose16(slots+16U,errors+16U);
    bool c=dispose16(slots+32U,errors+32U);
    bool d=dispose16(slots+48U,errors+48U);
    return (bool)((unsigned int)a&(unsigned int)b&
                  (unsigned int)c&(unsigned int)d);
}

static bool restrictive_budgets(struct mw_state *s, struct mw_data *d)
{
    uint64_t work=get64(d->request+128U), overall=get64(d->request+136U);
    if (work==0U || work>UINT64_MAX-UINT64_C(5000000000) ||
        work+UINT64_C(5000000000)!=overall)
        return mw_fail(s,MF_PROTOCOL,EINVAL);
    if (s->request_known)
        return (work==s->caller_work && overall==s->caller_overall) ||
               mw_fail(s,MF_PROTOCOL,ESTALE);
    s->caller_work=work;
    s->caller_overall=overall;
    if (work<s->work_deadline) s->work_deadline=work;
    if (overall<s->total_deadline) s->total_deadline=overall;
    return mw_timely(s,s->work_deadline);
}

bool mw_receive(struct mw_state *s, struct mw_data *d, enum mw_request phase, uint64_t deadline)
{
    struct mw_transport transaction;
    zero_request176(d->request);
    memset(transaction.control,0,sizeof transaction.control);
    s->received_count=0U;
    int ready=0;
    {
        struct poll_observation observed={0};
        s->poll_error=0;
        observe_wait(POLLIN,deadline,&observed);
        ready=commit_poll(s,MF_RECV,&observed);
    }
    if (ready!=1) return mw_fail(s,MF_RECV,ready==0 ? ETIMEDOUT : s->poll_error);
    const int borrowed[MW_FDS]={s->fd[0],s->fd[1],s->fd[2],s->fd[3],
        s->fd[4],s->fd[5],s->fd[6],s->fd[7],s->fd[8]};
    struct iovec vector={.iov_base=d->request,.iov_len=sizeof d->request};
    struct msghdr message={.msg_iov=&vector,.msg_iovlen=1U,
        .msg_control=transaction.control,.msg_controllen=sizeof transaction.control};
    ssize_t count=recvmsg(STDIN_FILENO,&message,MSG_DONTWAIT|MSG_CMSG_CLOEXEC);
    int saved=errno;
    s->last_recv_flags=(unsigned int)message.msg_flags;
    bool control_good=ancillary(borrowed,s->received,&s->received_count,
        &d->peer,transaction.control,message.msg_controllen);
    bool closed=dispose_received(s->received,s->received_closes);
    /* Drain every enrolled slot before bytes/flags/error refusal. */
    if (count<0) return mw_fail(s,MF_RECV,saved);
    if (!control_good || !closed) return mw_fail(s,MF_ANC,EPROTO);
    if (count!=MW_REQUEST || (message.msg_flags&~(MSG_EOR|MSG_CMSG_CLOEXEC))!=0 ||
        memcmp(d->request,"SIAWRQ04",8U)!=0 || get32(d->request+8U)!=4U ||
        get32(d->request+12U)!=(uint32_t)phase ||
        memcmp(d->request+48U,COMMISSION.generation,64U)!=0)
        return mw_fail(s,MF_PROTOCOL,EPROTO);
    unsigned char nonzero=0U;
    for (size_t i=0U; i<32U; ++i) nonzero=(unsigned char)(nonzero|d->request[16U+i]);
    if (nonzero==0U || !same32(s->challenge,d->request+144U) ||
        (s->request_known && !same32(s->nonce,d->request+16U)))
        return mw_fail(s,MF_PROTOCOL,EPROTO);
    uint64_t dev=get64(d->request+112U), ino=get64(d->request+120U);
    bool echo=phase==MR_EMPTY_ACK ? dev==(uint64_t)d->work_stat.st_dev &&
        ino==(uint64_t)d->work_stat.st_ino : dev==0U && ino==0U;
    if (!echo || !restrictive_budgets(s,d)) return mw_fail(s,MF_PROTOCOL,ESTALE);
    copy32(s->nonce,d->request+16U);
    s->request_known=true;
    return mw_timely(s,deadline);
}

static uint32_t owned_flags(const struct mw_state *s)
{
    return (uint32_t)s->work_created|((uint32_t)s->work_owned<<1U)|
        ((uint32_t)s->wait_owned<<2U)|((uint32_t)s->child_validated<<3U)|
        ((uint32_t)s->measured<<4U)|((uint32_t)s->ack<<5U)|
        ((uint32_t)s->cleanup_started<<6U)|((uint32_t)s->empty<<7U);
}

static void encode_identity(const struct mw_state *s, const struct mw_data *d, struct mw_transport *t)
{
    put32(t->wire+24U,(uint32_t)getpid());
    put32(t->wire+28U,(uint32_t)s->anchor_pid);
    put32(t->wire+32U,(uint32_t)s->child_pid);
    put32(t->wire+36U,COMMISSION.operator_uid);
    put32(t->wire+40U,(uint32_t)d->peer.pid);
    put32(t->wire+44U,s->wait_valid?1U:0U);
    put32(t->wire+48U,s->wait_valid?(uint32_t)s->wait_status:0U);
    put32(t->wire+52U,s->reaped?1U:0U);
    put32(t->wire+56U,s->empty?1U:0U);
    put32(t->wire+60U,s->removed?1U:0U);
    copy32(t->wire+64U,s->nonce);
    memcpy(t->wire+96U,COMMISSION.generation,64U);
    put32(t->wire+160U,COMMISSION.manager_pid);
    put32(t->wire+164U,(uint32_t)d->peer.gid);
    put64(t->wire+168U,COMMISSION.manager_start);
    put64(t->wire+176U,s->anchor_start);
    put64(t->wire+184U,s->child_start);
    memcpy(t->wire+192U,d->invocation,32U);
    put64(t->wire+224U,(uint64_t)d->service_stat.st_dev);
    put64(t->wire+232U,(uint64_t)d->service_stat.st_ino);
    put64(t->wire+240U,(uint64_t)d->work_stat.st_dev);
    put64(t->wire+248U,(uint64_t)d->work_stat.st_ino);
    memcpy(t->wire+480U,d->service_cgroup,sizeof d->service_cgroup);
    memcpy(t->wire+864U,d->work_cgroup,sizeof d->work_cgroup);
    memcpy(t->wire+1248U,d->unit_id,sizeof d->unit_id);
    memcpy(t->wire+1504U,COMMISSION.boot_id,36U);
}

static void encode_image(const struct mw_state *s, const struct mw_data *d, struct mw_transport *t)
{
    put64(t->wire+256U,s->image_before);
    put64(t->wire+264U,s->image_after);
    put64(t->wire+272U,s->empty_observed);
    put64(t->wire+280U,s->removed_at);
    put64(t->wire+288U,(uint64_t)d->image_stat.st_dev);
    put64(t->wire+296U,(uint64_t)d->image_stat.st_ino);
    put64(t->wire+304U,(uint64_t)d->image_stat.st_size);
    put32(t->wire+312U,(uint32_t)d->image_stat.st_mode);
    put32(t->wire+316U,(uint32_t)d->image_stat.st_uid);
    put32(t->wire+320U,(uint32_t)d->image_stat.st_gid);
    put32(t->wire+324U,(uint32_t)d->image_stat.st_nlink);
    put64(t->wire+328U,(uint64_t)d->image_stat.st_mtim.tv_sec);
    put32(t->wire+336U,(uint32_t)d->image_stat.st_mtim.tv_nsec);
    put32(t->wire+340U,(uint32_t)d->image_stat.st_ctim.tv_nsec);
    put64(t->wire+344U,(uint64_t)d->image_stat.st_ctim.tv_sec);
    memcpy(t->wire+352U,d->image_link,sizeof d->image_link);
}

static void put_errors4(unsigned char *wire, const int *errors)
{
    put32(wire,(uint32_t)errors[0]);
    put32(wire+4U,(uint32_t)errors[1]);
    put32(wire+8U,(uint32_t)errors[2]);
    put32(wire+12U,(uint32_t)errors[3]);
}

static void put_errors16(unsigned char *wire, const int *errors)
{
    put_errors4(wire,errors);
    put_errors4(wire+16U,errors+4U);
    put_errors4(wire+32U,errors+8U);
    put_errors4(wire+48U,errors+12U);
}

static void encode_report(const struct mw_state *s, const struct mw_data *d, struct mw_transport *t, enum mw_phase phase, uint32_t status)
{
    memset(t->wire,0,sizeof t->wire);
    memcpy(t->wire,"SIAWRS04",8U);
    put32(t->wire+8U,4U);
    put32(t->wire+12U,(uint32_t)phase);
    put32(t->wire+16U,status);
    put32(t->wire+20U,s->worker?2U:1U);
    encode_identity(s,d,t);
    encode_image(s,d,t);
    put_errors16(t->wire+1544U,s->faults);
    put_errors4(t->wire+1608U,s->faults+16U);
    put_errors4(t->wire+1624U,s->faults+20U);
    put_errors4(t->wire+1640U,s->closes);
    put_errors4(t->wire+1656U,s->closes+4U);
    put32(t->wire+1672U,(uint32_t)s->closes[8]);
    put32(t->wire+1676U,(uint32_t)s->closes[9]);
    put_errors16(t->wire+1680U,s->received_closes);
    put_errors16(t->wire+1744U,s->received_closes+16U);
    put_errors16(t->wire+1808U,s->received_closes+32U);
    put_errors16(t->wire+1872U,s->received_closes+48U);
    put64(t->wire+1936U,s->begin);
    put64(t->wire+1944U,s->work_deadline);
    put64(t->wire+1952U,s->total_deadline);
    put64(t->wire+1960U,s->cleanup_begin);
    put64(t->wire+1968U,(uint64_t)s->clone_result);
    put32(t->wire+1976U,owned_flags(s));
    put32(t->wire+1980U,s->last_recv_flags);
    put32(t->wire+1984U,(uint32_t)s->received_count);
    put32(t->wire+1988U,(uint32_t)s->clone_raw_cell);
    copy32(t->wire+1992U,s->challenge);
    put32(t->wire+2024U,(uint32_t)s->wait_error[0]);
    put32(t->wire+2028U,(uint32_t)s->wait_error[1]);
    put32(t->wire+2032U,s->wait_outcome[0]);
    put32(t->wire+2036U,s->wait_outcome[1]);
}

static void outgoing_control(struct mw_transport *t, struct msghdr *message, int fd)
{
    memset(t->control,0,sizeof t->control);
    size_t offset=0U;
    struct cmsghdr header={0};
    if (fd>=0) {
        header.cmsg_level=SOL_SOCKET;
        header.cmsg_type=SCM_RIGHTS;
        header.cmsg_len=CMSG_LEN(sizeof(int));
        memcpy(t->control,&header,sizeof header);
        memcpy(t->control+CMSG_LEN(0U),&fd,sizeof fd);
        offset=CMSG_SPACE(sizeof(int));
    }
    header.cmsg_level=SOL_SOCKET;
    header.cmsg_type=SCM_CREDENTIALS;
    header.cmsg_len=CMSG_LEN(sizeof(struct ucred));
    memcpy(t->control+offset,&header,sizeof header);
    struct ucred self={.pid=getpid(),.uid=getuid(),.gid=getgid()};
    memcpy(t->control+offset+CMSG_LEN(0U),&self,sizeof self);
    message->msg_control=t->control;
    message->msg_controllen=offset+CMSG_SPACE(sizeof self);
}

static void observe_send(const struct msghdr *message,
                           struct send_observation *observed)
{
    observed->outcome=MSO_ERROR;
    observed->error=0;
    observed->count=sendmsg(STDIN_FILENO,message,MSG_DONTWAIT|MSG_NOSIGNAL);
    if (observed->count<0) observed->error=errno;
    else observed->outcome=MSO_NONNEGATIVE;
}

static bool commit_send(struct mw_state *s, size_t length,
                         const struct send_observation *observed)
{
    switch (observed->outcome) {
    case MSO_ERROR:
        if (observed->count<0) return mw_fail(s,MF_SEND,observed->error);
        break;
    case MSO_NONNEGATIVE:
        if (observed->count<0 || observed->error!=0) break;
        ++s->sent_count;
        return (size_t)observed->count==length || mw_fail(s,MF_SEND,EIO);
    default:
        break;
    }
    (void)mw_fail(s,MF_INTERNAL,EPROTO);
    return mw_fail(s,MF_SEND,EIO);
}

static bool send_packet(struct mw_state *s, struct mw_transport *t, size_t length, int fd, uint64_t deadline)
{
    if (s->sent_count>=MW_RESPONSES) return mw_fail(s,MF_SEND,EOVERFLOW);
    struct iovec vector={.iov_base=t->wire,.iov_len=length};
    struct msghdr message={.msg_iov=&vector,.msg_iovlen=1U};
    outgoing_control(t,&message,fd);
    int ready=0;
    {
        struct poll_observation poll_observed={0};
        s->poll_error=0;
        observe_wait(POLLOUT,deadline,&poll_observed);
        ready=commit_poll(s,MF_SEND,&poll_observed);
    }
    if (ready!=1) return mw_fail(s,MF_SEND,ready==0 ? ETIMEDOUT : s->poll_error);
    {
        struct send_observation send_observed={0};
        observe_send(&message,&send_observed);
        if (!commit_send(s,length,&send_observed)) return false;
    }
    return mw_timely(s,deadline) || mw_fail(s,MF_SEND,EIO);
}

bool mw_send(struct mw_state *s, struct mw_data *d, enum mw_phase phase, uint32_t status,
             bool transfer, uint64_t deadline)
{
    int fd=-1;
    if (phase<MP_PREPARED || phase>MP_TERMINAL)
        return mw_fail(s,MF_INTERNAL,EINVAL);
    if (transfer) {
        if (phase!=MP_IMAGE || s->fd[MS_IMAGE]<0 || !s->measured)
            return mw_fail(s,MF_INTERNAL,EINVAL);
        fd=s->fd[MS_IMAGE];
    }
    struct mw_transport transaction;
    encode_report(s,d,&transaction,phase,status);
    return send_packet(s,&transaction,MW_WIRE,fd,deadline);
}

bool mw_send_namespace(struct mw_state *s, struct mw_data *d, enum mw_phase phase)
{
    if (s->namespace_slot!=MS_IMAGE && s->namespace_slot!=MS_WORK)
        return mw_fail(s,MF_NAMESPACE,EINVAL);
    if (phase<MP_ANCHOR_PID || phase>MP_POSTIMAGE_USER ||
        s->fd[s->namespace_slot]<0) return mw_fail(s,MF_NAMESPACE,EINVAL);
    struct mw_transport transaction;
    memset(transaction.wire,0,sizeof transaction.wire);
    memcpy(transaction.wire,"SIAWNS04",8U);
    put32(transaction.wire+8U,4U); put32(transaction.wire+12U,(uint32_t)phase);
    put32(transaction.wire+16U,2U); put32(transaction.wire+20U,s->worker?2U:1U);
    put32(transaction.wire+24U,(uint32_t)getpid());
    put32(transaction.wire+28U,(uint32_t)s->anchor_pid);
    put32(transaction.wire+32U,(uint32_t)s->child_pid);
    put32(transaction.wire+36U,COMMISSION.manager_pid);
    put32(transaction.wire+40U,COMMISSION.operator_uid);
    put32(transaction.wire+44U,(uint32_t)d->peer.pid);
    copy32(transaction.wire+48U,s->nonce);
    memcpy(transaction.wire+80U,COMMISSION.generation,64U);
    memcpy(transaction.wire+144U,d->invocation,32U);
    put64(transaction.wire+176U,COMMISSION.manager_start);
    put64(transaction.wire+184U,s->worker?s->child_start:s->anchor_start);
    copy32(transaction.wire+192U,s->challenge);
    put64(transaction.wire+224U,s->namespace_observed);
    put64(transaction.wire+232U,(uint64_t)d->namespace_stat.st_dev);
    put64(transaction.wire+240U,(uint64_t)d->namespace_stat.st_ino);
    put32(transaction.wire+248U,s->namespace_type);
    return send_packet(s,&transaction,MW_NS_WIRE,s->fd[s->namespace_slot],s->work_deadline);
}

bool mw_challenge(struct mw_state *s)
{
    unsigned char next[32]={0};
    ssize_t count=getrandom(next,sizeof next,GRND_NONBLOCK);
    if (count<0) return mw_fail(s,MF_PROTOCOL,errno);
    unsigned char nonzero=0U;
    for (size_t i=0U; i<32U; ++i) nonzero=(unsigned char)(nonzero|next[i]);
    if (count!=32 || nonzero==0U || same32(next,s->challenge) ||
        same32(next,s->first_challenge))
        return mw_fail(s,MF_PROTOCOL,EPROTO);
    uint64_t deadline=s->cleanup_started ? s->cleanup_deadline : s->work_deadline;
    if (!mw_timely(s,deadline)) return false;
    copy32(s->challenge,next);
    return true;
}

void mw_begin_cleanup(struct mw_state *s)
{
    if (s->cleanup_started) return;
    s->cleanup_started=true;
    s->cleanup_deadline=s->total_deadline;
    uint64_t now=0U;
    if (!mw_now(s,&now)) return;
    s->cleanup_begin=now;
    if (now>UINT64_MAX-UINT64_C(5000000000)) {
        (void)mw_fail(s,MF_DEADLINE,ERANGE);
        return;
    }
    uint64_t shared=now+UINT64_C(5000000000);
    if (shared<s->cleanup_deadline) s->cleanup_deadline=shared;
    if (s->caller_overall!=0U && s->caller_overall<s->cleanup_deadline)
        s->cleanup_deadline=s->caller_overall;
}

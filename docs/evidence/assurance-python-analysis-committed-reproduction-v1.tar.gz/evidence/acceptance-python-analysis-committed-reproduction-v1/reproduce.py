"""Bounded committed-checker reproduction; execution requires explicit opt-in.

This is integration evidence, not a proof of the runner, Python, Ruff, or SIA.
Every executed fixture is retained and sealed before its command starts.
"""

import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import platform
import re
import signal
import subprocess
import sys
import tarfile
import time


COMMIT = '9bd84d19ae2e9907c7129f1e555bf45f9e162eac'
REPO = Path('/home/sicarii/Work/sia-assurance-kernel-20261019')
ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'run-v1'
RUFF = Path('/home/sicarii/Work/sia-assurance-evidence-20261019/assurance-analysis-tools-v1/venv/bin/ruff')
RUFF_SHA = '7ac5f222f6b5db43a5551f7d21c3245e6f71f7b17c4271504d656721bb8bce05'
RULES_SHA = '0fea46b8e04811e2b1142cc0517f8152d1c7f36641ca13e14d8b94ea9b3c0741'
CI_BLOCK_SHA = 'd35d5dd03d96b08e7557751f81f219193b0a1037f3f72062dc7db160b09de647'
RULES = 'docs/evidence/assurance-ruff-rules-v1.txt'
CHECKER = 'scripts/assurance_acceptance_manifest.py'
MAX_FILES = 256
MAX_ENTRIES = 512
MAX_FILE = 1024 * 1024
MAX_TOTAL = 16 * MAX_FILE
MAX_LOG = 2 * MAX_FILE
MAX_BINARY = 64 * MAX_FILE
DEADLINE = 30
REQUIRED = (
    CHECKER, 'scripts/assurance_source_inventory.py',
    'tests/test_assurance_acceptance_manifest.py',
    'tests/test_assurance_source_inventory.py',
    'docs/ASSURANCE-GOAL.md', 'docs/ASSURANCE-IMPLEMENTATION-GATES.md',
    'docs/AGENT-CONTINUITY.md', 'docs/POWER-OF-TEN-ASSESSMENT.md',
    'docs/ASSURANCE-COMPLETION-CONTRACT-20261021-V2.txt',
    'docs/ASSURANCE-ACCEPTANCE-MANIFEST.md',
    'docs/ASSURANCE-PYTHON-ANALYSIS.md', RULES, '.github/workflows/ci.yml',
    'spark/sia_assurance.gpr', 'spark/restrictions.adc',
)


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def read_bound(path, limit):
    with path.open('rb') as stream:
        raw = stream.read(limit + 1)
    if len(raw) > limit:
        raise ValueError('input exceeds declared byte bound: ' + str(path))
    return raw


def write_once(path, raw):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as stream:
        if stream.write(raw) != len(raw):
            raise OSError('short evidence write')
        stream.flush()
        os.fsync(stream.fileno())


def save_json(path, value):
    raw = (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()
    write_once(path, raw)
    return sha(raw)


def file_map(directory):
    result = {}
    entries = 0
    total = 0
    for current, directories, names in os.walk(directory, followlinks=False):
        entries += len(directories) + len(names)
        if entries > MAX_ENTRIES:
            raise ValueError('fixture directory entry bound exceeded')
        for name in directories:
            if (Path(current) / name).is_symlink():
                raise ValueError('fixture directory symlink refused')
        for name in names:
            path = Path(current) / name
            if path.is_symlink() or not path.is_file() or len(result) >= MAX_FILES:
                raise ValueError('fixture file type/count refused')
            raw = read_bound(path, MAX_FILE)
            total += len(raw)
            if total > MAX_TOTAL:
                raise ValueError('fixture total byte bound exceeded')
            result[path.relative_to(directory).as_posix()] = {
                'bytes': len(raw), 'sha256': sha(raw)}
    return dict(sorted(result.items()))


def binary_identity(path):
    resolved = path.resolve(strict=True)
    raw = read_bound(resolved, MAX_BINARY)
    return {'path': str(path), 'resolved_path': str(resolved),
            'bytes': len(raw), 'sha256': sha(raw)}


def environment(case):
    return {
        'PATH': str(OUT / 'tool-bin') + ':/usr/bin:/bin',
        'LANG': 'C.UTF-8', 'LC_ALL': 'C.UTF-8', 'NO_COLOR': '1',
        'PYTHON_COLORS': '0', 'PYTHONWARNINGS': 'error',
        'PYTHONNOUSERSITE': '1', 'PYTHONDONTWRITEBYTECODE': '1',
        'PYTHONPATH': str(case / 'inputs/source'),
        'RAYON_NUM_THREADS': '1', 'RUNNER_TEMP': str(case / 'output'),
        'TMPDIR': str(case / 'tmp'),
    }


def process(directory, command, cwd, env, expected, seal_sha=None):
    directory.mkdir(parents=True, exist_ok=True)
    receipt = {'command': command, 'cwd': str(cwd), 'environment': env,
               'expected_exit': expected, 'timeout_seconds': DEADLINE,
               'input_seal_sha256': seal_sha, 'started_utc': utc()}
    started = time.monotonic()
    with (directory / 'stdout.log').open('xb') as stdout:
        with (directory / 'stderr.log').open('xb') as stderr:
            child = subprocess.Popen(command, cwd=cwd, env=env, stdout=stdout,
                                     stderr=stderr, start_new_session=True)
            try:
                receipt['exit'] = child.wait(timeout=DEADLINE)
                receipt['timed_out'] = False
            except subprocess.TimeoutExpired:
                os.killpg(child.pid, signal.SIGKILL)
                receipt['exit'] = child.wait(timeout=5)
                receipt['timed_out'] = True
    receipt.update(finished_utc=utc(), elapsed_seconds=time.monotonic() - started)
    for name in ('stdout', 'stderr'):
        path = directory / (name + '.log')
        size = path.stat().st_size
        receipt[name] = {'path': path.relative_to(OUT).as_posix(), 'bytes': size,
                         'sha256': sha(read_bound(path, MAX_LOG)) if size <= MAX_LOG else None}
    receipt['accepted_expected_exit'] = (
        receipt['exit'] == expected and not receipt['timed_out']
        and all(receipt[name]['bytes'] <= MAX_LOG for name in ('stdout', 'stderr')))
    save_json(directory / 'receipt.json', receipt)
    if not receipt['accepted_expected_exit']:
        raise RuntimeError('unexpected command outcome: ' + str(directory))
    return receipt


def git_read(label, arguments):
    directory = OUT / 'git' / label
    process(directory, ['/usr/bin/git', '-C', str(REPO), *arguments],
            REPO, {'PATH': '/usr/bin:/bin', 'LANG': 'C.UTF-8'}, 0)
    return read_bound(directory / 'stdout.log', MAX_LOG)


def select_sources():
    observed = git_read('commit', ['rev-parse', '--verify', COMMIT + '^{commit}'])
    if observed != (COMMIT + '\n').encode():
        raise ValueError('exact commit resolution mismatch')
    arguments = ['ls-tree', '-r', '-z', COMMIT, '--', *REQUIRED,
                 'tests/__init__.py', 'spark/src', 'spark/tests']
    entries = {}
    for row in git_read('tree', arguments).split(b'\0'):
        if not row:
            continue
        metadata, name = row.split(b'\t', 1)
        mode, kind, identity = metadata.decode('ascii').split()
        path = name.decode('utf-8')
        ada = path.startswith(('spark/src/', 'spark/tests/')) and path.endswith(('.ads', '.adb'))
        if path not in REQUIRED and path != 'tests/__init__.py' and not ada:
            continue
        if len(entries) >= MAX_FILES or mode != '100644' or kind != 'blob':
            raise ValueError('unsupported committed source type/count')
        if path in entries:
            raise ValueError('duplicate committed source')
        entries[path] = identity
    if not set(REQUIRED) <= set(entries):
        raise ValueError('required committed source absent')
    save_json(OUT / 'source-git-blobs.json', entries)
    write_once(OUT / 'source-files.txt', ('\n'.join(sorted(entries)) + '\n').encode())
    return entries


def create_archive(entries):
    destination = OUT / 'source.tar'
    arguments = ['archive', '--format=tar', '--output=' + str(destination),
                 COMMIT, '--', *sorted(entries)]
    git_read('archive', arguments)
    raw = read_bound(destination, MAX_TOTAL)
    save_json(OUT / 'source-archive.json', {
        'source_commit': COMMIT, 'bytes': len(raw), 'sha256': sha(raw),
        'selection': sorted(entries), 'overlay': False})
    return destination


def extract_sources(archive_path, entries):
    source = OUT / 'source'
    source.mkdir()
    observed = set()
    count = 0
    total = 0
    with tarfile.open(archive_path, 'r:') as archive:
        if archive.pax_headers.get('comment') != COMMIT:
            raise ValueError('Git archive commit marker mismatch')
        for member in archive:
            count += 1
            parts = PurePosixPath(member.name).parts
            if count > MAX_ENTRIES or member.name.startswith('/') or '..' in parts:
                raise ValueError('unsafe archive path/count')
            if member.isdir():
                continue
            if (not member.isfile() or member.name not in entries
                    or member.name in observed or member.size > MAX_FILE):
                raise ValueError('unsupported archive source member')
            with archive.extractfile(member) as stream:
                raw = stream.read(MAX_FILE + 1)
            total += len(raw)
            blob = hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()
            if len(raw) != member.size or total > MAX_TOTAL or blob != entries[member.name]:
                raise ValueError('committed source content mismatch')
            write_once(source / member.name, raw)
            observed.add(member.name)
    if observed != set(entries):
        raise ValueError('committed source roster mismatch')
    identity = file_map(source)
    save_json(OUT / 'source-map.json', identity)
    return source, identity


def frozen_ci(source):
    workflow = read_bound(source / '.github/workflows/ci.yml', MAX_FILE)
    start = b'      - name: experimental assurance checker static analysis\n'
    if workflow.count(start) != 1:
        raise ValueError('CI step identity ambiguous')
    step = workflow.split(start, 1)[1].split(b'      - name:', 1)[0]
    prefix, body = step.split(b'        run: |\n', 1)
    if b'RAYON_NUM_THREADS: "1"' not in prefix or b'PYTHONWARNINGS: error' not in prefix:
        raise ValueError('CI environment differs from required scope')
    lines = body.splitlines(keepends=True)
    if not lines or any(line.strip() and not line.startswith(b'          ') for line in lines):
        raise ValueError('unsupported CI literal indentation')
    shell = b''.join(line[10:] if line.startswith(b'          ') else line for line in lines)
    rules = read_bound(source / RULES, 65536)
    codes = rules.decode('ascii').splitlines()
    if sha(shell) != CI_BLOCK_SHA or sha(rules) != RULES_SHA:
        raise ValueError('committed CI/rule identity differs from reviewed checkpoint')
    if len(codes) != 167 or len(set(codes)) != 167:
        raise ValueError('frozen expanded rule roster mismatch')
    write_once(OUT / 'committed-ci-step.sh', shell)
    return shell


def runtime_identity():
    identities = {name: binary_identity(path) for name, path in (
        ('python', Path(sys.executable)), ('ruff', RUFF),
        ('bash', Path('/usr/bin/bash')), ('timeout', Path('/usr/bin/timeout')),
        ('paste', Path('/usr/bin/paste')), ('head', Path('/usr/bin/head')))}
    if identities['ruff']['sha256'] != RUFF_SHA:
        raise ValueError('pinned Ruff executable mismatch')
    identities['python'].update(sys_executable=sys.executable, sys_version=sys.version,
                               implementation=platform.python_implementation(),
                               platform=platform.platform())
    tools = OUT / 'tool-bin'
    tools.mkdir()
    (tools / 'ruff').symlink_to(RUFF.resolve(strict=True))
    (tools / 'python3').symlink_to(Path(sys.executable).resolve(strict=True))
    save_json(OUT / 'runtime-identities.json', identities)
    return identities


def check_runtime(identities):
    for identity in identities.values():
        current = binary_identity(Path(identity['path']))
        if any(current[key] != identity[key] for key in ('resolved_path', 'bytes', 'sha256')):
            raise ValueError('runtime executable identity changed')
    for name, key in (('ruff', 'ruff'), ('python3', 'python')):
        if (OUT / 'tool-bin' / name).resolve(strict=True) != Path(identities[key]['resolved_path']):
            raise ValueError('runtime tool binding changed')


def prepare_case(name, source, source_map, shell, mutation=None, draft=None):
    case = OUT / 'cases' / name
    case.mkdir(parents=True)
    for directory in ('inputs/source', 'output', 'tmp', 'execution'):
        (case / directory).mkdir(parents=True)
    for relative in source_map:
        raw = read_bound(source / relative, MAX_FILE)
        if mutation and relative == mutation['path']:
            raw = mutation['replacement']
        write_once(case / 'inputs/source' / relative, raw)
    write_once(case / 'inputs/ci-step.sh', shell)
    if draft is not None:
        write_once(case / 'inputs/draft.json', draft)
    return case


def sealed_run(case, arguments, expected, identities, archive_sha, mutation=None):
    inputs = file_map(case / 'inputs')
    check_runtime(identities)
    command = [str(value) for value in arguments]
    env = environment(case)
    seal = {'source_commit': COMMIT, 'source_archive_sha256': archive_sha,
            'input_root': 'inputs', 'inputs': inputs, 'runtime': identities,
            'command': command, 'cwd': str(case / 'inputs/source'),
            'environment': env, 'expected_exit': expected, 'sealed_utc': utc(),
            'mutation': mutation, 'timeout_seconds': DEADLINE,
            'runner_sha256': sha(read_bound(Path(__file__), MAX_FILE)),
            'seal_kind': 'retained byte/hash map, not a signature or sandbox'}
    seal_path = case / 'input-seal.json'
    seal_sha = save_json(seal_path, seal)
    seal_path.chmod(0o444)
    receipt = process(case / 'execution', command, case / 'inputs/source',
                      env, expected, seal_sha)
    unchanged = file_map(case / 'inputs') == inputs and sha(read_bound(seal_path, MAX_FILE)) == seal_sha
    check_runtime(identities)
    save_json(case / 'input-unchanged.json', {'input_seal_sha256': seal_sha,
              'all_input_bytes_unchanged': unchanged, 'checked_utc': utc()})
    if not unchanged:
        raise ValueError('sealed execution input changed')
    return receipt


def logs(case):
    return tuple(read_bound(case / 'execution' / (name + '.log'), MAX_LOG)
                 for name in ('stdout', 'stderr'))


def checker_runs(source, source_map, shell, identities, archive_sha):
    results = {}
    tests = prepare_case('focused-tests', source, source_map, shell)
    args = [sys.executable, '-B', '-m', 'unittest',
            'tests.test_assurance_acceptance_manifest', 'tests.test_assurance_source_inventory', '-v']
    results['focused-tests'] = sealed_run(tests, args, 0, identities, archive_sha)
    stdout, stderr = logs(tests)
    counts = {module: len(re.findall(rb'^test_.*\(tests\.' + module + rb'\..*\) \.\.\. ok$', stderr, re.M))
              for module in (b'test_assurance_acceptance_manifest', b'test_assurance_source_inventory')}
    if (stdout or counts != {b'test_assurance_acceptance_manifest': 26, b'test_assurance_source_inventory': 4}
            or not re.search(rb'^Ran 30 tests in .*\n\nOK\n\Z', stderr, re.M)):
        raise ValueError('original focused unittest roster/result mismatch')
    draft = prepare_case('draft', source, source_map, shell)
    draft_root = draft / 'inputs/source'
    results['draft'] = sealed_run(draft, [sys.executable, '-B', CHECKER, 'draft',
                                          '--root', draft_root], 0, identities, archive_sha)
    draft_raw, draft_stderr = logs(draft)
    if draft_stderr:
        raise ValueError('draft emitted unexpected stderr')
    write_once(OUT / 'actual-draft.json', draft_raw)
    audit = prepare_case('audit', source, source_map, shell, draft=draft_raw)
    results['audit'] = sealed_run(audit, [sys.executable, '-B', CHECKER, 'audit',
        '--root', audit / 'inputs/source', '--manifest', audit / 'inputs/draft.json'],
        2, identities, archive_sha)
    audit_raw, audit_stderr = logs(audit)
    value = json.loads(audit_raw)
    if audit_stderr or value.get('status') != 'INCOMPLETE' or value.get('authority') != 'NONE':
        raise ValueError('actual audit lost INCOMPLETE/NONE contract')
    if type(value.get('gaps')) is not list or not value['gaps']:
        raise ValueError('actual audit lacks retained gaps')
    write_once(OUT / 'actual-audit.json', audit_raw)
    return results, value


def analyzer_positive(source, source_map, shell, identities, archive_sha):
    results = {}
    version = prepare_case('ruff-version', source, source_map, shell)
    results['ruff-version'] = sealed_run(version, [OUT / 'tool-bin/ruff', '--version'],
                                        0, identities, archive_sha)
    if logs(version) != (b'ruff 0.17.1\n', b''):
        raise ValueError('Ruff version output mismatch')
    syntax = prepare_case('ci-syntax', source, source_map, shell)
    results['ci-syntax'] = sealed_run(syntax, ['/usr/bin/bash', '-n', syntax / 'inputs/ci-step.sh'],
                                      0, identities, archive_sha)
    if logs(syntax) != (b'', b''):
        raise ValueError('CI syntax check emitted diagnostics')
    positive = prepare_case('ci-positive', source, source_map, shell)
    results['ci-positive'] = sealed_run(positive, ['/usr/bin/bash', positive / 'inputs/ci-step.sh'],
                                        0, identities, archive_sha)
    stdout, stderr = logs(positive)
    raw_json = read_bound(positive / 'output/sia-assurance-checker-ruff.json', MAX_FILE)
    raw_stderr = read_bound(positive / 'output/sia-assurance-checker-ruff.stderr', MAX_FILE)
    if stderr or raw_stderr or json.loads(raw_json) != [] or stdout != raw_json:
        raise ValueError('positive analysis is not an empty-diagnostic pass')
    output_map = file_map(positive / 'output')
    if set(output_map) != {'sia-assurance-checker-ruff.json', 'sia-assurance-checker-ruff.stderr'}:
        raise ValueError('unexpected positive CI output roster')
    save_json(positive / 'ci-output-map.json', output_map)
    return results


def analyzer_faults(source, source_map, shell, identities, archive_sha):
    original_rules = read_bound(source / RULES, 65536)
    original_checker = read_bound(source / CHECKER, MAX_FILE)
    changed = b''.join(original_rules.splitlines(keepends=True)[1:])
    if not changed or changed == original_rules:
        raise ValueError('changed nonempty rule fixture invalid')
    faults = (
        ('empty-rules', RULES, b'', b'Frozen analyzer rule identity mismatch\n'),
        ('changed-rules', RULES, changed, b'Frozen analyzer rule identity mismatch\n'),
        ('suppression', CHECKER, original_checker + b'\n# noqa: F401\n',
         ('Oversized source or suppression directive: ' + CHECKER + '\n').encode()),
    )
    results = {}
    for name, relative, replacement, expected_stderr in faults:
        original = read_bound(source / relative, MAX_FILE)
        mutation = {'path': relative, 'replacement': replacement}
        case = prepare_case(name, source, source_map, shell, mutation=mutation)
        description = {'path': relative, 'original_bytes': len(original),
                       'original_sha256': sha(original), 'fixture_bytes': len(replacement),
                       'fixture_sha256': sha(replacement), 'expected_stderr': expected_stderr.decode()}
        fixture_map = file_map(case / 'inputs/source')
        differences = [path for path in source_map if fixture_map[path] != source_map[path]]
        if differences != [relative]:
            raise ValueError('fault fixture changes more than its declared input')
        results[name] = sealed_run(case, ['/usr/bin/bash', case / 'inputs/ci-step.sh'],
                                    1, identities, archive_sha, mutation=description)
        if logs(case) != (b'', expected_stderr):
            raise ValueError('fault did not produce its exact expected refusal')
        if any((case / 'output').iterdir()):
            raise ValueError('analyzer outputs exist after pre-analysis fault refusal')
    return results


def completed_receipt(source, source_map, archive_sha, identities, runs, audit):
    if file_map(source) != source_map:
        raise ValueError('archived baseline input changed')
    check_runtime(identities)
    receipt = {
        'status': 'TESTED_COMMITTED_PARTIAL_PYTHON_ANALYSIS_ONLY',
        'source_commit': COMMIT, 'source_archive_sha256': archive_sha, 'overlay': False,
        'source_inputs_unchanged': True, 'source_map': source_map,
        'runtime': identities, 'commands': runs, 'authority': 'NONE',
        'focused_tests': {'manifest': 26, 'inventory': 4, 'combined': 30},
        'actual_draft_audit_status': audit['status'], 'actual_gap_count': len(audit['gaps']),
        'actual_audit_sha256': sha(read_bound(OUT / 'actual-audit.json', MAX_LOG)),
        'frozen_rule_file_sha256': RULES_SHA, 'stable_rule_count': 167,
        'exact_ci_shell_sha256': CI_BLOCK_SHA,
        'runner_sha256': sha(read_bound(Path(__file__), MAX_FILE)),
        'limits': [
            'No whole-system, P10-compliance, proof, build, installation, release, or remote CI acceptance.',
            'Historical actual-ci-step-v2 faults had no sealed per-fixture input maps; those receipts remain unchanged.',
            'New input seals are retained byte/hash maps, not independent signatures, sandboxes, or an attestation service.',
            'Binary hashes do not pin OS, dynamic libraries, all runtime dependencies, or remote x86_64 execution.',
            'Each command has an outer 30-second deadline; no host memory or output-disk quota is imposed.',
            'Complete ALL baseline findings, omitted analysis, existing A/G/C/P obligations, and OPEN gates remain binding.',
        ],
    }
    save_json(OUT / 'committed-reproduction.receipt.json', receipt)
    write_once(OUT / 'report.txt', (
        'TESTED committed checker and finite partial Python analysis only.\n'
        + 'Commit: ' + COMMIT + '\n'
        + 'Original 26 manifest + 4 inventory unittest cases passed with warnings as errors.\n'
        + 'Exact committed CI block passed; three independently byte-sealed fault copies refused.\n'
        + 'Actual draft/audit remains INCOMPLETE, authority NONE; complete gaps retained.\n'
        + '\n'.join(receipt['limits']) + '\n').encode())
    print(json.dumps({key: receipt[key] for key in (
        'status', 'source_commit', 'actual_draft_audit_status', 'actual_gap_count', 'authority')}))


def execute():
    OUT.mkdir()
    write_once(OUT / 'runner-at-start.py', read_bound(Path(__file__), MAX_FILE))
    entries = select_sources()
    archive = create_archive(entries)
    archive_sha = sha(read_bound(archive, MAX_TOTAL))
    source, source_map = extract_sources(archive, entries)
    shell = frozen_ci(source)
    identities = runtime_identity()
    runs, audit = checker_runs(source, source_map, shell, identities, archive_sha)
    runs.update(analyzer_positive(source, source_map, shell, identities, archive_sha))
    runs.update(analyzer_faults(source, source_map, shell, identities, archive_sha))
    completed_receipt(source, source_map, archive_sha, identities, runs, audit)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--commit', required=True, choices=[COMMIT])
    parser.add_argument('--execute', action='store_true', help='Execute only after runner/plan inspection.')
    args = parser.parse_args()
    if not args.execute:
        print('PREPARED ONLY: inspect COMMAND-PLAN.txt; no reproduction command executed.')
        return
    try:
        execute()
    except Exception as error:
        if (not isinstance(error, FileExistsError) and OUT.is_dir()
                and not (OUT / 'failure.json').exists()):
            save_json(OUT / 'failure.json', {'status': 'FAILED_REPRODUCTION',
                      'exception_type': type(error).__name__, 'message': str(error),
                      'source_commit': COMMIT, 'recorded_utc': utc(), 'authority': 'NONE'})
        raise


if __name__ == '__main__':
    main()

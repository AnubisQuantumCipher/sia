#!/usr/bin/env bash
set -euo pipefail
umask 077
out=/home/sicarii/Work/sia-assurance-evidence-20261019/ownership-transfer-20261024/event-pack-model-v1
exec 9>/home/sicarii/.worldline-heavy.lock
flock -n 9
ulimit -c 0
ulimit -f 524288
ulimit -a > "$out/candidate2-limits.txt"
export JAVA_BIN=/home/sicarii/opt/sia-assurance-model-tools/jdk-21.0.12.1+1-jre/bin/java
export TLA_JAR=/home/sicarii/opt/sia-assurance-model-tools/tla2tools-1.7.4.jar
status=0
cd /home/sicarii/Work/sia-assurance-checkpoint-20261023
bash spark/check-event-pack-model.sh "$out/candidate2-run" > "$out/candidate2.stdout" 2> "$out/candidate2.stderr" || status=$?
printf '%s\n' "$status" > "$out/candidate2.exit"
exit "$status"

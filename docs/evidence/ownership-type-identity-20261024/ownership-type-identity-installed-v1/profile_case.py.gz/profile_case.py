"""Unchanged full modules selected by affected boundary before execution."""
import unittest

NAMES = ['tests.test_installed_engine_boundary', 'tests.test_installed_engine_get_boundary']

if __name__ == "__main__":
    suite = unittest.defaultTestLoader.loadTestsFromNames(NAMES)
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    raise SystemExit(0 if result.wasSuccessful() else 1)

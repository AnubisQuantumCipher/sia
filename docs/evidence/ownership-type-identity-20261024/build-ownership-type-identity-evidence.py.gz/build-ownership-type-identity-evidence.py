"""Retain and reproduce the bounded exact-type repair checkpoint manifest."""
import gzip
import hashlib
import json
from pathlib import Path
import sys

BASE = Path(__file__).parent
REPO = Path('/home/sicarii/Work/sia-note-boundary-checkpoint-20261024')
DEST = REPO / 'docs/evidence/ownership-type-identity-20261024'
SOURCES = ('bin/siacognitiveregistry.py', 'bin/siacontrollerdeliverywrapper.py', 'bin/siacontrollerdeliverywriter.py', 'bin/siagetrenderadmit.py', 'bin/siainstalledengine.py', 'bin/sialivepublication.py', 'tests/test_ownership_exact_type_admission.py')
GROUPS = {'ownership-type-identity-baseline-v1': ('profile_case.py', 'run_profile.py', 'workload-result.json', 'workload.stdout', 'workload.stderr', 'originals/siacognitiveregistry.py', 'originals/siacontrollerdeliverywrapper.py', 'originals/siacontrollerdeliverywriter.py', 'originals/siagetrenderadmit.py', 'originals/siainstalledengine.py', 'originals/sialivepublication.py'), 'ownership-type-identity-candidate-v1': ('profile_case.py', 'run_profile.py', 'workload-result.json', 'workload.stdout', 'workload.stderr', 'baseline-static-result.json', 'baseline-static.stdout', 'candidate-static-result.json', 'candidate-static.stdout', 'STATIC-DISPOSITION.md', 'SOURCE-REVIEW.txt', 'FINAL-BINDING.json', 'candidate.patch', 'candidate/bin/siacognitiveregistry.py', 'candidate/bin/siacontrollerdeliverywrapper.py', 'candidate/bin/siacontrollerdeliverywriter.py', 'candidate/bin/siagetrenderadmit.py', 'candidate/bin/siainstalledengine.py', 'candidate/bin/sialivepublication.py', 'candidate/tests/test_ownership_exact_type_admission.py'), 'ownership-type-identity-publication-v1': ('profile_case.py', 'run_profile.py', 'workload-result.json', 'workload.stdout', 'workload.stderr'), 'ownership-type-identity-installed-v1': ('profile_case.py', 'run_profile.py', 'workload-result.json', 'workload.stdout', 'workload.stderr'), 'ownership-type-identity-writer-v1': ('profile_case.py', 'run_profile.py', 'workload-result.json', 'workload.stdout', 'workload.stderr')}

def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def publish(path, raw, check):
    if check:
        if path.read_bytes() != raw:
            raise ValueError('evidence mismatch: ' + str(path))
    else:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(raw)


def members():
    result = [BASE / group / name for group, names in GROUPS.items() for name in names]
    result.append(Path(__file__))
    if len(result) > 256:
        raise ValueError('member capacity')
    return result


def main():
    if sys.argv[1:] not in ([], ['--check']):
        raise ValueError('unsupported arguments')
    check = bool(sys.argv[1:])
    records = []
    total = 0
    for source in members():
        raw = source.read_bytes()
        total += len(raw)
        if len(raw) > 8 * 1024 * 1024 or total > 16 * 1024 * 1024:
            raise ValueError('evidence byte capacity')
        name = str(source.relative_to(BASE)) + '.gz'
        packed = gzip.compress(raw, mtime=0)
        publish(DEST / name, packed, check)
        records.append({'path': str((DEST / name).relative_to(REPO)), 'sha256': digest(packed),
                        'original_sha256': digest(raw), 'original_bytes': len(raw)})
    data = {'schema': 'sia-ownership-type-identity-evidence-v1', 'status': 'FAILED_FULL_WRITER_QUALIFICATION_NOT_ADOPTED',
            'base_commit': 'dbc7ffe6fddad7d471919093db8e59f53188f78e',
            'candidate_source_sha256': {name: digest((BASE / 'ownership-type-identity-candidate-v1/candidate' / name).read_bytes()) for name in SOURCES},
            'base_source_sha256': {name: digest((BASE / 'ownership-type-identity-baseline-v1/originals' / Path(name).name).read_bytes()) for name in SOURCES if name.startswith('bin/')},
            'members': records, 'limits': 'Original runtime caps unchanged; no release authority.'}
    publish(REPO / 'docs/OWNERSHIP-TYPE-IDENTITY-20261024.json',
            (json.dumps(data, indent=2) + '\n').encode(), check)
    print(json.dumps({'check': check, 'members': len(records), 'uncompressed_bytes': total}))


if __name__ == '__main__':
    main()

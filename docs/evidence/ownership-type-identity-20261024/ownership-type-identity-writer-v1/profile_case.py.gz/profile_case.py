"""Unchanged full modules selected by affected boundary before execution."""
import unittest

NAMES = ['tests.test_controller_delivery_writer', 'tests.test_controller_delivery_writer_exit_tail', 'tests.test_controller_delivery_writer_completed_phase']

if __name__ == "__main__":
    suite = unittest.defaultTestLoader.loadTestsFromNames(NAMES)
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    raise SystemExit(0 if result.wasSuccessful() else 1)

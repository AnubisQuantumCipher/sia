"""Unchanged full modules selected by affected boundary before execution."""
import unittest

NAMES = ['tests.test_ownership_exact_type_admission', 'tests.test_cognitive_mechanism_registry', 'tests.test_get_render_admission', 'tests.test_live_publication', 'tests.test_live_publication_integrity']

if __name__ == "__main__":
    suite = unittest.defaultTestLoader.loadTestsFromNames(NAMES)
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    raise SystemExit(0 if result.wasSuccessful() else 1)

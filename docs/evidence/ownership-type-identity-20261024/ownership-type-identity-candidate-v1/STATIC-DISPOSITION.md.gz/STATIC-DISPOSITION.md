Selected static checks do not pass. Baseline and candidate report the same
code/message multiplicities by filename: BLE0015, B9041, B9053, F821171.
Undefined-name findings include the existing runtime-bound publication module;
this observation is not a waiver or static proof of those bindings. Existing
broad exception and zip checks also remain open. The new fixture introduces
no additional finding under this selected policy. No zero-warning claim.

"""Read-only source review counterexamples; writes only through temp fixtures."""
import json
import sys
from pathlib import Path

REPO = Path('/home/sicarii/Work/sia-assurance-kernel-20261019')
sys.path.insert(0, str(REPO))
from tests.test_assurance_acceptance_manifest import CHECK, ManifestControls


def probe(name, extra):
    fixture = ManifestControls()
    fixture.setUp()
    try:
        path = fixture.root / name
        path.write_bytes(path.read_bytes() + extra.encode('utf-8'))
        try:
            with CHECK.Checkout(fixture.root) as checkout:
                fixture.manifest = CHECK.draft(checkout)
            fixture.populated()
            result = fixture.audit()
        except CHECK.Refusal as error:
            result = {'status': 'REFUSED', 'reason': str(error)}
        print(json.dumps({'input': name, 'appended_row': extra.strip(),
                          'expected': 'REFUSED', 'observed': result}, sort_keys=True))
        return result['status'] == 'STRUCTURALLY_VALID'
    finally:
        fixture.doCleanups()


def main():
    mutations = (
        ('docs/ASSURANCE-GOAL.md', '\n| A100 | additional obligation | required evidence | OPEN |\n'),
        ('docs/ASSURANCE-IMPLEMENTATION-GATES.md', '\n| G10: additional gate | work | evidence |\n'),
        ('docs/AGENT-CONTINUITY.md', '\n| C100 | additional contract | refusal evidence |\n'),
        ('docs/POWER-OF-TEN-ASSESSMENT.md', '\n| 100 — additional rule | core | adapter | required check |\n'),
    )
    accepted = [probe(name, extra) for name, extra in mutations]
    return 1 if any(accepted) else 0


if __name__ == '__main__':
    sys.exit(main())

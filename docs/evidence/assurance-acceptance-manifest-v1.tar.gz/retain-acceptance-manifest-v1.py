#!/usr/bin/env python3
"""Retain bounded, explicit checkpoint inputs; never confer acceptance."""
import argparse
import gzip
import hashlib
import io
import json
from pathlib import Path
import stat
import tarfile

LIMIT = 1024 * 1024
ROOT = Path('/home/sicarii/Work/sia-assurance-kernel-20261019')
EVIDENCE = Path('/home/sicarii/Work/sia-assurance-evidence-20261019')
BUNDLE = 'docs/evidence/assurance-acceptance-manifest-v1.tar.gz'
MANIFEST = 'docs/ASSURANCE-ACCEPTANCE-MANIFEST-EVIDENCE-V1.json'
SOURCE = ('.github/workflows/ci.yml', 'docs/ASSURANCE-GOAL.md',
          'docs/ASSURANCE-ACCEPTANCE-MANIFEST.md',
          'docs/ASSURANCE-COMPLETION-CONTRACT-20261021-V2.txt',
          'docs/ASSURANCE-COMPLETION-CONTRACT-EVIDENCE-20261021-V2.json',
          'docs/evidence/assurance-completion-contract-original-20261021-v2.txt.gz',
          'docs/ASSURANCE-IMPLEMENTATION-GATES.md', 'docs/AGENT-CONTINUITY.md',
          'docs/POWER-OF-TEN-ASSESSMENT.md',
          'scripts/assurance_acceptance_manifest.py',
          'tests/test_assurance_acceptance_manifest.py',
          'scripts/assurance_source_inventory.py', 'tests/test_assurance_source_inventory.py',
          'spark/sia_assurance.gpr', 'spark/restrictions.adc')
RECORDS = ('takeover-dirty-source-20261021.tar.gz',
           'acceptance-manifest-development-v3.log', 'acceptance-manifest-development-v4.log',
           'acceptance-manifest-development-v4.exit', 'acceptance-manifest-inventory-v3.json',
           'acceptance-manifest-inventory-v3.exit', 'acceptance-manifest-draft-v3.json',
           'acceptance-manifest-audit-v3.json', 'acceptance-manifest-execution-v3.json')


def read(path):
    if not stat.S_ISREG(path.lstat().st_mode):
        raise ValueError('regular input required')
    with path.open('rb') as stream:
        raw = stream.read(LIMIT + 1)
    if len(raw) > LIMIT:
        raise ValueError('input byte budget')
    return raw


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def collect(root, evidence):
    members = {'source/' + name: read(root / name) for name in SOURCE}
    for name in RECORDS:
        members['evidence/' + name] = read(evidence / name)
    for directory in ('takeover-manifest-independent-v1', 'takeover-manifest-independent-v2'):
        paths = []
        for path in (evidence / directory).iterdir():
            if len(paths) >= 32:
                raise ValueError('review file count budget')
            paths.append(path)
        for path in sorted(paths):
            members['evidence/' + directory + '/' + path.name] = read(path)
    members['retain-acceptance-manifest-v1.py'] = read(Path(__file__))
    if len(members) > 96 or sum(len(raw) for raw in members.values()) > 16 * LIMIT:
        raise ValueError('aggregate retention budget')
    return members


def archive(members):
    output = io.BytesIO()
    with tarfile.open(fileobj=output, mode='w', format=tarfile.USTAR_FORMAT) as stream:
        for name, raw in sorted(members.items()):
            item = tarfile.TarInfo(name)
            item.size, item.mode, item.mtime = len(raw), 0o644, 0
            stream.addfile(item, io.BytesIO(raw))
    return gzip.compress(output.getvalue(), mtime=0)


def manifest(members, compressed):
    prefix = 'evidence/takeover-manifest-independent-v2/'
    binding = json.loads(members[prefix + 'final-independent-review.binding.json'])
    for name, expected in binding['reviewed_sha256'].items():
        if digest(members['source/' + name]) != expected:
            raise ValueError('reviewed source mismatch')
    for name, expected in binding['artifacts_sha256'].items():
        if digest(members[prefix + name]) != expected:
            raise ValueError('review artifact mismatch')
    run = json.loads(members[prefix + 'final-focused-suite.receipt.json'])
    if run['exit'] != 0 or run['timed_out'] or run['sha256_before'] != run['sha256_after']:
        raise ValueError('independent run incomplete or changed')
    for name, expected in run['sha256_after'].items():
        if digest(members['source/' + name]) != expected:
            raise ValueError('executed source mismatch')
    result = json.loads(members['evidence/acceptance-manifest-audit-v3.json'])
    if result['status'] != 'INCOMPLETE' or result['authority'] != 'NONE':
        raise ValueError('draft must preserve incompleteness')
    return {'kind': 'Development checkpoint; no system acceptance', 'authority': 'NONE',
            'baseline_head': binding['baseline_head'], 'source_kind': 'exact overlay on baseline',
            'bundle': {'path': BUNDLE, 'sha256': digest(compressed)},
            'members': {name: {'bytes': len(raw), 'sha256': digest(raw)}
                        for name, raw in sorted(members.items())},
            'independent_model': binding['reviewer_model_declaration'],
            'execution_receipt': prefix + 'final-focused-suite.receipt.json',
            'review': prefix + 'final-independent-review.txt',
            'draft_status': result['status'], 'draft_gap_count': len(result['gaps']),
            'preservation': 'Original counterexamples, failed result, original tests and normative rows retained.',
            'open': ['Detailed campaign/oracle roster and prospective workload budgets',
                     'Comprehensive pinned static analysis and remaining Power of Ten controls',
                     'Whole-project proof, installed qualification and all mandatory system gates'],
            'limits': ['Hash binding is not authenticated producer custody or proof.',
                       'Tests exercise structural metadata; authority remains NONE.',
                       'No new SPARK proof, install, release or mission acceptance.']}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--check', action='store_true')
    parser.add_argument('--root', type=Path, default=ROOT)
    parser.add_argument('--evidence', type=Path, default=EVIDENCE)
    args = parser.parse_args()
    members = collect(args.root, args.evidence)
    compressed = archive(members)
    record = (json.dumps(manifest(members, compressed), indent=2, sort_keys=True) + '\n').encode()
    for name, raw in ((BUNDLE, compressed), (MANIFEST, record)):
        path = args.root / name
        if args.check:
            if read(path) != raw:
                raise ValueError('retained bytes differ')
        else:
            with path.open('xb') as stream:
                stream.write(raw)
    print('Retained evidence reproduced exactly' if args.check else 'Created checkpoint evidence')


if __name__ == '__main__':
    main()

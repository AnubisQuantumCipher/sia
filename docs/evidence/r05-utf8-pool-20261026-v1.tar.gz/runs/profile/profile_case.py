"""Profile one unchanged delivery fixture, not the failed complete roster."""
import cProfile
import json
import pstats
import time
import unittest


def main():
    suite = unittest.defaultTestLoader.loadTestsFromNames([
        'tests.test_controller_source_capture_v3.ControllerSourceCaptureV3.'
        'test_real_idle_capture_keeps_gist_origins_and_bound_empty_journal'])
    profiler = cProfile.Profile()
    started = time.monotonic_ns()
    result = profiler.runcall(unittest.TextTestRunner(verbosity=2).run, suite)
    elapsed = time.monotonic_ns() - started
    stats = pstats.Stats(profiler).stats
    if len(stats) > 8192:
        raise ValueError('profile capacity')
    rows = [{'file': key[0], 'line': key[1], 'name': key[2],
             'primitive_calls': value[0], 'calls': value[1],
             'own_seconds': value[2], 'inclusive_seconds': value[3]}
            for key, value in stats.items()]
    rows.sort(key=lambda row: row['own_seconds'], reverse=True)
    print(json.dumps({'success': result.wasSuccessful(), 'tests': result.testsRun,
                      'elapsed_ns': elapsed, 'functions': rows,
                      'scope': 'One profiled original case; inclusive costs overlap. '
                               'Not full-roster qualification or unprofiled latency.'}))
    raise SystemExit(0 if result.wasSuccessful() else 1)


if __name__ == '__main__':
    main()

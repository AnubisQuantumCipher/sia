"""Audit exact selected pool controls; retain known nested-isolation diagnostics."""
import argparse
import ast
import datetime
import hashlib
import json
from pathlib import Path
import re

BASE = Path(__file__).resolve().parent
DIAGNOSTIC = ('SIA: unprivileged PID-namespace isolation is unavailable on this host '
              '(unshare refused); bounded subprocesses fall back to process-group isolation\n')


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def identities(root):
    manifest = json.loads((root / 'execution-source.json').read_text())
    binding = json.loads((root / 'source-binding.json').read_text())
    config = json.loads((root / 'config.json').read_text())
    mismatch = []
    for name, expected in manifest.items():
        if sha(root / name) != expected:
            mismatch.append('execution:' + name)
    for name, row in binding['files'].items():
        if sha(root / 'source' / name) != row['sha256']:
            mismatch.append('snapshot:' + name)
        if sha(Path(binding['canonical']) / name) != row['canonical_sha256']:
            mismatch.append('canonical:' + name)
    for group in ('tools', 'proof_tools'):
        for name, expected in config[group].items():
            if sha(Path(name)) != expected:
                mismatch.append('tool:' + name)
    return mismatch


def terminal_controls(execution):
    cleanup = execution['cleanup']
    terminal = execution['execution_status'] == 'TERMINAL_REPORTS_REQUIRE_AUDIT'
    terminal = terminal and cleanup['complete'] and not cleanup['errors']
    terminal = terminal and execution['proof_dispatched']
    terminal = terminal and set(execution['terminal']) == {'init', 'launcher', 'leader'}
    return terminal and all(row['terminal'] and row['reaped']
                            for row in execution['terminal'].values())


def expected_cases(root, phase):
    tree = ast.parse((root / 'test_utf8_pool.py').read_text())
    cases = set()
    for node in tree.body:
        if isinstance(node, ast.ClassDef):
            for method in node.body:
                if isinstance(method, ast.FunctionDef) and method.name.startswith('test_'):
                    cases.add('test_utf8_pool.' + node.name + '.' + method.name)
    if phase == 'regression':
        prior = (BASE / 'r05-revocation-regression-20261026-v1/proof.stderr').read_text()
        prior = prior.replace(DIAGNOSTIC, '')
        cases.update(re.findall(r'^test_\S+ \(([^)]+)\) \.\.\. ok$', prior, re.MULTILINE))
    return cases


def check_output(root, phase, execution):
    stderr = (root / 'proof.stderr').read_text()
    diagnostic_count = stderr.count(DIAGNOSTIC)
    normalized = stderr.replace(DIAGNOSTIC, '')
    counts = re.findall(r'^Ran (\d+) tests? in ([0-9.]+)s$', normalized, re.MULTILINE)
    if len(counts) != 1:
        raise ValueError('ambiguous test summary')
    count, elapsed = int(counts[0][0]), counts[0][1]
    results = re.findall(r'^test_\S+ \(([^)]+)\) \.\.\. ok$', normalized, re.MULTILINE)
    expected = expected_cases(root, phase)
    leftover = re.sub(r'^test_\S+ \([^)]+\) \.\.\. ok\n', '', normalized, flags=re.MULTILINE)
    summary = '\n' + '-' * 70 + '\nRan ' + str(count) + ' tests in ' + elapsed + 's\n\nOK\n'
    passed = (execution['exit'] == 0 and count == len(expected) == len(results)
              and set(results) == expected and leftover == summary
              and not (root / 'proof.stdout').read_bytes())
    return dict(output_pass=passed, tests=count, elapsed_seconds=elapsed,
                expected_tests=len(expected), missing=sorted(expected - set(results)),
                unexpected=sorted(set(results) - expected),
                nested_isolation_fallback_diagnostics=diagnostic_count,
                all_raw_output_classified=leftover == summary)


def audit(phase):
    root = BASE / ('r05-pool-' + phase + '-20261026-v2')
    execution = json.loads((root / 'execution-result.json').read_text())
    mismatch = identities(root)
    terminal = terminal_controls(execution)
    output = check_output(root, phase, execution)
    passed = output['output_pass'] and terminal and not mismatch
    names = ('execution-source.json', 'source-binding.json', 'execution-result.json',
             'proof.stdout', 'proof.stderr')
    result = dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  status='SELECTED_TESTS_PASS' if passed else 'NONPASS_CONTROL_FAILURE',
                  phase=phase, output=output, identity_mismatches=mismatch,
                  tracked_terminal_cleanup=terminal, exit=execution['exit'],
                  evidence_sha256={name: sha(root / name) for name in names},
                  independent_review='PENDING', adoption=False,
                  limitation='Fixed private pool controls only. Total Python heap, '
                             'lifecycle, cross-process quiescence, physical erasure, '
                             'material performance, R05 BOTH and system acceptance remain open.')
    with (root / 'OWNER-AUDIT.json').open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps(result))
    if not passed:
        raise SystemExit(1)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('phase', choices=('focused', 'regression'))
    audit(parser.parse_args().phase)


if __name__ == '__main__':
    main()

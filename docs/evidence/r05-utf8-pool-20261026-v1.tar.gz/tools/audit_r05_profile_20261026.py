"""Audit the unchanged one-case profile; no whole-workload timing inference."""
import datetime
import hashlib
import json
import math
from pathlib import Path
import re

BASE = Path(__file__).resolve().parent
ROOT = BASE / 'r05-current-delivery-profile-20261026-v1'
DIAGNOSTIC = ('SIA: unprivileged PID-namespace isolation is unavailable on this host '
              '(unshare refused); bounded subprocesses fall back to process-group isolation\n')
CASE = ('tests.test_controller_source_capture_v3.ControllerSourceCaptureV3.'
        'test_real_idle_capture_keeps_gist_origins_and_bound_empty_journal')


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def identities(root):
    manifest = json.loads((root / 'execution-source.json').read_text())
    binding = json.loads((root / 'source-binding.json').read_text())
    config = json.loads((root / 'config.json').read_text())
    mismatch = []
    for name, expected in manifest.items():
        if sha(root / name) != expected:
            mismatch.append('execution:' + name)
    for name, row in binding['files'].items():
        if sha(root / 'source' / name) != row['sha256']:
            mismatch.append('snapshot:' + name)
        if sha(Path(binding['canonical']) / name) != row['canonical_sha256']:
            mismatch.append('canonical:' + name)
    for group in ('tools', 'proof_tools'):
        for name, expected in config[group].items():
            if sha(Path(name)) != expected:
                mismatch.append('tool:' + name)
    return mismatch


def terminal_controls(execution):
    cleanup = execution['cleanup']
    terminal = execution['execution_status'] == 'TERMINAL_REPORTS_REQUIRE_AUDIT'
    terminal = terminal and cleanup['complete'] and not cleanup['errors']
    terminal = terminal and execution['proof_dispatched']
    terminal = terminal and set(execution['terminal']) == {'init', 'launcher', 'leader'}
    return terminal and all(row['terminal'] and row['reaped']
                            for row in execution['terminal'].values())


def profile_rows(value):
    if set(value) != {'success', 'tests', 'elapsed_ns', 'functions', 'scope'} \
            or value['success'] is not True or value['tests'] != 1 \
            or type(value['elapsed_ns']) is not int or value['elapsed_ns'] < 0:
        raise ValueError('profile output contract')
    rows = value['functions']
    if type(rows) is not list or not 1 <= len(rows) <= 8192:
        raise ValueError('profile row contract')
    keys = {'file', 'line', 'name', 'primitive_calls', 'calls',
            'own_seconds', 'inclusive_seconds'}
    for row in rows:
        if type(row) is not dict or set(row) != keys \
                or any(type(row[name]) is not str for name in ('file', 'name')) \
                or any(type(row[name]) is not int or row[name] < 0
                       for name in ('line', 'primitive_calls', 'calls')) \
                or any(type(row[name]) not in (int, float) or not math.isfinite(row[name])
                       or row[name] < 0 for name in ('own_seconds', 'inclusive_seconds')):
            raise ValueError('profile row shape')
    return rows


def main():
    execution = json.loads((ROOT / 'execution-result.json').read_text())
    profile = json.loads((ROOT / 'proof.stdout').read_text())
    rows = profile_rows(profile)
    stderr = (ROOT / 'proof.stderr').read_text()
    normalized = stderr.replace(DIAGNOSTIC, '')
    counts = re.findall(r'^Ran 1 test in ([0-9.]+)s$', normalized, re.MULTILINE)
    if len(counts) != 1:
        raise ValueError('profile test summary')
    expected = (CASE.rsplit('.', 1)[1] + ' (' + CASE + ') ... ok\n\n'
                + '-' * 70 + '\nRan 1 test in ' + counts[0] + 's\n\nOK\n')
    mismatch = identities(ROOT)
    terminal = terminal_controls(execution)
    passed = normalized == expected and execution['exit'] == 0 and terminal and not mismatch
    names = ('execution-source.json', 'source-binding.json', 'execution-result.json',
             'proof.stdout', 'proof.stderr', 'profile_case.py')
    selected = [row for row in rows if row['name'] in
                {'_count_ascii_json_string', '_json_size', '<method \'decode\' of \'bytes\' objects>'}]
    result = dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  status='PROFILE_CASE_PASS' if passed else 'NONPASS_CONTROL_FAILURE',
                  tests=1, elapsed_seconds=counts[0], functions=len(rows),
                  selected_rows=selected, top_own_time_rows=rows[:12],
                  known_fallback_diagnostics=stderr.count(DIAGNOSTIC),
                  all_raw_output_classified=normalized == expected,
                  identity_mismatches=mismatch, tracked_terminal_cleanup=terminal,
                  evidence_sha256={name: sha(ROOT / name) for name in names},
                  independent_review='PENDING', performance_qualification=False,
                  limitation='One original profiled case including fixture and assertions; '
                             'inclusive costs overlap; no unprofiled latency or R05 acceptance.')
    with (ROOT / 'OWNER-AUDIT.json').open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps(result))
    if not passed:
        raise SystemExit(1)


if __name__ == '__main__':
    main()

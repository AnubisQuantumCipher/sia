"""Prepare two fixed private pool evaluations; execute no product/test code."""
import copy
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

BASE = Path(__file__).resolve().parent
PRIOR = BASE / 'r05-revocation-regression-20261026-v1'
REPAIR = BASE / 'r05-utf8-pool-v1'
CARRIER = Path('/home/sicarii/Work/sia-assurance-checkpoint-20261023')
HEAD = 'f330d3f31f55ab67df07112a966d703a9698b266'
ROSTER = ['test_utf8_derivation', 'tests.test_retained_image_memo',
          'tests.test_retained_validation_preflight', 'tests.test_retained_validation_context',
          'tests.test_retained_projector_context', 'tests.test_replay_refusal_order',
          'tests.test_replay_interleaved_frontier', 'tests.test_replay_source_binding',
          'tests.test_intake_bounded_traversal', 'tests.test_event_live_intake']
TESTS = ('test_utf8_derivation.py', 'test_utf8_pool.py')


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write('\n')


def check_inputs():
    manifest = json.loads((REPAIR / 'SOURCE-MANIFEST.json').read_text())
    static = json.loads((REPAIR / 'STATIC-v3.json').read_text())
    if static['exit'] or static['stderr'] or json.loads(static['stdout']):
        raise ValueError('repair static failure')
    head = subprocess.run(['git', 'rev-parse', 'HEAD'], cwd=CARRIER,
                          capture_output=True, text=True, check=True).stdout.strip()
    status = subprocess.run(['git', 'status', '--porcelain'], cwd=CARRIER,
                            capture_output=True, text=True, check=True).stdout
    if head != HEAD or status:
        raise ValueError('clean source-bound publisher required')
    binding = json.loads((PRIOR / 'source-binding.json').read_text())
    if not 1 <= len(binding['files']) <= 2048 or binding['canonical'] != str(CARRIER):
        raise ValueError('source roster bound or carrier')
    for name, row in binding['files'].items():
        if sha(PRIOR / 'source' / name) != row['sha256']:
            raise ValueError('prior snapshot changed: ' + name)
        if sha(CARRIER / name) != row['canonical_sha256']:
            raise ValueError('source changed: ' + name)
    for name, row in manifest['source'].items():
        if binding['files']['bin/' + name]['sha256'] != row['original']:
            raise ValueError('tested original mismatch: ' + name)
        for side in ('original', 'candidate'):
            if sha(REPAIR / side / 'bin' / name) != row[side]:
                raise ValueError('repair source changed: ' + name)
    for name, expected in manifest['tests'].items():
        if sha(REPAIR / name) != expected:
            raise ValueError('test changed: ' + name)
    binding['head'] = HEAD
    return binding


def snapshot(root, original):
    binding = copy.deepcopy(original)
    overlays = json.loads((REPAIR / 'SOURCE-MANIFEST.json').read_text())['source']
    for name, row in binding['files'].items():
        source = CARRIER / name
        if name.startswith('bin/') and name[4:] in overlays:
            source = REPAIR / 'candidate' / name
        if source.is_symlink() or not source.is_file():
            raise ValueError('nonregular source: ' + name)
        target = root / 'source' / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, target)
        target.chmod(0o555 if source.stat().st_mode & 0o111 else 0o444)
        row.update(sha256=sha(target), bytes=target.stat().st_size)
    for name in ('obj', 'bin'):
        (root / 'source/spark' / name).mkdir(parents=True, mode=0o555)
    for path in (root / 'source').rglob('*'):
        if path.is_dir():
            path.chmod(0o555)
    (root / 'source').chmod(0o555)
    save(root / 'source-binding.json', binding)


def configure(root, phase):
    config = json.loads((PRIOR / 'config.json').read_text().replace(str(PRIOR), str(root)))
    roster = ROSTER + ['test_utf8_pool'] if phase == 'regression' else ['test_utf8_pool']
    code = ('import sys,unittest; sys.path[:0]=["/tmp","/tmp/source/bin","/tmp/source"]; '
            'from tests import sia_test_home; '
            'suite=unittest.defaultTestLoader.loadTestsFromNames(' + repr(roster) + '); '
            'result=unittest.TextTestRunner(verbosity=2).run(suite); '
            'raise SystemExit(0 if result.wasSuccessful() else 1)')
    config['proof_command'] = ['/usr/bin/python3', '-I', '-B', '-W',
                               'error::ResourceWarning', '-c', code]
    extra = ['--ro-bind', str(root / 'test_utf8_pool.py'), '/tmp/test_utf8_pool.py']
    config['namespace_prefix'].extend(extra)
    index = config['command'].index('/usr/bin/setpriv')
    config['command'][index:index] = extra
    config['candidate_phase'] = 'r05-pool-' + phase
    save(root / 'config.json', config)
    for name in ('proof_wrapper.py', 'proof_payload.py'):
        shutil.copyfile(PRIOR / name, root / name)
    for name in TESTS:
        shutil.copyfile(REPAIR / name, root / name)
    names = ('config.json', 'source-binding.json', 'proof_wrapper.py',
             'proof_payload.py') + TESTS
    save(root / 'execution-source.json', {name: sha(root / name) for name in names})
    print(json.dumps(dict(root=str(root), phase=phase, roster=roster,
                         manifest_sha256=sha(root / 'execution-source.json'))))


def main():
    binding = check_inputs()
    for phase in ('focused', 'regression'):
        root = BASE / ('r05-pool-' + phase + '-20261026-v2')
        root.mkdir(mode=0o700)
        for name in ('obj', 'bin', 'home', 'tmp', 'cache', 'out'):
            (root / name).mkdir(mode=0o700)
        snapshot(root, binding)
        configure(root, phase)


if __name__ == '__main__':
    main()

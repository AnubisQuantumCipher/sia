"""Audit exact selected pool controls; retain known nested-isolation diagnostics."""
import argparse
import ast
import datetime
import hashlib
import json
from pathlib import Path
import re

BASE = Path(__file__).resolve().parent
DIAGNOSTIC = ('SIA: unprivileged PID-namespace isolation is unavailable on this host '
              '(unshare refused); bounded subprocesses fall back to process-group isolation\n')


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def identities(root):
    manifest = json.loads((root / 'execution-source.json').read_text())
    binding = json.loads((root / 'source-binding.json').read_text())
    config = json.loads((root / 'config.json').read_text())
    mismatch = []
    for name, expected in manifest.items():
        if sha(root / name) != expected:
            mismatch.append('execution:' + name)
    for name, row in binding['files'].items():
        if sha(root / 'source' / name) != row['sha256']:
            mismatch.append('snapshot:' + name)
        if sha(Path(binding['canonical']) / name) != row['canonical_sha256']:
            mismatch.append('canonical:' + name)
    for group in ('tools', 'proof_tools'):
        for name, expected in config[group].items():
            if sha(Path(name)) != expected:
                mismatch.append('tool:' + name)
    return mismatch


def terminal_controls(execution):
    cleanup = execution['cleanup']
    terminal = execution['execution_status'] == 'TERMINAL_REPORTS_REQUIRE_AUDIT'
    terminal = terminal and cleanup['complete'] and not cleanup['errors']
    terminal = terminal and execution['proof_dispatched']
    terminal = terminal and set(execution['terminal']) == {'init', 'launcher', 'leader'}
    return terminal and all(row['terminal'] and row['reaped']
                            for row in execution['terminal'].values())


def expected_cases(root, phase):
    tree = ast.parse((root / 'test_utf8_pool.py').read_text())
    cases = set()
    for node in tree.body:
        if isinstance(node, ast.ClassDef):
            for method in node.body:
                if isinstance(method, ast.FunctionDef) and method.name.startswith('test_'):
                    cases.add('test_utf8_pool.' + node.name + '.' + method.name)
    if phase == 'regression':
        prior = (BASE / 'r05-revocation-regression-20261026-v1/proof.stderr').read_text()
        prior = prior.replace(DIAGNOSTIC, '')
        cases.update(re.findall(r'^test_\S+ \(([^)]+)\) \.\.\. ok$', prior, re.MULTILINE))
    return cases


def classify_stdout(root, phase):
    raw = (root / 'proof.stdout').read_text()
    if phase == 'focused':
        return dict(classified=not raw, rows=[])
    prior = (BASE / 'r05-revocation-regression-20261026-v1/proof.stdout').read_text()
    actual = [json.loads(line) for line in raw.splitlines()]
    expected = [json.loads(line) for line in prior.splitlines()]
    if len(actual) != 3 or len(expected) != 3:
        return dict(classified=False, rows=actual)
    observation = actual[0].get('utf8_reuse_single_observation')
    if type(observation) is not list or len(observation) != 2:
        return dict(classified=False, rows=actual)
    comparable = json.loads(raw.splitlines()[0])
    for index, sample in enumerate(comparable['utf8_reuse_single_observation']):
        if type(sample) is not dict or type(sample.get('elapsed_ns')) is not int \
                or sample['elapsed_ns'] < 0:
            return dict(classified=False, rows=actual)
        sample['elapsed_ns'] = expected[0]['utf8_reuse_single_observation'][index]['elapsed_ns']
    return dict(classified=comparable == expected[0] and actual[1:] == expected[1:],
                rows=actual, performance_qualification=False,
                rule='Exact prior diagnostic records; only nonnegative elapsed_ns may vary.')


def check_output(root, phase, execution):
    stderr = (root / 'proof.stderr').read_text()
    diagnostic_count = stderr.count(DIAGNOSTIC)
    normalized = stderr.replace(DIAGNOSTIC, '')
    counts = re.findall(r'^Ran (\d+) tests? in ([0-9.]+)s$', normalized, re.MULTILINE)
    if len(counts) != 1:
        raise ValueError('ambiguous test summary')
    count, elapsed = int(counts[0][0]), counts[0][1]
    results = re.findall(r'^test_\S+ \(([^)]+)\) \.\.\. ok$', normalized, re.MULTILINE)
    expected = expected_cases(root, phase)
    leftover = re.sub(r'^test_\S+ \([^)]+\) \.\.\. ok\n', '', normalized, flags=re.MULTILINE)
    summary = '\n' + '-' * 70 + '\nRan ' + str(count) + ' tests in ' + elapsed + 's\n\nOK\n'
    stdout = classify_stdout(root, phase)
    passed = (execution['exit'] == 0 and count == len(expected) == len(results)
              and set(results) == expected and leftover == summary
              and stdout['classified'])
    return dict(output_pass=passed, tests=count, elapsed_seconds=elapsed,
                expected_tests=len(expected), missing=sorted(expected - set(results)),
                unexpected=sorted(set(results) - expected),
                nested_isolation_fallback_diagnostics=diagnostic_count,
                all_raw_output_classified=leftover == summary and stdout['classified'],
                stdout=stdout)


def audit(phase):
    root = BASE / ('r05-pool-' + phase + '-20261026-v2')
    execution = json.loads((root / 'execution-result.json').read_text())
    mismatch = identities(root)
    terminal = terminal_controls(execution)
    output = check_output(root, phase, execution)
    passed = output['output_pass'] and terminal and not mismatch
    names = ('execution-source.json', 'source-binding.json', 'execution-result.json',
             'proof.stdout', 'proof.stderr')
    result = dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  status='SELECTED_TESTS_PASS' if passed else 'NONPASS_CONTROL_FAILURE',
                  phase=phase, output=output, identity_mismatches=mismatch,
                  tracked_terminal_cleanup=terminal, exit=execution['exit'],
                  evidence_sha256={name: sha(root / name) for name in names},
                  independent_review='PENDING', adoption=False,
                  limitation='Fixed private pool controls only. Total Python heap, '
                             'lifecycle, cross-process quiescence, physical erasure, '
                             'material performance, R05 BOTH and system acceptance remain open.')
    with (root / 'OWNER-AUDIT.json').open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps(result))
    if not passed:
        raise SystemExit(1)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('phase', choices=('focused', 'regression'))
    audit(parser.parse_args().phase)


if __name__ == '__main__':
    main()

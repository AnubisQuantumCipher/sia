"""Package the non-adopted pool experiment, failures and complete observations."""
import argparse
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

BASE = Path(__file__).resolve().parent
ROOT = BASE / 'r05-pool-package-20261026-v1'
POOL = BASE / 'r05-utf8-pool-v1'
ARCHIVE = 'r05-utf8-pool-20261026-v1.tar.gz'
SOURCES = ('siaeventplan.py', 'siasourcebatch.py', 'siaeventintake.py')
RUNS = {
    'focused': ('r05-pool-focused-20261026-v2', 'OWNER-AUDIT.json'),
    'regression': ('r05-pool-regression-20261026-v2', 'OWNER-AUDIT-v2.json'),
    'delivery-baseline': ('r05-workload-delivery-baseline-20261026-v1', 'OWNER-AUDIT.json'),
    'delivery-candidate': ('r05-workload-delivery-candidate-20261026-v1', 'OWNER-AUDIT.json'),
    'resident-baseline': ('r05-workload-resident-baseline-20261026-v1', 'OWNER-AUDIT.json'),
    'resident-candidate': ('r05-workload-resident-candidate-20261026-v1', 'OWNER-AUDIT.json'),
    'profile': ('r05-current-delivery-profile-20261026-v1', 'OWNER-AUDIT.json'),
}


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write('\n')


def roster():
    files = {}
    common = ('config.json', 'execution-source.json', 'source-binding.json',
              'execution-result.json', 'proof.stdout', 'proof.stderr',
              'proof_wrapper.py', 'proof_payload.py', 'RESULT-INDEPENDENT-REVIEW.json')
    for label, (directory, audit) in RUNS.items():
        for name in common + (audit,):
            files['runs/' + label + '/' + name] = BASE / directory / name
    files['failures/regression-audit-v1.json'] = BASE / RUNS['regression'][0] / 'OWNER-AUDIT.json'
    for name in ('test_utf8_derivation.py', 'test_utf8_pool.py', 'SOURCE-MANIFEST.json',
                 'SOURCE-MANIFEST-v1.json', 'STATIC-v1.json', 'STATIC-v2.json', 'STATIC-v3.json',
                 'SOURCE-INDEPENDENT-REVIEW-v1.json', 'SOURCE-INDEPENDENT-REVIEW-v2.json',
                 'EVALUATION-INDEPENDENT-REVIEW-v1.json', 'EVALUATION-INDEPENDENT-REVIEW-v2.json',
                 'EVALUATION-EXECUTION-v2.json', 'EVALUATION-STORAGE.json',
                 'LIFECYCLE-NEXT-REVIEW.json', 'DISPOSITION.json'):
        files['pool/' + name] = POOL / name
    for label, run in (('baseline', 'delivery-baseline'), ('candidate', 'focused')):
        for name in SOURCES:
            files[label + '-source/bin/' + name] = BASE / RUNS[run][0] / 'source/bin' / name
    for name in SOURCES:
        files['reviewed-precleanup-source/' + name] = POOL / 'reviewed-v1' / name
    profile = BASE / RUNS['profile'][0]
    for name in ('profile_case.py', 'PROFILE-SOURCE.json', 'EXECUTION-DECISION.json'):
        files['runs/profile/' + name] = profile / name
    for stem in ('prepare_r05_pool_evaluation_20261026', 'prepare_r05_workloads_20261026',
                 'prepare_r05_profile_20261026', 'audit_r05_pool_20261026',
                 'audit_r05_workloads_20261026', 'audit_r05_profile_20261026'):
        files['tools/' + stem + '.py'] = BASE / (stem + '.py')
    for name in ('audit_r05_pool_20261026-v1.py', 'audit_r05_pool_20261026-v2.py',
                 'audit_r05_pool_20261026.static-v3.json',
                 'audit_r05_workloads_20261026.static.json',
                 'audit_r05_workloads_20261026.review.json',
                 'audit_r05_profile_20261026.static.json',
                 'R05-WORKLOAD-EXECUTION-20261026.json',
                 'R05-WORKLOAD-INDEPENDENT-PREFLIGHT-20261026.json'):
        files['tools/' + name] = BASE / name
    files['tools/package_r05_pool_20261026.py'] = Path(__file__).resolve()
    return files


def check_inputs(files):
    for directory, name in RUNS.values():
        root = BASE / directory
        audit = json.loads((root / name).read_text())
        for relative, expected in audit['evidence_sha256'].items():
            if sha(root / relative) != expected:
                raise ValueError('audited evidence drift: ' + relative)
        review = json.loads((root / 'RESULT-INDEPENDENT-REVIEW.json').read_text())
        if review['audit_sha256'] != sha(root / name):
            raise ValueError('independent review drift')
        binding = json.loads((root / 'source-binding.json').read_text())
        for relative, row in binding['files'].items():
            if sha(root / 'source' / relative) != row['sha256']:
                raise ValueError('source snapshot drift: ' + relative)
    for name, path in files.items():
        if path.is_symlink() or not path.is_file():
            raise ValueError('nonregular input: ' + name)
    return {name: dict(sha256=sha(path), bytes=path.stat().st_size)
            for name, path in sorted(files.items())}


def archive_bytes(files):
    output = io.BytesIO()
    with gzip.GzipFile(fileobj=output, mode='wb', filename='', mtime=0) as zipped:
        with tarfile.open(fileobj=zipped, mode='w', format=tarfile.USTAR_FORMAT) as archive:
            for name, path in sorted(files.items()):
                data = path.read_bytes()
                info = tarfile.TarInfo(name)
                info.size, info.mode, info.mtime = len(data), 0o444, 0
                archive.addfile(info, io.BytesIO(data))
    return output.getvalue()


def manifest(files, data):
    results = {}
    for label, (directory, audit) in RUNS.items():
        result = json.loads((BASE / directory / audit).read_text())
        results[label] = dict(status=result['status'], observation=result.get('output',
                              {key: result.get(key) for key in ('tests', 'elapsed_seconds')}))
    return dict(status='EXPERIMENT_NOT_ADOPTED_MATERIAL_BENEFIT_UNESTABLISHED',
                base_commit='f330d3f31f55ab67df07112a966d703a9698b266',
                archive=dict(path='docs/evidence/' + ARCHIVE, bytes=len(data),
                             sha256=hashlib.sha256(data).hexdigest()),
                members=check_inputs(files), results=results,
                production_changes_adopted=False,
                limits=['Original test gates remain binding; R05 BOTH remains OPEN.',
                        'Selected pool controls are tested, not formally proved.',
                        'Complete workload behavior passed; every historical timing target missed.',
                        'Single observations do not establish causal performance change.',
                        'Profile includes fixtures/assertions and changes execution cost.',
                        'Lifecycle, cross-process quiescence, total heap and physical erasure unqualified.',
                        'Observer-loss custody remains UNKNOWN.',
                        'Configs use original local paths; not a portable execution service.',
                        'No installed, compaction, judge, release or marketplace acceptance.',
                        'Initial static test variant was not separately hash-frozen; its diagnostics remain.'])


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--check', action='store_true')
    args = parser.parse_args()
    files = roster()
    check_inputs(files)
    data = archive_bytes(files)
    expected = manifest(files, data)
    if args.check:
        if (ROOT / ARCHIVE).read_bytes() != data \
                or json.loads((ROOT / 'manifest.json').read_text()) != expected:
            raise ValueError('package reproduction mismatch')
    else:
        ROOT.mkdir(mode=0o700)
        (ROOT / ARCHIVE).write_bytes(data)
        save(ROOT / 'manifest.json', expected)
    print(json.dumps(dict(status='PACKAGE_CHECK_PASS' if args.check else 'PACKAGE_CREATED',
                          archive_sha256=expected['archive']['sha256'], members=len(files),
                          bytes=len(data), manifest_sha256=sha(ROOT / 'manifest.json'))))


if __name__ == '__main__':
    main()

"""Unchanged actual-EOF oracle must detect a compiled adapter fault."""
import runpy
import unittest

namespace = runpy.run_path("/tmp/newtests.py")
case = namespace["CapturedAdmission"]("test_actual_trailing_bytes_and_declared_counts")
result = unittest.TextTestRunner(verbosity=2).run(unittest.TestSuite([case]))
raise SystemExit(0 if result.wasSuccessful() and not result.skipped else 1)

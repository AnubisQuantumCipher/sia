"""Retain the original isolated regression workload and caps, adding integration tests."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
SOURCE = Path("/home/sicarii/Work/sia-assurance-checkpoint-20261023")


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def pins(binary):
    names = json.loads((ROOT / "base.json").read_text())["pins"]
    result = {name: digest(SOURCE / name) for name in names}
    for name in ("regression_case.py", "test_event_pack_admission.py", "test_run.py"):
        result["campaign/" + name] = digest(ROOT / name)
    result["binary"] = digest(binary)
    return result


def main():
    if len(sys.argv) != 2 or sys.argv[1] not in ("c2", "c3", "negative"):
        raise ValueError("declared candidate required")
    candidate = sys.argv[1]
    binary = ROOT / ("stage-" + candidate) / "spark/pack-proposal-bin/pack_proposal_probe"
    old = json.loads((ROOT.parent / "pack-captured-proposal-v1/v6-tests.json").read_text())
    command = old["command"][:]
    command[command.index("--unshare-net"):command.index("--unshare-net")] = [
        "--ro-bind", str(ROOT / "test_event_pack_admission.py"), "/tmp/newtests.py"]
    for index, argument in enumerate(command):
        if argument.endswith("/pack-captured-proposal-v1/regression_case.py"):
            command[index] = str(ROOT / "regression_case.py")
        if argument.endswith("/stage-v6/spark/pack-proposal-bin/pack_proposal_probe"):
            command[index] = str(binary)
    record = dict(command=command, environment=old["environment"], before=pins(binary))
    prefix = ROOT / (candidate + "-tests")
    with prefix.with_suffix(".inputs.json").open("x") as handle:
        json.dump(record, handle, indent=2)
    started = time.monotonic_ns()
    with prefix.with_suffix(".stdout").open("xb") as out, \
            prefix.with_suffix(".stderr").open("xb") as err:
        result = subprocess.run(command, env=old["environment"], stdout=out, stderr=err,
                                timeout=70, check=False)
    record.update(exit=result.returncode, elapsed_ns=time.monotonic_ns()-started,
                  after=pins(binary))
    with prefix.with_suffix(".result.json").open("x") as handle:
        json.dump(record, handle, indent=2)
    print(json.dumps({key: record[key] for key in ("exit", "elapsed_ns")}))
    raise SystemExit(result.returncode)


if __name__ == "__main__":
    main()

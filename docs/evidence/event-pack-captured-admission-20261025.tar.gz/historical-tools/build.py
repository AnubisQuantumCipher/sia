"""Build the test-only adapter under the existing resource policy."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent


def pins(stage, names):
    return {name: hashlib.sha256((stage / name).read_bytes()).hexdigest()
            for name in names}


def main():
    if len(sys.argv) != 2 or sys.argv[1] not in ("c2", "c3", "negative"):
        raise ValueError("declared candidate required")
    candidate = sys.argv[1]
    stage = ROOT / ("stage-" + candidate)
    names = json.loads((ROOT / "c1-build.inputs.json").read_text())["files"]
    command = ["flock", "-n", "-F", "/home/sicarii/.worldline-heavy.lock",
               "timeout", "--kill-after=5s", "60s", "bash", "-c",
               "ulimit -c 0; ulimit -f 524288; ulimit -v 2097152; "
               "source /home/sicarii/opt/gnat/env.sh; "
               "exec gprbuild -p -P spark/pack_proposal_probe.gpr -j1"]
    record = dict(command=command, cwd=str(stage), before=pins(stage, names))
    prefix = ROOT / (candidate + "-build")
    with prefix.with_suffix(".inputs.json").open("x") as handle:
        json.dump(record, handle, indent=2)
    started = time.monotonic_ns()
    with prefix.with_suffix(".stdout").open("xb") as out, \
            prefix.with_suffix(".stderr").open("xb") as err:
        result = subprocess.run(command, cwd=stage, stdout=out, stderr=err,
                                check=False, timeout=70)
    record.update(exit=result.returncode, elapsed_ns=time.monotonic_ns()-started,
                  after=pins(stage, names))
    binary = stage / "spark/pack-proposal-bin/pack_proposal_probe"
    record["binary_sha256"] = hashlib.sha256(binary.read_bytes()).hexdigest() if binary.is_file() else None
    with prefix.with_suffix(".result.json").open("x") as handle:
        json.dump(record, handle, indent=2)
    print(json.dumps({key: record[key] for key in ("exit", "elapsed_ns", "binary_sha256")}))
    raise SystemExit(result.returncode)


if __name__ == "__main__":
    main()

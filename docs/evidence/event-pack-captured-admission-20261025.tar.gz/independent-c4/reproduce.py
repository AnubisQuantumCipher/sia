"""One exact-source fresh build and unchanged bounded regression reproduction."""
import hashlib
import json
from pathlib import Path
import subprocess
import time

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent
SOURCE = Path('/home/sicarii/Work/sia-assurance-checkpoint-20261023')
STAGE = OUT / 'stage-c4'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(name, value):
    with (OUT / name).open('x') as handle:
        json.dump(value, handle, indent=2)


def execute(name, command, cwd, environment, snapshot, expected):
    before = snapshot()
    if before != expected:
        raise ValueError('prelaunch input mismatch: ' + name)
    record = dict(command=command, cwd=str(cwd), environment=environment, before=before)
    save(name + '.inputs.json', record)
    started = time.monotonic_ns()
    with (OUT / (name + '.stdout')).open('xb') as out, (OUT / (name + '.stderr')).open('xb') as err:
        child = subprocess.run(command, cwd=cwd, env=environment, stdout=out, stderr=err,
                               timeout=70, check=False)
    record.update(exit=child.returncode, elapsed_ns=time.monotonic_ns()-started,
                  after=snapshot())
    record['unchanged'] = record['before'] == record['after']
    save(name + '.result.json', record)
    print(json.dumps({key: record[key] for key in ('exit', 'elapsed_ns', 'unchanged')}), flush=True)
    if child.returncode != 0 or not record['unchanged']:
        raise ValueError('phase failed; no retry: ' + name)
    return record


def main():
    build = json.loads((ROOT / 'c4-build.result.json').read_text())
    source_pins = build['before']
    if len(source_pins) != 21 or source_pins != build['after']:
        raise ValueError('source roster mismatch')
    STAGE.mkdir()
    for name, expected in source_pins.items():
        original = ROOT / 'stage-c4' / name
        if digest(original) != expected:
            raise ValueError('original source drift: ' + name)
        target = STAGE / name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(original.read_bytes())
        if digest(target) != expected:
            raise ValueError('copied source mismatch')
    tools = [Path(name) for name in ('/usr/bin/flock','/usr/bin/prlimit','/usr/bin/timeout',
             '/usr/bin/bwrap','/usr/bin/python3','/usr/bin/bash','/home/sicarii/opt/gnat/env.sh',
             '/home/sicarii/Documents/sia-repository-audit-20261024/git-review-executable')]
    tool_pins = {str(path): digest(path) for path in tools}
    save('admission.json', dict(source_pins=source_pins, tool_pins=tool_pins,
                               build_command=build['command'], fresh_cache=True))
    def build_snapshot():
        return dict(source={name:digest(STAGE/name) for name in source_pins},
                    tools={name:digest(Path(name)) for name in tool_pins})
    execute('build', build['command'], STAGE, None, build_snapshot,
            dict(source=source_pins, tools=tool_pins))
    binary = STAGE / 'spark/pack-proposal-bin/pack_proposal_probe'
    record = json.loads((ROOT/'c4-tests.inputs.json').read_text())
    command = record['command'][:]
    old = str(ROOT/'stage-c4/spark/pack-proposal-bin/pack_proposal_probe')
    if command.count(old) != 1:
        raise ValueError('binary substitution not unique')
    command[command.index(old)] = str(binary)
    expected = dict(record['before'])
    expected['binary'] = digest(binary)
    def test_snapshot():
        rows = {}
        for name in expected:
            path = binary if name == 'binary' else ROOT/name[9:] if name.startswith('campaign/') else SOURCE/name
            rows[name] = digest(path)
        return dict(inputs=rows, source=build_snapshot()['source'], tools=build_snapshot()['tools'])
    execute('regression', command, SOURCE, record['environment'], test_snapshot,
            dict(inputs=expected, source=source_pins, tools=tool_pins))


if __name__ == '__main__':
    main()

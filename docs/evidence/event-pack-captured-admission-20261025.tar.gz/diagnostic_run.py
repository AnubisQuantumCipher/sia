"""Run declared fault controls with the same isolation and limits."""
import json
from pathlib import Path
import subprocess
import sys
import time

import test_run

ROOT = Path(__file__).resolve().parent


def main():
    if len(sys.argv) != 2 or sys.argv[1] not in ("cleanup", "negative"):
        raise ValueError("declared fault case required")
    variant = sys.argv[1]
    binary = ROOT / ("stage-" + variant) / "spark/pack-proposal-bin/pack_proposal_probe"
    old = json.loads((ROOT / "c4-tests.inputs.json").read_text())
    case = ROOT / (variant + "_case.py")
    command = old["command"][:]
    for index, argument in enumerate(command):
        if argument == str(ROOT / "regression_case.py"):
            command[index] = str(case)
        if argument.endswith("/stage-c4/spark/pack-proposal-bin/pack_proposal_probe"):
            command[index] = str(binary)
    record = dict(command=command, environment=old["environment"],
                  before=test_run.pins(binary), case_sha256=test_run.digest(case))
    prefix = ROOT / (variant + "-runtime")
    with prefix.with_suffix(".inputs.json").open("x") as handle:
        json.dump(record, handle, indent=2)
    started = time.monotonic_ns()
    with prefix.with_suffix(".stdout").open("xb") as out, \
            prefix.with_suffix(".stderr").open("xb") as err:
        result = subprocess.run(command, env=old["environment"], stdout=out, stderr=err,
                                timeout=70, check=False)
    record.update(exit=result.returncode, elapsed_ns=time.monotonic_ns()-started,
                  after=test_run.pins(binary), case_after_sha256=test_run.digest(case))
    with prefix.with_suffix(".result.json").open("x") as handle:
        json.dump(record, handle, indent=2)
    print(json.dumps({key: record[key] for key in ("exit", "elapsed_ns")}))
    raise SystemExit(result.returncode)


if __name__ == "__main__":
    main()

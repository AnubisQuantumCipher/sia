"""Derive the portable, non-acceptance evidence packet from retained bytes."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

ROOT = Path(__file__).resolve().parent
CANDIDATE = ROOT / "candidate"
ARCHIVE = "docs/evidence/event-pack-captured-admission-20261025.tar.gz"
RECEIPT = "docs/EVENT-PACK-CAPTURED-ADMISSION-EVIDENCE-20261025.json"


def digest(data):
    return hashlib.sha256(data).hexdigest()


def members():
    result = []
    fixed = ("base.json", "build.py", "test_run.py", "regression_case.py",
             "negative_case.py", "cleanup_case.py", "diagnostic_run.py", "package.py",
             "test_event_pack_admission.py", "test_event_pack_admission-c2.py",
             "proof-source-reuse.json", "fault-intents.json", "review-c2.json",
             "package-c1.py", "package-c1-evidence.json", "package-failure.json")
    result.extend(ROOT / name for name in fixed)
    for prefix in ("c1-", "c2-", "c3-", "c4-", "negative-", "cleanup-", "static-"):
        result.extend(path for path in ROOT.glob(prefix + "*") if path.is_file())
    result.extend((ROOT / "historical-tools").glob("*.py"))
    names = json.loads((ROOT / "c1-build.inputs.json").read_text())["files"]
    for stage in ("stage-c1", "stage-c2", "stage-c3", "stage-c4", "stage-negative", "stage-cleanup"):
        result.extend(ROOT / stage / name for name in names)
    independent = ROOT / "independent-c4"
    result.extend(path for path in independent.iterdir() if path.is_file())
    result.extend(independent / "stage-c4" / name for name in names)
    result.extend(path for path in CANDIDATE.rglob("*")
                  if path.is_file() and str(path.relative_to(CANDIDATE)) not in (ARCHIVE, RECEIPT))
    return sorted(set(result))


def archive(paths):
    destination = CANDIDATE / ARCHIVE
    destination.parent.mkdir(parents=True, exist_ok=True)
    hashes = {}
    with destination.open("wb") as raw, gzip.GzipFile(fileobj=raw, filename="", mode="wb", mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode="w") as output:
            for path in paths:
                if path.is_symlink():
                    raise ValueError("unexpected symbolic link")
                name, data = str(path.relative_to(ROOT)), path.read_bytes()
                info = tarfile.TarInfo(name)
                info.size, info.mode, info.mtime = len(data), 0o644, 0
                output.addfile(info, io.BytesIO(data))
                hashes[name] = digest(data)
    with tarfile.open(destination, "r:gz") as source:
        readback = {entry.name: digest(source.extractfile(entry).read()) for entry in source.getmembers()}
    if readback != hashes:
        raise ValueError("archive member readback mismatch")
    return hashes


def main():
    paths = members()
    hashes = archive(paths)
    source_pins = {str(path.relative_to(CANDIDATE)): digest(path.read_bytes())
                   for path in paths if CANDIDATE in path.parents}
    result = dict(status="INACTIVE_TEST_INTEGRATION_CHECKPOINT", authority="NONE",
                  base_commit=json.loads((ROOT / "base.json").read_text())["commit"],
                  source_sha256=source_pins, members=hashes)
    result["archive"] = dict(path=ARCHIVE, bytes=(CANDIDATE / ARCHIVE).stat().st_size,
                             sha256=digest((CANDIDATE / ARCHIVE).read_bytes()))
    result["owner"] = dict(tests=378, skips=0, strict_build="PASS", regression="PASS",
                           cleanup_controls=3, negative="compiled EOF bypass fails unchanged oracle")
    result["independent"] = json.loads((ROOT / "independent-c4/final-review.json").read_text())
    result["proof"] = json.loads((ROOT / "proof-source-reuse.json").read_text())
    result["failures"] = ["c1 obsolete aggregate syntax", "c3 unobserved modified file state",
                          "c2 passed before cleanup repair; not final-source qualification"]
    result["limits"] = "Test adapter outside SPARK; no authentication, protected effects, installation, native/R05 closure, release or whole-system assurance. Allocation and stderr failures remain environmental limits."
    (CANDIDATE / RECEIPT).write_text(json.dumps(result, sort_keys=True, indent=2) + "\n")
    print(json.dumps(dict(members=len(hashes), archive=result["archive"],
                          receipt_sha256=digest((CANDIDATE / RECEIPT).read_bytes()))))


if __name__ == "__main__":
    main()

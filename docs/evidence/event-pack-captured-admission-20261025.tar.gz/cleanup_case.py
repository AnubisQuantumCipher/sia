"""Exercise primary and paired cleanup failures through the fault-injected executable."""
import os
from pathlib import Path
import runpy
import subprocess
import tempfile
import unittest

namespace = runpy.run_path("/tmp/newtests.py")


class Cleanup(unittest.TestCase):
    def exercise(self, *, primary=False, short_proposal=False):
        frame, selected, fallback = namespace["synthetic"](1, 0)
        if primary:
            selected = b"\xff" + selected[1:]
        if short_proposal:
            frame = frame[:-1]
        with tempfile.TemporaryDirectory() as directory:
            paths = [Path(directory) / name for name in ("proposal", "selected", "fallback")]
            for path, data in zip(paths, (frame, selected, fallback), strict=True):
                self.assertEqual(path.write_bytes(data), len(data))
            arguments = paths[:1] if short_proposal else paths
            result = subprocess.run([os.environ["SIA_PACK_PROPOSAL_PROBE"],
                                     *(str(path) for path in arguments)],
                                    capture_output=True, timeout=5, check=False)
            self.assertNotEqual(result.returncode, 0)
            self.assertEqual(result.stdout, b"")
            self.assertIn(b"selection cleanup failure: raised PROGRAM_ERROR : INJECTED_CLOSE", result.stderr)
            if not short_proposal:
                self.assertIn(b"fallback cleanup failure: raised PROGRAM_ERROR : INJECTED_CLOSE", result.stderr)
            if primary or short_proposal:
                message = b"short proposal" if short_proposal else b"INJECTED_PRIMARY"
                self.assertIn(b"primary input failure: raised CONSTRAINT_ERROR : " + message, result.stderr)
                self.assertTrue(result.stderr.rstrip().endswith(b"raised CONSTRAINT_ERROR : " + message), result.stderr)
            else:
                self.assertNotIn(b"primary input failure:", result.stderr)
                self.assertTrue(result.stderr.rstrip().endswith(b"raised PROGRAM_ERROR : INJECTED_CLOSE"), result.stderr)
            print(result.stderr.decode(), end="")

    def test_both_cleanup_errors_prevent_acceptance(self):
        self.exercise()

    def test_primary_and_both_cleanup_errors_retained(self):
        self.exercise(primary=True)

    def test_proposal_read_error_survives_close_error(self):
        self.exercise(short_proposal=True)


result = unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(Cleanup))
raise SystemExit(0 if result.wasSuccessful() and not result.skipped else 1)

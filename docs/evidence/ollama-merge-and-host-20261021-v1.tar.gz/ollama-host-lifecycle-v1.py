"""Qualify live UFW reload and guard stop/start without restarting Ollama."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path

ROOT = Path('/home/sicarii/Work/sia-assurance-evidence-20261019')


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


def main():
    if os.geteuid() != 0:
        raise ValueError('administrator required')
    driver = PROBES.DRIVER
    run = driver.run
    check = ['/usr/bin/python3', '-I', '-S', '-B',
             '/usr/local/libexec/sia-ollama-guard', 'check-kernel']
    run('lifecycle-kernel-before', check)
    run('system-unit-verify', ['/usr/bin/systemd-analyze', 'verify',
                             '/etc/systemd/system/sia-ollama-guard.service'])
    run('ufw-reload', ['/usr/bin/ufw', 'reload'], 60)
    run('kernel-after-ufw-reload', check)
    run('ufw-after-reload', ['/usr/bin/ufw', 'status', 'verbose'])
    run('denial-after-ufw-reload', ['/usr/bin/runuser', '-u', 'nobody', '--',
        '/usr/bin/python3', '-I', '-S', '-B', '-c', PROBES.DENIED])
    run('guard-stop', ['/usr/bin/systemctl', 'stop', 'sia-ollama-guard.service'])
    run('kernel-after-guard-stop', check)
    run('denial-after-guard-stop', ['/usr/bin/runuser', '-u', 'nobody', '--',
        '/usr/bin/python3', '-I', '-S', '-B', '-c', PROBES.DENIED])
    run('guard-start', ['/usr/bin/systemctl', 'start', 'sia-ollama-guard.service'], 60)
    run('kernel-after-guard-start', check)
    run('owner-embedding-after-reload', ['/usr/bin/runuser', '-u', 'sicarii', '--',
        '/usr/bin/python3', '-I', '-S', '-B', '-c', PROBES.OWNER], 90)
    run('owner-gate-after-lifecycle', ['/usr/bin/runuser', '-u', 'sicarii', '--',
        '/usr/bin/python3', '-I', '-S', '-B',
        '/usr/local/libexec/sia-ollama-guard', 'gate'])
    driver.save('lifecycle-result.json', (json.dumps({
        'status': 'OBSERVED_UFW_RELOAD_AND_GUARD_STOP_START_PASS',
        'checks': driver.EVENTS,
        'listener_restart_performed': False,
        'open': ['actual boot ordering', 'actual Ollama restart',
                 'installed upgrade/uninstall lifecycle', 'complete SIA readiness']}, indent=2) + '\n').encode())
    print('Live UFW reload and guard stop/start preserved denial; owner embedding and full gate passed.')


if __name__ == '__main__':
    PROBES = load('host_probes', ROOT / 'probe-ollama-host-v1.py')
    PROBES.DRIVER = load('commission_driver', ROOT / 'commission-ollama-host-v1.py')
    helper = ROOT / 'bounded-read-capture-v1.py'
    if hashlib.sha256(helper.read_bytes()).hexdigest() != 'e647b40e9cf1aa705c107c54535889b3f08b6651ec989a07add5cf371d6dc5b6':
        raise ValueError('capture helper changed')
    PROBES.DRIVER.CAPTURE = load('capture', helper)
    main()

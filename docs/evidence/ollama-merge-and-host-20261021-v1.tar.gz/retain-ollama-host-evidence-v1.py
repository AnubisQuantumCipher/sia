"""Publish selected receipts only; private firewall snapshots and retrieved text stay local."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import sys
import tarfile

ROOT=Path(__file__).parent
REPO=Path('/home/sicarii/Work/sia-assurance-kernel-20261019')
HOST=ROOT/'ollama-host-commission-20261021-v1'
DEST=REPO/'docs/OLLAMA-MERGE-AND-HOST-EVIDENCE-20261021.json'
BUNDLE=REPO/'docs/evidence/ollama-merge-and-host-20261021-v1.tar.gz'
LIMIT=1_048_576
FILES=(
    'merge-freeze-close-20261021-v1/merge-intent.json',
    'merge-freeze-close-20261021-v1/pr-before.stdout',
    'merge-freeze-close-20261021-v1/pr-after.stdout',
    'merge-freeze-close-20261021-v1/merge.command.json',
    'merge-freeze-close-20261021-v1/retired-request.stdout',
    'merge-ollama-fix-20261021-v1/merge-intent.json',
    'merge-ollama-fix-20261021-v1/pr-before.stdout',
    'merge-ollama-fix-20261021-v1/pr-after.stdout',
    'merge-ollama-fix-20261021-v1/merge.command.json',
    'ollama-merge-base-20261021-v1/receipt.json',
    'ollama-merge-base-20261021-v1/freeze-unit.stderr',
    'ollama-merge-base-20261021-v1/actual-main-push-gate.stdout',
    'ollama-source-merge-review-20261021.txt',
    'ollama-merge-composition-review-20261021.txt',
    'ollama-host-commission-20261021-v1/source.json',
    'ollama-host-commission-20261021-v1/installed-hashes.json',
    'ollama-host-commission-20261021-v1/installation-result.json',
    'ollama-host-commission-20261021-v1/runtime-result.json',
    'ollama-host-commission-20261021-v1/lifecycle-result.json',
    'ollama-host-commission-20261021-v1/unrelated-policy-comparison.json',
    'ollama-host-commission-20261021-v1/user-unit-update.json',
    'ollama-host-commission-20261021-v1/owner-embedding.log',
    'ollama-host-commission-20261021-v1/other-account-denial.log',
    'ollama-host-commission-20261021-v1/owner-delegation.log',
    'ollama-host-commission-20261021-v1/owner-embedding-after-reload.log',
    'ollama-host-commission-20261021-v1/service-readback.log',
    'ollama-host-commission-20261021-v1/owner-gate-after-lifecycle.log',
    'installed-readiness-after-guard-v1.json',
    'installed-readiness-after-guard-v1.log',
    'installed-note-direct-20261021-v6.json',
    'installed-note-direct-20261021-v6.log',
    'installed-note-direct-20261021-v7.json',
    'installed-note-body-comparison-v7.json',
    'commission-ollama-host-v1.py', 'probe-ollama-host-v1.py',
    'ollama-host-lifecycle-v1.py', 'bounded-read-capture-v1.py',
    'retain-ollama-host-evidence-v1.py')


def read(name):
    path=ROOT/name
    if path.is_symlink() or not path.resolve().is_relative_to(ROOT.resolve()):
        raise ValueError('unsafe artifact path')
    with path.open('rb') as stream:
        raw=stream.read(LIMIT+1)
    if len(raw)>LIMIT:
        raise ValueError('artifact exceeds bounded input')
    return raw


def value(name):
    return json.loads(read(name))


def verify():
    merges=[value(name) for name in ('merge-freeze-close-20261021-v1/pr-after.stdout',
        'merge-ollama-fix-20261021-v1/pr-after.stdout')]
    if any(x['state']!='MERGED' for x in merges):
        raise ValueError('merge not confirmed')
    source=value('ollama-host-commission-20261021-v1/source.json')
    installed=value('ollama-host-commission-20261021-v1/installed-hashes.json')
    if source['merged_source']!=merges[1]['mergeCommit']['oid']:
        raise ValueError('host source differs from merged source')
    if any(installed[name]!=source[name]['sha256'] for name in ('helper','unit','sudoers')):
        raise ValueError('installed hashes differ')
    records=[value('ollama-host-commission-20261021-v1/'+name) for name in (
        'installation-result.json','runtime-result.json','lifecycle-result.json')]
    for record in records:
        if not record['checks'] or any(x['exit']!=0 or x['capture_status']!='complete' for x in record['checks']):
            raise ValueError('host command incomplete or failed')
        for item in record['checks']:
            raw=read('ollama-host-commission-20261021-v1/'+item['name']+'.log')
            if hashlib.sha256(raw).hexdigest()!=item['sha256']:
                raise ValueError('private source log changed')
    ready=value('installed-readiness-after-guard-v1.json')
    if ready['exit']!=0 or ready['capture_status']!='complete' or ready['before']!=ready['after']:
        raise ValueError('native readiness not confirmed')
    recalled=value('installed-note-body-comparison-v7.json')
    if not all(recalled[k] for k in ('same_body','exact_origin','request_id_present','installed_binaries_unchanged')):
        raise ValueError('exact note readback not confirmed')
    return merges,source,ready,recalled


def packed():
    output=io.BytesIO()
    with gzip.GzipFile(fileobj=output,mode='wb',mtime=0) as zipped:
        with tarfile.open(fileobj=zipped,mode='w|',format=tarfile.USTAR_FORMAT) as archive:
            for name in sorted(FILES):
                raw=read(name)
                entry=tarfile.TarInfo(name)
                entry.size=len(raw)
                entry.mode=0o600
                archive.addfile(entry,io.BytesIO(raw))
    return output.getvalue()


def store(path,raw,checking):
    if checking:
        if path.read_bytes()!=raw:
            raise ValueError('versioned artifact does not reproduce: '+str(path))
    else:
        with path.open('xb') as stream:
            stream.write(raw)


def main():
    if sys.argv[1:] not in ([],['--check']):
        raise ValueError('expected optional --check')
    checking=sys.argv[1:]==['--check']
    merges,source,ready,recalled=verify()
    bundle=packed()
    artifacts=[{'path':name,'bytes':len(read(name)),'sha256':hashlib.sha256(read(name)).hexdigest()} for name in FILES]
    result={'status':'OBSERVED_SOURCE_MERGES_AND_SCOPED_INSTALLED_GUARD_CONTROLS',
        'merges':merges,'installed_source':source,'native_readiness':ready,
        'direct_model_note':recalled,'artifacts':artifacts,
        'bundle':{'path':str(BUNDLE.relative_to(REPO)),'sha256':hashlib.sha256(bundle).hexdigest(),'bytes':len(bundle)},
        'private_exclusions':['full firewall snapshots/status','original returned note text','unrelated user configuration'],
        'open':['post-merge main CI','actual boot and Ollama restart execution','installed upgrade/uninstall lifecycle',
            'new release and exact-SHA marketplace approval','complete SIA assurance and continuity mission'],
        'limits':['Current runtime CLI remains the previously installed version; only reviewed guard and user unit were updated.',
            'Kernel/systemd/nftables/interpreter/root administrator remain trusted.',
            'Same-UID code and privileged firewall changes remain outside this account boundary.',
            'Direct model-note recall is not semantic retrieval accuracy or automatic continuity.']}
    store(BUNDLE,bundle,checking)
    store(DEST,(json.dumps(result,indent=2,sort_keys=True)+'\n').encode(),checking)
    print('host and merge receipts match' if checking else 'host and merge receipts retained')


if __name__=='__main__':
    main()

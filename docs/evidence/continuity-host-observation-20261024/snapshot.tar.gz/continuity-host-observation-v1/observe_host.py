"""Read pinned host metadata/bytes only; never import candidate code."""
import hashlib
import json
import os
from pathlib import Path
import stat

PREP = Path('/home/sicarii/Documents/Codex/2026-10-24/task/sia-codex-adapter/docs/evidence/codex-continuity-adapter-20261024/wrapper-v2')
MANIFESTS = ('administrative-seed330.json', 'prospective-stdlib-inputs.json',
             'prospective-crypto-inputs.json', 'prospective-native-dependencies.json',
             'startup-context-inputs.json')
PACKAGES = ('cffi', 'cffi-2.1.1.dist-info', 'cryptography',
            'cryptography-50.0.1.dist-info', 'pycparser', 'pycparser-3.0.dist-info')
FIELDS = ('st_dev', 'st_ino', 'st_mode', 'st_uid', 'st_gid', 'st_nlink',
          'st_size', 'st_mtime_ns', 'st_ctime_ns')
MAX_BYTES = 536870912


def require(condition, reason):
    if not condition:
        raise ValueError(reason)


def identity(info):
    return {key: getattr(info, key) for key in FIELDS}


def load_manifests():
    values, pins = {}, {}
    for name in MANIFESTS:
        path = PREP / name
        before = path.lstat()
        require(stat.S_ISREG(before.st_mode) and before.st_size <= 16777216,
                'bounded regular manifest')
        data = path.read_bytes()
        require(identity(before) == identity(path.lstat()) and len(data) == before.st_size,
                'manifest changed')
        values[name] = json.loads(data)
        pins[name] = hashlib.sha256(data).hexdigest()
    return values, pins


def cohorts(values):
    files = dict(values['administrative-seed330.json'])
    stdlib = values['prospective-stdlib-inputs.json']
    crypto = values['prospective-crypto-inputs.json']['packages']
    native = values['prospective-native-dependencies.json']
    require(set(crypto) == set(PACKAGES) | {'native_cffi_backend'}, 'crypto cohort')
    groups = [stdlib['files'], native['files']]
    groups.extend(crypto[name]['files'] for name in PACKAGES)
    backend = crypto['native_cffi_backend']
    groups.append({backend['path']: backend})
    for group in groups:
        require(type(group) is dict and len(group) <= 2048, 'file cohort bound')
        for name, row in group.items():
            if name in files:
                require(all(files[name][key] == row[key] for key in ('bytes', 'sha256')),
                        'duplicate byte disagreement')
            files[name] = row
    require(len(files) <= 2048, 'aggregate file cohort bound')
    require(all(type(row['bytes']) is int and 0 <= row['bytes'] <= MAX_BYTES
                for row in files.values()), 'declared sizes')
    require(sum(row['bytes'] for row in files.values()) <= MAX_BYTES, 'aggregate read budget')
    directories = list(stdlib['directories'])
    for name in PACKAGES:
        directories.extend(crypto[name]['directories'])
    require(len(directories) <= 4096 and len(native['aliases']) <= 32, 'metadata cohort bound')
    return files, directories, native['aliases']


def file_row(name, expected):
    path = Path(name)
    resolved = path.resolve(strict=True)
    before = path.stat()
    require(stat.S_ISREG(before.st_mode) and before.st_size == expected['bytes'],
            'regular file size mismatch')
    require(str(resolved) == expected['resolved'], 'canonical target mismatch')
    descriptor = os.open(resolved, os.O_RDONLY | os.O_CLOEXEC | os.O_NOFOLLOW | os.O_NONBLOCK)
    try:
        require(identity(os.fstat(descriptor)) == identity(before), 'open identity mismatch')
        digest, total = hashlib.sha256(), 0
        for _ in range(MAX_BYTES // 65536 + 1):
            data = os.read(descriptor, min(65536, expected['bytes'] + 1 - total))
            if not data:
                break
            total += len(data)
            require(total <= expected['bytes'], 'file grew')
            digest.update(data)
        else:
            raise ValueError('read iteration bound')
        require(total == expected['bytes'], 'short file')
        require(identity(os.fstat(descriptor)) == identity(before), 'open file drift')
    finally:
        os.close(descriptor)
    require(identity(path.stat()) == identity(before) and path.resolve(strict=True) == resolved,
            'pathname drift')
    actual = {'bytes': total, 'sha256': digest.hexdigest(),
              'resolved': str(resolved), 'identity': identity(before)}
    require(all(actual[key] == expected[key] for key in actual if key in expected),
            'declared file bytes or identity mismatch')
    return actual


def directory_row(expected):
    path = Path(expected['path'])
    info = path.lstat()
    require(stat.S_ISDIR(info.st_mode) and path.resolve(strict=True) == path,
            'canonical directory mismatch')
    require(identity(info) == expected['identity'], 'directory identity mismatch')
    return identity(info)


def alias_row(name, expected):
    path = Path(name)
    before = path.lstat()
    require(stat.S_ISLNK(before.st_mode), 'alias type mismatch')
    actual = {'identity': identity(before), 'text': os.readlink(path),
              'resolved': str(path.resolve(strict=True))}
    require(actual == expected and identity(path.lstat()) == identity(before),
            'alias identity, text or target mismatch')
    return actual


def startup(values):
    entries = values['startup-context-inputs.json']['entries']
    require(len(entries) <= 32, 'startup absence cohort bound')
    for name, expected in entries.items():
        require(expected == {'absent': True} and not os.path.lexists(name), 'startup context present')
    for name in ('/etc/ld.so.preload', '/var/lib/pacman/db.lck'):
        require(not os.path.lexists(name), 'preload or package mutation present')
    names = []
    for index, path in enumerate(Path('/usr/lib/python3.14/site-packages').iterdir()):
        require(index < 20000 and not path.name.endswith('.pth'), 'startup namespace or hook')
        names.append(path.name)
    return sorted(names)


def main():
    values, before = load_manifests()
    files, directories, aliases = cohorts(values)
    report = {'scope': 'Read-only named host endpoints; no candidate import, runtime '
              'profile, loaded-code authenticity or continuous custody claim.',
              'manifests_before': before, 'files': {}, 'directories': {}, 'aliases': {},
              'failures': [], 'status': 'NONPASS', 'candidate_execution': False}
    tasks = (('files', files.items(), file_row),
             ('directories', ((row['path'], row) for row in directories),
              lambda _name, row: directory_row(row)),
             ('aliases', aliases.items(), alias_row))
    for group, entries, operation in tasks:
        for name, expected in entries:
            try:
                report[group][name] = operation(name, expected)
            except (OSError, ValueError, KeyError, TypeError) as error:
                report['failures'].append({'group': group, 'path': name,
                                           'kind': type(error).__name__, 'reason': str(error)})
    try:
        report['startup_names'] = startup(values)
        _, after = load_manifests()
        report['manifests_after'] = after
        require(after == before, 'manifest endpoints changed')
    except (OSError, ValueError, KeyError, TypeError) as error:
        report['failures'].append({'group': 'startup-or-manifest', 'kind': type(error).__name__,
                                   'reason': str(error)})
    if not report['failures']:
        report['status'] = 'OBSERVED_NAMED_ENDPOINTS_MATCH'
    print(json.dumps(report, indent=2))
    return 0 if not report['failures'] else 1


if __name__ == '__main__':
    raise SystemExit(main())

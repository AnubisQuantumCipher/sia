"""SAVED_UNRUN final guard preparation and independent occupied-slot cases."""
import unittest
from unittest.mock import patch

from test_main_resources import MainProduction
from test_support import PROBE, zero_clock


class EntryAndRetirement(MainProduction):
    def test_guard_preparation_failure_is_raw_and_no_sdk_acquisition(self):
        self.positive()
        error = MemoryError('first finalization guard')
        code, state, io, stream = self.invoke(patches=(
            patch.object(PROBE, 'Capture', side_effect=error),))
        self.assertEqual(code, 1)
        self.assertIs(state.raw[0], error)
        self.assertEqual(state.phases[0], 'late-finalization')
        self.assertEqual(io.used, 0)
        self.assertEqual(stream.writes, 0)

    def test_guarded_late_output_budget_preserves_serializer_refusal(self):
        self.positive()
        original = PROBE.Output.record
        def exhaust(output, value):
            output.state.read_bytes = 536870912
            return original(output, value)
        code, state, io, _stream = self.invoke(patches=(
            patch.object(PROBE.Output, 'record', exhaust),))
        self.assertEqual(code, 1)
        self.assertEqual(state.raw[0].args, ('SDK aggregate preparation/text/output bound',))
        self.assertEqual(state.phases[0], 'serializer')
        io.assert_closed(self)
        self.assertTrue(all(value is None for value in state.diagnostic_refs))

    def test_each_occupied_selected_slot_failure_does_not_skip_other32(self):
        with patch.object(PROBE.time, 'monotonic_ns', zero_clock):
            for failed in PROBE.DerivedRefs.__slots__:
                with self.subTest(failed=failed):
                    state = PROBE.ProbeState()
                    state.work, state.total = 1, 5000000001
                    checker = PROBE.build_checker(state)
                    sentinel, error = object(), OSError('selected retirement')
                    for field in PROBE.DerivedRefs.__slots__:
                        setattr(checker.refs, field, sentinel)
                    attempts, original = [], PROBE.retire_owned_attribute
                    def retire(value, field, *, attempts=attempts, checker=checker, error=error, failed=failed, original=original):
                        if value is checker.refs:
                            attempts.append(field)
                            if field == failed:
                                raise error
                        return original(value, field)
                    with patch.object(PROBE, 'retire_owned_attribute', retire):
                        checker.clear()
                    self.assertEqual(attempts, list(PROBE.DerivedRefs.__slots__))
                    self.assertIs(state.raw[0], error)
                    self.assertEqual(state.phases[0], 'selected-reference-clear')
                    for field in PROBE.DerivedRefs.__slots__:
                        if field != failed:
                            self.assertIsNone(getattr(checker.refs, field))
                    self.assertIs(getattr(checker.refs, failed), sentinel)


class ExactOutputRefusal(unittest.TestCase):
    def test_positive_then_exact_prelength_and_precharge_refusals(self):
        state = PROBE.ProbeState()
        state.work, state.total = 1, 5000000001
        with patch.object(PROBE.time, 'monotonic_ns', zero_clock):
            output = PROBE.Output(state)
            output.prepare()
            output.text('positive')
            self.assertEqual(bytes(output.buffer[:output.used]), b'"positive"')
            with patch.object(PROBE.json, 'dumps') as encoder:
                with self.assertRaises(ValueError) as caught:
                    output.text('x' * 4097)
                self.assertEqual(caught.exception.args, ('SDK output exact text prelength',))
                encoder.assert_not_called()
            state.read_bytes = 536870912
            with patch.object(PROBE.json, 'dumps') as encoder:
                with self.assertRaises(ValueError) as caught:
                    output.text('within-name-bound')
                self.assertEqual(caught.exception.args, ('SDK aggregate preparation/text/output bound',))
                encoder.assert_not_called()


if __name__ == '__main__':
    unittest.main()

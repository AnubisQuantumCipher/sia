"""SAVED_UNRUN exact native diagnostic routes and bounded output predicates."""
import unittest
from unittest.mock import patch

from test_support import PROBE, zero_clock


class CallbackError(Exception):
    calls = 0

    def __getattribute__(self, _name):
        CallbackError.calls += 1
        raise AssertionError('diagnostic candidate getter')

    def __str__(self):
        CallbackError.calls += 1
        raise AssertionError('diagnostic candidate str')

    def __repr__(self):
        CallbackError.calls += 1
        raise AssertionError('diagnostic candidate repr')


class NativeDiagnostics(unittest.TestCase):
    def setUp(self):
        self.clock = patch.object(PROBE.time, 'monotonic_ns', zero_clock)
        self.clock.start()
        self.addCleanup(self.clock.stop)
        self.state = PROBE.ProbeState()
        self.state.work, self.state.total = 1, 5000000001
        self.checker = PROBE.build_checker(self.state)
        self.addCleanup(self.checker.clear)
        PROBE.prepare_diagnostics(self.state, self.checker)
        self.addCleanup(PROBE.clear_diagnostics, self.state,
                        PROBE.Capture(self.state, 'diagnostic-reference-clear'))

    def install(self, errors):
        self.assertLessEqual(len(errors), 64)
        for index in range(len(errors)):
            self.state.raw[index], self.state.phases[index] = errors[index], 'ROOT'
        self.state.used = len(errors)

    def positive(self):
        error = OSError('bounded', 3)
        self.install([error])
        result = PROBE.diagnostics(self.state)
        self.assertEqual(result['errors'][0]['class_tag'], 'OSError')
        self.assertEqual(result['errors'][0]['args'], ['bounded', 3])
        self.assertTrue(result['errors'][0]['complete'])
        self.assertIs(self.state.raw[0], error)
        self.assertIs(self.state.diagnostic_refs[0], error)
        return result

    def test_valid_positive_then_shared_direct_cyclic_root_aliases_only(self):
        self.positive()
        first, second = OSError('first'), ValueError('second')
        first.__cause__, first.__context__ = second, first
        second.__cause__, second.__context__ = first, second
        self.install([first, second, first])
        self.state.diagnostic_refs[:] = [None] * 192
        self.state.diagnostic_used = 0
        result = PROBE.diagnostics(self.state)
        rows = result['errors']
        self.assertEqual([row['process_local_reference'] for row in rows], [0, 1, 0])
        self.assertEqual((rows[0]['cause_reference'], rows[0]['context_reference']), (1, 0))
        self.assertEqual((rows[1]['cause_reference'], rows[1]['context_reference']), (0, 1))
        self.assertFalse(any(row['complete'] for row in rows))
        self.assertEqual(self.state.diagnostic_used, 2)
        self.assertIs(self.state.raw[0], first)
        self.assertIs(self.state.raw[1], second)

    def test_64_roots_128_unique_immediate_endpoints_exact_fixed_slots(self):
        roots = [OSError('root') for _ in range(64)]
        for error in roots:
            error.__cause__, error.__context__ = OSError('cause'), OSError('context')
        self.install(roots)
        result = PROBE.diagnostics(self.state)
        self.assertEqual(len(result['errors']), 64)
        self.assertEqual(self.state.diagnostic_used, 192)
        self.assertFalse(result['reference_overflow'])
        for index in range(64):
            self.assertIs(self.state.diagnostic_refs[index], roots[index])
            self.assertFalse(result['errors'][index]['complete'])

    def test_unsupported_callback_error_raw_retained_without_callbacks(self):
        self.positive()
        error = CallbackError('opaque')
        CallbackError.calls = 0
        self.install([error])
        projection = PROBE.diagnostics(self.state)
        self.assertFalse(projection['errors'][0]['complete'])
        self.assertIsNone(projection['errors'][0]['class_tag'])
        self.assertIs(self.state.raw[0], error)
        self.assertEqual(CallbackError.calls, 0)

    def test_each_native_descriptor_kind_owner_name_receiver_and_output_refuses(self):
        self.positive()
        capsule = self.state.capsule
        for field in ('args_descriptor', 'dict_descriptor', 'cause_descriptor', 'context_descriptor'):
            with self.subTest(field=field):
                original = getattr(capsule, field)
                setattr(capsule, field, object())
                with self.assertRaises(ValueError) as caught:
                    PROBE.diagnostics(self.state)
                self.assertEqual(caught.exception.args, ('diagnostic exact native descriptor kind',))
                setattr(capsule, field, original)
        descriptor = capsule.args_descriptor
        for wrong in (object(), None, 'not exception'):
            with self.subTest(receiver=type(wrong)):
                with self.assertRaises(ValueError) as caught:
                    capsule.read(self.state, descriptor, wrong, 'args', tuple)
                self.assertEqual(caught.exception.args, ('diagnostic native exception receiver',))
        with self.assertRaises(ValueError) as caught:
            capsule.check_descriptor(self.state, descriptor, ValueError, 'args')
        self.assertEqual(caught.exception.args, ('diagnostic exact native descriptor owner',))
        with self.assertRaises(ValueError) as caught:
            capsule.check_descriptor(self.state, descriptor, BaseException, 'wrong')
        self.assertEqual(caught.exception.args, ('diagnostic exact native descriptor name',))
        original_get = capsule.get
        def wrong_output(desc, receiver, owner):
            if desc is descriptor:
                return []
            return original_get(desc, receiver, owner)
        capsule.get = wrong_output
        with self.assertRaises(ValueError) as caught:
            PROBE.diagnostics(self.state)
        self.assertEqual(caught.exception.args, ('diagnostic native descriptor output',))
        capsule.get = original_get

    def test_native_primary_and_each_capsule_retirement_secondary_retained(self):
        self.positive()
        primary, secondary = OSError('native route'), OSError('capsule close')
        capsule = self.state.capsule
        original_get, original_retire = capsule.get, PROBE.retire_owned_attribute
        def fail_native(desc, receiver, owner):
            if desc is capsule.args_descriptor:
                raise primary
            return original_get(desc, receiver, owner)
        capsule.get = fail_native
        with PROBE.Capture(self.state, 'diagnostics'):
            PROBE.diagnostics(self.state)
        attempts = []
        def retire(value, field):
            if value is capsule:
                attempts.append(field)
                if field == 'kind':
                    raise secondary
            return original_retire(value, field)
        with patch.object(PROBE, 'retire_owned_attribute', retire):
            PROBE.clear_diagnostics(self.state, PROBE.Capture(self.state, 'diagnostic-reference-clear'))
        self.assertEqual(attempts, list(PROBE.DiagnosticCapsule.__slots__))
        self.assertIs(self.state.raw[1], primary)
        self.assertIs(self.state.raw[2], secondary)
        self.assertEqual(self.state.phases[1:3], ['diagnostics', 'diagnostic-reference-clear'])

    def test_unsupported_args_extra_dict_and_text_budget_remain_incomplete(self):
        self.positive()
        for error in (OSError(object()), OSError('x' * 257), ValueError(1, 2, 3, 4, 5)):
            with self.subTest(argument_count=len(error.args)):
                self.install([error])
                self.assertFalse(PROBE.diagnostics(self.state)['errors'][0]['complete'])
        error = OSError('extra')
        error.extra = 'bounded but unadmitted'
        self.install([error])
        self.assertFalse(PROBE.diagnostics(self.state)['errors'][0]['complete'])
        self.state.read_bytes = 536870912
        with self.assertRaises(ValueError) as caught:
            PROBE.diagnostics(self.state)
        self.assertEqual(caught.exception.args, ('SDK aggregate preparation/text/output bound',))


class BoundedOutput(unittest.TestCase):
    def setUp(self):
        self.clock = patch.object(PROBE.time, 'monotonic_ns', zero_clock)
        self.clock.start()
        self.addCleanup(self.clock.stop)
        self.state = PROBE.ProbeState()
        self.state.work, self.state.total = 1, 5000000001
        self.output = PROBE.Output(self.state)
        self.output.prepare()

    def test_valid_positive_precharge_then_oversize_and_aggregate_refuse_before_encoder(self):
        self.output.text('bounded')
        self.assertEqual(bytes(self.output.buffer[:self.output.used]), b'"bounded"')
        for text in ('x' * 4097, 'bounded'):
            with self.subTest(length=len(text)):
                if len(text) <= 4096:
                    self.state.read_bytes = 536870912
                with patch.object(PROBE.json, 'dumps') as encoder:
                    with self.assertRaises(ValueError):
                        self.output.text(text)
                encoder.assert_not_called()

    def test_chunk_repeat_charge_and_utf8_invalid_never_full_materialization(self):
        self.output.text('a' * 2048)
        first = self.state.read_bytes
        self.output.text('a' * 2048)
        self.assertGreater(self.state.read_bytes, first)
        with self.assertRaises(UnicodeEncodeError):
            self.output.text('\ud800')
        self.assertLessEqual(self.output.used, 8388608)


if __name__ == '__main__':
    unittest.main()

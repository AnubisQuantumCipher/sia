"""SAVED_UNRUN original IO/namespace and mapped-origin production oracles."""
import hashlib
import os
import unittest
from contextlib import ExitStack
from types import SimpleNamespace
from unittest.mock import patch

from test_support import Harness, PROBE, zero_clock


def stat_fields(size=2):
    return dict(st_dev=os.makedev(0, 1), st_ino=2, st_mode=0o100444,
                st_nlink=1, st_uid=0, st_gid=0, st_size=size,
                st_mtime_ns=1, st_ctime_ns=1)


def expected_row():
    return {'identity': stat_fields(), 'sha256': hashlib.sha256(b'ab').hexdigest()}


class FileWorld:
    """Bounded synthetic primitive acquisition; production helpers stay live."""

    def __init__(self, paths=('/input',), maps=None):
        self.paths = tuple(paths)
        self.blocks = {path: (b'a', b'b', b'') for path in self.paths}
        self.before, self.after, self.post = stat_fields(), stat_fields(), stat_fields()
        self.maps = maps
        self.opened, self.closed, self.reads, self.stats = [], [], [], {}
        self.streams, self.fd_paths, self.remainders = {}, {}, {}
        self.read_error, self.close_error, self.post_error = None, None, None
        self.stat_error, self.stat_error_at = None, None

    def open(self, path, flags):
        if path == '/proc/self/maps' and self.maps is not None:
            number, blocks = 31, self.maps
        else:
            if path not in self.paths:
                raise AssertionError('unexpected synthetic file acquisition')
            number, blocks = 17, self.blocks[path]
        self.opened.append(path)
        self.streams[number], self.fd_paths[number], self.stats[number] = iter(blocks), path, 0
        self.remainders[number] = b''
        return number

    def read(self, number, amount):
        if len(self.reads) >= 20000:
            raise AssertionError('synthetic read fixture bound')
        self.reads.append((number, amount))
        if self.read_error is not None:
            raise self.read_error
        block = self.remainders[number] or next(self.streams[number])
        self.remainders[number] = block[amount:]
        return block[:amount]

    def fstat(self, number):
        self.stats[number] += 1
        if self.stat_error is not None and self.stats[number] == self.stat_error_at:
            raise self.stat_error
        if number == 31:
            return SimpleNamespace(**stat_fields(0))
        value = self.before if self.stats[number] == 1 else self.after
        return SimpleNamespace(**value)

    def lstat(self, path):
        if self.post_error is not None:
            raise self.post_error
        if path not in self.paths:
            raise AssertionError('unexpected synthetic endpoint')
        return SimpleNamespace(**self.post)

    def close(self, number):
        self.closed.append(number)
        if self.close_error is not None:
            raise self.close_error
        return None

    def install(self, stack):
        for field in ('open', 'read', 'fstat', 'lstat', 'close'):
            stack.enter_context(patch.object(PROBE.os, field, getattr(self, field)))
        stack.enter_context(patch.object(PROBE.os.path, 'realpath', side_effect=lambda path: path))
        return self


class Entry:
    reads = 0

    def __init__(self, name):
        self.value = name

    @property
    def name(self):
        Entry.reads += 1
        return self.value


class Directory:
    def __init__(self, count=0, names=None, primary=None, secondary=None):
        self.count, self.names, self.primary, self.secondary = count, names, primary, secondary
        self.used, self.closed = 0, 0

    def __next__(self):
        if self.primary is not None:
            raise self.primary
        if self.used == self.count:
            raise StopIteration
        if self.used >= 8193:
            raise AssertionError('directory fixture exceeds fixed bound')
        name = 'entry' + str(self.used) if self.names is None else self.names[self.used]
        self.used += 1
        return Entry(name)

    def close(self):
        self.closed += 1
        if self.secondary is not None:
            raise self.secondary
        return None


class IOBoundaries(unittest.TestCase):
    def setUp(self):
        clock = patch.object(PROBE.time, 'monotonic_ns', zero_clock)
        clock.start()
        self.addCleanup(clock.stop)

    def state(self):
        value = PROBE.ProbeState()
        value.work, value.total, value.stage = 1, 5000000001, 'IO_TEST'
        return value

    def direct_error(self, state, action, message):
        with self.assertRaises(ValueError) as caught:
            action()
        self.assertIs(type(caught.exception), ValueError)
        self.assertEqual(caught.exception.args, (message,))
        self.assertEqual(state.stage, 'IO_TEST')
        self.assertEqual(state.used, 0)
        return caught.exception

    def guarded_error(self, state, action, phase, message=None, primary=None):
        with self.assertRaises(RuntimeError) as caught:
            action()
        self.assertIs(caught.exception, state.failure)
        self.assertGreaterEqual(state.used, 1)
        self.assertEqual(state.phases[0], phase)
        self.assertEqual(state.stage, 'IO_TEST')
        if primary is not None:
            self.assertIs(state.raw[0], primary)
        else:
            self.assertIs(type(state.raw[0]), ValueError)
            self.assertEqual(state.raw[0].args, (message,))
        return state.raw[0]

    def regular_positive(self, method='read'):
        state, world = self.state(), FileWorld()
        with ExitStack() as stack:
            world.install(stack)
            actual = (PROBE.read_bounded(state, '/input', 2) if method == 'read'
                      else PROBE.file_row(state, '/input'))
        self.assertEqual(actual, b'ab' if method == 'read' else expected_row())
        self.assertEqual(world.closed, [17])
        self.assertEqual(state.used, 0)
        return actual

    def test_every_full9_endpoint_field_read_and_hash(self):
        for method in ('read', 'hash'):
            for endpoint in ('after', 'post'):
                for field in PROBE.FIELDS:
                    self.regular_positive(method)
                    state, world = self.state(), FileWorld()
                    getattr(world, endpoint)[field] += 1
                    action = (lambda *, state=state: PROBE.read_bounded(state, '/input', 2)) if method == 'read' else (
                        lambda *, state=state: PROBE.file_row(state, '/input'))
                    message = ('regular SDK JSON endpoint changed or incomplete' if method == 'read'
                               else 'SDK input endpoint changed during hash')
                    with ExitStack() as stack:
                        world.install(stack)
                        self.guarded_error(state, action, 'read' if method == 'read' else 'hash', message)
                    self.assertEqual(world.closed, [17])

    def test_origin_all_full9_hash_and_source_cache_paths(self):
        paths = (PROBE.DERIVED_SO, PROBE.DERIVED_PY, PROBE.DERIVED_PYC)
        for path in paths:
            for field in PROBE.FIELDS + ('sha256',):
                self.regular_positive('hash')
                state, world = self.state(), FileWorld(paths)
                expected = expected_row()
                cohort = {'files': {path: expected}, 'excluded_origins': {},
                          'probe_source': expected_row()}
                with ExitStack() as stack:
                    world.install(stack)
                    self.assertEqual(PROBE.admitted_origin(state, path, cohort), path)
                    if field == 'sha256':
                        expected[field] = '0' * 64
                    else:
                        expected['identity'][field] += 1
                    self.direct_error(state, lambda *, cohort=cohort, path=path, state=state: PROBE.admitted_origin(state, path, cohort),
                                      'observed SDK origin was not prospectively pinned')
                self.assertEqual(world.closed, [17, 17])

    def test_origin_missing_excluded_and_unknown_paths_no_acquisition(self):
        for mode in ('missing', 'excluded', 'unknown'):
            self.regular_positive('hash')
            state, world = self.state(), FileWorld((PROBE.DERIVED_SO,))
            cohort = {'files': {}, 'excluded_origins': {}, 'probe_source': expected_row()}
            if mode == 'excluded':
                cohort['excluded_origins'][PROBE.DERIVED_SO] = 'excluded'
            path = '/unknown/provider' if mode == 'unknown' else PROBE.DERIVED_SO
            message = ('explicitly excluded SDK provider loaded' if mode == 'excluded'
                       else 'observed SDK origin was not prospectively pinned')
            with ExitStack() as stack:
                world.install(stack)
                self.direct_error(state, lambda *, cohort=cohort, path=path, state=state: PROBE.admitted_origin(state, path, cohort), message)
            self.assertEqual(world.opened, [])

    def test_digest_preparation_fault_has_no_owned_open(self):
        self.regular_positive('hash')
        state, primary = self.state(), OSError('digest preparation')
        with patch.object(PROBE.hashlib, 'sha256', side_effect=primary), patch.object(
                PROBE.os, 'open') as opened:
            with self.assertRaises(OSError) as caught:
                PROBE.file_row(state, '/input')
        self.assertIs(caught.exception, primary)
        opened.assert_not_called()
        self.assertEqual(state.used, 0)

    def test_read_hash_primary_and_close_error_objects_and_exact_phases(self):
        for method in ('read', 'hash'):
            for location in ('read', 'fstat-first', 'fstat-post', 'poststat', 'update'):
                if method == 'read' and location == 'update':
                    continue
                self.regular_positive(method)
                state, world = self.state(), FileWorld()
                primary, secondary = OSError('primary'), OSError('secondary-close')
                world.close_error = secondary
                if location == 'read':
                    world.read_error = primary
                elif location == 'poststat':
                    world.post_error = primary
                elif location.startswith('fstat-'):
                    world.stat_error = primary
                    world.stat_error_at = 1 if location == 'fstat-first' else 2
                action = (lambda *, state=state: PROBE.read_bounded(state, '/input', 2)) if method == 'read' else (
                    lambda *, state=state: PROBE.file_row(state, '/input'))
                with ExitStack() as stack:
                    world.install(stack)
                    if location == 'update':
                        digest = SimpleNamespace(update=lambda block, *, primary=primary: self.raise_object(primary),
                                                 hexdigest=lambda: 'unused')
                        stack.enter_context(patch.object(PROBE.hashlib, 'sha256', return_value=digest))
                    self.guarded_error(state, action, 'read' if method == 'read' else 'hash', primary=primary)
                self.assertEqual(state.used, 2)
                self.assertIs(state.raw[1], secondary)
                self.assertEqual(state.phases[1], 'read-close' if method == 'read' else 'hash-close')
                self.assertEqual(world.closed, [17])

    def raise_object(self, error):
        raise error

    def test_regular_read_eof_limit_and_noeof_each_once_close(self):
        scenarios = (([b'a', b''], 2, 'regular SDK JSON endpoint changed or incomplete'),
                     ([b'abc'], 2, 'SDK read overflow'),
                     ([b'a'] * 129, 1024, 'SDK read loop exhausted without EOF'))
        for blocks, limit, message in scenarios:
            self.regular_positive()
            state, world = self.state(), FileWorld()
            world.blocks['/input'] = blocks
            with ExitStack() as stack:
                world.install(stack)
                self.guarded_error(state, lambda *, limit=limit, state=state: PROBE.read_bounded(state, '/input', limit), 'read', message)
            self.assertEqual(world.closed, [17])
        self.regular_positive()

    def test_hash_growth_short_eof_and_missing_eof_preserve_raw(self):
        scenarios = (([b'abc'], 'SDK hash grew past admitted size'),
                     ([b'a', b''], 'SDK hash loop exhausted or size mismatch'),
                     ([b'a'] * 1025, 'SDK hash loop exhausted or size mismatch'))
        for blocks, message in scenarios:
            self.regular_positive('hash')
            state, world = self.state(), FileWorld()
            world.blocks['/input'] = blocks
            if len(blocks) == 1025:
                world.before['st_size'] = 1025
            with ExitStack() as stack:
                world.install(stack)
                self.guarded_error(state, lambda *, state=state: PROBE.file_row(state, '/input'), 'hash', message)
            self.assertEqual(world.closed, [17])

    def test_namespace_limit_excess_sort_and_independent_close(self):
        for count in (8192, 8193):
            state, iterator = self.state(), Directory(8192)
            with patch.object(PROBE.os, 'scandir', return_value=iterator):
                self.assertEqual(len(PROBE.bounded_names(state, '/namespace')), 8192)
            self.assertEqual(iterator.closed, 1)
            state, iterator = self.state(), Directory(count)
            Entry.reads = 0
            with patch.object(PROBE.os, 'scandir', return_value=iterator), patch.object(
                    PROBE, 'sorted', wraps=sorted, create=True) as sort:
                if count == 8192:
                    self.assertEqual(len(PROBE.bounded_names(state, '/namespace')), 8192)
                    self.assertEqual(sort.call_count, 1)
                else:
                    self.guarded_error(state, lambda *, state=state: PROBE.bounded_names(state, '/namespace'),
                                       'namespace-read', 'SDK namespace exceeds fixed entry budget')
                    sort.assert_not_called()
            self.assertEqual(Entry.reads, 8192)
            self.assertEqual(iterator.closed, 1)

    def test_namespace_iteration_deadline_and_close_actual_secondary(self):
        for mode in ('iterator', 'deadline'):
            state, iterator = self.state(), Directory(1)
            with patch.object(PROBE.os, 'scandir', return_value=iterator):
                self.assertEqual(PROBE.bounded_names(state, '/namespace'), ['entry0'])
            state = self.state()
            primary, secondary = OSError('scan-primary'), OSError('scan-close')
            iterator = Directory(1, primary=primary if mode == 'iterator' else None, secondary=secondary)
            with ExitStack() as stack:
                stack.enter_context(patch.object(PROBE.os, 'scandir', return_value=iterator))
                if mode == 'deadline':
                    stack.enter_context(patch.object(PROBE.time, 'monotonic_ns', side_effect=[0, state.total]))
                    with self.assertRaises(RuntimeError) as caught:
                        PROBE.bounded_names(state, '/namespace')
                    self.assertIs(caught.exception, state.failure)
                    self.assertIs(type(state.raw[0]), TimeoutError)
                    self.assertEqual(state.raw[0].args, ('original absolute SDK probe deadline',))
                    self.assertEqual(state.phases[0], 'namespace-read')
                else:
                    self.guarded_error(state, lambda *, state=state: PROBE.bounded_names(state, '/namespace'),
                                       'namespace-read', primary=primary)
            self.assertIs(state.raw[1], secondary)
            self.assertEqual(state.phases[1], 'namespace-close')
            self.assertEqual(iterator.closed, 1)

    def namespace_cohort(self):
        fields = stat_fields(0)
        return {'directories': {'/namespace': {'identity': fields, 'names': ['ok.py']}},
                'aliases': {'/alias': {'identity': dict(fields), 'link': 'target',
                                       'resolved': '/target'}},
                'negative_lookup': {'/absent': {'state': 'ENOENT'},
                    'site_top_level_special': {'directory': '/site', 'names': [],
                        'predicate': '*.pth or sitecustomize*/usercustomize*'}}}

    def namespace_run(self, cohort, changed=None):
        observations = {'/namespace': 0}
        def lstat(path):
            if path == '/namespace':
                observations[path] += 1
            values = stat_fields(0)
            if changed == 'directory' and path == '/namespace':
                values['st_ino'] = 3
            if changed == 'directory-late' and path == '/namespace' and observations[path] == 2:
                values['st_ino'] = 3
            if changed == 'alias-identity' and path == '/alias':
                values['st_ino'] = 3
            return SimpleNamespace(**values)
        def scandir(path):
            names = ['ok.py'] if path == '/namespace' else []
            if changed == 'names' and path == '/namespace':
                names = ['changed.py']
            if changed == 'startup' and path == '/site':
                names = ['bad.pth']
            return Directory(len(names), names)
        with ExitStack() as stack:
            stack.enter_context(patch.object(PROBE.os, 'lstat', side_effect=lstat))
            stack.enter_context(patch.object(PROBE.os, 'scandir', side_effect=scandir))
            stack.enter_context(patch.object(PROBE.os, 'readlink',
                                            return_value='bad' if changed == 'link' else 'target'))
            stack.enter_context(patch.object(PROBE.os.path, 'realpath',
                                            return_value='/bad' if changed == 'resolved' else '/target'))
            stack.enter_context(patch.object(PROBE.os.path, 'lexists', return_value=changed == 'negative'))
            return PROBE.verify_namespace(self.namespace_state, cohort)

    def test_namespace_directory_alias_negative_and_startup_changes(self):
        cases = (('directory', 'SDK directory endpoint changed'),
                 ('directory-late', 'SDK directory changed around namespace observation'),
                 ('names', 'SDK directory namespace changed'),
                 ('alias-identity', 'SDK alias changed'), ('link', 'SDK alias changed'),
                 ('resolved', 'SDK alias changed'), ('negative', 'SDK negative lookup changed'),
                 ('startup', 'SDK startup customization changed'))
        for changed, message in cases:
            self.namespace_state = self.state()
            self.namespace_run(self.namespace_cohort())
            self.namespace_state = self.state()
            self.direct_error(self.namespace_state,
                              lambda *, changed=changed: self.namespace_run(self.namespace_cohort(), changed), message)

    def map_row(self, permission='r-xp', device='00:01', inode='2', path=None):
        path = PROBE.DERIVED_SO if path is None else path
        return ('0000-1000 ' + permission + ' 00000000 ' + device + ' ' + inode + ' ' + path + '\n').encode()

    def maps_run(self, state, blocks, expected=None):
        world = FileWorld((PROBE.DERIVED_SO,), maps=blocks)
        cohort = {'files': {PROBE.DERIVED_SO: expected_row() if expected is None else expected},
                  'excluded_origins': {}, 'probe_source': expected_row()}
        with ExitStack() as stack:
            world.install(stack)
            try:
                result = PROBE.maps(state, cohort)
            finally:
                self.assertEqual(world.closed.count(31), 1)
                self.assertEqual(world.closed.count(17), world.opened.count(PROBE.DERIVED_SO))
        return result

    def maps_positive(self):
        state, row = self.state(), self.map_row()
        result = self.maps_run(state, (row[:7], row[7:], b''))
        self.assertEqual(result['regular_origins'], [PROBE.DERIVED_SO])
        self.assertEqual(result['raw_utf8'], row.decode())
        self.assertEqual(state.used, 0)

    def test_maps_short_prefix_then_unknown_suffix_requires_complete_eof(self):
        self.maps_positive()
        state, row = self.state(), self.map_row()
        suffix = b'0000-1000 rw-p 0 00:00 0 unpinned-suffix\n'
        self.direct_error(state, lambda: self.maps_run(state, (row[:7], row[7:], suffix, b'')),
                          'unknown nonregular mapped origin')

    def test_maps_each_device_inode_path_executable_and_conflicting_row(self):
        cases = ((self.map_row(device='01:01'), 'actual mapped device/inode differs from prospective file'),
                 (self.map_row(device='00:02'), 'actual mapped device/inode differs from prospective file'),
                 (self.map_row(inode='3'), 'actual mapped device/inode differs from prospective file'),
                 (self.map_row(path='/unknown/provider'), 'observed SDK origin was not prospectively pinned'),
                 (self.map_row(permission='r--p'), 'pinned producer has no observed executable mapping'),
                 (self.map_row() + self.map_row(inode='3'),
                  'actual mapped device/inode differs from prospective file'))
        for row, message in cases:
            self.maps_positive()
            state = self.state()
            self.direct_error(state, lambda *, row=row, state=state: self.maps_run(state, (row[:9], row[9:], b'')), message)

    def test_maps_row_bound_and_regular_full9_hash_mismatch(self):
        self.maps_positive()
        state = self.state()
        rows = b'0000-1000 rw-p 0 00:00 0 [anon]\n' * 8193
        self.direct_error(state, lambda: self.maps_run(state, (rows, b'')), 'SDK mapped row bound')
        for field in PROBE.FIELDS + ('sha256',):
            self.maps_positive()
            state, expected = self.state(), expected_row()
            if field == 'sha256':
                expected[field] = '0' * 64
            else:
                expected['identity'][field] += 1
            self.direct_error(state, lambda *, expected=expected, state=state: self.maps_run(state, (self.map_row(), b''), expected),
                              'observed SDK origin was not prospectively pinned')

    def test_actual_module_census_cache_origin_changes_keep_policy_live(self):
        for path in (PROBE.DERIVED_PY, PROBE.DERIVED_PYC, PROBE.DERIVED_SO):
            h = Harness(self)
            modules = tuple(h.modules.values())
            paths = set()
            for module in modules:
                for key in ('__file__', '__cached__'):
                    value = module.__dict__.get(key)
                    if value is not None:
                        paths.add(value)
            cohort = {'files': {name: expected_row() for name in paths},
                      'excluded_origins': {}, 'probe_source': expected_row()}
            world = FileWorld(tuple(paths))
            with ExitStack() as stack:
                world.install(stack)
                stack.enter_context(patch.object(PROBE.os.path, 'exists', return_value=True))
                PROBE.modules(h.state, cohort, h.checker)
            h.checker.graph(recheck=True)
            h.checker.final_roster()
            h.close()
            h = Harness(self)
            expected = cohort['files'][path]
            expected['sha256'] = '0' * 64
            world = FileWorld(tuple(paths))
            with ExitStack() as stack:
                world.install(stack)
                stack.enter_context(patch.object(PROBE.os.path, 'exists', return_value=True))
                with self.assertRaises(ValueError) as caught:
                    PROBE.modules(h.state, cohort, h.checker)
            self.assertEqual(caught.exception.args, ('observed SDK origin was not prospectively pinned',))
            self.assertEqual(h.state.stage, 'METADATA')
            h.close()


    def test_prospective_malformed_shapes_refuse_before_namespace_traversal(self):
        mutations = (('directory-keys', 'SDK full9 identity keys'),
                     ('alias-link', 'SDK alias link bound'),
                     ('negative-shape', 'SDK negative lookup row shape'),
                     ('startup-predicate', 'SDK startup predicate mismatch'))
        for mode, message in mutations:
            self.namespace_state = self.state()
            self.namespace_run(self.namespace_cohort())
            cohort = self.namespace_cohort()
            if mode == 'directory-keys':
                del cohort['directories']['/namespace']['identity']['st_ino']
            elif mode == 'alias-link':
                cohort['aliases']['/alias']['link'] = ''
            elif mode == 'negative-shape':
                cohort['negative_lookup']['/absent'] = {'state': 'OTHER'}
            else:
                cohort['negative_lookup']['site_top_level_special']['predicate'] = 'other'
            state = self.state()
            with patch.object(PROBE.os, 'scandir') as scan, patch.object(PROBE.os, 'lstat') as endpoint:
                action = (lambda *, cohort=cohort: PROBE.validate_directories(cohort)) if mode in (
                    'directory-keys', 'alias-link') else lambda *, cohort=cohort: PROBE.validate_negative(cohort)
                self.direct_error(state, action, message)
            scan.assert_not_called()
            endpoint.assert_not_called()

    def test_owned_close_status_failures_and_independent_read_close_objects(self):
        for method in ('read', 'hash'):
            self.regular_positive(method)
            state, world = self.state(), FileWorld()
            action = (lambda *, state=state: PROBE.read_bounded(state, '/input', 2)) if method == 'read' else (
                lambda *, state=state: PROBE.file_row(state, '/input'))
            def close(number, *, world=world):
                world.closed.append(number)
                return 1
            with ExitStack() as stack:
                world.install(stack)
                stack.enter_context(patch.object(PROBE.os, 'close', side_effect=close))
                phase = 'read-close' if method == 'read' else 'hash-close'
                self.guarded_error(state, action, phase, 'unexpected SDK descriptor close return')
            self.assertEqual(world.closed, [17])


    def test_fixed_input_limits_kind_size_and_virtual_scope(self):
        for limit in (0, 8388609, True):
            self.regular_positive()
            state = self.state()
            with patch.object(PROBE.os, 'open') as opened:
                self.direct_error(state, lambda *, limit=limit, state=state: PROBE.read_bounded(state, '/input', limit),
                                  'SDK bounded input byte limit')
            opened.assert_not_called()
        state = self.state()
        with patch.object(PROBE.os, 'open') as opened:
            self.direct_error(state, lambda: PROBE.read_bounded(state, '/input', 2, virtual=True),
                              'fixed proc maps virtual-read scope')
        opened.assert_not_called()
        for method in ('read', 'hash'):
            for mode in ('kind', 'size'):
                self.regular_positive(method)
                state, world = self.state(), FileWorld()
                if mode == 'kind':
                    world.before['st_mode'] = 0
                else:
                    world.before['st_size'] = 3 if method == 'read' else 67108865
                with ExitStack() as stack:
                    world.install(stack)
                    action = (lambda *, state=state: PROBE.read_bounded(state, '/input', 2)) if method == 'read' else (
                        lambda *, state=state: PROBE.file_row(state, '/input'))
                    message = 'SDK regular input kind/size bound' if method == 'read' else 'SDK regular file bound'
                    self.guarded_error(state, action, 'read' if method == 'read' else 'hash', message)
                self.assertEqual(world.closed, [17])
                self.assertEqual(world.reads, [])


if __name__ == '__main__':
    unittest.main()

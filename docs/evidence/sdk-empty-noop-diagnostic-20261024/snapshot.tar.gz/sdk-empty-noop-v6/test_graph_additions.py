"""SAVED_UNRUN additive V3 graph oracles; no SDK or acceptance authority."""
import sys
import unittest
from collections.abc import Mapping
from unittest.mock import patch

from test_support import CHECKER, PROBE, Harness
from test_graph_matrix import Collision, Opaque, StringKey, clone_module

PROXY = type(type.__dict__)
ROLE_KEYS = ('pyexpat.errors', 'pyexpat.model', 'pyexpat', 'xml.parsers.expat')


def namespace_view(role, result, backing, exposed):
    """Inject only namespace results; other native routes keep their result."""
    if role not in ('MODULE_NAMESPACE', 'TYPE_NAMESPACE',
                    'SPEC_NAMESPACE', 'LOADER_NAMESPACE'):
        return result
    if not backing:
        backing.append(dict(result))
        exposed.append(PROXY(backing[0]) if role == 'TYPE_NAMESPACE' else backing[0])
    return exposed[0]


class ForeignDict(dict):
    calls = 0

    def items(self):
        ForeignDict.calls += 1
        raise AssertionError('foreign dict items')

    def __len__(self):
        ForeignDict.calls += 1
        raise AssertionError('foreign dict length')


class ForeignMapping(Mapping):
    calls = 0

    def __getitem__(self, key):
        ForeignMapping.calls += 1
        raise AssertionError('foreign mapping get')

    def __iter__(self):
        ForeignMapping.calls += 1
        raise AssertionError('foreign mapping iteration')

    def __len__(self):
        ForeignMapping.calls += 1
        raise AssertionError('foreign mapping length')


class ForeignNamespace:
    calls = 0

    def __getattribute__(self, key):
        ForeignNamespace.calls += 1
        raise AssertionError('foreign namespace getter')

    def __getattr__(self, key):
        ForeignNamespace.calls += 1
        raise AssertionError('foreign namespace fallback')

    def __get__(self, receiver, owner):
        ForeignNamespace.calls += 1
        raise AssertionError('foreign standalone descriptor')

    @property
    def __dict__(self):
        ForeignNamespace.calls += 1
        raise AssertionError('foreign dictionary property')


class GraphAdditions(unittest.TestCase):
    def fresh(self):
        self.live = self.live.fresh() if hasattr(self, 'live') else Harness(self)
        return self.live.positive()

    def initial_roster(self):
        self.fresh()
        self.live = self.live.fresh()
        return self.live

    def captured_error(self, h, action, message, phase):
        initial = h.state.used
        with PROBE.Capture(h.state, 'origin-probe'):
            action()
        self.assertEqual(h.state.used, initial + 1)
        self.assertFalse(h.state.overflow)
        error = h.state.raw[initial]
        self.assertIs(type(error), ValueError)
        self.assertEqual(error.args, (message,))
        self.assertEqual(h.state.phases[initial], phase)
        self.assertEqual(h.state.stage, phase)
        return error

    def graph_error(self, h, message, phase='METADATA', recheck=True):
        return self.captured_error(h, lambda: h.checker.graph(recheck=recheck), message, phase)

    def no_callbacks(self):
        self.assertEqual(Collision.calls, 0)
        self.assertEqual(StringKey.calls, 0)
        self.assertEqual(Opaque.calls, 0)

    def reset_callbacks(self):
        Collision.calls, StringKey.calls, Opaque.calls = 0, 0, 0

    def test_missing_frozen_alias_and_machinery_exports(self):
        for key in ('importlib._bootstrap', 'importlib._bootstrap_external'):
            h = self.fresh()
            before = dict(h.modules)
            del h.modules[key]
            self.graph_error(h, 'derived missing required field', 'RECHECK')
            for other in before:
                if other != key:
                    self.assertIs(h.modules[other], before[other])
        for field in ('ModuleSpec', 'SourceFileLoader', 'ExtensionFileLoader'):
            h = self.fresh()
            module = clone_module(h.modules['importlib.machinery'])
            before = dict(module.__dict__)
            del module.__dict__[field]
            h.modules['importlib.machinery'] = module
            self.graph_error(h, 'derived missing required field', 'RECHECK')
            for other in before:
                if other != field:
                    self.assertIs(module.__dict__[other], before[other])

    def test_independent_registration_joins_retain_all_other_bindings(self):
        keys = ('pyexpat', 'xml.parsers.expat', 'pyexpat.errors', 'pyexpat.model',
                'xml.parsers.expat.errors', 'xml.parsers.expat.model')
        for key in keys:
            for absent in (False, True):
                h = self.fresh()
                before = dict(h.modules)
                if absent:
                    del h.modules[key]
                    expected = 'derived missing required field'
                else:
                    h.modules[key] = type(sys)('replacement')
                    expected = ('derived wrapper child aliases' if key.startswith('xml.parsers.expat.')
                                else 'derived selected first identity changed')
                self.graph_error(h, expected, 'RECHECK')
                for other in before:
                    if other != key:
                        self.assertIs(h.modules[other], before[other])

    def test_module_descriptor_export_guard_precedes_member_first_and_recheck(self):
        for route in ('bind', 'graph', 'recheck', 'census', 'final'):
            h = self.fresh()
            c, r = h.checker, h.checker.refs
            native, getset, member_calls = CHECKER.DerivedChecker.native, r.getset_get_intrinsic, []
            def read(descriptor, receiver, owner, *, getset=getset, r=r):
                result = getset(descriptor, receiver, owner)
                if descriptor is r.type_namespace_descriptor and receiver is r.module_type:
                    result = dict(result)
                    result['__dict__'] = r.type_namespace_descriptor
                    return PROXY(result)
                return result
            def counted(checker, role, descriptor, receiver, owner, name, *, member_calls=member_calls, native=native):
                if role == 'MODULE_NAMESPACE':
                    member_calls.append(receiver)
                return native(checker, role, descriptor, receiver, owner, name)
            actions = {'bind': c.bind_actual_sys, 'graph': c.graph,
                       'recheck': lambda *, c=c: c.graph(recheck=True),
                       'census': c.start_roster, 'final': c.final_roster}
            phase = 'ANCHORS' if route == 'graph' else 'RECHECK'
            c.state.stage = 'RECHECK'
            with patch.object(r, 'getset_get_intrinsic', read), patch.object(
                    CHECKER.DerivedChecker, 'native', counted):
                self.captured_error(h, actions[route], 'derived intrinsic module descriptor export', phase)
            self.assertEqual(member_calls, [])

    def test_all_anchor_intrinsic_exports_refuse_at_exact_first_guard(self):
        exports = CHECKER.DERIVED_EXPORTS + CHECKER.DERIVED_EXTERNAL
        for field, name in exports:
            for intrinsic in ('type', 'object', 'module', 'getset', 'proxy'):
                h = self.fresh()
                r = h.checker.refs
                candidate = {'type': type, 'object': object, 'module': r.module_type,
                             'getset': r.getset_descriptor_type, 'proxy': r.mappingproxy_type}[intrinsic]
                key = '_frozen_importlib' if field in ('ModuleSpec', 'FrozenImporter') else '_frozen_importlib_external'
                alias = 'importlib._bootstrap' if key == '_frozen_importlib' else 'importlib._bootstrap_external'
                provider = clone_module(h.modules[key])
                provider.__dict__[name] = candidate
                h.modules[key], h.modules[alias] = provider, provider
                expected = 'derived anchor intrinsic collision'
                if field in ('ModuleSpec', 'FileLoader'):
                    if intrinsic in ('object', 'getset', 'proxy'):
                        expected = 'derived missing required field'
                    elif intrinsic == 'module':
                        expected = 'derived heap dictionary descriptor kind'
                self.graph_error(h, expected, 'ANCHORS', recheck=False)
                self.assertIs(getattr(r, field), candidate)

    def native_route(self, h, role):
        c, r = h.checker, h.checker.refs
        wrapper = role.endswith('-W')
        p = h.modules['xml.parsers.expat' if wrapper else 'pyexpat']
        if role == 'MODULE':
            return r.module_namespace_descriptor, lambda: c.module_namespace(p), 'ANCHORS'
        if role == 'TYPE':
            return r.type_namespace_descriptor, lambda: c.class_namespace(r.ModuleSpec), 'ANCHORS'
        if role == 'BASES':
            return r.type_bases_descriptor, c.anchor_bases, 'ANCHORS'
        descriptor = r.spec_namespace_descriptor if role.startswith('SPEC') else r.fileloader_namespace_descriptor
        name, path, package, cached = ('xml.parsers.expat', CHECKER.DERIVED_PY, 'xml.parsers', CHECKER.DERIVED_PYC) if wrapper else ('pyexpat', CHECKER.DERIVED_SO, '', None)
        return descriptor, lambda: c.file_module(p, name, path, package, cached, True), 'METADATA'

    def test_actual_native_callers_metadata_output_error_no_fallback(self):
        for role in ('MODULE', 'TYPE', 'BASES', 'SPEC', 'LOADER', 'SPEC-W', 'LOADER-W'):
            for fault in ('owner', 'name', 'output', 'operation'):
                h = self.fresh()
                c, r = h.checker, h.checker.refs
                descriptor, action, phase = self.native_route(h, role)
                getter, member, getset = r.object_getattribute_intrinsic, r.member_get_intrinsic, r.getset_get_intrinsic
                calls, primary = [], OSError('actual primitive result fault')
                def metadata(value, name, *, descriptor=descriptor, fault=fault, getter=getter):
                    result = getter(value, name)
                    if value is descriptor and fault == 'owner' and name == '__objclass__':
                        return object()
                    if value is descriptor and fault == 'name' and name == '__name__':
                        return 'wrong'
                    return result
                def operate(original, value, receiver, owner, *, calls=calls, descriptor=descriptor, fault=fault, primary=primary):
                    result = original(value, receiver, owner)
                    if value is descriptor:
                        calls.append(receiver)
                        if fault == 'operation':
                            raise primary
                        if fault == 'output':
                            return object()
                    return result
                def read_member(value, receiver, owner, *, member=member):
                    return operate(member, value, receiver, owner)
                def read_getset(value, receiver, owner, *, getset=getset):
                    return operate(getset, value, receiver, owner)
                c.state.stage = phase
                with patch.object(r, 'object_getattribute_intrinsic', metadata), patch.object(
                        r, 'member_get_intrinsic', read_member), patch.object(r, 'getset_get_intrinsic', read_getset):
                    if fault == 'operation':
                        with PROBE.Capture(h.state, 'native-' + role):
                            action()
                        self.assertIs(h.state.raw[0], primary)
                        self.assertEqual(h.state.phases[0], 'native-' + role)
                        self.assertEqual(h.state.stage, phase)
                    else:
                        expected = {'owner': 'derived native descriptor owner',
                                    'name': 'derived exact text mismatch',
                                    'output': 'derived native descriptor output'}[fault]
                        self.captured_error(h, action, expected, phase)
                self.assertEqual(len(calls), 0 if fault in ('owner', 'name') else 1)

    def test_heap_descriptor_export_kind_owner_and_recheck_refusal(self):
        for field in ('ModuleSpec', 'FileLoader'):
            for mode in ('kind', 'owner', 'name'):
                h = self.fresh()
                r = h.checker.refs
                selected = getattr(r, field)
                original, native_getter = r.getset_get_intrinsic, r.object_getattribute_intrinsic
                other = r.FileLoader if field == 'ModuleSpec' else r.ModuleSpec
                def read(descriptor, receiver, owner, *, mode=mode, original=original, other=other, r=r, selected=selected):
                    result = original(descriptor, receiver, owner)
                    if descriptor is r.type_namespace_descriptor and receiver is selected and mode != 'name':
                        result = dict(result)
                        result['__dict__'] = object() if mode == 'kind' else other.__dict__['__dict__']
                        return PROXY(result)
                    return result
                held = r.spec_namespace_descriptor if field == 'ModuleSpec' else r.fileloader_namespace_descriptor
                def metadata(value, name, *, held=held, mode=mode, native_getter=native_getter):
                    result = native_getter(value, name)
                    if value is held and name == '__name__' and mode == 'name':
                        return 'wrong'
                    return result
                with patch.object(r, 'getset_get_intrinsic', read), patch.object(
                        r, 'object_getattribute_intrinsic', metadata):
                    self.graph_error(h, 'derived exact text mismatch' if mode == 'name'
                                     else 'derived heap dictionary descriptor ' + mode, 'RECHECK')
                self.assertIs(r.spec_namespace_descriptor if field == 'ModuleSpec'
                              else r.fileloader_namespace_descriptor, held)

    def namespace_target(self, h, target):
        r = h.checker.refs
        table = {'sys': (r.sys_actual, 'modules'), 'boot': (r.bootstrap_module, 'ModuleSpec'),
                 'external': (r.external_module, 'FileLoader'),
                 'machinery': (h.modules['importlib.machinery'], 'ModuleSpec'),
                 'class-module': (r.module_type, '__dict__'),
                 'class-spec': (r.ModuleSpec, '__dict__'), 'class-loader': (r.FileLoader, '__dict__'),
                 'spec-P': (r.S_P, 'name'), 'spec-W': (r.S_W, 'name'),
                 'loader-P': (r.L_P, 'name'), 'loader-W': (r.L_W, 'name'),
                 'role-E': (r.E, '__name__'), 'role-M': (r.M, '__name__'),
                 'generic-module': (r.W, '__file__'), 'generic-spec': (r.S_W, 'origin'),
                 'boot-spec': (r.bootstrap_module.__spec__, 'name'),
                 'external-spec': (r.external_module.__spec__, 'name')}
        return table[target]

    def late_case(self, h, target, kind, replace):
        c = h.checker
        receiver, selected = (None, '_frozen_importlib') if target == 'modules' else self.namespace_target(h, target)
        native, snapshot, field = CHECKER.DerivedChecker.native, CHECKER.DerivedChecker.snapshot, CHECKER.DerivedChecker.field
        backing, exposed, selected_values, mutation, fresh_invalid = [], [], [], [], []
        poison = Collision() if kind == 'object' else StringKey(selected)
        def read(checker, role, descriptor, value, owner, name):
            result = native(checker, role, descriptor, value, owner, name)
            if checker is c and value is receiver:
                return namespace_view(role, result, backing, exposed)
            return result
        def capture(checker, namespace, bound=8192):
            match = checker is c and (namespace is h.modules if target == 'modules'
                                     else bool(exposed) and namespace is exposed[0])
            if match and mutation:
                fresh_invalid.append(True)
            result = snapshot(checker, namespace, bound)
            if match and not mutation:
                values = h.modules if target == 'modules' else backing[0]
                mutation.append(values[selected])
                if replace:
                    del values[selected]
                values[poison] = None
                self.reset_callbacks()
            return result
        def inspect(checker, name, required=True):
            result = field(checker, name, required)
            if checker is c and name == selected and mutation and not fresh_invalid:
                selected_values.append(result[1])
            return result
        with patch.object(CHECKER.DerivedChecker, 'native', read), patch.object(
                CHECKER.DerivedChecker, 'snapshot', capture), patch.object(CHECKER.DerivedChecker, 'field', inspect):
            self.finish_late(h, target, mutation, fresh_invalid, selected_values)
        self.no_callbacks()

    def finish_late(self, h, target, mutation, fresh_invalid, selected_values):
        row = None
        if target.startswith('generic-'):
            row = next(row for row in h.checker.rows[:h.checker.row_count]
                       if row['_module'] is h.checker.refs.W)
            row['_checked'] = False
            def action():
                return h.checker.inspect_row(row, lambda value: value, lambda value: True)
        else:
            def action():
                return h.checker.graph(recheck=True)
        initial = h.state.used
        with PROBE.Capture(h.state, 'origin-probe'):
            action()
        if h.state.used == initial:
            self.assertTrue(mutation)
            if row is not None:
                row['_checked'] = False
            with PROBE.Capture(h.state, 'origin-probe'):
                action()
        self.assertEqual(h.state.used, initial + 1)
        error = h.state.raw[initial]
        self.assertIs(type(error), ValueError)
        self.assertEqual(error.args, ('derived exact text prelength',))
        self.assertEqual(h.state.phases[initial], 'KEYS')
        self.assertEqual(h.state.stage, 'KEYS')
        self.assertTrue(fresh_invalid)
        self.assertTrue(mutation)
        self.assertTrue(selected_values)
        self.assertIs(selected_values[0], mutation[0])

    def test_namespace_injector_preserves_bases_after_matching_class_namespace(self):
        native_bases = type.__dict__['__bases__'].__get__(str, type)
        original_namespace = type.__dict__['__dict__'].__get__(str, type)
        backing, exposed = [], []
        self.assertIs(namespace_view('TYPE_BASES', native_bases, backing, exposed), native_bases)
        self.assertEqual((backing, exposed), ([], []))
        held = namespace_view('TYPE_NAMESPACE', original_namespace, backing, exposed)
        self.assertIs(type(held), PROXY)
        self.assertIs(namespace_view('TYPE_BASES', native_bases, backing, exposed), native_bases)
        self.assertIs(exposed[0], held)
        self.assertEqual(len(backing), 1)
        self.assertEqual(len(exposed), 1)

    def test_persistent_late_insert_replace_both_keys_every_frontier(self):
        targets = ('sys', 'modules', 'boot', 'external', 'machinery', 'class-module',
                   'class-spec', 'class-loader', 'spec-P', 'spec-W', 'loader-P',
                   'loader-W', 'role-E', 'role-M', 'generic-module', 'generic-spec',
                   'boot-spec', 'external-spec')
        for target in targets:
            for kind in ('object', 'str-subclass'):
                for replace in (False, True):
                    with self.subTest(target=target, kind=kind, replace=replace):
                        self.late_case(self.fresh(), target, kind, replace)

    def test_generic_spec_collision_both_keys_before_origin_callbacks(self):
        for kind in ('object', 'str-subclass'):
            h = self.fresh()
            row = next(row for row in h.checker.rows[:h.checker.row_count]
                       if row['_module'] is h.checker.refs.W)
            namespace = h.checker.refs.S_W.__dict__
            namespace[Collision() if kind == 'object' else StringKey('origin')] = None
            row['_checked'] = False
            self.reset_callbacks()
            self.captured_error(h, lambda *, h=h, row=row: h.checker.inspect_row(row, lambda value: value, lambda value: True),
                    'derived exact text prelength', 'KEYS')
            self.no_callbacks()

    def test_namespace_exact_kind_refuses_without_foreign_dispatch(self):
        for value in (ForeignDict(), ForeignMapping(), ForeignNamespace()):
            h = self.fresh()
            ForeignDict.calls, ForeignMapping.calls, ForeignNamespace.calls = 0, 0, 0
            self.captured_error(h, lambda *, h=h, value=value: h.checker.snapshot(value), 'derived native namespace type', 'KEYS')
            self.assertEqual((ForeignDict.calls, ForeignMapping.calls, ForeignNamespace.calls), (0, 0, 0))

    def spec_bad_values(self, field):
        if field in ('name', 'origin', '_cached'):
            return (Opaque(), StringKey('wrong'))
        if field == 'loader':
            return (Opaque(), StringKey('wrong'))
        if field in ('loader_state', 'submodule_search_locations'):
            return (Opaque(), [], {}, lambda: None, len, StringKey('wrong'))
        if field == '_uninitialized_submodules':
            return (Opaque(), (), StringKey('wrong'), [None])
        return (Opaque(), 0, 1, None, StringKey('wrong'))

    def test_each_file_spec_scalar_wrong_exact_type_and_subclass(self):
        for key in ('pyexpat', 'xml.parsers.expat'):
            for field in CHECKER.DERIVED_SPEC_KEYS:
                for value in self.spec_bad_values(field):
                    h = self.fresh()
                    h.modules[key].__spec__.__dict__[field] = value
                    if field in ('name', 'origin'):
                        expected = 'derived exact text prelength'
                    elif field == '_cached':
                        expected = ('derived producer spec cache' if key == 'pyexpat'
                                    else 'derived exact text prelength')
                    elif field == 'loader':
                        expected = 'derived spec loader identity'
                    elif field in ('loader_state', 'submodule_search_locations'):
                        expected = 'derived spec required None'
                    elif field == '_uninitialized_submodules':
                        expected = 'derived spec empty list'
                    else:
                        expected = 'derived exact spec booleans'
                    self.reset_callbacks()
                    self.graph_error(h, expected)
                    self.no_callbacks()

    def test_bootstrap_opaque_callable_mutable_values_not_interpreted(self):
        for key in ('_frozen_importlib', '_frozen_importlib_external'):
            for field in ('loader_state', 'submodule_search_locations'):
                for value in (Opaque(), [], {}, lambda: None, len):
                    h = self.fresh()
                    provider = h.modules[key]
                    original = CHECKER.DerivedChecker.native
                    namespace = dict(provider.__spec__.__dict__)
                    namespace[field] = value
                    def read(checker, role, descriptor, receiver, owner, name, *, namespace=namespace, original=original, provider=provider):
                        result = original(checker, role, descriptor, receiver, owner, name)
                        return namespace if receiver is provider.__spec__ else result
                    self.reset_callbacks()
                    with patch.object(CHECKER.DerivedChecker, 'native', read):
                        h.checker.graph(recheck=True)
                    self.no_callbacks()

    def test_generic_origin_wrong_exact_type_never_invokes_callbacks(self):
        for value in (Opaque(), StringKey('frozen'), [], {}, lambda: None):
            h = self.fresh()
            module = type(sys)('generic-fixture')
            module.__spec__ = h.checker.refs.ModuleSpec('generic-fixture', None, origin=value)
            row = {'name': 'generic-fixture', '_module': module, '_checked': False, 'origin': None}
            self.reset_callbacks()
            self.captured_error(h, lambda *, h=h, row=row: h.checker.inspect_row(row, lambda path: path, lambda path: True),
                    'derived exact text prelength', h.state.stage)
            self.no_callbacks()

    def test_every_doc_absence_optional_exact_strings_and_late_metadata(self):
        for key in ROLE_KEYS:
            h = self.fresh()
            del h.modules[key].__dict__['__doc__']
            self.graph_error(h, 'derived missing required field')
        for key in ('pyexpat.errors', 'pyexpat.model', 'pyexpat'):
            for field in ('__file__', '__cached__'):
                if key == 'pyexpat' and field == '__file__':
                    continue
                h = self.fresh()
                h.modules[key].__dict__[field] = '/exact/string'
                self.graph_error(h, 'derived optional None field')
        for key, field in (('pyexpat', '__file__'), ('xml.parsers.expat', '__package__'),
                           ('pyexpat.errors', '__name__'), ('pyexpat.model', '__name__')):
            h = self.fresh()
            h.modules[key].__dict__[field] = 'late-change'
            self.graph_error(h, 'derived exact text mismatch')

    def text_targets(self, h):
        result = []
        for key in ROLE_KEYS:
            result.append((h.modules[key].__dict__, '__name__', 256, 1024))
            result.append((h.modules[key].__dict__, '__doc__', 65536, 65536))
        for key in ('pyexpat', 'xml.parsers.expat'):
            module = h.modules[key]
            result.extend(((module.__dict__, '__package__', 256, 1024),
                           (module.__dict__, '__file__', 4096, 4096),
                           (module.__spec__.__dict__, 'name', 256, 1024),
                           (module.__spec__.__dict__, 'origin', 4096, 4096),
                           (module.__loader__.__dict__, 'name', 256, 1024),
                           (module.__loader__.__dict__, 'path', 4096, 4096)))
        wrapper = h.modules['xml.parsers.expat']
        result.extend(((wrapper.__dict__, '__cached__', 4096, 4096),
                       (wrapper.__spec__.__dict__, '_cached', 4096, 4096)))
        return result

    def test_every_governed_metadata_prelength_byte_and_surrogate_frontier(self):
        count = len(self.text_targets(self.fresh()))
        for position in range(count):
            for mode in ('prelength', 'utf8', 'surrogate'):
                h = self.fresh()
                namespace, field, points, byte_limit = self.text_targets(h)[position]
                if mode == 'prelength':
                    value, expected = 'x' * (points + 1), 'derived exact text prelength'
                elif mode == 'utf8':
                    # Name256 * UTF8max4 ==1024: byte excess cannot fit its codepoint bound.
                    if points == 256:
                        continue
                    value, expected = '\U00010000' * (byte_limit // 4 + 1), 'derived UTF8 byte bound'
                else:
                    value, expected = '\ud800', None
                namespace[field] = value
                before = h.state.read_bytes
                if mode == 'surrogate':
                    with self.assertRaises(UnicodeEncodeError) as caught:
                        h.checker.graph(recheck=True)
                    self.assertEqual(caught.exception.object, value)
                    self.assertEqual(h.state.stage, 'METADATA')
                else:
                    original, observations = CHECKER.DerivedChecker.text, []
                    def text(checker, candidate, points=256, byte_limit=1024, empty=True, *, observations=observations, original=original, value=value):
                        previous = checker.state.read_bytes
                        try:
                            return original(checker, candidate, points, byte_limit, empty)
                        finally:
                            if candidate is value:
                                observations.append((points, byte_limit, previous, checker.state.read_bytes))
                    with patch.object(CHECKER.DerivedChecker, 'text', text):
                        self.graph_error(h, expected)
                    self.assertEqual(len(observations), 1)
                    self.assertEqual(observations[0][:2], (points, byte_limit))
                    if mode == 'prelength':
                        self.assertEqual(observations[0][2], observations[0][3])
                self.assertGreaterEqual(h.state.read_bytes, before)

    def test_text_repeated_charge_chunk_bound_and_exact_boundaries(self):
        h = self.fresh()
        c = h.checker
        c.text('x' * 256)
        c.text('\U00010000' * 256)
        for value, points, byte_limit in (('x' * 4096, 4096, 4096),
                                           ('x' * 65536, 65536, 65536)):
            c.text(value, points, byte_limit)
        c.state.read_bytes = 536870912 - 8
        c.text('ab')
        self.assertEqual(c.state.read_bytes, 536870912)
        self.captured_error(h, lambda: c.text('ab'), 'derived aggregate text budget', h.state.stage)
        self.assertEqual(c.state.read_bytes, 536870912)
        h = self.fresh()
        c = h.checker
        calls, clock = [], CHECKER.time.monotonic_ns
        def tick():
            calls.append(True)
            return clock()
        with patch.object(CHECKER.time, 'monotonic_ns', tick):
            c.text('x' * 2049, 4096, 4096)
        self.assertEqual(len(calls), 7)

    def test_checker_work_entry_and_mid_operation_expiry(self):
        for late in (False, True):
            h = self.fresh()
            with patch.object(CHECKER.time, 'monotonic_ns',
                              side_effect=[0, 1] if late else [1]):
                with self.assertRaises(TimeoutError) as caught:
                    h.checker.graph(recheck=True)
            self.assertEqual(caught.exception.args, ('derived original work deadline',))
            self.assertEqual(h.state.stage, 'RECHECK')
            self.assertEqual(h.state.used, 0)

    def test_namespace_limits_full_capacity_eof_and_excess(self):
        for bound in (256, 8192):
            h = self.fresh()
            namespace = {'field' + str(index): None for index in range(bound)}
            h.checker.snapshot(namespace, bound)
            self.assertEqual(h.checker.count, bound)
            namespace['excess'] = None
            self.captured_error(h, lambda *, bound=bound, h=h, namespace=namespace: h.checker.snapshot(namespace, bound),
                    'derived namespace count bound', 'KEYS')
        for bound in (-1, 8193, True):
            h = self.fresh()
            self.captured_error(h, lambda *, bound=bound, h=h: h.checker.snapshot({}, bound), 'derived exact namespace limit', 'KEYS')

    def test_snapshot_duplicate_initial_and_final_pairs(self):
        for final in (False, True):
            h = self.fresh() if final else self.initial_roster()
            c, original, pending = h.checker, next, []
            native = CHECKER.DerivedChecker.snapshot
            def capture(checker, namespace, bound=8192, *, c=c, h=h, native=native, pending=pending):
                if checker is c and namespace is h.modules:
                    pending.append(True)
                return native(checker, namespace, bound)
            seen = []
            def advance(iterator, default=None, *, original=original, pending=pending, seen=seen):
                pair = original(iterator, default)
                if pending and pair is not None:
                    if not seen:
                        seen.append(pair)
                    elif len(seen) == 1:
                        seen.append(pair)
                        return seen[0]
                return pair
            with patch.object(CHECKER.DerivedChecker, 'snapshot', capture), patch.object(
                    CHECKER, 'next', advance, create=True):
                if final:
                    self.captured_error(h, c.final_roster, 'CENSUS_COVERAGE', 'RECHECK')
                else:
                    self.captured_error(h, c.start_roster, 'CENSUS_COVERAGE', 'METADATA')

    def test_roster_duplicate_visit_skipped_and_same_count_replacement(self):
        for mode in ('duplicate-visit', 'skipped', 'delete-insert'):
            h = self.fresh()
            c = h.checker
            if mode == 'duplicate-visit':
                row = c.rows[0]
                self.captured_error(h, lambda *, c=c, row=row: c.inspect_row(row, lambda path: path, lambda path: True),
                        'CENSUS_VISIT', h.state.stage)
            elif mode == 'skipped':
                c.rows[0]['_checked'] = False
                self.captured_error(h, c.final_roster, 'CENSUS_VISIT', 'RECHECK')
            else:
                h.modules['replacement'] = h.modules.pop('xml.parsers.expat')
                self.captured_error(h, c.final_roster, 'CENSUS_COVERAGE', 'RECHECK')

    def test_snapshot_count_mutation_and_partial_capture_exact_raw_cleanup(self):
        for mode in ('length', 'count', 'partial-capture'):
            h = self.fresh()
            c, original, calls = h.checker, next, []
            namespace = {'first': object(), 'second': object()}
            primary, secondary = OSError('partial roster iterator'), OSError('independent cleanup')
            def advance(iterator, default=None, *, calls=calls, mode=mode, namespace=namespace, original=original, primary=primary):
                pair = original(iterator, default)
                calls.append(True)
                if mode == 'length' and len(calls) == 1:
                    namespace['late'] = None
                    # Do not resume the invalidated native iterator: native next raises on mutation.
                if mode == 'count' and len(calls) == 2:
                    return None
                if mode == 'partial-capture' and len(calls) == 2:
                    raise primary
                return pair
            with patch.object(CHECKER, 'next', advance, create=True):
                with PROBE.Capture(h.state, 'capture-' + mode):
                    c.snapshot(namespace)
            self.assertEqual(h.state.phases[0], 'capture-' + mode)
            if mode == 'partial-capture':
                self.assertIs(h.state.raw[0], primary)
            elif mode == 'count':
                self.assertEqual(h.state.raw[0].args, ('derived namespace changed during capture',))
            else:
                self.assertIs(type(h.state.raw[0]), RuntimeError)
                self.assertEqual(h.state.raw[0].args, ('dictionary changed size during iteration',))
            original_retire = CHECKER.retire_reference_cell
            attempts = []
            def retire(array, index, *, attempts=attempts, c=c, original_retire=original_retire, secondary=secondary):
                attempts.append(index)
                if array is c.keys and index == 0:
                    raise secondary
                return original_retire(array, index)
            with patch.object(CHECKER, 'retire_reference_cell', retire):
                c.clear_scratch()
            self.assertEqual(len(attempts), 16384)
            self.assertIs(h.state.raw[1], secondary)
            self.assertEqual(h.state.phases[1], 'scratch-clear')


    def test_foreign_namespace_outputs_at_every_actual_native_caller(self):
        for role in ('MODULE', 'TYPE', 'BASES', 'SPEC', 'LOADER', 'SPEC-W', 'LOADER-W'):
            for value in (ForeignDict(), ForeignMapping(), ForeignNamespace()):
                h = self.fresh()
                c, r = h.checker, h.checker.refs
                descriptor, action, phase = self.native_route(h, role)
                field = 'member_get_intrinsic' if role == 'MODULE' else 'getset_get_intrinsic'
                original = getattr(r, field)
                calls = []
                def read(selected, receiver, owner, *, calls=calls, descriptor=descriptor, original=original, value=value):
                    result = original(selected, receiver, owner)
                    if selected is descriptor:
                        calls.append(True)
                        return value
                    return result
                ForeignDict.calls, ForeignMapping.calls, ForeignNamespace.calls = 0, 0, 0
                c.state.stage = phase
                with patch.object(r, field, read):
                    self.captured_error(h, action, 'derived native descriptor output', phase)
                self.assertEqual(len(calls), 1)
                self.assertEqual((ForeignDict.calls, ForeignMapping.calls, ForeignNamespace.calls), (0, 0, 0))

    def test_actual_partial_roster_install_and_later_retirement_after_fault(self):
        h = self.initial_roster()
        c = h.checker
        primary, secondary = OSError('owned row install'), OSError('first row retirement')
        class FaultRow(dict):
            def __setitem__(self, name, value):
                raise primary
        c.rows[1] = FaultRow(name=None, origin=None, _module=None, _checked=False)
        with PROBE.Capture(h.state, 'partial-roster-install'):
            c.start_roster()
        self.assertIs(h.state.raw[0], primary)
        self.assertEqual(h.state.phases[0], 'partial-roster-install')
        self.assertEqual(c.row_count, 1)
        self.assertIs(c.rows[0]['_module'], h.modules[c.rows[0]['name']])
        self.assertEqual(h.state.stage, 'METADATA')
        c.rows[2]['_module'] = h.modules['pyexpat']
        first, later = c.rows[0], c.rows[2]
        attempts, original = [], CHECKER.retire_roster_module
        def retire(row):
            attempts.append(row)
            if row is first:
                raise secondary
            return original(row)
        with patch.object(CHECKER, 'retire_roster_module', retire):
            c.clear()
        self.assertEqual(len(attempts), 8192)
        self.assertIs(h.state.raw[1], secondary)
        self.assertEqual(h.state.phases[1], 'roster-reference-clear')
        self.assertIsNone(later['_module'])

    def test_graph_iterator_raw_error_then_independent_scratch_cleanup(self):
        h = self.fresh()
        c, original, count = h.checker, next, []
        primary, secondary = OSError('graph native iterator'), OSError('graph scratch clear')
        def advance(iterator, default=None):
            count.append(True)
            if len(count) == 2:
                raise primary
            return original(iterator, default)
        with patch.object(CHECKER, 'next', advance, create=True):
            with PROBE.Capture(h.state, 'origin-probe'):
                c.graph(recheck=True)
        self.assertIs(h.state.raw[0], primary)
        self.assertEqual(h.state.phases[0], 'KEYS')
        original_retire, attempts = CHECKER.retire_reference_cell, []
        def retire(array, index):
            attempts.append(index)
            if array is c.keys and index == 0:
                raise secondary
            return original_retire(array, index)
        with patch.object(CHECKER, 'retire_reference_cell', retire):
            c.clear_scratch()
        self.assertEqual(len(attempts), 16384)
        self.assertIs(h.state.raw[1], secondary)
        self.assertEqual(h.state.phases[1], 'scratch-clear')

    def test_missing_eof_input_refuses_exact_excess_without_overcapture(self):
        h = self.fresh()
        c = h.checker
        progression, used = [None] * 8193, [0]
        def advance(iterator, default=None):
            if used[0] >= 8193:
                raise AssertionError('bounded nonEOF fixture exhausted')
            progression[used[0]] = c.count
            used[0] += 1
            return ('field', None)
        with patch.object(CHECKER, 'next', advance, create=True):
            error = self.captured_error(h, lambda: c.snapshot({'field': None}),
                    'derived namespace excess before capture', 'KEYS')
        self.assertIs(error, h.state.raw[0])
        self.assertEqual(used[0], 8193)
        self.assertEqual(progression, list(range(8193)))
        self.assertEqual(c.count, 8192)
        self.assertEqual((len(c.keys), len(c.values)), (8192, 8192))
        self.assertEqual((c.keys[0], c.keys[8191]), ('field', 'field'))
        self.assertIsNone(c.pair)
        self.assertIsNone(c.current_key)
        self.assertIsNone(c.current_value)


    def test_actual_caller_descriptor_argument_kind_before_operation(self):
        for role in ('MODULE', 'TYPE', 'BASES', 'SPEC', 'LOADER', 'SPEC-W', 'LOADER-W'):
            h = self.fresh()
            c, r = h.checker, h.checker.refs
            descriptor, action, phase = self.native_route(h, role)
            native = CHECKER.DerivedChecker.native
            member, getset, calls = r.member_get_intrinsic, r.getset_get_intrinsic, []
            malformed = object()
            def routed(checker, operation, selected, receiver, owner, name, *, descriptor=descriptor, malformed=malformed, native=native):
                return native(checker, operation, malformed if selected is descriptor else selected,
                              receiver, owner, name)
            def read_member(selected, receiver, owner, *, calls=calls, malformed=malformed, member=member):
                if selected is malformed:
                    calls.append(True)
                return member(selected, receiver, owner)
            def read_getset(selected, receiver, owner, *, calls=calls, getset=getset, malformed=malformed):
                if selected is malformed:
                    calls.append(True)
                return getset(selected, receiver, owner)
            c.state.stage = phase
            with patch.object(CHECKER.DerivedChecker, 'native', routed), patch.object(
                    r, 'member_get_intrinsic', read_member), patch.object(r, 'getset_get_intrinsic', read_getset):
                self.captured_error(h, action, 'derived native descriptor kind', phase)
            self.assertEqual(calls, [])

    def test_bootstrap_every_governed_scalar_wrong_exact_type_and_subclass(self):
        fields = ('name', 'origin', 'loader', '_cached', '_set_fileattr',
                  '_uninitialized_submodules', '_initializing')
        for key in ('_frozen_importlib', '_frozen_importlib_external'):
            for field in fields:
                for value in self.spec_bad_values(field):
                    h = self.fresh()
                    provider = h.modules[key]
                    namespace = dict(provider.__spec__.__dict__)
                    namespace[field] = value
                    native = CHECKER.DerivedChecker.native
                    def read(checker, role, descriptor, receiver, owner, name, *, namespace=namespace, native=native, provider=provider):
                        result = native(checker, role, descriptor, receiver, owner, name)
                        return namespace if receiver is provider.__spec__ else result
                    if field in ('name', 'origin'):
                        expected = 'derived exact text prelength'
                    elif field == 'loader':
                        expected = 'derived bootstrap loader identity'
                    elif field in ('_cached', '_set_fileattr'):
                        expected = 'derived bootstrap cache/location'
                    elif field == '_uninitialized_submodules':
                        expected = 'derived bootstrap empty list'
                    else:
                        expected = 'derived bootstrap initialization'
                    self.reset_callbacks()
                    with patch.object(CHECKER.DerivedChecker, 'native', read):
                        self.graph_error(h, expected, 'RECHECK')
                    self.no_callbacks()


    def test_custom_descriptor_property_getattr_every_metadata_caller(self):
        names = ('module', 'class', 'bases', 'spec', 'loader', 'role', 'file', 'generic')
        for name in names:
            h = self.fresh()
            c, r = h.checker, h.checker.refs
            candidate = ForeignNamespace()
            actions = {'module': lambda *, c=c, candidate=candidate: c.module_namespace(candidate),
                       'class': lambda *, c=c, candidate=candidate: c.class_namespace(candidate),
                       'bases': lambda *, c=c, candidate=candidate: c.bases(candidate),
                       'spec': lambda *, c=c, candidate=candidate: c.spec_namespace(candidate),
                       'loader': lambda *, c=c, candidate=candidate, r=r: c.loader(candidate, r.ExtensionFileLoader, 'pyexpat', CHECKER.DERIVED_SO),
                       'role': lambda *, c=c, candidate=candidate: c.role(candidate, 'pyexpat.errors'),
                       'file': lambda *, c=c, candidate=candidate: c.file_module(candidate, 'pyexpat', CHECKER.DERIVED_SO, '', None, True),
                       'generic': lambda *, c=c, candidate=candidate: c.generic_fields(candidate)}
            expected = {'class': 'derived exact class receiver', 'bases': 'derived exact class receiver',
                        'spec': 'derived exact spec receiver', 'loader': 'derived exact loader type'}.get(
                            name, 'derived exact module receiver')
            phase = 'ANCHORS' if name in ('module', 'class', 'bases') else 'METADATA'
            c.state.stage = phase
            ForeignNamespace.calls = 0
            self.captured_error(h, actions[name], expected, phase)
            self.assertEqual(ForeignNamespace.calls, 0)


    def test_each_metadata_field_work_expiry_at_actual_text_operation(self):
        count = len(self.text_targets(self.fresh()))
        for position in range(count):
            h = self.fresh()
            c = h.checker
            namespace, field, points, byte_limit = self.text_targets(h)[position]
            if field == '__doc__':
                namespace[field] = 'bounded documentation fixture'
            value = namespace[field]
            c.graph(recheck=True)
            snapshot, text = CHECKER.DerivedChecker.snapshot, CHECKER.DerivedChecker.text
            armed, reached = [], []
            def capture(checker, actual, bound=8192, *, armed=armed, c=c, namespace=namespace, snapshot=snapshot):
                result = snapshot(checker, actual, bound)
                if checker is c and actual is namespace:
                    armed.append(True)
                return result
            def inspect(checker, candidate, point_cap=256, byte_cap=1024, empty=True, *, armed=armed, c=c, h=h, reached=reached, text=text, value=value):
                if checker is c and armed and candidate is value and checker.state.stage == 'METADATA':
                    reached.append((point_cap, byte_cap))
                    with patch.object(CHECKER.time, 'monotonic_ns', return_value=h.state.work):
                        return text(checker, candidate, point_cap, byte_cap, empty)
                return text(checker, candidate, point_cap, byte_cap, empty)
            with patch.object(CHECKER.DerivedChecker, 'snapshot', capture), patch.object(
                    CHECKER.DerivedChecker, 'text', inspect):
                with PROBE.Capture(h.state, 'origin-probe'):
                    c.graph(recheck=True)
            self.assertEqual(reached, [(points, byte_limit)])
            self.assertEqual(h.state.used, 1)
            self.assertIs(type(h.state.raw[0]), TimeoutError)
            self.assertEqual(h.state.raw[0].args, ('derived original work deadline',))
            self.assertEqual(h.state.phases[0], 'METADATA')
            self.assertEqual(h.state.stage, 'METADATA')


if __name__ == '__main__':
    unittest.main()

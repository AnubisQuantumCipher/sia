"""SAVED_UNRUN precise name prelength, partial pairs and type-tag callbacks."""
import unittest
from unittest.mock import patch

from test_support import CHECKER, PROBE, Harness


class TypeMeta(type):
    calls = 0

    def __eq__(cls, other):
        TypeMeta.calls += 1
        raise AssertionError('candidate type equality')

    def __hash__(cls):
        TypeMeta.calls += 1
        raise AssertionError('candidate type hash')


class MetaError(Exception, metaclass=TypeMeta):
    pass


class SnapshotAndNames(unittest.TestCase):
    def test_actual_graph_name257_refuses_before_that_value_encoding_or_charge(self):
        h = Harness(self).positive()
        bad = 'x' * 257
        h.modules['pyexpat.errors'].__dict__['__name__'] = bad
        original, observed = CHECKER.DerivedChecker.text, []
        def text(checker, value, points=256, byte_limit=1024, empty=True):
            if value is bad:
                before = checker.state.read_bytes
                try:
                    return original(checker, value, points, byte_limit, empty)
                finally:
                    observed.append((points, byte_limit, before, checker.state.read_bytes))
            return original(checker, value, points, byte_limit, empty)
        with patch.object(CHECKER.DerivedChecker, 'text', text):
            h.error(h.checker.graph, 'derived exact text prelength', 'METADATA')
        self.assertEqual(len(observed), 1)
        self.assertEqual(observed[0][:2], (256, 1024))
        self.assertEqual(observed[0][2], observed[0][3])

    def test_partial_pair_and_exact_iterator_fault_keeps_raw_and_independent_clearing(self):
        h = Harness(self).positive()
        primary, secondary = OSError('native next'), OSError('scratch retirement')
        original_next, calls = next, [0]
        def advance(iterator, default=None):
            calls[0] += 1
            if calls[0] == 2:
                raise primary
            return original_next(iterator, default)
        with patch.object(CHECKER, 'next', advance, create=True):
            with PROBE.Capture(h.state, 'partial-snapshot'):
                h.checker.snapshot({'first': object(), 'second': object()})
        self.assertIs(h.state.raw[0], primary)
        self.assertEqual(h.state.phases[0], 'partial-snapshot')
        self.assertEqual(h.checker.count, 1)
        self.assertIsNone(h.checker.pair)
        self.assertIsNone(h.checker.current_key)
        self.assertIsNone(h.checker.current_value)
        attempts, original_retire = [], CHECKER.retire_reference_cell
        def retire(array, index):
            attempts.append((array is h.checker.keys, index))
            if array is h.checker.keys and index == 0:
                raise secondary
            return original_retire(array, index)
        with patch.object(CHECKER, 'retire_reference_cell', retire):
            h.checker.clear_scratch()
        self.assertEqual(len(attempts), 16384)
        self.assertIs(h.state.raw[1], secondary)
        self.assertEqual(h.state.phases[1], 'scratch-clear')
        self.assertTrue(all(value is None for value in h.checker.values))

    def test_pair_shape_type_and_missing_eof_exact_phase_after_positive(self):
        for pair in ([], ('one',), ('one', 'two', 'three')):
            h = Harness(self).positive()
            with patch.object(CHECKER, 'next', return_value=pair, create=True):
                h.error(lambda *, h=h: h.checker.snapshot({'field': None}),
                        'derived native pair shape', 'KEYS')
            self.assertIsNone(h.checker.pair)
        h = Harness(self).positive()
        with patch.object(CHECKER, 'next', return_value=('field', None), create=True):
            h.error(lambda: h.checker.snapshot({'field': None}),
                    'derived namespace excess before capture', 'KEYS')

    def test_exact_class_tag_identity_no_metaclass_hash_or_equality(self):
        self.assertEqual(PROBE.error_class_tag(OSError('positive')), 'OSError')
        error = MetaError('unadmitted')
        TypeMeta.calls = 0
        self.assertIsNone(PROBE.error_class_tag(error))
        self.assertEqual(TypeMeta.calls, 0)


if __name__ == '__main__':
    unittest.main()

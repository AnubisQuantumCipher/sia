"""SAVED_UNRUN caller-level native diagnostic role/resource controls."""
import unittest
from unittest.mock import patch

from test_support import PROBE, zero_clock


ROUTES = ('args_descriptor', 'dict_descriptor', 'cause_descriptor',
          'context_descriptor', 'mro_descriptor')
NAMES = ('args', '__dict__', '__cause__', '__context__', '__mro__')


class DiagnosticFixture(unittest.TestCase):
    def setUp(self):
        self.clock = patch.object(PROBE.time, 'monotonic_ns', zero_clock)
        self.clock.start()
        self.addCleanup(self.clock.stop)

    def ready(self):
        state = PROBE.ProbeState()
        state.work, state.total = 1, 5000000001
        checker = PROBE.build_checker(state)
        self.addCleanup(checker.clear)
        PROBE.prepare_diagnostics(state, checker)
        self.addCleanup(PROBE.clear_diagnostics, state,
                        PROBE.Capture(state, 'diagnostic-reference-clear'))
        return state, state.capsule

    def call(self, state, capsule, index, error):
        if index == 4:
            return capsule.receiver(state, error)
        descriptor = getattr(capsule, ROUTES[index])
        expected = tuple if index == 0 else dict if index == 1 else None
        return capsule.read(state, descriptor, error, NAMES[index], expected)

    def positive(self, index):
        state, capsule = self.ready()
        error = OSError('positive')
        if index == 2:
            error.__cause__ = ValueError('actual direct cause')
        elif index == 3:
            error.__context__ = ValueError('actual direct context')
        result = self.call(state, capsule, index, error)
        if index == 0:
            self.assertEqual(result, ('positive',))
        elif index == 1:
            self.assertEqual(result, {})
        elif index == 2:
            self.assertIs(result, error.__cause__)
        elif index == 3:
            self.assertIs(result, error.__context__)
        else:
            self.assertIsNone(result)
        self.assertEqual(state.used, 0)
        return state, capsule, error

    def raw(self, state, action, kind, message=None, actual=None):
        with PROBE.Capture(state, 'diagnostics'):
            action()
        self.assertEqual(state.used, 1)
        self.assertEqual(state.phases[0], 'diagnostics')
        self.assertIs(type(state.raw[0]), kind)
        if actual is not None:
            self.assertIs(state.raw[0], actual)
        if message is not None:
            self.assertEqual(state.raw[0].args, (message,))

    def test_all_five_kind_owner_name_through_actual_selected_descriptor(self):
        for index in range(5):
            for mode in ('kind', 'owner', 'name'):
                state, capsule, error = self.positive(index)
                field = ROUTES[index]
                actual_get, calls = capsule.get, []
                def get(descriptor, receiver, owner, *, actual_get=actual_get, calls=calls):
                    calls.append(descriptor)
                    return actual_get(descriptor, receiver, owner)
                capsule.get = get
                if mode == 'kind':
                    bad = object()
                    message = 'diagnostic exact native descriptor kind'
                elif mode == 'owner':
                    bad = type.__dict__['__mro__'] if index != 4 else BaseException.__dict__['args']
                    message = 'diagnostic exact native descriptor owner'
                else:
                    bad = BaseException.__dict__['__dict__'] if index != 4 else type.__dict__['__dict__']
                    if index == 1:
                        bad = BaseException.__dict__['args']
                    message = 'diagnostic exact native descriptor name'
                setattr(capsule, field, bad)
                self.raw(state, lambda *, capsule=capsule, error=error, index=index, state=state: self.call(state, capsule, index, error), ValueError, message)
                self.assertEqual(calls, [])

    def test_every_native_operation_error_actual_identity_and_no_fallback(self):
        for index in range(5):
            state, capsule, error = self.positive(index)
            descriptor, actual_get = getattr(capsule, ROUTES[index]), capsule.get
            primary, target_calls = OSError('native actual failure'), []
            def get(selected, receiver, owner, *, actual_get=actual_get, descriptor=descriptor, primary=primary, target_calls=target_calls):
                result = actual_get(selected, receiver, owner)
                if selected is descriptor:
                    target_calls.append(True)
                    raise primary
                return result
            capsule.get = get
            self.raw(state, lambda *, capsule=capsule, error=error, index=index, state=state: self.call(state, capsule, index, error), OSError, actual=primary)
            self.assertEqual(target_calls, [True])

    def test_every_native_output_or_link_receiver_refuses_after_actual_operation(self):
        for index in range(5):
            state, capsule, error = self.positive(index)
            descriptor, actual_get = getattr(capsule, ROUTES[index]), capsule.get
            target_calls = []
            def get(selected, receiver, owner, *, actual_get=actual_get, descriptor=descriptor, index=index, target_calls=target_calls):
                result = actual_get(selected, receiver, owner)
                if selected is descriptor:
                    target_calls.append(True)
                    return object() if index != 4 else []
                return result
            capsule.get = get
            message = ('diagnostic native descriptor output' if index < 2 else
                       'diagnostic native MRO output' if index == 4 else
                       'diagnostic native exception receiver')
            self.raw(state, lambda *, capsule=capsule, error=error, index=index, state=state: self.call(state, capsule, index, error), ValueError, message)
            self.assertEqual(target_calls, [True])

    def test_mro_empty_oversize_nonexception_and_each_native_metadata_fault(self):
        for output, message in (((), 'diagnostic native MRO output'),
                                ((object,) * 8193, 'diagnostic native MRO output'),
                                ((object,), 'diagnostic native exception receiver')):
            state, capsule, error = self.positive(4)
            actual_get = capsule.get
            def get(descriptor, receiver, owner, *, actual_get=actual_get, capsule=capsule, output=output):
                result = actual_get(descriptor, receiver, owner)
                return output if descriptor is capsule.mro_descriptor else result
            capsule.get = get
            self.raw(state, lambda *, capsule=capsule, error=error, state=state: capsule.receiver(state, error), ValueError, message)
        for index in range(5):
            for field in ('__objclass__', '__name__'):
                state, capsule, error = self.positive(index)
                descriptor, attribute = getattr(capsule, ROUTES[index]), capsule.attribute
                primary, seen = OSError('native metadata failure'), []
                def read(selected, name, *, attribute=attribute, descriptor=descriptor, field=field, primary=primary, seen=seen):
                    result = attribute(selected, name)
                    if selected is descriptor and name == field:
                        seen.append(True)
                        raise primary
                    return result
                capsule.attribute = read
                self.raw(state, lambda *, capsule=capsule, error=error, index=index, state=state: self.call(state, capsule, index, error), OSError, actual=primary)
                self.assertEqual(seen, [True])

    def test_each_route_after_actual_native_total_expiry_and_no_deadline_extension(self):
        for index in range(5):
            state, capsule, error = self.positive(index)
            descriptor, actual_get = getattr(capsule, ROUTES[index]), capsule.get
            expired, seen = [False], []
            def get(selected, receiver, owner, *, actual_get=actual_get, descriptor=descriptor, expired=expired, seen=seen):
                result = actual_get(selected, receiver, owner)
                if selected is descriptor:
                    seen.append(True)
                    expired[0] = True
                return result
            def clock(*, expired=expired, state=state):
                return state.total if expired[0] else 0
            capsule.get = get
            with patch.object(PROBE.time, 'monotonic_ns', side_effect=clock):
                self.raw(state, lambda *, capsule=capsule, error=error, index=index, state=state: self.call(state, capsule, index, error),
                         TimeoutError, 'original absolute SDK probe deadline')
            self.assertEqual(seen, [True])
            self.assertEqual((state.work, state.total), (1, 5000000001))

    def test_each_route_name_budget_utf8_and_repeated_reservations(self):
        for index in range(5):
            state, capsule, error = self.positive(index)
            descriptor, attribute = getattr(capsule, ROUTES[index]), capsule.attribute
            seen = []
            def read(selected, name, *, attribute=attribute, descriptor=descriptor, seen=seen, state=state):
                result = attribute(selected, name)
                if selected is descriptor and name == '__name__':
                    seen.append(True)
                    state.read_bytes = 536870912 - 32
                return result
            capsule.attribute = read
            self.raw(state, lambda *, capsule=capsule, error=error, index=index, state=state: self.call(state, capsule, index, error), ValueError,
                     'SDK aggregate preparation/text/output bound')
            self.assertEqual(seen, [True])
        state, capsule, error = self.positive(0)
        before = state.read_bytes
        self.call(state, capsule, 0, error)
        middle = state.read_bytes
        self.call(state, capsule, 0, error)
        self.assertGreater(middle, before)
        self.assertGreater(state.read_bytes, middle)
        for value, kind, message in ((object(), ValueError, 'diagnostic exact native descriptor name'),
                                      ('x' * 257, ValueError, 'diagnostic exact native descriptor name'),
                                      ('\ud800', UnicodeEncodeError, None)):
            state, capsule, error = self.positive(0)
            attribute = capsule.attribute
            def read(selected, name, *, attribute=attribute, capsule=capsule, value=value):
                result = attribute(selected, name)
                return value if selected is capsule.args_descriptor and name == '__name__' else result
            capsule.attribute = read
            self.raw(state, lambda *, capsule=capsule, error=error, state=state: self.call(state, capsule, 0, error), kind, message)

    def test_capture_uses_work_deadline_but_late_diagnostics_uses_existing_total(self):
        state, capsule, error = self.positive(0)
        with patch.object(PROBE.time, 'monotonic_ns', return_value=state.work):
            self.call(state, capsule, 0, error)
            with self.assertRaises(TimeoutError) as caught:
                capsule.capture(state, PROBE.build_checker(state))
        self.assertEqual(caught.exception.args, ('original absolute SDK probe deadline',))
        self.assertEqual((state.work, state.total), (1, 5000000001))


if __name__ == '__main__':
    unittest.main()

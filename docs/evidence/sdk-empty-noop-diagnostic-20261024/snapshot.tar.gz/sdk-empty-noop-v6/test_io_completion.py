"""SAVED_UNRUN original IO/map caller and closed JSON shape additions."""
import json
import unittest
from contextlib import ExitStack
from unittest.mock import patch

import test_io_boundaries as old_io
from test_main_resources import ObserveIO
from test_support import PROBE, zero_clock


class IOSupplement(unittest.TestCase):
    def setUp(self):
        clock = patch.object(PROBE.time, 'monotonic_ns', zero_clock)
        clock.start()
        self.addCleanup(clock.stop)

    def state(self):
        state = PROBE.ProbeState()
        state.work, state.total, state.stage = 1, 5000000001, 'IO_CALLER'
        return state

    def positive(self):
        state, world = self.state(), old_io.FileWorld()
        with ExitStack() as stack:
            world.install(stack)
            self.assertEqual(PROBE.file_row(state, '/input'), old_io.expected_row())
        self.assertEqual(world.closed, [17])
        self.assertEqual(state.used, 0)

    def test_pinned_file_actual_open_absence_not_missing_prospective_row(self):
        for path in (PROBE.DERIVED_SO, PROBE.DERIVED_PY, PROBE.DERIVED_PYC):
            self.positive()
            state, error = self.state(), FileNotFoundError('actual pinned endpoint absent')
            cohort = {'files': {path: old_io.expected_row()}, 'excluded_origins': {},
                      'probe_source': old_io.expected_row()}
            with patch.object(PROBE.os.path, 'realpath', side_effect=lambda value: value):
                with patch.object(PROBE.os, 'open', side_effect=error) as acquired:
                    with patch.object(PROBE.os, 'close') as closed:
                        with PROBE.Capture(state, 'origin-open'):
                            PROBE.admitted_origin(state, path, cohort)
            self.assertIs(state.raw[0], error)
            self.assertEqual(state.phases[0], 'origin-open')
            self.assertEqual(acquired.call_count, 1)
            closed.assert_not_called()

    def test_read_hash_scan_guard_and_step_preparation_before_acquisition(self):
        for operation in ('read', 'hash', 'scan'):
            for seam in ('Capture', 'range'):
                self.positive()
                state, error = self.state(), MemoryError('preacquisition preparation')
                def action(*, operation=operation, state=state):
                    if operation == 'read':
                        return PROBE.read_bounded(state, '/input', 2)
                    if operation == 'hash':
                        return PROBE.file_row(state, '/input')
                    return PROBE.bounded_names(state, '/namespace')
                with patch.object(PROBE, seam, side_effect=error, create=True):
                    with patch.object(PROBE.os, 'open') as opened:
                        with patch.object(PROBE.os, 'scandir') as scanned:
                            with patch.object(PROBE.os, 'close') as closed:
                                with self.assertRaises(MemoryError) as caught:
                                    action()
                self.assertIs(caught.exception, error)
                opened.assert_not_called()
                scanned.assert_not_called()
                closed.assert_not_called()
                self.assertEqual(state.used, 0)

    def map_positive(self):
        state = self.state()
        raw = ('0000-1000 r-xp 0 00:01 2 ' + PROBE.DERIVED_SO + '\n').encode()
        world = old_io.FileWorld((PROBE.DERIVED_SO,), maps=(raw[:7], raw[7:], b''))
        cohort = {'files': {PROBE.DERIVED_SO: old_io.expected_row()},
                  'excluded_origins': {}, 'probe_source': old_io.expected_row()}
        with ExitStack() as stack:
            world.install(stack)
            self.assertEqual(PROBE.maps(state, cohort)['regular_origins'], [PROBE.DERIVED_SO])
        self.assertEqual(world.closed.count(31), 1)
        self.assertEqual(world.closed.count(17), 1)
        return cohort

    def test_actual_maps_overflow_noeof_readclose_and_late_read_deadline(self):
        scenarios = ('overflow', 'noeof', 'read', 'deadline')
        for mode in scenarios:
            cohort = self.map_positive()
            state, primary, secondary = self.state(), OSError('map read'), OSError('map close')
            blocks = (b'x' * 8388609, b'') if mode == 'overflow' else (b'x',) * 129
            world = old_io.FileWorld((PROBE.DERIVED_SO,), maps=blocks)
            if mode == 'read':
                world.read_error = primary
            if mode in ('read', 'deadline'):
                world.close_error = secondary
            expired, original = [False], world.read
            def read(number, amount, *, expired=expired, original=original):
                result = original(number, amount)
                expired[0] = True
                return result
            with ExitStack() as stack:
                world.install(stack)
                if mode == 'deadline':
                    stack.enter_context(patch.object(PROBE.os, 'read', side_effect=read))
                    stack.enter_context(patch.object(PROBE.time, 'monotonic_ns',
                        side_effect=lambda *, expired=expired, state=state: state.total if expired[0] else 0))
                with self.assertRaises(RuntimeError) as caught:
                    PROBE.maps(state, cohort)
            self.assertIs(caught.exception, state.failure)
            self.assertEqual(world.closed, [31])
            self.assertEqual(state.phases[0], 'read')
            if mode == 'read':
                self.assertIs(state.raw[0], primary)
            elif mode == 'deadline':
                self.assertIs(type(state.raw[0]), TimeoutError)
                self.assertEqual(state.raw[0].args, ('original absolute SDK probe deadline',))
            else:
                message = 'SDK read overflow' if mode == 'overflow' else 'SDK read loop exhausted without EOF'
                self.assertEqual(state.raw[0].args, (message,))
            if mode in ('read', 'deadline'):
                self.assertIs(state.raw[1], secondary)
                self.assertEqual(state.phases[1], 'read-close')
            self.assertEqual((state.work, state.total), (1, 5000000001))

    def reject(self, action, message):
        with self.assertRaises(ValueError) as caught:
            action()
        self.assertIs(type(caught.exception), ValueError)
        self.assertEqual(caught.exception.args, (message,))

    def cohort(self):
        value = ObserveIO().cohort
        PROBE.validate_cohort(value)
        return json.loads(json.dumps(value))

    def test_every_top_level_collection_kind_and_error_list(self):
        for key in ('files', 'directories', 'aliases', 'negative_lookup', 'excluded_origins'):
            for value in (None, [], ()):
                cohort = self.cohort()
                cohort[key] = value
                with patch.object(PROBE.os, 'open') as opened:
                    self.reject(lambda *, cohort=cohort: PROBE.validate_cohort(cohort), 'SDK map type/count bound')
                opened.assert_not_called()
        for value in (None, (), [None]):
            cohort = self.cohort()
            cohort['errors'] = value
            self.reject(lambda *, cohort=cohort: PROBE.validate_cohort(cohort), 'prospective SDK closure incomplete')

    def test_every_identity_field_wrong_type_and_both_integer_endpoints(self):
        for field in PROBE.FIELDS:
            for value in (True, 1.0, None, 1 << 128, -(1 << 128) - 1):
                cohort = self.cohort()
                cohort['probe_source']['identity'][field] = value
                self.reject(lambda *, cohort=cohort: PROBE.validate_cohort(cohort), 'SDK identity exact bounded integer')
        for value in ('0' * 63, 'z' * 64, None):
            cohort = self.cohort()
            cohort['probe_source']['sha256'] = value
            self.reject(lambda *, cohort=cohort: PROBE.validate_cohort(cohort), 'SDK SHA256 exact text')
        cohort = self.cohort()
        del cohort['probe_source']['identity']['st_ino']
        self.reject(lambda: PROBE.validate_cohort(cohort), 'SDK full9 identity keys')

    def test_file_and_aggregate_size_caps_and_file_row_key_shapes(self):
        for size in (-1, 67108865):
            cohort = self.cohort()
            cohort['files'][PROBE.DERIVED_SO]['identity']['st_size'] = size
            self.reject(lambda *, cohort=cohort: PROBE.validate_cohort(cohort), 'SDK cohort per-file bound')
        cohort = self.cohort()
        row = old_io.expected_row()
        row['identity']['st_size'] = 67108864
        cohort['files'] = {'/bounded/file' + str(index): row for index in range(9)}
        self.reject(lambda: PROBE.validate_cohort(cohort), 'SDK cohort aggregate bound')
        for row in ({}, {'identity': old_io.stat_fields()},
                    {'identity': old_io.stat_fields(), 'sha256': '0' * 64, 'extra': None}):
            self.cohort()
            message = 'SDK map type/count bound' if len(row) > 2 else 'SDK file row keys'
            self.reject(lambda *, row=row: PROBE.validate_file_row(row), message)

    def test_all_absolute_path_and_leaf_shape_predicates_before_native_io(self):
        paths = (None, 3, '', 'relative', '/a/./b', '/a/../b', '/a\x00b', '/' + 'x' * 4096)
        leaves = (None, 3, '', '.', '..', 'a/b', 'a\x00b', 'x' * 256, '\u00e9' * 128)
        for value in paths:
            PROBE.path_text('/positive')
            self.reject(lambda *, value=value: PROBE.path_text(value), 'SDK absolute path shape/bound')
        for value in leaves:
            PROBE.leaf_text('positive.py')
            self.reject(lambda *, value=value: PROBE.leaf_text(value), 'SDK namespace entry shape/bound')
        for value in (None, (), 'names'):
            self.reject(lambda *, value=value: PROBE.validate_names(value), 'SDK namespace list type/count')
        self.reject(lambda: PROBE.validate_names(['name'] * 8193), 'SDK namespace list type/count')

    def test_directory_alias_negative_row_and_nested_names_shapes(self):
        cases = (('directory', 'SDK directory row keys'), ('names', 'SDK namespace list type/count'),
                 ('alias', 'SDK alias row keys'), ('resolved', 'SDK absolute path shape/bound'),
                 ('link', 'SDK alias link bound'), ('negative', 'SDK negative lookup row shape'),
                 ('startup', 'SDK startup predicate mismatch'))
        for mode, message in cases:
            cohort = self.cohort()
            if mode in ('directory', 'names'):
                row = {'identity': old_io.stat_fields(0), 'names': None}
                if mode == 'directory':
                    row['extra'] = row.pop('names')
                cohort['directories'] = {'/directory': row}
            elif mode in ('alias', 'resolved', 'link'):
                row = {'identity': old_io.stat_fields(), 'link': 'target', 'resolved': '/target'}
                if mode == 'alias':
                    row['extra'] = row.pop('link')
                else:
                    row['resolved' if mode == 'resolved' else 'link'] = ''
                cohort['aliases'] = {'/alias': row}
            elif mode == 'negative':
                cohort['negative_lookup'] = {'/absent': {'state': 'wrong'}}
            else:
                cohort['negative_lookup'] = {'site_top_level_special': {
                    'directory': '/site', 'names': [], 'predicate': 'wrong'}}
            with patch.object(PROBE.os, 'scandir') as scanned:
                self.reject(lambda *, cohort=cohort: PROBE.validate_cohort(cohort), message)
            scanned.assert_not_called()


if __name__ == '__main__':
    unittest.main()

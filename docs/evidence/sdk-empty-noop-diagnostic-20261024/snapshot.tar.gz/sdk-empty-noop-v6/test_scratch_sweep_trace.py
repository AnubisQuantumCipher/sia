"""Compare exhaustive retirement traces with the retained original checker."""
import importlib.util
from pathlib import Path
import unittest
from unittest.mock import patch

from test_support import CHECKER, PROBE, zero_clock

BASE = Path(__file__).parent.parent / 'sdk-fixtures-constant-clock-v1'


def load_original():
    spec = importlib.util.spec_from_file_location(
        'scratch_original_checker', BASE / 'production_checker.py')
    if spec is None or spec.loader is None:
        raise RuntimeError('original checker loader unavailable')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


ORIGINAL = load_original()


class ScratchSweepTrace(unittest.TestCase):
    def exercise(self, module, failures=(), *, every=False, mutation=None):
        with patch.object(module.time, 'monotonic_ns', zero_clock):
            state = PROBE.ProbeState()
            state.work, state.total = 1, 5000000001
            checker = module.build_checker(state)
            marker = object()
            for index in (0, 4096, 8191):
                checker.keys[index] = checker.values[index] = marker
            checker.pair = checker.current_key = checker.current_value = marker
            trace, errors = [], []
            original_retire = module.retire_reference_cell

            def retire(sequence, index):
                kind = 'keys' if sequence is checker.keys else 'values'
                trace.append((kind, index))
                if mutation is not None:
                    mutation(checker, kind, index, marker)
                if every or (kind, index) in failures:
                    error = OSError(kind, index)
                    if len(errors) < 64:
                        errors.append(error)
                    raise error
                original_retire(sequence, index)

            with patch.object(module, 'retire_reference_cell', retire):
                checker.clear_scratch()
            self.assertEqual(trace, [('keys', i) for i in range(8192)]
                             + [('values', i) for i in range(8192)])
            for index, error in enumerate(errors):
                self.assertIs(state.raw[index], error)
            record = self.record(checker, state)
            checker.clear()
            return record

    def record(self, checker, state):
        return {'keys': tuple(item is None for item in checker.keys),
                'values': tuple(item is None for item in checker.values),
                'temporaries': (checker.pair, checker.current_key, checker.current_value),
                'count': checker.count, 'used': state.used, 'overflow': state.overflow,
                'errors': [(state.phases[i], type(state.raw[i]).__name__, state.raw[i].args)
                           for i in range(state.used)]}

    def compare(self, failures=(), *, every=False, mutation=None):
        expected = self.exercise(ORIGINAL, failures, every=every, mutation=mutation)
        for module in (CHECKER, PROBE):
            with self.subTest(module=module.__name__):
                actual = self.exercise(module, failures, every=every, mutation=mutation)
                self.assertEqual(actual, expected)
        return expected

    def test_success_attempts_every_empty_and_occupied_slot(self):
        result = self.compare()
        self.assertEqual((result['used'], result['overflow']), (0, False))
        self.assertTrue(all(result['keys']) and all(result['values']))

    def test_first_middle_last_and_consecutive_failures_keep_trace(self):
        failures = (('keys', 0), ('keys', 1), ('keys', 4096), ('keys', 8191),
                    ('values', 0), ('values', 1), ('values', 4096), ('values', 8191))
        result = self.compare(failures)
        self.assertEqual(result['used'], len(failures))
        self.assertFalse(result['overflow'])

    def test_terminal_cell_failure_is_recorded_without_retry(self):
        result = self.compare((('values', 8191),))
        self.assertEqual(result['errors'], [('scratch-clear', 'OSError', ('values', 8191))])

    def test_every_cell_failure_preserves_first64_and_continues_after_overflow(self):
        result = self.compare(every=True)
        self.assertEqual(result['used'], 64)
        self.assertTrue(result['overflow'])

    def test_high_slot_repopulation_is_still_reached(self):
        def mutate(checker, kind, index, marker):
            if kind == 'keys' and index == 0:
                checker.keys[8191] = checker.values[8191] = marker
        result = self.compare(mutation=mutate)
        self.assertTrue(all(result['keys']) and all(result['values']))

    def test_earlier_slot_repopulation_remains_explicit_limitation(self):
        def mutate(checker, kind, index, marker):
            if kind == 'keys' and index == 8191:
                checker.keys[0] = marker
        result = self.compare(mutation=mutate)
        self.assertFalse(result['keys'][0])
        self.assertEqual(result['used'], 0)


if __name__ == '__main__':
    unittest.main()

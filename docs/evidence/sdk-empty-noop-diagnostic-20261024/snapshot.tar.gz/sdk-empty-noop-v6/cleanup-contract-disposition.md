# Cleanup contract reconciliation

Owner disposition: complete fixture suite TESTED. Candidate adoption OPEN.
No semantic equivalence, no new no-hooks premise and no policy deviation
approved by this record. No SDK/native observation grant follows.

The existing source contracts require:

1. Examine the entire fixed scratch capacity on success and failure before reuse.
2. Release held references at their required lifetime; keep named first values
   through recheck/diagnostics. Retire actual independently owned capabilities
   exactly once; do not invent a close operation for native iterators.
3. Preserve actual primary and independent secondary raw error identities,
   their ordering/phase and raw64 overflow behavior; an actual cleanup failure
   cannot become success or prevent independent remaining cleanup.
4. Preserve current substituted retirement callbacks and original fault seams.
5. Keep original work/storage limits and explicit unproved interpreter costs.
6. Add no no-hooks/no-mutation premise to obtain acceptance.

The candidate's None check reads an exact built-in list slot. If it is None,
the omitted original helper would assign None to that slot, releasing no foreign
referent. Occupied slots still call the helper and trigger their normal release.
The existing tests exercise replacement/restoration/code mutation after actual
finalizers, shrink-induced errors, later-slot repopulation and raw overflow.
Earlier-slot repopulation remains a pre-existing explicit limitation.

That local source argument does not establish equivalence of function-entry
failures or frame/profile observations. The strong-roster amendment explicitly
forbids a new no-hooks premise. The V7 resource record marks allocation,
traceback, finalizer and WCET behavior UNKNOWN; it does not discharge these
properties. Neither universal equivalence nor a policy deviation follows
automatically. A complete observable-contract argument is still needed before
adoption. No existing original controls or budgets are removed to settle it.

Next work: reconcile the exact observable requirement with these operation
differences, keeping all actual-error and callback obligations. If no such
argument is justified, retain this tested candidate as nonadopted and develop
a successor preserving the required behavior; do not rerun unchanged tests or
increase limits. Native output/source binding is a later, separate admission.

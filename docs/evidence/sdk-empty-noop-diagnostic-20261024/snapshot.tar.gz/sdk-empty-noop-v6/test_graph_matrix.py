"""SAVED_UNRUN independent graph matrix; prospective pure mechanics only.

No SDK installation, admission, proof, or execution result is claimed here.
Every mutation starts after Harness.positive on actual production methods.
"""
import sys
import unittest
from unittest.mock import patch

from test_support import CHECKER, Harness


class Collision:
    calls = 0

    def __hash__(self):
        Collision.calls += 1
        return hash('__spec__')

    def __eq__(self, other):
        Collision.calls += 1
        return False

    def __repr__(self):
        Collision.calls += 1
        raise RuntimeError('candidate collision rendering')


class StringKey(str):
    calls = 0

    def __hash__(self):
        StringKey.calls += 1
        return str.__hash__(self)

    def __eq__(self, other):
        StringKey.calls += 1
        return False


class Opaque:
    calls = 0

    def __getattribute__(self, name):
        Opaque.calls += 1
        raise RuntimeError('opaque getter')

    def __eq__(self, other):
        Opaque.calls += 1
        raise RuntimeError('opaque equality')

    def __hash__(self):
        Opaque.calls += 1
        raise RuntimeError('opaque hash')

    def __repr__(self):
        Opaque.calls += 1
        raise RuntimeError('opaque rendering')

    def __iter__(self):
        Opaque.calls += 1
        raise RuntimeError('opaque iteration')

    def __call__(self):
        Opaque.calls += 1
        raise RuntimeError('opaque invocation')


def clone_module(original):
    result = type(sys)(original.__name__)
    result.__dict__.update(original.__dict__)
    return result


def clone_spec(original):
    result = type(original)(original.name, original.loader)
    result.__dict__.clear()
    result.__dict__.update(original.__dict__)
    return result


class GraphMatrix(unittest.TestCase):
    def fresh(self):
        if not hasattr(self, "_harness"):
            self._harness = Harness(self)
        else:
            self._harness = self._harness.fresh()
        self._harness.positive()
        return self._harness

    def graph_error(self, harness, message, recheck=False, phase='METADATA'):
        return harness.error(lambda: harness.checker.graph(recheck=recheck),
                             message, phase)

    def test_positive_complete_production_graph_census_and_scalar_ceiling(self):
        h = self.fresh()
        h.checker.graph(recheck=True)
        h.checker.final_roster()
        self.assertEqual(h.checker.row_count, len(h.modules))
        h.checker.clear()
        rows = h.checker.scalar_rows()
        self.assertEqual({row['name'] for row in rows}, set(h.modules))
        for row in rows:
            self.assertEqual(set(row), {'name', 'origin'})
        self.assertEqual(h.state.used, 0)

    def test_all_role_distinctness_pairs_with_coherent_child_joins(self):
        keys = ('pyexpat', 'xml.parsers.expat', 'pyexpat.errors', 'pyexpat.model')
        for left in range(4):
            for right in range(left):
                with self.subTest(left=left, right=right):
                    h = self.fresh()
                    h.modules[keys[left]] = h.modules[keys[right]]
                    h.modules['xml.parsers.expat.errors'] = h.modules['pyexpat.errors']
                    h.modules['xml.parsers.expat.model'] = h.modules['pyexpat.model']
                    self.graph_error(h, 'derived role distinctness', phase='ANCHORS')

    def test_role_bootstrap_collision_and_wrong_exact_module(self):
        keys = ('pyexpat', 'xml.parsers.expat', 'pyexpat.errors', 'pyexpat.model')
        for key in keys:
            for provider in ('_frozen_importlib', '_frozen_importlib_external'):
                h = self.fresh()
                h.modules[key] = h.modules[provider]
                h.modules['xml.parsers.expat.errors'] = h.modules['pyexpat.errors']
                h.modules['xml.parsers.expat.model'] = h.modules['pyexpat.model']
                self.graph_error(h, 'derived role bootstrap collision', phase='ANCHORS')
            h = self.fresh()
            h.modules[key] = object()
            h.modules['xml.parsers.expat.errors'] = h.modules['pyexpat.errors']
            h.modules['xml.parsers.expat.model'] = h.modules['pyexpat.model']
            self.graph_error(h, 'derived exact role module', phase='ANCHORS')

    def test_every_registration_missing_and_changed_at_recheck(self):
        keys = ('pyexpat', 'xml.parsers.expat', 'pyexpat.errors', 'pyexpat.model',
                'xml.parsers.expat.errors', 'xml.parsers.expat.model')
        for key in keys:
            for missing in (False, True):
                h = self.fresh()
                if missing:
                    del h.modules[key]
                    message = 'derived missing required field'
                else:
                    h.modules[key] = type(sys)('replacement')
                    message = ('derived wrapper child aliases' if key.startswith('xml.parsers.expat.')
                               else 'derived selected first identity changed')
                self.graph_error(h, message, recheck=True, phase='RECHECK')

    def test_every_module_export_join_missing_and_changed(self):
        for key in ('pyexpat', 'xml.parsers.expat'):
            for field in ('errors', 'model', 'sys'):
                if field == 'sys' and key == 'pyexpat':
                    continue
                for missing in (False, True):
                    h = self.fresh()
                    namespace = h.modules[key].__dict__
                    before = dict(namespace)
                    if missing:
                        del namespace[field]
                        message = 'derived missing required field'
                    else:
                        namespace[field] = type(sys)('replacement')
                        message = ('derived wrapper actual sys export' if field == 'sys'
                                   else 'derived module role exports')
                    self.graph_error(h, message)
                    for other in before:
                        if other != field:
                            self.assertIs(namespace[other], before[other])

    def test_frozen_alias_and_each_machinery_export_exact_recheck_phase(self):
        for alias in ('importlib._bootstrap', 'importlib._bootstrap_external'):
            h = self.fresh()
            h.modules[alias] = type(sys)('replacement')
            self.graph_error(h, 'derived frozen module alias', True, 'RECHECK')
        for field in ('ModuleSpec', 'SourceFileLoader', 'ExtensionFileLoader'):
            h = self.fresh()
            machinery = clone_module(h.modules['importlib.machinery'])
            machinery.__dict__[field] = object()
            h.modules['importlib.machinery'] = machinery
            self.graph_error(h, 'derived machinery export alias', True, 'RECHECK')

    def test_all_provider_export_absence_metaclass_and_first_identity(self):
        class Meta(type):
            calls = 0
            def __getattribute__(cls, name):
                Meta.calls += 1
                raise RuntimeError('candidate class getter')
        candidate = Meta('Candidate', (), {})
        for field, export in CHECKER.DERIVED_EXPORTS + CHECKER.DERIVED_EXTERNAL:
            boot = field in ('ModuleSpec', 'FrozenImporter')
            key = '_frozen_importlib' if boot else '_frozen_importlib_external'
            for mode in ('missing', 'metaclass', 'recheck'):
                h = self.fresh()
                provider = h.modules[key]
                replacement = dict(provider.__dict__)
                if mode == 'missing':
                    del replacement[export]
                    message = 'derived missing required field'
                elif mode == 'metaclass':
                    replacement[export] = candidate
                    message = 'derived exact anchor metaclass'
                else:
                    replacement[export] = type('Replacement', (), {})
                    message = 'derived selected first identity changed'
                original = h.checker.refs.member_get_intrinsic
                def read(descriptor, receiver, owner, *, original=original, provider=provider, replacement=replacement):
                    result = original(descriptor, receiver, owner)
                    return replacement if receiver is provider else result
                Meta.calls = 0
                with patch.object(h.checker.refs, 'member_get_intrinsic', read):
                    self.graph_error(h, message, mode == 'recheck',
                                     'RECHECK' if mode == 'recheck' else 'ANCHORS')
                self.assertEqual(Meta.calls, 0)

    def test_every_file_spec_field_absence_and_independent_wrong_value(self):
        changes = (('name', 'wrong', 'derived exact text mismatch'),
                   ('origin', '/wrong', 'derived exact text mismatch'),
                   ('loader', None, 'derived spec loader identity'),
                   ('loader_state', Opaque(), 'derived spec required None'),
                   ('submodule_search_locations', Opaque(), 'derived spec required None'),
                   ('_uninitialized_submodules', (), 'derived spec empty list'),
                   ('_set_fileattr', 1, 'derived exact spec booleans'),
                   ('_cached', '/wrong', 'cache'),
                   ('_initializing', 0, 'derived exact spec booleans'))
        for key in ('pyexpat', 'xml.parsers.expat'):
            for field, value, message in changes:
                for missing in (False, True):
                    h = self.fresh()
                    namespace = h.modules[key].__spec__.__dict__
                    if missing:
                        del namespace[field]
                        # Closed schema count precedes selection.
                        expected = 'derived exact closed key count'
                    else:
                        namespace[field] = value
                        expected = message
                        if message == 'cache':
                            expected = ('derived producer spec cache' if key == 'pyexpat'
                                        else 'derived exact text mismatch')
                    Opaque.calls = 0
                    self.graph_error(h, expected)
                    self.assertEqual(Opaque.calls, 0)
            h = self.fresh()
            h.modules[key].__spec__.__dict__['extra'] = None
            self.graph_error(h, 'derived exact closed key count')

    def test_bootstrap_specs_both_providers_optional_and_opaque_fields(self):
        changes = (('name', 'wrong', 'derived exact text mismatch'),
                   ('origin', 'built-in', 'derived exact text mismatch'),
                   ('loader', None, 'derived bootstrap loader identity'),
                   ('_cached', 'x', 'derived bootstrap cache/location'),
                   ('_set_fileattr', 0, 'derived bootstrap cache/location'),
                   ('_uninitialized_submodules', (), 'derived bootstrap empty list'),
                   ('_initializing', None, 'derived bootstrap initialization'))
        for key, alias in (('_frozen_importlib', 'importlib._bootstrap'),
                           ('_frozen_importlib_external', 'importlib._bootstrap_external')):
            for field, value, message in changes:
                h = self.fresh()
                provider = clone_module(h.modules[key])
                provider.__spec__ = clone_spec(provider.__spec__)
                provider.__spec__.__dict__[field] = value
                h.modules[key], h.modules[alias] = provider, provider
                self.graph_error(h, message, phase='ANCHORS')
            for field in ('loader_state', 'submodule_search_locations'):
                h = self.fresh()
                provider = clone_module(h.modules[key])
                provider.__spec__ = clone_spec(provider.__spec__)
                provider.__spec__.__dict__[field] = Opaque()
                h.modules[key], h.modules[alias] = provider, provider
                Opaque.calls = 0
                h.checker.graph()
                self.assertEqual(Opaque.calls, 0)

    def test_each_loader_schema_and_wrong_exact_class(self):
        for key in ('pyexpat', 'xml.parsers.expat'):
            for field in ('name', 'path'):
                for mode in ('missing', 'wrong', 'subclass'):
                    h = self.fresh()
                    namespace = h.modules[key].__loader__.__dict__
                    if mode == 'missing':
                        del namespace[field]
                        message = 'derived exact closed key count'
                    else:
                        namespace[field] = StringKey('wrong') if mode == 'subclass' else 'wrong'
                        message = ('derived exact text prelength' if mode == 'subclass'
                                   else 'derived exact text mismatch')
                    StringKey.calls = 0
                    self.graph_error(h, message)
                    self.assertEqual(StringKey.calls, 0)
            h = self.fresh()
            h.modules[key].__loader__.__dict__['extra'] = Opaque()
            self.graph_error(h, 'derived exact closed key count')
            h = self.fresh()
            h.modules[key].__loader__ = object()
            self.graph_error(h, 'derived exact loader type')

    def test_each_synthetic_metadata_field_presence_and_value(self):
        for key in ('pyexpat.errors', 'pyexpat.model'):
            for field in ('__package__', '__loader__', '__spec__'):
                for missing in (False, True):
                    h = self.fresh()
                    namespace = h.modules[key].__dict__
                    if missing:
                        del namespace[field]
                    else:
                        namespace[field] = Opaque()
                    Opaque.calls = 0
                    self.graph_error(h, 'derived missing required field' if missing
                                     else 'derived synthetic required None')
                    self.assertEqual(Opaque.calls, 0)
            for field in ('__file__', '__cached__', '__path__'):
                h = self.fresh()
                h.modules[key].__dict__[field] = None if field == '__path__' else Opaque()
                self.graph_error(h, 'derived forbidden present field' if field == '__path__'
                                 else 'derived optional None field')

    def test_all_role_and_file_metadata_text_doc_and_absent_paths(self):
        keys = ('pyexpat.errors', 'pyexpat.model', 'pyexpat', 'xml.parsers.expat')
        for key in keys:
            fields = ('__name__',) if key.endswith(('.errors', '.model')) else (
                '__name__', '__package__', '__file__')
            for field in fields:
                for value in ('wrong', object(), StringKey('wrong'), 'x' * 4097):
                    h = self.fresh()
                    h.modules[key].__dict__[field] = value
                    message = ('derived exact text mismatch' if type(value) is str
                               and value == 'wrong' else 'derived exact text prelength')
                    StringKey.calls = 0
                    self.graph_error(h, message)
                    self.assertEqual(StringKey.calls, 0)
                h = self.fresh()
                del h.modules[key].__dict__[field]
                self.graph_error(h, 'derived missing required field')
            for doc in (None, '', 'finite documentation'):
                h = self.fresh()
                h.modules[key].__doc__ = doc
                h.checker.graph(recheck=True)
            for doc in (object(), StringKey('doc'), 'x' * 65537):
                h = self.fresh()
                h.modules[key].__doc__ = doc
                self.graph_error(h, 'derived exact text prelength')
            h = self.fresh()
            h.modules[key].__dict__['__path__'] = None
            self.graph_error(h, 'derived forbidden present field')

    def test_extra_children_both_prefixes_and_opaque_unused_values(self):
        for prefix in ('pyexpat.', 'xml.parsers.expat.'):
            h = self.fresh()
            h.modules[prefix + 'unadmitted'] = type(sys)('unadmitted')
            self.graph_error(h, 'derived extra registered child', phase='ANCHORS')
        for key in ('pyexpat', 'xml.parsers.expat', 'pyexpat.errors', 'pyexpat.model'):
            for value in (Opaque(), [], {}, lambda: None, len):
                h = self.fresh()
                h.modules[key].__dict__['unused_opaque'] = value
                Opaque.calls = 0
                h.checker.graph(recheck=True)
                self.assertEqual(Opaque.calls, 0)

    def native_roles(self, h):
        r, p = h.checker.refs, h.modules['pyexpat']
        return (('MODULE_NAMESPACE', r.module_namespace_descriptor, p, r.module_type, '__dict__'),
                ('TYPE_NAMESPACE', r.type_namespace_descriptor, r.ModuleSpec, type, '__dict__'),
                ('TYPE_BASES', r.type_bases_descriptor, r.ModuleSpec, type, '__bases__'),
                ('SPEC_NAMESPACE', r.spec_namespace_descriptor, p.__spec__, r.ModuleSpec, '__dict__'),
                ('LOADER_NAMESPACE', r.fileloader_namespace_descriptor, p.__loader__, r.FileLoader, '__dict__'))

    def test_every_native_route_preflight_operation_output_and_no_fallback(self):
        for index in range(5):
            for mode in ('kind', 'owner', 'name', 'receiver', 'output', 'error'):
                h = self.fresh()
                args = list(self.native_roles(h)[index])
                operation_field = ('member_get_intrinsic' if index == 0 else 'getset_get_intrinsic')
                original = getattr(h.checker.refs, operation_field)
                calls = []
                fault = RuntimeError('actual primitive failure')
                def operation(*values, calls=calls, fault=fault, mode=mode, original=original):
                    calls.append(values)
                    result = original(*values)
                    if mode == 'error':
                        raise fault
                    return object() if mode == 'output' else result
                if mode == 'kind':
                    args[1] = object()
                    message = 'derived native descriptor kind'
                elif mode == 'owner':
                    args[3] = object
                    message = 'derived native descriptor owner'
                elif mode == 'name':
                    args[4] = 'wrong'
                    message = 'derived exact text mismatch'
                elif mode == 'receiver':
                    args[2] = object()
                    message = ('derived exact module receiver', 'derived exact class receiver',
                               'derived exact class receiver', 'derived exact spec receiver',
                               'derived exact loader receiver')[index]
                else:
                    message = 'derived native descriptor output'
                setattr(h.checker.refs, operation_field, operation)
                if mode == 'error':
                    with self.assertRaises(RuntimeError) as caught:
                        h.checker.native(*args)
                    self.assertIs(caught.exception, fault)
                else:
                    h.error(lambda *, args=args, h=h: h.checker.native(*args), message, h.state.stage)
                self.assertEqual(len(calls), 1 if mode in ('output', 'error') else 0)
                setattr(h.checker.refs, operation_field, original)

    def collision_target(self, h, target, role, receiver):
        r = h.checker.refs
        return ((target == 'sys' and receiver is r.sys_actual)
                or (target == 'boot' and receiver is r.bootstrap_module)
                or (target == 'external' and receiver is r.external_module)
                or (target == 'classModule' and role == 'TYPE_NAMESPACE' and receiver is r.module_type)
                or (target == 'classSpec' and role == 'TYPE_NAMESPACE' and receiver is r.ModuleSpec)
                or (target == 'classLoader' and role == 'TYPE_NAMESPACE' and receiver is r.FileLoader)
                or (target == 'bootSpec' and receiver is r.bootstrap_module.__spec__)
                or (target == 'externalSpec' and receiver is r.external_module.__spec__)
                or (target == 'machinery' and receiver is h.modules['importlib.machinery'])
                or (target == 'specP' and receiver is r.S_P)
                or (target == 'specW' and receiver is r.S_W)
                or (target == 'loaderP' and receiver is r.L_P)
                or (target == 'loaderW' and receiver is r.L_W)
                or (target == 'roleE' and receiver is r.E)
                or (target == 'roleM' and receiver is r.M)
                or (target == 'generic' and receiver is r.W))

    def test_collision_all_native_namespace_frontiers_graph_and_census(self):
        targets = ('sys', 'boot', 'external', 'classModule', 'classSpec', 'classLoader',
                   'bootSpec', 'externalSpec', 'machinery', 'specP', 'specW',
                   'loaderP', 'loaderW', 'roleE', 'roleM', 'generic')
        for target in targets:
            for key_kind in ('object', 'str-subclass'):
                h = self.fresh()
                c, r = h.checker, h.checker.refs
                poison = Collision() if key_kind == 'object' else StringKey('__spec__')
                done = []
                member, getset = r.member_get_intrinsic, r.getset_get_intrinsic
                def alter(result, receiver, role, *, done=done, h=h, poison=poison, target=target):
                    if self.collision_target(h, target, role, receiver):
                        result = dict(result)
                        result[poison] = None
                        if role == 'TYPE_NAMESPACE':
                            result = type(type.__dict__)(result)
                        Collision.calls, StringKey.calls = 0, 0
                        done.append(True)
                    return result
                def read_member(descriptor, receiver, owner, *, member=member):
                    return alter(member(descriptor, receiver, owner), receiver, 'MODULE_NAMESPACE')
                def read_getset(descriptor, receiver, owner, *, getset=getset, r=r):
                    result = getset(descriptor, receiver, owner)
                    role = 'TYPE_NAMESPACE' if descriptor is r.type_namespace_descriptor else 'OTHER'
                    return alter(result, receiver, role)
                with patch.object(r, 'member_get_intrinsic', read_member), patch.object(
                        r, 'getset_get_intrinsic', read_getset):
                    if target == 'generic':
                        row = next(row for row in c.rows[:c.row_count] if row['_module'] is r.W)
                        row['_checked'] = False
                        def action(*, c=c, row=row):
                            return c.inspect_row(row, lambda value: value, lambda value: True)
                    else:
                        def action(*, c=c):
                            return c.graph(recheck=True)
                    h.error(action, 'derived exact text prelength', 'KEYS')
                self.assertTrue(done)
                self.assertEqual(Collision.calls, 0)
                self.assertEqual(StringKey.calls, 0)

    def test_each_retained_identity_frontier_changed_at_fresh_recheck(self):
        for key in ('_frozen_importlib', '_frozen_importlib_external',
                    'pyexpat', 'xml.parsers.expat', 'pyexpat.errors', 'pyexpat.model'):
            h = self.fresh()
            replacement = clone_module(h.modules[key])
            h.modules[key] = replacement
            if key == '_frozen_importlib':
                h.modules['importlib._bootstrap'] = replacement
            elif key == '_frozen_importlib_external':
                h.modules['importlib._bootstrap_external'] = replacement
            elif key == 'pyexpat.errors':
                h.modules['xml.parsers.expat.errors'] = replacement
            elif key == 'pyexpat.model':
                h.modules['xml.parsers.expat.model'] = replacement
            self.graph_error(h, 'derived selected first identity changed', True, 'RECHECK')
        for key in ('pyexpat', 'xml.parsers.expat'):
            for field in ('__spec__', '__loader__'):
                h = self.fresh()
                module = h.modules[key]
                old = module.__dict__[field]
                module.__dict__[field] = clone_spec(old) if field == '__spec__' else type(old)(old.name, old.path)
                self.graph_error(h, 'derived selected first identity changed', True)

    def test_final_roster_count_name_type_identity_and_visit(self):
        for mode in ('delete', 'insert', 'rename', 'wrong-type', 'replace', 'unchecked', 'duplicate-row'):
            h = self.fresh()
            c = h.checker
            key = 'xml.parsers.expat'
            if mode == 'delete':
                del h.modules[key]
            elif mode == 'insert':
                h.modules['extra'] = type(sys)('extra')
            elif mode == 'rename':
                h.modules['renamed'] = h.modules.pop(key)
            elif mode == 'wrong-type':
                h.modules[key] = object()
            elif mode == 'replace':
                h.modules[key] = clone_module(h.modules[key])
            elif mode == 'unchecked':
                c.rows[0]['_checked'] = False
            else:
                c.rows[1]['name'] = c.rows[0]['name']
            message = {'wrong-type': 'derived census final exact ModuleType',
                       'replace': 'CENSUS_STRONG_IDENTITY', 'unchecked': 'CENSUS_VISIT'}.get(mode, 'CENSUS_COVERAGE')
            h.error(c.final_roster, message, 'RECHECK')
        h = self.fresh()
        ordered = tuple(h.modules.items())
        h.modules.clear()
        h.modules.update(reversed(ordered))
        h.checker.final_roster()


    def test_seven_anchor_distinctness_every_pair(self):
        exports = CHECKER.DERIVED_EXPORTS + CHECKER.DERIVED_EXTERNAL
        for left in range(7):
            for right in range(left):
                h = self.fresh()
                common = type('CommonAnchor', (), {})
                replacements = {}
                for index in (left, right):
                    field, name = exports[index]
                    key = '_frozen_importlib' if index < 2 else '_frozen_importlib_external'
                    if key not in replacements:
                        replacements[key] = clone_module(h.modules[key])
                    replacements[key].__dict__[name] = common
                for key, value in replacements.items():
                    h.modules[key] = value
                    alias = 'importlib._bootstrap' if key == '_frozen_importlib' else 'importlib._bootstrap_external'
                    h.modules[alias] = value
                self.graph_error(h, 'derived anchor distinctness', phase='ANCHORS')

    def test_every_base_tuple_entry_and_length_through_graph(self):
        names = ('ModuleSpec', 'FileLoader', 'SourceLoader', 'LoaderBasics',
                 'SourceFileLoader', 'ExtensionFileLoader', 'FrozenImporter')
        for name in names:
            width = 2 if name in ('SourceFileLoader', 'ExtensionFileLoader') else 1
            for slot in range(width + 1):
                h = self.fresh()
                r = h.checker.refs
                selected = getattr(r, name)
                original = r.getset_get_intrinsic
                count = []
                def read(descriptor, receiver, owner, *, count=count, original=original, r=r, selected=selected, slot=slot, width=width):
                    result = original(descriptor, receiver, owner)
                    if descriptor is r.type_bases_descriptor and receiver is selected:
                        count.append(True)
                        if slot == width:
                            return ()
                        changed = list(result)
                        changed[slot] = type
                        return tuple(changed)
                    return result
                with patch.object(r, 'getset_get_intrinsic', read):
                    message = ('derived exact double base identity' if width == 2
                               else 'derived exact single base identity')
                    self.graph_error(h, message, phase='ANCHORS')
                self.assertEqual(len(count), 1)

    def test_actual_sys_binding_missing_changed_wrong_type_at_every_frontier(self):
        for frontier in ('graph', 'start', 'final'):
            for mode in ('missing', 'replace', 'wrong-type', 'collision'):
                h = self.fresh()
                c, r = h.checker, h.checker.refs
                original = CHECKER.DerivedChecker.native
                held = r.modules_dict
                count = []
                poison = Collision()
                def native(checker, role, descriptor, receiver, owner, name, *, count=count, held=held, mode=mode, original=original, poison=poison, r=r):
                    result = original(checker, role, descriptor, receiver, owner, name)
                    if receiver is r.sys_actual:
                        count.append(True)
                        result = dict(result)
                        if mode == 'missing':
                            del result['modules']
                        elif mode == 'replace':
                            result['modules'] = dict(held)
                        elif mode == 'wrong-type':
                            result['modules'] = object()
                        else:
                            result[poison] = None
                            Collision.calls = 0
                    return result
                action = {'graph': lambda *, c=c: c.graph(recheck=True),
                          'start': c.start_roster, 'final': c.final_roster}[frontier]
                c.state.stage = 'RECHECK'
                expected = {'missing': 'derived missing required field',
                            'replace': 'derived actual sys modules first identity changed',
                            'wrong-type': 'derived modules exact dict',
                            'collision': 'derived exact text prelength'}[mode]
                with patch.object(CHECKER.DerivedChecker, 'native', native):
                    h.error(action, expected, 'KEYS' if mode == 'collision' else 'RECHECK')
                self.assertIs(r.modules_dict, held)
                self.assertEqual(len(count), 1)
                self.assertEqual(Collision.calls, 0)

    def test_bootstrap_each_required_absence_optional_false_and_type(self):
        for key, alias in (('_frozen_importlib', 'importlib._bootstrap'),
                           ('_frozen_importlib_external', 'importlib._bootstrap_external')):
            for field in CHECKER.DERIVED_SPEC_KEYS[:-1]:
                h = self.fresh()
                provider = clone_module(h.modules[key])
                provider.__spec__ = clone_spec(provider.__spec__)
                namespace = provider.__spec__.__dict__
                namespace.pop('_initializing', None)
                del namespace[field]
                h.modules[key], h.modules[alias] = provider, provider
                self.graph_error(h, 'derived bootstrap key count', phase='ANCHORS')
            for initializing in ('absent', False, 0, None):
                h = self.fresh()
                provider = clone_module(h.modules[key])
                provider.__spec__ = clone_spec(provider.__spec__)
                namespace = provider.__spec__.__dict__
                if initializing == 'absent':
                    namespace.pop('_initializing', None)
                else:
                    namespace['_initializing'] = initializing
                h.modules[key], h.modules[alias] = provider, provider
                if initializing == 'absent' or initializing is False:
                    h.checker.graph()
                else:
                    self.graph_error(h, 'derived bootstrap initialization', phase='ANCHORS')
            h = self.fresh()
            provider = clone_module(h.modules[key])
            provider.__spec__ = Opaque()
            h.modules[key], h.modules[alias] = provider, provider
            Opaque.calls = 0
            self.graph_error(h, 'derived exact spec receiver', phase='ANCHORS')
            self.assertEqual(Opaque.calls, 0)

    def test_direct_dictionary_subclasses_properties_and_getters_not_called(self):
        class HostileModule(type(sys)):
            calls = 0
            def __getattribute__(self, name):
                HostileModule.calls += 1
                raise RuntimeError('candidate module getter')
            def __getattr__(self, name):
                HostileModule.calls += 1
                raise RuntimeError('candidate fallback getter')
            @property
            def __dict__(self):
                HostileModule.calls += 1
                raise RuntimeError('candidate dictionary property')
        class HostileSpec:
            calls = 0
            @property
            def __dict__(self):
                HostileSpec.calls += 1
                raise RuntimeError('candidate spec property')
        candidate = HostileModule('candidate')
        spec = HostileSpec()
        for key in ('pyexpat', 'xml.parsers.expat', 'pyexpat.errors', 'pyexpat.model'):
            h = self.fresh()
            h.modules[key] = candidate
            h.modules['xml.parsers.expat.errors'] = h.modules['pyexpat.errors']
            h.modules['xml.parsers.expat.model'] = h.modules['pyexpat.model']
            HostileModule.calls = 0
            self.graph_error(h, 'derived exact role module', phase='ANCHORS')
            self.assertEqual(HostileModule.calls, 0)
        for key in ('pyexpat', 'xml.parsers.expat'):
            h = self.fresh()
            h.modules[key].__spec__ = spec
            HostileSpec.calls = 0
            self.graph_error(h, 'derived exact spec receiver')
            self.assertEqual(HostileSpec.calls, 0)

    def test_late_native_namespace_insertion_and_replacement_owned_selection(self):
        targets = ('sys', 'boot', 'external', 'bootSpec', 'externalSpec', 'machinery',
                   'classModule', 'classSpec', 'classLoader', 'specP', 'specW', 'loaderP',
                   'loaderW', 'roleE', 'roleM')
        for target in targets:
            for mode in ('insert', 'replace'):
                h = self.fresh()
                c = h.checker
                original_native = CHECKER.DerivedChecker.native
                original_next = next
                pending, mutations = [], []
                poison = Collision()
                def native(checker, role, descriptor, receiver, owner, name, *, h=h, original_native=original_native, pending=pending, target=target):
                    result = original_native(checker, role, descriptor, receiver, owner, name)
                    if self.collision_target(h, target, role, receiver):
                        result = dict(result)
                        pending.append(result)
                        if role == 'TYPE_NAMESPACE':
                            result = type(type.__dict__)(result)
                    return result
                def advance(iterator, default=None, *, mode=mode, mutations=mutations, original_next=original_next, pending=pending, poison=poison):
                    pair = original_next(iterator, default)
                    if pair is None and pending:
                        namespace = pending.pop()
                        if mode == 'replace':
                            key = original_next(iter(namespace))
                            del namespace[key]
                        namespace[poison] = None
                        Collision.calls = 0
                        mutations.append(True)
                    return pair
                with patch.object(CHECKER.DerivedChecker, 'native', native), patch.object(
                        CHECKER, 'next', advance, create=True):
                    if mode == 'insert':
                        h.error(lambda *, c=c: c.graph(recheck=True),
                                'derived namespace changed during capture', 'KEYS')
                    else:
                        # Count unchanged: owned pairs, not late foreign indexing, govern selection.
                        c.graph(recheck=True)
                self.assertTrue(mutations)
                self.assertEqual(Collision.calls, 0)


    def test_registered_mapping_collision_keys_at_graph_and_roster_frontiers(self):
        for frontier in ('graph', 'start', 'final'):
            for kind in ('collision', 'str-subclass'):
                h = self.fresh()
                key = Collision() if kind == 'collision' else StringKey('pyexpat')
                h.modules[key] = None
                Collision.calls, StringKey.calls = 0, 0
                action = {'graph': lambda *, h=h: h.checker.graph(recheck=True),
                          'start': h.checker.start_roster,
                          'final': h.checker.final_roster}[frontier]
                h.error(action, 'derived exact text prelength', 'KEYS')
                self.assertEqual(Collision.calls, 0)
                self.assertEqual(StringKey.calls, 0)

    def test_closed_spec_and_loader_unknown_replacing_required_key(self):
        for key in ('pyexpat', 'xml.parsers.expat'):
            for field in ('__spec__', '__loader__'):
                h = self.fresh()
                namespace = h.modules[key].__dict__[field].__dict__
                del namespace['name']
                namespace['unknown'] = Opaque()
                Opaque.calls = 0
                self.graph_error(h, 'derived unknown closed key')
                self.assertEqual(Opaque.calls, 0)

    def test_optional_none_presence_cache_and_required_wrapper_cache(self):
        for key in ('pyexpat.errors', 'pyexpat.model', 'pyexpat'):
            for field in ('__file__', '__cached__'):
                if key == 'pyexpat' and field == '__file__':
                    continue
                for present in (False, True):
                    h = self.fresh()
                    namespace = h.modules[key].__dict__
                    if present:
                        namespace[field] = None
                    else:
                        namespace.pop(field, None)
                    h.checker.graph(recheck=True)
        for mode in ('missing', 'none', 'subclass', 'wrong'):
            h = self.fresh()
            namespace = h.modules['xml.parsers.expat'].__dict__
            if mode == 'missing':
                del namespace['__cached__']
                expected = 'derived missing required field'
            else:
                namespace['__cached__'] = {'none': None, 'subclass': StringKey('cache'),
                                           'wrong': '/wrong'}[mode]
                expected = ('derived exact text mismatch' if mode == 'wrong'
                            else 'derived exact text prelength')
            StringKey.calls = 0
            self.graph_error(h, expected)
            self.assertEqual(StringKey.calls, 0)

    def test_loader_and_spec_subclasses_and_methods_are_never_dispatched(self):
        for key in ('pyexpat', 'xml.parsers.expat'):
            h = self.fresh()
            original_loader = h.modules[key].__loader__
            class LoaderSubclass(type(original_loader)):
                calls = 0
                def __getattribute__(self, name):
                    LoaderSubclass.calls += 1
                    raise RuntimeError('candidate loader getter')
                def get_filename(self, name):
                    LoaderSubclass.calls += 1
                    raise RuntimeError('candidate loader method')
                def __eq__(self, other):
                    LoaderSubclass.calls += 1
                    raise RuntimeError('candidate loader equality')
                def __hash__(self):
                    LoaderSubclass.calls += 1
                    raise RuntimeError('candidate loader hash')
            candidate = LoaderSubclass(original_loader.name, original_loader.path)
            h.modules[key].__loader__ = candidate
            LoaderSubclass.calls = 0
            self.graph_error(h, 'derived exact loader type')
            self.assertEqual(LoaderSubclass.calls, 0)
            h = self.fresh()
            original_spec = h.modules[key].__spec__
            class SpecSubclass(type(original_spec)):
                calls = 0
                def __getattribute__(self, name):
                    SpecSubclass.calls += 1
                    raise RuntimeError('candidate spec getter')
            candidate = object.__new__(SpecSubclass)
            object.__getattribute__(candidate, '__dict__').update(original_spec.__dict__)
            h.modules[key].__spec__ = candidate
            SpecSubclass.calls = 0
            self.graph_error(h, 'derived exact spec receiver')
            self.assertEqual(SpecSubclass.calls, 0)


if __name__ == '__main__':
    unittest.main()

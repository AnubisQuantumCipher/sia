"""SAVED_UNRUN production observe/main, cleanup and late-output cases.

Synthetic read-only SDK endpoint responses exercise real production decisions;
these fixtures never supply SDK qualification or install modules into sys.
"""
import hashlib
import json
import sys
import unittest
from contextlib import ExitStack
from types import SimpleNamespace
from unittest.mock import patch

from test_support import PROBE, fixture_modules, zero_clock


class Stream:
    def __init__(self, write_error=None, flush_error=None, short=False):
        self.parts, self.writes, self.flushes = [], 0, 0
        self.write_error, self.flush_error, self.short = write_error, flush_error, short

    def write(self, value):
        self.writes += 1
        if self.write_error is not None:
            raise self.write_error
        if self.writes > 8192 or type(value) is not str or len(value) > 1024:
            raise ValueError('fixture bounded write')
        self.parts.append(value)
        return len(value) - 1 if self.short else len(value)

    def flush(self):
        self.flushes += 1
        if self.flush_error is not None:
            raise self.flush_error
        return None


def fixture_dependency_paths(modules):
    """Complete bounded synthetic file closure of the actual finite fixture rows."""
    if type(modules) is not dict or len(modules) > 64:
        raise ValueError('fixture module dependency bound')
    paths = {PROBE.DERIVED_SO: None, PROBE.DERIVED_PY: None, PROBE.DERIVED_PYC: None}
    for module in modules.values():
        if type(module) is not type(sys):
            raise ValueError('fixture exact ModuleType dependency')
        namespace = module.__dict__
        for field in ('__file__', '__cached__'):
            value = namespace.get(field)
            if value is not None:
                if type(value) is not str or len(value) > 4096 or not value.startswith('/'):
                    raise ValueError('fixture exact dependency path')
                paths[value] = None
                if len(paths) > 64:
                    raise ValueError('fixture file dependency bound')
        spec = namespace.get('__spec__')
        if spec is not None:
            value = spec.__dict__.get('origin')
            if type(value) is str and value.startswith('/'):
                if len(value) > 4096:
                    raise ValueError('fixture origin dependency bound')
                paths[value] = None
                if len(paths) > 64:
                    raise ValueError('fixture file dependency bound')
    return paths


class ObserveIO:
    """At most64 synthetic descriptor acquisitions; no actual descriptor calls."""

    def __init__(self):
        self.modules = fixture_modules()
        self.paths, self.positions, self.closes = [None] * 64, [0] * 64, [0] * 64
        self.used, self.imports = 0, 0
        self.file_identity = dict(st_dev=0, st_ino=7, st_mode=0o100444, st_nlink=1,
                                  st_uid=0, st_gid=0, st_size=1,
                                  st_mtime_ns=1, st_ctime_ns=1)
        self.row = {'identity': self.file_identity, 'sha256': hashlib.sha256(b'x').hexdigest()}
        self.cohort = {'errors': [], 'files': {}, 'directories': {}, 'aliases': {},
                       'negative_lookup': {}, 'excluded_origins': {}, 'probe_source': self.row}
        self.dependency_paths = fixture_dependency_paths(self.modules)
        for path in self.dependency_paths:
            self.cohort['files'][path] = self.row
        self.cohort_bytes = json.dumps(self.cohort).encode('utf-8')
        self.maps_bytes = ('1000-2000 r-xp 00000000 00:00 7 ' + PROBE.DERIVED_SO + '\n').encode()

    def payload(self, path):
        if path == PROBE.OUT + 'SELECTED-COHORTS.json':
            return self.cohort_bytes
        if path == '/proc/self/maps':
            return self.maps_bytes
        if path in self.cohort['files']:
            return b'x'
        raise ValueError('fixture unexpected actual read path')

    def opened(self, path, flags):
        if self.used == 64:
            raise ValueError('fixture fd budget')
        self.payload(path)
        index = self.used
        self.used += 1
        self.paths[index] = path
        return 100 + index

    def read(self, number, count):
        index = number - 100
        if type(count) is not int or not 0 < count <= 65536 or not 0 <= index < self.used:
            raise ValueError('fixture bounded read arguments')
        raw, position = self.payload(self.paths[index]), self.positions[index]
        block = raw[position:position + count]
        self.positions[index] += len(block)
        return block

    def stat(self, number):
        path = self.paths[number - 100]
        return self.lstat(path)

    def lstat(self, path):
        value = dict(self.file_identity)
        if path == PROBE.OUT + 'SELECTED-COHORTS.json':
            value['st_size'] = len(self.cohort_bytes)
        elif path == '/proc/self/maps':
            value['st_size'] = 0
        elif path not in self.cohort['files']:
            raise ValueError('fixture unexpected stat path')
        return SimpleNamespace(**value)

    def close(self, number):
        index = number - 100
        if not 0 <= index < self.used or self.closes[index]:
            raise ValueError('fixture duplicate or unauthorized close')
        self.closes[index] += 1
        return None

    def native(self, original):
        def read(checker, role, descriptor, receiver, owner, name):
            result = original(checker, role, descriptor, receiver, owner, name)
            if role == 'MODULE_NAMESPACE' and receiver is sys:
                result = dict(result)
                result['modules'] = self.modules
            return result
        return read

    def install(self, stack):
        stack.enter_context(patch.object(PROBE.time, 'monotonic_ns', zero_clock))
        stack.enter_context(patch.object(PROBE.os, 'open', side_effect=self.opened))
        stack.enter_context(patch.object(PROBE.os, 'read', side_effect=self.read))
        stack.enter_context(patch.object(PROBE.os, 'fstat', side_effect=self.stat))
        stack.enter_context(patch.object(PROBE.os, 'lstat', side_effect=self.lstat))
        stack.enter_context(patch.object(PROBE.os, 'close', side_effect=self.close))
        stack.enter_context(patch.object(PROBE.os.path, 'realpath', side_effect=lambda path: path))
        stack.enter_context(patch.object(PROBE.os.path, 'exists', return_value=True))
        stack.enter_context(patch.object(PROBE.DerivedChecker, 'native',
                                        self.native(PROBE.DerivedChecker.native)))
        stack.enter_context(patch.object(PROBE.sys, 'path',
                                        ['/usr/lib/python314.zip', '/usr/lib/python3.14',
                                         '/usr/lib/python3.14/lib-dynload',
                                         '/usr/lib/python3.14/site-packages']))
        stack.enter_context(patch.object(PROBE.sys, 'executable', '/usr/bin/python3.14'))
        stack.enter_context(patch.object(PROBE.sys, 'argv', ['origin_probe.py', '1', '5000000001']))

    def assert_closed(self, case):
        case.assertGreater(self.used, 0)
        for index in range(self.used):
            case.assertEqual(self.closes[index], 1)


class MainProduction(unittest.TestCase):
    def invoke(self, io=None, stream=None, patches=()):
        io = ObserveIO() if io is None else io
        stream = Stream() if stream is None else stream
        state = PROBE.ProbeState()
        original_imports = PROBE.import_selected
        def selected():
            io.imports += 1
            return original_imports()
        with ExitStack() as stack:
            io.install(stack)
            stack.enter_context(patch.object(PROBE, 'import_selected', selected))
            stack.enter_context(patch.object(PROBE.sys, 'stdout', stream))
            for target in patches:
                stack.enter_context(target)
            code = PROBE.run_main(state)
        return code, state, io, stream

    def positive(self):
        code, state, io, stream = self.invoke()
        self.assertEqual(code, 0)
        self.assertEqual(state.used, 0)
        self.assertEqual(io.imports, 1)
        io.assert_closed(self)
        self.assertGreater(stream.writes, 0)
        self.assertEqual(stream.flushes, 1)
        record = json.loads(''.join(stream.parts))
        self.assertFalse(record['acceptance'])
        self.assertIn('PENDING_ROOT_READBACK', record['status'])
        self.assertEqual(len(record['observation']['modules']), len(io.modules))
        for row in record['observation']['modules']:
            self.assertEqual(set(row), {'name', 'origin'})
        self.assertEqual(record['observation']['derived_ceiling'],
                         'RELATIONSHIP_NOT_CREATOR_ABI_OR_AUTHORITY')
        self.assertEqual(record['observation']['trusted_installed_sdk_premise'],
                         'ASSUMED_NOT_PROVED')
        opened = set(io.paths[:io.used])
        self.assertTrue(set(io.dependency_paths).issubset(opened))
        self.assertEqual(set(io.cohort['files']), set(io.dependency_paths))
        self.assertEqual(record['observation']['maps']['regular_origins'], [PROBE.DERIVED_SO])
        self.assertTrue(all(value is None for value in state.diagnostic_refs))
        return record

    def test_full_observe_positive_real_import_body_and_native_decisions(self):
        self.positive()

    def test_primary_read_refusal_still_closes_and_emits_nonpass(self):
        self.positive()
        io, primary = ObserveIO(), OSError('actual read seam')
        original = io.read
        def read(number, count):
            if io.paths[number - 100] == '/proc/self/maps':
                raise primary
            return original(number, count)
        io.read = read
        code, state, io, stream = self.invoke(io)
        self.assertEqual(code, 1)
        self.assertIs(state.raw[0], primary)
        self.assertEqual(state.phases[0], 'read')
        io.assert_closed(self)
        self.assertIsNone(json.loads(''.join(stream.parts))['observation'])

    def test_actual_write_and_flush_simultaneous_faults_preserved(self):
        self.positive()
        primary, secondary = OSError('write'), OSError('flush')
        code, state, io, stream = self.invoke(stream=Stream(primary, secondary))
        self.assertEqual(code, 1)
        self.assertIs(state.raw[0], primary)
        self.assertIs(state.raw[1], secondary)
        self.assertEqual(state.phases[:2], ['stdout-write', 'stdout-flush'])
        self.assertEqual(stream.writes, 1)
        self.assertEqual(stream.flushes, 1)
        io.assert_closed(self)

    def test_flush_only_and_short_actual_write_are_nonpass(self):
        self.positive()
        error = OSError('flush only')
        for stream in (Stream(flush_error=error), Stream(short=True)):
            with self.subTest(short=stream.short):
                code, state, io, returned_stream = self.invoke(stream=stream)
                self.assertIs(returned_stream, stream)
                self.assertEqual(code, 1)
                self.assertEqual(stream.flushes, 1)
                if stream.short:
                    self.assertEqual(state.raw[0].args, ('SDK stdout exact complete write return',))
                    self.assertEqual(state.phases[0], 'stdout-write')
                else:
                    self.assertIs(state.raw[0], error)
                    self.assertEqual(state.phases[0], 'stdout-flush')
                io.assert_closed(self)

    def test_late_record_preparation_and_encoder_errors_are_guarded(self):
        self.positive()
        for seam in ('new_record',):
            error = OSError('late record')
            with self.subTest(seam=seam):
                code, state, io, stream = self.invoke(patches=(
                    patch.object(PROBE, seam, side_effect=error),))
                self.assertEqual(code, 1)
                self.assertIs(state.raw[0], error)
                self.assertEqual(state.phases[0], 'serializer')
                self.assertFalse(json.loads(''.join(stream.parts))['diagnostics_complete'])
                io.assert_closed(self)
        error = OSError('bounded scalar encoder')
        code, state, io, stream = self.invoke(patches=(
            patch.object(PROBE.json, 'dumps', side_effect=error),))
        self.assertEqual(code, 1)
        self.assertIs(state.raw[0], error)
        self.assertEqual(state.phases[0], 'serializer')
        io.assert_closed(self)

    def test_output_preparation_failure_precedes_any_sdk_open(self):
        error = MemoryError('fixed output buffer')
        code, state, io, _stream = self.invoke(patches=(
            patch.object(PROBE, 'new_output_buffer', side_effect=error),))
        self.assertEqual(code, 1)
        self.assertIs(state.raw[0], error)
        self.assertEqual(state.phases[0], 'output-prepare')
        self.assertEqual(io.used, 0)

    def test_late_total_expiry_never_resets_deadline_or_returns_success(self):
        self.positive()
        original, expired = PROBE.Output.record, [False]
        def expire(output, record):
            original(output, record)
            expired[0] = True
        def clock():
            return 5000000001 if expired[0] else 0
        code, state, io, _stream = self.invoke(patches=(
            patch.object(PROBE.Output, 'record', expire),
            patch.object(PROBE.time, 'monotonic_ns', side_effect=clock)))
        self.assertEqual(code, 1)
        self.assertTrue(any(type(state.raw[index]) is TimeoutError for index in range(state.used)))
        self.assertEqual(state.total, 5000000001)
        io.assert_closed(self)


class CleanupProduction(unittest.TestCase):
    def setUp(self):
        self.clock = patch.object(PROBE.time, 'monotonic_ns', zero_clock)
        self.clock.start()
        self.addCleanup(self.clock.stop)
        self.state = PROBE.ProbeState()
        self.state.work, self.state.total = 1, 5000000001

    def test_partial_checker_preparation_keeps_actual_error_and_retires_cells(self):
        error, seen = MemoryError('second fixed array'), []
        original = PROBE.new_reference_array
        calls = 0
        def allocate(bound):
            nonlocal calls
            calls += 1
            if calls == 2:
                raise error
            return original(bound)
        real_retire = PROBE.retire_reference_cell
        def retire(array, index):
            seen.append(index)
            return real_retire(array, index)
        with patch.object(PROBE, 'new_reference_array', allocate):
            with patch.object(PROBE, 'retire_reference_cell', retire):
                with self.assertRaises(RuntimeError) as caught:
                    PROBE.build_checker(self.state)
        self.assertIs(caught.exception, self.state.failure)
        self.assertIs(self.state.raw[0], error)
        self.assertEqual(self.state.phases[0], 'checker-prepare')
        self.assertEqual(seen, list(range(8192)))

    def test_independent_peroccupied_scratch_row_selected_and_diagnostic_retirement(self):
        checker = PROBE.build_checker(self.state)
        sentinel = object()
        checker.keys[0], checker.values[0], checker.pair = sentinel, sentinel, (sentinel, sentinel)
        checker.rows[0]['_module'] = sentinel
        checker.refs.P = sentinel
        primary, secondary = OSError('scratch'), OSError('row')
        calls, original = [], PROBE.retire_reference_cell
        def retire(array, index):
            calls.append((array is checker.keys, index))
            if array is checker.keys and index == 0:
                raise primary
            return original(array, index)
        def row(value):
            if value is checker.rows[0]:
                raise secondary
            return None
        with patch.object(PROBE, 'retire_reference_cell', retire):
            with patch.object(PROBE, 'retire_roster_module', row):
                checker.clear()
        self.assertEqual(len(calls), 16384)
        self.assertIs(self.state.raw[0], primary)
        self.assertIs(self.state.raw[1], secondary)
        self.assertEqual(self.state.phases[:2], ['scratch-clear', 'roster-reference-clear'])
        self.assertIsNone(checker.refs.P)
        self.assertIsNone(checker.pair)
        for index in range(192):
            self.state.diagnostic_refs[index] = sentinel
        attempts = []
        def diagnostic_retire(array, index):
            attempts.append(index)
            if index in (0, 191):
                raise primary if index == 0 else secondary
            return original(array, index)
        with patch.object(PROBE, 'retire_reference_cell', diagnostic_retire):
            PROBE.clear_diagnostics(self.state, PROBE.Capture(self.state, 'diagnostic-reference-clear'))
        self.assertEqual(attempts, list(range(192)))
        self.assertIs(self.state.raw[2], primary)
        self.assertIs(self.state.raw[3], secondary)

    def test_raw64_overflow_still_attempts_all_remaining_cleanup(self):
        for index in range(64):
            self.state.raw[index], self.state.phases[index] = OSError('occupied'), 'fixture'
        self.state.used = 64
        attempts, error = [], OSError('overflow retirement')
        def refuse(_array, index):
            attempts.append(index)
            raise error
        with patch.object(PROBE, 'retire_reference_cell', refuse):
            PROBE.clear_diagnostics(self.state, PROBE.Capture(self.state, 'diagnostic-reference-clear'))
        self.assertEqual(attempts, list(range(192)))
        self.assertTrue(self.state.overflow)
        self.assertEqual(self.state.used, 64)


if __name__ == '__main__':
    unittest.main()

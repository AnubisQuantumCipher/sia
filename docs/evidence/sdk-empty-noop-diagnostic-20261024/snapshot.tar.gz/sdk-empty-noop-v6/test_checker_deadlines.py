"""SAVED_UNRUN local held-native/comparison original-work boundary oracles."""
import unittest
from unittest.mock import patch

from test_support import CHECKER, PROBE, Harness


ROLES = ('MODULE', 'TYPE', 'BASES', 'SPEC-P', 'SPEC-W', 'LOADER-P',
         'LOADER-W', 'JOIN-SPEC-P', 'JOIN-SPEC-W', 'JOIN-LOADER-P',
         'JOIN-LOADER-W', 'EXPORT-SPEC', 'EXPORT-LOADER')


def route(h, role):
    c, r = h.checker, h.checker.refs
    wrapper = role.endswith('-W')
    module = h.modules['xml.parsers.expat' if wrapper else 'pyexpat']
    name, path, package, cached = ('xml.parsers.expat', CHECKER.DERIVED_PY, 'xml.parsers', CHECKER.DERIVED_PYC) if wrapper else ('pyexpat', CHECKER.DERIVED_SO, '', None)
    if role == 'MODULE':
        return r.module_namespace_descriptor, module, lambda: c.module_namespace(module), 'ANCHORS'
    if role == 'TYPE':
        return r.type_namespace_descriptor, r.ModuleSpec, lambda: c.class_namespace(r.ModuleSpec), 'ANCHORS'
    if role == 'BASES':
        return r.type_bases_descriptor, r.ModuleSpec, lambda: c.bases(r.ModuleSpec), 'ANCHORS'
    if role.startswith('EXPORT'):
        cls = r.ModuleSpec if role == 'EXPORT-SPEC' else r.FileLoader
        field = 'spec_namespace_descriptor' if role == 'EXPORT-SPEC' else 'fileloader_namespace_descriptor'
        return getattr(r, field), cls, lambda: c.checked_descriptor(cls, field, True), 'RECHECK'
    is_spec = 'SPEC' in role
    descriptor = r.spec_namespace_descriptor if is_spec else r.fileloader_namespace_descriptor
    receiver = module.__spec__ if is_spec else module.__loader__
    if role.startswith('JOIN'):
        def action():
            return c.file_module(module, name, path, package, cached, True)
    elif is_spec:
        def action():
            return c.spec_namespace(receiver)
    else:
        cls = r.SourceFileLoader if wrapper else r.ExtensionFileLoader
        def action():
            return c.loader(receiver, cls, name, path)
    return descriptor, receiver, action, 'METADATA'


class NativeBoundary(unittest.TestCase):
    def fresh(self):
        if hasattr(self, 'harness'):
            self.harness = self.harness.fresh()
        else:
            self.harness = Harness(self)
        return self.harness.positive()

    def positive(self, role):
        h = self.fresh()
        descriptor, receiver, action, phase = route(h, role)
        h.state.stage = phase
        action()
        self.assertEqual(h.state.used, 0)
        return h, descriptor, receiver, action, phase

    def exercise(self, role, mode):
        h, descriptor, receiver, action, phase = self.positive(role)
        c, r = h.checker, h.checker.refs
        expired, entered, operations, metadata = [False], [], [], []
        primary = OSError('actual held native primary')
        native, member, getset = CHECKER.DerivedChecker.native, r.member_get_intrinsic, r.getset_get_intrinsic
        attribute, text, required = r.object_getattribute_intrinsic, CHECKER.DerivedChecker.same_text, CHECKER.DerivedChecker.required
        def clock():
            return h.state.work if expired[0] else 0
        def boundary(checker, operation, selected, target, owner, name):
            if checker is c and selected is descriptor and target is receiver:
                entered.append(True)
                if mode == 'before':
                    expired[0] = True
            return native(checker, operation, selected, target, owner, name)
        def exported(checker, name):
            result = required(checker, name)
            if checker is c and name == '__dict__' and result is descriptor and mode == 'before':
                entered.append(True)
                expired[0] = True
            return result
        def read(selected, name):
            result = attribute(selected, name)
            if selected is descriptor:
                metadata.append(name)
                if mode.startswith('owner') and name == '__objclass__':
                    expired[0] = True
                    if mode.endswith('primary'):
                        raise primary
                if mode.startswith('name') and name == '__name__':
                    expired[0] = True
                    if mode.endswith('primary'):
                        raise primary
            return result
        def compare(checker, value, expected, points=256, byte_limit=1024):
            result = text(checker, value, expected, points, byte_limit)
            if checker is c and metadata and metadata[-1] == '__name__' and mode == 'operation-before':
                expired[0] = True
            return result
        def operate(original, selected, target, owner):
            result = original(selected, target, owner)
            if selected is descriptor and target is receiver:
                operations.append(True)
                if mode in ('operation-after', 'operation-primary'):
                    expired[0] = True
                    if mode == 'operation-primary':
                        raise primary
            return result
        def member_read(selected, target, owner):
            return operate(member, selected, target, owner)
        def getset_read(selected, target, owner):
            return operate(getset, selected, target, owner)
        self.run_armed(h, role, mode, action, phase, primary, descriptor,
                       (clock, boundary, exported, read, compare, member_read, getset_read),
                       entered, operations, metadata)

    def run_armed(self, h, role, mode, action, phase, primary, descriptor,
                  seams, entered, operations, metadata):
        clock, boundary, exported, read, compare, member_read, getset_read = seams
        c, r = h.checker, h.checker.refs
        with patch.object(CHECKER.time, 'monotonic_ns', clock), patch.object(
                CHECKER.DerivedChecker, 'native', boundary), patch.object(
                CHECKER.DerivedChecker, 'required', exported), patch.object(
                CHECKER.DerivedChecker, 'same_text', compare), patch.object(
                r, 'object_getattribute_intrinsic', read), patch.object(
                r, 'member_get_intrinsic', member_read), patch.object(r, 'getset_get_intrinsic', getset_read):
            with PROBE.Capture(h.state, 'origin-probe'):
                action()
            self.assertEqual(h.state.used, 1)
            self.assertEqual(h.state.phases[0], phase)
            self.assertEqual(h.state.stage, phase)
            if mode.endswith('primary'):
                self.assertIs(h.state.raw[0], primary)
            else:
                self.assertIs(type(h.state.raw[0]), TimeoutError)
                self.assertEqual(h.state.raw[0].args, ('derived original work deadline',))
            if mode == 'before':
                self.assertTrue(entered)
                self.assertEqual(metadata, [])
            if mode.startswith('owner'):
                self.assertEqual(metadata, ['__objclass__'])
            if mode.startswith('name'):
                self.assertEqual(metadata, ['__objclass__', '__name__'])
            if role.startswith('EXPORT'):
                field = 'spec_namespace_descriptor' if role == 'EXPORT-SPEC' else 'fileloader_namespace_descriptor'
                self.assertIs(getattr(r, field), descriptor)
            self.assertEqual(operations, [True] if mode.startswith('operation-')
                             and mode != 'operation-before' else [])
            self.assertEqual((h.state.work, h.state.total), (1, 5000000001))
            c.clear()
            self.assertEqual(h.state.used, 1)
            self.assertTrue(all(value is None for value in c.keys))
            self.assertTrue(all(value is None for value in c.values))
            for field in CHECKER.DerivedRefs.__slots__:
                self.assertIsNone(getattr(r, field))

    def test_all_held_roles_and_export_before_after_metadata_deadlines(self):
        for role in ROLES:
            for mode in ('before', 'owner-after', 'name-after', 'owner-primary', 'name-primary'):
                self.exercise(role, mode)

    def test_all_held_operations_before_after_and_primary_precedence(self):
        for role in ROLES:
            if not role.startswith('EXPORT'):
                for mode in ('operation-before', 'operation-after', 'operation-primary'):
                    self.exercise(role, mode)


class ExactTextBoundary(unittest.TestCase):
    def test_validated_exact_string_comparison_before_after_and_primary_precedence(self):
        for mode in ('equal-before', 'equal-after', 'equal-within',
                     'unequal-before', 'unequal-after', 'unequal-within'):
            h = Harness(self).positive()
            c = h.checker
            c.state.stage = 'METADATA'
            c.same_text('validated', 'validated')
            original, validations, armed, ticks = CHECKER.DerivedChecker.text, [], [False], [0]
            def text(checker, value, points=256, byte_limit=1024, empty=True, *, armed=armed, c=c, original=original, validations=validations):
                result = original(checker, value, points, byte_limit, empty)
                if checker is c:
                    validations.append(value)
                    if len(validations) == 2:
                        armed[0] = True
                return result
            def clock(*, armed=armed, h=h, mode=mode, ticks=ticks):
                if armed[0]:
                    ticks[0] += 1
                    if mode.endswith('before') or (mode.endswith('after') and ticks[0] >= 2):
                        return h.state.work
                return 0
            result = 'not-returned'
            with patch.object(CHECKER.DerivedChecker, 'text', text):
                with patch.object(CHECKER.time, 'monotonic_ns', clock):
                    with PROBE.Capture(h.state, 'origin-probe'):
                        result = c.same_text('validated', 'different' if mode.startswith('unequal')
                                             else 'validated')
            self.assertEqual(len(validations), 2)
            self.assertEqual(ticks[0], 1 if mode.endswith('before') else 2)
            expected_used = 0 if mode == 'equal-within' else 1
            self.assertEqual(h.state.used, expected_used)
            if mode == 'equal-within':
                self.assertIsNone(result)
            else:
                self.assertEqual(result, 'not-returned')
                self.assertEqual(h.state.phases[0], 'METADATA')
                if mode == 'unequal-within':
                    self.assertIs(type(h.state.raw[0]), ValueError)
                    self.assertEqual(h.state.raw[0].args, ('derived exact text mismatch',))
                else:
                    self.assertIs(type(h.state.raw[0]), TimeoutError)
                    self.assertEqual(h.state.raw[0].args, ('derived original work deadline',))
            self.assertEqual((h.state.work, h.state.total), (1, 5000000001))
            c.clear()
            self.assertEqual(h.state.used, expected_used)
            self.assertTrue(all(value is None for value in c.keys))
            self.assertTrue(all(value is None for value in c.values))
            for field in CHECKER.DerivedRefs.__slots__:
                self.assertIsNone(getattr(c.refs, field))
            h.close()


if __name__ == '__main__':
    unittest.main()

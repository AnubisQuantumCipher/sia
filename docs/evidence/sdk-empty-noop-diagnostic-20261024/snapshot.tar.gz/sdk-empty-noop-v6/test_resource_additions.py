"""SAVED_UNRUN actual partial-owner, occupied cleanup and main-return cases."""
import json
import unittest
from unittest.mock import patch

import test_main_resources as main_cases
from test_support import PROBE, zero_clock


class ReturnedStream(main_cases.Stream):
    def __init__(self, returned, flush_return=False):
        super().__init__()
        self.returned, self.flush_return = returned, flush_return

    def write(self, value):
        actual = super().write(value)
        return actual if self.flush_return else self.returned

    def flush(self):
        actual = super().flush()
        return self.returned if self.flush_return else actual


class IntSubclass(int):
    pass


class PartialOwners(unittest.TestCase):
    def setUp(self):
        clock = patch.object(PROBE.time, 'monotonic_ns', zero_clock)
        clock.start()
        self.addCleanup(clock.stop)

    def state(self):
        state = PROBE.ProbeState()
        state.work, state.total = 1, 5000000001
        return state

    def positive(self):
        state = self.state()
        checker = PROBE.build_checker(state)
        checker.clear()
        self.assertEqual(state.used, 0)
        return state

    def test_initial_refs_each_array_and_first_later_last_row_preparation_failures(self):
        cases = (('new_derived_refs', 1), ('new_reference_array', 1),
                 ('new_reference_array', 2), ('new_reference_array', 3),
                 ('new_roster_row', 1), ('new_roster_row', 2), ('new_roster_row', 8192))
        for seam, fail_at in cases:
            self.positive()
            state, primary = self.state(), MemoryError('actual preparation seam')
            original, calls, owned = getattr(PROBE, seam), [0], []
            original_init = PROBE.DerivedChecker.__init__
            def observe(checker, value, preparation_guard=None, *, original_init=original_init, owned=owned):
                owned.append(checker)
                return original_init(checker, value, preparation_guard)
            def prepare(*args, calls=calls, fail_at=fail_at, original=original, primary=primary):
                calls[0] += 1
                if calls[0] == fail_at:
                    raise primary
                return original(*args)
            with patch.object(PROBE.DerivedChecker, '__init__', observe):
                with patch.object(PROBE, seam, prepare):
                    with self.assertRaises(RuntimeError) as caught:
                        PROBE.build_checker(state)
            self.assertIs(caught.exception, state.failure)
            self.assertIs(state.raw[0], primary)
            self.assertEqual(state.phases[0], 'checker-prepare')
            self.assertEqual(len(owned), 1)
            checker = owned[0]
            for array in (checker.keys, checker.values):
                if array is not None:
                    self.assertTrue(all(value is None for value in array))
            if checker.refs is not None:
                for field in PROBE.DerivedRefs.__slots__:
                    self.assertIsNone(getattr(checker.refs, field))

    def test_seed_failure_actual_occupied_refs_and_secondary_all_independent(self):
        self.positive()
        state, primary, secondary = self.state(), OSError('seed failure'), OSError('selected release')
        original_seed, original_retire = PROBE.DerivedChecker.seed_intrinsics, PROBE.retire_owned_attribute
        attempts, owned = [], []
        def seed(checker):
            original_seed(checker)
            owned.append(checker)
            raise primary
        def retire(value, field):
            if owned and value is owned[0].refs:
                attempts.append(field)
                if field == 'sys_actual':
                    raise secondary
            return original_retire(value, field)
        with patch.object(PROBE.DerivedChecker, 'seed_intrinsics', seed):
            with patch.object(PROBE, 'retire_owned_attribute', retire):
                with self.assertRaises(RuntimeError) as caught:
                    PROBE.build_checker(state)
        self.assertIs(caught.exception, state.failure)
        self.assertIs(state.raw[0], primary)
        self.assertIs(state.raw[1], secondary)
        self.assertEqual(state.phases[:2], ['checker-prepare', 'selected-reference-clear'])
        self.assertEqual(attempts, list(PROBE.DerivedRefs.__slots__))
        self.assertIs(owned[0].refs.sys_actual, PROBE.sys)
        for field in PROBE.DerivedRefs.__slots__:
            if field != 'sys_actual':
                self.assertIsNone(getattr(owned[0].refs, field))
        owned[0].clear()

    def test_each_occupied_current_reference_failure_cannot_skip_later_occupied_rows(self):
        for failed in ('pair', 'current_key', 'current_value'):
            self.positive()
            state = self.state()
            checker = PROBE.build_checker(state)
            marker, first, later = object(), object(), object()
            checker.pair, checker.current_key, checker.current_value = marker, marker, marker
            checker.rows[0]['_module'], checker.rows[8191]['_module'] = first, later
            primary, secondary = OSError('current ref'), OSError('first row ref')
            original_attr, original_row = PROBE.retire_owned_attribute, PROBE.retire_roster_module
            fields, rows = [], []
            def attr(value, field, *, checker=checker, failed=failed, fields=fields, original_attr=original_attr, primary=primary):
                if value is checker:
                    fields.append(field)
                    if field == failed:
                        raise primary
                return original_attr(value, field)
            def row(value, *, checker=checker, original_row=original_row, rows=rows, secondary=secondary):
                rows.append(value)
                if value is checker.rows[0]:
                    raise secondary
                return original_row(value)
            with patch.object(PROBE, 'retire_owned_attribute', attr):
                with patch.object(PROBE, 'retire_roster_module', row):
                    checker.clear()
            self.assertEqual(fields, ['pair', 'current_key', 'current_value'])
            self.assertEqual(len(rows), 8192)
            self.assertIs(rows[-1], checker.rows[8191])
            self.assertIsNone(checker.rows[8191]['_module'])
            self.assertIs(checker.rows[0]['_module'], first)
            self.assertIs(state.raw[0], primary)
            self.assertIs(state.raw[1], secondary)
            self.assertEqual(state.phases[:2], ['scratch-clear', 'roster-reference-clear'])
            for field in ('pair', 'current_key', 'current_value'):
                self.assertIs(getattr(checker, field), marker if field == failed else None)
            checker.clear()

    def test_partial_capsule_init_capture_native_and_retirement_keep_primary_secondary(self):
        for seam in ('__init__', 'capture'):
            self.positive()
            state = self.state()
            checker = PROBE.build_checker(state)
            primary, secondary = OSError('capsule preparation'), OSError('capsule retirement')
            original = getattr(PROBE.DiagnosticCapsule, seam)
            original_retire, attempts = PROBE.retire_owned_attribute, []
            def prepare(capsule, *args, original=original, primary=primary):
                original(capsule, *args)
                raise primary
            with patch.object(PROBE.DiagnosticCapsule, seam, prepare):
                with PROBE.Capture(state, 'capsule-prepare'):
                    PROBE.prepare_diagnostics(state, checker)
            self.assertIsNotNone(state.capsule)
            def retire(value, field, *, attempts=attempts, original_retire=original_retire, secondary=secondary, state=state):
                if value is state.capsule:
                    attempts.append(field)
                    if field == 'kind':
                        raise secondary
                return original_retire(value, field)
            with patch.object(PROBE, 'retire_owned_attribute', retire):
                PROBE.clear_diagnostics(state, PROBE.Capture(state, 'capsule-clear'))
            self.assertEqual(attempts, list(PROBE.DiagnosticCapsule.__slots__))
            self.assertIs(state.raw[0], primary)
            self.assertIs(state.raw[1], secondary)
            self.assertEqual(state.phases[:2], ['capsule-prepare', 'capsule-clear'])
            checker.clear()


class MainLateCases(unittest.TestCase):
    def runner(self):
        return main_cases.MainProduction(methodName='test_full_observe_positive_real_import_body_and_native_decisions')

    def test_all_wrong_exact_write_returns_and_non_none_flush_status(self):
        runner = self.runner()
        runner.positive()
        for value in (None, True, 1.5, IntSubclass(1), -1, 2048):
            stream = ReturnedStream(value)
            code, state, io, stream = runner.invoke(stream=stream)
            self.assertEqual(code, 1)
            self.assertEqual(state.raw[0].args, ('SDK stdout exact complete write return',))
            self.assertEqual(state.phases[0], 'stdout-write')
            self.assertEqual(stream.writes, 1)
            self.assertEqual(stream.flushes, 1)
            io.assert_closed(self)
        for value in (False, 0, 1, 'not None'):
            code, state, io, stream = runner.invoke(stream=ReturnedStream(value, True))
            self.assertEqual(code, 1)
            self.assertEqual(state.raw[0].args, ('SDK stdout flush return',))
            self.assertEqual(state.phases[0], 'stdout-flush')
            self.assertEqual(stream.flushes, 1)
            io.assert_closed(self)

    def test_actual_flush_completion_total_expiry_is_raw_nonpass(self):
        runner = self.runner()
        runner.positive()
        expired = [False]
        class Expiring(main_cases.Stream):
            def flush(self):
                result = super().flush()
                expired[0] = True
                return result
        def clock():
            return 5000000001 if expired[0] else 0
        code, state, io, stream = runner.invoke(stream=Expiring(), patches=(
            patch.object(PROBE.time, 'monotonic_ns', side_effect=clock),))
        self.assertEqual(code, 1)
        self.assertIs(type(state.raw[0]), TimeoutError)
        self.assertEqual(state.phases[0], 'stdout-flush')
        self.assertEqual(stream.flushes, 1)
        self.assertEqual((state.work, state.total), (1, 5000000001))
        io.assert_closed(self)

    def test_actual_each_schema_output_boundary_failure_keeps_raw_and_clears_refs(self):
        runner = self.runner()
        runner.positive()
        methods = ('put', 'text', 'scalar', 'field', 'strings', 'mapping',
                   'module_rows', 'observation', 'diagnostic_rows', 'projection', 'record')
        for name in methods:
            primary, original, calls = OSError('late bounded output'), getattr(PROBE.Output, name), []
            def fail(output, *args, calls=calls, original=original, primary=primary, **kwargs):
                result = original(output, *args, **kwargs)
                calls.append(True)
                if len(calls) == 1:
                    raise primary
                return result
            code, state, io, _stream = runner.invoke(patches=(patch.object(PROBE.Output, name, fail),))
            self.assertEqual(code, 1)
            self.assertIs(state.raw[0], primary)
            self.assertEqual(state.phases[0], 'serializer')
            self.assertGreaterEqual(len(calls), 1)
            self.assertTrue(all(value is None for value in state.diagnostic_refs))
            for field in PROBE.DiagnosticCapsule.__slots__:
                self.assertIsNone(getattr(state.capsule, field))
            io.assert_closed(self)

    def test_full_main_overflow_retains_original64_and_null_nonaccepting_output(self):
        runner = self.runner()
        runner.positive()
        state = PROBE.ProbeState()
        state.work, state.total = 1, 5000000001
        checker = None
        io, stream = main_cases.ObserveIO(), main_cases.Stream()
        with main_cases.ExitStack() as stack:
            io.install(stack)
            checker = PROBE.build_checker(state)
            PROBE.prepare_diagnostics(state, checker)
            checker.clear()
            roots = [OSError('retained') for _ in range(64)]
            for index in range(64):
                state.raw[index], state.phases[index] = roots[index], 'ROOT'
            state.used = 64
            original_retire, actual = PROBE.retire_reference_cell, OSError('overflow cleanup')
            def retire(array, index):
                if array is state.diagnostic_refs and index == 0:
                    raise actual
                return original_retire(array, index)
            stack.enter_context(patch.object(PROBE, 'retire_reference_cell', retire))
            stack.enter_context(patch.object(PROBE.sys, 'stdout', stream))
            code = PROBE.run_main(state)
        self.assertEqual(code, 1)
        self.assertTrue(state.overflow)
        for index in range(64):
            self.assertIs(state.raw[index], roots[index])
        record = json.loads(''.join(stream.parts))
        self.assertFalse(record['acceptance'])
        self.assertEqual(record['status'], 'NONPASS')
        self.assertFalse(record['diagnostics_complete'])
        self.assertEqual(io.used, 0)


if __name__ == '__main__':
    unittest.main()

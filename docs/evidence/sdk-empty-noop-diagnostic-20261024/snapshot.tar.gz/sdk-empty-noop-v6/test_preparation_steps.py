"""SAVED_UNRUN occupied partial allocation and native preparation frontiers."""
import unittest
from unittest.mock import patch

from test_diagnostic_additions import DiagnosticFixture
from test_support import PROBE, zero_clock


class OccupiedPartialArrays(unittest.TestCase):
    def test_each_partial_array_has_owned_markers_and_every_existing_slot_retired(self):
        with patch.object(PROBE.time, 'monotonic_ns', zero_clock):
            for fail_at in (2, 3):
                state = PROBE.ProbeState()
                state.work, state.total = 1, 5000000001
                checker = PROBE.build_checker(state)
                checker.clear()
                self.assertEqual(state.used, 0)
                state, owned, allocations = PROBE.ProbeState(), [], [0]
                state.work, state.total = 1, 5000000001
                marker, primary, secondary = object(), OSError('array creation'), OSError('array release')
                original_init = PROBE.DerivedChecker.__init__
                original_array, original_retire = PROBE.new_reference_array, PROBE.retire_reference_cell
                attempts = []
                def observe(value, invocation, preparation_guard=None, *, original_init=original_init, owned=owned):
                    owned.append(value)
                    return original_init(value, invocation, preparation_guard)
                def allocate(bound, *, allocations=allocations, fail_at=fail_at, marker=marker, original_array=original_array, owned=owned, primary=primary):
                    allocations[0] += 1
                    if allocations[0] == fail_at:
                        owned[0].keys[0], owned[0].keys[8191] = marker, marker
                        if owned[0].values is not None:
                            owned[0].values[0], owned[0].values[8191] = marker, marker
                        raise primary
                    return original_array(bound)
                def retire(array, index, *, attempts=attempts, original_retire=original_retire, owned=owned, secondary=secondary):
                    attempts.append((array is owned[0].keys, index))
                    if array is owned[0].keys and index == 0:
                        raise secondary
                    return original_retire(array, index)
                with patch.object(PROBE.DerivedChecker, '__init__', observe):
                    with patch.object(PROBE, 'new_reference_array', allocate):
                        with patch.object(PROBE, 'retire_reference_cell', retire):
                            with self.assertRaises(RuntimeError) as caught:
                                PROBE.build_checker(state)
                self.assertIs(caught.exception, state.failure)
                self.assertIs(state.raw[0], primary)
                self.assertIs(state.raw[1], secondary)
                self.assertEqual(state.phases[:2], ['checker-prepare', 'scratch-clear'])
                self.assertIs(owned[0].keys[0], marker)
                self.assertIsNone(owned[0].keys[8191])
                self.assertEqual([index for keys, index in attempts if keys], list(range(8192)))
                if fail_at == 3:
                    self.assertEqual([index for keys, index in attempts if not keys], list(range(8192)))
                    self.assertTrue(all(value is None for value in owned[0].values))
                owned[0].clear()


class NativePreparation(DiagnosticFixture):
    def test_each_actual_capture_class_namespace_failure_clears_partial_capsule(self):
        for receiver in (type, BaseException):
            self.positive(0)
            state, primary, secondary = PROBE.ProbeState(), OSError('capture native'), OSError('capture release')
            state.work, state.total = 1, 5000000001
            checker = PROBE.build_checker(state)
            original, calls = PROBE.DerivedChecker.native, []
            def native(value, role, descriptor, target, owner, name, *, calls=calls, checker=checker, original=original, primary=primary, receiver=receiver):
                result = original(value, role, descriptor, target, owner, name)
                if value is checker and role == 'TYPE_NAMESPACE' and target is receiver:
                    calls.append(True)
                    raise primary
                return result
            with patch.object(PROBE.DerivedChecker, 'native', native):
                with PROBE.Capture(state, 'capsule-prepare'):
                    PROBE.prepare_diagnostics(state, checker)
            self.assertEqual(calls, [True])
            self.assertIs(state.raw[0], primary)
            self.assertEqual(state.phases[0], 'capsule-prepare')
            self.assertIs(state.capsule.base, BaseException)
            if receiver is BaseException:
                self.assertIsNotNone(state.capsule.mro_descriptor)
            attempts, retire = [], PROBE.retire_owned_attribute
            def release(value, field, *, attempts=attempts, retire=retire, secondary=secondary, state=state):
                if value is state.capsule:
                    attempts.append(field)
                    if field == 'base':
                        raise secondary
                return retire(value, field)
            with patch.object(PROBE, 'retire_owned_attribute', release):
                PROBE.clear_diagnostics(state, PROBE.Capture(state, 'capsule-clear'))
            self.assertEqual(attempts, list(PROBE.DiagnosticCapsule.__slots__))
            self.assertIs(state.raw[1], secondary)
            self.assertEqual(state.phases[1], 'capsule-clear')
            checker.clear()

    def test_each_route_owner_name_and_literal_budget_frontier(self):
        routes = ('args_descriptor', 'dict_descriptor', 'cause_descriptor', 'context_descriptor', 'mro_descriptor')
        for index in range(5):
            for mode in ('owner', 'actual-name', 'literal-name'):
                state, capsule, error = self.positive(index)
                descriptor, attribute, seen = getattr(capsule, routes[index]), capsule.attribute, []
                def read(selected, name, *, attribute=attribute, descriptor=descriptor, mode=mode, seen=seen, state=state):
                    result = attribute(selected, name)
                    if selected is descriptor and name == ('__objclass__' if mode == 'owner' else '__name__'):
                        seen.append(True)
                        if mode == 'literal-name':
                            state.read_bytes = 536870912 - 32 - 4 * len(result)
                        else:
                            state.read_bytes = 536870912 - 32
                    return result
                capsule.attribute = read
                self.raw(state, lambda *, capsule=capsule, error=error, index=index, state=state: self.call(state, capsule, index, error), ValueError,
                         'SDK aggregate preparation/text/output bound')
                self.assertEqual(seen, [True])

    def test_each_route_native_metadata_after_operation_total_expiry(self):
        routes = ('args_descriptor', 'dict_descriptor', 'cause_descriptor', 'context_descriptor', 'mro_descriptor')
        for index in range(5):
            for field in ('__objclass__', '__name__'):
                state, capsule, error = self.positive(index)
                descriptor, attribute, expired, seen = getattr(capsule, routes[index]), capsule.attribute, [False], []
                def read(selected, name, *, attribute=attribute, descriptor=descriptor, expired=expired, field=field, seen=seen):
                    result = attribute(selected, name)
                    if selected is descriptor and name == field:
                        seen.append(True)
                        expired[0] = True
                    return result
                def clock(*, expired=expired, state=state):
                    return state.total if expired[0] else 0
                capsule.attribute = read
                with patch.object(PROBE.time, 'monotonic_ns', side_effect=clock):
                    self.raw(state, lambda *, capsule=capsule, error=error, index=index, state=state: self.call(state, capsule, index, error),
                             TimeoutError, 'original absolute SDK probe deadline')
                self.assertEqual(seen, [True])

    def test_mro_repeat_work_budget_and_after_each_first_loop_frontier(self):
        state, capsule, error = self.positive(4)
        get, seen = capsule.get, []
        def read(descriptor, receiver, owner):
            result = get(descriptor, receiver, owner)
            if descriptor is capsule.mro_descriptor:
                seen.append(True)
                state.read_bytes = 536870912 - 32
            return result
        capsule.get = read
        self.raw(state, lambda: capsule.receiver(state, error), ValueError,
                 'SDK aggregate preparation/text/output bound')
        self.assertEqual(seen, [True])
        for expire_at in (1, 2):
            state, capsule, error = self.positive(4)
            get, step, after_get, steps, expired = capsule.get, PROBE.diagnostic_step, [False], [0], [False]
            def read(descriptor, receiver, owner, *, after_get=after_get, capsule=capsule, get=get):
                result = get(descriptor, receiver, owner)
                if descriptor is capsule.mro_descriptor:
                    after_get[0] = True
                return result
            def inspection(invocation, deadline, *, after_get=after_get, expire_at=expire_at, expired=expired, step=step, steps=steps):
                result = step(invocation, deadline)
                if after_get[0]:
                    steps[0] += 1
                    if steps[0] == expire_at:
                        expired[0] = True
                return result
            capsule.get = read
            with patch.object(PROBE, 'diagnostic_step', inspection):
                with patch.object(PROBE.time, 'monotonic_ns',
                                  side_effect=lambda *, expired=expired, state=state: state.total if expired[0] else 0):
                    self.raw(state, lambda *, capsule=capsule, error=error, state=state: capsule.receiver(state, error),
                             TimeoutError, 'original absolute SDK probe deadline')
            self.assertEqual(steps[0], expire_at)
            self.assertEqual((state.work, state.total), (1, 5000000001))


if __name__ == '__main__':
    unittest.main()

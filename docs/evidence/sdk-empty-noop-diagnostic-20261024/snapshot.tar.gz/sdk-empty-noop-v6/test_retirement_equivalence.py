"""Original intrinsic versus exact-list cell retirement controls."""
import unittest
from unittest.mock import patch

from test_support import CHECKER, PROBE


class HostileList(list):
    calls = 0

    def __setitem__(self, key, value):
        HostileList.calls += 1
        raise AssertionError('subclass dispatch forbidden')


class Index:
    def __init__(self, value, events):
        self.value, self.events = value, events

    def __index__(self):
        self.events.append('index')
        return self.value


class RetirementEquivalence(unittest.TestCase):
    def observe(self, retire, sequence, index):
        error = None
        try:
            retire(sequence, index)
        except (TypeError, IndexError, OverflowError) as caught:
            error = (type(caught).__name__, caught.args)
        return sequence, error

    def original(self, sequence, index):
        list.__setitem__(sequence, index, None)

    def test_exact_and_subclass_success_and_error_results(self):
        indices = (0, 1, -1, 2, -3, True, False, 2 ** 100,
                   'bad', None, slice(None), (0,))
        for sequence_type in (list, HostileList):
            for index in indices:
                expected = self.observe(self.original, sequence_type([1, 2]), index)
                for module in (CHECKER, PROBE):
                    with self.subTest(module=module.__name__, kind=sequence_type, index=index):
                        actual = self.observe(module.retire_reference_cell,
                                              sequence_type([1, 2]), index)
                        self.assertEqual(actual, expected)
        self.assertEqual(HostileList.calls, 0)

    def test_index_conversion_order_and_count(self):
        for value in (0, -1, 9, 2 ** 100, 'bad'):
            expected_events = []
            expected = self.observe(self.original, [1, 2], Index(value, expected_events))
            for module in (CHECKER, PROBE):
                events = []
                actual = self.observe(module.retire_reference_cell, [1, 2], Index(value, events))
                self.assertEqual(actual, expected)
                self.assertEqual(events, expected_events)
                self.assertEqual(events, ['index'])

    def test_non_list_receivers_retain_original_errors(self):
        for sequence in (None, (), {}, 'text', object()):
            expected = self.observe(self.original, sequence, 0)
            for module in (CHECKER, PROBE):
                self.assertEqual(self.observe(module.retire_reference_cell, sequence, 0), expected)

    def finalizer_trace(self, retire):
        events, sequence = [], [None, 'later']

        class Retired:
            def __del__(self):
                events.append(sequence[0] is None)
                sequence[1] = 'repopulated'

        sequence[0] = Retired()
        retire(sequence, 0)
        return sequence, events

    def test_finalizer_observes_replacement_before_callback(self):
        expected = self.finalizer_trace(self.original)
        self.assertEqual(expected, ([None, 'repopulated'], [True]))
        for module in (CHECKER, PROBE):
            self.assertEqual(self.finalizer_trace(module.retire_reference_cell), expected)

    def sweep_finalizer(self, module, target):
        events, attempts, sequence = [], [], [None] * 8192

        class Retired:
            def __del__(self):
                events.append(sequence[4096] is None)
                sequence[target] = 'repopulated'

        sequence[4096] = Retired()
        original = module.retire_reference_cell

        def counted(array, index):
            attempts.append(index)
            original(array, index)

        state = PROBE.ProbeState()
        guard = module.DerivedClearGuard(state, 'scratch-clear')
        with patch.object(module, 'retire_reference_cell', counted):
            module.retire_reference_array(sequence, guard)
        self.assertEqual(events, [True])
        self.assertEqual(attempts, list(range(8192)))
        self.assertEqual(state.used, 0)
        self.assertFalse(state.overflow)
        self.assertIsNone(sequence[4096])
        self.assertEqual(sequence[target], 'repopulated' if target == 0 else None)

    def test_finalizer_release_once_and_remaining_sweep(self):
        for module in (CHECKER, PROBE):
            for target in (0, 8191):
                self.sweep_finalizer(module, target)


if __name__ == '__main__':
    unittest.main()

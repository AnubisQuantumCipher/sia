"""Prevent fixture rehashing from contaminating product collision oracles."""
import unittest
from unittest.mock import patch

from test_graph_matrix import Collision, StringKey
from test_support import CHECKER, Harness, fixture_sys_namespace


class SysFixtureNamespace(unittest.TestCase):
    def test_poisoned_view_identity_and_zero_callbacks(self):
        for key in (Collision(), StringKey('__spec__')):
            actual_modules, fixture_modules = object(), object()
            namespace = {'__spec__': None, 'modules': actual_modules, key: None}
            Collision.calls, StringKey.calls = 0, 0
            result = fixture_sys_namespace(namespace, fixture_modules)
            self.assertIs(result, namespace)
            self.assertEqual(Collision.calls, 0)
            self.assertEqual(StringKey.calls, 0)

    def test_healthy_copy_substitutes_only_fixture_modules(self):
        actual_modules, fixture_modules, marker = object(), object(), object()
        namespace = {'modules': actual_modules, 'retained': marker}
        result = fixture_sys_namespace(namespace, fixture_modules)
        self.assertIsNot(result, namespace)
        self.assertIs(namespace['modules'], actual_modules)
        self.assertIs(result['modules'], fixture_modules)
        self.assertIs(result['retained'], marker)
        self.assertEqual(len(result), len(namespace))

    def test_oversized_or_wrong_kind_view_is_untouched(self):
        oversized = {str(index): None for index in range(8193)}
        for namespace in (oversized, (), None):
            self.assertIs(fixture_sys_namespace(namespace, object()), namespace)

    def test_product_refuses_before_binding_actual_modules(self):
        harness = Harness(self).positive()
        checker, refs = harness.checker, harness.checker.refs
        member = refs.member_get_intrinsic
        binds = []

        def poisoned(descriptor, receiver, owner):
            result = member(descriptor, receiver, owner)
            if receiver is refs.sys_actual:
                result = dict(result)
                result[Collision()] = None
                Collision.calls = 0
            return result

        def forbidden_bind(current, modules, recheck):
            binds.append((current, modules, recheck))
            raise AssertionError('malformed sys view reached module binding')

        with patch.object(refs, 'member_get_intrinsic', poisoned), patch.object(
                CHECKER.DerivedChecker, 'bind_modules', forbidden_bind):
            harness.error(lambda: checker.graph(recheck=True),
                          'derived exact text prelength', 'KEYS')
        self.assertEqual(binds, [])
        self.assertEqual(Collision.calls, 0)


if __name__ == '__main__':
    unittest.main()

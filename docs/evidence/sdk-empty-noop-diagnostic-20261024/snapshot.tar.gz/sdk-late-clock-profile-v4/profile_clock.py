"""Bounded profile of the corrected original frontier test, not acceptance."""
import cProfile
import json
import sys
import time
import unittest

FIXTURE = '/home/sicarii/Work/sia-assurance-evidence-20261019/ownership-transfer-20261024/sdk-scratch-sweep-v4'
sys.path.insert(0, FIXTURE)


def exercise():
    name = ('test_main_resources.MainProduction.'
            'test_late_total_expiry_never_resets_deadline_or_returns_success')
    suite = unittest.defaultTestLoader.loadTestsFromName(name)
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    if not result.wasSuccessful():
        raise RuntimeError('profiled original late clock test failed')


def main():
    profiler = cProfile.Profile()
    started = time.perf_counter_ns()
    profiler.runcall(exercise)
    elapsed = time.perf_counter_ns() - started
    statistics = profiler.getstats()
    if len(statistics) > 4096:
        raise RuntimeError('diagnostic function roster capacity')
    rows = []
    for entry in statistics:
        code = entry.code
        location = (code if type(code) is str
                    else code.co_filename + ':' + str(code.co_firstlineno)
                    + ':' + code.co_name)
        rows.append({'location': location, 'calls': entry.callcount,
                     'recursive_calls': entry.reccallcount,
                     'own_seconds': entry.inlinetime,
                     'cumulative_seconds': entry.totaltime})
    rows.sort(key=lambda item: item['cumulative_seconds'], reverse=True)
    print(json.dumps({'status': 'OBSERVED_ORIGINAL_LATE_CLOCK_ONLY',
                      'elapsed_ns': elapsed, 'functions': rows}, indent=2))


if __name__ == '__main__':
    main()

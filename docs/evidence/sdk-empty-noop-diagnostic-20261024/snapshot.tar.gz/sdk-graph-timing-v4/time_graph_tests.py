"""Measure original graph-method costs without changing assertions or cases."""
import json
import sys
import time
import unittest

FIXTURE = '/home/sicarii/Work/sia-assurance-evidence-20261019/ownership-transfer-20261024/sdk-scratch-sweep-v4'
sys.path.insert(0, FIXTURE)


class TimedResult(unittest.TextTestResult):
    def startTest(self, test):
        if self.testsRun >= 512:
            raise RuntimeError('diagnostic method capacity')
        self.method_started = time.perf_counter_ns()
        print(json.dumps({'event': 'start', 'test': test.id()}), flush=True)
        super().startTest(test)

    def stopTest(self, test):
        elapsed = time.perf_counter_ns() - self.method_started
        super().stopTest(test)
        print(json.dumps({'event': 'stop', 'test': test.id(),
                          'elapsed_ns': elapsed}), flush=True)


def main():
    names = ('test_graph_additions.GraphAdditions', 'test_graph_matrix.GraphMatrix')
    suite = unittest.defaultTestLoader.loadTestsFromNames(names)
    runner = unittest.TextTestRunner(verbosity=2, resultclass=TimedResult)
    result = runner.run(suite)
    print(json.dumps({'event': 'complete', 'tests': result.testsRun,
                      'successful': result.wasSuccessful(),
                      'scope': 'Method-cost diagnostic only; not complete SDK suite'}), flush=True)
    return 0 if result.wasSuccessful() else 1


if __name__ == '__main__':
    raise SystemExit(main())

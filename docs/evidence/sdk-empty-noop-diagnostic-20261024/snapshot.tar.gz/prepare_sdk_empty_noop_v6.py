"""Create a private successor without modifying frozen SDK inputs."""
import difflib
from pathlib import Path

ROOT = Path(__file__).resolve().parent
BASE = ROOT / 'sdk-scratch-sweep-v4'
OUT = ROOT / 'sdk-empty-noop-v6'
OLD = '''def retire_reference_array(sequence, guard):
    """Attempt every fixed slot, resuming after a recorded cell failure.

    Successful fixed-guard entry/exit is inert. Each attempted retirement
    advances next_index first; cell errors never retry or skip a later cell.
    This does not qualify asynchronous interruption between those statements.
    """
    next_index = 0
    for _attempt in range(8192):
        with guard:
            for index in range(next_index, 8192):
                next_index = index + 1
                retire_reference_cell(sequence, index)
        if next_index == 8192:
            return
    with guard:
        raise RuntimeError('derived scratch sweep incomplete')
'''
NEW = '''_RETIRE_CELL = retire_reference_cell
_RETIRE_CODE = retire_reference_cell.__code__


def empty_retirement_is_noop(sequence):
    """Only the admitted exact-list primitive can skip an already-None write."""
    return (type(sequence) is list and len(sequence) == 8192
            and retire_reference_cell is _RETIRE_CELL
            and _RETIRE_CELL.__code__ is _RETIRE_CODE)


def retire_reference_array(sequence, guard):
    """Examine every fixed slot; retire occupied or substituted-path cells.

    A known None assignment releases no foreign reference. Reconsider this
    fact after every call/failure; finalizers can change the next cell's path.
    This does not preserve arbitrary tracing or call-entry resource failures.
    """
    next_index = 0
    for _attempt in range(8192):
        with guard:
            empty_noop = empty_retirement_is_noop(sequence)
            for index in range(next_index, 8192):
                next_index = index + 1
                if not empty_noop or sequence[index] is not None:
                    retire_reference_cell(sequence, index)
                    empty_noop = empty_retirement_is_noop(sequence)
        if next_index == 8192:
            return
    with guard:
        raise RuntimeError('derived scratch sweep incomplete')
'''


def main():
    OUT.mkdir()
    differences = []
    for path in sorted(BASE.glob('*.py')):
        text = path.read_text()
        if path.name in ('origin_probe.py', 'production_checker.py'):
            if text.count(OLD) != 1:
                raise ValueError('expected exact v4 sweep')
            changed = text.replace(OLD, NEW)
        else:
            changed = text.replace(str(BASE), str(OUT))
        (OUT / path.name).write_text(changed)
        differences.extend(difflib.unified_diff(text.splitlines(True), changed.splitlines(True),
                                                fromfile='v4/' + path.name,
                                                tofile='v6/' + path.name))
    (OUT / 'source.diff').write_text(''.join(differences))


if __name__ == '__main__':
    main()

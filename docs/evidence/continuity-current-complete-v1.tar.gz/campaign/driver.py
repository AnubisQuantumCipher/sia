#!/usr/bin/env python3
"""Prepared first changed Current0e5 complete campaign; execute only after explicit root authorization and heavy-lane release."""
from pathlib import Path
import argparse
import hashlib
import json
import os
import platform
import re
import shlex
import shutil
import subprocess
import tarfile
import time

PREP=Path(__file__).resolve().parent
INPUT=PREP.parent/'takeover-current-availability-case-helper-proposal-v1'
OUT=PREP.parent/'takeover-current-case-helper-complete-v1'
REPO=Path('/home/sicarii/Work/sia-assurance-kernel-20261019')
PIN='9bd84d19ae2e9907c7129f1e555bf45f9e162eac'
TARGET='spark/tests/continuity_current_wire_tests.adb'
BASE='20a1a6a5bbacedd9d17b4c38168dba2ddedb6fdcd877be61cb6b565af6d9f4f6'
OVERLAY='0e5f6192940b1927bbae80d2e4d86a71075981cd75ede204369e8574ebc0c288'
PROJECT='d439a1e2908c70643c951d296294a87c3ba2756be6b1d0bb4c9a6bd4814ebe49'
PATCH='bfac9f6408e9a8e6af45f0a3b8ce2b70ef4f18aa1608b2d1695d199233142a93'
RESERVE=10_000_000_000
EXPECTED_DECLARATIONS=(('Continuity_Current_Wire_Tests', 6), ('Continuity_Current_Wire_Tests.Check_Zero', 11), ('Continuity_Current_Wire_Tests.Check_Header_Order', 30), ('Continuity_Current_Wire_Tests.Check_Witnesses', 58), ('Continuity_Current_Wire_Tests.Check_Claim_Order', 81), ('Continuity_Current_Wire_Tests.Check_Operation_Order', 127), ('Continuity_Current_Wire_Tests.Check_Header_Codes', 170), ('Continuity_Current_Wire_Tests.Check_Header_Reserved', 198), ('Continuity_Current_Wire_Tests.Check_Claim_Refusal', 220), ('Continuity_Current_Wire_Tests.Check_Operation_Refusal', 245), ('Continuity_Current_Wire_Tests.Check_Operation_Refusal.Check_Operation_Slot', 249), ('Continuity_Current_Wire_Tests.Check_Available_Refusal', 278), ('Continuity_Current_Wire_Tests.Check_Available_Refusal.Check_Available_Claim', 279), ('Continuity_Current_Wire_Tests.Check_Available_Refusal.Check_Available_Operation', 301), ('Continuity_Current_Wire_Tests.Check_Availability', 336), ('Continuity_Current_Wire_Tests.Check_Availability.Check_Availability_Case', 342))
EXPECTED_ORACLES=(('Assert', 23), ('Assert', 24), ('Assert', 27), ('Assert', 42), ('Assert', 43), ('Assert', 50), ('Assert', 52), ('Assert', 53), ('Assert', 54), ('Assert', 55), ('Assert', 68), ('Assert', 69), ('Assert', 73), ('Assert', 78), ('Assert', 123), ('Assert', 124), ('Assert', 166), ('Assert', 167), ('Assert', 183), ('Assert', 184), ('Assert', 192), ('Assert', 193), ('Assert', 208), ('Assert', 213), ('Assert', 215), ('Assert', 235), ('Assert', 237), ('Assert', 240), ('Assert', 260), ('Assert', 262), ('Assert', 266), ('Assert', 269), ('Assert', 290), ('Assert', 292), ('Assert', 296), ('Assert', 299), ('Assert', 312), ('Assert', 314), ('Assert', 318), ('Assert', 321), ('Assert', 354), ('Assert', 355), ('Assert', 357), ('Assert', 358))
RUNTIMES=('policy','transaction','request_wire','request_admission','grant_lifetime','retraction','consolidation','continuity','continuity_transition','continuity_record_wire','continuity_observation_wire','continuity_checkpoint_wire','continuity_current_wire','continuity_frame_wire','continuity_response_wire')


def require(condition,message):
    if not condition:
        raise ValueError(message)


def save(path,value):
    path.write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')


def pairs(items):
    result={}
    for key,value in items:
        require(key not in result,'duplicate JSON key')
        result[key]=value
    return result


def decoded(data):
    def invalid(value):
        raise ValueError('non-JSON numeric constant: '+value)
    return json.loads(data,object_pairs_hook=pairs,parse_constant=invalid)


def digest(path):
    require(path.is_file() and not path.is_symlink(),'hash input type')
    require(path.stat().st_size<=536_870_912,'hash byte budget')
    value=hashlib.sha256()
    with path.open('rb') as stream:
        for unused in range(8193):
            data=stream.read(65536)
            if not data:
                return value.hexdigest()
            value.update(data)
    raise ValueError('hash iteration budget')


def roster(directory):
    result={}
    for count,(current,directories,files) in enumerate(os.walk(directory,followlinks=False)):
        require(count<1024 and len(result)+len(files)<=4096,'source inventory budget')
        directories.sort()
        for name in sorted(files):
            path=Path(current)/name
            result[str(path.relative_to(directory))]=digest(path)
    return result


def small(args,label,cwd=REPO):
    value=subprocess.run(args,cwd=cwd,capture_output=True,timeout=30)
    (OUT/(label+'.stdout')).write_bytes(value.stdout)
    (OUT/(label+'.stderr')).write_bytes(value.stderr)
    save(OUT/(label+'.command.json'),args)
    (OUT/(label+'.exit')).write_text(str(value.returncode)+'\n')
    require(value.returncode==0,'preparation command failed: '+label)
    return value.stdout


def storage():
    args=['python3','/home/sicarii/.codex/skills/project-vault/scripts/storage_status.py']
    value=subprocess.run(args,cwd=REPO,capture_output=True,timeout=30)
    require(value.returncode==0,'storage preflight failed')
    data=decoded(value.stdout)
    pinned=any(OUT.is_relative_to(Path(p)) for p in data['pins'])
    scoped={key:data[key] for key in ('local_disk_bytes','configured_local_reserve_bytes','backup_service','ipad_availability','blanket_eviction_enabled')}
    scoped.update(command=args,exit=value.returncode,evidence_root=str(OUT.parent),evidence_root_pinned=pinned,stdout_retention='Only relevant scoped storage fields retained; unrelated queue/path inventory excluded',stderr=value.stderr.decode())
    save(OUT/'storage-preflight.json',scoped)
    require(pinned,'external evidence root not pinned')
    require(shutil.disk_usage(OUT).free>=max(RESERVE,data['configured_local_reserve_bytes']),'reserve unavailable')


def archive(pin):
    path=OUT/'source.tar'
    small(['git','archive','--format=tar','--output='+str(path),pin,'spark'],'archive')
    tree=small(['git','ls-tree','-r','--full-tree',pin,'spark'],'base-tree').decode().splitlines()
    expected={row.split('\t',1)[1]:row.split()[2] for row in tree}
    require(0<len(expected)<=4096,'archive member budget')
    binding={}
    with tarfile.open(path,'r:') as bundle:
        for member in bundle.getmembers():
            if member.isdir():
                continue
            require(member.isfile() and member.name in expected,'unexpected archive member')
            data=bundle.extractfile(member).read(536_870_913)
            require(len(data)<=536_870_912,'archive member byte budget')
            git_hash=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
            require(git_hash==expected[member.name],'archive blob mismatch')
            binding[member.name]={'git_blob':git_hash,'sha256':hashlib.sha256(data).hexdigest()}
    require(set(binding)==set(expected),'archive roster mismatch')
    save(OUT/'archive-correspondence.json',binding)
    require(binding[TARGET]['sha256']==BASE,'base Current file mismatch')
    require(binding['spark/sia_assurance.gpr']['sha256']==PROJECT,'strict project changed')
    return binding


def retain_overlay():
    require(digest(INPUT/'candidate.adb')==OVERLAY,'reviewed Current candidate changed')
    require(digest(INPUT/'candidate.patch')==PATCH,'reviewed Current patch changed')
    for name in ('candidate.patch','proposal.json','review-request.md','mapping.json'):
        shutil.copyfile(INPUT/name,OUT/name)
    shutil.copyfile(INPUT/'before.adb',OUT/'base-current-overlay-9e.adb')
    review=PREP.parent/'takeover-current-case-helper-diagnostics-v1/01-case-helper/source-review.json'
    require(digest(review)=='728debe4f83a1e4859d0e3aeab3af42f0bee39c9b1296410ed08f413704c7f8c','independent source review changed')
    shutil.copyfile(review,OUT/'independent-source-review.json')
    audit=PREP.parent/'takeover-current-case-helper-independent-audit-v1/review.json'
    require(digest(audit)=='9a582ac7580a67d4b52cc09f2d2ebb03568706c3880819b98cb9962f847e210f','scoped proof audit changed')
    shutil.copyfile(audit,OUT/'scoped-helper-wrapper-independent-audit.json')
    shutil.copyfile(INPUT/'candidate.adb',OUT/'overlay-continuity_current_wire_tests.adb')
    require(digest(OUT/'overlay-continuity_current_wire_tests.adb')==OVERLAY,'copied overlay mismatch')


def fresh_source(binding):
    source=OUT/'source'
    source.mkdir()
    small(['tar','-xf',str(OUT/'source.tar'),'-C',str(source)],'extract')
    require(all(digest(source/name)==row['sha256'] for name,row in binding.items()),'extraction mismatch')
    shutil.copyfile(OUT/'overlay-continuity_current_wire_tests.adb',source/TARGET)
    require(digest(source/TARGET)==OVERLAY,'campaign overlay mismatch')
    require(digest(source/'spark/sia_assurance.gpr')==PROJECT,'strict project mismatch')
    require('procedure Check_Availability_Case' in (source/TARGET).read_text().splitlines()[341],'helper moved')
    initial=roster(source)
    save(OUT/'source-hashes-before.json',initial)
    save(OUT/'intended-coverage.json',{'declarations':EXPECTED_DECLARATIONS,'assertions_and_invariants':EXPECTED_ORACLES,'termination_declarations':EXPECTED_DECLARATIONS[1:],'scope':'Every original/helper declaration and original/new oracle in complete Current unit; not full project'})
    return source,initial


def toolchain(pin):
    manifest=decoded(small(['git','show',pin+':docs/CONTINUITY-IO-COMMITTED-EVIDENCE-20261021.json'],'inherited-tool-manifest'))
    expected=manifest['receipt']['proof_tools_before']
    resolved={}
    for name in ('gnatprove','gprbuild','gnatls','gcc','timeout','git','python3','tar','flock'):
        path=shutil.which(name)
        require(path is not None,'tool missing: '+name)
        resolved[name]=str(Path(path).resolve())
    paths=sorted(set(list(expected)+list(resolved.values())+['/home/sicarii/opt/gnat/env.sh']))
    before={p:digest(Path(p)) for p in paths}
    save(OUT/'tool-paths.json',resolved)
    save(OUT/'tool-hashes-before.json',before)
    require(all(before[p]==value for p,value in expected.items()),'inherited proof tool identity changed')
    for name in ('gnatprove','gprbuild','gnatls','gcc'):
        small([resolved[name],'--version'],name+'-version')
    return resolved,paths,before


def obligations(data):
    selected=[row for row in data['proof'] if row.get('file')=='continuity_current_wire_tests.adb']
    required={}
    for kind,line in EXPECTED_ORACLES:
        rules=('VC_ASSERT',) if kind=='Assert' else ('VC_LOOP_INVARIANT_INIT','VC_LOOP_INVARIANT_PRESERV')
        for rule in rules:
            found=[row for row in selected if row.get('line')==line and row.get('rule')==rule]
            require(bool(found),'required assertion/invariant missing: '+str((line,rule)))
            require(all(row['how_proved'] in ('prover','trivial') and row.get('message',{}).get('text')=='assertion proved' for row in found),'required assertion not proved')
            required[str(line)+':'+rule]=found
    for name,line in EXPECTED_DECLARATIONS[1:]:
        flow=[row for row in data['flow'] if row.get('rule')=='SUBPROGRAM_TERMINATION' and row.get('line')==line]
        require(bool(flow),'declared termination proof missing: '+name)
        required[str(line)+':SUBPROGRAM_TERMINATION']=flow
    return required


def inspect(stage):
    raw=stage/'raw'
    reports=sorted(raw.glob('*.spark'))
    require([p.name for p in reports]==['continuity_current_wire_tests.spark'],'unexpected/missing raw report roster')
    data=decoded(reports[0].read_bytes())
    require(data['stop_reason']=='STOP_REASON_NONE','raw report incomplete')
    for channel in ('warn_error','flow','proof'):
        require(isinstance(data[channel],list),'raw diagnostic channel type')
        require(all(isinstance(v,dict) and v.get('severity') in ('info','information') for v in data[channel]),'non-information raw diagnostic')
    for field in ('pragma_assume','skip_proof','skip_flow_proof'):
        require(data[field]==[],'explicit assumption/exclusion')
    covered=[]
    for key,state in data['spark'].items():
        require(state=='all','partial SPARK entity')
        row=data['entities'][key]
        require(len(row['sloc'])==1,'ambiguous entity location')
        loc=row['sloc'][0]
        require(loc['file']=='continuity_current_wire_tests.adb','unexpected entity source')
        covered.append((row['name'],loc['line']))
    require(sorted(covered)==sorted(EXPECTED_DECLARATIONS),'complete declaration coverage mismatch')
    required=obligations(data)
    summary=raw/'gnatprove.out'
    require(summary.is_file(),'fresh summary missing')
    totals=[row for row in summary.read_text().splitlines() if row.startswith('Total ')]
    require(len(totals)==1,'missing/duplicate total row')
    fields=re.sub(r'\([0-9]+%\)','',totals[0]).split()
    require(fields[-2:]==['.','.'],'nonzero justified/unproved checks')
    return {'status':'COMPLETE CURRENT UNIT ONLY','covered':covered,'required_obligations':required,'total_row':totals[0],'reported_total':int(fields[1]),'justified':0,'unproved':0,'raw_diagnostics':'No non-information warn_error/flow/proof entries','pragma_assume':[],'skip_proof':[],'skip_flow_proof':[],'assumptions':data['assumptions'],'entities':data['entities'],'full_project_acceptance':False}


def retain_generated(stage,source):
    directory=source/'spark/obj/gnatprove'
    save(stage/'generated-proof-output-hashes.json',roster(directory))
    retained=stage/'retained-generated'
    retained.mkdir()
    names=['continuity_current_wire_tests.adb.stdout','continuity_current_wire_tests.adb.stderr']
    names+=sorted(p.name for p in directory.glob('why3*') if p.is_file() and p.name!='why3.conf')
    require(len(names)<=32,'generated channel roster budget')
    for name in names:
        path=directory/name
        if path.is_file() and path.stat().st_size<=1_048_576:
            shutil.copyfile(path,retained/name)


def run_stage(source,resolved,name,command,seconds,proof=False):
    stage=OUT/name
    stage.mkdir()
    args=[resolved['timeout'],'--kill-after=5s',seconds]+command
    save(stage/'command.json',args)
    (stage/'command').write_text(shlex.join(args)+'\n')
    require(shutil.disk_usage(OUT).free>=RESERVE,'reserve unavailable before '+name)
    if proof:
        report=source/'spark/obj/gnatprove'
        require(not list(report.glob('*.spark')) and not (report/'gnatprove.out').exists(),'stale proof reports before campaign proof')
    started=time.monotonic()
    with (stage/'stdout').open('wb') as stdout,(stage/'stderr').open('wb') as stderr:
        value=subprocess.run(args,cwd=source,stdout=stdout,stderr=stderr)
    result={'name':name,'command':args,'exit':value.returncode,'elapsed_seconds':time.monotonic()-started,'passed':value.returncode==0}
    (stage/'exit').write_text(str(value.returncode)+'\n')
    if proof:
        raw=stage/'raw'
        raw.mkdir()
        for path in sorted(list(report.glob('*.spark'))+list(report.glob('gnatprove.out'))):
            shutil.copyfile(path,raw/path.name)
        retain_generated(stage,source)
        try:
            inspection=inspect(stage)
            save(stage/'inspection.json',inspection)
        except (ValueError,KeyError,TypeError,UnicodeError) as error:
            save(stage/'inspection.json',{'status':'REFUSED','error':str(error),'full_project_acceptance':False})
            result['passed']=False
        result['fresh_summary_present']=(raw/'gnatprove.out').exists()
    save(stage/'result.json',result)
    print(json.dumps(result),flush=True)
    return result


def sequence(source,resolved):
    results=[run_stage(source,resolved,'strict-build',[resolved['gprbuild'],'-p','-j1','-P','spark/sia_assurance.gpr'],'120s')]
    if not results[-1]['passed']:
        return results
    for name in RUNTIMES:
        results.append(run_stage(source,resolved,name+'-runtime',['spark/bin/'+name+'_tests'],'30s'))
        if not results[-1]['passed']:
            return results
    proof=[resolved['gnatprove'],'-P','spark/sia_assurance.gpr','-u','continuity_current_wire_tests.adb','--mode=all','--assumptions','--no-inlining','--memlimit=512','--timeout=10','-j1']
    results.append(run_stage(source,resolved,'complete-current-harness',proof,'120s',True))
    return results


def finish(pin,source,paths,before,initial,results):
    after={p:digest(Path(p)) for p in paths}
    save(OUT/'tool-hashes-after.json',after)
    final={name:digest(source/name) for name in initial}
    save(OUT/'source-hashes-after.json',final)
    save(OUT/'source-output-hashes.json',roster(source))
    expected=['strict-build']+[name+'-runtime' for name in RUNTIMES]+['complete-current-harness']
    free=shutil.disk_usage(OUT).free
    receipt={'base_commit':pin,'archive_sha256':digest(OUT/'source.tar'),'only_overlay':{TARGET:OVERLAY},'base_current_sha256':BASE,'patch_sha256':PATCH,'project_sha256':PROJECT,'checks':results,'tool_rosters_equal':before==after,'archived_overlay_sources_unchanged':initial==final,'retained_current_overlay_sha256_after':digest(OUT/'overlay-continuity_current_wire_tests.adb'),'free_after_bytes':free,'complete_campaign_passed':all(row['passed'] for row in results) and [row['name'] for row in results]==expected and before==after and initial==final and free>=RESERVE and digest(OUT/'overlay-continuity_current_wire_tests.adb')==OVERLAY,'full_project_proof':'OPEN; no full-project command run','installed_acceptance':'OPEN; no installed action','scope':'First structurally changed Current0e5 fresh strict build/all15 original runtimes/complete unit only; no selected repeats/fullproject; prior failed complete and selected campaigns remain separate'}
    save(OUT/'receipt.json',receipt)
    print(json.dumps(receipt,indent=2),flush=True)
    return receipt


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--base-commit',required=True)
    parser.add_argument('--root-authorized-current-complete',action='store_true',required=True)
    args=parser.parse_args()
    require(args.base_commit==PIN,'owner authorized only exact pinned base')
    require(not OUT.exists(),'fresh evidence directory required')
    OUT.mkdir()
    try:
        storage()
        binding=archive(args.base_commit)
        retain_overlay()
        source,initial=fresh_source(binding)
        resolved,paths,before=toolchain(args.base_commit)
        shutil.copyfile(PREP/'driver.py',OUT/'driver.py')
        shutil.copyfile(PREP/'launch.sh',OUT/'launch.sh')
        shutil.copyfile(PREP/'preparation.json',OUT/'preparation.json')
        save(OUT/'source-binding.json',{'commit':args.base_commit,'source_archive_sha256':digest(OUT/'source.tar'),'base_git_blob':'631abbb7b25a4e1e04de78bd1ccc34849c445415','only_overlay':{TARGET:OVERLAY},'other_worktree_files':'Never copied; only exact archived spark plus frozen Current0e5; dirty Checkpoint/Frame/docs excluded','platform':platform.platform(),'lock':'launch.sh holds flock -n -E75 /home/sicarii/.worldline-heavy.lock through full campaign and retention','intended_declarations':EXPECTED_DECLARATIONS,'intended_assertions_invariants':EXPECTED_ORACLES})
        results=sequence(source,resolved)
        receipt=finish(args.base_commit,source,paths,before,initial,results)
        if not receipt['complete_campaign_passed']:
            raise SystemExit(1)
    except Exception as error:
        save(OUT/'driver-failure.json',{'type':type(error).__name__,'error':str(error),'full_project_acceptance':False})
        raise

if __name__=='__main__':
    main()

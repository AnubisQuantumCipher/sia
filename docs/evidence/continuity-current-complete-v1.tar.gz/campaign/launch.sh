#!/usr/bin/env bash
set -euo pipefail
if [[ $# != 2 || $1 != 9bd84d19ae2e9907c7129f1e555bf45f9e162eac || $2 != ROOT_AUTHORIZED_CURRENT_COMPLETE ]]; then
    printf 'usage: launch.sh 9bd84d19ae2e9907c7129f1e555bf45f9e162eac ROOT_AUTHORIZED_CURRENT_COMPLETE\n' >&2
    exit 2
fi
source /home/sicarii/opt/gnat/env.sh
exec flock -n -E 75 /home/sicarii/.worldline-heavy.lock python3 -B \
    /home/sicarii/Work/sia-assurance-evidence-20261019/takeover-current-case-helper-complete-preparation-v1/driver.py \
    --base-commit "$1" --root-authorized-current-complete

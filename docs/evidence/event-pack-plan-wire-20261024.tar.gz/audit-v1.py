"""Audit the explicit focused scope; never substitute for the full proof gate."""
import hashlib
import importlib.util
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parent
REPO = Path('/home/sicarii/Work/sia-assurance-checkpoint-20261023')
STAGE = ROOT / 'stage-c6'
PROOF = STAGE / 'spark/pack-plan-obj/gnatprove'


def load(name):
    return json.loads((ROOT / name).read_text())


def pin(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def source():
    files = load('c6-proof.result.json')['before']
    if len(files) != 18:
        raise ValueError('unexpected source roster')
    for name, expected in files.items():
        if pin(REPO / name) != expected or pin(STAGE / name) != expected:
            raise ValueError('source mismatch')
    for phase in ('build', 'runtime', 'proof'):
        result = load('c6-' + phase + '.result.json')
        if result['exit'] != 0 or not result['unchanged'] or result['before'] != files:
            raise ValueError('incomplete positive evidence')
    negative = load('negative6-runtime.result.json')
    if negative['exit'] != 1 or not negative['unchanged']:
        raise ValueError('unexpected negative outcome')
    if load('negative6-build.result.json')['exit'] != 0:
        raise ValueError('negative must compile')
    for name in files:
        if name != 'spark/src/sia_pack_plan_wire.ads' and \
                pin(ROOT / 'stage-negative6' / name) != files[name]:
            raise ValueError('negative changed outside declared predicate')
    if (ROOT / 'negative6-runtime.stderr').read_text().strip() != \
            'raised PROGRAM_ERROR : complete nonuniform correspondence':
        raise ValueError('wrong negative refusal')
    return files


def declaration_details(lines):
    """Exact flat-spec declaration roster, not a general Ada parser."""
    expected = set()
    sources = load('c6-proof.result.json')['before']
    pattern = re.compile(r"^(?:package|   function|   procedure) ([A-Za-z][A-Za-z0-9_]*)\b")
    for name in sources:
        if not name.startswith('spark/src/') or not name.endswith('.ads'):
            continue
        path = STAGE / name
        package = None
        for number, line in enumerate(path.read_text().splitlines(), 1):
            match = pattern.match(line)
            if match is None:
                continue
            short = match.group(1)
            if line.startswith('package '):
                if package is not None:
                    raise ValueError('unsupported nested or multiple package')
                package = short
                qualified = short
            else:
                if package is None:
                    raise ValueError('declaration outside package')
                qualified = package + '.' + short
            expected.add((qualified.lower(), path.name, number))
        if package is None:
            raise ValueError('missing flat package declaration')
    detail = re.compile(
        r"  ([A-Za-z][A-Za-z0-9_.]*) at ([a-z][a-z0-9_]*\.(?:ads|adb)):"
        r"([1-9][0-9]{0,5}) flow analyzed "
        r"\(0 errors, 0 checks, 0 warnings and 0 pragma Assume statements\)"
        r" and proved \([0-9]{1,6} checks\)")
    seen = set()
    current = None
    for line in lines:
        if line.startswith('in unit '):
            current = line.split()[2].rstrip(',')
        elif ' at ' in line or 'flow analyzed' in line or 'pragma Assume' in line:
            match = detail.fullmatch(line)
            if match is None:
                raise ValueError('malformed or non-clean detail')
            name, filename, number = match.groups()
            key = (name.lower(), filename, int(number))
            if Path(filename).stem != current or key not in expected or key in seen:
                raise ValueError('misbound, unknown or duplicated source declaration')
            seen.add(key)
    if not expected or seen != expected:
        raise ValueError('source declaration coverage mismatch')


def report_checks():
    spec = importlib.util.spec_from_file_location('original_checker', REPO / 'spark/check-proof-summary.py')
    if spec is None or spec.loader is None:
        raise ValueError('checker import unavailable')
    checker = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(checker)
    lines = (PROOF / 'gnatprove.out').read_text().splitlines()
    checker.check_totals(lines)
    declaration_details(lines)
    units = [line for line in lines if line.startswith('in unit ')]
    expected = {'pack_retirement_test_support': 0, 'pack_retirement_tests': 0,
                'pack_plan_wire_test_support': 0, 'pack_plan_wire_tests': 0,
                'sia_continuity': 18, 'sia_continuity_record_wire': 15,
                'sia_pack_plan_wire': 13, 'sia_pack_retirement': 16, 'sia_policy': 7}
    if len(units) != len(expected):
        raise ValueError('unit scope changed')
    for line in units:
        match = checker.UNIT.fullmatch(line)
        if match is None:
            raise ValueError('invalid scope row')
        name, analyzed, available = match.groups()
        if name not in expected or int(analyzed) != expected[name] or analyzed != available:
            raise ValueError('unexpected scope')
    return units


def raw_checks():
    for name in ('sia_policy', 'sia_continuity', 'sia_continuity_record_wire',
                 'sia_pack_retirement', 'sia_pack_plan_wire'):
        raw = json.loads((PROOF / (name + '.spark')).read_text())
        for field in ('pragma_assume', 'skip_proof', 'skip_flow_proof'):
            if raw.get(field) != []:
                raise ValueError('assumed or excluded production proof')
        for field in ('warn_error', 'flow', 'proof'):
            rows = raw.get(field)
            if not isinstance(rows, list) or len(rows) > 4096:
                raise ValueError('missing or oversized diagnostics')
            if any(row.get('severity') != 'info' for row in rows):
                raise ValueError('noninformational production diagnostic')
    if re.search(r'\b(warning|medium|high|error):', (ROOT / 'c6-proof.stderr').read_text()):
        raise ValueError('unclean proof stderr')


def main():
    files = source()
    units = report_checks()
    raw_checks()
    result = {'status': 'FOCUSED_EXACT_SOURCE_CHECKS_DISCHARGED', 'source': files,
              'units': units, 'report_sha256': pin(PROOF / 'gnatprove.out'),
              'binary_sha256': pin(STAGE / 'spark/pack-plan-bin/pack_plan_wire_tests'),
              'scope': 'Fixed-frame decoder correspondence and conditional policy; tests outside SPARK; original full gate OPEN',
              'negative': 'Coherent Corpus/Organ swap rejected by unchanged independent runtime expectation'}
    with (ROOT / 'integrity-audit.json').open('x') as handle:
        json.dump(result, handle, indent=2)
    print(result['status'])


if __name__ == '__main__':
    main()

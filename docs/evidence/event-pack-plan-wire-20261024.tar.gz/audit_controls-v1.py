"""Adversarial controls for exact declaration identity in the scoped audit."""
import json
from pathlib import Path
import audit

ROOT = Path(__file__).resolve().parent


def main():
    lines = (audit.PROOF / 'gnatprove.out').read_text().splitlines()
    rows = [i for i, line in enumerate(lines) if ' flow analyzed ' in line]
    if not rows or len(rows) > 128:
        raise ValueError('unexpected detail capacity')
    audit.declaration_details(lines)
    refused = 0
    for index in rows:
        row = lines[index]
        variants = ([], [row, row], [row.replace('.ads:', '.adb:')],
                    [row.replace(' at ', '_Unknown at ')],
                    [row.replace('0 warnings', '1 warnings')],
                    [row.replace(':', ':999999', 1)])
        for replacement in variants:
            candidate = lines[:index] + replacement + lines[index + 1:]
            try:
                audit.declaration_details(candidate)
            except ValueError:
                refused += 1
            else:
                raise AssertionError('changed declaration report admitted')
    result = {'status': 'PASS', 'positive': 'complete real c6 declaration roster',
              'negative_refusals': refused, 'source_detail_rows': len(rows),
              'boundary': 'Synthetic report mutations; not GNATprove evidence.'}
    with (ROOT / 'audit-controls.json').open('x') as handle:
        json.dump(result, handle, indent=2)
    print(json.dumps(result))


if __name__ == '__main__':
    main()

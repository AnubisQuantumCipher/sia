# Pack-plan wire retained qualification history

- c1: strict build/runtime passed. Proof failed with six operator-reassociation warnings. This is not a proved candidate. Raw source and diagnostics retained.
- c2: explicit arithmetic grouping resolved the reported source warning forms. Strict build passed; runtime/proof were not run because review requested additional negative controls first. Helper encoder guards remained active but were removed from the displayed semantic-check counter.
- c3: added invalid high-byte and noncanonical scalar-tail cases, all presence codes 2/255, all roster count/length guard positions, and separate padding/order/union/fallback-only policy refusals. Strict build and runtime passed (188 retirement and 19508 wire controls). Complete scoped proof timed out at the existing 120-second cap, exit 124, with unchanged source. No final summary or complete new-unit proof exists for c3. Partial Why3 records retained; a passing subset is not completion.
- negative: coherent Corpus/Organ swap in Scope_Value changes both decoder and shared correspondence definition. Strict build passed; unchanged independent runtime fixture failed with PROGRAM_ERROR: complete nonuniform correspondence. It demonstrates that this particular correlated mapping defect is detected, not universal oracle adequacy.
- c4: Record_Value is now a separately checked body with complete Identity, Content and Bytes postcondition, avoiding repeated expression expansion in roster quantifiers. Input domains, runtime mapping, full test workload and proof caps unchanged. Strict build/runtime passed; complete proof again timed out at 120 seconds. No whole-scope qualification.

No candidate activates a protected actuator, authenticates producer identity, qualifies the installed runtime or discharges whole-system gates.

- Roster-only c4 diagnostic: all selected roster-decoder obligations discharged within the unchanged cap. This narrowed diagnostic does not replace the failed full scoped gate.
- c5: fixed-domain array aggregates replace mutable array-building loops while preserving all public contracts and input domains. Strict build and unchanged runtime workload passed; proof checks discharged in reported scope, but strict analysis failed on a dead Candidate initialization and stopped before complete unit coverage. This remains FAILED, not a pass.

- c6: removed the unnecessary Candidate initialization; definite assignment before use remains a required flow check. Strict build/runtime and complete focused proof passed; raw/source audit and coherent final-source negative passed.

- negative9 was prepared from c5 but deliberately not executed after the dead-initialization fix; negative6 is the final-source mutation candidate.

- Initial focused auditor: independent review found that unit membership plus row count did not reject a duplicated zero-analysis test unit replacing another. The genuine c6 report had all nine units, but the auditor was not yet robust to this mutation. The defect was reproduced: original auditor admitted a synthetic duplicated zero-analysis unit; corrected auditor refused. Final auditor adds duplicate-name rejection and exact set equality; both the original auditor and its narrower controls are retained.

- Public archive preparation initially exceeded its 512-member cap by including every Why3 session. The cap was not raised. The compact public archive retains exact source stages, command receipts, available raw .spark/summary output and timeout-stage decoder Why3 sessions. All other intermediates remain in the complete local sealed evidence inventory.

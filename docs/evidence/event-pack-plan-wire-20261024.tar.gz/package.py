"""Publish reproducible scoped evidence while keeping all failed attempts visible."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile

ROOT = Path(__file__).resolve().parent
REPO = Path('/home/sicarii/Work/sia-assurance-checkpoint-20261023')


def load(name):
    return json.loads((ROOT / name).read_text())


def pin(path):
    return {'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
            'bytes': path.stat().st_size}


def members():
    result = set()
    for pattern in ('c[1-9]-*.*', 'negative*.*', 'roster-diagnostic.*'):
        result.update(ROOT.glob(pattern))
    names = ('run.py', 'audit.py', 'audit_controls.py', 'package.py', 'FAILURES.md',
             'audit-v1.py', 'audit_controls-v1.py', 'audit-initial-failure.txt',
             'integrity-audit-initial.json', 'audit-controls-initial.json',
             'audit-controls.json', 'audit-regression.json',
             'audit-negative-fixture/gnatprove.out',
             'REVIEW-final.txt', 'REVIEW-source-c3.txt', 'REVIEW-source-c6.txt',
             'integrity-audit.json', 'toolchain-executable-pins.json',
             'toolchain.json', 'arithmetic-oracle.json', 'driver-static-final.json')
    result.update(ROOT / name for name in names)
    source = load('integrity-audit.json')['source']
    stages = sorted(ROOT.glob('stage-*'))
    if not stages or len(stages) > 16:
        raise ValueError('stage capacity')
    for stage in stages:
        result.update(stage / name for name in source)
        proof = stage / 'spark/pack-plan-obj/gnatprove'
        for pattern in ('gnatprove.out', '*.spark', '*.adb.stdout', '*.adb.stderr'):
            result.update(proof.glob(pattern))
        if stage.name in ('stage-c3', 'stage-c4'):
            result.update(proof.glob('sia_pack_plan_wire__*/why3session.xml'))
    if not result or len(result) > 512:
        raise ValueError('archive member capacity')
    return sorted(result)


def archive(paths):
    target = REPO / 'docs/evidence/event-pack-plan-wire-20261024.tar.gz'
    inventory = {}
    total = 0
    with target.open('wb') as output, gzip.GzipFile(fileobj=output, mode='wb', mtime=0, filename='') as compressed:
        with tarfile.open(fileobj=compressed, mode='w|') as tar:
            for path in paths:
                if path.is_symlink() or not path.is_file():
                    raise ValueError('nonregular archive member')
                size = path.stat().st_size
                total += size
                if size > 4 * 1024 * 1024 or total > 16 * 1024 * 1024:
                    raise ValueError('archive byte capacity')
                raw = path.read_bytes()
                name = str(path.relative_to(ROOT))
                info = tarfile.TarInfo(name)
                info.size, info.mode, info.mtime = len(raw), 0o644, 0
                tar.addfile(info, io.BytesIO(raw))
                inventory[name] = {'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)}
    with tarfile.open(target, 'r:gz') as tar:
        for member in tar:
            handle = tar.extractfile(member)
            if handle is None or hashlib.sha256(handle.read()).hexdigest() != inventory[member.name]['sha256']:
                raise ValueError('archive readback mismatch')
    return {'path': str(target.relative_to(REPO)), **pin(target), 'members': inventory}


def validate():
    audit = load('integrity-audit.json')
    for name, expected in audit['source'].items():
        if pin(REPO / name)['sha256'] != expected:
            raise ValueError('source drift')
    static = load('driver-static-final.json')
    if static['exit'] != 0 or json.loads(static['stdout']) != [] or static['stderr']:
        raise ValueError('static diagnostics')
    for name, expected in static['source'].items():
        if pin(ROOT / name)['sha256'] != expected:
            raise ValueError('driver drift')
    return audit


def main():
    audit = validate()
    artifact = archive(members())
    summary = {'status': 'DECODER_CORRESPONDENCE_PROVED_RUNTIME_TESTED_INACTIVE',
               'base_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO,
                                                      text=True, timeout=10).strip(),
               'audit': audit, 'archive': artifact,
               'runtime': (ROOT / 'c6-runtime.stdout').read_text().strip(),
               'proof_result': load('c6-proof.result.json'),
               'negative_result': load('negative6-runtime.result.json'),
               'arithmetic_oracle': load('arithmetic-oracle.json'),
               'toolchain': load('toolchain.json'),
               'review': (ROOT / 'REVIEW-final.txt').read_text(),
               'failures': (ROOT / 'FAILURES.md').read_text(),
               'boundary': 'No runtime activation, PlanID hashing or authentication, general encoder roundtrip/uniqueness proof, native qualification, R05 waiver, whole-system proof or release acceptance.'}
    target = REPO / 'docs/EVENT-PACK-PLAN-WIRE-EVIDENCE-20261024.json'
    target.write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps({'summary': pin(target), 'archive': pin(REPO / artifact['path']),
                      'members': len(artifact['members'])}))


if __name__ == '__main__':
    main()

package body SIA_Pack_Plan_Wire with SPARK_Mode is
   function Roster_Value (Data : Frame; Start : Roster_Offset) return Roster is
      Result : Roster := Empty_Roster;
      I : Positive range 1 .. Max_Records + 1 := 1;
   begin
      Result.Count := Record_Count (Data (Start + 7));
      while I <= Max_Records loop
         Result.Records (I) := Record_Value (Data, Record_Start (Start, I));
         pragma Loop_Invariant (I <= Max_Records);
         pragma Loop_Invariant (Result.Count = Record_Count (Data (Start + 7)));
         pragma Loop_Invariant
           (for all J in 1 .. I => Result.Records (J) =
              Record_Value (Data, Record_Start (Start, J)));
         pragma Loop_Variant (Decreases => (Max_Records + 1) - I);
         I := I + 1;
      end loop;
      return Result;
   end Roster_Value;

   function Value (Data : Frame) return Plan is
      Result : Plan := Empty_Plan;
      I : Positive range 1 .. Max_Records + 1 := 1;
   begin
      Result.Identity := Digest (Data (9 .. 40));
      Result.Scope := Scope_Value (Data);
      Result.Organ_Bytes := Small_Value (Data, 401);
      Result.Selected := Small_Value (Data, 409);
      Result.Fallback_Count := Small_Value (Data, 417);
      Result.Prior := Roster_Value (Data, Prior_Start);
      Result.Target := Roster_Value (Data, Target_Start);
      Result.Represented := Roster_Value (Data, Represented_Start);
      while I <= Max_Records loop
         Result.Legacy_Present (I) := Data (Presence_Start + I - 1) = 1;
         Result.Legacy_Generation (I) := Digest
           (Data (Generations_Start + (I - 1) * 32 .. Generations_Start + I * 32 - 1));
         pragma Loop_Invariant (I <= Max_Records);
         pragma Loop_Invariant
           (for all J in 1 .. I =>
              Result.Legacy_Present (J) = (Data (Presence_Start + J - 1) = 1) and then
              Result.Legacy_Generation (J) = Digest
                (Data (Generations_Start + (J - 1) * 32 .. Generations_Start + J * 32 - 1)));
         pragma Loop_Variant (Decreases => (Max_Records + 1) - I);
         I := I + 1;
      end loop;
      return Result;
   end Value;

   procedure Decode
     (Data : Frame; Length : Natural; Accepted : out Boolean; Item : out Plan)
   is
      Candidate : Plan := Empty_Plan;
   begin
      Accepted := False;
      Item := Empty_Plan;
      if Shape_Valid (Data, Length) then
         Candidate := Value (Data);
         if Valid_Retirement_Plan (Candidate) then
            Item := Candidate;
            Accepted := True;
         end if;
      end if;
   end Decode;
end SIA_Pack_Plan_Wire;

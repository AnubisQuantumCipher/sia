with Ada.Text_IO;
with SIA_Policy;
with SIA_Pack_Retirement;
with SIA_Pack_Plan_Wire;
package body Pack_Plan_Wire_Test_Support is
   use SIA_Policy;
   use SIA_Pack_Retirement;
   use SIA_Pack_Plan_Wire;
   Checks : Natural := 0;

   procedure Check (Condition : Boolean; Label_Text : String) is
   begin
      if not Condition then
         raise Program_Error with Label_Text;
      end if;
      Checks := Checks + 1;
   end Check;

   function Pattern (Seed : Digest_Byte) return Digest is
      Result : Digest;
   begin
      for I in Result'Range loop
         Result (I) := Seed + Digest_Byte (I * 3);
      end loop;
      return Result;
   end Pattern;

   function Fixture return Plan is
      Item : Plan := Empty_Plan;
   begin
      Item.Identity := Pattern (1);
      Item.Scope := ((16#0102030405060708#, Pattern (2)),
                     Pattern (3), Pattern (4), Pattern (5), Pattern (6),
                     Pattern (7), Pattern (8), Pattern (9), Pattern (10),
                     Pattern (11), Pattern (12));
      Item.Organ_Bytes := 200;
      Item.Selected := 65_536;
      Item.Fallback_Count := 65_534;
      Item.Prior.Count := 1;
      Item.Prior.Records (1) := (Pattern (20), Pattern (30), 1);
      Item.Target.Count := 2;
      Item.Target.Records (1) := Item.Prior.Records (1);
      Item.Target.Records (2) := (Pattern (21), Pattern (31), 2);
      Item.Represented := Item.Target;
      Item.Legacy_Present (2) := True;
      Item.Legacy_Generation (1) := Pattern (40);
      Item.Legacy_Generation (2) := Pattern (41);
      return Item;
   end Fixture;

   procedure Put_Word (Data : in out Frame; Start : Positive; Value : Generation) is
      Remaining : Generation := Value;
   begin
      for I in reverse 0 .. 7 loop
         Data (Start + I) := Digest_Byte (Remaining mod 256);
         Remaining := Remaining / 256;
      end loop;
      Check (Remaining = 0, "test word representable");
   end Put_Word;

   procedure Put_Digest (Data : in out Frame; Start : Positive; Value : Digest) is
   begin
      for I in Value'Range loop
         Data (Start + I - 1) := Value (I);
      end loop;
   end Put_Digest;

   procedure Put_Roster (Data : in out Frame; Start : Positive; Value : Roster) is
      Position : Positive := Start + 8;
   begin
      Put_Word (Data, Start, Generation (Value.Count));
      for I in Value.Records'Range loop
         Put_Digest (Data, Position, Value.Records (I).Identity);
         Put_Digest (Data, Position + 32, Value.Records (I).Content);
         Put_Word (Data, Position + 64, Generation (Value.Records (I).Bytes));
         Position := Position + 72;
      end loop;
   end Put_Roster;

   --  Independent literal offsets; no production offset/decoder helpers.
   function Encode_Oracle (Item : Plan) return Frame is
      Data : Frame := [others => 0];
   begin
      Data (1) := 1;
      Put_Digest (Data, 9, Item.Identity);
      Put_Word (Data, 41, Item.Scope.Transaction.Epoch);
      Put_Digest (Data, 49, Item.Scope.Transaction.Transaction);
      Put_Digest (Data, 81, Item.Scope.Corpus);
      Put_Digest (Data, 113, Item.Scope.Organ);
      Put_Digest (Data, 145, Item.Scope.Prefix);
      Put_Digest (Data, 177, Item.Scope.Revision);
      Put_Digest (Data, 209, Item.Scope.Capture);
      Put_Digest (Data, 241, Item.Scope.Selection);
      Put_Digest (Data, 273, Item.Scope.Fallback);
      Put_Digest (Data, 305, Item.Scope.Old_Target);
      Put_Digest (Data, 337, Item.Scope.New_Target);
      Put_Digest (Data, 369, Item.Scope.Permission);
      Put_Word (Data, 401, Generation (Item.Organ_Bytes));
      Put_Word (Data, 409, Generation (Item.Selected));
      Put_Word (Data, 417, Generation (Item.Fallback_Count));
      Put_Roster (Data, 425, Item.Prior);
      Put_Roster (Data, 5_041, Item.Target);
      Put_Roster (Data, 9_657, Item.Represented);
      for I in 1 .. 64 loop
         Data (14_272 + I) := (if Item.Legacy_Present (I) then 1 else 0);
         Put_Digest (Data, 14_337 + (I - 1) * 32, Item.Legacy_Generation (I));
      end loop;
      return Data;
   end Encode_Oracle;

   procedure Require_Refusal (Data : Frame; Length : Natural; Label_Text : String) is
      Accepted : Boolean;
      Item : Plan := Fixture;
   begin
      Decode (Data, Length, Accepted, Item);
      Check (not Accepted and then Item = Empty_Plan, Label_Text);
   end Require_Refusal;

   procedure Boundaries is
      Expected : Plan := Fixture;
      Data : Frame := Encode_Oracle (Expected);
      Accepted : Boolean;
      Item : Plan;
   begin
      Decode (Data, 16_384, Accepted, Item);
      Check (Accepted and then Item = Expected, "complete nonuniform correspondence");
      Require_Refusal (Data, 0, "empty input");
      Require_Refusal (Data, 16_383, "short input");
      Require_Refusal (Data, 16_385, "trailing input");
      Require_Refusal (Data, Natural'Last, "length overflow domain");
      Expected.Scope.Transaction.Epoch := Generation'Last;
      Data := Encode_Oracle (Expected);
      Decode (Data, 16_384, Accepted, Item);
      Check (Accepted and then Item = Expected, "maximum epoch");
      Data (41) := 128;
      Require_Refusal (Data, 16_384, "epoch high bit");
      Expected.Scope.Transaction.Epoch := 0;
      Require_Refusal (Encode_Oracle (Expected), 16_384, "zero epoch policy");
      Expected := Fixture;
      Expected.Identity := Zero;
      Data := Encode_Oracle (Expected);
      Decode (Data, 16_384, Accepted, Item);
      Check (Accepted and then Item = Expected, "zero digest not sentinel");
   end Boundaries;

   procedure Full_Roster is
      Expected : Plan := Fixture;
      Data : Frame;
      Accepted : Boolean;
      Item : Plan;
   begin
      Expected.Prior := Empty_Roster;
      Expected.Target.Count := 64;
      for I in Record_Index loop
         Expected.Target.Records (I) :=
           (Pattern (Digest_Byte (I)), Pattern (Digest_Byte (I + 64)), 1);
         Expected.Legacy_Present (I) := True;
         Expected.Legacy_Generation (I) := Pattern (Digest_Byte (I + 128));
      end loop;
      Expected.Represented := Expected.Target;
      Expected.Fallback_Count := 65_472;
      Data := Encode_Oracle (Expected);
      Decode (Data, 16_384, Accepted, Item);
      Check (Accepted and then Item = Expected, "full roster and count domains");
      Expected.Target.Records (64).Bytes := 65_536;
      Expected.Represented := Expected.Target;
      Require_Refusal (Encode_Oracle (Expected), 16_384, "complete frame capacity");
   end Full_Roster;

   procedure Every_Byte is
      Expected : constant Plan := Fixture;
      Original : constant Frame := Encode_Oracle (Expected);
      Data : Frame;
      Accepted : Boolean;
      Item : Plan;
   begin
      for I in Original'Range loop
         Data := Original;
         Data (I) := Data (I) xor 1;
         Decode (Data, 16_384, Accepted, Item);
         if Accepted then
            Check (Item /= Expected, "changed byte cannot disappear");
            Check (Encode_Oracle (Item) = Data, "exact accepted roundtrip");
         else
            Check (Item = Empty_Plan, "refusal has no partial plan");
         end if;
      end loop;
   end Every_Byte;

   procedure Run is
   begin
      Boundaries;
      Full_Roster;
      Every_Byte;
      Ada.Text_IO.Put_Line ("pack plan wire runtime controls PASS:" & Checks'Image);
   end Run;
end Pack_Plan_Wire_Test_Support;

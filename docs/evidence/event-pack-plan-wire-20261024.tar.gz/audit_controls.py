"""Adversarial controls for exact declaration identity in the scoped audit."""
import json
from pathlib import Path
import audit

ROOT = Path(__file__).resolve().parent


def main():
    lines = (audit.PROOF / 'gnatprove.out').read_text().splitlines()
    rows = [i for i, line in enumerate(lines) if ' flow analyzed ' in line]
    if not rows or len(rows) > 128:
        raise ValueError('unexpected detail capacity')
    audit.report_checks(lines)
    refused = 0
    for index in rows:
        row = lines[index]
        variants = ([], [row, row], [row.replace('.ads:', '.adb:')],
                    [row.replace(' at ', '_Unknown at ')],
                    [row.replace('0 warnings', '1 warnings')],
                    [row.replace(':', ':999999', 1)])
        for replacement in variants:
            candidate = lines[:index] + replacement + lines[index + 1:]
            try:
                audit.report_checks(candidate)
            except ValueError:
                refused += 1
            else:
                raise AssertionError('changed declaration report admitted')
    unit_rows = [i for i, line in enumerate(lines) if line.startswith('in unit ')]
    unit_refused = 0
    for index in unit_rows:
        other = next(i for i in unit_rows if i != index)
        for replacement in ([], [lines[index], lines[index]], [lines[other]]):
            candidate = lines[:index] + replacement + lines[index + 1:]
            try:
                audit.report_checks(candidate)
            except ValueError:
                unit_refused += 1
            else:
                raise AssertionError('changed unit roster admitted')
    result = {'status': 'PASS', 'positive': 'complete real c6 declaration roster',
              'negative_refusals': refused, 'unit_roster_refusals': unit_refused, 'source_detail_rows': len(rows),
              'boundary': 'Synthetic report mutations; not GNATprove evidence.'}
    with (ROOT / 'audit-controls.json').open('x') as handle:
        json.dump(result, handle, indent=2)
    print(json.dumps(result))


if __name__ == '__main__':
    main()

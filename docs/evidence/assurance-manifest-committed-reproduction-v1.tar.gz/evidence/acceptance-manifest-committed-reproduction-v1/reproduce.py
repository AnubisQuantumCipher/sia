"""Exact committed-source checker reproduction; no build or authority grant."""
import datetime
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import platform
import subprocess
import sys
import tarfile

REPO = Path('/home/sicarii/Work/sia-assurance-kernel-20261019')
COMMIT = 'b947dbdd41f3a36f2e9a35cca8fa5dd3955e6ff7'
OUTPUT = Path(__file__).resolve().parent
SOURCE = OUTPUT / 'source'
MAX_FILES = 256
MAX_BYTES = 1024 * 1024
REQUIRED = (
    'scripts/assurance_acceptance_manifest.py',
    'scripts/assurance_source_inventory.py',
    'tests/test_assurance_acceptance_manifest.py',
    'tests/test_assurance_source_inventory.py',
    'docs/ASSURANCE-GOAL.md', 'docs/ASSURANCE-IMPLEMENTATION-GATES.md',
    'docs/AGENT-CONTINUITY.md', 'docs/POWER-OF-TEN-ASSESSMENT.md',
    'docs/ASSURANCE-COMPLETION-CONTRACT-20261021-V2.txt',
    'docs/ASSURANCE-ACCEPTANCE-MANIFEST.md', '.github/workflows/ci.yml',
    'spark/sia_assurance.gpr', 'spark/restrictions.adc',
)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def save_json(name, value):
    (OUTPUT / name).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def git(*args):
    command = ['git', '-C', str(REPO), *args]
    result = subprocess.run(command, capture_output=True, timeout=30, check=False)
    if result.returncode != 0:
        raise RuntimeError('git operation failed: ' + repr(command))
    return result.stdout


def selection():
    raw = git('ls-tree', '-r', '-z', COMMIT)
    entries = {}
    for row in raw.split(b'\0'):
        if not row:
            continue
        metadata, name = row.split(b'\t', 1)
        mode, kind, identity = metadata.decode().split()
        path = name.decode()
        ada = path.startswith(('spark/src/', 'spark/tests/')) and path.endswith(('.ads', '.adb'))
        if path in REQUIRED or path == 'tests/__init__.py' or ada:
            if len(entries) >= MAX_FILES or kind != 'blob' or mode != '100644':
                raise ValueError('unsupported selected source entry')
            entries[path] = identity
    if not set(REQUIRED) <= set(entries):
        raise ValueError('missing required committed source')
    (OUTPUT / 'source-files.txt').write_text('\n'.join(sorted(entries)) + '\n')
    save_json('source-git-blobs.json', entries)
    return entries


def create_archive(entries):
    destination = OUTPUT / 'source.tar'
    command = ['git', '-C', str(REPO), 'archive', '--format=tar',
               '--output=' + str(destination), COMMIT, '--', *sorted(entries)]
    result = subprocess.run(command, capture_output=True, timeout=30, check=False)
    (OUTPUT / 'git-archive.stdout.log').write_bytes(result.stdout)
    (OUTPUT / 'git-archive.stderr.log').write_bytes(result.stderr)
    save_json('git-archive.receipt.json', {
        'command': command, 'exit': result.returncode, 'timeout_seconds': 30,
        'source_commit': COMMIT, 'archive_sha256': sha(destination.read_bytes())
        if destination.exists() else None})
    if result.returncode != 0:
        raise RuntimeError('git archive failed')
    return destination


def extract_archive(destination, entries):
    SOURCE.mkdir()
    observed = {}
    with tarfile.open(destination, 'r:') as archive:
        if archive.pax_headers.get('comment') != COMMIT:
            raise ValueError('archive commit marker mismatch')
        for member in archive:
            parts = PurePosixPath(member.name).parts
            if member.name.startswith('/') or '..' in parts:
                raise ValueError('unsafe archive path')
            target = SOURCE / member.name
            if member.isdir():
                target.mkdir(parents=True, exist_ok=True)
                continue
            if (not member.isfile() or member.name not in entries
                    or member.name in observed or member.size > MAX_BYTES):
                raise ValueError('unsupported archived source')
            raw = archive.extractfile(member).read(MAX_BYTES + 1)
            blob = hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()
            if len(raw) != member.size or blob != entries[member.name]:
                raise ValueError('committed Git blob mismatch')
            target.parent.mkdir(parents=True, exist_ok=True)
            with target.open('xb') as stream:
                if stream.write(raw) != len(raw):
                    raise OSError('short source write')
            observed[member.name] = sha(raw)
    if set(observed) != set(entries):
        raise ValueError('archived source roster mismatch')
    save_json('source-sha256.json', observed)
    return observed


def interpreter():
    executable = Path(sys.executable)
    identity = {'sys_executable': str(executable), 'resolved_executable': str(executable.resolve()),
                'sha256': sha(executable.read_bytes()), 'sys_version': sys.version,
                'platform': platform.platform(), 'implementation': platform.python_implementation()}
    save_json('interpreter.json', identity)
    return identity


def run(label, arguments, stdout_name, expected_exit):
    overrides = {'PYTHONWARNINGS': 'error', 'PYTHONNOUSERSITE': '1', 'PYTHONPATH': str(SOURCE)}
    environment = dict(os.environ)
    environment.update(overrides)
    command = [sys.executable, '-B', *arguments]
    receipt = {'command': command, 'cwd': str(SOURCE), 'environment_override': overrides,
               'timeout_seconds': 30, 'expected_exit': expected_exit,
               'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat()}
    try:
        result = subprocess.run(command, cwd=SOURCE, env=environment,
                                capture_output=True, timeout=30, check=False)
        stdout, stderr = result.stdout, result.stderr
        receipt['exit'], receipt['timed_out'] = result.returncode, False
    except subprocess.TimeoutExpired as error:
        stdout, stderr = error.stdout or b'', error.stderr or b''
        receipt['exit'], receipt['timed_out'] = None, True
    for stream, name, raw in (('stdout', stdout_name, stdout),
                               ('stderr', label + '.stderr.log', stderr)):
        (OUTPUT / name).write_bytes(raw)
        receipt[stream] = {'path': name, 'sha256': sha(raw)}
    receipt['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    save_json(label + '.receipt.json', receipt)
    print(json.dumps({'command': label, 'exit': receipt['exit'], 'timed_out': receipt['timed_out']}))
    if receipt['exit'] != expected_exit or receipt['timed_out']:
        raise RuntimeError('unexpected committed reproduction outcome: ' + label)
    return receipt


def executions():
    tests = run('focused-tests', ['-m', 'unittest', 'tests.test_assurance_acceptance_manifest',
                'tests.test_assurance_source_inventory', '-v'], 'focused-tests.stdout.log', 0)
    draft = run('draft', ['scripts/assurance_acceptance_manifest.py', 'draft',
                '--root', str(SOURCE)], 'draft.json', 0)
    audit = run('audit', ['scripts/assurance_acceptance_manifest.py', 'audit',
                '--root', str(SOURCE), '--manifest', str(OUTPUT / 'draft.json')], 'audit.json', 2)
    result = json.loads((OUTPUT / 'audit.json').read_bytes())
    if result['status'] != 'INCOMPLETE' or result['authority'] != 'NONE':
        raise ValueError('draft failed to retain incomplete/non-authoritative status')
    return {'tests': tests, 'draft': draft, 'audit': audit}, result


def main():
    entries = selection()
    archive = create_archive(entries)
    source_hashes = extract_archive(archive, entries)
    runtime = interpreter()
    runs, result = executions()
    after = {name: sha((SOURCE / name).read_bytes()) for name in source_hashes}
    if after != source_hashes or sha(Path(sys.executable).read_bytes()) != runtime['sha256']:
        raise ValueError('reproduction input identity changed')
    receipt = {'source_commit': COMMIT, 'source_archive_sha256': sha(archive.read_bytes()),
               'source_files_sha256': source_hashes, 'source_files_unchanged': True,
               'interpreter': runtime, 'commands': runs, 'authority': 'NONE',
               'status': 'TESTED_COMMITTED_CHECKER_ONLY', 'draft_audit_status': result['status'],
               'draft_gap_count': len(result['gaps']), 'runner_sha256': sha(Path(__file__).read_bytes()),
               'limits': ['No build, proof, installation, system, compliance or release acceptance.',
                          'Existing A/G/C/P obligations, failed evidence and OPEN gates remain binding.']}
    save_json('committed-reproduction.receipt.json', receipt)
    print(json.dumps({'status': receipt['status'], 'source_commit': COMMIT,
                      'draft_status': result['status'], 'authority': 'NONE'}))


if __name__ == '__main__':
    main()

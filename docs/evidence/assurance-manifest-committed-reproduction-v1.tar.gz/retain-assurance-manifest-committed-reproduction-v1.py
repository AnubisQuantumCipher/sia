#!/usr/bin/env python3
"""Retain fixed checker-reproduction bytes; never execute retained code."""
import argparse
import gzip
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import re
import stat
import sys
import tarfile

COMMIT = 'b947dbdd41f3a36f2e9a35cca8fa5dd3955e6ff7'
LIMIT = 1024 * 1024
PREFIX = 'evidence/acceptance-manifest-committed-reproduction-v1/'
BUNDLE = 'docs/evidence/assurance-manifest-committed-reproduction-v1.tar.gz'
MANIFEST = 'docs/ASSURANCE-MANIFEST-COMMITTED-EVIDENCE-V1.json'
NAMES = (
    'reproduce.py', 'source.tar', 'source-files.txt', 'source-git-blobs.json',
    'source-sha256.json', 'git-archive.stdout.log', 'git-archive.stderr.log',
    'git-archive.receipt.json', 'interpreter.json', 'focused-tests.stdout.log',
    'focused-tests.stderr.log', 'focused-tests.receipt.json', 'draft.json',
    'draft.stderr.log', 'draft.receipt.json', 'audit.json', 'audit.stderr.log',
    'audit.receipt.json', 'committed-reproduction.receipt.json',
    'committed-reproduction.report.txt', 'committed-reproduction.binding.json',
)


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def read(path):
    if not stat.S_ISREG(path.lstat().st_mode):
        raise ValueError('regular file required')
    with path.open('rb') as stream:
        raw = stream.read(LIMIT + 1)
    if len(raw) > LIMIT:
        raise ValueError('file byte budget')
    return raw


def collect(source):
    members = {PREFIX + name: read(source / name) for name in NAMES}
    members[Path(__file__).name] = read(Path(__file__))
    if len(members) > 32 or sum(len(raw) for raw in members.values()) > 16 * LIMIT:
        raise ValueError('aggregate retention budget')
    return members


def source_archive(raw, source_hashes):
    observed = {}
    with tarfile.open(fileobj=io.BytesIO(raw), mode='r:') as archive:
        if archive.pax_headers.get('comment') != COMMIT:
            raise ValueError('source archive commit mismatch')
        for count, member in enumerate(archive, 1):
            if count > 256 or member.name.startswith('/') or '..' in PurePosixPath(member.name).parts:
                raise ValueError('source archive roster/path budget')
            if member.isdir():
                continue
            if (not member.isfile() or member.name not in source_hashes
                    or member.name in observed or member.size > LIMIT):
                raise ValueError('unsupported source archive member')
            stream = archive.extractfile(member)
            with stream:
                content = stream.read(LIMIT + 1)
            if len(content) != member.size:
                raise ValueError('source archive member length mismatch')
            observed[member.name] = digest(content)
    if observed != source_hashes:
        raise ValueError('source archive hash/roster mismatch')


def verification(members):
    data = {name: members[PREFIX + name] for name in NAMES}
    binding = json.loads(data['committed-reproduction.binding.json'])
    receipt = json.loads(data['committed-reproduction.receipt.json'])
    if binding['source_commit'] != COMMIT or receipt['source_commit'] != COMMIT:
        raise ValueError('source commit mismatch')
    expected_artifacts = set(NAMES) - {'committed-reproduction.binding.json'}
    if set(binding['artifact_sha256']) != expected_artifacts:
        raise ValueError('bound artifact roster mismatch')
    for name, expected in binding['artifact_sha256'].items():
        if digest(data[name]) != expected:
            raise ValueError('original artifact mismatch: ' + name)
    sources = json.loads(data['source-sha256.json'])
    if (sources != binding['source_files_sha256'] or sources != receipt['source_files_sha256']
            or digest(data['source.tar']) != receipt['source_archive_sha256']
            or not receipt['source_files_unchanged']):
        raise ValueError('source identity mismatch')
    if data['source-files.txt'].decode().splitlines() != sorted(sources):
        raise ValueError('source file list mismatch')
    source_archive(data['source.tar'], sources)
    check_runs(data, receipt)
    return binding, receipt, json.loads(data['audit.json'])


def check_runs(data, receipt):
    for label, field, code in (('focused-tests', 'tests', 0), ('draft', 'draft', 0), ('audit', 'audit', 2)):
        run = json.loads(data[label + '.receipt.json'])
        if run != receipt['commands'][field] or run['exit'] != code or run['timed_out']:
            raise ValueError('run identity/outcome mismatch')
        if run['environment_override']['PYTHONWARNINGS'] != 'error' or run['timeout_seconds'] != 30:
            raise ValueError('warning/deadline mismatch')
        for stream in ('stdout', 'stderr'):
            name = run[stream]['path']
            if name not in NAMES or digest(data[name]) != run[stream]['sha256']:
                raise ValueError('run output hash mismatch')
    log = data['focused-tests.stderr.log'].decode()
    if not re.search(r'^Ran 30 tests in [^\n]+$', log, re.MULTILINE) or not log.rstrip().endswith('OK'):
        raise ValueError('expected complete test log absent')
    audit = json.loads(data['audit.json'])
    if audit['status'] != 'INCOMPLETE' or audit['authority'] != 'NONE':
        raise ValueError('incomplete/non-authoritative draft result absent')
    if receipt['authority'] != 'NONE' or receipt['draft_audit_status'] != audit['status']:
        raise ValueError('receipt consequence mismatch')


def archive(members):
    buffer = io.BytesIO()
    with tarfile.open(fileobj=buffer, mode='w', format=tarfile.USTAR_FORMAT) as stream:
        for name, raw in sorted(members.items()):
            member = tarfile.TarInfo(name)
            member.size, member.mode, member.mtime = len(raw), 0o644, 0
            stream.addfile(member, io.BytesIO(raw))
    return gzip.compress(buffer.getvalue(), mtime=0)


def manifest(members, compressed, binding, receipt, audit):
    return {
        'kind': 'Portable exact-committed-source checker reproduction; no system acceptance',
        'authority': 'NONE', 'source_commit': COMMIT,
        'bundle': {'path': BUNDLE, 'sha256': digest(compressed)},
        'members': {name: {'bytes': len(raw), 'sha256': digest(raw)}
                    for name, raw in sorted(members.items())},
        'source_archive': {'member': PREFIX + 'source.tar', 'sha256': receipt['source_archive_sha256']},
        'source_files_sha256': receipt['source_files_sha256'],
        'tests': {'status': 'TESTED', 'count': binding['observed_test_count'], 'exit': 0,
                  'summary': binding['observed_test_summary'], 'warnings': 'error',
                  'receipt': PREFIX + 'focused-tests.receipt.json'},
        'actual_draft_audit': {'status': audit['status'], 'authority': audit['authority'],
                              'exit': 2, 'gaps': len(audit['gaps']),
                              'draft': PREFIX + 'draft.json', 'audit': PREFIX + 'audit.json'},
        'reproduction_receipt': PREFIX + 'committed-reproduction.receipt.json',
        'report': PREFIX + 'committed-reproduction.report.txt',
        'preservation': 'Original raw fields and output bytes retained without modification.',
        'limits': ['No new tests are run by this retainer; it checks retained byte identities.',
                   'No build, proof, install, system, Power-of-Ten compliance or release acceptance.',
                   'Hashes do not authenticate producers, actual model identity or custody.',
                   'All existing failed evidence and A/G/C/P acceptance obligations remain binding.',
                   'Bounded Python allocation and filesystem operations are not formally proved.'],
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', type=Path, default=Path(__file__).parent / PREFIX)
    parser.add_argument('--output', type=Path, default=Path(__file__).parent)
    parser.add_argument('--check', action='store_true')
    args = parser.parse_args()
    members = collect(args.source)
    binding, receipt, audit = verification(members)
    compressed = archive(members)
    record = (json.dumps(manifest(members, compressed, binding, receipt, audit),
                         indent=2, sort_keys=True) + '\n').encode()
    for name, raw in ((BUNDLE, compressed), (MANIFEST, record)):
        target = args.output / name
        if args.check:
            if read(target) != raw:
                raise ValueError('retained bytes differ')
        else:
            target.parent.mkdir(parents=True, exist_ok=True)
            with target.open('xb') as stream:
                if stream.write(raw) != len(raw):
                    raise OSError('short publication write')
    print('Retained committed reproduction matches exactly' if args.check else 'Created committed reproduction package')


if __name__ == '__main__':
    try:
        main()
    except (OSError, ValueError, KeyError, TypeError, tarfile.TarError) as error:
        print(json.dumps({'status': 'REFUSED', 'authority': 'NONE', 'reason': str(error)}))
        sys.exit(1)

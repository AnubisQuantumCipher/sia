"""Retain full original workload results under the revised engineering policy."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import re
import tarfile

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent
REPO = Path('/home/sicarii/Work/sia-assurance-checkpoint-20261023')
CASES = ('source-capture-completion-20261025-v1',
         'source-resident-completion-20261025-v1',
         'source-writer-completion-20261025-v1')
FILES = ('run.py', 'static-result.json', 'static.stdout', 'static.stderr',
         'admission.json', 'process.json', 'result.json', 'full.stdout', 'full.stderr')
PRIOR = ('r05-fresh-delivery-capture-v1', 'r05-fresh-resident-v1',
         'writer-scalar-dispatch-full-writer-v1')
HEAD = '0db1d4f3c097d63e4d2741881b3a4e790764a0d2'


def read(path):
    with path.open('rb') as stream:
        raw = stream.read(8388609)
    if len(raw) > 8388608:
        raise ValueError('forensic member input capacity')
    return raw


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def validate_case(name):
    directory = ROOT / name
    result = json.loads(read(directory / 'result.json'))
    if result['source_head'] != HEAD or result['exit'] != 0 \
            or not result['unchanged'] or result['before'] != result['after']:
        raise ValueError('source or result mismatch')
    for stream in ('full.stdout', 'full.stderr'):
        if digest(read(directory / stream)) != result['outputs'][stream]:
            raise ValueError('raw output mismatch')
    for path, expected in result['after'].items():
        if digest(read(Path(path))) != expected:
            raise ValueError('bound input changed')
    raw = read(directory / 'full.stderr').decode('utf-8')
    terminal = re.search(r'\nRan ([0-9]+) tests in ([0-9.]+)s\n\nOK\n\Z', raw)
    if terminal is None or 'skipped' in raw:
        raise ValueError('missing complete unskipped terminal summary')
    return dict(case=name, tests=int(terminal[1]), seconds=terminal[2],
                exit=result['exit'], unchanged=True, source_pins=len(result['after']),
                wrapper_elapsed_ns=result['elapsed_ns'], outputs=result['outputs'])


def payloads():
    members = {name + '/' + file: read(ROOT / name / file)
               for name in CASES for file in FILES}
    for name in PRIOR:
        for file in ('workload-result.json', 'workload.stdout', 'workload.stderr'):
            members['prior/' + name + '/' + file] = read(ROOT / name / file)
    profile = 'writer-scalar-dispatch-full-writer-v1/profile_case.py'
    members['prior/' + profile] = read(ROOT / profile)
    policy = 'execution-policy-20261025-v1/AUTHORIZATION.md'
    members['AUTHORIZATION.md'] = read(ROOT / policy)
    for file in ('build_public.py', 'REPORT.md', 'review.md', 'root-readback.json',
                 'builder-static.json'):
        members['publication/' + file] = read(OUT / file)
    pins = {name: digest(raw) for name, raw in members.items()}
    members['SHA256.json'] = (json.dumps(pins, indent=2, sort_keys=True) + '\n').encode()
    return members


def archive(members):
    target = io.BytesIO()
    with gzip.GzipFile(fileobj=target, mode='wb', filename='', mtime=0) as zipped:
        with tarfile.open(fileobj=zipped, mode='w', format=tarfile.USTAR_FORMAT) as tar:
            for name, raw in sorted(members.items()):
                entry = tarfile.TarInfo(name)
                entry.size, entry.mode = len(raw), 0o644
                tar.addfile(entry, io.BytesIO(raw))
    return target.getvalue()


def main():
    results = [validate_case(name) for name in CASES]
    parent = json.loads(read(OUT / 'root-readback.json'))
    if not all(parent['parent_exit_zero'].values()) or not parent['clean_source_observed']:
        raise ValueError('parent or final source readback incomplete')
    members = payloads()
    raw = archive(members)
    if archive(members) != raw:
        raise ValueError('archive reproduction failed')
    relative = 'docs/evidence/source-workload-completion-20261025.tar.gz'
    report = dict(schema='sia.source-workload-completion.v1', source_head=HEAD,
        status='SELECTED_COMPLETE_ROSTERS_PASS_SYSTEM_INCOMPLETE', authority='NONE',
        results=results, engineering_caps_removed=True, product_bounds_unchanged=True,
        old_failures_retained=True, installed_qualification=False,
        whole_system_acceptance=False, archive=dict(path=relative,
        sha256=digest(raw), bytes=len(raw), members=len(members), reproduced=True))
    with (REPO / relative).open('xb') as stream:
        stream.write(raw)
    with (REPO / 'docs/SOURCE-WORKLOAD-COMPLETION-20261025.json').open('x') as stream:
        json.dump(report, stream, indent=2, sort_keys=True)
        stream.write('\n')
    with (REPO / 'docs/SOURCE-WORKLOAD-COMPLETION-20261025.md').open('xb') as stream:
        stream.write(read(OUT / 'REPORT.md'))
    print(json.dumps(report))


if __name__ == '__main__':
    main()

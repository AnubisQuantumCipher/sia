"""Read-only audit of this fresh reproduction; writes its review receipt only."""
import hashlib
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parent
STAGE = ROOT / 'stage-c3'
PROOF = STAGE / 'spark/pack-proposal-obj/gnatprove'
UNITS = {'sia_policy': 7, 'sia_pack_retirement': 16,
         'sia_pack_manifest_wire': 18, 'sia_pack_partition': 16,
         'sia_continuity': 18, 'sia_continuity_record_wire': 15,
         'sia_pack_plan_wire': 13, 'sia_pack_proposal': 15,
         'pack_retirement_tests': 0, 'pack_retirement_test_support': 0,
         'pack_manifest_tests': 0, 'pack_plan_wire_tests': 0,
         'pack_plan_wire_test_support': 0, 'pack_proposal_tests': 0}


def read(path, maximum=4194304):
    with path.open('rb') as stream:
        raw = stream.read(maximum + 1)
    if len(raw) > maximum:
        raise ValueError('audit input bound: ' + str(path))
    return raw


def load(path):
    return json.loads(read(path))


def sha(path):
    return hashlib.sha256(read(path)).hexdigest()


def phases():
    wanted = load(ROOT / 'admission.json')['source_sha256']
    results = {}
    for phase in ('build', 'runtime', 'retirement', 'wire', 'manifest', 'proof'):
        path = ROOT / ('c3-' + phase + '.result.json')
        record = load(path)
        if record['exit'] != 0 or not record['unchanged']:
            raise ValueError('failed phase: ' + phase)
        if record['before'] != wanted or record['after'] != wanted:
            raise ValueError('phase source mismatch: ' + phase)
        results[phase] = {'exit': record['exit'], 'elapsed_ns': record['elapsed_ns'],
                          'receipt_sha256': sha(path)}
    for name, digest in wanted.items():
        if sha(STAGE / name) != digest:
            raise ValueError('final source mismatch: ' + name)
    return results


def declarations():
    expected = set()
    private_records = {'sia_pack_manifest_wire': 'Cursor',
                       'sia_pack_partition': 'Partition_State', 'sia_pack_proposal': 'State'}
    pattern = re.compile(r'^(?:package|   function|   procedure) ([A-Za-z][A-Za-z0-9_]*)\b')
    for unit, count in UNITS.items():
        if count == 0:
            continue
        path = STAGE / 'spark/src' / (unit + '.ads')
        private = False
        for number, line in enumerate(read(path).decode().splitlines(), 1):
            private = private or line == 'private'
            match = pattern.match(line) if not private else None
            if match:
                name = match.group(1) if line.startswith('package ') else unit + '.' + match.group(1)
                expected.add((name.lower(), path.name, number))
            elif private and line == '   type ' + private_records.get(unit, '') + ' is record':
                expected.add((unit + '.' + private_records[unit].lower(), path.name, number))
    return expected


def report():
    lines = read(PROOF / 'gnatprove.out').decode().splitlines()
    totals = [line for line in lines if line.startswith('Total ')]
    pattern = r'Total\s+(\d+)\s+(\d+)(?: \([^)]*\))?\s+(\d+)(?: \([^)]*\))?\s+\.\s+\.'
    match = re.fullmatch(pattern, totals[0].strip()) if len(totals) == 1 else None
    if match is None:
        raise ValueError('unclean or missing totals')
    total, flow, prover = (int(value) for value in match.groups())
    if total != flow + prover:
        raise ValueError('inconsistent proof total')
    unit_pattern = re.compile(r'in unit ([a-z][a-z0-9_]*), (\d+) subprograms and packages out of (\d+) analyzed')
    detail = re.compile(r'  ([A-Za-z][A-Za-z0-9_.]*) at ([a-z][a-z0-9_]*\.ads):(\d+) flow analyzed \(0 errors, 0 checks, 0 warnings and 0 pragma Assume statements\) and proved \(\d+ checks\)')
    expected, seen, units, current = declarations(), set(), set(), None
    for line in lines:
        if line.startswith('in unit '):
            row = unit_pattern.fullmatch(line)
            if row is None:
                raise ValueError('malformed unit')
            current, analyzed, available = row.groups()
            if current in units or current not in UNITS or int(analyzed) != UNITS[current] or analyzed != available:
                raise ValueError('unit roster mismatch')
            units.add(current)
        elif ' at ' in line or 'flow analyzed' in line or 'pragma Assume' in line:
            row = detail.fullmatch(line)
            if row is None:
                raise ValueError('unclean detail')
            name, filename, number = row.groups()
            key = (name.lower(), filename, int(number))
            if key not in expected or key in seen or Path(filename).stem != current:
                raise ValueError('declaration coverage mismatch')
            seen.add(key)
    if units != set(UNITS) or seen != expected:
        raise ValueError('incomplete unit/declaration scope')
    return {'total': total, 'flow': flow, 'prover': prover, 'justified': 0,
            'unproved': 0, 'entities': sorted(seen), 'units': UNITS}


def raw_reports(expected_names):
    summary = {}
    for unit, count in UNITS.items():
        data = load(PROOF / (unit + '.spark'))
        if data['progress'] != 'PROGRESS_PROOF' or data['stop_reason'] != 'STOP_REASON_NONE':
            raise ValueError('incomplete raw unit: ' + unit)
        if len(data['spark']) != count or any(value != 'all' for value in data['spark'].values()):
            raise ValueError('partial SPARK unit: ' + unit)
        for key in ('pragma_assume', 'skip_proof', 'skip_flow_proof'):
            if data.get(key) != []:
                raise ValueError('assumed or excluded unit: ' + unit)
        for key in ('proof', 'flow', 'warn_error'):
            rows = data.get(key)
            if not isinstance(rows, list) or len(rows) > 4096 or any(row.get('severity') != 'info' for row in rows):
                raise ValueError('unclean raw diagnostics: ' + unit)
        for claim in data['assumptions']:
            for ref in [claim['claim'], *claim['assumptions']]:
                name = data['entities'][' ' + str(ref['arg'])]['name'].lower()
                if name not in expected_names:
                    raise ValueError('dependency outside declared analyzed scope: ' + name)
        summary[unit] = {'entities': count, 'raw_sha256': sha(PROOF / (unit + '.spark')),
                         'modular_assumption_rows': len(data['assumptions'])}
    for channel in ('stdout', 'stderr'):
        text = read(ROOT / ('c3-proof.' + channel)).decode()
        if re.search(r'\b(?:warning|error|low|medium|high):', text):
            raise ValueError('noninformational proof channel')
    return summary


def main():
    executed = phases()
    verified = report()
    raw = raw_reports({row[0] for row in verified['entities']})
    result = {'reviewer_model': 'GPT-6.1', 'status': 'INDEPENDENT_FOCUSED_REPRODUCTION_PASS',
              'phases': executed, 'proof': verified, 'raw_units': raw,
              'proof_report_sha256': sha(PROOF / 'gnatprove.out'),
              'source_admission_sha256': sha(ROOT / 'admission.json'),
              'auditor_sha256': sha(Path(__file__)),
              'limitations': ['Supported pinned flat-source declaration audit, not a general Ada parser',
                             'Ordinary modular assumptions and compiler/toolchain trust remain',
                             'Tests are SPARK-off runtime evidence',
                             'No original-byte authentication, hashing, custody or effect authority',
                             'No whole-system, original aggregate gate, native, R05 or release acceptance']}
    with (ROOT / 'final-review.json').open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps({'status': result['status'], 'checks': verified['total'],
                      'flow': verified['flow'], 'prover': verified['prover']}))


if __name__ == '__main__':
    main()

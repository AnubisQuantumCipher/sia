# Retained failures and limits

- Sealed predecessor v1 contains the strict build failure, missing discriminator
  contract, all full-proof timeouts, rejected auditors, intermediate sources,
  semantic mutants and unrun drafts. Its failures are not relabeled by c3.
- V2 c1: strict build and all original runtimes pass; complete proof exit124.
- V2 c2: strict build and all original runtimes pass; complete proof exit124.
  Expanded five-byte predicate alone did not qualify the composition.
- C1/c2 auditors exit1 with incomplete positive evidence; no acceptance file.
- Offline VC rendering first failed for a missing bundled standard-theory path;
  the second attempt inserted that path at flock's -F option and failed. The
  third corrected the argument placement, rendered without invoking a prover,
  and retained bundled-library warnings. Rendering is not proof qualification.
- V2 c3: full proof exit0; all original runtimes pass; raw-scope audit passes.
  Independent reproduction remains separately recorded, not inferred here.
- Negative6/8 replace full target with represented roster in both exclusion
  predicate and contract: strict builds pass, proposal runtime fails as required.
- Negative7/9 remove high-byte4 check: strict builds pass, original wire oracle
  fails as required. These are deliberately invalid candidates, never shipped.
- Original stage-negative (v1 c8-derived) remains UNRUN in v2.

No resource increase, scope narrowing, suppressed checks, runtime activation,
permission expansion, full-system assurance or release follows from this packet.
Native qualification, R05 useful reuse AND fresh policy validation, protected
capture/publication, harness lifecycle, retrieval, recovery and installed/release
obligations remain open. Complete current backup is not established.

"""Bounded deterministic evidence archives; archive integrity is not acceptance."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

ROOT = Path(__file__).resolve().parent


def pin(path):
    if path.is_symlink() or not path.is_file() or path.stat().st_size > 4 * 1024 * 1024:
        raise ValueError('nonregular or oversized member')
    raw = path.read_bytes()
    return {'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)}


def source_members(base, final_name, files):
    paths = set()
    rosters = {}
    stages = sorted(base.glob('stage-*'))
    if not stages or len(stages) > 16:
        raise ValueError('stage capacity')
    for stage in stages:
        roster = {}
        for name, expected in files.items():
            actual = pin(stage / name)['sha256']
            stored = base / final_name if actual == expected else stage
            member = stored / name
            paths.add(member)
            roster[name] = {'sha256': actual, 'archive_source': str(member.relative_to(base))}
        rosters[stage.name] = roster
    return paths, rosters


def members(base, final_name, files, independent=False):
    paths, rosters = source_members(base, final_name, files)
    for pattern in ('c[1-9]-*.*', 'negative*.*', 'audit*.*', 'integrity-audit*.json',
                    'static-*.*', 'REVIEW*.*', 'run*.py', 'offline-vc*.json'):
        paths.update(base.glob(pattern))
    for name in ('FAILURES.md', 'base.json', 'toolchain.json', 'RESULT.json'):
        if (base / name).exists():
            paths.add(base / name)
    for stage in sorted(base.glob('stage-*')):
        proof = stage / 'spark/pack-proposal-obj/gnatprove'
        for pattern in ('gnatprove.out', '*.spark', 'sia_pack_proposal__*/why3session.xml',
                        'sia_pack_plan_wire__roster_*/why3session.xml'):
            paths.update(proof.glob(pattern))
    if independent:
        other = base / 'independent-c3'
        paths.update(other.glob('*.json'))
        paths.update(other.glob('*.stdout'))
        paths.update(other.glob('*.stderr'))
        paths.update(other.glob('*.py'))
        proof = other / 'stage-c3/spark/pack-proposal-obj/gnatprove'
        paths.update(proof.glob('gnatprove.out'))
        paths.update(proof.glob('*.spark'))
        paths.add(base / 'package.py')
    if not paths or len(paths) > 512:
        raise ValueError('archive member capacity')
    return sorted(paths), rosters


def archive(base, paths, target):
    inventory = {}
    total = 0
    with target.open('xb') as out, gzip.GzipFile(fileobj=out, mode='wb', mtime=0, filename='') as compressed:
        with tarfile.open(fileobj=compressed, mode='w|') as tar:
            for path in paths:
                before = pin(path)
                total += before['bytes']
                if total > 16 * 1024 * 1024:
                    raise ValueError('archive byte capacity')
                raw = path.read_bytes()
                if hashlib.sha256(raw).hexdigest() != before['sha256']:
                    raise ValueError('source drift')
                name = str(path.relative_to(base))
                info = tarfile.TarInfo(name)
                info.size, info.mode, info.mtime = len(raw), 0o644, 0
                tar.addfile(info, io.BytesIO(raw))
                inventory[name] = before
    seen = set()
    with tarfile.open(target, 'r:gz') as tar:
        for member in tar:
            handle = tar.extractfile(member)
            if member.name in seen or handle is None or member.name not in inventory:
                raise ValueError('unexpected member')
            expected = inventory[member.name]
            if member.size != expected['bytes'] or hashlib.sha256(handle.read()).hexdigest() != expected['sha256']:
                raise ValueError('archive readback mismatch')
            seen.add(member.name)
    if seen != set(inventory):
        raise ValueError('incomplete archive')
    return {'path': target.name, **pin(target), 'members': inventory}


def main():
    prior = ROOT.parent / 'pack-proposal-admission-v1'
    sources = json.loads((ROOT / 'c3-proof.result.json').read_text())['before']
    previous = json.loads((prior / 'c8-proof.result.json').read_text())['before']
    for base, stage, files, label in ((prior, 'stage-c8', previous, 'prior-failures'),
                                      (ROOT, 'stage-c3', sources, 'qualified-c3')):
        paths, rosters = members(base, stage, files, base == ROOT)
        target = ROOT / ('proposal-' + label + '.tar.gz')
        result = archive(base, paths, target)
        result['source_rosters'] = rosters
        with (ROOT / ('archive-' + label + '.json')).open('x') as handle:
            json.dump(result, handle, indent=2)
        print(json.dumps({'path': target.name, 'members': len(paths), **pin(target)}))


if __name__ == '__main__':
    main()

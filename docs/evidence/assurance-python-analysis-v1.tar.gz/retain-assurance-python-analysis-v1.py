#!/usr/bin/env python3
"""Retain fixed partial-analysis evidence; never execute retained source."""
import argparse
import gzip
import hashlib
import io
import json
from pathlib import Path
import re
import stat
import sys
import tarfile

LIMIT = 2 * 1024 * 1024
BASE = '1292d328ebc27680a040a263a7445cb04b2d82bd'
BUNDLE = 'docs/evidence/assurance-python-analysis-v1.tar.gz'
MANIFEST = 'docs/ASSURANCE-PYTHON-ANALYSIS-EVIDENCE-V1.json'
RULE_HASH = '0fea46b8e04811e2b1142cc0517f8152d1c7f36641ca13e14d8b94ea9b3c0741'
TOOLS = 'evidence/assurance-analysis-tools-v1/'
REPAIR = 'evidence/acceptance-static-repair-v1/'
NAMES = (
    'evidence/acceptance-static-repair-v1/audit.receipt.json',
    'evidence/acceptance-static-repair-v1/audit.stderr',
    'evidence/acceptance-static-repair-v1/audit.stdout',
    'evidence/acceptance-static-repair-v1/counterexamples.receipt.json',
    'evidence/acceptance-static-repair-v1/counterexamples.stderr',
    'evidence/acceptance-static-repair-v1/counterexamples.stdout',
    'evidence/acceptance-static-repair-v1/draft.receipt.json',
    'evidence/acceptance-static-repair-v1/draft.stderr',
    'evidence/acceptance-static-repair-v1/draft.stdout',
    'evidence/acceptance-static-repair-v1/receipt.json',
    'evidence/acceptance-static-repair-v1/tests.receipt.json',
    'evidence/acceptance-static-repair-v1/tests.stderr',
    'evidence/acceptance-static-repair-v1/tests.stdout',
    'evidence/acceptance-static-repair-v1/verify.py',
    'evidence/assurance-analysis-tools-v1/actual-ci-step-v1/0.stderr',
    'evidence/assurance-analysis-tools-v1/actual-ci-step-v1/0.stdout',
    'evidence/assurance-analysis-tools-v1/actual-ci-step-v1/1.stderr',
    'evidence/assurance-analysis-tools-v1/actual-ci-step-v1/1.stdout',
    'evidence/assurance-analysis-tools-v1/actual-ci-step-v1/ci-step.sh',
    'evidence/assurance-analysis-tools-v1/actual-ci-step-v1/receipt.json',
    'evidence/assurance-analysis-tools-v1/actual-ci-step-v1/sia-assurance-checker-ruff.json',
    'evidence/assurance-analysis-tools-v1/actual-ci-step-v1/sia-assurance-checker-ruff.stderr',
    'evidence/assurance-analysis-tools-v1/actual-ci-step-v2/ci-step.sh',
    'evidence/assurance-analysis-tools-v1/actual-ci-step-v2/empty-rules/receipt.json',
    'evidence/assurance-analysis-tools-v1/actual-ci-step-v2/empty-rules/stderr',
    'evidence/assurance-analysis-tools-v1/actual-ci-step-v2/empty-rules/stdout',
    'evidence/assurance-analysis-tools-v1/actual-ci-step-v2/positive/receipt.json',
    'evidence/assurance-analysis-tools-v1/actual-ci-step-v2/positive/sia-assurance-checker-ruff.json',
    'evidence/assurance-analysis-tools-v1/actual-ci-step-v2/positive/sia-assurance-checker-ruff.stderr',
    'evidence/assurance-analysis-tools-v1/actual-ci-step-v2/positive/stderr',
    'evidence/assurance-analysis-tools-v1/actual-ci-step-v2/positive/stdout',
    'evidence/assurance-analysis-tools-v1/actual-ci-step-v2/receipt.json',
    'evidence/assurance-analysis-tools-v1/actual-ci-step-v2/suppression/receipt.json',
    'evidence/assurance-analysis-tools-v1/actual-ci-step-v2/suppression/stderr',
    'evidence/assurance-analysis-tools-v1/actual-ci-step-v2/suppression/stdout',
    'evidence/assurance-analysis-tools-v1/actual-ci-step-v2/syntax/receipt.json',
    'evidence/assurance-analysis-tools-v1/actual-ci-step-v2/syntax/stderr',
    'evidence/assurance-analysis-tools-v1/actual-ci-step-v2/syntax/stdout',
    'evidence/assurance-analysis-tools-v1/baseline-all.receipt.json',
    'evidence/assurance-analysis-tools-v1/baseline-all.stderr.log',
    'evidence/assurance-analysis-tools-v1/baseline-all.stdout.json',
    'evidence/assurance-analysis-tools-v1/candidate-lane-v1/receipt.json',
    'evidence/assurance-analysis-tools-v1/candidate-lane-v1/stderr.log',
    'evidence/assurance-analysis-tools-v1/candidate-lane-v1/stdout.json',
    'evidence/assurance-analysis-tools-v1/install.log',
    'evidence/assurance-analysis-tools-v1/prospective-lane-v1/all-rule-metadata.receipt.json',
    'evidence/assurance-analysis-tools-v1/prospective-lane-v1/all-rule-metadata.stderr.txt',
    'evidence/assurance-analysis-tools-v1/prospective-lane-v1/all-rule-metadata.stdout.json',
    'evidence/assurance-analysis-tools-v1/prospective-lane-v1/candidate-ci-snippet.yml.txt',
    'evidence/assurance-analysis-tools-v1/prospective-lane-v1/candidate-scope.json',
    'evidence/assurance-analysis-tools-v1/prospective-lane-v1/check-help.receipt.json',
    'evidence/assurance-analysis-tools-v1/prospective-lane-v1/check-help.stderr.txt',
    'evidence/assurance-analysis-tools-v1/prospective-lane-v1/check-help.stdout.txt',
    'evidence/assurance-analysis-tools-v1/prospective-lane-v1/checker-settings-v2.receipt.json',
    'evidence/assurance-analysis-tools-v1/prospective-lane-v1/checker-settings-v2.stderr.txt',
    'evidence/assurance-analysis-tools-v1/prospective-lane-v1/checker-settings-v2.stdout.txt',
    'evidence/assurance-analysis-tools-v1/prospective-lane-v1/checker-settings.receipt.json',
    'evidence/assurance-analysis-tools-v1/prospective-lane-v1/checker-settings.stderr.txt',
    'evidence/assurance-analysis-tools-v1/prospective-lane-v1/checker-settings.stdout.txt',
    'evidence/assurance-analysis-tools-v1/prospective-lane-v1/derive.py',
    'evidence/assurance-analysis-tools-v1/prospective-lane-v1/expanded-stable-rule-codes.txt',
    'evidence/assurance-analysis-tools-v1/prospective-lane-v1/expanded-stable-rules.json',
    'evidence/assurance-analysis-tools-v1/prospective-lane-v1/explicit-files-v2.receipt.json',
    'evidence/assurance-analysis-tools-v1/prospective-lane-v1/explicit-files-v2.stderr.txt',
    'evidence/assurance-analysis-tools-v1/prospective-lane-v1/explicit-files-v2.stdout.txt',
    'evidence/assurance-analysis-tools-v1/prospective-lane-v1/linux-wheel-derivation.json',
    'evidence/assurance-analysis-tools-v1/prospective-lane-v1/prospective-lane-report.txt',
    'evidence/assurance-analysis-tools-v1/prospective-lane-v1/prospective-lane.binding.json',
    'evidence/assurance-analysis-tools-v1/prospective-lane-v1/prospective-ruff-requirement.txt',
    'evidence/assurance-analysis-tools-v1/prospective-lane-v1/rule-help.receipt.json',
    'evidence/assurance-analysis-tools-v1/prospective-lane-v1/rule-help.stderr.txt',
    'evidence/assurance-analysis-tools-v1/prospective-lane-v1/rule-help.stdout.txt',
    'evidence/assurance-analysis-tools-v1/prospective-lane-v1/rule-selection-derivation.json',
    'evidence/assurance-analysis-tools-v1/prospective-lane-v1/selected-baseline-projection.json',
    'evidence/assurance-analysis-tools-v1/prospective-lane-v1/test-settings-v2.receipt.json',
    'evidence/assurance-analysis-tools-v1/prospective-lane-v1/test-settings-v2.stderr.txt',
    'evidence/assurance-analysis-tools-v1/prospective-lane-v1/test-settings-v2.stdout.txt',
    'evidence/assurance-analysis-tools-v1/prospective-lane-v1/version.receipt.json',
    'evidence/assurance-analysis-tools-v1/prospective-lane-v1/version.stderr.txt',
    'evidence/assurance-analysis-tools-v1/prospective-lane-v1/version.stdout.txt',
    'evidence/assurance-analysis-tools-v1/provisioning-inputs.json',
    'evidence/assurance-analysis-tools-v1/requirements.txt',
    'evidence/assurance-analysis-tools-v1/ruff-0.17.1-pypi.json',
    'evidence/assurance-analysis-tools-v1/static-analysis-scope-review-v1.binding.json',
    'evidence/assurance-analysis-tools-v1/static-analysis-scope-review-v1.txt',
    'evidence/independent-python-analysis-review-v1.binding.json',
    'evidence/independent-python-analysis-review-v1.txt',
    'evidence/original-roster-counterexamples.py',
    'evidence/packaging-staging-refusal-v0.json',
    'evidence/prepare-python-analysis-package.py',
    'source/analysis-snapshot/.github/workflows/ci.yml',
    'source/analysis-snapshot/docs/ASSURANCE-ACCEPTANCE-MANIFEST.md',
    'source/analysis-snapshot/docs/ASSURANCE-PYTHON-ANALYSIS.md',
    'source/analysis-snapshot/docs/evidence/assurance-ruff-rules-v1.txt',
    'source/base-1292d32.tar',
    'source/base-archive.receipt.json',
    'source/base-files.txt',
    'source/base-sha256.json',
    'source/epochs.json',
    'source/historical-ci-v1.yml',
    'source/repair-overlay/scripts/assurance_acceptance_manifest.py',
    'source/repair-overlay/tests/test_assurance_acceptance_manifest.py',
)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def read(path):
    if not stat.S_ISREG(path.lstat().st_mode):
        raise ValueError('regular file required')
    with path.open('rb') as stream:
        raw = stream.read(LIMIT + 1)
    if len(raw) > LIMIT:
        raise ValueError('retention file budget')
    return raw


def collect(root):
    members = {name: read(root / name) for name in NAMES}
    members[Path(__file__).name] = read(Path(__file__))
    if len(members) > 128 or sum(len(raw) for raw in members.values()) > 16 * 1024 * 1024:
        raise ValueError('retention aggregate budget')
    return members


def value(members, name):
    return json.loads(members[name])


def base_sources(members):
    expected = value(members, 'source/base-sha256.json')
    found = {}
    with tarfile.open(fileobj=io.BytesIO(members['source/base-1292d32.tar']), mode='r:') as archive:
        if archive.pax_headers.get('comment') != BASE:
            raise ValueError('historical base commit mismatch')
        for index, item in enumerate(archive, 1):
            if index > 256:
                raise ValueError('base source entry budget')
            if item.isdir():
                continue
            if not item.isfile() or item.name not in expected or item.name in found or item.size > LIMIT:
                raise ValueError('base source member mismatch')
            with archive.extractfile(item) as stream:
                raw = stream.read(LIMIT + 1)
            if len(raw) != item.size or sha(raw) != expected[item.name]:
                raise ValueError('base source byte mismatch')
            found[item.name] = raw
    if set(found) != set(expected):
        raise ValueError('base source roster mismatch')
    return found


def repair_context(members, base):
    source = dict(base)
    for name in ('scripts/assurance_acceptance_manifest.py', 'tests/test_assurance_acceptance_manifest.py'):
        source[name] = members['source/repair-overlay/' + name]
    receipt = value(members, REPAIR + 'receipt.json')
    if receipt['source_before'] != receipt['source_after']:
        raise ValueError('repair identity changed')
    for name, expected in receipt['source_after'].items():
        if sha(source[name]) != expected:
            raise ValueError('repair source mismatch')
    draft = value(members, REPAIR + 'draft.stdout')
    for name, expected in draft['plan']['inputs'].items():
        if sha(source[name]) != expected:
            raise ValueError('historical draft normative mismatch')
    for name, expected in draft['plan']['proof_inventory']['sources'].items():
        if sha(source[name]) != expected:
            raise ValueError('historical draft proof inventory mismatch')
    for check in receipt['checks']:
        if check['exit'] != check['expected_exit']:
            raise ValueError('retained behavioral run failed')
    log = members[REPAIR + 'tests.stderr'].decode()
    if not re.search(r'^Ran 26 tests in [^\n]+$', log, re.M) or not log.rstrip().endswith('OK'):
        raise ValueError('expected 26-test result absent')
    controls = [json.loads(row) for row in members[REPAIR + 'counterexamples.stdout'].splitlines()]
    if len(controls) != 4 or any(row['observed']['status'] != 'REFUSED' for row in controls):
        raise ValueError('original counterexample outcome mismatch')
    audit = value(members, REPAIR + 'audit.stdout')
    if audit['status'] != 'INCOMPLETE' or audit['authority'] != 'NONE' or len(audit['gaps']) != 434:
        raise ValueError('historical incomplete status mismatch')
    return source


def baseline_context(members, base):
    baseline = value(members, TOOLS + 'baseline-all.receipt.json')
    if baseline['exit'] != 1 or baseline['before'] != baseline['after']:
        raise ValueError('failed ALL baseline was lost')
    for name, expected in baseline['after'].items():
        if sha(base[name]) != expected:
            raise ValueError('baseline source mismatch')
    for channel in ('stdout', 'stderr'):
        name = 'baseline-all.stdout.json' if channel == 'stdout' else 'baseline-all.stderr.log'
        if sha(members[TOOLS + name]) != baseline[channel + '_sha256']:
            raise ValueError('baseline output mismatch')
    if len(value(members, TOOLS + 'baseline-all.stdout.json')) != 1832:
        raise ValueError('unfiltered baseline diagnostics changed')
    prospective = TOOLS + 'prospective-lane-v1/'
    failed = value(members, prospective + 'checker-settings.receipt.json')
    if failed['exit'] != 2 or not members[prospective + 'checker-settings.stderr.txt']:
        raise ValueError('failed metadata command lost')
    binding = value(members, prospective + 'prospective-lane.binding.json')
    for name, expected in binding['artifact_sha256'].items():
        if sha(members[prospective + name]) != expected:
            raise ValueError('prospective artifact mismatch')
    rules = members['source/analysis-snapshot/docs/evidence/assurance-ruff-rules-v1.txt']
    if sha(rules) != RULE_HASH or rules != members[prospective + 'expanded-stable-rule-codes.txt']:
        raise ValueError('frozen rule scope mismatch')
    if len(rules.splitlines()) != 167:
        raise ValueError('expanded stable rule count mismatch')
    provision = value(members, TOOLS + 'provisioning-inputs.json')
    if sha(members[TOOLS + 'ruff-0.17.1-pypi.json']) != provision['metadata_sha256']:
        raise ValueError('official provisioning metadata mismatch')


def ci_context(members, source):
    for version in ('v1', 'v2'):
        prefix = TOOLS + 'actual-ci-step-' + version + '/'
        receipt = value(members, prefix + 'receipt.json')
        if receipt['source_before'] != receipt['source_after']:
            raise ValueError('CI identity changed during execution')
        for name, expected in receipt['source_after'].items():
            if name == '.github/workflows/ci.yml' and version == 'v1':
                raw = members['source/historical-ci-v1.yml']
            elif 'source/analysis-snapshot/' + name in members:
                raw = members['source/analysis-snapshot/' + name]
            else:
                raw = source[name]
            if sha(raw) != expected:
                raise ValueError('CI source mismatch')
        if version == 'v1':
            if any(row['exit'] != 0 for row in receipt['checks']):
                raise ValueError('historical CI failed')
            continue
        if [row['exit'] for row in receipt['checks']] != [0, 0, 1, 1]:
            raise ValueError('final CI/control result mismatch')
        if sha(members[prefix + 'ci-step.sh']) != receipt['script_sha256']:
            raise ValueError('final CI body hash mismatch')
        if value(members, prefix + 'positive/sia-assurance-checker-ruff.json') != []:
            raise ValueError('final diagnostics nonempty')
        if members[prefix + 'positive/sia-assurance-checker-ruff.stderr'] or members[prefix + 'positive/stderr']:
            raise ValueError('final stderr nonempty')
        if members[prefix + 'empty-rules/stderr'] != b'Frozen analyzer rule identity mismatch\n':
            raise ValueError('empty-rule control output mismatch')
        if not members[prefix + 'suppression/stderr'].startswith(b'Oversized source or suppression directive: '):
            raise ValueError('suppression control output mismatch')
    lane = value(members, TOOLS + 'candidate-lane-v1/receipt.json')
    if lane['source_before'] != lane['source_after']:
        raise ValueError('development lane source changed')
    for name, expected in lane['source_after'].items():
        if sha(source[name]) != expected:
            raise ValueError('development lane source mismatch')
    if lane['exit'] != 0 or value(members, TOOLS + 'candidate-lane-v1/stdout.json') != []:
        raise ValueError('selected-prefix development lane failed')
    if members[TOOLS + 'candidate-lane-v1/stderr.log']:
        raise ValueError('selected-prefix development stderr nonempty')


def archive(members):
    buffer = io.BytesIO()
    with tarfile.open(fileobj=buffer, mode='w', format=tarfile.USTAR_FORMAT) as stream:
        for name, raw in sorted(members.items()):
            item = tarfile.TarInfo(name)
            item.size, item.mode, item.mtime = len(raw), 0o644, 0
            stream.addfile(item, io.BytesIO(raw))
    return gzip.compress(buffer.getvalue(), mtime=0)


def manifest(members, compressed):
    return {'kind': 'Retained partial Python correctness-analysis increment; no system acceptance',
        'authority': 'NONE', 'base_commit': BASE,
        'bundle': {'path': BUNDLE, 'sha256': sha(compressed)},
        'source_epochs': value(members, 'source/epochs.json'),
        'members': {name: {'bytes': len(raw), 'sha256': sha(raw)} for name, raw in sorted(members.items())},
        'analysis': {'version': 'Ruff 0.17.1', 'local_platform': 'Linux aarch64',
            'stable_rule_count': 167, 'rule_file_sha256': RULE_HASH,
            'status': 'Retained local exact-CI step passed; remote/x86_64 CI UNRUN',
            'final_receipt': TOOLS + 'actual-ci-step-v2/receipt.json'},
        'behavior': {'manifest_tests': 26, 'original_counterexamples': '4 REFUSED',
            'actual_draft_status': 'INCOMPLETE', 'actual_draft_authority': 'NONE',
            'actual_audit_exit': 2, 'gaps': 434, 'receipt': REPAIR + 'receipt.json'},
        'retained_negative_results': ['Unfiltered ALL baseline: exit 1, 1832 diagnostics plus incompatible-rule warnings',
            'Prospective metadata option conflict: exit 2', 'Packaging staging source-identity refusal',
            'Final empty-rule and suppression controls: exit 1'],
        'review': 'evidence/independent-python-analysis-review-v1.txt',
        'limits': ['No new analyzer, test, build or proof execution by this retainer.',
            'No wheels, virtualenv, executables, private corpus or operational handoff included.',
            'Historical base plus Python overlay is distinct from later CI/docs snapshot.',
            'Original negative-control receipts lack per-fixture input hashes; they are retained local observations.',
            'Unrelated live Ada/Goal edits are excluded; complete system/proof/P10 acceptance remains OPEN.',
            'Parser/preview bounds are not disk quotas, WCET, static allocation proof or authenticated custody.',
            'Producer/model identity and approval authenticity are not established by hashes.']}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', type=Path, default=Path(__file__).parent)
    parser.add_argument('--output', type=Path, default=Path(__file__).parent)
    parser.add_argument('--check', action='store_true')
    args = parser.parse_args()
    members = collect(args.source)
    base = base_sources(members)
    source = repair_context(members, base)
    baseline_context(members, base)
    ci_context(members, source)
    compressed = archive(members)
    record = (json.dumps(manifest(members, compressed), indent=2, sort_keys=True) + '\n').encode()
    for name, raw in ((BUNDLE, compressed), (MANIFEST, record)):
        path = args.output / name
        if args.check:
            if read(path) != raw:
                raise ValueError('retained bytes differ')
        else:
            path.parent.mkdir(parents=True, exist_ok=True)
            with path.open('xb') as stream:
                if stream.write(raw) != len(raw):
                    raise OSError('short publication write')
    print('Partial analysis evidence reproduced exactly' if args.check else 'Created partial analysis evidence')


if __name__ == '__main__':
    try:
        main()
    except (OSError, ValueError, KeyError, TypeError, tarfile.TarError) as error:
        print(json.dumps({'status': 'REFUSED', 'authority': 'NONE', 'reason': str(error)}))
        sys.exit(1)

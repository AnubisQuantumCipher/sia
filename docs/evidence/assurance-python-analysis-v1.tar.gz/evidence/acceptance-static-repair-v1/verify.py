from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import sys
import time

ROOT = Path('/home/sicarii/Work/sia-assurance-kernel-20261019')
OUT = Path(__file__).resolve().parent
INPUTS = ('scripts/assurance_acceptance_manifest.py',
          'tests/test_assurance_acceptance_manifest.py',
          'docs/ASSURANCE-GOAL.md', 'docs/ASSURANCE-IMPLEMENTATION-GATES.md',
          'docs/AGENT-CONTINUITY.md', 'docs/POWER-OF-TEN-ASSESSMENT.md',
          'docs/ASSURANCE-COMPLETION-CONTRACT-20261021-V2.txt')
COUNTER = Path('/home/sicarii/Work/sia-assurance-evidence-20261019/takeover-manifest-independent-v1/roster_counterexamples.py')

def hashes():
    return {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest()
            for name in INPUTS}

def run(name, arguments, expected):
    env = dict(os.environ, PYTHONWARNINGS='error', PYTHONNOUSERSITE='1',
               PYTHONPATH=str(ROOT), PYTHONDONTWRITEBYTECODE='1')
    command = ['/usr/bin/timeout', '--kill-after=5s', '30s', sys.executable, '-B'] + arguments
    started = time.monotonic()
    with (OUT / (name + '.stdout')).open('xb') as stdout, (OUT / (name + '.stderr')).open('xb') as stderr:
        result = subprocess.run(command, cwd=ROOT, env=env, stdout=stdout, stderr=stderr, timeout=36)
    receipt = {'command': command, 'exit': result.returncode,
               'expected_exit': expected, 'elapsed_seconds': time.monotonic() - started}
    (OUT / (name + '.receipt.json')).write_text(json.dumps(receipt, indent=2) + '\n')
    if result.returncode != expected:
        raise RuntimeError('unexpected exit: ' + name)
    return receipt

def main():
    before = hashes()
    checks = [run('tests', ['-m', 'unittest', 'tests.test_assurance_acceptance_manifest', '-v'], 0),
              run('counterexamples', [str(COUNTER)], 0),
              run('draft', ['scripts/assurance_acceptance_manifest.py', 'draft'], 0),
              run('audit', ['scripts/assurance_acceptance_manifest.py', 'audit', '--manifest', str(OUT / 'draft.stdout')], 2)]
    probes = [json.loads(line) for line in (OUT / 'counterexamples.stdout').read_text().splitlines()]
    audit = json.loads((OUT / 'audit.stdout').read_text())
    if len(probes) != 4 or any(p['observed']['status'] != 'REFUSED' for p in probes):
        raise RuntimeError('counterexample mismatch')
    if audit['status'] != 'INCOMPLETE' or audit['authority'] != 'NONE':
        raise RuntimeError('audit mismatch')
    after = hashes()
    if before != after:
        raise RuntimeError('source changed during verification')
    receipt = {'status': 'TESTED scoped checker repair only', 'source_before': before,
               'source_after': after, 'checks': checks,
               'python': str(Path(sys.executable).resolve()),
               'python_sha256': hashlib.sha256(Path(sys.executable).resolve().read_bytes()).hexdigest(),
               'counterexample_sha256': hashlib.sha256(COUNTER.read_bytes()).hexdigest(),
               'audit_status': audit['status'], 'authority': audit['authority'],
               'gap_count': len(audit['gaps']),
               'test_summary': re.findall(r'^Ran .*$|^OK$', (OUT / 'tests.stderr').read_text(), re.M),
               'limits': 'Development overlay; static analysis, committed reproduction and all system gates remain OPEN.'}
    (OUT / 'receipt.json').write_text(json.dumps(receipt, indent=2, sort_keys=True) + '\n')
    print(json.dumps({k: receipt[k] for k in ('status', 'audit_status', 'authority', 'gap_count', 'test_summary')}))

if __name__ == '__main__':
    main()

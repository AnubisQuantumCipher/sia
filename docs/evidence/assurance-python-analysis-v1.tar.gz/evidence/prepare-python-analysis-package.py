"""Freeze selected public evidence and verify its distinct source epochs."""
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile

REPO = Path('/home/sicarii/Work/sia-assurance-kernel-20261019')
EVIDENCE = Path('/home/sicarii/Work/sia-assurance-evidence-20261019')
TOOLS = EVIDENCE / 'assurance-analysis-tools-v1'
OUTPUT = Path(__file__).resolve().parent
INPUTS = OUTPUT / 'inputs'
BASE = '1292d328ebc27680a040a263a7445cb04b2d82bd'
LIMIT = 2 * 1024 * 1024
SOURCES = ('scripts/assurance_acceptance_manifest.py', 'scripts/assurance_source_inventory.py',
           'tests/test_assurance_acceptance_manifest.py', 'tests/test_assurance_source_inventory.py',
           'docs/ASSURANCE-GOAL.md', 'docs/ASSURANCE-IMPLEMENTATION-GATES.md',
           'docs/AGENT-CONTINUITY.md', 'docs/POWER-OF-TEN-ASSESSMENT.md',
           'docs/ASSURANCE-COMPLETION-CONTRACT-20261021-V2.txt',
           'docs/ASSURANCE-ACCEPTANCE-MANIFEST.md', '.github/workflows/ci.yml',
           'spark/sia_assurance.gpr', 'spark/restrictions.adc')
SNAPSHOT = ('.github/workflows/ci.yml', 'docs/ASSURANCE-PYTHON-ANALYSIS.md',
            'docs/ASSURANCE-ACCEPTANCE-MANIFEST.md', 'docs/evidence/assurance-ruff-rules-v1.txt')
TOOLS_FILES = ('ruff-0.17.1-pypi.json', 'provisioning-inputs.json', 'requirements.txt',
               'install.log', 'baseline-all.stdout.json', 'baseline-all.stderr.log',
               'baseline-all.receipt.json', 'static-analysis-scope-review-v1.txt',
               'static-analysis-scope-review-v1.binding.json')
REPAIR_FILES = ('verify.py', 'receipt.json', 'tests.stdout', 'tests.stderr',
                'tests.receipt.json', 'counterexamples.stdout', 'counterexamples.stderr',
                'counterexamples.receipt.json', 'draft.stdout', 'draft.stderr',
                'draft.receipt.json', 'audit.stdout', 'audit.stderr', 'audit.receipt.json')
PROSPECTIVE = ('all-rule-metadata.receipt.json', 'all-rule-metadata.stdout.json',
    'all-rule-metadata.stderr.txt', 'candidate-ci-snippet.yml.txt', 'candidate-scope.json',
    'check-help.receipt.json', 'check-help.stdout.txt', 'check-help.stderr.txt',
    'checker-settings.receipt.json', 'checker-settings.stdout.txt', 'checker-settings.stderr.txt',
    'checker-settings-v2.receipt.json', 'checker-settings-v2.stdout.txt', 'checker-settings-v2.stderr.txt',
    'derive.py', 'expanded-stable-rule-codes.txt', 'expanded-stable-rules.json',
    'explicit-files-v2.receipt.json', 'explicit-files-v2.stdout.txt', 'explicit-files-v2.stderr.txt',
    'linux-wheel-derivation.json', 'prospective-lane-report.txt', 'prospective-lane.binding.json',
    'prospective-ruff-requirement.txt', 'rule-help.receipt.json', 'rule-help.stdout.txt',
    'rule-help.stderr.txt', 'rule-selection-derivation.json', 'selected-baseline-projection.json',
    'test-settings-v2.receipt.json', 'test-settings-v2.stdout.txt', 'test-settings-v2.stderr.txt',
    'version.receipt.json', 'version.stdout.txt', 'version.stderr.txt')


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def read(path):
    with path.open('rb') as stream:
        raw = stream.read(LIMIT + 1)
    if len(raw) > LIMIT:
        raise ValueError('snapshot byte budget')
    return raw


def put(name, raw):
    path = INPUTS / name
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as stream:
        if stream.write(raw) != len(raw):
            raise OSError('short snapshot write')


def put_json(name, value):
    put(name, (json.dumps(value, indent=2, sort_keys=True) + '\n').encode())


def git(*args):
    result = subprocess.run(['git', '-C', str(REPO), *args], capture_output=True,
                            timeout=30, check=False)
    if result.returncode != 0:
        raise ValueError('Git metadata/archive failed')
    return result.stdout


def base_archive():
    names = set(SOURCES)
    for path in git('ls-tree', '-r', '--name-only', BASE, '--', 'spark/src', 'spark/tests').decode().splitlines():
        if path.endswith(('.ads', '.adb')):
            names.add(path)
    raw = git('archive', '--format=tar', BASE, '--', *sorted(names))
    put('source/base-1292d32.tar', raw)
    put('source/base-files.txt', ('\n'.join(sorted(names)) + '\n').encode())
    contents = {}
    with tarfile.open(fileobj=io.BytesIO(raw), mode='r:') as archive:
        if archive.pax_headers.get('comment') != BASE:
            raise ValueError('base archive commit mismatch')
        for member in archive:
            if member.isfile():
                contents[member.name] = archive.extractfile(member).read(LIMIT + 1)
            elif not member.isdir():
                raise ValueError('unsupported base source member')
    if set(contents) != names:
        raise ValueError('base archive roster mismatch')
    put_json('source/base-sha256.json', {name: sha(value) for name, value in contents.items()})
    put_json('source/base-archive.receipt.json', {
        'command': ['git', '-C', str(REPO), 'archive', '--format=tar', BASE, '--', *sorted(names)],
        'exit': 0, 'timeout_seconds': 30, 'source_commit': BASE, 'archive_sha256': sha(raw)})
    return contents


def source_snapshots(base):
    repair = json.loads(read(EVIDENCE / 'acceptance-static-repair-v1/receipt.json'))
    overlay = {}
    for name in ('scripts/assurance_acceptance_manifest.py', 'tests/test_assurance_acceptance_manifest.py'):
        value = read(REPO / name)
        if sha(value) != repair['source_after'][name]:
            raise ValueError('repair source changed after execution')
        overlay[name] = value
        put('source/repair-overlay/' + name, value)
    expected = base['scripts/assurance_acceptance_manifest.py']
    for old, new in ((b'zip(rows, expected):', b'zip(rows, expected, strict=True):'),
                     (b'zip(rows, expected):', b'zip(rows, expected, strict=True):')):
        expected = expected.replace(old, new, 1)
    if expected != overlay['scripts/assurance_acceptance_manifest.py']:
        raise ValueError('checker edits differ from the two reviewed strict joins')
    marker = b'    def test_wide_or_noncanonical_numeric_rows_cannot_disappear(self):\n        for name, prefix, count, columns in CHECK.TABLES:'
    changed = marker.replace(b'prefix, count,', b'prefix, _count,')
    if base['tests/test_assurance_acceptance_manifest.py'].replace(marker, changed, 1) != overlay['tests/test_assurance_acceptance_manifest.py']:
        raise ValueError('test edit differs from reviewed unused-name change')
    snapshot = {name: read(REPO / name) for name in SNAPSHOT}
    for name, value in snapshot.items():
        put('source/analysis-snapshot/' + name, value)
    put_json('source/epochs.json', {'historical_repair': {'base_commit': BASE,
        'overlay_sha256': {name: sha(value) for name, value in overlay.items()},
        'description': 'Exact base plus only two Python files; before later CI/docs and Current Ada work.'},
        'later_analysis_snapshot_sha256': {name: sha(value) for name, value in snapshot.items()},
        'excluded': ['Live unrelated Current Ada overlay', 'Any later ASSURANCE-GOAL append']})
    return {**base, **overlay}, snapshot


def copy_evidence():
    for name in TOOLS_FILES:
        put('evidence/assurance-analysis-tools-v1/' + name, read(TOOLS / name))
    for name in PROSPECTIVE:
        put('evidence/assurance-analysis-tools-v1/prospective-lane-v1/' + name,
            read(TOOLS / 'prospective-lane-v1' / name))
    for directory, names in (
        ('candidate-lane-v1', ('stdout.json', 'stderr.log', 'receipt.json')),
        ('actual-ci-step-v1', ('ci-step.sh', 'receipt.json', '0.stdout', '0.stderr',
                              '1.stdout', '1.stderr', 'sia-assurance-checker-ruff.json',
                              'sia-assurance-checker-ruff.stderr'))):
        for name in names:
            put('evidence/assurance-analysis-tools-v1/' + directory + '/' + name,
                read(TOOLS / directory / name))
    for name in REPAIR_FILES:
        put('evidence/acceptance-static-repair-v1/' + name,
            read(EVIDENCE / 'acceptance-static-repair-v1' / name))
    final_names = ('ci-step.sh', 'receipt.json', 'syntax/receipt.json', 'syntax/stdout',
        'syntax/stderr', 'positive/receipt.json', 'positive/stdout', 'positive/stderr',
        'positive/sia-assurance-checker-ruff.json', 'positive/sia-assurance-checker-ruff.stderr',
        'empty-rules/receipt.json', 'empty-rules/stdout', 'empty-rules/stderr',
        'suppression/receipt.json', 'suppression/stdout', 'suppression/stderr')
    for name in final_names:
        put('evidence/assurance-analysis-tools-v1/actual-ci-step-v2/' + name,
            read(TOOLS / 'actual-ci-step-v2' / name))
    put('evidence/original-roster-counterexamples.py',
        read(EVIDENCE / 'takeover-manifest-independent-v1/roster_counterexamples.py'))
    put('evidence/packaging-staging-refusal-v0.json', read(OUTPUT / 'staging-refusal-v0.json'))


def verify_context(source, snapshot):
    repair = json.loads(read(EVIDENCE / 'acceptance-static-repair-v1/receipt.json'))
    if repair['source_before'] != repair['source_after']:
        raise ValueError('repair source changed during test run')
    for name, expected in repair['source_after'].items():
        if sha(source[name]) != expected:
            raise ValueError('historical repair input mismatch: ' + name)
    draft = json.loads(read(EVIDENCE / 'acceptance-static-repair-v1/draft.stdout'))
    for name, expected in draft['plan']['inputs'].items():
        if sha(source[name]) != expected:
            raise ValueError('draft normative input mismatch')
    for name, expected in draft['plan']['proof_inventory']['sources'].items():
        if sha(source[name]) != expected:
            raise ValueError('draft proof inventory differs from exact committed base')
    actual = json.loads(read(TOOLS / 'actual-ci-step-v2/receipt.json'))
    if actual['source_before'] != actual['source_after']:
        raise ValueError('CI source changed during retained run')
    for name, expected in actual['source_after'].items():
        value = snapshot[name] if name in snapshot else source[name]
        if sha(value) != expected:
            raise ValueError('actual CI input mismatch')
    workflow = snapshot['.github/workflows/ci.yml'].decode()
    start = workflow.index('      - name: experimental assurance checker static analysis\n')
    start = workflow.index('        run: |\n', start) + len('        run: |\n')
    end = workflow.index('      - name: experimental assurance boundary controls\n', start)
    block = ''.join(line[10:] if line.startswith('          ') else line
                    for line in workflow[start:end].splitlines(keepends=True))
    if block.encode() != read(TOOLS / 'actual-ci-step-v2/ci-step.sh'):
        raise ValueError('executed CI shell differs from retained workflow')
    prior_block = read(TOOLS / 'actual-ci-step-v1/ci-step.sh').decode()
    prior_workflow = workflow[:start] + ''.join('          ' + line
        for line in prior_block.splitlines(keepends=True)) + workflow[end:]
    prior = json.loads(read(TOOLS / 'actual-ci-step-v1/receipt.json'))
    if sha(prior_workflow.encode()) != prior['source_after']['.github/workflows/ci.yml']:
        raise ValueError('historical v1 CI reconstruction mismatch')
    put('source/historical-ci-v1.yml', prior_workflow.encode())
    rules = snapshot['docs/evidence/assurance-ruff-rules-v1.txt']
    if rules != read(TOOLS / 'prospective-lane-v1/expanded-stable-rule-codes.txt'):
        raise ValueError('frozen rule scope differs from reviewed expansion')


if __name__ == '__main__':
    INPUTS.mkdir()
    base = base_archive()
    source, snapshot = source_snapshots(base)
    verify_context(source, snapshot)
    copy_evidence()
    names = sorted(str(path.relative_to(INPUTS)) for path in INPUTS.rglob('*') if path.is_file())
    if len(names) > 128:
        raise ValueError('explicit member budget')
    (OUTPUT / 'member-names.json').write_text(json.dumps(names, indent=2) + '\n')
    print(json.dumps({'selected_members_before_review_retainer': len(names),
                      'historical_base': BASE, 'review_blockers': [], 'authority': 'NONE'}))

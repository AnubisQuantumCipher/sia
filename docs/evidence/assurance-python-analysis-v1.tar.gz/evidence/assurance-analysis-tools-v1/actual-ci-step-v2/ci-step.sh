set -euo pipefail
test "$(ruff --version)" = 'ruff 0.17.1'
# Reject all suppression directives, including the newer Ruff forms.
# This conservative byte scan also refuses directive-like text in strings.
python3 -B - <<'PY'
from pathlib import Path
import hashlib
import re
with Path('docs/evidence/assurance-ruff-rules-v1.txt').open('rb') as rules:
    raw_rules = rules.read(65537)
if len(raw_rules) > 65536 or hashlib.sha256(raw_rules).hexdigest() != '0fea46b8e04811e2b1142cc0517f8152d1c7f36641ca13e14d8b94ea9b3c0741':
    raise SystemExit('Frozen analyzer rule identity mismatch')
names = ('scripts/assurance_acceptance_manifest.py', 'tests/test_assurance_acceptance_manifest.py')
forbidden = re.compile(rb'#\s*(?:noqa\b|(?:ruff|flake8)\s*:\s*(?:noqa\b|ignore\b|file-ignore\b|disable\b|enable\b))', re.I)
for name in names:
    with Path(name).open('rb') as source:
        raw = source.read(1048577)
    if len(raw) > 1048576 or forbidden.search(raw):
        raise SystemExit('Oversized source or suppression directive: ' + name)
PY
task_ruff_rules="$(paste -sd, docs/evidence/assurance-ruff-rules-v1.txt)"
task_ruff_json="$RUNNER_TEMP/sia-assurance-checker-ruff.json"
task_ruff_stderr="$RUNNER_TEMP/sia-assurance-checker-ruff.stderr"
task_ruff_exit=0
timeout --kill-after=5s 30s ruff check \
  --isolated --no-cache --target-version py312 \
  --select "$task_ruff_rules" \
  --ignore-noqa --no-fix --no-fix-only --no-unsafe-fixes --no-preview \
  --no-respect-gitignore --no-force-exclude --output-format json \
  scripts/assurance_acceptance_manifest.py \
  tests/test_assurance_acceptance_manifest.py \
  > "$task_ruff_json" 2> "$task_ruff_stderr" || task_ruff_exit=$?
# Bounded previews only; the exit/stderr/complete-JSON gates below
# still reject a failure even when its diagnostic output is larger.
head -c 65536 "$task_ruff_json"
head -c 65536 "$task_ruff_stderr" >&2
test "$task_ruff_exit" -eq 0
test ! -s "$task_ruff_stderr"
python3 -B - "$task_ruff_json" <<'PYJSON'
from pathlib import Path
import json
import sys
with Path(sys.argv[1]).open('rb') as source:
    raw = source.read(1048577)
if len(raw) > 1048576:
    raise SystemExit('Analyzer output exceeds byte limit')
value = json.loads(raw.decode('utf-8'))
if type(value) is not list or value:
    raise SystemExit('Analyzer diagnostics are not empty')
PYJSON

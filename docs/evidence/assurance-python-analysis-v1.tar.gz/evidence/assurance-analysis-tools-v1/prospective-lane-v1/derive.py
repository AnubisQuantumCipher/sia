"""Derive fixed rule/wheel data from retained metadata; run no analyzer."""
import hashlib
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parent
SELECTORS = ('E4', 'E7', 'E9', 'F', 'B', 'A', 'BLE', 'PLE', 'PLW', 'RUF100')
WHEELS = ('ruff-0.17.1-py3-none-manylinux_2_17_aarch64.manylinux2014_aarch64.whl',
          'ruff-0.17.1-py3-none-manylinux_2_17_x86_64.manylinux2014_x86_64.whl')


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(name, value):
    (ROOT / name).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def enabled(name):
    text = (ROOT / name).read_text()
    block = re.search(r'^linter\.rules\.enabled = \[\n(.*?)^\]', text, re.M | re.S)
    if block is None:
        raise ValueError('enabled rule metadata absent')
    return sorted(re.findall(r'\(([A-Z]+[0-9]+)\)', block[1]))


def matches(code, selector):
    rule = re.fullmatch(r'([A-Z]+)([0-9]+)', code)
    selected = re.fullmatch(r'([A-Z]+)([0-9]*)', selector)
    if rule is None or selected is None:
        raise ValueError('unsupported selector/code')
    return rule[1] == selected[1] and rule[2].startswith(selected[2])


def rules():
    metadata = json.loads((ROOT / 'all-rule-metadata.stdout.json').read_bytes())
    coded = [item for item in metadata if isinstance(item['code'], str)]
    selected = enabled('checker-settings-v2.stdout.txt')
    if selected != enabled('test-settings-v2.stdout.txt'):
        raise ValueError('file-specific expansion mismatch')
    expected = sorted(item['code'] for item in coded
                      if any(matches(item['code'], selector) for selector in SELECTORS)
                      and 'Stable' in item['status'] and not item['preview'])
    if selected != expected:
        raise ValueError('stable rules differ from effective settings')
    by_code = {item['code']: item for item in coded}
    fields = ('code', 'name', 'status', 'preview', 'category', 'linter')
    write('expanded-stable-rules.json', [
        {field: by_code[code][field] for field in fields} for code in selected])
    (ROOT / 'expanded-stable-rule-codes.txt').write_text('\n'.join(selected) + '\n')
    write('rule-selection-derivation.json', {
        'selectors': list(SELECTORS), 'expanded_rule_count': len(selected),
        'expanded_codes_sha256': digest(ROOT / 'expanded-stable-rule-codes.txt'),
        'expanded_metadata_sha256': digest(ROOT / 'expanded-stable-rules.json'),
        'derivation': 'Both effective rule lists equal the stable/non-preview rules in exact letter-family plus numeric-prefix selection. A does not select ANN/AIR/ARG/ASYNC; F does not select FURB/FAST/etc.',
        'no_candidate_source_analysis_performed': True, 'authority': 'NONE'})
    return len(selected)


def wheels():
    metadata_path = ROOT.parent / 'ruff-0.17.1-pypi.json'
    metadata = json.loads(metadata_path.read_bytes())
    records = []
    for filename in WHEELS:
        candidates = [item for item in metadata['urls'] if item['filename'] == filename]
        if len(candidates) != 1 or candidates[0]['yanked'] or candidates[0]['packagetype'] != 'bdist_wheel':
            raise ValueError('ambiguous/unusable official wheel')
        item = candidates[0]
        records.append({'filename': filename, 'sha256': item['digests']['sha256'],
                        'url': item['url'], 'requires_python': item['requires_python'],
                        'size': item['size'], 'yanked': item['yanked'],
                        'locally_retained': (ROOT.parent / filename).exists()})
    write('linux-wheel-derivation.json', {
        'version': metadata['info']['version'], 'metadata_sha256': digest(metadata_path),
        'metadata_url': 'https://pypi.org/pypi/ruff/0.17.1/json', 'wheels': records,
        'limit': 'x86_64 wheel digest comes from retained official metadata; x86_64 wheel and binary were not downloaded or executed by this preparation.'})
    requirement = 'ruff==0.17.1 ' + ' '.join('--hash=sha256:' + item['sha256'] for item in records)
    (ROOT / 'prospective-ruff-requirement.txt').write_text(requirement + '\n')


if __name__ == '__main__':
    count = rules()
    wheels()
    print(json.dumps({'expanded_stable_rule_count': count, 'authority': 'NONE',
                      'candidate_analysis_performed': False}))

"""Pack a finite forensic diagnostic snapshot; never execute archive members."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile


ROOT = Path(__file__).resolve().parent
PRODUCT = Path('/home/sicarii/Work/sia-assurance-checkpoint-20261023')
NAMES = ('measure.py', 'source-static.json', 'admission.json', 'result.json',
         'stdout.json', 'stderr', 'independent-review.txt', 'scope-readback.json',
         'source/runner-source.py', 'source/production_checker.py',
         'source/origin_probe.py', 'source/test_support.py',
         'source/test_name_and_snapshot.py', 'package_report.py')


def pack():
    buffer, rows = io.BytesIO(), []
    with tarfile.open(fileobj=buffer, mode='w', format=tarfile.USTAR_FORMAT) as archive:
        for name in NAMES:
            path = ROOT / name
            with path.open('rb') as stream:
                raw = stream.read(2097153)
            if len(raw) > 2097152:
                raise ValueError('forensic member bound')
            member = tarfile.TarInfo(name)
            member.mode, member.size = 0o444, len(raw)
            archive.addfile(member, io.BytesIO(raw))
            rows.append({'path': name, 'bytes': len(raw),
                         'sha256': hashlib.sha256(raw).hexdigest()})
    return gzip.compress(buffer.getvalue(), mtime=0), rows


def main():
    raw, rows = pack()
    other, second = pack()
    if raw != other or rows != second:
        raise ValueError('forensic inputs drifted')
    destination = PRODUCT / 'docs/evidence/sdk-pair-cost-20261025.tar.gz'
    with destination.open('xb') as stream:
        stream.write(raw)
    report = {'schema': 'sia.sdk-pair-cost-evidence.v1', 'authority': 'NONE',
              'status': 'INSTRUMENTED_SINGLE_ORIGINAL_METHOD_ONLY',
              'full_suite_qualification': False, 'native_admission': False,
              'archive': 'evidence/sdk-pair-cost-20261025.tar.gz',
              'archive_sha256': hashlib.sha256(raw).hexdigest(),
              'archive_bytes': len(raw), 'repeated_pack_equal': True, 'files': rows}
    with (PRODUCT / 'docs/SDK-PAIR-COST-EVIDENCE-20261025.json').open('x') as stream:
        stream.write(json.dumps(report, indent=2, sort_keys=True) + '\n')
    print(json.dumps({'archive_sha256': report['archive_sha256'], 'members': len(rows)}))


if __name__ == '__main__':
    main()

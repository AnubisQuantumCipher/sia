"""One finite diagnostic using the original full pair-shape method."""
import datetime
import hashlib
import json
from pathlib import Path
import subprocess

from run_sdk_sweep import BASE, ROOT, pins

WORK = ROOT / 'sdk-loop-finally-v8'
PREVIOUS = ROOT / 'sdk-last-index-v7'
EXPOSED = ROOT / 'sdk-scratch-sweep-v4'
OUT = ROOT / 'sdk-pair-phase-v8'


def prepare():
    declared = json.loads((ROOT / 'sdk-frontier-phase-v8/result.json').read_text())
    argv = declared['command'][:]
    old = str(ROOT / 'sdk-frontier-phase-v8')
    argv = [str(OUT) if value == old else value for value in argv]
    argv[-1] = str(OUT / 'measure.py')
    if argv.count('30s') != 1 or argv.count('--kill-after=5s') != 1:
        raise ValueError('original diagnostic envelope')
    capacity = json.loads((OUT / 'storage-preflight.json').read_text())
    free = capacity['local_disk_bytes']['free']
    reserve = capacity['configured_local_reserve_bytes']
    if free < reserve + 1073741824:
        raise ValueError('insufficient diagnostic output headroom')
    return {'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'command': argv, 'environment': declared['environment'],
            'source_before': pins(WORK), 'baseline_before': pins(BASE),
            'previous_before': pins(PREVIOUS), 'exposed_before': pins(EXPOSED),
            'capacity': {'free': free, 'reserve': reserve},
            'diagnostic_sha256': hashlib.sha256((OUT / 'measure.py').read_bytes()).hexdigest(),
            'runner_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'scope': 'Distinct complete pair-shape method cost observation; not full-suite/native acceptance.'}


def execute(record):
    with (OUT / 'stdout.json').open('xb') as stdout, (OUT / 'stderr').open('xb') as stderr:
        try:
            result = subprocess.run(record['command'], env=record['environment'],
                                    stdout=stdout, stderr=stderr, timeout=40, check=False)
            return result.returncode, False
        except subprocess.TimeoutExpired:
            return 124, True


def main():
    record = prepare()
    with (OUT / 'admission.json').open('x') as stream:
        stream.write(json.dumps(record, indent=2) + '\n')
    code, observer_timeout = execute(record)
    record.update(exit=code, observer_timeout=observer_timeout,
                  source_after=pins(WORK), baseline_after=pins(BASE),
                  previous_after=pins(PREVIOUS), exposed_after=pins(EXPOSED),
                  diagnostic_after=hashlib.sha256((OUT / 'measure.py').read_bytes()).hexdigest())
    record['source_unchanged'] = (record['source_before'] == record['source_after']
                                and record['baseline_before'] == record['baseline_after']
                                and record['previous_before'] == record['previous_after']
                                and record['exposed_before'] == record['exposed_after']
                                and record['diagnostic_sha256'] == record['diagnostic_after'])
    with (OUT / 'result.json').open('x') as stream:
        stream.write(json.dumps(record, indent=2) + '\n')
    print(json.dumps({'exit': code, 'source_unchanged': record['source_unchanged'],
                      'observer_timeout': observer_timeout}))
    return code if record['source_unchanged'] else 1


if __name__ == '__main__':
    raise SystemExit(main())

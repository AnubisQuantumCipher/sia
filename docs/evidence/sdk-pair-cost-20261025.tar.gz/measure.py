"""Whole original pair-shape test and coarse scratch timing; no acceptance."""
import json
from pathlib import Path
import sys
import time
import unittest
from unittest.mock import patch


ROOT = Path(__file__).resolve().parent.parent
SELECTOR = ('test_name_and_snapshot.SnapshotAndNames.'
            'test_pair_shape_type_and_missing_eof_exact_phase_after_positive')
sys.path.insert(0, str(ROOT / 'sdk-loop-finally-v8'))


def timed(original, row):
    """Call the original cleanup unchanged, with bounded coarse accounting."""
    def invoke(*args, **kwargs):
        if row['calls'] >= 262144:
            raise ValueError('phase observation call bound')
        row['calls'] += 1
        start = time.perf_counter_ns()
        try:
            return original(*args, **kwargs)
        finally:
            row['inclusive_ns'] += time.perf_counter_ns() - start
    return invoke


def main():
    suite = unittest.defaultTestLoader.loadTestsFromName(SELECTOR)
    if suite.countTestCases() != 1:
        raise ValueError('fixed diagnostic selector')
    support = sys.modules['test_support']
    owner = support.CHECKER.DerivedChecker
    row = {'phase': 'DerivedChecker.clear_scratch', 'calls': 0, 'inclusive_ns': 0}
    original = owner.clear_scratch
    start = time.perf_counter_ns()
    with patch.object(owner, 'clear_scratch', timed(original, row)):
        result = unittest.TextTestRunner(verbosity=2).run(suite)
    elapsed = time.perf_counter_ns() - start
    report = {'selector': SELECTOR, 'tests': result.testsRun,
              'successful': result.wasSuccessful(), 'skipped': len(result.skipped),
              'whole_test_and_cleanup_ns': elapsed, 'rows': [row],
              'scope': 'Complete original method and unittest cleanups; one temporary '
                       'clear_scratch wrapper calls its captured original. All cases '
                       'retained; original fixture clocks unchanged. Inclusive intervals '
                       'can overlap; instrumentation affects timing. Not a full-suite '
                       'attribution, optimization, native or WCET qualification.'}
    payload = json.dumps(report, indent=2)
    if len(payload.encode()) > 65536:
        raise ValueError('phase report byte bound')
    print(payload)
    return 0 if result.wasSuccessful() and not result.skipped else 1


if __name__ == '__main__':
    raise SystemExit(main())

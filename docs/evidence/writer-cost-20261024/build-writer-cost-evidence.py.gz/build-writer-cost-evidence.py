"""Reproduce bounded diagnostic evidence without adopting runtime candidates."""
import gzip
import hashlib
import json
from pathlib import Path
import sys

BASE = Path(__file__).parent
REPO = Path('/home/sicarii/Work/sia-note-boundary-checkpoint-20261024')
DEST = REPO / 'docs/evidence/writer-cost-20261024'
GROUPS = (
    'writer-next-capture-stack-diagnostic-v1',
    'writer-next-capture-cost-diagnostic-v1',
    'writer-size-internal-profile-v1',
    'writer-scalar-dispatch-candidate-v1',
    'writer-scalar-dispatch-full-writer-v1',
)
COMMON = ('profile_case.py', 'run_profile.py', 'SCOPE.md',
          'workload-result.json', 'workload.stdout', 'workload.stderr')
EXTRAS = {
    'writer-size-internal-profile-v1': ('tooling-static-result.json',
        'tooling-static.stdout', 'tooling-static.stderr'),
    'writer-scalar-dispatch-candidate-v1': ('original.py', 'candidate.py',
        'SOURCE-REVIEW.json', 'static-result.json', 'static.stdout', 'static.stderr'),
    'writer-scalar-dispatch-full-writer-v1': ('original.py', 'candidate.py'),
}


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def publish(path, raw, check):
    if check:
        if path.read_bytes() != raw:
            raise ValueError('evidence mismatch: ' + str(path))
    else:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(raw)


def members():
    result = [BASE / group / name for group in GROUPS
              for name in COMMON + EXTRAS.get(group, ())]
    result.append(Path(__file__))
    if len(result) > 256:
        raise ValueError('member capacity')
    return result


def main():
    if sys.argv[1:] not in ([], ['--check']):
        raise ValueError('unsupported arguments')
    check, total, records = bool(sys.argv[1:]), 0, []
    for source in members():
        raw = source.read_bytes()
        total += len(raw)
        if len(raw) > 8 * 1024 * 1024 or total > 16 * 1024 * 1024:
            raise ValueError('evidence byte capacity')
        target = DEST / (str(source.relative_to(BASE)) + '.gz')
        packed = gzip.compress(raw, mtime=0)
        publish(target, packed, check)
        records.append({'path': str(target.relative_to(REPO)), 'sha256': digest(packed),
                        'original_sha256': digest(raw), 'original_bytes': len(raw)})
    source_root = BASE / 'writer-scalar-dispatch-candidate-v1'
    manifest = {'schema': 'sia-writer-cost-evidence-v1',
        'status': 'FAILED_FULL_WRITER_QUALIFICATION_NOT_ADOPTED',
        'base_commit': 'b2d89c37e85445765d4d531bc77a57247c07f18a',
        'prior_candidate_manifest': 'docs/OWNERSHIP-TYPE-IDENTITY-20261024.json',
        'prior_candidate_manifest_sha256': digest(
            (REPO / 'docs/OWNERSHIP-TYPE-IDENTITY-20261024.json').read_bytes()),
        'scalar_source_sha256': {name: digest((source_root / name).read_bytes())
                                 for name in ('original.py', 'candidate.py')},
        'members': records, 'limits': 'Original runtime caps unchanged. No release authority.'}
    publish(REPO / 'docs/WRITER-COST-20261024.json',
            (json.dumps(manifest, indent=2) + '\n').encode(), check)
    print(json.dumps({'check': check, 'members': len(records), 'uncompressed_bytes': total}))


if __name__ == '__main__':
    main()

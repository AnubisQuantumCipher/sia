"""Original sizing roster plus branch-order result/trace/error controls."""
import importlib.util
import math
from types import SimpleNamespace
import unittest
from unittest import mock

import siasourcebatch as candidate


def load_original():
    spec = importlib.util.spec_from_file_location('scalar_original', '/tmp/scalar-original.py')
    if spec is None or spec.loader is None:
        raise RuntimeError('baseline loader missing')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


ORIGINAL = load_original()


def observed(module, value, ceiling, ascii_only, mode, injected):
    trace = []
    append = module._JsonSizeCounter.add
    string = module._live._count_ascii_json_string

    def add(counter, amount):
        if len(trace) >= 256:
            raise RuntimeError('trace capacity')
        trace.append(('add', amount))
        return append(counter, amount)

    def text(item, add_amount, *, ascii_only):
        trace.append(('string', item, ascii_only))
        if mode == 'string-error':
            raise injected
        return string(item, add_amount, ascii_only=ascii_only)

    def finite(item):
        trace.append(('finite', repr(item)))
        if mode == 'math-error':
            raise injected
        return math.isfinite(item)

    counter = module._JsonSizeCounter(ceiling)
    owner = {'math': SimpleNamespace(isfinite=finite)}
    with mock.patch.object(module._JsonSizeCounter, 'add', add), \
            mock.patch.object(module._live, '_count_ascii_json_string', text):
        try:
            result = module._json_scalar_size(owner, value, counter, ascii_only)
        except (ValueError, RuntimeError, TypeError) as error:
            outcome = (type(error).__name__, str(error), error is injected)
        else:
            outcome = ('returned', result)
    return outcome, counter.total, trace


class ScalarDispatchDifferential(unittest.TestCase):
    def test_original_outcomes_traces_and_exception_identity(self):
        class Exotic(type):
            __hash__ = None

            def __eq__(cls, _other):
                raise AssertionError('type equality dispatched')

        class ExoticString(str, metaclass=Exotic):
            pass

        class IntChild(int):
            pass

        values = (None, True, False, 0, -1, 1 << 256, 1.5, -0.0,
                  float('nan'), float('inf'), '', 'abc', '\x00"\\',
                  'é😀', '\ud800', b'bytes', [], {}, object(),
                  ExoticString('no hooks'), IntChild(3))
        for value in values:
            for ceiling in (1, 2, 4, 8, 4096):
                for ascii_only in (False, True):
                    for mode in ('normal', 'string-error', 'math-error'):
                        injected = RuntimeError('injected callback')
                        with self.subTest(kind=type(value).__name__, ceiling=ceiling,
                                          ascii_only=ascii_only, mode=mode):
                            expected = observed(ORIGINAL, value, ceiling, ascii_only,
                                                mode, injected)
                            actual = observed(candidate, value, ceiling, ascii_only,
                                              mode, injected)
                            self.assertEqual(actual, expected)


NAMES = [
    'tests.test_json_exact_type_admission', 'tests.test_json_size_iterative',
    'tests.test_json_key_step', 'tests.test_ascii_json_budget',
    'tests.test_unicode_sizing_admission', 'tests.test_json_size_fast_path',
    'tests.test_cognitive_baseline', 'tests.test_cognitive_baseline_prefix',
    'tests.test_cognitive_history_capture', 'tests.test_cognitive_selection',
    'tests.test_cognitive_source_link_selection',
    'tests.test_cognitive_source_link_policy_freeze', 'tests.test_replay_gist',
    'tests.test_event_page_plan', 'tests.test_page_size_cleanup',
    'tests.test_page_size_differential', 'tests.test_page_size_traversal',
]


if __name__ == '__main__':
    suite = unittest.defaultTestLoader.loadTestsFromNames(NAMES)
    suite.addTests(unittest.defaultTestLoader.loadTestsFromTestCase(ScalarDispatchDifferential))
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    raise SystemExit(0 if result.wasSuccessful() else 1)

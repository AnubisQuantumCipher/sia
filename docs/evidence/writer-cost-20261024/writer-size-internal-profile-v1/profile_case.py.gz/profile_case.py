"""Bounded deterministic sampling of genuine sizing calls; diagnostic only."""
import cProfile
import functools
import json
import pstats
import unittest
from unittest import mock

import siasourcebatch as source


def main():
    profiler = cProfile.Profile()
    original = source._json_size
    state = {"calls": 0, "samples": 0, "active": False}

    @functools.wraps(original)
    def sampled(*args, **kwargs):
        if state["calls"] >= 1_000_000:
            raise RuntimeError("diagnostic-call-capacity")
        state["calls"] += 1
        selected = (not state["active"] and state["samples"] < 256
                    and state["calls"] % 64 == 0)
        if not selected:
            return original(*args, **kwargs)
        state["samples"] += 1
        state["active"] = True
        profiler.enable()
        try:
            return original(*args, **kwargs)
        finally:
            profiler.disable()
            state["active"] = False

    suite = unittest.defaultTestLoader.loadTestsFromNames([
        "tests.test_controller_delivery_writer.ControllerDeliveryWriter."
        "test_real_output_then_next_capture_binding_and_pulse_keep_exact_nonempty_record"])
    with mock.patch.object(source, "_json_size", sampled):
        result = unittest.TextTestRunner(verbosity=2).run(suite)
    print(json.dumps({"state": state, "tests": result.testsRun,
                      "success": result.wasSuccessful(),
                      "scope": "Every original call executes. Every 64th sizing call "
                      "is profiled, at most 256 samples. Altered callable identity "
                      "and timing; no full-roster or worst-case latency claim."}))
    pstats.Stats(profiler).strip_dirs().sort_stats("tottime").print_stats(35)
    raise SystemExit(0 if result.wasSuccessful() else 1)


if __name__ == "__main__":
    main()

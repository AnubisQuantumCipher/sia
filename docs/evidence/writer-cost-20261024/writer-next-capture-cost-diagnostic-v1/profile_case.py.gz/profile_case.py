"""Bounded coarse instrumentation; diagnostic only, never acceptance."""
import contextlib
import functools
import importlib
import json
import time
import unittest
from unittest import mock

TARGETS = (
    ("siasourcebatch", "validate_batch"),
    ("siasourcebatch", "_validate_batch_image"),
    ("siasourcebatch", "_json_size"),
    ("siasourcebatch", "native_bytes"),
    ("sialiveloop", "_size"),
    ("sialiveloop", "prepare_pulse"),
    ("siathought", "bind"),
)


def measured(original, row):
    @functools.wraps(original)
    def invoke(*args, **kwargs):
        if row["calls"] >= 1_000_000 or row["depth"] >= 64:
            raise ValueError("diagnostic-counter-capacity")
        row["calls"] += 1
        outer = row["depth"] == 0
        row["depth"] += 1
        started = time.monotonic_ns() if outer else 0
        try:
            return original(*args, **kwargs)
        finally:
            row["depth"] -= 1
            if outer:
                row["outer_calls"] += 1
                row["outer_inclusive_ns"] += time.monotonic_ns() - started
    return invoke


def main():
    suite = unittest.defaultTestLoader.loadTestsFromNames([
        "tests.test_controller_delivery_writer.ControllerDeliveryWriter."
        "test_real_output_then_next_capture_binding_and_pulse_keep_exact_nonempty_record"])
    rows = []
    started = time.monotonic_ns()
    with contextlib.ExitStack() as stack:
        for module_name, name in TARGETS:
            module = importlib.import_module(module_name)
            original = getattr(module, name)
            row = {"module": module_name, "function": name, "calls": 0,
                   "outer_calls": 0, "depth": 0, "outer_inclusive_ns": 0}
            rows.append(row)
            stack.enter_context(mock.patch.object(module, name, measured(original, row)))
        result = unittest.TextTestRunner(verbosity=2).run(suite)
    if any(row["depth"] != 0 for row in rows):
        raise ValueError("diagnostic-unbalanced-depth")
    print(json.dumps({"success": result.wasSuccessful(), "tests": result.testsRun,
                      "elapsed_ns": time.monotonic_ns() - started, "rows": rows,
                      "scope": "Single-threaded diagnostic with altered callable identity. "
                      "Categories overlap. Not uninstrumented latency, WCET, original "
                      "full-roster qualification, policy approval or runtime adoption."}))
    raise SystemExit(0 if result.wasSuccessful() else 1)


if __name__ == "__main__":
    main()

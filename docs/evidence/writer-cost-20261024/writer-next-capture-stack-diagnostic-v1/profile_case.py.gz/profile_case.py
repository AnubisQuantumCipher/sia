"""Single original test with timed stack observation; not roster acceptance."""
import faulthandler
import unittest


def main():
    suite = unittest.defaultTestLoader.loadTestsFromNames([
        "tests.test_controller_delivery_writer.ControllerDeliveryWriter."
        "test_real_output_then_next_capture_binding_and_pulse_keep_exact_nonempty_record"])
    faulthandler.dump_traceback_later(5, repeat=True)
    try:
        result = unittest.TextTestRunner(verbosity=2).run(suite)
    finally:
        faulthandler.cancel_dump_traceback_later()
    raise SystemExit(0 if result.wasSuccessful() else 1)


if __name__ == "__main__":
    main()

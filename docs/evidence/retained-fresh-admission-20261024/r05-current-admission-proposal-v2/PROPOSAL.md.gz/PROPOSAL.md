# Proposed R05 contract correction — NOT APPROVED OR ADOPTED

The current integration source is 79a9e39eee58dfe88b32536a9d3a8a1fcd99b14e.
The concrete private change is [candidate.patch](candidate.patch). Production,
installed files, original tests and the release policy remain unchanged.

## Decision requested

Approve retiring the requirement that repeated admission must reuse an expensive
closed computation, and replacing only the original combined-validator call-count
assertion. Require fresh current validation on every call instead. Keep the same
fixture, changed-image refusal, VERSION/context checks, output equality and
detachment requirements. Preserve all existing deadline, capacity, full-workload,
proof, independent review, installed-runtime and release gates.

This is broader than the existing conditional instrumentation permission. That
permission still requires useful expensive reuse and explicitly excludes adopting
the no-cache candidate. This proposal does not reinterpret that prior decision.
No approval is inferred from silence or general project ownership.

## Why this correction is proposed

The two outer memos store prior successful admission. Their keys do not bind
mutable policies and callback behavior. Existing retained regressions show warm
acceptance where a cold run refuses. Keeping cached success is therefore unsafe.

The available cost evidence primarily locates current admission, including
sizing, decoding, sanitization and repeated policy evaluation. The measured
association-helper cache costs more to key than it saves; the string-cache
experiment has no demonstrated complete-validation benefit and unresolved
retention. Neither is an honest replacement for expensive derivation reuse.

The new exact-byte checkpoint-cut diagnostic demonstrates a further conflict
inside a single validation. Stable native validation makes 16 policy calls;
the proposed shortcut makes 12, with two hits and two misses. The same callable
configured to refuse its sixteenth invocation makes native validation refuse
with custom-selection-canonical-identity, while the shortcut incorrectly accepts.
All input bytes remain unchanged. Owned bytes alone do not certify policy.

This finding concerns the inspected architecture and tested shortcut. It does
not prove that useful safe caching is impossible in every design.

## Concrete private patch

- Legacy admission keeps the original size and digest/owner-read preflight, then invokes the complete
  current batch validator every time.
- Compact admission keeps the original memo-key hash/preflight evaluation, then
  invokes the complete current capture validator every time.
- No success entry is read or written. Existing empty dictionaries remain only
  for diagnostic cleanup compatibility. No validation is renamed to game counts.
- Obsolete cache comments and the now-unused copy import are removed.
- Current decoders, policies, refusal order, alias checks and optional idle and
  delivery validation remain in the existing validator bodies.

## Risks and acceptance

Repeated validation can cost more CPU and latency than the unsafe warm hit.
Passing a small roster cannot establish maximum-load performance. If unchanged
workload deadlines fail, the candidate remains FAILED until implementation
improves; this decision permits no deadline increase or hidden fallback.

The original reuse assertion is expected to fail for this patch. Its source and
raw result remain historical evidence. Replacement is not permitted until the
user approves this exact contract correction. Other failures must be repaired,
not reclassified. The full historical workload remains outstanding.

Acceptance still requires current-source warm/cold policy controls, unchanged
image/version and malformed-input controls, applicable idle/delivery tests,
negative controls, bounded full-workload measurement and independent source/
evidence review. All broader SIA assurance and marketplace gates remain open.

The user's AGENTS instructions in this session require: "Require a written
justification, risk assessment, and my explicit approval for deviations before
accepting them as policy." This document supplies the justification and risk
assessment; it does not supply the approval.

## Preparation correction

V1 removed the legacy initial native digest call inadvertently. Independent
review identified that separate callback/read/refusal change. Its source and
14-test raw failure remain retained. V2 restores the exact digest and owner
reads before the full validator. No V1 result is acceptance evidence for V2.

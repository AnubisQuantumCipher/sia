# Current proposal evidence

Status: **FAILED original reuse requirement; APPROVAL PENDING; NOT ADOPTED**.

The unchanged original 14-method roster plus two preflight controls completed:
16 tests in 51.652 seconds, one failure, process exit 1. The only reported failure
is the original identical-image combined-validator call-count assertion. Its
later assertions were not reached; do not describe this as a complete pass.

Source endpoint maps are unchanged. All 442 repository Python entries match
79a9e39eee58dfe88b32536a9d3a8a1fcd99b14e before the two documented private overlays.
Selected 167-rule static analysis reports no findings; syntax checks pass.
Original 60-second deadline, five-second termination grace, 2 GiB address-space
and 512 MiB file limits remain in the retained command. No cap was raised.

Actual GPT-6.1 reviewed source and raw results. This is not independent execution.
The full historical workload, current-machine lifecycle, whole SPARK proof,
installed path and marketplace release acceptance remain incomplete.

V1's unused-import failure and omitted-preflight blocker, V1's raw runtime
failure, the unsafe checkpoint-cut diagnostic and all preceding cache failures
remain separately retained. No historical result was rewritten.

Approval concerns the specific written contract correction in PROPOSAL.md.
It would permit qualification of the fresh-admission replacement; it would not
make this candidate or the whole system accepted by itself.

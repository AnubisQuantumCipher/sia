"""Retain and reproduce the bounded fresh-admission checkpoint manifest."""
import gzip
import hashlib
import json
from pathlib import Path
import sys

BASE = Path(__file__).parent
REPO = Path('/home/sicarii/Work/sia-note-boundary-checkpoint-20261024')
DEST = REPO / 'docs/evidence/retained-fresh-admission-20261024'
SOURCES = ('bin/siasourcebatch.py', 'bin/siasourcecheckpoint.py',
           'tests/test_retained_image_memo.py', 'tests/test_retained_validation_preflight.py')
GROUPS = {
    'r05-current-admission-proposal-v2': ('PROPOSAL.md', 'RESULTS.md', 'candidate.patch', 'review.txt', 'workload-result.json', 'workload.stderr'),
    'r05-fresh-admission-adoption-v1': ('DECISION.md', 'original-test_retained_image_memo.py', 'workload-result.json', 'workload.stderr', 'static-result.json', 'static.stdout'),
    'r05-fresh-admission-adoption-v2': ('run_adoption.py', 'workload-result.json', 'workload.stdout', 'workload.stderr', 'static-result.json', 'static.stdout', 'static.stderr', 'independent-review.txt', 'final-source-binding.json'),
    'r05-fresh-admission-integration-v1': ('run_adoption.py', 'workload-result.json', 'workload.stdout', 'workload.stderr'),
    'r05-fresh-admission-workload-v1': ('run_probe.py', 'workload_probe.py', 'result.json', 'stdout', 'stderr', 'artifacts/comparison.json', 'artifacts/retained-batch.json'),
}


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def publish(path, raw, check):
    if check:
        if path.read_bytes() != raw:
            raise ValueError('evidence mismatch: ' + str(path))
    else:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(raw)


def members():
    result = [BASE / group / name for group, names in GROUPS.items() for name in names]
    result.extend(BASE / 'r05-fresh-admission-workload-v1/artifacts' / f'load{i:03d}.txt' for i in range(104))
    result.append(Path(__file__))
    if len(result) > 256:
        raise ValueError('member capacity')
    return result


def main():
    if sys.argv[1:] not in ([], ['--check']):
        raise ValueError('unsupported arguments')
    check = bool(sys.argv[1:])
    records = []
    total = 0
    for source in members():
        raw = source.read_bytes()
        total += len(raw)
        if len(raw) > 8 * 1024 * 1024 or total > 16 * 1024 * 1024:
            raise ValueError('evidence byte capacity')
        name = str(source.relative_to(BASE)) + '.gz'
        packed = gzip.compress(raw, mtime=0)
        publish(DEST / name, packed, check)
        records.append({'path': str((DEST / name).relative_to(REPO)), 'sha256': digest(packed),
                        'original_sha256': digest(raw), 'original_bytes': len(raw)})
    data = {'schema': 'sia-fresh-admission-evidence-v1', 'status': 'TESTED_SUBSETS_ACCEPTANCE_INCOMPLETE',
            'base_commit': '79a9e39eee58dfe88b32536a9d3a8a1fcd99b14e',
            'source_sha256': {name: digest((REPO / name).read_bytes()) for name in SOURCES},
            'members': records, 'limits': 'Original runtime caps unchanged; no release authority.'}
    publish(REPO / 'docs/RETAINED-FRESH-ADMISSION-20261024.json',
            (json.dumps(data, indent=2) + '\n').encode(), check)
    print(json.dumps({'check': check, 'members': len(records), 'uncompressed_bytes': total}))


if __name__ == '__main__':
    main()

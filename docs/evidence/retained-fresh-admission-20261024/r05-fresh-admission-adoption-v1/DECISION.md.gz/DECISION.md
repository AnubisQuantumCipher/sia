# R05 delegated decision

The user replied to the concrete pending R05 proposal: “That desision is up to you use your best judgment”. The implementation owner selects fresh validation on every call as described in r05-current-admission-proposal-v2/PROPOSAL.md. This explicit response delegates the specific presented decision; it is not inferred from silence or the broader project mandate.

The mandatory expensive-reuse requirement and combined-validator call-count assertion are superseded. Current admission, callback/read/refusal order, first aliases, image/version/output checks, full workloads, deadlines, resource limits, proof and release gates remain. The reviewed proposal supplies the justification and CPU/latency risk assessment. Acceptance is pending current-source testing; authorization is not acceptance. Original proposal, test source and failed runs remain immutable.

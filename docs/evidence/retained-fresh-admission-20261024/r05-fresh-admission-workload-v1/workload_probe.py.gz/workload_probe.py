"""Synthetic bounded multi-source diagnostic; not the historical workload."""
import hashlib
import json
from pathlib import Path
import resource
import time

import siasourcebatch as batches
from tests.test_controller_source_capture import ControllerSourceCapture

OUTPUT = Path('/tmp/workload-artifacts')
SOURCE_COUNT = 104
EVENTS_PER_SOURCE = 10


def emit(stage, **values):
    print(json.dumps({'stage': stage, **values}, sort_keys=True), flush=True)


def save(name, raw):
    with (OUTPUT / name).open('xb') as stream:
        stream.write(raw)
    return {'path': name, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def provision(case):
    case.custom_entries = [case.bridge.custom(f'load{index:03d}')
                           for index in range(SOURCE_COUNT)]
    disabled = sorted((set(case.lib.BASE_ORGANS) | set(case.lib.OPTIONAL_ORGANS)) - {'aegis'})
    case.install_config({'senses': {'disable': disabled},
                         'custom_senses': case.custom_entries})
    case.configure_selection(['sense_aegis'], case.custom_entries)
    for entry in case.custom_entries:
        case.before_cursors['custom.' + entry['name']] = 0
    case.cursors_path.write_bytes(batches.native_bytes(vars(case.lib), case.before_cursors))
    sources = []
    for entry in case.custom_entries:
        count = EVENTS_PER_SOURCE
        if count > case.lib.MAX_SOURCE_TAIL_RECORDS:
            raise ValueError('fixture record capacity')
        lines = [f'Synthetic continuity {entry["name"]} event {index:04d}: '
                 + 'retained evidence ' * 4 + '\n' for index in range(count)]
        raw = ''.join(lines).encode('utf-8')
        if len(raw) > case.lib.MAX_SOURCE_TAIL_BYTES:
            raise ValueError('fixture byte capacity')
        Path(entry['path']).write_bytes(raw)
        sources.append({'source_id': 'sense_custom:' + entry['name'],
                        'requested_events': count, **save(entry['name'] + '.txt', raw)})
    return sources


def measure(validate, owner, image):
    started = time.monotonic_ns()
    try:
        result = validate(owner, image, image['batch_sha256'])
    except batches.SourceBatchRefusal as error:
        outcome = {'status': 'refused', 'reason': error.reason}
    else:
        if result is not None:
            raise AssertionError('unexpected retained validation result')
        outcome = {'status': 'accepted'}
    return {'elapsed_ns': time.monotonic_ns() - started, 'outcome': outcome,
            'process_peak_rss_kib': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}


def compare(owner, image):
    batches._VALIDATED_BATCHES.clear()
    cold = measure(batches.validate_batch, owner, image)
    warm = measure(batches.validate_batch, owner, image)
    changed = dict(owner, MAX_SOURCE_REPLAY_SOURCES=1)
    warm_changed = measure(batches.validate_batch, changed, image)
    batches._VALIDATED_BATCHES.clear()
    cold_changed = measure(batches.validate_batch, changed, image)
    if cold['outcome'] != {'status': 'accepted'} or warm['outcome'] != cold['outcome']:
        raise AssertionError('ordinary complete workload admission failed')
    if cold_changed['outcome']['status'] != 'refused':
        raise AssertionError('changed capacity control is ineffective')
    return {'cold': cold, 'warm': warm, 'warm_changed': warm_changed,
            'cold_changed': cold_changed,
            'equivalent_after_change': warm_changed['outcome'] == cold_changed['outcome']}


def run(case):
    sources = provision(case)
    before = case.inert_before()
    emit('capture_started', sources=sources,
         limits={'source_records': case.lib.MAX_SOURCE_TAIL_RECORDS,
                 'source_bytes': case.lib.MAX_SOURCE_TAIL_BYTES,
                 'state_bytes': case.lib.MAX_STATE_JSON_BYTES})
    started = time.monotonic_ns()
    image = case.capture()
    capture_elapsed = time.monotonic_ns() - started
    case.assert_inert(before)
    owner = vars(case.lib)
    raw = batches.native_bytes(owner, image)
    artifact = save('retained-batch.json', raw)
    counts = [{'source_id': row['source_id'], 'events': len(row['events'])}
              for row in image['source_returns']['runs']]
    for expected in sources:
        actual = next(row for row in counts if row['source_id'] == expected['source_id'])
        if actual['events'] != expected['requested_events']:
            raise AssertionError('collector did not return the complete synthetic roster')
    emit('capture_completed', elapsed_ns=capture_elapsed, image=artifact, counts=counts,
         refusals=image['refusal_intents'])
    batches._VALIDATED_BATCHES.clear()
    emit('complete_cold_warm_comparison_started')
    measured = compare(owner, image)
    if batches.native_bytes(owner, image) != raw:
        raise AssertionError('validation mutated retained input')
    case.assert_inert(before)
    result = {'status': 'TESTED_PASS' if measured['equivalent_after_change'] else 'FAILED_STALE_ADMISSION', 'sources': sources,
              'counts': counts, 'image': artifact, 'measurements': measured,
              'capture_elapsed_ns': capture_elapsed,
              'scope': 'Actual private collectors and fresh retained-image validation; '
                       'Single unprofiled cold/warm observations are not a latency bound or WCET. '
                       'This is not the historical 12.7 MB/1046-event capture.'}
    receipt = save('comparison.json', (json.dumps(result, indent=2) + '\n').encode())
    emit('completed', result=receipt, measurements=measured)
    if not measured['equivalent_after_change']:
        raise AssertionError('warm admission bypasses the current source capacity')


def main():
    case = ControllerSourceCapture(methodName='runTest')
    try:
        case.setUp()
        run(case)
    finally:
        case.doCleanups()
        batches._VALIDATED_BATCHES.clear()


if __name__ == '__main__':
    main()

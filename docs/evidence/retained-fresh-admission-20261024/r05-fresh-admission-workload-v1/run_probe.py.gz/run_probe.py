"""Run one bounded private workload probe and retain exact input identities."""
import hashlib
import json
from pathlib import Path
import subprocess
import time

ROOT = Path(__file__).parent
REPOSITORY = Path('/home/sicarii/Work/sia-note-boundary-checkpoint-20261024')


def hashes(paths):
    if len(paths) > 2048:
        raise ValueError('source inventory capacity')
    return {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in sorted(paths)}


def main():
    if (ROOT / 'result.json').exists():
        raise ValueError('existing result')
    template = json.loads((ROOT.parent / 'r05-page-sizing-iterative-v1' /
                           'profile-baseline-result.json').read_bytes())
    command = template['command']
    position = command.index('/tmp/validation-profile.py')
    command[position - 1] = str(ROOT / 'workload_probe.py')
    point = command.index('--unshare-net')
    command[point:point] = ['--bind', str(ROOT / 'artifacts'), '/tmp/workload-artifacts']
    names = subprocess.check_output(['git', 'ls-files', '-z', 'bin', 'tests'],
                                    cwd=REPOSITORY, timeout=10).decode().split('\0')
    paths = {REPOSITORY / name for name in names if name and name.endswith('.py')}
    paths |= {ROOT / 'workload_probe.py', Path(__file__)}
    before = hashes(paths)
    receipt = {'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'],
                   cwd=REPOSITORY, timeout=10, text=True).strip(),
               'command': command, 'environment': template['environment'], 'before': before}
    (ROOT / 'inputs.json').write_text(json.dumps(receipt, indent=2) + '\n')
    started = time.monotonic_ns()
    with (ROOT / 'stdout').open('xb') as out, (ROOT / 'stderr').open('xb') as err:
        result = subprocess.run(command, env=template['environment'], stdout=out,
                                stderr=err, check=False)
    receipt.update(after=hashes(paths), exit=result.returncode,
                   elapsed_ns=time.monotonic_ns() - started)
    receipt['unchanged'] = receipt['before'] == receipt['after']
    receipt['output_hashes'] = hashes({ROOT / 'stdout', ROOT / 'stderr'})
    (ROOT / 'result.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps({key: receipt[key] for key in ('head', 'exit', 'unchanged', 'elapsed_ns')}))


if __name__ == '__main__':
    main()

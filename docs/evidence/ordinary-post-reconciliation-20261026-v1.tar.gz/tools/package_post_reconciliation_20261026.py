"""Reproduce one interrupted-fixture reconciliation record without executing archived source."""
import argparse
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

BASE = Path(__file__).resolve().parent
ROOT = BASE / 'ordinary-post-reconciliation-package-20261026-v1'
ARCHIVE = 'ordinary-post-reconciliation-20261026-v1.tar.gz'
RUN = BASE / 'ordinary-post-reconciliation-20261026-v1'
NAMES = ('AUDITOR-STATIC.json', 'EXECUTION-DECISION.json', 'EXECUTION-PLAN.json', 'OWNER-AUDIT.json', 'PRE-EXECUTION-REVIEW.json', 'RESULT-INDEPENDENT-REVIEW.json', 'STATIC-v1.json', 'TEST-EXECUTION-DECISION.json', 'TEST-RESULT.json', 'TEST-TOOL-OBSERVATION.json', 'TOOL-EXIT-OBSERVATION.json', 'candidate.py', 'pre_reconcile.py', 'test_pre.py', 'decision.json', 'invoke.py', 'normal_reconcile.py', 'outer-result.json', 'outer.stdout', 'readback.py', 'readback.stdout', 'reconcile.py', 'run_tests.py', 'source.json', 'test_normal.py', 'test_reconcile.py', 'tests.stderr')


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def add(files, prefix, directory, names):
    for name in names:
        key = prefix + '/' + name
        if key in files:
            raise ValueError('duplicate member')
        files[key] = directory / name


def roster():
    files = {}
    add(files, 'run', RUN, NAMES)
    add(files, 'syntax-failure', RUN / 'syntax-failure',
        ('FAILURE.json', 'candidate.py', 'normal_reconcile.py', 'test_normal.py', 'invoke.py',
         'pre_reconcile.py', 'test_pre.py', 'readback.py', 'reconcile.py', 'test_reconcile.py', 'run_tests.py'))
    add(files, 'tools', BASE, ('audit_post_reconciliation_20261026.py', Path(__file__).name))
    return files


def verify():
    audit = json.loads((RUN / 'OWNER-AUDIT.json').read_text())
    for name, expected in audit['evidence_sha256'].items():
        if sha(RUN / name) != expected:
            raise ValueError('audited evidence changed: ' + name)
    review = json.loads((RUN / 'RESULT-INDEPENDENT-REVIEW.json').read_text())
    if review['audit_sha256'] != sha(RUN / 'OWNER-AUDIT.json'):
        raise ValueError('review binding changed')
    for name, expected in json.loads((RUN / 'source.json').read_text()).items():
        if sha(RUN / name) != expected:
            raise ValueError('execution source changed: ' + name)


def members(files):
    if not 1 <= len(files) <= 160:
        raise ValueError('member count')
    result, total = {}, 0
    for name, path in sorted(files.items()):
        size = path.stat().st_size
        if path.is_symlink() or not path.is_file() or size > 1048576:
            raise ValueError('invalid member: ' + name)
        total += size
        if total > 8388608:
            raise ValueError('archive input limit')
        result[name] = dict(sha256=sha(path), bytes=size)
    return result


def encoded_archive(files, rows):
    output = io.BytesIO()
    with gzip.GzipFile(fileobj=output, mode='wb', filename='', mtime=0) as zipped:
        with tarfile.open(fileobj=zipped, mode='w', format=tarfile.USTAR_FORMAT) as archive:
            for name, path in sorted(files.items()):
                with path.open('rb') as stream:
                    data = stream.read(1048577)
                if len(data) != rows[name]['bytes'] or hashlib.sha256(data).hexdigest() != rows[name]['sha256']:
                    raise ValueError('input changed during packaging')
                info = tarfile.TarInfo(name)
                info.size, info.mode, info.mtime = len(data), 0o444, 0
                archive.addfile(info, io.BytesIO(data))
    return output.getvalue()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--check', action='store_true')
    args = parser.parse_args()
    verify()
    files = roster()
    rows = members(files)
    data = encoded_archive(files, rows)
    record = dict(status='EXACT_POST_ADMISSION_FIXTURE_RECONCILIATION_PASS', authority='NONE',
        carrier_head='4ade8e3856e16678ffc37d76aec35c3cc69333b6', members=rows,
        archive=dict(path='docs/evidence/' + ARCHIVE, sha256=hashlib.sha256(data).hexdigest(), bytes=len(data)),
        result=json.loads((RUN / 'OWNER-AUDIT.json').read_text()),
        prerequisite_checkpoint='4ade8e3856e16678ffc37d76aec35c3cc69333b6',
        limitations=['One exact interrupted post-admission fixed sentinel fixture; no replay or successor authority.',
            'Original pending inode and bytes preserved; previous history checked by bytes/metadata.',
            'Prior actual cut/refusal evidence and baseline snapshot retained in prerequisite checkpoint.',
            'Ordinary nonhostile root/host; unsigned tool observations; no hardware crash proof.',
            'Pre-entry/witness-loss/arbitrary-descendant custody, native C14, compaction and R05 BOTH remain open.',
            'No installed product, service, firewall, provider, release or marketplace change.'])
    encoded = (json.dumps(record, indent=2, sort_keys=True) + '\n').encode()
    if args.check:
        if (ROOT / ARCHIVE).read_bytes() != data or (ROOT / 'manifest.json').read_bytes() != encoded:
            raise ValueError('byte reproduction mismatch')
    else:
        ROOT.mkdir(mode=0o700)
        for name, value in ((ARCHIVE, data), ('manifest.json', encoded)):
            with (ROOT / name).open('xb') as stream:
                if stream.write(value) != len(value):
                    raise OSError('short package write')
    print(json.dumps(dict(status='PACKAGE_CHECK_PASS' if args.check else 'PACKAGE_CREATED',
                         archive=record['archive'], members=len(rows))))


if __name__ == '__main__':
    main()

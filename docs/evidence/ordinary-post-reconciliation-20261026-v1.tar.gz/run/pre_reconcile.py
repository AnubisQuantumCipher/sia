"""One exact interrupted-fixture reconciliation; no replay or successor authority."""
from contextlib import ExitStack
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import stat
import sys

ROOT = Path(__file__).resolve().parent
NORMAL = ROOT.parent / 'ordinary-observer-cut-20261026-v2'
REFUSAL = ROOT.parent / 'ordinary-observer-cut-refusal-20261026-v1'
PENDING_SHA = '74faf232cf9bea62a5c9e72f9c32b3a4f435c35e448268a81963e43d226b4678'
MANIFEST_SHA = 'fba159b884fc1a46a88df326f54e1ce4ba05e771fb16b4b22d5005b05f1fd5c4'
RETIRED = 'retired-' + MANIFEST_SHA + '.json'
DECISION = 'decision-' + MANIFEST_SHA + '.json'
MAX_RECORD = 65536
SOURCE_NAMES = ('candidate.py', 'reconcile.py', 'test_reconcile.py', 'decision.json',
                'normal_reconcile.py', 'test_normal.py', 'run_tests.py', 'invoke.py', 'readback.py')
EVIDENCE_NAMES = (
    'config.json', 'execution-source.json', 'source-binding.json', 'proof_wrapper.py',
    'witness.py', 'observer_driver.py', 'witness-result.json', 'witness-before-cleanup.json',
    'outer-result.json', 'outer.stdout', 'entry.json', 'active.json',
    'OWNER-AUDIT.json', 'RESULT-INDEPENDENT-REVIEW.json', 'TOOL-EXIT-OBSERVATION.json',
)
REFUSAL_NAMES = ('execution-source.json', 'outer-result.json', 'outer.stdout', 'entry.json',
                 'pending-after.json', 'OWNER-AUDIT.json', 'RESULT-INDEPENDENT-REVIEW.json',
                 'TOOL-EXIT-OBSERVATION.json')
ROLES = {'observer', 'launcher', 'init', 'leader'}


def sha(path):
    if not path.is_file() or path.is_symlink() or path.stat().st_size > 1048576:
        raise ValueError('bounded regular evidence file required')
    with path.open('rb') as stream:
        data = stream.read(1048577)
    if len(data) > 1048576:
        raise ValueError('evidence grew beyond bound')
    return hashlib.sha256(data).hexdigest()


def candidate_module():
    spec = importlib.util.spec_from_file_location('fixed_latch_candidate', ROOT / 'candidate.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    # Only source validation and ledger helpers are used; never its executor.
    module.ROOT = NORMAL
    return module


def pending_identity(candidate, directory, descriptor, links):
    opened = os.fstat(descriptor)
    named = os.stat('pending.json', dir_fd=directory, follow_symlinks=False)
    if not stat.S_ISREG(opened.st_mode) or opened.st_uid != os.geteuid() \
            or stat.S_IMODE(opened.st_mode) != 0o600 or opened.st_nlink != links \
            or candidate.metadata(opened) != candidate.metadata(named):
        raise ValueError('pending identity changed')
    os.lseek(descriptor, 0, os.SEEK_SET)
    data = os.read(descriptor, MAX_RECORD + 1)
    if len(data) != opened.st_size or len(data) > MAX_RECORD \
            or hashlib.sha256(data).hexdigest() != PENDING_SHA:
        raise ValueError('pending content changed')
    return opened


def durable_decision(candidate, directory, value):
    descriptor = None
    errors = []
    stage = 'create-decision'
    try:
        descriptor = os.open(DECISION, os.O_WRONLY | os.O_CREAT | os.O_EXCL |
                             os.O_NOFOLLOW | os.O_CLOEXEC, 0o600, dir_fd=directory)
        stage = 'write-decision'
        candidate.write_receipt(descriptor, value)
        stage = 'sync-decision'
        os.fsync(descriptor)
        stage = 'sync-decision-directory'
        os.fsync(directory)
    except (OSError, ValueError, TypeError) as error:
        errors.append(candidate.receipt_error(stage, error))
    finally:
        candidate.close_receipt(descriptor, 'decision', errors)
    if errors:
        raise ValueError(json.dumps(dict(decision_errors=errors)))


def preserve_then_unlink(candidate, directory, descriptor):
    stage = 'check-before-link'
    try:
        original = pending_identity(candidate, directory, descriptor, 1)
        stage = 'link-retired'
        os.link('pending.json', RETIRED, src_dir_fd=directory, dst_dir_fd=directory,
                follow_symlinks=False)
        stage = 'check-retired'
        linked = pending_identity(candidate, directory, descriptor, 2)
        archived = os.stat(RETIRED, dir_fd=directory, follow_symlinks=False)
        if candidate.metadata(linked) != candidate.metadata(archived) \
                or (original.st_dev, original.st_ino) != (linked.st_dev, linked.st_ino):
            raise ValueError('retired hardlink identity mismatch')
        stage = 'sync-retired-directory'
        os.fsync(directory)
        stage = 'check-before-unlink'
        pending_identity(candidate, directory, descriptor, 2)
        stage = 'unlink-pending'
        os.unlink('pending.json', dir_fd=directory)
        stage = 'sync-unlinked-directory'
        os.fsync(directory)
        stage = 'check-archived-after-unlink'
        archived = os.stat(RETIRED, dir_fd=directory, follow_symlinks=False)
        if archived.st_nlink != 1 or candidate.metadata(archived) != candidate.metadata(os.fstat(descriptor)):
            raise ValueError('final retired identity changed')
    except (OSError, ValueError) as error:
        raise ValueError(json.dumps(dict(retirement_error=candidate.receipt_error(stage, error)))) from error


def reconcile_once(candidate, ledger, decision):
    """No retry/rollback on error; concurrent privileged mutation is excluded.

    Caller holds the same heavy lock and has independently admitted this exact
    interrupted fixture. This storage operation grants no successor/replay authority.
    """
    directory = descriptor = None
    errors = []
    stage = 'ancestry'
    try:
        candidate.ledger_ancestry()
        stage = 'open-ledger'
        directory = os.open(candidate.LEDGER, os.O_RDONLY | os.O_DIRECTORY |
                            os.O_NOFOLLOW | os.O_CLOEXEC)
        candidate.ledger_identity(directory, ledger['identity'])
        candidate.read_epoch(directory, ledger['epoch_sha256'])
        stage = 'open-pending'
        descriptor = os.open('pending.json', os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC,
                             dir_fd=directory)
        stage = 'validate-pending'
        pending_identity(candidate, directory, descriptor, 1)
        stage = 'durable-decision'
        durable_decision(candidate, directory, decision)
        stage = 'preserve-and-retire'
        preserve_then_unlink(candidate, directory, descriptor)
        stage = 'final-directory-identity'
        candidate.ledger_identity(directory, ledger['identity'])
    except (OSError, ValueError, TypeError) as error:
        errors.append(candidate.receipt_error(stage, error))
    finally:
        candidate.close_receipt(descriptor, 'pending', errors)
        candidate.close_receipt(directory, 'ledger', errors)
    if errors:
        raise RuntimeError(json.dumps(dict(status='UNKNOWN_NO_RETRY_OR_ROLLBACK', errors=errors)))
    return dict(status='EXACT_PRE_ADMISSION_CUT_RECONCILED', authority='NONE',
                pending_sha256=PENDING_SHA, retired_name=RETIRED, decision_name=DECISION,
                successor_admitted=False, replay_authorized=False)


def read(path):
    with path.open('rb') as stream:
        data = stream.read(1048577)
    if len(data) > 1048576:
        raise ValueError('bounded record required')
    return json.loads(data)


def verify_evidence_roster(root, rows, names):
    if set(rows) != set(names):
        raise ValueError('closed evidence roster required')
    for name, expected in rows.items():
        if sha(root / name) != expected:
            raise ValueError('evidence changed: ' + name)


def verify_terminal(result, before):
    if before['status'] != 'FAILED_OR_UNKNOWN':
        raise ValueError('preliminary record changed')
    for key, value in before.items():
        if key != 'status' and result[key] != value:
            raise ValueError('before-cleanup observation mismatch')
    if result['acquired_roles'] != sorted(ROLES) or result['unacquired_roles_unknown'] \
            or set(result['before_cleanup']) != ROLES:
        raise ValueError('incomplete tracked roles')
    for row in result['before_cleanup'].values():
        if row != dict(mask=17, terminal=True, reaped=True):
            raise ValueError('tracked role not terminal before cleanup')
    cleanup = result['cleanup']
    if not cleanup['complete'] or cleanup['signals'] or cleanup['errors'] or cleanup['waited'] != -9 \
            or cleanup['observations'] != result['before_cleanup']:
        raise ValueError('cleanup-assisted or incomplete termination')


def verify_cut_acknowledgment(result):
    outer = read(NORMAL / 'outer-result.json')
    tool = read(NORMAL / 'TOOL-EXIT-OBSERVATION.json')
    if result['status'] != 'TESTED_INSTRUMENTED_PRE_ADMISSION_CUT' \
            or result['cut'] != 'AFTER_ACTIVE_DURABLE_BEFORE_PROVE' or not result['instrumented'] \
            or result['manifest'] != MANIFEST_SHA or result['observer_wait'] != -9 \
            or result['intervention'] != 'SIGKILL_SENT' or result['payload_entered'] \
            or not result['cleanup_was_after_observation'] or not result['post_source_and_tools_verified'] \
            or result['replay_authorized'] or result['successor_admitted']:
        raise ValueError('wrong interrupted disposition')
    if outer['actual_exit'] != 0 or tool['exit_code'] != 0 \
            or outer['manifest_sha256'] != MANIFEST_SHA \
            or outer['wrapper_sha256'] != sha(NORMAL / 'witness.py') \
            or outer['stdout_sha256'] != sha(NORMAL / 'outer.stdout') \
            or read(NORMAL / 'outer.stdout') != result:
        raise ValueError('cut acknowledgment mismatch')


def verify_refusal(result):
    outer = read(REFUSAL / 'outer-result.json')
    note = read(REFUSAL / 'TOOL-EXIT-OBSERVATION.json')
    expected = dict(status='UNCERTAIN_DO_NOT_RETRY', errors=[dict(stage='create-pending',
                    type='FileExistsError', errno=17, message="[Errno 17] File exists: 'pending.json'")])
    if outer['actual_exit'] != 1 or note['invocation']['exit_code'] != 1 \
            or note['invocation']['exception_value'] != expected or note['readback']['exit_code'] != 0 \
            or outer['manifest_sha256'] != sha(REFUSAL / 'execution-source.json') \
            or outer['stdout_sha256'] != sha(REFUSAL / 'outer.stdout') \
            or (REFUSAL / 'outer.stdout').stat().st_size != 0:
        raise ValueError('pending refusal mismatch')
    if sha(REFUSAL / 'pending-after.json') != PENDING_SHA \
            or read(REFUSAL / 'pending-after.json') != result['pending_binding']['value']:
        raise ValueError('refused pending changed')
    for root in (NORMAL, REFUSAL):
        if (root / 'out/payload-entered.json').exists() or (root / 'execution-result.json').exists():
            raise ValueError('unexpected payload or final observer receipt')
    if (REFUSAL / 'active.json').exists():
        raise ValueError('refused invocation became active')


def verify_observations(decision):
    if decision['operation_manifest'] != MANIFEST_SHA or decision['pending_sha256'] != PENDING_SHA \
            or decision['scope'] != 'EXACT_ABORTED_PRE_ADMISSION_FIXTURE_ONLY' \
            or decision['authority'] != 'NONE' or decision['successor_admitted'] or decision['replay_authorized']:
        raise ValueError('fixed interrupted-fixture scope required')
    verify_evidence_roster(NORMAL, decision['evidence_sha256'], EVIDENCE_NAMES)
    verify_evidence_roster(REFUSAL, decision['refusal_sha256'], REFUSAL_NAMES)
    result = read(NORMAL / 'witness-result.json')
    verify_cut_acknowledgment(result)
    verify_terminal(result, read(NORMAL / 'witness-before-cleanup.json'))
    pending = result['pending_binding']
    if result['pending_before'] != PENDING_SHA or result['pending_after'] != PENDING_SHA \
            or pending['sha256'] != PENDING_SHA or pending['identity'] != decision['pending_identity'] \
            or pending['value']['bindings']['manifest'] != MANIFEST_SHA \
            or pending['value']['status'] != 'UNRESOLVED_DO_NOT_RETRY':
        raise ValueError('cut pending binding mismatch')
    verify_refusal(result)


def verify_ledger_state(candidate, config, decision):
    expected = dict(config['cut']['ledger_files'], **{'pending.json': PENDING_SHA})
    if decision['ledger_before'] != expected:
        raise ValueError('fixed ledger roster changed')
    names = set()
    with os.scandir(candidate.LEDGER) as entries:
        for entry in entries:
            if len(names) >= 4:
                raise ValueError('unexpected extra ledger record')
            names.add(entry.name)
    if names != set(expected):
        raise ValueError('ledger roster mismatch')
    for name, wanted in expected.items():
        if sha(candidate.LEDGER / name) != wanted:
            raise ValueError('ledger history changed')
    if candidate.metadata((candidate.LEDGER / 'pending.json').lstat()) != decision['pending_identity']:
        raise ValueError('original interrupted pending identity changed')


def verify_source_argument():
    if len(sys.argv) != 2 or sha(ROOT / 'source.json') != sys.argv[1]:
        raise ValueError('fixed reconciliation source required')
    sources = json.loads((ROOT / 'source.json').read_text())
    if set(sources) != set(SOURCE_NAMES):
        raise ValueError('closed reconciliation source roster required')
    for name, expected in sources.items():
        if sha(ROOT / name) != expected:
            raise ValueError('reconciliation source changed')


def admit_normal(candidate, config, helper, decision, lock):
    """Caller holds lock; all validation precedes the first ledger write."""
    verify_source_argument()
    verify_observations(decision)
    candidate.verify_manifest(json.loads((NORMAL / 'execution-source.json').read_text()))
    candidate.verify_inputs(config, json.loads((NORMAL / 'source-binding.json').read_text()))
    verify_ledger_state(candidate, config, decision)
    candidate.verify_host(config, helper)
    helper.validate_tools(config)
    if helper.identity(lock) != tuple(decision['lock_identity']) \
            or helper.identity(lock) != helper.identity(helper.LOCK.lstat()):
        raise ValueError('heavy lock mismatch')


def main():
    verify_source_argument()
    decision = json.loads((ROOT / 'decision.json').read_text())
    verify_observations(decision)
    candidate = candidate_module()
    config = json.loads((NORMAL / 'config.json').read_text())
    helper = candidate.helpers(config)
    candidate.verify_host(config, helper)
    helper.validate_tools(config)
    with ExitStack() as stack:
        lock = helper.hold_lock(stack)
        admit_normal(candidate, config, helper, decision, lock)
        result = reconcile_once(candidate, config['recovery_ledger'], decision)
    print(json.dumps(result), flush=True)


if __name__ == '__main__':
    main()

"""One operator-authorized normal-fixture reconciliation; no recovery authority."""
from contextlib import ExitStack
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import stat
import sys

ROOT = Path(__file__).resolve().parent
NORMAL = ROOT.parent / 'ordinary-recovery-latch-integration-20261026-v1'
PENDING_SHA = '61b0198e55a845a4d84a0711189071ed11a7d7140816252c52637cfb480ebf0f'
MANIFEST_SHA = '27dfb8d87c9381a5e5768149b8168e85348d6b000a327afe94e89bd95f196d28'
RETIRED = 'retired-' + MANIFEST_SHA + '.json'
DECISION = 'decision-' + MANIFEST_SHA + '.json'
MAX_RECORD = 65536
SOURCE_NAMES = ('candidate.py', 'reconcile.py', 'test_reconcile.py', 'decision.json')
EVIDENCE_NAMES = (
    'config.json', 'execution-source.json', 'source-binding.json', 'proof_wrapper.py',
    'execution-result.json', 'outer-result.json', 'outer.stdout', 'proof.stderr',
    'proof.stdout', 'entry.json', 'active.json', 'pending-before.json',
    'PENDING-READBACK.json', 'OWNER-AUDIT.json', 'RESULT-INDEPENDENT-REVIEW.json',
    'TOOL-EXIT-OBSERVATION.json', 'EXECUTION-DECISION.json',
)


def sha(path):
    if not path.is_file() or path.is_symlink() or path.stat().st_size > 1048576:
        raise ValueError('bounded regular evidence file required')
    with path.open('rb') as stream:
        data = stream.read(1048577)
    if len(data) > 1048576:
        raise ValueError('evidence grew beyond bound')
    return hashlib.sha256(data).hexdigest()


def candidate_module():
    spec = importlib.util.spec_from_file_location('fixed_latch_candidate', ROOT / 'candidate.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    # Only source validation and ledger helpers are used; never its executor.
    module.ROOT = NORMAL
    return module


def pending_identity(candidate, directory, descriptor, links):
    opened = os.fstat(descriptor)
    named = os.stat('pending.json', dir_fd=directory, follow_symlinks=False)
    if not stat.S_ISREG(opened.st_mode) or opened.st_uid != os.geteuid() \
            or stat.S_IMODE(opened.st_mode) != 0o600 or opened.st_nlink != links \
            or candidate.metadata(opened) != candidate.metadata(named):
        raise ValueError('pending identity changed')
    os.lseek(descriptor, 0, os.SEEK_SET)
    data = os.read(descriptor, MAX_RECORD + 1)
    if len(data) != opened.st_size or len(data) > MAX_RECORD \
            or hashlib.sha256(data).hexdigest() != PENDING_SHA:
        raise ValueError('pending content changed')
    return opened


def durable_decision(candidate, directory, value):
    descriptor = None
    errors = []
    stage = 'create-decision'
    try:
        descriptor = os.open(DECISION, os.O_WRONLY | os.O_CREAT | os.O_EXCL |
                             os.O_NOFOLLOW | os.O_CLOEXEC, 0o600, dir_fd=directory)
        stage = 'write-decision'
        candidate.write_receipt(descriptor, value)
        stage = 'sync-decision'
        os.fsync(descriptor)
        stage = 'sync-decision-directory'
        os.fsync(directory)
    except (OSError, ValueError, TypeError) as error:
        errors.append(candidate.receipt_error(stage, error))
    finally:
        candidate.close_receipt(descriptor, 'decision', errors)
    if errors:
        raise ValueError(json.dumps(dict(decision_errors=errors)))


def preserve_then_unlink(candidate, directory, descriptor):
    stage = 'check-before-link'
    try:
        original = pending_identity(candidate, directory, descriptor, 1)
        stage = 'link-retired'
        os.link('pending.json', RETIRED, src_dir_fd=directory, dst_dir_fd=directory,
                follow_symlinks=False)
        stage = 'check-retired'
        linked = pending_identity(candidate, directory, descriptor, 2)
        archived = os.stat(RETIRED, dir_fd=directory, follow_symlinks=False)
        if candidate.metadata(linked) != candidate.metadata(archived) \
                or (original.st_dev, original.st_ino) != (linked.st_dev, linked.st_ino):
            raise ValueError('retired hardlink identity mismatch')
        stage = 'sync-retired-directory'
        os.fsync(directory)
        stage = 'check-before-unlink'
        pending_identity(candidate, directory, descriptor, 2)
        stage = 'unlink-pending'
        os.unlink('pending.json', dir_fd=directory)
        stage = 'sync-unlinked-directory'
        os.fsync(directory)
        stage = 'check-archived-after-unlink'
        archived = os.stat(RETIRED, dir_fd=directory, follow_symlinks=False)
        if archived.st_nlink != 1 or candidate.metadata(archived) != candidate.metadata(os.fstat(descriptor)):
            raise ValueError('final retired identity changed')
    except (OSError, ValueError) as error:
        raise ValueError(json.dumps(dict(retirement_error=candidate.receipt_error(stage, error)))) from error


def reconcile_once(candidate, ledger, decision):
    """No retry/rollback on error; concurrent privileged mutation is excluded.

    Caller holds the same heavy lock and has independently admitted this exact
    normal fixture. This storage operation grants no successor/replay authority.
    """
    directory = descriptor = None
    errors = []
    stage = 'ancestry'
    try:
        candidate.ledger_ancestry()
        stage = 'open-ledger'
        directory = os.open(candidate.LEDGER, os.O_RDONLY | os.O_DIRECTORY |
                            os.O_NOFOLLOW | os.O_CLOEXEC)
        candidate.ledger_identity(directory, ledger['identity'])
        candidate.read_epoch(directory, ledger['epoch_sha256'])
        stage = 'open-pending'
        descriptor = os.open('pending.json', os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC,
                             dir_fd=directory)
        stage = 'validate-pending'
        pending_identity(candidate, directory, descriptor, 1)
        stage = 'durable-decision'
        durable_decision(candidate, directory, decision)
        stage = 'preserve-and-retire'
        preserve_then_unlink(candidate, directory, descriptor)
        stage = 'final-directory-identity'
        candidate.ledger_identity(directory, ledger['identity'])
    except (OSError, ValueError, TypeError) as error:
        errors.append(candidate.receipt_error(stage, error))
    finally:
        candidate.close_receipt(descriptor, 'pending', errors)
        candidate.close_receipt(directory, 'ledger', errors)
    if errors:
        raise RuntimeError(json.dumps(dict(status='UNKNOWN_NO_RETRY_OR_ROLLBACK', errors=errors)))
    return dict(status='EXACT_NORMAL_FIXTURE_RECONCILED', authority='NONE',
                pending_sha256=PENDING_SHA, retired_name=RETIRED, decision_name=DECISION,
                successor_admitted=False, replay_authorized=False)


def verify_observations(decision):
    if decision['operation_manifest'] != MANIFEST_SHA or decision['pending_sha256'] != PENDING_SHA \
            or decision['scope'] != 'EXACT_COMPLETED_NORMAL_FIXTURE_ONLY':
        raise ValueError('fixed manual decision scope required')
    if set(decision['evidence_sha256']) != set(EVIDENCE_NAMES):
        raise ValueError('closed normal evidence roster required')
    for name, expected in decision['evidence_sha256'].items():
        if sha(NORMAL / name) != expected:
            raise ValueError('normal evidence changed: ' + name)
    result = json.loads((NORMAL / 'execution-result.json').read_text())
    outer = json.loads((NORMAL / 'outer-result.json').read_text())
    tool = json.loads((NORMAL / 'TOOL-EXIT-OBSERVATION.json').read_text())
    if result['execution_status'] != 'TERMINAL_REPORTS_REQUIRE_AUDIT' \
            or result['exit'] != 0 or not result['proof_dispatched'] \
            or outer['actual_exit'] != 0 or tool['exit_code'] != 0 \
            or outer['manifest_sha256'] != MANIFEST_SHA \
            or outer['stdout_sha256'] != sha(NORMAL / 'outer.stdout') \
            or json.loads((NORMAL / 'outer.stdout').read_text()) != result:
        raise ValueError('normal acknowledgment mismatch')
    cleanup = result['cleanup']
    if not cleanup['complete'] or cleanup['errors'] or cleanup['waited'] != 0:
        raise ValueError('normal cleanup incomplete')
    for observations in (result['terminal'], cleanup['observations']):
        if set(observations) != {'launcher', 'init', 'leader'} or \
                any(row != dict(mask=17, reaped=True, terminal=True) for row in observations.values()):
            raise ValueError('tracked terminal evidence missing')


def verify_source_argument():
    if len(sys.argv) != 2 or sha(ROOT / 'source.json') != sys.argv[1]:
        raise ValueError('fixed reconciliation source required')
    sources = json.loads((ROOT / 'source.json').read_text())
    if set(sources) != set(SOURCE_NAMES):
        raise ValueError('closed reconciliation source roster required')
    for name, expected in sources.items():
        if sha(ROOT / name) != expected:
            raise ValueError('reconciliation source changed')


def admit_normal(candidate, config, helper, decision, lock):
    """Caller holds lock; all validation precedes the first ledger write."""
    verify_source_argument()
    verify_observations(decision)
    candidate.verify_manifest(json.loads((NORMAL / 'execution-source.json').read_text()))
    candidate.verify_inputs(config, json.loads((NORMAL / 'source-binding.json').read_text()))
    candidate.verify_host(config, helper)
    helper.validate_tools(config)
    if helper.identity(lock) != tuple(decision['lock_identity']) \
            or helper.identity(lock) != helper.identity(helper.LOCK.lstat()):
        raise ValueError('heavy lock mismatch')


def main():
    verify_source_argument()
    decision = json.loads((ROOT / 'decision.json').read_text())
    verify_observations(decision)
    candidate = candidate_module()
    config = json.loads((NORMAL / 'config.json').read_text())
    helper = candidate.helpers(config)
    candidate.verify_host(config, helper)
    helper.validate_tools(config)
    with ExitStack() as stack:
        lock = helper.hold_lock(stack)
        admit_normal(candidate, config, helper, decision, lock)
        result = reconcile_once(candidate, config['recovery_ledger'], decision)
    print(json.dumps(result), flush=True)


if __name__ == '__main__':
    main()

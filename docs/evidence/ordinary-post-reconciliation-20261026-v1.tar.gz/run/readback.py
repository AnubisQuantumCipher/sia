"""Read only: exact new archive, previous records and unchanged ledger identity."""
import hashlib
import json
import os
from pathlib import Path
import stat

ROOT = Path(__file__).resolve().parent
LEDGER = Path('/var/tmp/sia-ordinary-recovery-20261026-v1')
FIELDS = ('st_dev', 'st_ino', 'st_mode', 'st_uid', 'st_gid', 'st_nlink')


def identity(value):
    return [getattr(value, field) for field in FIELDS]


def decision_digest(value):
    encoded = (json.dumps(value, indent=2, sort_keys=True) + '\n').encode('utf-8')
    return hashlib.sha256(encoded).hexdigest()


def read_file(name):
    path = LEDGER / name
    descriptor = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
    try:
        meta = os.fstat(descriptor)
        mode = 0o444 if name == 'epoch' else 0o600
        if not stat.S_ISREG(meta.st_mode) or meta.st_uid != 0 or meta.st_nlink != 1 \
                or stat.S_IMODE(meta.st_mode) != mode or meta.st_size > 65536:
            raise ValueError('ledger file metadata')
        data = os.read(descriptor, 65537)
        if len(data) != meta.st_size or identity(meta) != identity(path.lstat()):
            raise ValueError('ledger file changed')
    finally:
        os.close(descriptor)
    return data, dict(sha256=hashlib.sha256(data).hexdigest(), bytes=len(data), identity=identity(meta))


def main():
    if os.getresuid() != (0, 0, 0):
        raise ValueError('fixed root readback required')
    decision = json.loads((ROOT / 'decision.json').read_text())
    manifest = decision['operation_manifest']
    retired, name = 'retired-' + manifest + '.json', 'decision-' + manifest + '.json'
    expected = {key: value for key, value in decision['ledger_before'].items() if key != 'pending.json'}
    expected[retired] = decision['pending_sha256']
    expected[name] = decision_digest(decision)
    names = set()
    with os.scandir(LEDGER) as entries:
        for entry in entries:
            if len(names) >= 7:
                raise ValueError('extra ledger record')
            names.add(entry.name)
    if names != set(expected) or identity(LEDGER.lstat()) != decision['ledger_identity']:
        raise ValueError('ledger roster or identity')
    rows = {}
    for key, digest in expected.items():
        data, row = read_file(key)
        if row['sha256'] != digest:
            raise ValueError('ledger byte mismatch')
        if key == name and json.loads(data) != decision:
            raise ValueError('decision changed')
        if key == retired and row['identity'] != decision['pending_identity']:
            raise ValueError('original pending identity changed')
        rows[key] = row
    print(json.dumps(dict(status='EXACT_POST_ADMISSION_FIXTURE_READBACK', authority='NONE',
                          directory=identity(LEDGER.lstat()), rows=rows, pending_absent=True)), flush=True)


if __name__ == '__main__':
    main()

"""One fixed invocation and actual exit readback; not a whole-job custodian."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def sync_directory():
    descriptor = os.open(ROOT, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


def main():
    if len(sys.argv) != 2 or sha(ROOT / 'source.json') != sys.argv[1] \
            or os.getresuid() != (1000, 1000, 1000):
        raise ValueError('fixed source-bound user invocation required')
    if (ROOT / 'outer-result.json').exists() or (ROOT / 'entry.json').exists():
        raise ValueError('existing or uncertain invocation; reconcile before retry')
    manifest = json.loads((ROOT / 'source.json').read_text())
    for name, expected in manifest.items():
        if sha(ROOT / name) != expected:
            raise ValueError('source changed: ' + name)
    command = ['/usr/bin/sudo', '/usr/bin/prlimit', '--core=0:0', '--',
               '/usr/bin/python3', '-I', '-B',
               str(ROOT / 'reconcile.py'), sys.argv[1]]
    # stdin and stderr stay on the terminal for sudo's masked credential input.
    # Neither credential input nor stderr is copied into these receipt files.
    with (ROOT / 'outer.stdout').open('xb') as stream:
        completed = subprocess.run(command, stdout=stream, check=False)
        stream.flush()
        os.fsync(stream.fileno())
    sync_directory()
    result = dict(actual_exit=completed.returncode, command=command,
                  manifest_sha256=sys.argv[1], stdout_sha256=sha(ROOT / 'outer.stdout'),
                  wrapper_sha256=sha(ROOT / 'reconcile.py'),
                  status='ACTUAL_EXIT_OBSERVED_NOT_ACCEPTANCE')
    with (ROOT / 'outer-result.json').open('x') as stream:
        json.dump(result, stream, indent=2, sort_keys=True)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())
    sync_directory()
    print(json.dumps(result), flush=True)
    raise SystemExit(0 if completed.returncode == 0 else 1)


if __name__ == '__main__':
    main()

#!/usr/bin/env bash
set -eo pipefail
source /home/sicarii/opt/gnat/env.sh
set -u
cd /home/sicarii/Work/sia-assurance-evidence-20261019/ownership-transfer-20261024/continuity-descriptor-domain-v1
exec 9>/home/sicarii/.worldline-heavy.lock
if ! flock -n 9; then printf 'BUSY\n' > admission.txt; exit 75; fi
printf 'ADMITTED single local owner; no cap increases\n' > admission.txt
run_step() {
    local task_label="$1"
    shift
    local task_exit=0
    timeout --kill-after=5s 60s prlimit --as=2147483648 --fsize=536870912 --core=0 -- "$@" > "../${task_label}.stdout" 2> "../${task_label}.stderr" || task_exit=$?
    printf '%s\n' "$task_exit" > "../${task_label}.exit"
    return "$task_exit"
}
cd source
run_step continuity-compile gprbuild -q -p -j1 -c -U -P spark/transport/continuity_probe.gpr
run_step continuity-link gprbuild -q -p -j1 -P spark/transport/continuity_probe.gpr
run_step request-compile gprbuild -q -p -j1 -c -U -P spark/transport/request_probe.gpr
run_step request-link gprbuild -q -p -j1 -P spark/transport/request_probe.gpr
sha256sum spark/bin/* > ../binary-before.sha256
run_step full-python python3 -B -m unittest discover -s spark/tests -p 'test_*.py' -v
sha256sum --check ../binary-before.sha256 > ../binary-after-check.txt

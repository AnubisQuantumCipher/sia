"""Bound observation pipes without changing the observed process's file limits."""
import os
import selectors
import signal
import subprocess
import time


def capture(command, *, seconds, maximum):
    if (type(seconds) not in (int, float) or not 0 < seconds <= 240
            or type(maximum) is not int or not 0 < maximum <= 1_048_576):
        raise ValueError('capture bounds refused')
    started = time.monotonic()
    output = bytearray()
    status = 'running'
    with selectors.DefaultSelector() as selector:
        process = subprocess.Popen(command, stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            start_new_session=True, close_fds=True)
        try:
            if process.stdout is None:
                raise RuntimeError('missing output pipe')
            selector.register(process.stdout, selectors.EVENT_READ)
            # Each nonempty read consumes at least one byte of the finite budget.
            for _ in range(maximum + 1):
                remaining = seconds - (time.monotonic() - started)
                if remaining <= 0 or not selector.select(remaining):
                    status = 'deadline'
                    break
                block = os.read(process.stdout.fileno(),
                                min(65_536, maximum - len(output) + 1))
                if not block:
                    status = 'complete'
                    break
                if len(output) + len(block) > maximum:
                    status = 'output-limit'
                    break
                output.extend(block)
            else:
                status = 'read-count-limit'
            if status == 'complete':
                try:
                    result = process.wait(timeout=max(
                        0.001, seconds - (time.monotonic() - started)))
                except subprocess.TimeoutExpired:
                    status = 'deadline'
            if status != 'complete':
                # No poll/reap precedes signaling this still-owned group leader.
                os.killpg(process.pid, signal.SIGKILL)
                result = process.wait(timeout=5)
        except BaseException:
            if process.returncode is None:
                os.killpg(process.pid, signal.SIGKILL)
                process.wait(timeout=5)
            raise
        finally:
            if process.stdout is not None:
                process.stdout.close()
    return {'exit': result, 'capture_status': status,
            'elapsed_seconds': time.monotonic() - started}, bytes(output)

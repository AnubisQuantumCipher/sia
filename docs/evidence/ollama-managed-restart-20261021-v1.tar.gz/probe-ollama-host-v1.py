"""Non-destructive installed-account controls. No model deletion or service restart."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path

ROOT = Path('/home/sicarii/Work/sia-assurance-evidence-20261019')


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


OWNER = '''import json, urllib.request
request=urllib.request.Request('http://127.0.0.1:11434/api/embed',
    data=json.dumps({'model':'nomic-embed-text:v1.5',
        'input':'SIA installed account guard commissioning'}).encode(),
    headers={'Content-Type':'application/json'})
with urllib.request.urlopen(request, timeout=60) as response:
    raw=response.read(1048577)
    if response.status!=200 or len(raw)>1048576:
        raise RuntimeError('embedding response refused')
value=json.loads(raw)
vectors=value.get('embeddings')
if not isinstance(vectors,list) or len(vectors)!=1 or not isinstance(vectors[0],list) or not vectors[0]:
    raise RuntimeError('embedding shape refused')
print(json.dumps({'status':'OBSERVED_OWNER_EMBEDDING','model':value.get('model'),
    'vector_dimensions':len(vectors[0]),'finite':all(isinstance(x,(int,float)) and abs(x)<float('inf') for x in vectors[0])}))
if not all(isinstance(x,(int,float)) and abs(x)<float('inf') for x in vectors[0]):
    raise RuntimeError('nonfinite embedding')
'''

DENIED = '''import json, socket, urllib.request, urllib.error
try:
    with socket.create_connection(('127.0.0.1',11434),timeout=3):
        raise RuntimeError('alternate account connected')
except ConnectionRefusedError:
    pass
request=urllib.request.Request('http://127.0.0.1:11434/api/delete', method='DELETE',
    data=b'{"model":"sia-guard-denial-canary-do-not-create:20261021"}',
    headers={'Content-Type':'application/json'})
try:
    urllib.request.urlopen(request,timeout=3)
    raise RuntimeError('alternate account reached HTTP')
except urllib.error.HTTPError:
    raise RuntimeError('HTTP response proves guard bypass')
except urllib.error.URLError as error:
    if not isinstance(error.reason, ConnectionRefusedError):
        raise
print(json.dumps({'status':'OBSERVED_OTHER_UID_TRANSPORT_DENIAL','uid':__import__('os').getuid(),
    'controls':['TCP connect','DELETE nonexistent canary'],
    'limitation':'No production model deletion attempted; same-UID and root remain trusted.'}))
'''

DELEGATION = '''import json, subprocess
prefix=['/usr/bin/sudo','-n','-k','--']
base=['/usr/bin/python3','-I','-S','-B','/usr/local/libexec/sia-ollama-guard']
cases=[('exact-read-only',base+['check-kernel'],True),
    ('apply-refused',base+['apply'],False),
    ('changed-arguments-refused',base+['check-kernel','extra'],False),
    ('general-interpreter-refused',['/usr/bin/python3','-I','-S','-B','-c','raise SystemExit(0)'],False)]
results=[]
for name,argv,wanted in cases:
    result=subprocess.run(prefix+argv,capture_output=True,timeout=20)
    if (result.returncode==0)!=wanted:
        raise RuntimeError(name+' unexpected delegation result')
    results.append({'name':name,'exit':result.returncode})
print(json.dumps({'status':'OBSERVED_OWNER_DELEGATION_CONTROLS','cases':results}))
'''


def normalize(value):
    if isinstance(value, list):
        return [normalize(x) for x in value]
    if isinstance(value, dict):
        result = {}
        for key, child in value.items():
            if key == 'counter' and isinstance(child, dict):
                result[key] = {k: 0 if k in ('packets', 'bytes') else v for k, v in child.items()}
            else:
                result[key] = normalize(child)
        return result
    return value


def unrelated(raw):
    value = json.loads(raw)
    return [normalize(x) for x in value['nftables'] if 'metainfo' not in x and
        not any(isinstance(y, dict) and (y.get('table') == 'sia_ollama_owner_v1' or
            y.get('name') == 'sia_ollama_owner_v1') for y in x.values())]


def main():
    if os.geteuid() != 0:
        raise ValueError('administrator required for alternate-account controls')
    run = DRIVER.run
    before = (DRIVER.OUT / 'ruleset-before.log').read_bytes()
    after = (DRIVER.OUT / 'ruleset-after.log').read_bytes()
    if unrelated(before) != unrelated(after):
        raise ValueError('unrelated firewall policy changed beyond traffic counters')
    DRIVER.save('unrelated-policy-comparison.json', b'{"status":"MATCH_EXCEPT_LIVE_COUNTER_VALUES","raw_bytes_equal":false}\n')
    tags = run('owner-tags-before', ['/usr/bin/runuser', '-u', 'sicarii', '--',
        '/usr/bin/curl', '--fail', '--silent', '--show-error', '--max-time', '10',
        'http://127.0.0.1:11434/api/tags'])
    run('owner-embedding', ['/usr/bin/runuser', '-u', 'sicarii', '--',
        '/usr/bin/python3', '-I', '-S', '-B', '-c', OWNER], 90)
    run('other-account-denial', ['/usr/bin/runuser', '-u', 'nobody', '--',
        '/usr/bin/python3', '-I', '-S', '-B', '-c', DENIED])
    run('owner-delegation', ['/usr/bin/runuser', '-u', 'sicarii', '--',
        '/usr/bin/python3', '-I', '-S', '-B', '-c', DELEGATION], 90)
    current = run('owner-tags-after', ['/usr/bin/runuser', '-u', 'sicarii', '--',
        '/usr/bin/curl', '--fail', '--silent', '--show-error', '--max-time', '10',
        'http://127.0.0.1:11434/api/tags'])
    if json.loads(tags) != json.loads(current):
        raise ValueError('model inventory changed')
    run('post-probe-kernel', ['/usr/bin/python3', '-I', '-S', '-B',
        '/usr/local/libexec/sia-ollama-guard', 'check-kernel'])
    DRIVER.save('runtime-result.json', (json.dumps({
        'status': 'OBSERVED_INSTALLED_ACCOUNT_CONTROLS_PASS', 'checks': DRIVER.EVENTS,
        'model_inventory_unchanged': True, 'same_uid_and_root_outside_boundary': True,
        'open': ['firewall reload', 'boot ordering execution', 'actual managed restart',
            'upgrade/uninstall on this host', 'full installed SIA readiness and recall']}, indent=2) + '\n').encode())
    print('Installed guard: owner embedding, other-account denial and exact delegation controls passed.')


if __name__ == '__main__':
    DRIVER = load('commission_driver', ROOT / 'commission-ollama-host-v1.py')
    helper = ROOT / 'bounded-read-capture-v1.py'
    if hashlib.sha256(helper.read_bytes()).hexdigest() != 'e647b40e9cf1aa705c107c54535889b3f08b6651ec989a07add5cf371d6dc5b6':
        raise ValueError('capture helper changed')
    DRIVER.CAPTURE = load('capture', helper)
    main()

"""First-install only. Exact reviewed files, no listener restart or ruleset flush."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import stat
import sys

ROOT = Path('/home/sicarii/Work/sia-assurance-evidence-20261019')
OUT = ROOT / 'ollama-host-commission-20261021-v1'
TARGETS = {
    'owner': ('/etc/sia/ollama-owner', 0o644),
    'helper': ('/usr/local/libexec/sia-ollama-guard', 0o755),
    'unit': ('/etc/systemd/system/sia-ollama-guard.service', 0o644),
    'sudoers': ('/etc/sudoers.d/sia-ollama-guard', 0o440),
}
EVENTS = []


def save(name, raw):
    path = OUT / name
    with path.open('xb') as stream:
        stream.write(raw)
    os.chmod(path, 0o600)
    os.chown(path, 1000, 1000)


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


def run(name, args, seconds=30):
    result, raw = CAPTURE.capture(args, seconds=seconds, maximum=1_048_576)
    save(name + '.log', raw)
    EVENTS.append({'name': name, 'argv': args, **result,
        'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)})
    save(name + '.json', (json.dumps(EVENTS[-1], indent=2) + '\n').encode())
    if result['capture_status'] != 'complete' or result['exit'] != 0:
        raise RuntimeError(name + ' did not pass')
    return raw


def protected_directory(path):
    info = path.lstat()
    if not stat.S_ISDIR(info.st_mode) or info.st_uid != 0 or info.st_mode & 0o022:
        raise ValueError('unprotected parent: ' + str(path))


def preflight():
    for name, (target, _) in TARGETS.items():
        if os.path.lexists(target):
            raise ValueError('first-install target already exists: ' + target)
        raw = (OUT / name).read_bytes()
        if len(raw) > 32768:
            raise ValueError('oversized staged artifact')
    source = json.loads((OUT / 'source.json').read_text())
    if source['merged_source'] != '514779ddf9ba6dcd4b5d1dafabac602910751cb3':
        raise ValueError('unexpected merged source')
    for name in ('helper', 'unit', 'sudoers'):
        if hashlib.sha256((OUT / name).read_bytes()).hexdigest() != source[name]['sha256']:
            raise ValueError('staged source changed')
    if source['helper']['sha256'] != '9f00a649ec27c4531b8e4fa3942c40105e714a1eaf093f4ac0ec971dfc27b3d7':
        raise ValueError('helper differs from independently reviewed source')
    if (OUT / 'owner').read_bytes() != b'1000\n':
        raise ValueError('owner configuration differs')
    for path in ('/etc', '/etc/systemd', '/etc/systemd/system',
                 '/etc/sudoers.d', '/usr', '/usr/local', '/usr/local/libexec'):
        protected_directory(Path(path))
    if os.path.lexists('/etc/sia'):
        protected_directory(Path('/etc/sia'))
    tables = json.loads(run('tables-before', ['/usr/bin/nft', '-j', '-n', 'list', 'tables']))
    for entry in tables['nftables']:
        if entry.get('table', {}).get('name') == 'sia_ollama_owner_v1':
            raise ValueError('guard table already exists; review required')
    run('ruleset-before', ['/usr/bin/nft', '-j', '-n', 'list', 'ruleset'])
    run('ufw-before', ['/usr/bin/ufw', 'status', 'verbose'])
    run('sudoers-stage-check', ['/usr/sbin/visudo', '-c', '-f', str(OUT / 'sudoers')])


def install():
    if not Path('/etc/sia').exists():
        os.mkdir('/etc/sia', 0o755)
        os.chmod('/etc/sia', 0o755)
    protected_directory(Path('/etc/sia'))
    for name, (target, mode) in TARGETS.items():
        raw = (OUT / name).read_bytes()
        fd = os.open(target, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, mode)
        with os.fdopen(fd, 'wb') as stream:
            if stream.write(raw) != len(raw):
                raise OSError('short protected-file write')
            stream.flush()
            os.fsync(stream.fileno())
            os.fchmod(stream.fileno(), mode)
        info = Path(target).lstat()
        if info.st_uid != 0 or info.st_gid != 0 or Path(target).read_bytes() != raw:
            raise ValueError('installed artifact differs')
    run('sudoers-global-check', ['/usr/sbin/visudo', '-c'])
    run('daemon-reload', ['/usr/bin/systemctl', 'daemon-reload'])
    run('enable-start', ['/usr/bin/systemctl', 'enable', '--now', 'sia-ollama-guard.service'], 60)
    run('kernel-check', ['/usr/bin/python3', '-I', '-S', '-B',
        '/usr/local/libexec/sia-ollama-guard', 'check-kernel'])
    run('service-readback', ['/usr/bin/systemctl', 'show', 'sia-ollama-guard.service',
        '--property=LoadState,ActiveState,SubState,Result,ExecMainStatus,DropInPaths,FragmentPath,NeedDaemonReload,UnitFileState'])
    run('tables-after', ['/usr/bin/nft', '-j', '-n', 'list', 'tables'])
    run('ruleset-after', ['/usr/bin/nft', '-j', '-n', 'list', 'ruleset'])
    hashes = {name: hashlib.sha256(Path(target).read_bytes()).hexdigest()
              for name, (target, _) in TARGETS.items()}
    save('installed-hashes.json', (json.dumps(hashes, indent=2) + '\n').encode())


def main():
    if os.getuid() != 0 or os.geteuid() != 0:
        raise ValueError('administrator execution required')
    os.umask(0o077)
    preflight()
    save('installation-intent.json', b'{"scope":"reviewed first installation; no listener restart; runtime acceptance remains open"}\n')
    install()
    save('installation-result.json', (json.dumps({'status': 'INSTALLED_PENDING_RUNTIME_QUALIFICATION',
        'source': '514779ddf9ba6dcd4b5d1dafabac602910751cb3', 'checks': EVENTS}, indent=2) + '\n').encode())
    print('Guard installed; exact kernel readback passed. Runtime and lifecycle qualification remain open.')


if __name__ == '__main__':
    helper = ROOT / 'bounded-read-capture-v1.py'
    if hashlib.sha256(helper.read_bytes()).hexdigest() != 'e647b40e9cf1aa705c107c54535889b3f08b6651ec989a07add5cf371d6dc5b6':
        raise ValueError('capture helper changed')
    CAPTURE = module('bounded_capture', helper)
    main()

"""Derive scoped restart evidence without publishing original memory content."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import sys
import tarfile

ROOT = Path(__file__).parent
REPO = Path('/home/sicarii/Work/sia-assurance-kernel-20261019')
RESTART = 'ollama-managed-restart-20261021-v1/'
PROBES = 'ollama-post-restart-probes-20261021-v1/'
DEST = REPO / 'docs/OLLAMA-MANAGED-RESTART-20261021.json'
BUNDLE = REPO / 'docs/evidence/ollama-managed-restart-20261021-v1.tar.gz'
FILES = (
    RESTART + 'source.json', RESTART + 'result.json', RESTART + 'restart-intent.json',
    RESTART + 'connections-before.log', RESTART + 'gate-before.log',
    RESTART + 'manager-before.log', RESTART + 'restart.log',
    RESTART + 'manager-after.log', RESTART + 'gate-after.log',
    PROBES + 'result.json', PROBES + 'owner-embedding.log',
    PROBES + 'other-account-denial.log', PROBES + 'owner-gate.log',
    PROBES + 'other-account-delegation.log',
    'installed-readiness-after-restart-v1.json', 'installed-readiness-after-restart-v1.log',
    'installed-note-direct-20261021-v8.json', 'installed-note-body-comparison-v8.json',
    'ollama-managed-restart-v1.py', 'ollama-post-restart-probes-v1.py',
    'commission-ollama-host-v1.py', 'probe-ollama-host-v1.py',
    'bounded-read-capture-v1.py', 'retain-managed-restart-evidence-v1.py')


def read(name):
    path = ROOT / name
    if path.is_symlink() or not path.resolve().is_relative_to(ROOT.resolve()):
        raise ValueError('unexpected evidence path')
    with path.open('rb') as stream:
        raw = stream.read(1_048_577)
    if len(raw) > 1_048_576:
        raise ValueError('evidence byte limit exceeded')
    return raw


def decoded(name):
    return json.loads(read(name))


def verify():
    restart = decoded(RESTART + 'result.json')
    probes = decoded(PROBES + 'result.json')
    if restart['status'] != 'OBSERVED_MANAGED_RESTART_AND_STARTUP_GATE':
        raise ValueError('restart not confirmed')
    if probes['status'] != 'OBSERVED_POST_RESTART_OWNER_DENIAL_AND_DELEGATION_PASS':
        raise ValueError('post-restart controls incomplete')
    if probes['managed_pid'] != restart['after']['MainPID'] or probes['managed_pid'] in ('0', restart['before']['MainPID']):
        raise ValueError('managed process mismatch')
    for prefix, record in ((RESTART, restart), (PROBES, probes)):
        for check in record['checks']:
            if check['exit'] != 0 or check['capture_status'] != 'complete':
                raise ValueError('incomplete command')
            if hashlib.sha256(read(prefix + check['name'] + '.log')).hexdigest() != check['sha256']:
                raise ValueError('log changed')
    if read(RESTART + 'connections-before.log').strip():
        raise ValueError('restart interrupted observed API clients')
    ready = decoded('installed-readiness-after-restart-v1.json')
    if ready['exit'] != 0 or ready['capture_status'] != 'complete' or ready['before'] != ready['after']:
        raise ValueError('native readiness not confirmed')
    recall = decoded('installed-note-body-comparison-v8.json')
    if not all(recall[k] for k in ('same_body', 'exact_origin', 'request_id_present', 'installed_binaries_unchanged')):
        raise ValueError('direct model-note readback not confirmed')
    return restart, probes, ready, recall


def package():
    output = io.BytesIO()
    artifacts = []
    with gzip.GzipFile(fileobj=output, mode='wb', mtime=0) as zipped:
        with tarfile.open(fileobj=zipped, mode='w|', format=tarfile.USTAR_FORMAT) as archive:
            for name in sorted(FILES):
                raw = read(name)
                info = tarfile.TarInfo(name)
                info.size, info.mode = len(raw), 0o600
                archive.addfile(info, io.BytesIO(raw))
                artifacts.append({'path': name, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()})
    return output.getvalue(), artifacts


def retain(path, raw, checking):
    if checking:
        if path.read_bytes() != raw:
            raise ValueError('versioned evidence does not reproduce')
    else:
        with path.open('xb') as stream:
            stream.write(raw)


def main():
    if sys.argv[1:] not in ([], ['--check']):
        raise ValueError('expected optional --check')
    checking = sys.argv[1:] == ['--check']
    restart, probes, ready, recall = verify()
    payload, artifacts = package()
    value = {'status': 'OBSERVED_SCOPED_MANAGED_RESTART_AND_POST_RESTART_CONTROLS',
        'restart': restart, 'post_restart': probes, 'native_readiness': ready,
        'direct_model_note': recall, 'artifacts': artifacts,
        'bundle': {'path': str(BUNDLE.relative_to(REPO)), 'sha256': hashlib.sha256(payload).hexdigest(), 'bytes': len(payload)},
        'supersedes': 'Earlier no-restart and other-account sudo UNRUN observations only; earlier raw evidence remains.',
        'private_exclusions': ['Original returned note text', 'Private full firewall snapshots'],
        'limits': ['Native leases are cooperative; unrelated same-UID programs remain outside this coordination.',
            'No actual boot, installed upgrade/uninstall, full dependency attestation or complete SIA assurance.',
            'Exact model-note readback does not establish semantic accuracy or compaction continuity.']}
    retain(BUNDLE, payload, checking)
    retain(DEST, (json.dumps(value, indent=2, sort_keys=True) + '\n').encode(), checking)
    print('managed restart evidence matches' if checking else 'managed restart evidence retained')


if __name__ == '__main__':
    main()

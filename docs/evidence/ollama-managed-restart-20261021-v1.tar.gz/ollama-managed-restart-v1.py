"""One coordinated restart attempt; defer if native owners or API clients are active."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import sys

ROOT = Path(__file__).parent
OUT = ROOT / 'ollama-managed-restart-20261021-v1'
BIN = Path('/home/sicarii/.local/share/sia/bin')
EVENTS = []


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


def save(name, value):
    with (OUT / name).open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


def run(name, argv, seconds=30):
    result, raw = CAPTURE.capture(argv, seconds=seconds, maximum=1_048_576)
    with (OUT / (name + '.log')).open('xb') as stream:
        stream.write(raw)
    EVENTS.append({'name': name, 'command': argv, **result,
        'sha256': hashlib.sha256(raw).hexdigest()})
    save(name + '.json', EVENTS[-1])
    if result['exit'] != 0 or result['capture_status'] != 'complete':
        raise RuntimeError(name + ' failed or uncertain; reconcile before retry')
    return raw


def manager(name):
    argv = ['/usr/bin/env', 'XDG_RUNTIME_DIR=/run/user/1000',
        'DBUS_SESSION_BUS_ADDRESS=unix:path=/run/user/1000/bus',
        '/usr/bin/systemctl', '--user', 'show', 'ollama.service',
        '--property=MainPID,ActiveState,SubState,ExecStartPre,ExecMainStatus,NeedDaemonReload']
    return dict(line.split('=', 1) for line in run(name, argv).decode().splitlines())


def guarded_restart(native):
    config = json.loads((ROOT / 'ollama-host-commission-20261021-v1/source.json').read_text())
    paths = {'user-unit': Path('/home/sicarii/.config/systemd/user/ollama.service'),
             'helper': Path('/usr/local/libexec/sia-ollama-guard')}
    for name, path in paths.items():
        if hashlib.sha256(path.read_bytes()).hexdigest() != config[name]['sha256']:
            raise ValueError('installed artifact changed')
    with native._owner_lease(native.CORPUS_OWNER_LOCK, 'SIA corpus transaction', blocking=False):
        with native._owner_lease(native.GBRAIN_OWNER_LOCK, 'SIA PGLite', blocking=False):
            connections = run('connections-before', ['/usr/bin/ss', '-H', '-tn',
                'state', 'established', '( sport = :11434 or dport = :11434 )'])
            if connections.strip():
                return {'status': 'DEFERRED_ACTIVE_API_CONNECTIONS'}
            run('gate-before', ['/usr/bin/python3', '-I', '-S', '-B',
                '/usr/local/libexec/sia-ollama-guard', 'gate'])
            before = manager('manager-before')
            if before['ActiveState'] != 'active' or before['NeedDaemonReload'] != 'no':
                raise ValueError('unexpected service state')
            save('restart-intent.json', {'state': 'DISPATCH_ABOUT_TO_BEGIN', 'before': before,
                'source': config['merged_source'], 'scope': 'authorized managed restart under native cooperative leases',
                'uncertain_outcome_rule': 'Read manager/PID before considering another restart.'})
            run('restart', ['/usr/bin/env', 'XDG_RUNTIME_DIR=/run/user/1000',
                'DBUS_SESSION_BUS_ADDRESS=unix:path=/run/user/1000/bus',
                '/usr/bin/systemctl', '--user', '--job-mode=fail', 'restart', 'ollama.service'], 60)
            after = manager('manager-after')
            pre = after['ExecStartPre']
            if (after['ActiveState'], after['SubState'], after['ExecMainStatus']) != ('active', 'running', '0'):
                raise ValueError('service did not return to running')
            if after['MainPID'] in ('0', before['MainPID']) or 'sia-ollama-guard gate' not in pre:
                raise ValueError('new process or actual gate missing')
            if not re.search(r'code=exited\s*;\s*status=0(?:\s*;|\s*\})', pre):
                raise ValueError('actual ExecStartPre success not confirmed')
            run('gate-after', ['/usr/bin/python3', '-I', '-S', '-B',
                '/usr/local/libexec/sia-ollama-guard', 'gate'])
            return {'status': 'OBSERVED_MANAGED_RESTART_AND_STARTUP_GATE', 'before': before, 'after': after}


def main():
    OUT.mkdir(mode=0o700)
    sys.path.insert(0, str(BIN))
    native = load('installed_sialib_restart', BIN / 'sialib.py')
    save('source.json', {'native_library_sha256': hashlib.sha256((BIN / 'sialib.py').read_bytes()).hexdigest(),
        'runner_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'coordination_limit': 'Native cooperative leases and an empty socket observation do not constrain unrelated same-UID code.'})
    try:
        result = guarded_restart(native)
    except native.OwnerBusy:
        result = {'status': 'DEFERRED_ACTIVE_NATIVE_OWNER'}
    save('result.json', {**result, 'checks': EVENTS})
    print(json.dumps(result))


if __name__ == '__main__':
    CAPTURE = load('capture', ROOT / 'bounded-read-capture-v1.py')
    main()

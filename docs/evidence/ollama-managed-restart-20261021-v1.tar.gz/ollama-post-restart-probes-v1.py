"""Read-only account controls after the confirmed managed restart."""
import importlib.util
import json
import os
from pathlib import Path

ROOT = Path(__file__).parent
OUT = ROOT / 'ollama-post-restart-probes-20261021-v1'


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


def main():
    if os.geteuid() != 0:
        raise ValueError('administrator required for different-account control')
    prior = json.loads((ROOT / 'ollama-managed-restart-20261021-v1/result.json').read_text())
    if prior['status'] != 'OBSERVED_MANAGED_RESTART_AND_STARTUP_GATE':
        raise ValueError('restart not confirmed; reconcile instead of retry')
    probe = load('probe', ROOT / 'probe-ollama-host-v1.py')
    driver = load('driver', ROOT / 'commission-ollama-host-v1.py')
    driver.OUT = OUT
    driver.CAPTURE = load('capture', ROOT / 'bounded-read-capture-v1.py')
    run = driver.run
    run('owner-embedding', ['/usr/bin/runuser', '-u', 'sicarii', '--',
        '/usr/bin/python3', '-I', '-S', '-B', '-c', probe.OWNER], 90)
    run('other-account-denial', ['/usr/bin/runuser', '-u', 'nobody', '--',
        '/usr/bin/python3', '-I', '-S', '-B', '-c', probe.DENIED])
    run('owner-gate', ['/usr/bin/runuser', '-u', 'sicarii', '--',
        '/usr/bin/python3', '-I', '-S', '-B', '/usr/local/libexec/sia-ollama-guard', 'gate'])
    run('other-account-delegation', ['/usr/bin/runuser', '-u', 'nobody', '--',
        '/usr/bin/python3', '-I', '-S', '-B', '-c',
        "import subprocess; p=subprocess.run(['/usr/bin/sudo','-n','-k','--','/usr/bin/python3','-I','-S','-B','/usr/local/libexec/sia-ollama-guard','check-kernel'],capture_output=True,timeout=15); print('other-account delegation exit',p.returncode); raise SystemExit(0 if p.returncode!=0 else 1)"])
    driver.save('result.json', (json.dumps({
        'status': 'OBSERVED_POST_RESTART_OWNER_DENIAL_AND_DELEGATION_PASS',
        'managed_pid': prior['after']['MainPID'], 'checks': driver.EVENTS,
        'open': ['actual boot ordering', 'installed upgrade/uninstall lifecycle',
                 'complete installed dependency attestation', 'marketplace release']}, indent=2) + '\n').encode())
    print('Post-restart owner embedding, other-account denial, full gate and other-account sudo denial passed.')


if __name__ == '__main__':
    main()

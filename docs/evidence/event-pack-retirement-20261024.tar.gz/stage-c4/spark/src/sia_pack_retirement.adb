package body SIA_Pack_Retirement with SPARK_Mode is
   function Prefix_Sizes (Items : Roster; Organ_Bytes : Organ_Length)
      return Size_Array
   is
      Sizes : Size_Array := [others => 0];
      Total : Logical_Size :=
        ((((((Magic'Length + 1) + Organ_Bytes) + 3) + 1) + 4) + 32);
   begin
      Sizes (0) := Total;
      for I in 1 .. Items.Count loop
         Total := (Total + 68) + Items.Records (I).Bytes;
         Sizes (I) := Total;
         pragma Loop_Invariant (Total = Sizes (I));
         pragma Loop_Invariant
           (Sizes (0) = ((((((Magic'Length + 1) + Organ_Bytes) + 3) + 1) + 4) + 32));
         pragma Loop_Invariant
           (for all J in 1 .. I =>
              Sizes (J) = (Sizes (J - 1) + 68) + Items.Records (J).Bytes);
         pragma Loop_Invariant
           (for all J in I + 1 .. Max_Records => Sizes (J) = 0);
         pragma Loop_Invariant
           (for all J in Record_Count =>
              Sizes (J) <= Max_Header + J * (68 + Max_Frame_Bytes));
      end loop;
      return Sizes;
   end Prefix_Sizes;

   function Classify
     (Item : Plan; Seen : Observation; Execution : Digest; Slot : Record_Index)
      return Decision
   is
      Result : Decision := Refused;
   begin
      if Common_Matches (Item, Seen, Execution) then
         if Unlink_Matches (Item, Seen, Slot) then
            Result := Unlink_Proposed;
         elsif Retired_Matches (Item, Seen, Slot) then
            Result := Retirement_Recorded;
         elsif Original_Absence_Matches (Item, Seen, Slot) then
            Result := Originally_Absent;
         end if;
      end if;
      return Result;
   end Classify;
end SIA_Pack_Retirement;

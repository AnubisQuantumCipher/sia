# Retained candidate history

This record describes attempts, not waivers. All source stages and raw logs remain.

- Draft runtime fixture hand calculation omitted one header byte. Before any build,
  the actual Python codec and JACKAL exact arithmetic disproved it. Original draft
  retained as test-draft-before-codec-check.adb; arithmetic-oracle.json retains
  parsed inputs, exact status and non-formal evidence class. Corrected expectations
  were then independently exercised through codec_oracle.py. No previous test pass
  was claimed for the incorrect draft.
- c1 strict build FAILED: Pure aggregate used nonstatic composite constant;
  Always_Terminates is not accepted on functions by the installed compiler.
  Literal aggregate fixed; redundant explicit function aspect removed. Function
  termination remains a GNATprove obligation, not an assumed exemption.
- c2 strict build/runtime PASS (92 controls); proof FAILED six reassociation
  warnings, no accepted proof. Parenthesized arithmetic without changed operations.
- c3 strict build/runtime PASS (92 controls); proof FAILED array-initialization
  warning, despite 65 discharged checks. Warning not suppressed or accepted.
- c4 build FAILED intentional reverse-argument test's identifier names triggered
  parameter-order warning. Renamed test operands Lower_Value/Higher_Value;
  reversed-call negative test retained. No warning option disabled.
- c5 strict build/runtime PASS (188 controls); scalar accumulation retained exact
  prefix contract; proof FAILED same array-initialization warning (68 checks).
- c6 strict build/runtime PASS (188 controls); full static array assignment retained
  exact prefix contract; proof FAILED same warning (68 checks).
- c7 strict build FAILED: loop variant and invariants require adjacent placement.
  c8 places them together. Bounded while traversal retains complete fixed array
  domain and introduces an explicit decreasing variant; no warning suppression,
  assumptions, imported helper, unchecked allocation or restricted input domain.
- Initial negative stage was prepared from c5 but NOT EXECUTED; it is not a result.

The guide describes incomplete array-initialization recognition as a sound but
imprecise tool limitation. The policy here still requires zero warnings; a useful
partial check count is insufficient. Source reference inspected October 24, 2026:
https://docs.adacore.com/spark2014-docs/html/ug/en/appendix/gnatprove_limitations.html

Inspection errors included guessed absent file names and a relative-path search
from the evidence directory; no source mutation or qualification follows from
those unsuccessful reads. Native analyzer failure was not retried.

- c8 build/runtime PASS (188 controls), proof FAILED one upper-bound check on cursor increment. No array-initialization warning. c9 preserves loop guard explicitly in the invariant; no executable change.
- Inflight comparison initially compared historical merge-output metadata as though live state. Corrected comparison verifies HEAD, status and every original dirty file hash; all match. No other-writer drift was found.

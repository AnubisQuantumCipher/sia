"""Independent existing codec checks for fixed Ada boundary fixtures."""
import hashlib
import json
from pathlib import Path
import importlib.util

SOURCE = Path('/home/sicarii/Work/sia-assurance-checkpoint-20261023')


def load_codec():
    spec = importlib.util.spec_from_file_location('siaeventpack', SOURCE / 'bin/siaeventpack.py')
    if spec is None or spec.loader is None:
        raise ValueError('codec loader unavailable')
    codec = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(codec)
    return codec


def main():
    codec = load_codec()
    records = tuple((f'{index:064x}'.encode(), b'x') for index in range(64))
    checks = {
        'magic_length': len(codec.MAGIC),
        'header': codec.header_size('a', '000'),
        'three_records': len(codec.encode('a', '000', records[:3])),
        'maximum_organ': len(codec.encode('a' * 200, '000', records)),
    }
    if checks != {'magic_length': 17, 'header': 59, 'three_records': 266,
                      'maximum_organ': 4674}:
        raise AssertionError('codec scalar fixture mismatch')
    exact = records[:-1] + ((records[-1][0], b'x' * 61062),)
    raw = codec.encode('a', '000', exact)
    if len(raw) != 65536 or codec.decode(raw, 'a', '000') != exact:
        raise AssertionError('codec frame mismatch')
    too_large = records[:-1] + ((records[-1][0], b'x' * 61063),)
    try:
        codec.encode('a', '000', too_large)
    except ValueError as error:
        if str(error) != 'event pack exceeds its byte bound':
            raise AssertionError('unexpected codec error') from error
        checks['overflow'] = str(error)
    else:
        raise AssertionError('oversized frame admitted')
    checks.update(exact_frame_bytes=len(raw), status='PASS',
                  codec_sha256=hashlib.sha256(Path(codec.__file__).read_bytes()).hexdigest())
    print(json.dumps(checks, indent=2))


if __name__ == '__main__':
    main()

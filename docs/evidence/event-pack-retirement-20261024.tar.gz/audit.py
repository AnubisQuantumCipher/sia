"""Audit the explicit focused scope; never substitute for the full proof gate."""
import hashlib
import importlib.util
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parent
REPO = Path('/home/sicarii/Work/sia-assurance-checkpoint-20261023')
STAGE = ROOT / 'stage-c9'
PROOF = STAGE / 'spark/pack-retirement-obj/gnatprove'


def load(name):
    return json.loads((ROOT / name).read_text())


def pin(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def source():
    files = load('c9-proof.result.json')['before']
    if len(files) != 9:
        raise ValueError('unexpected source roster')
    for name, expected in files.items():
        if pin(REPO / name) != expected or pin(STAGE / name) != expected:
            raise ValueError('source mismatch')
    for phase in ('build', 'runtime', 'proof'):
        result = load('c9-' + phase + '.result.json')
        if result['exit'] != 0 or not result['unchanged'] or result['before'] != files:
            raise ValueError('incomplete positive evidence')
    negative = load('negative9-runtime.result.json')
    if negative['exit'] != 1 or not negative['unchanged']:
        raise ValueError('unexpected negative outcome')
    if load('negative9-build.result.json')['exit'] != 0:
        raise ValueError('negative must compile')
    for name in files:
        if name != 'spark/src/sia_pack_retirement.ads' and \
                pin(ROOT / 'stage-negative9' / name) != files[name]:
            raise ValueError('negative changed outside declared predicate')
    if (ROOT / 'negative9-runtime.stderr').read_text().strip() != \
            'raised PROGRAM_ERROR : unexplained absence':
        raise ValueError('wrong negative refusal')
    return files


def report_checks():
    spec = importlib.util.spec_from_file_location('original_checker', REPO / 'spark/check-proof-summary.py')
    if spec is None or spec.loader is None:
        raise ValueError('checker import unavailable')
    checker = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(checker)
    lines = (PROOF / 'gnatprove.out').read_text().splitlines()
    checker.check_totals(lines)
    checker.check_details(lines)
    units = [line for line in lines if line.startswith('in unit ')]
    expected = {'pack_retirement_test_support': 0, 'pack_retirement_tests': 0,
                'sia_pack_retirement': 16, 'sia_policy': 7}
    if len(units) != len(expected):
        raise ValueError('unit scope changed')
    for line in units:
        match = checker.UNIT.fullmatch(line)
        if match is None:
            raise ValueError('invalid scope row')
        name, analyzed, available = match.groups()
        if name not in expected or int(analyzed) != expected[name] or analyzed != available:
            raise ValueError('unexpected scope')
    return units


def raw_checks():
    for name in ('sia_pack_retirement', 'sia_policy'):
        raw = json.loads((PROOF / (name + '.spark')).read_text())
        for field in ('pragma_assume', 'skip_proof', 'skip_flow_proof'):
            if raw.get(field) != []:
                raise ValueError('assumed or excluded production proof')
        for field in ('warn_error', 'flow', 'proof'):
            rows = raw.get(field)
            if not isinstance(rows, list) or len(rows) > 4096:
                raise ValueError('missing or oversized diagnostics')
            if any(row.get('severity') != 'info' for row in rows):
                raise ValueError('noninformational production diagnostic')
    if re.search(r'\b(warning|medium|high|error):', (ROOT / 'c9-proof.stderr').read_text()):
        raise ValueError('unclean proof stderr')


def main():
    files = source()
    units = report_checks()
    raw_checks()
    result = {'status': 'FOCUSED_EXACT_SOURCE_CHECKS_DISCHARGED', 'source': files,
              'units': units, 'report_sha256': pin(PROOF / 'gnatprove.out'),
              'binary_sha256': pin(STAGE / 'spark/pack-retirement-bin/pack_retirement_tests'),
              'scope': 'Conditional policy only; tests outside SPARK; original full gate OPEN',
              'negative': 'Receipt removal rejected by unchanged independent runtime expectation'}
    with (ROOT / 'integrity-audit.json').open('x') as handle:
        json.dump(result, handle, indent=2)
    print(result['status'])


if __name__ == '__main__':
    main()

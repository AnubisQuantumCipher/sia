"""Retain and reproduce the bounded exact-type repair checkpoint manifest."""
import gzip
import hashlib
import json
from pathlib import Path
import sys

BASE = Path(__file__).parent
REPO = Path('/home/sicarii/Work/sia-note-boundary-checkpoint-20261024')
DEST = REPO / 'docs/evidence/json-type-identity-20261024'
SOURCES = ('bin/siacognitivebaseline.py', 'bin/siacognitivehistory.py', 'bin/siacognitiveselect.py', 'bin/siacognitivesourcelink.py', 'bin/siaeventplan.py', 'bin/siagist.py', 'bin/sialiveloop.py', 'bin/siasourcebatch.py', 'tests/test_json_exact_type_admission.py')
GROUPS = {'json-type-identity-v1': ('profile_case.py', 'run_profile.py', 'workload-result.json', 'workload.stdout', 'workload.stderr', 'originals/siacognitivebaseline.py', 'originals/siacognitivehistory.py', 'originals/siacognitiveselect.py', 'originals/siacognitivesourcelink.py', 'originals/siaeventplan.py', 'originals/siagist.py', 'originals/sialiveloop.py', 'originals/siasourcebatch.py'), 'json-type-identity-candidate-v1': ('profile_case.py', 'run_profile.py', 'workload-result.json', 'workload.stdout', 'workload.stderr', 'static-result.json', 'static.stdout', 'static.stderr'), 'json-type-identity-final-v1': ('profile_case.py', 'run_profile.py', 'workload-result.json', 'workload.stdout', 'workload.stderr', 'candidate-static-result.json', 'candidate-static.stdout', 'baseline-static-result.json', 'baseline-static.stdout', 'SOURCE-REVIEW.txt'), 'json-type-identity-integration-v1': ('profile_case.py', 'run_profile.py', 'workload-result.json', 'workload.stdout', 'workload.stderr'), 'json-type-identity-bound-roster-v1': ('profile_case.py', 'run_profile.py', 'workload-result.json', 'workload.stdout', 'workload.stderr', 'BINDING-CORRECTION.md')}

def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def publish(path, raw, check):
    if check:
        if path.read_bytes() != raw:
            raise ValueError('evidence mismatch: ' + str(path))
    else:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(raw)


def members():
    result = [BASE / group / name for group, names in GROUPS.items() for name in names]
    result.append(Path(__file__))
    if len(result) > 256:
        raise ValueError('member capacity')
    return result


def main():
    if sys.argv[1:] not in ([], ['--check']):
        raise ValueError('unsupported arguments')
    check = bool(sys.argv[1:])
    records = []
    total = 0
    for source in members():
        raw = source.read_bytes()
        total += len(raw)
        if len(raw) > 8 * 1024 * 1024 or total > 16 * 1024 * 1024:
            raise ValueError('evidence byte capacity')
        name = str(source.relative_to(BASE)) + '.gz'
        packed = gzip.compress(raw, mtime=0)
        publish(DEST / name, packed, check)
        records.append({'path': str((DEST / name).relative_to(REPO)), 'sha256': digest(packed),
                        'original_sha256': digest(raw), 'original_bytes': len(raw)})
    data = {'schema': 'sia-json-type-identity-evidence-v1', 'status': 'TESTED_SCOPED_REPAIR_STATIC_FINDINGS_OPEN',
            'base_commit': 'd03aef4cc3efe90cbf74fa08777df3aad98b1182',
            'source_sha256': {name: digest((REPO / name).read_bytes()) for name in SOURCES},
            'members': records, 'limits': 'Original runtime caps unchanged; no release authority.'}
    publish(REPO / 'docs/JSON-TYPE-IDENTITY-20261024.json',
            (json.dumps(data, indent=2) + '\n').encode(), check)
    print(json.dumps({'check': check, 'members': len(records), 'uncompressed_bytes': total}))


if __name__ == '__main__':
    main()

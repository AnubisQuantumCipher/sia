The preceding234-test run used git ls-files for its inventory, which omitted
the new untracked regression file. Its contents were inspected separately,
but the run receipt did not bind that file at both endpoints. Preserve that
result with this limitation. This runner adds the exact untracked test path
to the before/after inventory and repeats the unchanged full affected roster.
No source, test assertion, deadline, cap or policy change is introduced.

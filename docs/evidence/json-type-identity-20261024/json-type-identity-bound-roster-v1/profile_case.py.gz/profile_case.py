"""Original affected-module regressions plus exact-type negative controls."""
import unittest

NAMES = ['tests.test_json_exact_type_admission', 'tests.test_json_size_iterative', 'tests.test_json_key_step', 'tests.test_ascii_json_budget', 'tests.test_unicode_sizing_admission', 'tests.test_json_size_fast_path', 'tests.test_cognitive_baseline', 'tests.test_cognitive_baseline_prefix', 'tests.test_cognitive_history_capture', 'tests.test_cognitive_selection', 'tests.test_cognitive_source_link_selection', 'tests.test_cognitive_source_link_policy_freeze', 'tests.test_replay_gist', 'tests.test_event_page_plan', 'tests.test_page_size_cleanup', 'tests.test_page_size_differential', 'tests.test_page_size_traversal']

if __name__ == "__main__":
    suite = unittest.defaultTestLoader.loadTestsFromNames(NAMES)
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    raise SystemExit(0 if result.wasSuccessful() else 1)

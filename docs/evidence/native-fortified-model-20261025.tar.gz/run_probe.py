"""One bounded compiler diagnostic, using the retained strict cc1 options."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path(__file__).parent
OLD = ROOT.parent / 'manager-error-mask-compiler-preparation-v2/run/result.json'
CC1 = Path('/usr/lib/gcc/aarch64-unknown-linux-gnu/16.1.1/cc1')


def digest(path):
    value = hashlib.sha256()
    with path.open('rb') as stream:
        for _ in range(4096):
            chunk = stream.read(1048576)
            if not chunk:
                return value.hexdigest()
            value.update(chunk)
    raise ValueError('identity read capacity')


def command(run):
    old = json.loads(OLD.read_text())['command']
    options = old[old.index('-march=armv8-a'):old.index('-o')]
    return ['/usr/bin/flock', '-F', '-n', '-E', '75',
            '/home/sicarii/.worldline-heavy.lock', '/usr/bin/prlimit',
            '--as=2147483648:2147483648', '--fsize=16777216:16777216',
            '--core=0:0', '--', '/usr/bin/timeout', '--kill-after=5s', '30s',
            str(CC1), '-quiet', '-nostdinc', '-D', '_FORTIFY_SOURCE=3',
            str(ROOT / 'fortified_probe.c'), '-dumpdir', str(run) + '/',
            '-dumpbase', 'fortified_probe.c', *options,
            '-o', str(run / 'fortified_probe.s')]


def main():
    run = ROOT / 'run'
    run.mkdir()
    (run / 'home').mkdir()
    (run / 'tmp').mkdir()
    inputs = [CC1, ROOT / 'fortified_probe.c', Path(__file__), OLD]
    before = {str(p): digest(p) for p in inputs}
    free = os.statvfs(ROOT).f_bavail * os.statvfs(ROOT).f_frsize
    if free < 10067108864:
        raise ValueError('reserve plus bounded diagnostic allocation')
    args = command(run)
    env = dict(PATH='/usr/bin:/bin', HOME=str(run / 'home'),
               TMPDIR=str(run / 'tmp'), LANG='C', LC_ALL='C', TZ='UTC')
    started = time.monotonic_ns()
    with (run / 'stdout').open('xb') as out, (run / 'stderr').open('xb') as err:
        result = subprocess.run(args, cwd=run, env=env, stdout=out, stderr=err,
                                timeout=40, check=False)
    after = {str(p): digest(p) for p in inputs}
    record = dict(command=args, environment=env, exit=result.returncode,
                  elapsed_ns=time.monotonic_ns() - started, free_bytes=free,
                  before=before, after=after, inputs_unchanged=before == after,
                  scope='Diagnostic only; __analyzer_eval errors expected under -Werror',
                  product_acceptance=False)
    with (run / 'result.json').open('x') as stream:
        json.dump(record, stream, indent=2)
        stream.write('\n')
    print(json.dumps(record, indent=2))


if __name__ == '__main__':
    main()

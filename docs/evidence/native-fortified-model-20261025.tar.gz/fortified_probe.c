/* Compiler diagnostic fixture only; never linked or executed as SIA. */
typedef __SIZE_TYPE__ size_t;
extern void __analyzer_eval(int);
void checked_fill(size_t amount, size_t capacity);
void ordinary_fill(size_t amount);

static unsigned char checked_target[32];
static unsigned char ordinary_target[32];
static int checked_marker;
static int ordinary_marker;

void checked_fill(size_t amount, size_t capacity)
{
    if (amount == 0U || amount > sizeof checked_target || capacity < amount)
        return;
    checked_marker = 42;
    __builtin___memset_chk(checked_target, 0, amount, capacity);
    __analyzer_eval(checked_marker == 42);
    __analyzer_eval(checked_target[0] == 0U);
}

void ordinary_fill(size_t amount)
{
    if (amount == 0U || amount > sizeof ordinary_target)
        return;
    ordinary_marker = 42;
    __builtin_memset(ordinary_target, 0, amount);
    __analyzer_eval(ordinary_marker == 42);
    __analyzer_eval(ordinary_target[0] == 0U);
}

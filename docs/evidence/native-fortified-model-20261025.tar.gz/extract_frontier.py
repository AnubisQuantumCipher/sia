"""Retain a fixed window while verifying the entire capped diagnostic."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).parent
SOURCE = ROOT.parent / 'manager-error-mask-compiler-preparation-v2/run/witness_io.c.analyzer.txt'
PIN = '05b1fef546c156fca1d0a6c40c723d4513ba77ca3035cf011af978986a7105e6'


def main():
    before = SOURCE.stat()
    digest, selected, size = hashlib.sha256(), bytearray(), 0
    with SOURCE.open('rb') as stream:
        for number in range(1, 4000001):
            line = stream.readline(1048577)
            if not line:
                break
            size += len(line)
            if len(line) > 1048576 or size > 536870912:
                raise ValueError('input capacity')
            digest.update(line)
            if 143695 <= number <= 143800:
                entry = str(number).encode() + b': ' + line
                if len(selected) + len(entry) > 2097152:
                    raise ValueError('selection capacity')
                selected.extend(entry)
        else:
            raise ValueError('line capacity')
    if digest.hexdigest() != PIN or size != 536870912 or SOURCE.stat() != before:
        raise ValueError('source identity drift')
    with (ROOT / 'fortified-frontier.txt').open('xb') as stream:
        stream.write(selected)
    record = dict(source=str(SOURCE), source_sha256=PIN, source_stat_unchanged=True,
                  first_line=143695, last_line=143800, bytes=len(selected),
                  sha256=hashlib.sha256(selected).hexdigest(),
                  extractor_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
    with (ROOT / 'fortified-frontier.json').open('x') as stream:
        json.dump(record, stream, indent=2)
        stream.write('\n')
    print(json.dumps(record, indent=2))


if __name__ == '__main__':
    main()

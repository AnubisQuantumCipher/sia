"""Bounded predecessor extraction from one pinned, incomplete diagnostic."""
from collections import deque
import hashlib
import json
from pathlib import Path
import re
import sys

ROOT = Path(__file__).parent
SOURCE = ROOT.parent / 'manager-error-mask-compiler-preparation-v2/run/witness_io.c.analyzer.txt'
PIN = '05b1fef546c156fca1d0a6c40c723d4513ba77ca3035cf011af978986a7105e6'


def retain(selected, number, line, used):
    if number in selected:
        return used
    used += len(line) + 32
    if used > 2097152:
        raise ValueError('selection growth capacity')
    selected[number] = line
    return used


def extract(pattern):
    context, selected, matches = deque(maxlen=48), {}, []
    tail, size, selected_bytes = 0, 0, 0
    digest = hashlib.sha256()
    with SOURCE.open('rb') as stream:
        for number in range(1, 4000001):
            line = stream.readline(1048577)
            if not line:
                break
            size += len(line)
            if len(line) > 1048576 or size > 536870912:
                raise ValueError('diagnostic read capacity')
            digest.update(line)
            match = pattern.search(line)
            if match is not None:
                matches.append(dict(line=number, match=match.group().decode()))
                if len(matches) > 64:
                    raise ValueError('match capacity')
                for old_number, old_line in context:
                    selected_bytes = retain(selected, old_number, old_line, selected_bytes)
                tail = 16
            if tail:
                selected_bytes = retain(selected, number, line, selected_bytes)
                tail -= 1
            context.append((number, line))
        else:
            raise ValueError('diagnostic line capacity')
    if digest.hexdigest() != PIN:
        raise ValueError('source digest mismatch')
    raw = b''.join(str(number).encode() + b': ' + line
                   for number, line in sorted(selected.items()))
    if len(raw) > 2097152:
        raise ValueError('selection capacity')
    return raw, matches


def main():
    if not 1 <= len(sys.argv[1:]) <= 12:
        raise ValueError('one to twelve node identifiers required')
    if any(not word.isascii() or not word.isdecimal() or len(word) > 7
           for word in sys.argv[1:]):
        raise ValueError('node identifier representation')
    nodes = '|'.join(sys.argv[1:]).encode()
    pattern = re.compile(rb'\b(?:created EN: (?:' + nodes
                         + rb')\b|creating edge EN: [0-9]+ -> EN: (?:'
                         + nodes + rb')\b)')
    before = SOURCE.stat()
    if before.st_size != 536870912:
        raise ValueError('source size mismatch')
    raw, matches = extract(pattern)
    if SOURCE.stat() != before:
        raise ValueError('source metadata drift')
    name = 'nodes-' + '-'.join(sys.argv[1:])
    with (ROOT / (name + '.txt')).open('xb') as stream:
        stream.write(raw)
    record = dict(source=str(SOURCE), source_sha256=PIN, nodes=sys.argv[1:],
                  matches=matches, bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest(),
                  extractor_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
    with (ROOT / (name + '.json')).open('x') as stream:
        json.dump(record, stream, indent=2)
        stream.write('\n')
    print(json.dumps(record, indent=2))


if __name__ == '__main__':
    main()

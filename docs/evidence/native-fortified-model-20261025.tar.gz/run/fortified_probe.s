	.arch armv8-a
	.file	"fortified_probe.c"
	.text
	.align	2
	.p2align 5,,15
	.global	checked_fill
	.type	checked_fill, %function
checked_fill:
.LFB0:
	.cfi_startproc
	sub	x2, x0, #1
	cmp	x2, 31
	ccmp	x0, x1, 2, ls
	bls	.L7
	ret
	.p2align 2,,3
.L7:
	stp	x29, x30, [sp, -16]!
	.cfi_def_cfa_offset 16
	.cfi_offset 29, -16
	.cfi_offset 30, -8
	mov	x3, x1
	mov	x2, x0
	adrp	x4, .LANCHOR0
	mov	w1, 0
	mov	x29, sp
	add	x0, x4, :lo12:.LANCHOR0
	bl	__memset_chk
	mov	w0, 1
	bl	__analyzer_eval
	ldp	x29, x30, [sp], 16
	.cfi_restore 30
	.cfi_restore 29
	.cfi_def_cfa_offset 0
	adrp	x4, .LANCHOR0
	ldrb	w0, [x4, #:lo12:.LANCHOR0]
	cmp	w0, 0
	cset	w0, eq
	b	__analyzer_eval
	.cfi_endproc
.LFE0:
	.size	checked_fill, .-checked_fill
	.align	2
	.p2align 5,,15
	.global	ordinary_fill
	.type	ordinary_fill, %function
ordinary_fill:
.LFB1:
	.cfi_startproc
	sub	x1, x0, #1
	cmp	x1, 31
	bls	.L13
	ret
	.p2align 2,,3
.L13:
	stp	x29, x30, [sp, -32]!
	.cfi_def_cfa_offset 32
	.cfi_offset 29, -32
	.cfi_offset 30, -24
	adrp	x3, .LANCHOR0
	add	x3, x3, :lo12:.LANCHOR0
	mov	x2, x0
	mov	x29, sp
	mov	w1, 0
	add	x0, x3, 32
	str	x3, [sp, 24]
	bl	memset
	mov	w0, 1
	bl	__analyzer_eval
	ldr	x3, [sp, 24]
	ldrb	w0, [x3, 32]
	ldp	x29, x30, [sp], 32
	.cfi_restore 30
	.cfi_restore 29
	.cfi_def_cfa_offset 0
	cmp	w0, 0
	cset	w0, eq
	b	__analyzer_eval
	.cfi_endproc
.LFE1:
	.size	ordinary_fill, .-ordinary_fill
	.bss
	.align	4
	.set	.LANCHOR0,. + 0
	.type	checked_target, %object
	.size	checked_target, 32
checked_target:
	.zero	32
	.type	ordinary_target, %object
	.size	ordinary_target, 32
ordinary_target:
	.zero	32
	.ident	"GCC: (GNU) 16.1.1 20260430"
	.section	.note.GNU-stack,"",@progbits

	.aeabi_subsection aeabi_feature_and_bits, optional, ULEB128
	.aeabi_attribute Tag_Feature_BTI, 0
	.aeabi_attribute Tag_Feature_PAC, 0
	.aeabi_attribute Tag_Feature_GCS, 0

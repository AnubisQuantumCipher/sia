"""Three existing RTS members only; reproduce, compare, never install or link."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

ROOT = Path(__file__).resolve().parent
RTS = Path('/home/sicarii/opt/gnat/gnat-aarch64-linux-16.1.0-1/lib/gcc/aarch64-linux-gnu/16.1.0')
UNITS = ('s-soflin', 's-stalib', 'a-elchha')


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def record(path, value):
    path.write_text(json.dumps(value, sort_keys=True, indent=2) + '\n')


def run(label, args, directory):
    argv = ['timeout', '--kill-after=5s', '60s', 'prlimit',
            '--as=2147483648', '--fsize=536870912', '--core=0', '--', *args]
    with (directory / (label + '.stdout')).open('wb') as out:
        with (directory / (label + '.stderr')).open('wb') as err:
            result = subprocess.run(argv, cwd=directory, stdout=out,
                                    stderr=err, check=False)
    record(directory / (label + '.json'), {'argv': argv, 'exit': result.returncode})
    if result.returncode != 0:
        raise RuntimeError('command failed: ' + label)


def inputs(unit, directory):
    ali = RTS / 'adalib' / (unit + '.ali')
    lines = ali.read_text().splitlines()
    if len(lines) > 10000:
        raise RuntimeError('ALI line budget')
    shutil.copyfile(ali, directory / 'original.ali')
    target = directory / 'inputs'
    target.mkdir()
    names = [line.split()[1] for line in lines if line.startswith('D ')]
    if len(names) > 128:
        raise RuntimeError('source count budget')
    for name in names:
        if Path(name).name != name:
            raise RuntimeError('unexpected dependency path')
        shutil.copyfile(RTS / 'adainclude' / name, target / name)
    return [line[2:] for line in lines if line.startswith('A ')], {
        name: digest(target / name) for name in names}


def reproduce(unit):
    directory = ROOT / unit
    directory.mkdir()
    flags, sources = inputs(unit, directory)
    run('extract', ['ar', 'p', str(RTS / 'adalib/libgnat.a'), unit + '.o'], directory)
    shutil.copyfile(directory / 'extract.stdout', directory / 'original.o')
    run('compile', ['gcc', '-c', *flags, '-I' + str(directory / 'inputs'),
                    str(directory / 'inputs' / (unit + '.adb')),
                    '-o', str(directory / (unit + '.o')),
                    '-fstack-usage', '-fcallgraph-info=su,da'], directory)
    for before, after in (('original.o', 'original.nodebug.o'),
                          (unit + '.o', 'rebuilt.nodebug.o')):
        run('strip-' + before, ['objcopy', '--strip-debug', before, after], directory)
    run('compare', ['cmp', 'original.nodebug.o', 'rebuilt.nodebug.o'], directory)
    result = {'unit': unit, 'sources': sources, 'flags': flags,
              'original': digest(directory / 'original.o'),
              'rebuilt': digest(directory / (unit + '.o')),
              'original_stripped': digest(directory / 'original.nodebug.o'),
              'rebuilt_stripped': digest(directory / 'rebuilt.nodebug.o')}
    record(directory / 'result.json', result)
    return result


def main():
    archive_before = digest(RTS / 'adalib/libgnat.a')
    prior = json.loads((ROOT.parent / 'rts-secondary-correspondence-v1/admission.json').read_text())
    if archive_before != prior['libgnat_sha256']:
        raise RuntimeError('runtime archive differs from linked evidence')
    tools = {}
    for name in ('gcc', 'ar', 'objcopy', 'cmp'):
        path = shutil.which(name)
        if path is None:
            raise RuntimeError('missing tool: ' + name)
        tools[name] = {'path': path, 'sha256': digest(Path(path))}
    record(ROOT / 'admission.json', {'archive_sha256': archive_before,
           'tools': tools, 'scope': 'upstream object correspondence only; -gnatp reproduces RTS, never SIA flags'})
    results = [reproduce(unit) for unit in UNITS]
    if archive_before != digest(RTS / 'adalib/libgnat.a'):
        raise RuntimeError('runtime archive endpoint changed')
    record(ROOT / 'results.json', results)


if __name__ == '__main__':
    main()

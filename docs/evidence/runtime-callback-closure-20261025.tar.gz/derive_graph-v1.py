"""Bounded inspection of declared GCC reports; not a stack or feasibility proof."""
from collections import deque
import hashlib
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parent
QUOTED = r'"(?:[^"\\]|\\.)*"'
NODE = re.compile(r'node: \{ title: (' + QUOTED + r') label: (' + QUOTED +
                  r')(?: shape : ellipse)? \}')
EDGE = re.compile(r'edge: \{ sourcename: (' + QUOTED + r') targetname: (' +
                  QUOTED + r')(?: label: (' + QUOTED + r'))? \}')
HEADER = re.compile(r'graph: \{ title: ' + QUOTED)
FRAME = re.compile(r'\n(\d+) bytes \((static|dynamic|dynamic,bounded)\)\n')


def add_node(match, nodes, report):
    name, label = (json.loads(value) for value in match.groups())
    found = FRAME.search(label)
    frame = None if found is None else {
        'bytes_reported': int(found[1]), 'qualifier': found[2]}
    node = nodes.setdefault(name, {'frame': None, 'references': []})
    if frame is not None:
        if node['frame'] is not None and node['frame'] != frame:
            raise RuntimeError('conflicting frame: ' + name)
        node['frame'] = frame
    node['references'].append({'report': report, 'label': label})


def parse_report(path, nodes, edges):
    raw = path.read_bytes()
    if len(raw) > 4194304:
        raise RuntimeError('report byte budget')
    lines = raw.decode().splitlines()
    if not lines or HEADER.fullmatch(lines[0]) is None or lines[-1] != '}':
        raise RuntimeError('report envelope')
    for line in lines[1:-1]:
        match = NODE.fullmatch(line)
        if match is not None:
            add_node(match, nodes, path.name)
        else:
            match = EDGE.fullmatch(line)
            if match is None:
                raise RuntimeError('unknown report line: ' + line[:200])
            values = [None if value is None else json.loads(value)
                      for value in match.groups()]
            edges.append({'source': values[0], 'target': values[1],
                          'report': path.name, 'site': values[2]})
        if len(nodes) > 4096 or len(edges) > 16384:
            raise RuntimeError('graph capacity')
    return hashlib.sha256(raw).hexdigest()


def traverse(root, nodes, edges):
    adjacency = {name: set() for name in nodes}
    for edge in edges:
        if edge['source'] not in nodes or edge['target'] not in nodes:
            raise RuntimeError('missing endpoint')
        adjacency[edge['source']].add(edge['target'])
    todo, predecessor = deque([root]), {root: None}
    for _ in range(4096):
        if not todo:
            break
        name = todo.popleft()
        for child in sorted(adjacency[name]):
            if child not in predecessor:
                predecessor[child] = name
                todo.append(child)
    if todo:
        raise RuntimeError('traversal budget')
    return {'syntactically_reached': len(predecessor),
            'unresolved': sorted(name for name in predecessor
                                 if nodes[name]['frame'] is None),
            'nonstatic': {name: nodes[name]['frame'] for name in predecessor
                          if nodes[name]['frame'] is not None
                          and nodes[name]['frame']['qualifier'] != 'static'},
            'predecessor': predecessor}


def main():
    inputs = json.loads((ROOT / 'reports.json').read_text())
    if not 1 <= len(inputs) <= 64:
        raise RuntimeError('report count budget')
    nodes, edges = {}, []
    for item in inputs:
        path = ROOT / 'reports' / item['name']
        if path.name != item['name']:
            raise RuntimeError('report name')
        if parse_report(path, nodes, edges) != item['sha256']:
            raise RuntimeError('report identity')
    result = {'inputs': inputs, 'nodes': nodes, 'edges': edges,
              'entrypoints': {name: traverse(name, nodes, edges)
                             for name in ('main', '_ada_continuity_probe')},
              'scope': 'direct emitted edges only; unknown indirect/C/native bodies remain; no feasibility, recursion closure or cost-sum proof'}
    (ROOT / 'graph.json').write_text(json.dumps(result, indent=2) + '\n')


if __name__ == '__main__':
    main()

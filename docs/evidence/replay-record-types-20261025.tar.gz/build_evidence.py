"""Reproduce a fixed public evidence archive without changing sealed inputs."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import sys
import tarfile

OUT = Path(__file__).parent
SOURCE = Path('/home/sicarii/Work/sia-assurance-checkpoint-20261023')
BASE = '76ee08da8dd79567c05fd1e1f33974f03c99b43f'
ARCHIVE = SOURCE / 'docs/evidence/replay-record-types-20261025.tar.gz'
RECEIPT = SOURCE / 'docs/REPLAY-RECORD-TYPES-20261025.json'
MEMBERS = (
    'run.py', 'build_evidence.py', 'sialib.py.original', 'independent-review.txt',
    'before-inputs.json', 'before-result.json', 'before.stdout', 'before.stderr',
    'candidate-inputs.json', 'candidate-result.json', 'candidate.stdout', 'candidate.stderr',
    'policy-inputs.json', 'policy-result.json', 'policy.stdout', 'policy.stderr',
    'baseline-static-result.json', 'baseline-static.stdout', 'baseline-static.stderr',
    'candidate-static-result.json', 'candidate-static.stdout', 'candidate-static.stderr',
    'tooling-static-result.json', 'tooling-static.stdout', 'tooling-static.stderr',
    'builder-static-result.json', 'builder-static.stdout', 'builder-static.stderr',
)


def read_member(path):
    with path.open('rb') as stream:
        raw = stream.read(2097153)
    if len(raw) > 2097152:
        raise ValueError('member capacity')
    return raw


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def payloads():
    if len(MEMBERS) > 64:
        raise ValueError('roster capacity')
    members = {name: read_member(OUT / name) for name in MEMBERS}
    for name in ('bin/sialib.py', 'tests/test_event_replay_record_types.py'):
        members['source/' + name] = read_member(SOURCE / name)
    for mode, expected in (('before', 1), ('candidate', 0), ('policy', 1)):
        result = json.loads(members[mode + '-result.json'])
        if result['exit'] != expected or result['before'] != result['after']:
            raise ValueError('run receipt does not meet declared scope')
        for path, pin in result['output_hashes'].items():
            if digest(members[Path(path).name]) != pin:
                raise ValueError('output mismatch')
    candidate = json.loads(members['candidate-result.json'])
    for name in ('bin/sialib.py', 'tests/test_event_replay_record_types.py'):
        if digest(members['source/' + name]) != candidate['after'][str(SOURCE / name)]:
            raise ValueError('candidate source mismatch')
    if json.loads(members['baseline-static.stdout']) != json.loads(members['candidate-static.stdout']):
        raise ValueError('static diagnostic drift')
    return members


def archive_bytes(members):
    stream = io.BytesIO()
    with tarfile.open(fileobj=stream, mode='w', format=tarfile.USTAR_FORMAT) as archive:
        for name, raw in sorted(members.items()):
            info = tarfile.TarInfo(name)
            info.size, info.mode, info.mtime = len(raw), 0o644, 0
            archive.addfile(info, io.BytesIO(raw))
    return gzip.compress(stream.getvalue(), mtime=0)


def main():
    if len(sys.argv) != 2 or sys.argv[1] not in ('--write', '--check'):
        raise ValueError('explicit write/check required')
    members = payloads()
    packed = archive_bytes(members)
    result = {
        'status': 'TESTED_SCOPED_REPAIR_FULL_ASSURANCE_INCOMPLETE', 'base_commit': BASE,
        'scope': 'Invalid replay links/tags refuse before set/sort; no reuse or performance claim.',
        'archive': str(ARCHIVE.relative_to(SOURCE)), 'archive_sha256': digest(packed),
        'members': {name: digest(raw) for name, raw in sorted(members.items())},
        'results': {
            'baseline': '6 tests; 4 failures and 14 errors; exit1',
            'candidate': '65 PASS in9.107s; exit0',
            'policy': '16 tests in51.260s; exit1, sole original R05 reuse failure',
            'static': 'Full sialib baseline and candidate: identical154 findings, exit1; no waiver.',
            'tooling_static': 'Test, runner and builder: frozen167-rule profile exit0.',
        },
        'review': 'Actual GPT-6.1 source/raw review; no independent execution.',
        'remaining': 'R05 BOTH, original full workload/native/SPARK/SDK/compaction/recovery/installed/release gates remain open.',
        'limits': 'Endpoint pins are not loaded-code custody; Python subclasses, callbacks and runtime are not formally verified.',
    }
    encoded = (json.dumps(result, indent=2, sort_keys=True) + '\n').encode()
    if sys.argv[1] == '--write':
        with ARCHIVE.open('xb') as stream:
            stream.write(packed)
        with RECEIPT.open('xb') as stream:
            stream.write(encoded)
    elif ARCHIVE.read_bytes() != packed or RECEIPT.read_bytes() != encoded:
        raise ValueError('reproduction mismatch')
    print(json.dumps({'archive_sha256': result['archive_sha256'], 'members': len(members)}))


if __name__ == '__main__':
    main()

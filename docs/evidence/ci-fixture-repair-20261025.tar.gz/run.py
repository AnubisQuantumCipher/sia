"""Verify the reviewed fixture repair in the existing isolated execution route."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import time

OUT = Path(__file__).resolve().parent
SOURCE = Path('/home/sicarii/Work/sia-assurance-checkpoint-20261023')
ROSTER = [
    'tests.test_release.ReleaseContract.test_ci_discovers_the_tests_directory_and_promotes_resource_leaks',
    'tests.test_release.ReleaseContract.test_ci_shell_syntax_checks_every_script_without_execution',
    'tests.test_release.ReleaseContract.test_facade_child_modules_export_their_pinned_functions',
    'tests.test_release.ReleaseContract.test_facade_child_modules_hold_their_bind_invariants',
    'tests.test_event_index_delta.IndexDelta.test_handoff_close_error_cleans_every_registered_capture',
    'tests.test_event_index_delta.IndexDelta.test_original_page_publication_handoff_closes_every_capture',
    'tests.test_event_index_delta.IndexDelta.test_close_attempts_all_owned_descriptors_once_despite_multiple_errors',
    'tests.test_event_index_delta.IndexDelta.test_close_error_does_not_retry_a_reused_descriptor_number',
    'tests.test_event_pack_replay.PackedEventReplay.test_exhausted_capture_budget_refuses_before_reread_or_decode',
    'tests.test_sia.ProcessWideOsPatches.test_no_unlisted_process_wide_os_patch',
    'tests.test_sia.ProcessWideOsPatches.test_accepted_sites_all_still_exist',
]


def git(*args):
    return subprocess.check_output(['/usr/bin/git', '-C', str(SOURCE), *args])


def hashes(paths):
    result = {}
    for path in sorted(paths):
        with path.open('rb') as stream:
            result[str(path)] = hashlib.file_digest(stream, 'sha256').hexdigest()
    return result


def prepare():
    receipt_path = OUT.parent / 'r05-fresh-delivery-capture-v1/workload-result.json'
    receipt = json.loads(receipt_path.read_text())
    command = list(receipt['command'])
    old = '/home/sicarii/Work/sia-note-boundary-checkpoint-20261024'
    if command.count(old) != 1:
        raise ValueError('original isolated source mount changed')
    command[command.index(old)] = str(SOURCE)
    for option in ('--as=2147483648:2147483648', '--fsize=536870912:536870912'):
        if command.count(option) != 1:
            raise ValueError('original engineering cap changed')
        command.remove(option)
    index = command.index('/usr/bin/timeout')
    if command[index:index + 3] != ['/usr/bin/timeout', '--kill-after=5s', '60s']:
        raise ValueError('original timeout envelope changed')
    del command[index:index + 3]
    prefix, suffix = command[-1].split('loadTestsFromNames(', 1)
    _old_roster, ending = suffix.split('); result=', 1)
    command[-1] = prefix + 'loadTestsFromNames(' + repr(ROSTER) + '); result=' + ending
    tracked = git('ls-files', '-z', '--', 'bin', 'tests', 'scripts', 'VERSION',
                  'install.sh', 'uninstall.sh', 'systemd', 'Cockpit.qml', 'Model.js',
                  'README.md', 'SECURITY.md', 'docs/MANUAL.md',
                  '.github/workflows/ci.yml', 'spark/check-event-pack-model.sh')
    paths = {SOURCE / name.decode() for name in tracked.split(b'\0') if name}
    paths.update({OUT / 'run.py', OUT / 'candidate.json', receipt_path})
    paths.update(Path(name) for name in command if name.startswith('/usr/bin/'))
    paths.add(Path('/home/sicarii/Documents/sia-repository-audit-20261024/git-review-executable'))
    return command, receipt['environment'], paths


def main():
    candidate = json.loads((OUT / 'candidate.json').read_text())
    if git('rev-parse', 'HEAD').decode().strip() != candidate['head']:
        raise ValueError('source head changed')
    if git('write-tree').decode().strip() != candidate['tree'] or git('diff', '--name-only'):
        raise ValueError('candidate composition changed')
    if shutil.disk_usage(OUT).free < 10_000_000_000:
        raise ValueError('physical workspace reserve unavailable')
    command, environment, paths = prepare()
    record = dict(command=command, environment=environment, before=hashes(paths),
                  source_head=candidate['head'], source_tree=candidate['tree'],
                  scope='Endpoint pins, not loaded-code custody', roster=ROSTER,
                  policy='Human removed engineering time/memory/file caps; isolation, heavy lock, core0 and product test bounds retained')
    with (OUT / 'inputs.json').open('x') as stream:
        json.dump(record, stream, indent=2)
        stream.write('\n')
    started = time.monotonic_ns()
    with (OUT / 'tests.stdout').open('xb') as stdout, (OUT / 'tests.stderr').open('xb') as stderr:
        completed = subprocess.run(command, env=environment, stdout=stdout,
                                   stderr=stderr, check=False)
    record.update(after=hashes(paths), exit=completed.returncode,
                  elapsed_ns=time.monotonic_ns() - started,
                  output_hashes=hashes({OUT / 'tests.stdout', OUT / 'tests.stderr'}))
    record['unchanged'] = record['before'] == record['after']
    with (OUT / 'result.json').open('x') as stream:
        json.dump(record, stream, indent=2)
        stream.write('\n')
    print(json.dumps({key:record[key] for key in ('unchanged', 'exit', 'elapsed_ns')}))
    if not record['unchanged'] or completed.returncode:
        raise SystemExit(1)


if __name__ == '__main__':
    main()

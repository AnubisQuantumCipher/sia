"""Snapshot-binding regressions; no publication or live evidence mutation."""
import json
from pathlib import Path
import unittest
from unittest import mock

import build_public as builder


class SnapshotBinding(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        omitted = {'RESULT-REVIEW.json', 'builder-tests.json'}
        cls.members = {name: (builder.OUT / name).read_bytes()
                       for name in builder.FILES if name not in omitted}
        ci = builder.OUT.parent / 'hosted-ci-terminal-20261025-v1'
        cls.members.update({'previous-ci/' + name: (ci / name).read_bytes()
                            for name in builder.CI_FILES})

    def changed(self, name, key, value):
        members = dict(self.members)
        document = json.loads(members[name])
        document[key] = value
        members[name] = json.dumps(document).encode()
        return members

    def test_original_snapshot_validates_without_disk_reads(self):
        with mock.patch.object(Path, 'read_bytes', side_effect=AssertionError('reread')):
            with mock.patch.object(Path, 'read_text', side_effect=AssertionError('reread')):
                result, footer = builder.validate_evidence(self.members)
        self.assertEqual(result['exit'], 0)
        self.assertEqual(int(footer[1]), len(result['roster']))

    def test_substituted_payloads_are_rejected(self):
        for name in ('tests.stdout', 'tests.stderr', 'candidate.patch', 'run.py',
                     'previous-ci/121203087207.raw.log',
                     'previous-ci/121241832738.raw.log'):
            with self.subTest(name=name):
                members = dict(self.members)
                members[name] = b'changed\n' + members[name]
                with self.assertRaises(ValueError):
                    builder.validate_evidence(members)

    def test_changed_input_and_source_bindings_are_rejected(self):
        cases = (('inputs.json', 'command', []),
                 ('candidate.json', 'head', 'changed'),
                 ('candidate.json', 'tree', 'changed'),
                 ('REVIEW.json', 'patch_sha256', 'changed'),
                 ('previous-ci/REVIEW.json', 'source_head', 'changed'))
        for name, key, value in cases:
            with self.subTest(name=name, key=key):
                with self.assertRaises(ValueError):
                    builder.validate_evidence(self.changed(name, key, value))

    def test_static_failure_and_stale_pins_are_rejected(self):
        for name in ('static.json', 'builder-static.json'):
            for key, value in (('exit', 1), ('stdout', '[{}]'),
                               ('stderr', 'warning'), ('source', {})):
                with self.subTest(name=name, key=key):
                    with self.assertRaises(ValueError):
                        builder.validate_evidence(self.changed(name, key, value))

    def test_review_is_required_before_report(self):
        with self.assertRaises(KeyError):
            builder.report(builder.archive(self.members), self.members)

    def test_archive_is_reproducible_for_captured_bytes(self):
        self.assertEqual(builder.archive(self.members), builder.archive(self.members))


if __name__ == '__main__':
    unittest.main(verbosity=2)

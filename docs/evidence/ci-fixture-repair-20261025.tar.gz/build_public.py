"""Publish reproducible evidence only after the exact regression roster passes."""
import argparse
import ast
import gzip
import hashlib
import io
import json
from pathlib import Path
import re
import tarfile

OUT = Path(__file__).resolve().parent
REPO = Path('/home/sicarii/Work/sia-assurance-checkpoint-20261023')
FILES = ('run.py', 'candidate.json', 'candidate.patch', 'static.json',
         'REVIEW.json', 'inputs.json', 'result.json', 'tests.stdout',
         'tests.stderr', 'build_public.py', 'RESULT-REVIEW.json', 'builder-static.json',
         'test_build_public.py', 'builder-tests.json')
CI_FILES = ('REVIEW.json', 'raw-readback.json', '121203087207.raw.log',
            '121241832738.raw.log')


def payloads():
    members = {name: (OUT / name).read_bytes() for name in FILES}
    ci = OUT.parent / 'hosted-ci-terminal-20261025-v1'
    members.update({'previous-ci/' + name: (ci / name).read_bytes() for name in CI_FILES})
    pins = {name: digest(raw) for name, raw in members.items()}
    members['SHA256.json'] = (json.dumps(pins, indent=2, sort_keys=True) + '\n').encode()
    return members


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def document(members, name):
    return json.loads(members[name])


def require(condition, message):
    if not condition:
        raise ValueError(message)


def validate_execution(members):
    result = document(members, 'result.json')
    inputs = document(members, 'inputs.json')
    completion = {'after', 'exit', 'elapsed_ns', 'output_hashes', 'unchanged'}
    require(inputs == {k: v for k, v in result.items() if k not in completion},
            'execution input/result mismatch')
    require(result['exit'] == 0 and result['unchanged'] is True
            and result['before'] == result['after'], 'failed execution or endpoint drift')
    outputs = {str(OUT / name): digest(members[name])
               for name in ('tests.stdout', 'tests.stderr')}
    require(result['output_hashes'] == outputs, 'execution output digest mismatch')
    for name in ('run.py', 'candidate.json'):
        require(result['before'][str(OUT / name)] == digest(members[name]),
                'execution source mismatch: ' + name)
    runner = ast.parse(members['run.py'])
    rosters = [ast.literal_eval(node.value) for node in runner.body
               if isinstance(node, ast.Assign) and any(
                   isinstance(target, ast.Name) and target.id == 'ROSTER'
                   for target in node.targets)]
    require(rosters == [result['roster']], 'runner/result roster mismatch')
    stderr = members['tests.stderr'].decode()
    footer = re.search(r'\nRan (\d+) tests in ([\d.]+)s\n\nOK\n\Z', stderr)
    require(footer is not None and int(footer[1]) == len(result['roster']),
            'complete original regression footer missing')
    names = re.findall(r'^(\w+) \(([^)]+)\) \.\.\. ok$', stderr, re.MULTILINE)
    require([owner if owner.endswith('.' + name) else owner + '.' + name
             for name, owner in names] == result['roster'], 'ordered test names mismatch')
    return result, footer


def validate_candidate(members, result):
    candidate = document(members, 'candidate.json')
    review = document(members, 'REVIEW.json')
    require(candidate['head'] == result['source_head']
            and candidate['tree'] == result['source_tree'], 'candidate source mismatch')
    require(candidate['patch_sha256'] == digest(members['candidate.patch'])
            == review['patch_sha256'], 'candidate patch mismatch')
    require(review['status'] == 'NO_BLOCKING_SOURCE_DEFECT_FOUND'
            and review['model'] == 'gpt-6.1-sol', 'source review missing')
    static = document(members, 'static.json')
    require(static['exit'] == 0 and json.loads(static['stdout']) == []
            and static['stderr'] == '', 'selected static checks failed')
    paths = {str(REPO / name) for name in candidate['paths']} | {str(OUT / 'run.py')}
    require(set(static['source']) == paths, 'static source roster mismatch')
    require(all(value == result['before'][name] for name, value in static['source'].items()),
            'static source digest mismatch')
    builder = document(members, 'builder-static.json')
    require(builder['exit'] == 0 and json.loads(builder['stdout']) == []
            and builder['stderr'] == '' and builder['functions_over_60'] == [],
            'builder static checks failed')
    require(builder['source'] == {str(OUT / name): digest(members[name])
                                 for name in ('build_public.py', 'test_build_public.py')},
            'builder static source mismatch')


def validate_previous_ci(members, result):
    ci = document(members, 'previous-ci/raw-readback.json')
    review = document(members, 'previous-ci/REVIEW.json')
    require(review['source_head'] == result['source_head'], 'prior CI source mismatch')
    require({row['job'] for row in ci['records']}
            == {row['job'] for row in review['runs'].values()}
            and len(ci['records']) == len(CI_FILES) - 2, 'prior CI job roster mismatch')
    for row in ci['records']:
        raw = members['previous-ci/' + row['job'] + '.raw.log']
        require(row['exit'] == 0 and row['stderr_bytes'] == 0
                and row['bytes'] == len(raw) and row['sha256'] == digest(raw),
                'prior CI log binding mismatch')


def validate_evidence(members):
    result, footer = validate_execution(members)
    validate_candidate(members, result)
    validate_previous_ci(members, result)
    return result, footer


def validate_review(members):
    review = document(members, 'RESULT-REVIEW.json')
    reviewed = {name: digest(raw) for name, raw in members.items()
                if name not in ('RESULT-REVIEW.json', 'SHA256.json')}
    require(review['status'] == 'SELECTED_11_METHODS_PASS'
            and review['model'] == 'gpt-6.1-sol'
            and review['payload_sha256'] == reviewed, 'reviewed payload mismatch')
    require(review['result_sha256'] == digest(members['result.json']),
            'source-bound result review missing')
    tests = document(members, 'builder-tests.json')
    require(tests['exit'] == 0 and tests['status'] == 'PASS'
            and tests['source'] == {name: digest(members[name])
                                    for name in ('build_public.py', 'test_build_public.py')},
            'builder regression missing or stale')


def archive(members):
    target = io.BytesIO()
    with gzip.GzipFile(fileobj=target, mode='wb', filename='', mtime=0) as zipped:
        with tarfile.open(fileobj=zipped, mode='w', format=tarfile.USTAR_FORMAT) as tar:
            for name, raw in sorted(members.items()):
                entry = tarfile.TarInfo(name)
                entry.size, entry.mode = len(raw), 0o644
                tar.addfile(entry, io.BytesIO(raw))
    return target.getvalue()


def report(raw, members):
    result, footer = validate_evidence(members)
    validate_review(members)
    return dict(status='SELECTED_FIXTURE_REPAIR_PASS_FULL_ASSURANCE_INCOMPLETE',
                base_commit=result['source_head'], tested_tree=result['source_tree'],
                scope='Exact test and executable tree before evidence-only additions',
                tests=dict(count=int(footer[1]), seconds=footer[2], skips=0, exit=0),
                endpoint_pins=dict(count=len(result['before']), unchanged=True,
                                   limit='Endpoint correspondence, not continuous loaded-code custody'),
                static='Selected frozen 167-rule profile: zero findings',
                archive=dict(path='docs/evidence/ci-fixture-repair-20261025.tar.gz',
                             sha256=hashlib.sha256(raw).hexdigest(), bytes=len(raw),
                             members=len(members), reproduced=True),
                prior_ci='Both original exact25d706b suites failed5 with4439 tests and34 skips; full raw logs retained in archive',
                review='Actual GPT-6.1 source and retained-evidence review; no independent execution',
                remaining='R05 BOTH, fresh full-suite CI, all original A/G/C/P/R/EP obligations, full proofs, custody, SDK, compaction, recovery, retrieval, judge, installed qualification and release/marketplace')


def write_or_check(path, raw, check):
    if check:
        if path.read_bytes() != raw:
            raise ValueError('published evidence differs: ' + str(path))
    else:
        with path.open('xb') as stream:
            stream.write(raw)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--check', action='store_true')
    args = parser.parse_args()
    members = payloads()
    raw = archive(members)
    if raw != archive(members):
        raise ValueError('archive not reproducible')
    value = report(raw, members)
    write_or_check(REPO / value['archive']['path'], raw, args.check)
    report_path = REPO / 'docs/CI-FIXTURE-REPAIR-20261025.json'
    write_or_check(report_path, (json.dumps(value, indent=2, sort_keys=True) + '\n').encode(), args.check)
    print(json.dumps(value, indent=2))


if __name__ == '__main__':
    main()

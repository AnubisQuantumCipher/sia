"""Fixed, read-only postcondition check; no recovery or dispatch actions."""
import hashlib
import json
import os
from pathlib import Path
import stat

ROOT = Path(__file__).resolve().parent
LEDGER = Path('/var/tmp/sia-ordinary-recovery-20261026-v1')
MANIFEST = '27dfb8d87c9381a5e5768149b8168e85348d6b000a327afe94e89bd95f196d28'
FIELDS = ('st_dev', 'st_ino', 'st_mode', 'st_uid', 'st_gid', 'st_nlink')


def main():
    if os.getresuid() != (0, 0, 0):
        raise ValueError('fixed root readback required')
    expected = json.loads((ROOT / 'decision.json').read_text())
    names = {'epoch', 'decision-' + MANIFEST + '.json', 'retired-' + MANIFEST + '.json'}
    if {p.name for p in LEDGER.iterdir()} != names:
        raise ValueError('unexpected ledger roster')
    rows = {}
    for name in sorted(names):
        path = LEDGER / name
        meta = path.lstat()
        if not stat.S_ISREG(meta.st_mode) or meta.st_uid != 0 or meta.st_nlink != 1 \
                or meta.st_size > 65536:
            raise ValueError('unexpected ledger file metadata')
        with path.open('rb') as stream:
            data = stream.read(65537)
        if len(data) != meta.st_size:
            raise ValueError('ledger file changed during readback')
        rows[name] = dict(sha256=hashlib.sha256(data).hexdigest(), bytes=len(data),
                          identity=[getattr(meta, field) for field in FIELDS])
        if name.startswith('retired-') and rows[name]['sha256'] != expected['pending_sha256']:
            raise ValueError('retired content mismatch')
        if name.startswith('decision-') and json.loads(data) != expected:
            raise ValueError('retirement decision mismatch')
    directory = LEDGER.lstat()
    print(json.dumps(dict(status='EXACT_RETIRED_FIXTURE_READBACK', authority='NONE',
                          directory=[getattr(directory, field) for field in FIELDS],
                          rows=rows, pending_absent=True)), flush=True)


if __name__ == '__main__':
    main()

"""Source-bound audit of one explicit manual reconciliation, not custody proof."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent / 'ordinary-manual-reconciliation-20261026-v1'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(name):
    return json.loads((ROOT / name).read_text())


def check(condition, message):
    if not condition:
        raise ValueError(message)


def main():
    source = read('source.json')
    for name, expected in source.items():
        check(sha(ROOT / name) == expected, 'source changed: ' + name)
    tests = read('TEST-RESULT.json')
    for name, expected in tests['source'].items():
        check(sha(ROOT / name) == expected, 'test source changed: ' + name)
    raw = (ROOT / 'tests.stderr').read_text()
    check(tests['status'] == 'PASS' and tests['tests'] == 21 and
          tests['failures'] == tests['errors'] == tests['skipped'] == 0, 'tests not passed')
    check(raw.count(' ... ok\n') == 21 and raw.endswith('Ran 21 tests in 0.082s\n\nOK\n'), 'raw tests')
    outer, result, post = read('outer-result.json'), read('outer.stdout'), read('readback.stdout')
    check(outer['actual_exit'] == 0 and outer['manifest_sha256'] == sha(ROOT / 'source.json')
          and outer['stdout_sha256'] == sha(ROOT / 'outer.stdout'), 'actual exit or binding')
    check(result['status'] == 'EXACT_NORMAL_FIXTURE_RECONCILED' and
          result['successor_admitted'] is False and result['replay_authorized'] is False, 'result scope')
    check(post['status'] == 'EXACT_RETIRED_FIXTURE_READBACK' and post['pending_absent'] is True,
          'postcondition readback')
    config = json.loads((ROOT.parent / 'ordinary-recovery-latch-integration-20261026-v1/config.json').read_text())
    check(post['directory'] == config['recovery_ledger']['identity'], 'ledger identity')
    check(post['rows']['epoch']['sha256'] == config['recovery_ledger']['epoch_sha256'], 'epoch changed')
    retired = post['rows'][result['retired_name']]
    check(retired['sha256'] == read('decision.json')['pending_sha256'] and
          retired['sha256'] == result['pending_sha256'] and retired['bytes'] == 757 and
          retired['identity'][2:] == [33152, 0, 0, 1], 'retired binding')
    check(post['rows'][result['decision_name']]['identity'][2:] == [33152, 0, 0, 1], 'decision metadata')
    for name in ('STATIC-v2.json', 'INVOKER-STATIC.json', 'READBACK-STATIC.json'):
        static = read(name)
        check(static['exit'] == 0 and json.loads(static['stdout']) == [] and
              not static['stderr'] and not static['functions_over_60'], 'static checks')
    record = dict(status='EXACT_NORMAL_FIXTURE_RECONCILIATION_PASS', authority='NONE',
                  source_manifest=sha(ROOT / 'source.json'), component_tests=21,
                  evidence_sha256={p.name: sha(p) for p in sorted(ROOT.iterdir()) if p.is_file()},
                  limits=['One manual known-normal fixture only; no replay or successor authorization',
                          'No actual observer-death injection or hardware crash durability test',
                          'Ordinary root/host assumptions; unsigned tool readback is not platform authority',
                          'C14, R05 BOTH, native continuity, Astra judge, installed/release acceptance remain open'])
    with (ROOT / 'OWNER-AUDIT.json').open('x') as stream:
        json.dump(record, stream, indent=2, sort_keys=True)
        stream.write('\n')
    print(json.dumps(dict(status=record['status'], source=record['source_manifest'])))


if __name__ == '__main__':
    main()

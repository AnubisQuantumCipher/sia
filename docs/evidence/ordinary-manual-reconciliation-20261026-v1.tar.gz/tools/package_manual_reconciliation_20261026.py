"""Reproduce one manual reconciliation record without executing archived source."""
import argparse
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

BASE = Path(__file__).resolve().parent
ROOT = BASE / 'ordinary-manual-reconciliation-package-20261026-v1'
ARCHIVE = 'ordinary-manual-reconciliation-20261026-v1.tar.gz'
RUN = BASE / 'ordinary-manual-reconciliation-20261026-v1'
NAMES = ('AUDITOR-STATIC.json', 'EXECUTION-DECISION.json', 'INVOKER-STATIC.json', 'OWNER-AUDIT.json', 'PRE-EXECUTION-REVIEW.json', 'READBACK-STATIC.json', 'RESULT-INDEPENDENT-REVIEW.json', 'STATIC-v1.json', 'STATIC-v2.json', 'TEST-EXECUTION-DECISION.json', 'TEST-RESULT.json', 'TEST-TOOL-OBSERVATION.json', 'TOOL-EXIT-OBSERVATION.json', 'candidate.py', 'decision.json', 'invoke.py', 'outer-result.json', 'outer.stdout', 'readback.py', 'readback.stdout', 'reconcile.py', 'run_tests.py', 'source.json', 'test_reconcile.py', 'tests.stderr')


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def add(files, prefix, directory, names):
    for name in names:
        key = prefix + '/' + name
        if key in files:
            raise ValueError('duplicate member')
        files[key] = directory / name


def roster():
    files = {}
    add(files, 'run', RUN, NAMES)
    add(files, 'unrun-v1', RUN / 'unrun-v1',
        ('reconcile.py', 'test_reconcile.py', 'STATIC-v1.json', 'STATUS.json'))
    add(files, 'tools', BASE, ('audit_manual_reconciliation_20261026.py', Path(__file__).name))
    return files


def verify():
    audit = json.loads((RUN / 'OWNER-AUDIT.json').read_text())
    for name, expected in audit['evidence_sha256'].items():
        if sha(RUN / name) != expected:
            raise ValueError('audited evidence changed: ' + name)
    review = json.loads((RUN / 'RESULT-INDEPENDENT-REVIEW.json').read_text())
    if review['audit_sha256'] != sha(RUN / 'OWNER-AUDIT.json'):
        raise ValueError('review binding changed')
    for name, expected in json.loads((RUN / 'source.json').read_text()).items():
        if sha(RUN / name) != expected:
            raise ValueError('execution source changed: ' + name)


def members(files):
    if not 1 <= len(files) <= 160:
        raise ValueError('member count')
    result, total = {}, 0
    for name, path in sorted(files.items()):
        size = path.stat().st_size
        if path.is_symlink() or not path.is_file() or size > 1048576:
            raise ValueError('invalid member: ' + name)
        total += size
        if total > 8388608:
            raise ValueError('archive input limit')
        result[name] = dict(sha256=sha(path), bytes=size)
    return result


def encoded_archive(files, rows):
    output = io.BytesIO()
    with gzip.GzipFile(fileobj=output, mode='wb', filename='', mtime=0) as zipped:
        with tarfile.open(fileobj=zipped, mode='w', format=tarfile.USTAR_FORMAT) as archive:
            for name, path in sorted(files.items()):
                with path.open('rb') as stream:
                    data = stream.read(1048577)
                if len(data) != rows[name]['bytes'] or hashlib.sha256(data).hexdigest() != rows[name]['sha256']:
                    raise ValueError('input changed during packaging')
                info = tarfile.TarInfo(name)
                info.size, info.mode, info.mtime = len(data), 0o444, 0
                archive.addfile(info, io.BytesIO(data))
    return output.getvalue()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--check', action='store_true')
    args = parser.parse_args()
    verify()
    files = roster()
    rows = members(files)
    data = encoded_archive(files, rows)
    record = dict(status='EXACT_NORMAL_FIXTURE_RECONCILIATION_PASS', authority='NONE',
        carrier_head='fa78271acec7f9aea6dac6fe7043a53d129cc06b', members=rows,
        archive=dict(path='docs/evidence/' + ARCHIVE, sha256=hashlib.sha256(data).hexdigest(), bytes=len(data)),
        result=json.loads((RUN / 'OWNER-AUDIT.json').read_text()),
        prerequisite_checkpoint='fa78271acec7f9aea6dac6fe7043a53d129cc06b',
        limitations=['One exact known-normal fixture only; no automatic reconciliation, replay or successor.',
            'Pending archived with matching bytes; original unresolved status requires its separate decision.',
            'No observer-death cut, hardware crash test, whole-job custody or C14 acceptance.',
            'Ordinary nonhostile root and host assumptions; unsigned tool observations.',
            'Original source snapshots and normal raw evidence remain bound in prerequisite checkpoint.',
            'No installed product, service, firewall, provider, release or marketplace change.'])
    encoded = (json.dumps(record, indent=2, sort_keys=True) + '\n').encode()
    if args.check:
        if (ROOT / ARCHIVE).read_bytes() != data or (ROOT / 'manifest.json').read_bytes() != encoded:
            raise ValueError('byte reproduction mismatch')
    else:
        ROOT.mkdir(mode=0o700)
        for name, value in ((ARCHIVE, data), ('manifest.json', encoded)):
            with (ROOT / name).open('xb') as stream:
                if stream.write(value) != len(value):
                    raise OSError('short package write')
    print(json.dumps(dict(status='PACKAGE_CHECK_PASS' if args.check else 'PACKAGE_CREATED',
                         archive=record['archive'], members=len(rows))))


if __name__ == '__main__':
    main()

"""One source-bound, ordinary nonhostile proof. No protected-product authority."""
from contextlib import ExitStack
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import signal
import stat
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
LEDGER = Path('/var/tmp/sia-ordinary-recovery-20261026-v1')
LEDGER_FIELDS = ('st_dev', 'st_ino', 'st_mode', 'st_uid', 'st_gid', 'st_nlink')


def metadata(value):
    return [getattr(value, key) for key in LEDGER_FIELDS]


def ledger_ancestry():
    # Fixed host path only. /var/tmp is sticky; the leaf is separately pinned.
    for path in (Path('/'), Path('/var'), Path('/var/tmp')):
        value = path.lstat()
        if not stat.S_ISDIR(value.st_mode) or value.st_uid != 0:
            raise ValueError('recovery ledger ancestry')
        mode = stat.S_IMODE(value.st_mode)
        if path == Path('/var/tmp'):
            if mode != 0o1777:
                raise ValueError('recovery parent must be root-owned sticky directory')
        elif mode & 0o022:
            raise ValueError('writable recovery ancestry')


def ledger_identity(descriptor, expected):
    opened = os.fstat(descriptor)
    if metadata(opened) != expected or metadata(LEDGER.lstat()) != expected \
            or not stat.S_ISDIR(opened.st_mode) or opened.st_uid != os.geteuid() \
            or stat.S_IMODE(opened.st_mode) != 0o700:
        raise ValueError('recovery ledger identity changed')


def read_epoch(descriptor, expected):
    epoch = os.open('epoch', os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC,
                    dir_fd=descriptor)
    errors = []
    try:
        value = os.fstat(epoch)
        if not stat.S_ISREG(value.st_mode) or value.st_uid != os.geteuid() \
                or value.st_nlink != 1 or stat.S_IMODE(value.st_mode) != 0o444:
            raise ValueError('recovery epoch identity')
        data = os.read(epoch, 66)
        if len(data) != 65 or data[-1:] != b'\n' \
                or any(c not in b'0123456789abcdef' for c in data[:-1]) \
                or hashlib.sha256(data).hexdigest() != expected:
            raise ValueError('recovery epoch binding')
    except (OSError, ValueError) as error:
        errors.append(receipt_error('read-epoch', error))
    finally:
        close_receipt(epoch, 'epoch', errors)
    if errors:
        raise ValueError(json.dumps(dict(epoch_errors=errors)))


def pending_intent(manifest, config, binding, lock):
    hashes = dict(manifest=manifest, machine=config['machine_id_sha256'],
                  boot=config['boot_id_sha256'], epoch=config['recovery_ledger']['epoch_sha256'])
    for value in hashes.values():
        if type(value) is not str or len(value) != 64 \
                or any(c not in '0123456789abcdef' for c in value):
            raise ValueError('recovery intent digest')
    if type(binding['head']) is not str or len(binding['head']) != 40 \
            or any(c not in '0123456789abcdef' for c in binding['head']):
        raise ValueError('recovery source revision')
    return dict(schema=1, status='UNRESOLVED_DO_NOT_RETRY', authority='NONE',
                bindings=hashes, source_head=binding['head'], lock_identity=metadata(lock),
                output_identity=metadata(ROOT.lstat()),
                output_path_sha256=hashlib.sha256(os.fsencode(ROOT)).hexdigest())


def reserve_pending(config, binding, lock, manifest):
    """Refusal-only latch; there is deliberately no retirement/retry API.

    Called under the original heavy lock before Popen. A prior pending file,
    even empty or apparently complete, always refuses. All candidate invocations
    share LEDGER. Old wrappers are outside this guarantee. Root deletion, media
    rollback and a complete successor reconciliation protocol are not qualified.
    """
    intent = pending_intent(manifest, config, binding, lock)
    expected = config['recovery_ledger']['identity']
    directory = descriptor = None
    errors = []
    stage = 'check-ancestry'
    try:
        ledger_ancestry()
        stage = 'open-ledger'
        directory = os.open(LEDGER, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC)
        stage = 'check-ledger'
        ledger_identity(directory, expected)
        stage = 'check-epoch'
        read_epoch(directory, config['recovery_ledger']['epoch_sha256'])
        stage = 'create-pending'
        descriptor = os.open('pending.json', os.O_WRONLY | os.O_CREAT | os.O_EXCL |
                             os.O_NOFOLLOW | os.O_CLOEXEC, 0o600, dir_fd=directory)
        stage = 'write-pending'
        write_receipt(descriptor, intent)
        stage = 'sync-pending'
        os.fsync(descriptor)
        stage = 'sync-ledger'
        os.fsync(directory)
        stage = 'check-ledger-after'
        ledger_identity(directory, expected)
    except (OSError, TypeError, ValueError, OverflowError) as error:
        errors.append(receipt_error(stage, error))
    finally:
        close_receipt(descriptor, 'pending', errors)
        close_receipt(directory, 'ledger', errors)
    if errors:
        raise RuntimeError(json.dumps(dict(status='UNCERTAIN_DO_NOT_RETRY', errors=errors)))


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def receipt_error(stage, error):
    return dict(stage=stage, type=type(error).__name__,
                errno=error.errno if isinstance(error, OSError) else None, message=str(error))


def close_receipt(descriptor, role, errors):
    if descriptor is not None:
        try:
            os.close(descriptor)
        except OSError as error:
            # Do not retry close: the descriptor may already have been released.
            errors.append(receipt_error('close-' + role, error))


def check_receipt_directory(descriptor):
    opened = os.fstat(descriptor)
    named = ROOT.lstat()
    if (opened.st_dev, opened.st_ino, opened.st_mode) != \
            (named.st_dev, named.st_ino, named.st_mode):
        raise OSError('receipt directory identity changed')


def write_receipt(descriptor, value):
    # Preserve the baseline encoder's incremental fragments. This is not a
    # total-heap bound or a new input domain. Native receipt inputs come from
    # the three existing call sites. A failed fragment is never retried.
    for fragment in json.JSONEncoder(indent=2, sort_keys=True).iterencode(value):
        data = fragment.encode('utf-8')
        if os.write(descriptor, data) != len(data):
            raise OSError('short receipt write')
    if os.write(descriptor, b'\n') != 1:
        raise OSError('short receipt newline')


def save(name, value):
    """Exclusive, directory-anchored receipt; any IO uncertainty refuses ACK.

    ROOT is an already admitted, preexisting evidence directory. This does not
    prove storage hardware behavior or protect against a hostile same-UID owner.
    Only the three existing fixed receipt names may be persisted here.
    """
    if type(name) is not str or name not in ('entry.json', 'active.json', 'execution-result.json'):
        raise ValueError('fixed receipt name required')
    directory = descriptor = None
    errors = []
    stage = 'open-directory'
    try:
        directory = os.open(ROOT, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC)
        stage = 'check-directory-before'
        check_receipt_directory(directory)
        stage = 'create-file'
        descriptor = os.open(name, os.O_WRONLY | os.O_CREAT | os.O_EXCL |
                             os.O_NOFOLLOW | os.O_CLOEXEC, 0o644, dir_fd=directory)
        stage = 'write-file'
        write_receipt(descriptor, value)
        stage = 'sync-file'
        os.fsync(descriptor)
        stage = 'sync-directory'
        os.fsync(directory)
        stage = 'check-directory-after'
        check_receipt_directory(directory)
    except (OSError, TypeError, ValueError, OverflowError) as error:
        errors.append(receipt_error(stage, error))
    finally:
        close_receipt(descriptor, 'file', errors)
        close_receipt(directory, 'directory', errors)
    if errors:
        raise RuntimeError(json.dumps(dict(status='UNCERTAIN_DO_NOT_RETRY',
                                           receipt=name, errors=errors)))


def verify_manifest(manifest):
    for name, expected in manifest.items():
        if sha(ROOT / name) != expected:
            raise ValueError('execution source changed: ' + name)


def helpers(config):
    root = Path(config['helper_root'])
    for name, expected in config['helper_hashes'].items():
        if sha(root / name) != expected:
            raise ValueError('qualified helper changed: ' + name)
    spec = importlib.util.spec_from_file_location('qualified_controller', root / 'controller.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def verify_inputs(config, binding):
    paths = set()
    for name, expected in binding['files'].items():
        path = ROOT / 'source' / name
        paths.add(path)
        if path.is_symlink() or sha(path) != expected['sha256'] \
                or sha(Path(binding['canonical']) / name) != expected['canonical_sha256']:
            raise ValueError('proof input or canonical source drift: ' + name)
    actual = {p for p in (ROOT / 'source').rglob('*') if p.is_file()}
    if actual != paths:
        raise ValueError('source roster drift')
    for path, expected in config['proof_tools'].items():
        if sha(Path(path)) != expected:
            raise ValueError('proof executable drift: ' + path)


def wait_with_capacity(child, reserve):
    # Intended observer service loop: terminates on consuming child wait or a
    # capacity/error condition. No overall engineering time deadline is imposed.
    while True:
        try:
            return child.wait(timeout=5)
        except subprocess.TimeoutExpired:
            if shutil.disk_usage(ROOT).free < reserve:
                raise RuntimeError('physical working-space reserve reached') from None


def execute(config, binding, helper, stack, result):
    server = helper.server_for(ROOT / 'out', stack)
    stdout = stack.enter_context((ROOT / 'proof.stdout').open('xb'))
    stderr = stack.enter_context((ROOT / 'proof.stderr').open('xb'))
    child = subprocess.Popen(config['command'], stdout=stdout, stderr=stderr)
    descriptor = helper.owned_pidfd(child)
    stack.callback(os.close, descriptor)
    handles = dict(launcher=descriptor)
    result['launcher_pid'] = child.pid
    try:
        message = helper.receive(server, stack)
        connection, leader = helper.adopt_leader(config, message, child.pid, handles, result['peers'])
        verify_inputs(config, binding)
        helper.validate_tools(config)
        save('active.json', dict(launcher=child.pid, leader=leader,
                                namespace=result['peers'][0]['value']['namespaces'],
                                status='HANDLES_RETAINED_PROOF_ABOUT_TO_BE_ADMITTED',
                                recovery='Observer loss is UNKNOWN; no successor dispatch from a free lock'))
        if connection.send(b'prove') != 5:
            raise ValueError('proof admission transfer')
        result['proof_dispatched'] = True
        result['exit'] = wait_with_capacity(child, config['reserve_bytes'])
        result['terminal'] = helper.wait_terminal(handles, 5)
        if not all(item['terminal'] and item['reaped'] for item in result['terminal'].values()):
            raise ValueError('proof wrapper tracked processes not reaped')
    finally:
        result['cleanup'] = helper.cleanup(child, handles)
    if not result['cleanup']['complete']:
        raise ValueError('proof cleanup incomplete')
    result['execution_status'] = 'TERMINAL_REPORTS_REQUIRE_AUDIT'


def verify_host(config, helper):
    if os.getresuid() != (0, 0, 0) or signal.getsignal(signal.SIGCHLD) != signal.SIG_DFL:
        raise ValueError('fixed root observer required')
    if helper.namespaces(os.getpid()) != config['expected']['namespaces'] \
            or os.uname().nodename != config['hostname'] \
            or sha(Path('/etc/machine-id')) != config['machine_id_sha256'] \
            or sha(Path('/proc/sys/kernel/random/boot_id')) != config['boot_id_sha256']:
        raise ValueError('designated host changed')
    if shutil.disk_usage(ROOT).free < config['reserve_bytes']:
        raise ValueError('physical working-space admission failed')


def main():
    if len(sys.argv) != 2 or sha(ROOT / 'execution-source.json') != sys.argv[1]:
        raise ValueError('reviewed execution manifest required')
    manifest = json.loads((ROOT / 'execution-source.json').read_text())
    verify_manifest(manifest)
    config = json.loads((ROOT / 'config.json').read_text())
    binding = json.loads((ROOT / 'source-binding.json').read_text())
    helper = helpers(config)
    verify_host(config, helper)
    helper.validate_tools(config)
    verify_inputs(config, binding)
    result = dict(execution_status='FAILED_OR_INCOMPLETE', proof_dispatched=False,
                  peers=[], authority='NONE', source_head=binding['head'],
                  started=datetime.datetime.now(datetime.timezone.utc).isoformat())
    with ExitStack() as stack:
        meta = helper.hold_lock(stack)
        save('entry.json', dict(manifest=manifest, command=config['command'],
                               lock=helper.identity(meta), free_bytes=shutil.disk_usage(ROOT).free))
        reserve_pending(config, binding, meta, sys.argv[1])
        try:
            execute(config, binding, helper, stack, result)
            verify_inputs(config, binding)
            helper.validate_tools(config)
            verify_manifest(manifest)
            if helper.identity(meta) != helper.identity(helper.LOCK.lstat()):
                raise ValueError('heavy lock changed')
        except (OSError, ValueError, RuntimeError, subprocess.TimeoutExpired) as error:
            result['execution_status'] = 'FAILED_OR_INCOMPLETE'
            result['error'] = dict(type=type(error).__name__, message=str(error))
        result['finished'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        result['free_bytes'] = shutil.disk_usage(ROOT).free
        save('execution-result.json', result)
    print(json.dumps(result), flush=True)
    if result['execution_status'] != 'TERMINAL_REPORTS_REQUIRE_AUDIT':
        raise SystemExit(1)


if __name__ == '__main__':
    main()

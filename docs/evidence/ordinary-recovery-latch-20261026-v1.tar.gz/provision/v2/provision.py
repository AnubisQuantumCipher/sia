"""One explicit disposable ledger initialization, never an implicit recovery."""
from contextlib import ExitStack
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def load_candidate():
    spec = importlib.util.spec_from_file_location('fixed_latch_candidate', ROOT / 'candidate.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def initialize(candidate, epoch):
    parent = directory = descriptor = None
    errors = []
    result = None
    stage = 'ancestry'
    try:
        candidate.ledger_ancestry()
        stage = 'open-parent'
        parent = os.open(candidate.LEDGER.parent, os.O_RDONLY | os.O_DIRECTORY |
                         os.O_NOFOLLOW | os.O_CLOEXEC)
        stage = 'create-directory'
        os.mkdir(candidate.LEDGER.name, 0o700, dir_fd=parent)
        stage = 'sync-parent'
        os.fsync(parent)
        stage = 'open-directory'
        directory = os.open(candidate.LEDGER.name, os.O_RDONLY | os.O_DIRECTORY |
                            os.O_NOFOLLOW | os.O_CLOEXEC, dir_fd=parent)
        identity = candidate.metadata(os.fstat(directory))
        candidate.ledger_identity(directory, identity)
        stage = 'create-epoch'
        descriptor = os.open('epoch', os.O_WRONLY | os.O_CREAT | os.O_EXCL |
                             os.O_NOFOLLOW | os.O_CLOEXEC, 0o444, dir_fd=directory)
        stage = 'write-epoch'
        if os.write(descriptor, epoch) != len(epoch):
            raise OSError('short epoch write')
        stage = 'sync-epoch'
        os.fsync(descriptor)
        stage = 'sync-directory'
        os.fsync(directory)
        digest = hashlib.sha256(epoch).hexdigest()
        candidate.read_epoch(directory, digest)
        candidate.ledger_identity(directory, identity)
        result = dict(identity=identity, epoch_sha256=digest)
    except (OSError, ValueError, TypeError) as error:
        errors.append(candidate.receipt_error(stage, error))
    finally:
        for handle, role in ((descriptor, 'epoch'), (directory, 'ledger'), (parent, 'parent')):
            candidate.close_receipt(handle, role, errors)
    if errors:
        raise RuntimeError(json.dumps(dict(status='UNCERTAIN_DO_NOT_RETRY', errors=errors)))
    return result


def main():
    if len(sys.argv) != 2 or sha(ROOT / 'source.json') != sys.argv[1]:
        raise ValueError('fixed source manifest required')
    for name, expected in json.loads((ROOT / 'source.json').read_text()).items():
        if sha(ROOT / name) != expected:
            raise ValueError('provision source mismatch')
    epoch = (ROOT / 'epoch.txt').read_bytes()
    if len(epoch) != 65 or epoch[-1:] != b'\n' \
            or any(value not in b'0123456789abcdef' for value in epoch[:-1]):
        raise ValueError('bounded epoch required')
    candidate = load_candidate()
    config = json.loads((ROOT / 'host-config.json').read_text())
    helper = candidate.helpers(config)
    candidate.verify_host(config, helper)
    helper.validate_tools(config)
    with ExitStack() as stack:
        helper.hold_lock(stack)
        value = initialize(candidate, epoch)
    print(json.dumps(dict(status='LEDGER_INITIALIZED_NOT_RECOVERY_ACCEPTANCE',
                         ledger=str(candidate.LEDGER), recovery_ledger=value,
                         manifest_sha256=sys.argv[1])), flush=True)


if __name__ == '__main__':
    main()

"""Refusal-only ordinary recovery latch; no custody or reconciliation claim."""
import errno
from contextlib import redirect_stdout
import hashlib
import io
import json
import os
from pathlib import Path
import stat
import tempfile
import unittest
from unittest import mock

import receipt_candidate as candidate


class RecoveryLatch(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        self.root = Path(temporary.name)
        self.ledger = self.root / 'ledger'
        self.ledger.mkdir(mode=0o700)
        epoch = self.ledger / 'epoch'
        epoch.write_bytes(b'a' * 64 + b'\n')
        epoch.chmod(0o444)
        self.config = dict(machine_id_sha256='1' * 64, boot_id_sha256='2' * 64,
                           recovery_ledger=dict(identity=candidate.metadata(self.ledger.stat()),
                               epoch_sha256=hashlib.sha256(epoch.read_bytes()).hexdigest()))
        self.binding = dict(head='3' * 40)
        self.lock = self.root.stat()
        for name, value in (('ROOT', self.root), ('LEDGER', self.ledger)):
            patcher = mock.patch.object(candidate, name, value)
            patcher.start()
            self.addCleanup(patcher.stop)
        # Only host ancestry is omitted for the disposable UID1000 component
        # fixture. Separate controls below exercise the real ancestry validator.
        patcher = mock.patch.object(candidate, 'ledger_ancestry')
        self.ancestry = patcher.start()
        self.addCleanup(patcher.stop)

    def claim(self):
        candidate.reserve_pending(self.config, self.binding, self.lock, '4' * 64)

    def refused(self):
        with self.assertRaises(RuntimeError) as caught:
            self.claim()
        value = json.loads(str(caught.exception))
        self.assertEqual(value['status'], 'UNCERTAIN_DO_NOT_RETRY')
        return value['errors']

    def test_real_durable_intent_binds_run_and_source(self):
        self.claim()
        path = self.ledger / 'pending.json'
        value = json.loads(path.read_text())
        self.assertEqual(value['bindings'], dict(manifest='4' * 64, machine='1' * 64,
            boot='2' * 64, epoch=hashlib.sha256((self.ledger / 'epoch').read_bytes()).hexdigest()))
        self.assertEqual(value['source_head'], '3' * 40)
        self.assertEqual(value['output_path_sha256'], hashlib.sha256(os.fsencode(self.root)).hexdigest())
        self.assertEqual(value['lock_identity'], [self.lock.st_dev, self.lock.st_ino,
            self.lock.st_mode, self.lock.st_uid, self.lock.st_gid, self.lock.st_nlink])
        self.assertEqual(value['output_identity'], value['lock_identity'])
        self.assertEqual(value['status'], 'UNRESOLVED_DO_NOT_RETRY')
        self.assertEqual(stat.S_IMODE(path.stat().st_mode), 0o600)

    def test_changed_output_boot_source_does_not_clear_pending(self):
        self.claim()
        before = (self.ledger / 'pending.json').read_bytes()
        self.binding['head'] = '5' * 40
        self.config['boot_id_sha256'] = '6' * 64
        with mock.patch.object(candidate, 'ROOT', self.ledger):
            errors = self.refused()
        self.assertEqual(errors[0]['errno'], errno.EEXIST)
        self.assertEqual((self.ledger / 'pending.json').read_bytes(), before)

    def main_fixture(self):
        for name, value in (('config.json', self.config), ('source-binding.json', self.binding)):
            (self.root / name).write_text(json.dumps(value))
        manifest = {name: hashlib.sha256((self.root / name).read_bytes()).hexdigest()
                    for name in ('config.json', 'source-binding.json')}
        (self.root / 'execution-source.json').write_text(json.dumps(manifest))
        helper = mock.Mock()
        helper.hold_lock.return_value = self.lock
        helper.identity.side_effect = lambda value: candidate.metadata(value)
        return helper, hashlib.sha256((self.root / 'execution-source.json').read_bytes()).hexdigest()

    def test_main_reservation_failure_prevents_execute_and_popen(self):
        self.claim()
        helper, manifest = self.main_fixture()
        with mock.patch.object(candidate.sys, 'argv', ['proof_wrapper.py', manifest]), \
                mock.patch.object(candidate, 'helpers', return_value=helper), \
                mock.patch.object(candidate, 'verify_host'), \
                mock.patch.object(candidate, 'verify_inputs'), \
                mock.patch.object(candidate, 'execute') as execute, \
                mock.patch.object(candidate.subprocess, 'Popen') as popen:
            with self.assertRaises(RuntimeError):
                candidate.main()
        execute.assert_not_called()
        popen.assert_not_called()
        helper.hold_lock.assert_called_once()

    def test_main_reserves_before_execute_entry(self):
        helper, manifest = self.main_fixture()
        def at_execute(*_args):
            intent = json.loads((self.ledger / 'pending.json').read_text())
            self.assertEqual(intent['bindings']['manifest'], manifest)
            helper.hold_lock.assert_called_once()
            raise RuntimeError('fixed fixture stop before launch')
        with mock.patch.object(candidate.sys, 'argv', ['proof_wrapper.py', manifest]), \
                mock.patch.object(candidate, 'helpers', return_value=helper), \
                mock.patch.object(candidate, 'verify_host'), \
                mock.patch.object(candidate, 'verify_inputs'), \
                mock.patch.object(candidate, 'execute', side_effect=at_execute) as execute, \
                mock.patch.object(candidate.subprocess, 'Popen') as popen, \
                redirect_stdout(io.StringIO()), self.assertRaises(SystemExit) as exited:
            candidate.main()
        self.assertEqual(exited.exception.code, 1)
        execute.assert_called_once()
        popen.assert_not_called()

    def test_empty_malformed_and_apparent_completed_records_all_refuse(self):
        path = self.ledger / 'pending.json'
        for data in (b'', b'{', b'{"status":"COMPLETE"}'):
            with self.subTest(data=data):
                path.write_bytes(data)
                self.assertEqual(self.refused()[0]['stage'], 'create-pending')
                self.assertEqual(path.read_bytes(), data)
                path.unlink()  # Disposable test fixture only, not a retirement API.

    def test_missing_or_mismatched_epoch_has_no_intent(self):
        self.config['recovery_ledger']['epoch_sha256'] = '9' * 64
        self.assertEqual(self.refused()[0]['stage'], 'check-epoch')
        self.assertFalse((self.ledger / 'pending.json').exists())
        (self.ledger / 'epoch').unlink()
        self.assertEqual(self.refused()[0]['stage'], 'check-epoch')

    def test_directory_identity_mismatch_refuses_before_write(self):
        self.config['recovery_ledger']['identity'][1] += 1
        self.assertEqual(self.refused()[0]['stage'], 'check-ledger')
        self.assertFalse((self.ledger / 'pending.json').exists())

    def test_pending_symlink_refuses_without_touching_target(self):
        target = self.root / 'untouched'
        target.write_bytes(b'keep')
        (self.ledger / 'pending.json').symlink_to(target)
        self.assertEqual(self.refused()[0]['stage'], 'create-pending')
        self.assertEqual(target.read_bytes(), b'keep')

    def test_ledger_symlink_refuses(self):
        link = self.root / 'link'
        link.symlink_to(self.ledger)
        with mock.patch.object(candidate, 'LEDGER', link):
            self.assertEqual(self.refused()[0]['stage'], 'open-ledger')

    def test_ancestry_failure_has_no_open(self):
        self.ancestry.side_effect = ValueError('invalid ancestry')
        with mock.patch.object(candidate.os, 'open') as opened:
            self.assertEqual(self.refused()[0]['stage'], 'check-ancestry')
        opened.assert_not_called()

    def test_invalid_digest_has_no_io(self):
        with mock.patch.object(candidate.os, 'open') as opened:
            for value in ('x' * 64, 'a' * 65, b'a' * 64):
                self.config['boot_id_sha256'] = value
                with self.subTest(value=value), self.assertRaises(ValueError):
                    self.claim()
        opened.assert_not_called()

    def test_partial_write_is_retained_and_blocks_next_attempt(self):
        with mock.patch.object(candidate.os, 'write', side_effect=OSError(errno.ENOSPC, 'injected')):
            self.assertEqual(self.refused()[0]['stage'], 'write-pending')
        self.assertTrue((self.ledger / 'pending.json').exists())
        self.assertEqual(self.refused()[0]['stage'], 'create-pending')

    def test_each_sync_failure_retains_latch_and_blocks_next_attempt(self):
        sync = os.fsync
        for role in ('pending', 'ledger'):
            with self.subTest(role=role):
                def fail(fd, selected=role):
                    actual = 'ledger' if stat.S_ISDIR(os.fstat(fd).st_mode) else 'pending'
                    if actual == selected:
                        raise OSError(errno.EIO, 'injected sync')
                    return sync(fd)
                with mock.patch.object(candidate.os, 'fsync', side_effect=fail):
                    self.assertEqual(self.refused()[0]['stage'], 'sync-' + role)
                self.assertEqual(self.refused()[0]['stage'], 'create-pending')
                (self.ledger / 'pending.json').unlink()

    def test_close_failure_is_not_acknowledged_and_latch_remains(self):
        close = os.close
        def fail(fd):
            pending = stat.S_ISREG(os.fstat(fd).st_mode) and os.fstat(fd).st_size != 65
            close(fd)
            if pending:
                raise OSError(errno.EIO, 'injected close')
        with mock.patch.object(candidate.os, 'close', side_effect=fail):
            self.assertEqual(self.refused()[0]['stage'], 'close-pending')
        self.assertEqual(self.refused()[0]['stage'], 'create-pending')

    def test_epoch_symlink_and_oversized_epoch_refuse(self):
        epoch = self.ledger / 'epoch'
        epoch.unlink()
        epoch.symlink_to(self.root / 'absent')
        self.assertEqual(self.refused()[0]['stage'], 'check-epoch')
        epoch.unlink()
        epoch.write_bytes(b'a' * 65 + b'\n')
        epoch.chmod(0o444)
        self.assertEqual(self.refused()[0]['stage'], 'check-epoch')
        self.assertFalse((self.ledger / 'pending.json').exists())

    def test_epoch_primary_and_close_failures_both_remain(self):
        close = os.close
        def fail_close(fd):
            epoch = stat.S_ISREG(os.fstat(fd).st_mode)
            close(fd)
            if epoch:
                raise OSError(errno.EIO, 'epoch close')
        with mock.patch.object(candidate.os, 'read', side_effect=OSError(errno.EIO, 'epoch read')), \
                mock.patch.object(candidate.os, 'close', side_effect=fail_close):
            errors = self.refused()
        nested = json.loads(errors[0]['message'])['epoch_errors']
        self.assertEqual([row['stage'] for row in nested], ['read-epoch', 'close-epoch'])
        self.assertFalse((self.ledger / 'pending.json').exists())


class LedgerAncestry(unittest.TestCase):
    def test_actual_host_ancestry(self):
        candidate.ledger_ancestry()

    def test_symlink_wrong_owner_and_writable_parent_refuse(self):
        original = Path.lstat
        for replacement in ((stat.S_IFLNK | 0o777, 0), (stat.S_IFDIR | 0o755, 1000),
                            (stat.S_IFDIR | 0o775, 0)):
            with self.subTest(replacement=replacement):
                def metadata(path, selected=replacement):
                    if path != Path('/var'):
                        return original(path)
                    return mock.Mock(st_mode=selected[0], st_uid=selected[1])
                with mock.patch.object(Path, 'lstat', metadata), self.assertRaises(ValueError):
                    candidate.ledger_ancestry()

    def test_nonsticky_parent_refuses(self):
        original = Path.lstat
        def metadata(path):
            if path == Path('/var/tmp'):
                return mock.Mock(st_mode=stat.S_IFDIR | 0o777, st_uid=0)
            return original(path)
        with mock.patch.object(Path, 'lstat', metadata), self.assertRaises(ValueError):
            candidate.ledger_ancestry()


if __name__ == '__main__':
    unittest.main(verbosity=2)

"""Prepare one actual wrapper run and one pending-refusal control."""
import hashlib
import json
from pathlib import Path
import shutil

BASE = Path(__file__).resolve().parent
PRIOR = BASE / 'ordinary-recovery-latch-controls-20261026-v3'
PROVISION = BASE / 'ordinary-recovery-latch-provision-20261026-v2'
TARGETS = ('ordinary-recovery-latch-integration-20261026-v1',
           'ordinary-recovery-latch-refusal-20261026-v1')


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write('\n')


def source_binding():
    if sha(PRIOR / 'execution-source.json') != \
            '97e904de69f7bb83b864e03a90f500d8bc36f1400a9ce1312a5022f7bcf57bdd':
        raise ValueError('component manifest drift')
    manifest = json.loads((PRIOR / 'execution-source.json').read_text())
    for name, expected in manifest.items():
        if sha(PRIOR / name) != expected:
            raise ValueError('component source drift')
    binding = json.loads((PRIOR / 'source-binding.json').read_text())
    for name, row in binding['files'].items():
        source = PRIOR / 'source' / name
        if sha(source) != row['sha256'] or source.stat().st_size != row['bytes'] \
                or sha(Path(binding['canonical']) / name) != row['canonical_sha256']:
            raise ValueError('snapshot or canonical source drift')
    return manifest


def ledger_binding():
    note = json.loads((PROVISION / 'TOOL-EXIT-OBSERVATION.json').read_text())
    result = json.loads((PROVISION / 'provision.stdout').read_text())
    if note['exit_code'] != 0 or note['stdout_sha256'] != sha(PROVISION / 'provision.stdout') \
            or result['manifest_sha256'] != sha(PROVISION / 'source.json') \
            or result['status'] != 'LEDGER_INITIALIZED_NOT_RECOVERY_ACCEPTANCE' \
            or result['recovery_ledger']['epoch_sha256'] != sha(PROVISION / 'epoch.txt'):
        raise ValueError('initialization observation mismatch')
    return result['recovery_ledger']


def prepare(name, manifest, ledger):
    root = BASE / name
    root.mkdir(mode=0o700)
    for directory in ('obj', 'bin', 'home', 'tmp', 'cache', 'out'):
        (root / directory).mkdir(mode=0o700)
    shutil.copytree(PRIOR / 'source', root / 'source')
    for file in manifest:
        if file == 'config.json':
            config = json.loads((PRIOR / file).read_text().replace(str(PRIOR), str(root)))
            config['recovery_ledger'] = ledger
            save(root / file, config)
        elif file == 'proof_wrapper.py':
            shutil.copyfile(PRIOR / 'receipt_candidate.py', root / file)
        else:
            shutil.copyfile(PRIOR / file, root / file)
    save(root / 'execution-source.json', {name: sha(root / name) for name in manifest})
    return dict(root=str(root), manifest_sha256=sha(root / 'execution-source.json'))


def main():
    manifest, ledger = source_binding(), ledger_binding()
    for name in TARGETS:
        print(json.dumps(prepare(name, manifest, ledger)))


if __name__ == '__main__':
    main()

"""Reproduce ordinary refusal-latch evidence without executing archived source."""
import argparse
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

BASE = Path(__file__).resolve().parent
ROOT = BASE / 'ordinary-recovery-latch-package-20261026-v1'
ARCHIVE = 'ordinary-recovery-latch-20261026-v1.tar.gz'
RUNS = dict(component='ordinary-recovery-latch-controls-20261026-v3',
            integration='ordinary-recovery-latch-integration-20261026-v1',
            refusal='ordinary-recovery-latch-refusal-20261026-v1')


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def add(files, prefix, directory, names):
    for name in names:
        key = prefix + '/' + name
        if key in files:
            raise ValueError('duplicate member')
        files[key] = directory / name


def roster():
    files = {}
    common = ('config.json', 'execution-source.json', 'source-binding.json', 'entry.json',
              'proof_wrapper.py', 'proof_payload.py', 'receipt_candidate.py', 'receipt_baseline.py',
              'test_receipt_durability.py', 'test_error_paths.py', 'test_recovery_latch.py',
              'controller.py', 'proxy.py', 'invoke.py', 'outer-result.json', 'outer.stdout',
              'OWNER-AUDIT.json', 'RESULT-INDEPENDENT-REVIEW.json', 'EXECUTION-DECISION.json')
    for label, directory in RUNS.items():
        add(files, 'runs/' + label, BASE / directory, common)
        names = ('TOOL-RESULT-READBACK.json', 'pending-after.json', 'PENDING-READBACK.json') \
            if label == 'refusal' else ('execution-result.json', 'active.json', 'proof.stdout',
                                       'proof.stderr', 'TOOL-EXIT-OBSERVATION.json')
        add(files, 'runs/' + label, BASE / directory, names)
    add(files, 'runs/integration', BASE / RUNS['integration'],
        ('pending-before.json', 'PENDING-READBACK.json'))
    add(files, 'source', BASE / 'ordinary-recovery-latch-20261026-v1',
        ('proof_wrapper.py', 'test_recovery_latch.py', 'STATIC-v1.json', 'STATIC-v2.json', 'STATIC-v3.json'))
    for version in ('v1', 'v2'):
        add(files, 'unrun/controls-' + version, BASE / ('ordinary-recovery-latch-controls-20261026-' + version),
            ('UNRUN-DISPOSITION.json', 'execution-source.json', 'config.json', 'test_recovery_latch.py'))
    for version in ('v1', 'v2'):
        directory = BASE / ('ordinary-recovery-latch-provision-20261026-' + version)
        add(files, 'provision/' + version, directory,
            ('provision.py', 'candidate.py', 'host-config.json', 'epoch.txt', 'source.json', 'STATIC.json'))
    add(files, 'provision/v1', BASE / 'ordinary-recovery-latch-provision-20261026-v1', ('UNRUN-DISPOSITION.json',))
    add(files, 'provision/v2', BASE / 'ordinary-recovery-latch-provision-20261026-v2',
        ('EXECUTION-DECISION.json', 'provision.stdout', 'TOOL-EXIT-OBSERVATION.json'))
    add(files, 'tools', BASE, ('prepare_recovery_latch_controls_20261026.py',
        'prepare_recovery_latch_controls_20261026_v1.py', 'prepare_recovery_latch_controls_20261026_v2.py',
        'prepare_recovery_latch_integration_20261026.py', 'audit_recovery_latch_controls_20261026.py',
        'audit_recovery_latch_integration_20261026.py', 'audit_recovery_latch_refusal_20261026.py', Path(__file__).name))
    return files


def verify():
    for directory in RUNS.values():
        root = BASE / directory
        audit = json.loads((root / 'OWNER-AUDIT.json').read_text())
        for name, expected in audit['evidence_sha256'].items():
            if sha(root / name) != expected:
                raise ValueError('audited bytes drift: ' + name)
        review = json.loads((root / 'RESULT-INDEPENDENT-REVIEW.json').read_text())
        if review['audit_sha256'] != sha(root / 'OWNER-AUDIT.json'):
            raise ValueError('review binding drift')
        for name, expected in json.loads((root / 'execution-source.json').read_text()).items():
            if sha(root / name) != expected:
                raise ValueError('execution source drift')
        for name, row in json.loads((root / 'source-binding.json').read_text())['files'].items():
            path = root / 'source' / name
            if sha(path) != row['sha256'] or path.stat().st_size != row['bytes']:
                raise ValueError('snapshot drift')


def members(files):
    if not 1 <= len(files) <= 160:
        raise ValueError('member count')
    result, total = {}, 0
    for name, path in sorted(files.items()):
        size = path.stat().st_size
        if path.is_symlink() or not path.is_file() or size > 1048576:
            raise ValueError('invalid member: ' + name)
        total += size
        if total > 8388608:
            raise ValueError('archive input limit')
        result[name] = dict(sha256=sha(path), bytes=size)
    return result


def encoded_archive(files, rows):
    output = io.BytesIO()
    with gzip.GzipFile(fileobj=output, mode='wb', filename='', mtime=0) as zipped:
        with tarfile.open(fileobj=zipped, mode='w', format=tarfile.USTAR_FORMAT) as archive:
            for name, path in sorted(files.items()):
                with path.open('rb') as stream:
                    data = stream.read(1048577)
                if len(data) != rows[name]['bytes'] or hashlib.sha256(data).hexdigest() != rows[name]['sha256']:
                    raise ValueError('input changed during packaging')
                info = tarfile.TarInfo(name)
                info.size, info.mode, info.mtime = len(data), 0o444, 0
                archive.addfile(info, io.BytesIO(data))
    return output.getvalue()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--check', action='store_true')
    args = parser.parse_args()
    verify()
    files = roster()
    rows = members(files)
    data = encoded_archive(files, rows)
    record = dict(status='TESTED_NORMAL_THEN_REFUSED_NOT_RECOVERY_ACCEPTANCE', authority='NONE',
        carrier_head='ba6a451193bded8faa6401e6eb085bc6ee78b39e', members=rows,
        archive=dict(path='docs/evidence/' + ARCHIVE, sha256=hashlib.sha256(data).hexdigest(), bytes=len(data)),
        results={name: json.loads((BASE / directory / 'OWNER-AUDIT.json').read_text()) for name, directory in RUNS.items()},
        limitations=['No observer-death cut, reconciliation/retirement or safe successor protocol.',
            'Root pending remains unresolved; no clearing API and no automatic retry.',
            'Ordinary nonhostile host/root premises; old wrappers outside latch scope.',
            'No hardware crash durability, formal Python proof, C14 or whole-system acceptance.',
            'Full source snapshots bound but not reproduced; local paths retained.',
            'Tool observations not signed platform evidence; epoch is a public identity, not a secret.',
            'One disposable root-owned engineering ledger created; no installed product/service/provider change.'])
    encoded = (json.dumps(record, indent=2, sort_keys=True) + '\n').encode()
    if args.check:
        if (ROOT / ARCHIVE).read_bytes() != data or (ROOT / 'manifest.json').read_bytes() != encoded:
            raise ValueError('byte reproduction mismatch')
    else:
        ROOT.mkdir(mode=0o700)
        for name, value in ((ARCHIVE, data), ('manifest.json', encoded)):
            with (ROOT / name).open('xb') as stream:
                if stream.write(value) != len(value):
                    raise OSError('short package write')
    print(json.dumps(dict(status='PACKAGE_CHECK_PASS' if args.check else 'PACKAGE_CREATED',
                         archive=record['archive'], members=len(rows))))


if __name__ == '__main__':
    main()

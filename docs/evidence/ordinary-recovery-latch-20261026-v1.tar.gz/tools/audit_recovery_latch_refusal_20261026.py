"""Verify one expected refusal and unchanged unresolved intent; never retry."""
import hashlib
import json
from pathlib import Path

BASE = Path(__file__).resolve().parent
ROOT = BASE / 'ordinary-recovery-latch-refusal-20261026-v1'
PRIOR = BASE / 'ordinary-recovery-latch-integration-20261026-v1'


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def identities():
    files = json.loads((ROOT / 'execution-source.json').read_text())
    if sha(ROOT / 'execution-source.json') != \
            'cae88d6cab560cd44546c118fa4c776b72957a90b217600de3609743a4dca0f4':
        raise ValueError('execution manifest drift')
    for name, expected in files.items():
        if sha(ROOT / name) != expected:
            raise ValueError('execution file drift: ' + name)
    binding = json.loads((ROOT / 'source-binding.json').read_text())
    for name, row in binding['files'].items():
        path = ROOT / 'source' / name
        if sha(path) != row['sha256'] or path.stat().st_size != row['bytes'] \
                or sha(Path(binding['canonical']) / name) != row['canonical_sha256']:
            raise ValueError('source binding mismatch: ' + name)
    config = json.loads((ROOT / 'config.json').read_text())
    for field in ('tools', 'proof_tools'):
        for name, expected in config[field].items():
            if sha(Path(name)) != expected:
                raise ValueError('tool mismatch: ' + name)
    for name, expected in config['helper_hashes'].items():
        if sha(Path(config['helper_root']) / name) != expected:
            raise ValueError('helper mismatch: ' + name)
    return len(binding['files'])


def refusal():
    tool = json.loads((ROOT / 'TOOL-RESULT-READBACK.json').read_text())['result']
    outer = json.loads((ROOT / 'outer-result.json').read_text())
    if tool['exit_code'] != 1 or outer['actual_exit'] != 1:
        raise ValueError('expected refusal exit missing')
    lines = tool['output'].splitlines()
    errors = [json.loads(line[len('RuntimeError: '):]) for line in lines
              if line.startswith('RuntimeError: ')]
    expected = dict(status='UNCERTAIN_DO_NOT_RETRY', errors=[dict(stage='create-pending',
        type='FileExistsError', errno=17, message="[Errno 17] File exists: 'pending.json'")])
    if errors != [expected] or json.loads(lines[-1]) != outer:
        raise ValueError('wrong refusal or outer observation')
    if (ROOT / 'outer.stdout').read_bytes() != b'' \
            or outer['stdout_sha256'] != sha(ROOT / 'outer.stdout') \
            or outer['manifest_sha256'] != sha(ROOT / 'execution-source.json') \
            or outer['wrapper_sha256'] != sha(ROOT / 'proof_wrapper.py'):
        raise ValueError('refusal source or output mismatch')
    for name in ('active.json', 'execution-result.json', 'proof.stdout', 'proof.stderr', 'out/w.sock'):
        if (ROOT / name).exists() or (ROOT / name).is_symlink():
            raise ValueError('unexpected payload artifact: ' + name)
    for name in ('obj', 'bin', 'home', 'tmp', 'cache', 'out'):
        if any((ROOT / name).iterdir()):
            raise ValueError('unexpected payload output: ' + name)
    return expected


def predecessor():
    before = (PRIOR / 'pending-before.json').read_bytes()
    after = (ROOT / 'pending-after.json').read_bytes()
    if before != after:
        raise ValueError('unresolved intent changed')
    intent = json.loads(after)
    if intent['bindings']['manifest'] != sha(PRIOR / 'execution-source.json'):
        raise ValueError('wrong predecessor')
    old_entry = json.loads((PRIOR / 'entry.json').read_text())
    entry = json.loads((ROOT / 'entry.json').read_text())
    if entry['lock'] != old_entry['lock'] or entry['manifest'] != \
            json.loads((ROOT / 'execution-source.json').read_text()):
        raise ValueError('shared lock or current source mismatch')
    return hashlib.sha256(after).hexdigest()


def main():
    count = identities()
    failure = refusal()
    pending = predecessor()
    names = ('execution-source.json', 'source-binding.json', 'entry.json',
             'outer-result.json', 'outer.stdout', 'TOOL-RESULT-READBACK.json', 'pending-after.json')
    report = dict(status='EXPECTED_PENDING_REFUSAL_PASS', source_rows=count,
                  tests_executed=0, payload_artifacts_absent=True,
                  retained_refusal=failure, unchanged_pending_sha256=pending,
                  evidence_sha256={name: sha(ROOT / name) for name in names},
                  independent_review='PENDING', adoption=False,
                  limitations=['Observed normal-then-refused path; no observer-death injection.',
                      'Refusal intentionally leaves recovery debt unresolved.',
                      'Tool readback is not signed platform evidence.',
                      'No retirement, whole-job custody, C14 or system acceptance.'])
    with (ROOT / 'OWNER-AUDIT.json').open('x') as stream:
        json.dump(report, stream, indent=2, sort_keys=True)
        stream.write('\n')
    print(json.dumps(report))


if __name__ == '__main__':
    main()

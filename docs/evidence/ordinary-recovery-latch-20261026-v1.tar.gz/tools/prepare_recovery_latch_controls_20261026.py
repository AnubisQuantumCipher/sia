"""Prepare the refusal-only latch component controls; no root latch creation."""
import hashlib
import json
from pathlib import Path
import shutil

BASE = Path(__file__).resolve().parent
PRIOR = BASE / 'ordinary-receipt-integration-20261026-v1'
ROOT = BASE / 'ordinary-recovery-latch-controls-20261026-v3'
CANDIDATE = BASE / 'ordinary-recovery-latch-20261026-v1'


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write('\n')


def configuration():
    config = json.loads((PRIOR / 'config.json').read_text().replace(str(PRIOR), str(ROOT)))
    command = config['command']
    offset = command.index('/usr/bin/setpriv')
    command[offset:offset] = ['--ro-bind', str(ROOT / 'test_recovery_latch.py'),
                              '/tmp/test_recovery_latch.py']
    config['proof_command'][-1] = config['proof_command'][-1].replace(
        '"test_receipt_durability","test_error_paths"',
        '"test_receipt_durability","test_error_paths","test_recovery_latch"')
    config['candidate_phase'] = 'ordinary-recovery-latch-component-controls'
    return config


def main():
    if sha(PRIOR / 'execution-source.json') != \
            '99a15edc36e709dec918f6891aac0156263f18167fbe1def15fb7d2bac9f3818':
        raise ValueError('prior manifest changed')
    manifest = json.loads((PRIOR / 'execution-source.json').read_text())
    for name, expected in manifest.items():
        if sha(PRIOR / name) != expected:
            raise ValueError('prior source changed: ' + name)
    binding = json.loads((PRIOR / 'source-binding.json').read_text())
    for name, row in binding['files'].items():
        source = PRIOR / 'source' / name
        if sha(source) != row['sha256'] or source.stat().st_size != row['bytes'] \
                or sha(Path(binding['canonical']) / name) != row['canonical_sha256']:
            raise ValueError('baseline drift: ' + name)
    ROOT.mkdir(mode=0o700)
    for name in ('obj', 'bin', 'home', 'tmp', 'cache', 'out'):
        (ROOT / name).mkdir(mode=0o700)
    shutil.copytree(PRIOR / 'source', ROOT / 'source')
    for name in manifest:
        if name == 'config.json':
            save(ROOT / name, configuration())
        elif name == 'receipt_candidate.py':
            shutil.copyfile(CANDIDATE / 'proof_wrapper.py', ROOT / name)
        else:
            shutil.copyfile(PRIOR / name, ROOT / name)
    shutil.copyfile(CANDIDATE / 'test_recovery_latch.py', ROOT / 'test_recovery_latch.py')
    manifest['test_recovery_latch.py'] = sha(ROOT / 'test_recovery_latch.py')
    save(ROOT / 'execution-source.json', {name: sha(ROOT / name) for name in manifest})
    print(json.dumps(dict(root=str(ROOT), manifest_sha256=sha(ROOT / 'execution-source.json'))))


if __name__ == '__main__':
    main()

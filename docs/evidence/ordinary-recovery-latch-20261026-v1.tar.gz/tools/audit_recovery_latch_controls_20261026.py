"""Audit latch component controls through the prior ordinary wrapper."""
import ast
import hashlib
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parent / 'ordinary-recovery-latch-controls-20261026-v3'


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def methods():
    expected = []
    for module in ('test_receipt_durability', 'test_error_paths', 'test_recovery_latch'):
        source = ast.parse((ROOT / (module + '.py')).read_text())
        for node in source.body:
            if isinstance(node, ast.ClassDef):
                for method in node.body:
                    if isinstance(method, ast.FunctionDef) and method.name.startswith('test_'):
                        expected.append(method.name + ' (' + module + '.' + node.name + '.' +
                                        method.name + ') ... ok')
    if len(expected) != 37 or len(set(expected)) != 37:
        raise ValueError('expected fixed 37-method roster')
    return sorted(expected)


def output():
    stderr = (ROOT / 'proof.stderr').read_text()
    found = re.fullmatch(r'(.+)\n\n-+\nRan 37 tests in ([0-9.]+)s\n\nOK\n', stderr, re.DOTALL)
    if not found or sorted(found[1].splitlines()) != methods() or (ROOT / 'proof.stdout').stat().st_size:
        raise ValueError('raw roster or diagnostics mismatch')
    return dict(tests=37, elapsed_seconds=found[2], failures=0, errors=0, skips=0)


def identities():
    files = json.loads((ROOT / 'execution-source.json').read_text())
    if sha(ROOT / 'execution-source.json') != \
            '97e904de69f7bb83b864e03a90f500d8bc36f1400a9ce1312a5022f7bcf57bdd':
        raise ValueError('execution manifest drift')
    for name, expected in files.items():
        if sha(ROOT / name) != expected:
            raise ValueError('execution file drift: ' + name)
    binding = json.loads((ROOT / 'source-binding.json').read_text())
    for name, row in binding['files'].items():
        path = ROOT / 'source' / name
        if sha(path) != row['sha256'] or path.stat().st_size != row['bytes'] \
                or sha(Path(binding['canonical']) / name) != row['canonical_sha256']:
            raise ValueError('source binding mismatch: ' + name)
    config = json.loads((ROOT / 'config.json').read_text())
    for field in ('tools', 'proof_tools'):
        for name, expected in config[field].items():
            if sha(Path(name)) != expected:
                raise ValueError('tool mismatch: ' + name)
    for name, expected in config['helper_hashes'].items():
        if sha(Path(config['helper_root']) / name) != expected:
            raise ValueError('helper mismatch: ' + name)
    return len(binding['files'])


def acknowledgment(result):
    outer = json.loads((ROOT / 'outer-result.json').read_text())
    tool = json.loads((ROOT / 'TOOL-EXIT-OBSERVATION.json').read_text())
    if tool['exit_code'] != 0 or outer['actual_exit'] != 0:
        raise ValueError('outer execution failed or uncertain')
    if outer['stdout_sha256'] != sha(ROOT / 'outer.stdout') or \
            outer['manifest_sha256'] != sha(ROOT / 'execution-source.json') or \
            outer['wrapper_sha256'] != sha(ROOT / 'proof_wrapper.py'):
        raise ValueError('outer acknowledgment identity mismatch')
    if json.loads((ROOT / 'outer.stdout').read_text()) != result:
        raise ValueError('wrapper acknowledgment/final record mismatch')
    for name in ('entry.json', 'active.json', 'execution-result.json'):
        metadata = (ROOT / name).stat()
        if metadata.st_uid != 0 or metadata.st_mode & 0o777 != 0o644:
            raise ValueError('root receipt mode mismatch')


def main():
    selection = output()
    count = identities()
    result = json.loads((ROOT / 'execution-result.json').read_text())
    if result['execution_status'] != 'TERMINAL_REPORTS_REQUIRE_AUDIT' \
            or result['exit'] != 0 or not result['cleanup']['complete'] \
            or result['cleanup']['errors'] or not result['proof_dispatched']:
        raise ValueError('execution/cleanup mismatch')
    for row in result['terminal'].values():
        if not row['terminal'] or not row['reaped']:
            raise ValueError('tracked terminal evidence missing')
    acknowledgment(result)
    names = ('outer-result.json', 'outer.stdout', 'TOOL-EXIT-OBSERVATION.json', 'execution-source.json', 'source-binding.json', 'execution-result.json',
             'proof.stdout', 'proof.stderr', 'receipt_candidate.py', 'test_receipt_durability.py', 'test_recovery_latch.py')
    report = dict(status='RECOVERY_LATCH_COMPONENT_CONTROLS_PASS', output=selection,
                  source_rows=count, tracked_terminal_cleanup=True,
                  evidence_sha256={name: sha(ROOT / name) for name in names},
                  adoption=False, independent_review='PENDING',
                  limitations=['Candidate imported as module; mocked main ordering is not actual root main dispatch.',
                               'No root ledger provision, hardware crash durability, custody or retirement protocol.',
                               'Observer-loss recovery UNKNOWN; no C14 or whole-system acceptance.'])
    with (ROOT / 'OWNER-AUDIT.json').open('x') as stream:
        json.dump(report, stream, indent=2, sort_keys=True)
        stream.write('\n')
    print(json.dumps(report))


if __name__ == '__main__':
    main()

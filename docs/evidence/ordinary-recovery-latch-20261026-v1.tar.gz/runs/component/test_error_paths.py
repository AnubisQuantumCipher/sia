"""No process launches: exercise rejected source paths with deliberate failures."""
import importlib.util
import json
from pathlib import Path
import select
import signal
import subprocess
import unittest
from unittest.mock import Mock, patch

ROOT = Path(__file__).resolve().parent


def load(name):
    spec = importlib.util.spec_from_file_location(name, ROOT / (name + '.py'))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class ErrorPaths(unittest.TestCase):
    def test_acquisition_failure_keeps_direct_child_unreaped_until_signal(self):
        for module in (load('controller'), load('proxy')):
            child = Mock(pid=701)
            child.wait.return_value = -signal.SIGKILL
            with patch.object(module.os, 'pidfd_open', side_effect=OSError('fd failure')), \
                    patch.object(module.os, 'kill') as kill:
                with self.assertRaises(RuntimeError) as caught:
                    module.owned_pidfd(child)
            kill.assert_called_once_with(701, signal.SIGKILL)
            child.wait.assert_called_once_with(timeout=5)
            child.poll.assert_not_called()
            self.assertEqual(json.loads(str(caught.exception))['wait'], -signal.SIGKILL)

    def test_signal_error_does_not_skip_wait(self):
        for module in (load('controller'), load('proxy')):
            child = Mock(pid=701)
            child.wait.return_value = 0
            with patch.object(module.os, 'pidfd_open', side_effect=OSError('fd failure')), \
                    patch.object(module.os, 'kill', side_effect=PermissionError('signal failure')):
                with self.assertRaises(RuntimeError) as caught:
                    module.owned_pidfd(child)
            child.wait.assert_called_once_with(timeout=5)
            value = json.loads(str(caught.exception))
            self.assertIn('signal_error', value)
            self.assertEqual(value['wait'], 0)

    def test_poll_error_is_not_terminal_acceptance(self):
        module = load('controller')
        watcher = Mock()
        watcher.poll.return_value = [(41, select.POLLIN | select.POLLHUP | select.POLLERR)]
        with patch.object(module.select, 'poll', return_value=watcher):
            with self.assertRaises(ValueError):
                module.events(41)

    def test_cleanup_retains_signal_and_wait_errors(self):
        module = load('controller')
        child = Mock()
        child.wait.side_effect = subprocess.TimeoutExpired('fixture', 5)
        observed = {'leader': {'terminal': False, 'reaped': False, 'mask': 0}}
        with patch.object(module, 'events', return_value=0), \
                patch.object(module, 'signal_owned', side_effect=PermissionError('signal failure')), \
                patch.object(module, 'wait_terminal', return_value=observed):
            value = module.cleanup(child, {'leader': 41})
        self.assertFalse(value['complete'])
        self.assertEqual(value['observations'], observed)
        self.assertEqual([e['stage'] for e in value['errors']], ['signal', 'wait'])


if __name__ == '__main__':
    unittest.main(verbosity=2)

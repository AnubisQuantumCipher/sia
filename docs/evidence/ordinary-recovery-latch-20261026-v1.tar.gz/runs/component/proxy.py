"""Fixed creator-death witness; external controller retains transferred cleanup."""
import array
from contextlib import ExitStack
import json
import os
from pathlib import Path
import signal
import socket
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent


def remaining(deadline):
    value = deadline - time.monotonic()
    if value <= 0:
        raise TimeoutError('absolute creator deadline')
    return value


def owned_pidfd(child):
    try:
        return os.pidfd_open(child.pid)
    except OSError as acquisition:
        # This kernel-returned direct child is unreaped. No poll/wait, threads,
        # alternate waiter or SIGCHLD handler can release its PID here.
        disposition = dict(acquisition=str(acquisition))
        try:
            os.kill(child.pid, signal.SIGKILL)
            disposition['signal'] = 'DIRECT_UNREAPED_CHILD_SIGKILL'
        except OSError as error:
            disposition['signal_error'] = str(error)
        try:
            disposition['wait'] = child.wait(timeout=5)
        except (OSError, subprocess.TimeoutExpired) as error:
            disposition['wait_error'] = str(error)
        raise RuntimeError(json.dumps(disposition)) from acquisition


def transfer(out, descriptor, deadline, stack):
    directory = os.open(out, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    stack.callback(os.close, directory)
    with socket.socket(socket.AF_UNIX, socket.SOCK_SEQPACKET) as connection:
        connection.settimeout(remaining(deadline))
        connection.connect('/proc/self/fd/' + str(directory) + '/w.sock')
        payload = json.dumps(dict(role='launcher', controller=os.getpid())).encode()
        connection.settimeout(remaining(deadline))
        size = connection.sendmsg([payload], [(socket.SOL_SOCKET, socket.SCM_RIGHTS,
                                              array.array('i', [descriptor]))])
        connection.settimeout(remaining(deadline))
        if size != len(payload) or connection.recv(16) != b'hold':
            raise ValueError('launcher capability transfer')


def retire(child, descriptor):
    result = {}
    try:
        signal.pidfd_send_signal(descriptor, signal.SIGKILL)
        result['signal'] = 'SENT'
    except ProcessLookupError:
        result['signal'] = 'ALREADY_TERMINAL'
    except OSError as error:
        result['signal_error'] = str(error)
    try:
        result['wait'] = child.wait(timeout=5)
    except (OSError, subprocess.TimeoutExpired) as error:
        result['wait_error'] = str(error)
    print(json.dumps(dict(proxy_cleanup=result)), file=sys.stderr, flush=True)
    if 'signal_error' in result or 'wait_error' in result:
        raise RuntimeError('proxy cleanup incomplete')


def main():
    if sys.argv[1:] != ['controller-death'] or os.getresuid() != (0, 0, 0) \
            or signal.getsignal(signal.SIGCHLD) != signal.SIG_DFL:
        raise ValueError('fixed privileged witness only')
    out = ROOT / 'controller-death'
    command = json.loads((out / 'command.json').read_text())
    deadline = time.monotonic() + 20
    with ExitStack() as stack:
        child = subprocess.Popen(command)
        descriptor = owned_pidfd(child)
        stack.callback(os.close, descriptor)
        try:
            transfer(out, descriptor, deadline, stack)
            code = child.wait(timeout=remaining(deadline))
        finally:
            retire(child, descriptor)
    raise SystemExit(code)


if __name__ == '__main__':
    main()

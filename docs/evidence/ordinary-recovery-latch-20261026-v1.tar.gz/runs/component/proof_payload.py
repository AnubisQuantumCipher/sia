"""Transfer exact leader/reaper handles before the fixed ordinary proof starts."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path


def main():
    config = json.loads(Path('/tmp/proof_config.json').read_text())
    path = Path('/tmp/fixture.py')
    if hashlib.sha256(path.read_bytes()).hexdigest() != config['helper_hashes']['fixture.py']:
        raise ValueError('qualified handshake source changed')
    spec = importlib.util.spec_from_file_location('qualified_fixture', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    with module.connect('leader') as connection:
        if module.receive(connection) != b'prove':
            raise ValueError('proof not admitted')
    os.chdir('/tmp/source')
    os.execve(config['proof_command'][0], config['proof_command'], config['proof_env'])


if __name__ == '__main__':
    main()

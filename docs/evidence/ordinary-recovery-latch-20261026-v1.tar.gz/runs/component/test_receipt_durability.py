"""Ordinary observer receipt IO controls; no native lifecycle admission."""
import errno
import json
import os
from pathlib import Path
import stat
import tempfile
import unittest
from unittest import mock

import receipt_candidate as candidate
import receipt_baseline as baseline


class ReceiptDurability(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        self.patch = mock.patch.object(candidate, 'ROOT', self.root)
        self.patch.start()
        self.addCleanup(self.patch.stop)
        self.value = {'operation': 'fixed-disposable-test', 'authority': 'NONE'}

    def refusal(self, name='active.json'):
        with self.assertRaises(RuntimeError) as caught:
            candidate.save(name, self.value)
        value = json.loads(str(caught.exception))
        self.assertEqual(value['status'], 'UNCERTAIN_DO_NOT_RETRY')
        self.assertEqual(value['receipt'], name)
        return value['errors']

    def test_real_readback_and_existing_receipt_mode(self):
        candidate.save('active.json', self.value)
        path = self.root / 'active.json'
        self.assertEqual(json.loads(path.read_text()), self.value)
        self.assertEqual(stat.S_IMODE(path.stat().st_mode), 0o644)

    def test_baseline_never_synchronizes_parent_directory(self):
        sync = os.fsync
        roles = []
        def observe_sync(fd):
            roles.append('directory' if stat.S_ISDIR(os.fstat(fd).st_mode) else 'file')
            return sync(fd)
        with mock.patch.object(baseline, 'ROOT', self.root), \
                mock.patch.object(baseline.os, 'fsync', side_effect=observe_sync):
            baseline.save('active.json', self.value)
        self.assertEqual(roles, ['file'])

    def test_sync_order_is_file_then_directory_before_close(self):
        sync, close = os.fsync, os.close
        trace = []
        def sync_record(fd):
            trace.append('sync-directory' if stat.S_ISDIR(os.fstat(fd).st_mode) else 'sync-file')
            return sync(fd)
        def close_record(fd):
            trace.append('close-directory' if stat.S_ISDIR(os.fstat(fd).st_mode) else 'close-file')
            return close(fd)
        with mock.patch.object(candidate.os, 'fsync', side_effect=sync_record), \
                mock.patch.object(candidate.os, 'close', side_effect=close_record):
            candidate.save('entry.json', self.value)
        self.assertEqual(trace, ['sync-file', 'sync-directory', 'close-file', 'close-directory'])

    def test_existing_record_is_not_replaced_or_removed(self):
        path = self.root / 'active.json'
        path.write_bytes(b'original-uncertain-operation')
        errors = self.refusal()
        self.assertEqual(errors[0]['stage'], 'create-file')
        self.assertEqual(errors[0]['errno'], errno.EEXIST)
        self.assertEqual(path.read_bytes(), b'original-uncertain-operation')

    def test_receipt_symlink_is_not_followed(self):
        target = self.root / 'target'
        target.write_bytes(b'unchanged')
        (self.root / 'active.json').symlink_to(target)
        self.assertEqual(self.refusal()[0]['stage'], 'create-file')
        self.assertEqual(target.read_bytes(), b'unchanged')

    def test_directory_symlink_is_not_followed(self):
        alias = self.root / 'alias'
        alias.symlink_to(self.root, target_is_directory=True)
        with mock.patch.object(candidate, 'ROOT', alias):
            self.assertEqual(self.refusal()[0]['stage'], 'open-directory')
        self.assertFalse((self.root / 'active.json').exists())

    def test_invalid_name_has_no_io(self):
        with mock.patch.object(candidate.os, 'open') as opened:
            for name in ('../active.json', '/tmp/active.json', 'other.json', b'active.json'):
                with self.subTest(name=name), self.assertRaises(ValueError):
                    candidate.save(name, self.value)
        opened.assert_not_called()

    def test_encoding_failure_retains_uncertain_partial_file(self):
        self.value = {'unsupported': object()}
        errors = self.refusal()
        self.assertEqual(errors[0]['stage'], 'write-file')
        self.assertEqual(errors[0]['type'], 'TypeError')
        self.assertTrue((self.root / 'active.json').is_file())

    def test_directory_open_failure_is_retained(self):
        with mock.patch.object(candidate.os, 'open', side_effect=OSError(errno.EACCES, 'injected')):
            errors = self.refusal()
        self.assertEqual([(row['stage'], row['errno']) for row in errors],
                         [('open-directory', errno.EACCES)])

    def test_short_write_preserves_partial_and_has_no_sync_or_retry(self):
        write = os.write
        def short_write(fd, data):
            return write(fd, data[:0])
        with mock.patch.object(candidate.os, 'write', side_effect=short_write) as written, \
                mock.patch.object(candidate.os, 'fsync') as sync:
            errors = self.refusal()
        self.assertEqual(errors[0]['stage'], 'write-file')
        self.assertEqual(written.call_count, 1)
        sync.assert_not_called()
        self.assertEqual((self.root / 'active.json').stat().st_size, 0)

    def test_sync_failures_never_return_success(self):
        sync = os.fsync
        for failed_role in ('file', 'directory'):
            with self.subTest(role=failed_role):
                def fail_sync(fd, selected=failed_role):
                    role = 'directory' if stat.S_ISDIR(os.fstat(fd).st_mode) else 'file'
                    if role == selected:
                        raise OSError(errno.EIO, 'injected sync')
                    return sync(fd)
                with mock.patch.object(candidate.os, 'fsync', side_effect=fail_sync):
                    errors = self.refusal()
                self.assertEqual(errors[0]['stage'], 'sync-' + failed_role)
                self.assertEqual(json.loads((self.root / 'active.json').read_text()), self.value)
                (self.root / 'active.json').unlink()

    def test_both_close_errors_preserve_primary_write_error(self):
        close = os.close
        trace = []
        def fail_close(fd):
            trace.append(fd)
            close(fd)
            raise OSError(errno.EIO, 'injected close after release')
        with mock.patch.object(candidate.os, 'write', side_effect=OSError(errno.ENOSPC, 'injected')), \
                mock.patch.object(candidate.os, 'close', side_effect=fail_close):
            errors = self.refusal()
        self.assertEqual([row['stage'] for row in errors],
                         ['write-file', 'close-file', 'close-directory'])
        self.assertEqual(errors[0]['errno'], errno.ENOSPC)
        self.assertEqual(len(trace), 2)
        self.assertNotEqual(trace[0], trace[1])

    def test_close_error_alone_refuses_ack(self):
        close = os.close
        def fail_close(fd):
            is_file = stat.S_ISREG(os.fstat(fd).st_mode)
            close(fd)
            if is_file:
                raise OSError(errno.EIO, 'injected close after release')
        with mock.patch.object(candidate.os, 'close', side_effect=fail_close):
            errors = self.refusal()
        self.assertEqual([row['stage'] for row in errors], ['close-file'])

    def test_rebound_parent_refuses_and_preserves_original_record(self):
        write = os.write
        moved = self.root / 'moved'
        original = self.root / 'original'
        original.mkdir()
        def rename_after_write(fd, data):
            size = write(fd, data)
            if not moved.exists():
                original.rename(moved)
                original.mkdir()
            return size
        with mock.patch.object(candidate, 'ROOT', original), \
                mock.patch.object(candidate.os, 'write', side_effect=rename_after_write):
            errors = self.refusal('execution-result.json')
        self.assertEqual(errors[0]['stage'], 'check-directory-after')
        self.assertEqual(json.loads((moved / 'execution-result.json').read_text()), self.value)
        self.assertFalse((original / 'execution-result.json').exists())


if __name__ == '__main__':
    unittest.main()

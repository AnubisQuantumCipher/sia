"""Temporary, fixed, nonhostile namespace cleanup qualification. No product authority."""
import array
from contextlib import ExitStack
import datetime
import fcntl
import hashlib
import json
import os
from pathlib import Path
import select
import signal
import socket
import stat
import struct
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
LOCK = Path('/home/sicarii/.worldline-heavy.lock')
CASES = ('normal', 'launcher-death', 'init-death', 'controller-death')
CAPS = ('CapInh', 'CapPrm', 'CapEff', 'CapBnd', 'CapAmb')
IDENTITY = ('st_dev', 'st_ino', 'st_mode', 'st_uid', 'st_gid', 'st_nlink')


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())


def identity(value):
    return tuple(getattr(value, key) for key in IDENTITY)


def status(pid):
    raw = Path('/proc', str(pid), 'status').read_text()
    return dict(line.split(':', 1) for line in raw.splitlines() if ':' in line)


def namespaces(pid):
    return {key: os.readlink('/proc/' + str(pid) + '/ns/' + key)
            for key in ('pid', 'user', 'net')}


def descriptor_pid(descriptor):
    raw = Path('/proc/self/fdinfo', str(descriptor)).read_text()
    fields = dict(line.split(':', 1) for line in raw.splitlines() if ':' in line)
    pid = int(fields['Pid'])
    if pid <= 0:
        raise ValueError('pidfd has no live task identity')
    return pid


def events(descriptor):
    watcher = select.poll()
    watcher.register(descriptor, select.POLLIN)
    result = watcher.poll(0)
    value = result[0][1] if result else 0
    if value & ~(select.POLLIN | select.POLLHUP):
        raise ValueError('unexpected pidfd poll mask: ' + str(value))
    return value


def signal_owned(descriptor):
    try:
        signal.pidfd_send_signal(descriptor, signal.SIGKILL)
        return 'SIGKILL_SENT'
    except ProcessLookupError:
        return 'ALREADY_TERMINAL'


def owned_pidfd(child):
    try:
        return os.pidfd_open(child.pid)
    except OSError as acquisition:
        # This kernel-returned direct child is unreaped. No poll/wait, threads,
        # alternate waiter or SIGCHLD handler can release its PID here.
        disposition = dict(acquisition=str(acquisition))
        try:
            os.kill(child.pid, signal.SIGKILL)
            disposition['signal'] = 'DIRECT_UNREAPED_CHILD_SIGKILL'
        except OSError as error:
            disposition['signal_error'] = str(error)
        try:
            disposition['wait'] = child.wait(timeout=5)
        except (OSError, subprocess.TimeoutExpired) as error:
            disposition['wait_error'] = str(error)
        raise RuntimeError(json.dumps(disposition)) from acquisition


def validate_source(expected):
    for name, pin in expected.items():
        path = ROOT / name
        meta = path.lstat()
        if not stat.S_ISREG(meta.st_mode) or meta.st_uid != 1000 \
                or meta.st_nlink != 1 or digest(path) != pin:
            raise ValueError('source binding: ' + name)


def validate_tools(config):
    for name, pin in config['tools'].items():
        path = Path(name).resolve()
        meta = path.stat()
        if meta.st_uid != 0 or meta.st_mode & 0o022 or digest(path) != pin:
            raise ValueError('tool binding: ' + name)


def receive(server, stack):
    connection, _ = server.accept()
    stack.enter_context(connection)
    connection.settimeout(5)
    peer = struct.unpack('3i', connection.getsockopt(socket.SOL_SOCKET,
                                                   socket.SO_PEERCRED, 12))
    raw, ancillary, flags, _ = connection.recvmsg(
        8192, socket.CMSG_SPACE(2 * array.array('i').itemsize), socket.MSG_CMSG_CLOEXEC)
    descriptors = []
    for level, kind, payload in ancillary:
        if (level, kind) != (socket.SOL_SOCKET, socket.SCM_RIGHTS):
            raise ValueError('unexpected ancillary record')
        numbers = array.array('i')
        numbers.frombytes(payload)
        for descriptor in numbers:
            stack.callback(os.close, descriptor)
            descriptors.append(descriptor)
    if flags & (socket.MSG_TRUNC | socket.MSG_CTRUNC) or not raw or len(ancillary) != 1:
        raise ValueError('truncated or missing capability record')
    value = json.loads(raw)
    return connection, peer, value, descriptors


def validate_payload(config, peer, value, descriptor, parent):
    pid = descriptor_pid(descriptor)
    if peer != (pid, 1000, 1000) or events(descriptor):
        raise ValueError('peer capability identity')
    observed = status(pid)
    expected = config['expected']
    for field, key in (('Uid', 'proc_uid'), ('Gid', 'proc_gid'), ('Groups', 'groups')):
        if [int(x) for x in observed[field].split()] != expected[key]:
            raise ValueError('host-observed credentials: ' + field)
    for key in ('uid', 'gid', 'groups', 'proc_uid', 'proc_gid'):
        if value[key] != expected[key]:
            raise ValueError('payload credential observation: ' + key)
    if any(int(observed[key], 16) != 0 or int(value['caps'][key], 16) != 0
           for key in CAPS) or observed['NoNewPrivs'].strip() != '1' \
            or value['caps']['NoNewPrivs'] != '1':
        raise ValueError('payload authority retained')
    actual_ns = namespaces(pid)
    if actual_ns != value['namespaces'] or actual_ns['user'] != expected['namespaces']['user'] \
            or any(actual_ns[key] == expected['namespaces'][key] for key in ('pid', 'net')):
        raise ValueError('namespace credential observation')
    if int(observed['PPid']) != parent or actual_ns != namespaces(parent):
        raise ValueError('parent namespace join')
    return pid


def validate_launcher(peer, value, descriptors, proxy_pid):
    if value != dict(role='launcher', controller=proxy_pid) or peer != (proxy_pid, 0, 0) \
            or len(descriptors) != 1:
        raise ValueError('creator capability transfer')
    pid = descriptor_pid(descriptors[0])
    if int(status(pid)['PPid']) != proxy_pid or events(descriptors[0]):
        raise ValueError('creator child join')
    return descriptors[0], pid


def adopt_leader(config, message, launch_pid, handles, peers):
    connection, peer, value, descriptors = message
    if value.get('role') != 'leader' or len(descriptors) != 2:
        raise ValueError('leader record')
    init = descriptor_pid(descriptors[1])
    init_status = status(init)
    if int(init_status['NSpid'].split()[-1]) != 1 \
            or int(init_status['PPid']) != launch_pid or events(descriptors[1]):
        raise ValueError('namespace reaper join')
    leader = validate_payload(config, peer, value, descriptors[0], init)
    handles.update(init=descriptors[1], leader=descriptors[0])
    peers.append(dict(role='leader', peer=peer, pid=leader, init=init, value=value))
    return connection, leader


def command_for(config, out):
    return config['namespace_prefix'] + [
        '--ro-bind', str(ROOT / 'fixture.py'), '/tmp/fixture.py',
        '--bind', str(out), '/tmp/out'] + config['payload']


def server_for(out, stack):
    directory = os.open(out, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    stack.callback(os.close, directory)
    server = stack.enter_context(socket.socket(socket.AF_UNIX, socket.SOCK_SEQPACKET))
    server.bind('/proc/self/fd/' + str(directory) + '/w.sock')
    os.chown(out / 'w.sock', 1000, 1000, follow_symlinks=False)
    os.chmod(out / 'w.sock', 0o600)
    server.listen(4)
    server.settimeout(5)
    return server


def launch_case(config, case, out, stack, handles):
    command = command_for(config, out)
    save(out / 'command.json', command)
    if case == 'controller-death':
        command = ['/usr/bin/python3', '-I', '-B', str(ROOT / 'proxy.py'), case]
    stdout = stack.enter_context((out / 'stdout').open('xb'))
    stderr = stack.enter_context((out / 'stderr').open('xb'))
    child = subprocess.Popen(command, stdout=stdout, stderr=stderr)
    descriptor = owned_pidfd(child)
    stack.callback(os.close, descriptor)
    handles['proxy' if case == 'controller-death' else 'launcher'] = descriptor
    return child


def acquire(config, case, server, child, stack, handles, peers):
    first = receive(server, stack)
    launch_pid = child.pid
    leader_message = first
    if case == 'controller-death':
        second = receive(server, stack)
        launcher_message = first if first[2].get('role') == 'launcher' else second
        leader_message = second if launcher_message is first else first
        connection, peer, value, descriptors = launcher_message
        handles['launcher'], launch_pid = validate_launcher(peer, value, descriptors, child.pid)
        if connection.send(b'hold') != 4:
            raise ValueError('creator hold transfer')
    connection, parent = adopt_leader(config, leader_message, launch_pid, handles, peers)
    leader_connection = connection
    for role, command in (('child', b'fork'), ('grandchild', b'fork')):
        if connection.send(command) != len(command):
            raise ValueError('fork admission transfer')
        connection, peer, value, descriptors = receive(server, stack)
        if value.get('role') != role or len(descriptors) != 1:
            raise ValueError('descendant record')
        parent = validate_payload(config, peer, value, descriptors[0], parent)
        handles[role] = descriptors[0]
        peers.append(dict(role=role, peer=peer, pid=parent, value=value))
    if connection.send(b'hold') != 4 or any(events(fd) for fd in handles.values()):
        raise ValueError('lineage not live at intervention')
    return leader_connection


def wait_terminal(handles, seconds):
    end = time.monotonic() + seconds
    observations = {name: events(fd) for name, fd in handles.items()}
    for _ in range(501):
        if all(value & select.POLLHUP for value in observations.values()):
            break
        remaining = end - time.monotonic()
        if remaining <= 0:
            break
        time.sleep(min(0.01, remaining))
        observations = {name: events(fd) for name, fd in handles.items()}
    return {name: dict(mask=value, terminal=bool(value & select.POLLIN),
                       reaped=bool(value & select.POLLHUP))
            for name, value in observations.items()}


def cleanup(child, handles):
    result = dict(signals={}, errors=[], complete=False)
    for name, descriptor in handles.items():
        try:
            if not events(descriptor):
                result['signals'][name] = signal_owned(descriptor)
        except (OSError, ValueError) as error:
            result['errors'].append(dict(stage='signal', role=name, error=str(error)))
    try:
        result['waited'] = child.wait(timeout=5)
    except (OSError, subprocess.TimeoutExpired) as error:
        result['errors'].append(dict(stage='wait', error=str(error)))
    try:
        result['observations'] = wait_terminal(handles, 5)
    except (OSError, ValueError) as error:
        result['errors'].append(dict(stage='observe', error=str(error)))
    result['complete'] = not result['errors'] and bool(handles) and all(
        item['terminal'] and item['reaped'] for item in result['observations'].values())
    return result


def exercise(config, case, out, stack, result, handles):
    server = server_for(out, stack)
    child = launch_case(config, case, out, stack, handles)
    result['owned_child'] = child.pid
    try:
        leader = acquire(config, case, server, child, stack, handles, result['peers'])
        if case == 'normal':
            if leader.send(b'exit') != 4:
                raise ValueError('normal exit command')
            result['intervention'] = 'LEADER_EXIT_REQUEST'
        else:
            target = {'launcher-death': 'launcher', 'init-death': 'init',
                      'controller-death': 'proxy'}[case]
            result['intervention'] = dict(role=target, result=signal_owned(handles[target]))
        result['waited'] = child.wait(timeout=5)
        result['observations'] = wait_terminal(handles, 5)
        passed = all(value['terminal'] and value['reaped']
                     for value in result['observations'].values())
        expected_wait = {'normal': 0, 'launcher-death': -signal.SIGKILL,
                         'controller-death': -signal.SIGKILL}
        code_ok = result['waited'] == expected_wait[case] if case in expected_wait \
            else result['waited'] != 0
        if not passed or not code_ok:
            raise ValueError('terminal/reap or normal exit contract')
    finally:
        result['cleanup'] = cleanup(child, handles)
    if not result['cleanup']['complete']:
        raise ValueError('cleanup incomplete')
    result['status'] = 'TESTED_PASS_FIXED_LINEAGE'


def run_case(config, case):
    out = ROOT / case
    meta = out.lstat()
    if not stat.S_ISDIR(meta.st_mode) or meta.st_uid != 1000 or meta.st_mode & 0o077:
        raise ValueError('case directory ownership')
    result = dict(case=case, status='FAILED_OR_INCOMPLETE', peers=[],
                  started=datetime.datetime.now(datetime.timezone.utc).isoformat())
    with ExitStack() as stack:
        handles = {}
        try:
            exercise(config, case, out, stack, result, handles)
        except (OSError, ValueError, RuntimeError, subprocess.TimeoutExpired) as error:
            result['status'] = 'FAILED_OR_INCOMPLETE'
            result['error'] = dict(type=type(error).__name__, message=str(error))
        result['finished'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        save(out / 'result.json', result)
    print(json.dumps(result), flush=True)
    return result.get('status') == 'TESTED_PASS_FIXED_LINEAGE' \
        and result.get('cleanup', {}).get('complete') is True


def hold_lock(stack):
    descriptor = os.open(LOCK, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
    stack.callback(os.close, descriptor)
    meta = os.fstat(descriptor)
    if not stat.S_ISREG(meta.st_mode) or meta.st_uid != 1000 or meta.st_nlink != 1 \
            or identity(meta) != identity(LOCK.lstat()):
        raise ValueError('heavy lock identity')
    fcntl.flock(descriptor, fcntl.LOCK_EX | fcntl.LOCK_NB)
    return meta


def main():
    if len(sys.argv) != 2 or os.getresuid() != (0, 0, 0) \
            or signal.getsignal(signal.SIGCHLD) != signal.SIG_DFL:
        raise ValueError('fixed root qualification invocation required')
    if digest(ROOT / 'source.json') != sys.argv[1]:
        raise ValueError('reviewed manifest mismatch')
    source = json.loads((ROOT / 'source.json').read_text())
    config = json.loads((ROOT / 'config.json').read_text())
    validate_source(source)
    validate_tools(config)
    if config['cases'] != list(CASES) or namespaces(os.getpid()) != config['expected']['namespaces']:
        raise ValueError('case roster or parent namespace changed')
    if config['fixture_deadline_seconds'] != 20 or config['observation_deadline_seconds'] != 5:
        raise ValueError('fixed deadline declaration changed')
    if digest(Path('/etc/machine-id')) != config['machine_id_sha256'] \
            or digest(Path('/proc/sys/kernel/random/boot_id')) != config['boot_id_sha256'] \
            or os.uname().nodename != config['hostname']:
        raise ValueError('designated host changed')
    with ExitStack() as stack:
        meta = hold_lock(stack)
        save(ROOT / 'entry.json', dict(source=source, host=os.uname().nodename,
                                      kernel=list(os.uname()), lock=identity(meta)))
        results = []
        for case in CASES:
            passed = run_case(config, case)
            results.append(dict(case=case, passed=passed))
            if not passed:
                break
        validate_source(source)
        validate_tools(config)
        if identity(meta) != identity(LOCK.lstat()):
            raise ValueError('heavy lock changed')
        save(ROOT / 'result.json', dict(cases=results, authority='NONE',
                                       status='TESTED_PASS' if len(results) == 4
                                       and all(x['passed'] for x in results) else 'NONPASS'))
    if len(results) != 4 or not all(x['passed'] for x in results):
        raise SystemExit(1)


if __name__ == '__main__':
    main()

"""Build or reproduce the explicit, bounded non-final evidence package."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import sys
import tarfile

ROOT = Path(__file__).parent
PUBLISHER = Path('/home/sicarii/Work/sia-assurance-checkpoint-20261023')
ARCHIVE = PUBLISHER / 'docs/evidence/r05-executable-gate-20261025.tar.gz'
METADATA = PUBLISHER / 'docs/R05-EXECUTABLE-GATE-RESTORATION-20261025.json'
NAMES = (
    'build_evidence.py', 'run.py', 'preparation.json', 'inputs.json',
    'result.json', 'stdout', 'stderr', 'static-result.json',
    'static.stdout', 'static.stderr', 'original-test_retained_image_memo.py',
    'experimental-test_retained_image_memo.py', 'test_retained_image_memo.py',
    'independent-source-review.txt', 'fetch-observation.txt', 'arithmetic.json',
)


def package():
    manifest, content, total = {}, {}, 0
    for name in NAMES:
        with (ROOT / name).open('rb') as stream:
            raw = stream.read(2097153)
        total += len(raw)
        if len(raw) > 2097152 or total > 8388608:
            raise ValueError('evidence byte capacity')
        content[name] = raw
        manifest[name] = dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())
    content['MANIFEST.json'] = (json.dumps(manifest, indent=2, sort_keys=True) + '\n').encode()
    output = io.BytesIO()
    with gzip.GzipFile(filename='', mode='wb', fileobj=output, mtime=0) as zipped:
        with tarfile.open(fileobj=zipped, mode='w', format=tarfile.USTAR_FORMAT) as archive:
            for name, raw in sorted(content.items()):
                entry = tarfile.TarInfo(name)
                entry.mode, entry.size = 0o644, len(raw)
                archive.addfile(entry, io.BytesIO(raw))
    return output.getvalue(), manifest


def main():
    if sys.argv[1:] not in ([], ['--check']):
        raise ValueError('only --check is supported')
    archive, manifest = package()
    metadata = dict(
        status='TEST_GATE_RESTORED_R05_FAILED_NONFINAL',
        tested_base='01ad7fff8bef8e202fe00b4e723edcf4e34e7084',
        original_test_commit='ec713cacd2ff77905996e55b9f245bce88897b55',
        runtime='16 tests in55.763s; exit1; original reuse assertion FAILED; no skips/errors',
        current_policy='Separate current-context, source-checkpoint and preflight controls PASS',
        static='Frozen167-rule partial profile, exit0, zero findings; no whole-tree claim',
        archive=ARCHIVE.name, archive_bytes=len(archive),
        archive_sha256=hashlib.sha256(archive).hexdigest(), members=manifest,
        review='ActualGPT6.1 read-only source review; no independent execution',
        limitations='Later original method assertions unreachable after failure. No runtime repair, R05 closure, install or release.')
    encoded = (json.dumps(metadata, indent=2, sort_keys=True) + '\n').encode()
    if sys.argv[1:]:
        if ARCHIVE.read_bytes() != archive or METADATA.read_bytes() != encoded:
            raise ValueError('package reproduction mismatch')
    else:
        with ARCHIVE.open('xb') as stream:
            stream.write(archive)
        with METADATA.open('xb') as stream:
            stream.write(encoded)
    print(json.dumps({'status': 'MATCH' if sys.argv[1:] else 'CREATED',
                      'archive_sha256': metadata['archive_sha256']}))


if __name__ == '__main__':
    main()

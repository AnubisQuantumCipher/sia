"""Run the restored reuse gate beside unchanged current-policy controls."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import time

OUT = Path(__file__).parent
SOURCE = Path('/home/sicarii/Work/sia-assurance-checkpoint-20261023')
HEAD = '01ad7fff8bef8e202fe00b4e723edcf4e34e7084'
ROSTER = ['tests.test_retained_image_memo',
          'tests.test_retained_validation_context',
          'tests.test_retained_validation_preflight']


def read_json(path):
    with path.open('rb') as stream:
        raw = stream.read(2097153)
    if len(raw) > 2097152:
        raise ValueError('receipt capacity')
    return json.loads(raw)


def hashes(paths):
    result = {}
    if len(paths) > 2048:
        raise ValueError('inventory capacity')
    for path in sorted(paths):
        if path.stat().st_size > 134217728:
            raise ValueError('input capacity')
        with path.open('rb') as stream:
            result[str(path)] = hashlib.file_digest(stream, 'sha256').hexdigest()
    return result


def prepare():
    receipt_path = OUT.parent / 'r05-fresh-delivery-capture-v1/workload-result.json'
    receipt = read_json(receipt_path)
    command = list(receipt['command'])
    old = '/home/sicarii/Work/sia-note-boundary-checkpoint-20261024'
    if command.count(old) != 1 or command.count('60s') != 1:
        raise ValueError('unexpected original envelope')
    command[command.index(old)] = str(SOURCE)
    position = command.index('--unshare-net')
    command[position:position] = [
        '--ro-bind', str(OUT / 'test_retained_image_memo.py'),
        '/tmp/sia-review-source/tests/test_retained_image_memo.py']
    prefix, suffix = command[-1].split('loadTestsFromNames(', 1)
    _old_roster, ending = suffix.split('); result=', 1)
    command[-1] = prefix + 'loadTestsFromNames(' + repr(ROSTER) + '); result=' + ending
    tracked = subprocess.check_output(['/usr/bin/git', '-C', str(SOURCE),
        'ls-files', '-z', '--', 'bin', 'tests', 'scripts', 'VERSION'], timeout=10)
    paths = {SOURCE / name.decode() for name in tracked.split(b'\0') if name}
    paths.update(OUT / name for name in ('run.py', 'test_retained_image_memo.py',
        'original-test_retained_image_memo.py',
        'experimental-test_retained_image_memo.py', 'preparation.json'))
    paths.add(receipt_path)
    paths.update(Path(name) for name in command if name.startswith('/usr/bin/'))
    paths.add(Path('/home/sicarii/Documents/sia-repository-audit-20261024/git-review-executable'))
    return command, receipt['environment'], paths


def main():
    command, environment, paths = prepare()
    head = subprocess.check_output(['/usr/bin/git', '-C', str(SOURCE),
                                    'rev-parse', 'HEAD'], timeout=10).decode().strip()
    if head != HEAD or shutil.disk_usage(OUT).free < 11073741824:
        raise ValueError('source or storage admission failed')
    before = hashes(paths)
    record = dict(command=command, environment=environment, base_commit=head,
                  before=before, scope='Endpoint pins, not loaded-code custody')
    with (OUT / 'inputs.json').open('x') as stream:
        json.dump(record, stream, indent=2)
        stream.write('\n')
    started = time.monotonic_ns()
    with (OUT / 'stdout').open('xb') as stdout, \
            (OUT / 'stderr').open('xb') as stderr:
        completed = subprocess.run(command, env=environment, stdout=stdout,
                                   stderr=stderr, check=False)
    after = hashes(paths)
    record.update(after=after, unchanged=before == after,
                  exit=completed.returncode, elapsed_ns=time.monotonic_ns() - started)
    with (OUT / 'result.json').open('x') as stream:
        json.dump(record, stream, indent=2)
        stream.write('\n')
    print(json.dumps({key: record[key] for key in ('unchanged', 'exit', 'elapsed_ns')}))
    if not record['unchanged'] or completed.returncode:
        raise SystemExit(1)


if __name__ == '__main__':
    main()

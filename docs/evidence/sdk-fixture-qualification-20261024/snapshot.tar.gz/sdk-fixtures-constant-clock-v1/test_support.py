"""SAVED_UNRUN OWN-pinned fixture support; no SDK admission or execution grant.

Root must verify the complete active OWN map and exact source endpoints before
admitting this loader. Trusted interpreter/importlib semantics are ASSUMED.
"""
import hashlib
import importlib.machinery
import importlib.util
import json
import os
import sys
from unittest.mock import patch

import _frozen_importlib as bootstrap
import _frozen_importlib_external as external

ROOT = '/home/sicarii/Work/sia-assurance-evidence-20261019/ownership-transfer-20261024/sdk-fixtures-constant-clock-v1/'
IDENTITY_FIELDS = ('st_dev', 'st_ino', 'st_mode', 'st_nlink', 'st_uid',
                   'st_gid', 'st_size', 'st_mtime_ns', 'st_ctime_ns')
SOURCE_LIMIT = 1048576


class LoadFailure(RuntimeError):
    """Retain actual primary/independent once-close error without rendering."""
    __slots__ = ('primary', 'secondary')

    def __init__(self):
        super().__init__('OWN test loader primary and close failure')
        self.primary, self.secondary = None, None


def close_once(fd):
    result = os.close(fd)
    if result is not None:
        raise ValueError('OWN test loader close status')


def verify_identity(observed, expected):
    if type(expected) is not dict or set(expected) != set(IDENTITY_FIELDS):
        raise ValueError('OWN test loader full9 identity schema')
    for field in IDENTITY_FIELDS:
        if type(expected[field]) is not int:
            raise ValueError('OWN test loader exact identity integer')
        if getattr(observed, field) != expected[field]:
            raise ValueError('OWN test loader identity mismatch')


def read_checked(path, expected=None, want_text=False):
    """Preallocate digest/fault owner; explicit EOF and one independent close."""
    digest, failure = hashlib.sha256(), LoadFailure()
    fd, primary, secondary = None, None, None
    pieces, used, before, after = [], 0, None, None
    try:
        fd = os.open(path, os.O_RDONLY | os.O_CLOEXEC | os.O_NOFOLLOW)
        before = os.fstat(fd)
        if before.st_size < 0 or before.st_size > SOURCE_LIMIT:
            raise ValueError('OWN test loader size bound')
        if expected is not None:
            verify_identity(before, expected['identity'])
        for _ in range(1025):
            chunk = os.read(fd, min(65536, SOURCE_LIMIT + 1 - used))
            if type(chunk) is not bytes:
                raise ValueError('OWN test loader exact bytes')
            if not chunk:
                break
            used += len(chunk)
            if used > SOURCE_LIMIT:
                raise ValueError('OWN test loader read bound')
            digest.update(chunk)
            if want_text:
                pieces.append(chunk)
        else:
            raise ValueError('OWN test loader missing EOF')
        after = os.fstat(fd)
        if used != before.st_size:
            raise ValueError('OWN test loader file size disagreement')
        if expected is not None:
            verify_identity(after, expected['identity'])
            if digest.hexdigest() != expected['sha256']:
                raise ValueError('OWN test loader SHA mismatch')
        else:
            for field in IDENTITY_FIELDS:
                if getattr(before, field) != getattr(after, field):
                    raise ValueError('OWN test loader unpinned file changed')
    except BaseException as error:
        primary = error
    finally:
        if fd is not None:
            try:
                close_once(fd)
            except BaseException as error:
                secondary = error
    if primary is not None and secondary is not None:
        failure.primary, failure.secondary = primary, secondary
        raise failure from primary
    if primary is not None:
        raise primary
    if secondary is not None:
        raise secondary
    if expected is not None:
        verify_identity(os.lstat(path), expected['identity'])
    return b''.join(pieces) if want_text else None


def own_map():
    value = json.loads(read_checked(ROOT + 'OWN-SOURCE.json', want_text=True))
    if type(value) is not dict:
        raise ValueError('OWN test loader map exact dict')
    if value.get('schema') != 'sia.prospective-own-source-origins.v1':
        raise ValueError('OWN test loader map schema')
    files = value.get('files')
    if type(files) is not dict:
        raise ValueError('OWN test loader files exact dict')
    return files


def load_owned(name, filename, files):
    expected = files[filename]
    if type(expected) is not dict or set(expected) != {'identity', 'sha256'}:
        raise ValueError('OWN test loader source row schema')
    sha = expected['sha256']
    if (type(sha) is not str or len(sha) != 64
            or any(character not in '0123456789abcdef' for character in sha)):
        raise ValueError('OWN test loader SHA shape')
    path = ROOT + filename
    read_checked(path, expected)
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError('OWN test loader source loader unavailable')
    result = importlib.util.module_from_spec(spec)
    # Root separately admits this prospective load; no sys.modules registration.
    spec.loader.exec_module(result)
    read_checked(path, expected)
    return result


OWN_FILES = own_map()
CHECKER = load_owned('sia_checker_v2', 'production_checker.py', OWN_FILES)
PROBE = load_owned('sia_probe_v2', 'origin_probe.py', OWN_FILES)


def fixture_modules():
    """Actual stdlib classes; fixture dictionary never installed into sys."""
    module_type = type(sys)
    errors, model = module_type('pyexpat.errors'), module_type('pyexpat.model')
    producer, wrapper = module_type('pyexpat'), module_type('xml.parsers.expat')
    rows = ((producer, 'pyexpat', CHECKER.DERIVED_SO, '',
             external.ExtensionFileLoader, None),
            (wrapper, 'xml.parsers.expat', CHECKER.DERIVED_PY, 'xml.parsers',
             external.SourceFileLoader, CHECKER.DERIVED_PYC))
    for module, name, path, package, loader_type, cached in rows:
        loader = loader_type(name, path)
        spec = bootstrap.ModuleSpec(name, loader, origin=path)
        spec._set_fileattr, spec._initializing, spec._cached = True, False, cached
        module.__file__, module.__package__ = path, package
        module.__loader__, module.__spec__ = loader, spec
        module.errors, module.model = errors, model
        if cached is not None:
            module.__cached__ = cached
    wrapper.sys = sys
    return {'_frozen_importlib': bootstrap, 'importlib._bootstrap': bootstrap,
            '_frozen_importlib_external': external,
            'importlib._bootstrap_external': external,
            'importlib.machinery': importlib.machinery,
            'pyexpat': producer, 'xml.parsers.expat': wrapper,
            'pyexpat.errors': errors, 'pyexpat.model': model,
            'xml.parsers.expat.errors': errors, 'xml.parsers.expat.model': model}


def zero_clock():
    """Fixed fixture time without retaining a history of every clock call."""
    return 0


class Harness:
    """One live checker/fixture; closed cleanup shells retain no module graph."""

    def __init__(self, case):
        self.case = case
        self.state, self.checker, self.modules = None, None, None
        self._clock, self._native_patch = None, None
        self._closed, self._positive = False, False
        case.addCleanup(self.close)
        self._clock = patch.object(CHECKER.time, 'monotonic_ns', zero_clock)
        self._clock.start()
        self.state = PROBE.ProbeState()
        self.state.work, self.state.total = 1, 5000000001
        self.modules = fixture_modules()
        self.checker = CHECKER.build_checker(self.state)
        self._native_patch = self.native_sys()
        self._native_patch.start()
        self.checker.graph()
        self.checker.graph(recheck=True)

    def native_sys(self):
        original = CHECKER.DerivedChecker.native
        harness = self
        def native(checker, role, descriptor, receiver, owner, name):
            result = original(checker, role, descriptor, receiver, owner, name)
            if (checker is harness.checker and role == 'MODULE_NAMESPACE'
                    and receiver is checker.refs.sys_actual):
                result = dict(result)
                result['modules'] = harness.modules
            return result
        return patch.object(CHECKER.DerivedChecker, 'native', native)

    def positive(self):
        if self._closed or self._positive:
            raise RuntimeError('fixture positive requires live unvisited census')
        self.checker.graph()
        self.checker.graph(recheck=True)
        self.checker.census(lambda path: path, lambda path: True)
        self.checker.graph(recheck=True)
        self.checker.final_roster()
        self.case.assertEqual(self.state.used, 0)
        self.case.assertFalse(self.state.overflow)
        self._positive = True
        return self

    def error(self, action, exact_message, phase):
        caught = None
        try:
            action()
        except ValueError as error:
            caught = error
        self.case.assertIs(type(caught), ValueError)
        self.case.assertEqual(caught.args, (exact_message,))
        self.case.assertEqual(self.state.stage, phase)
        return caught

    def fresh(self):
        case = self.case
        self.close()
        return Harness(case)

    def close(self):
        if self._closed:
            return
        self._closed = True
        try:
            if self.checker is not None:
                self.checker.clear()
        finally:
            try:
                if self._native_patch is not None:
                    self._native_patch.stop()
            finally:
                try:
                    if self._clock is not None:
                        self._clock.stop()
                finally:
                    self.checker, self.state, self.modules = None, None, None
                    self._clock, self._native_patch = None, None

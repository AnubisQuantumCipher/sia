"""Bounded diagnostic of one original positive fixture, not suite acceptance."""
import cProfile
import json
import sys
import time
import unittest

FIXTURE = '/home/sicarii/Work/sia-assurance-evidence-20261019/ownership-transfer-20261024/sdk-fixtures-constant-clock-v1'
sys.path.insert(0, FIXTURE)


def exercise():
    from test_support import Harness
    case = unittest.TestCase()
    try:
        harness = Harness(case)
        harness.positive()
        if harness.state.used or harness.state.overflow:
            raise RuntimeError('positive fixture retained an error')
    finally:
        case.doCleanups()


def main():
    profiler = cProfile.Profile()
    started = time.perf_counter_ns()
    profiler.runcall(exercise)
    elapsed = time.perf_counter_ns() - started
    statistics = profiler.getstats()
    if len(statistics) > 4096:
        raise RuntimeError('diagnostic function roster capacity')
    rows = []
    for entry in statistics:
        code = entry.code
        location = (code if type(code) is str
                    else code.co_filename + ':' + str(code.co_firstlineno)
                    + ':' + code.co_name)
        rows.append({'location': location, 'calls': entry.callcount,
                     'recursive_calls': entry.reccallcount,
                     'own_seconds': entry.inlinetime,
                     'cumulative_seconds': entry.totaltime})
    rows.sort(key=lambda item: item['cumulative_seconds'], reverse=True)
    print(json.dumps({'status': 'OBSERVED_ONE_ORIGINAL_POSITIVE_FIXTURE',
                      'elapsed_ns': elapsed, 'functions': rows}, indent=2))


if __name__ == '__main__':
    main()

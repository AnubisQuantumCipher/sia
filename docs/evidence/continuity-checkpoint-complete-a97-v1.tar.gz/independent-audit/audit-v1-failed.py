#!/usr/bin/env python3
"""Post-run bounded file audit only; never execute a build, test, proof or lock."""
from pathlib import Path
import collections
import hashlib
import json
import os
import re
import tarfile
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parent
EVIDENCE = ROOT.parent
RUN = EVIDENCE / "takeover-checkpoint-complete-a97-v1"
PREP = EVIDENCE / "takeover-checkpoint-complete-a97-preparation-v1"
TARGET = "spark/tests/continuity_checkpoint_wire_tests.adb"
PIN = "9bd84d19ae2e9907c7129f1e555bf45f9e162eac"
SOURCE = "a97d60c565d5d2381628d6df50889395d89d9fd35ac48ff02adf03f9f5c5a738"
ARCHIVE = "49d06e57ec3aa182c75260c0c2c283e3249421ac0da83ac607e004fba36c783d"
PROJECT = "d439a1e2908c70643c951d296294a87c3ba2756be6b1d0bb4c9a6bd4814ebe49"
PREP_BINDING = "524f002fb549a5305c277ccaf57426dd10de6e8f7490a3b11ec40809ea326c44"
RUNTIMES = ("policy", "transaction", "request_wire", "request_admission",
            "grant_lifetime", "retraction", "consolidation", "continuity",
            "continuity_transition", "continuity_record_wire",
            "continuity_observation_wire", "continuity_checkpoint_wire",
            "continuity_current_wire", "continuity_frame_wire",
            "continuity_response_wire")
INPUTS = {}


def require(value, message):
    if not value:
        raise ValueError(message)


def sha(path):
    require(path.is_file() and not path.is_symlink(), "hash input type: " + str(path))
    require(path.stat().st_size <= 536_870_912, "hash byte bound")
    value = hashlib.sha256()
    with path.open("rb") as stream:
        for _count in range(8193):
            data = stream.read(65536)
            if not data:
                result = value.hexdigest()
                INPUTS[str(path)] = {"bytes": path.stat().st_size, "sha256": result}
                return result
            value.update(data)
    raise ValueError("hash iteration bound")


def read(path, bound=33_554_432):
    sha(path)
    with path.open("rb") as stream:
        data = stream.read(bound + 1)
    require(len(data) <= bound, "read bound")
    return data


def pairs(items):
    result = {}
    for key, value in items:
        require(key not in result, "duplicate JSON key")
        result[key] = value
    return result


def decoded(path):
    return json.loads(read(path), object_pairs_hook=pairs)


def save(name, value):
    (ROOT / name).write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")


def exact_roster(directory, expected):
    actual = {}
    for count, (current, directories, files) in enumerate(os.walk(directory, followlinks=False)):
        require(count < 1024 and len(actual) + len(files) <= 4096, "inventory bound")
        require(all(not (Path(current) / name).is_symlink() for name in directories), "symlink directory")
        for name in files:
            path = Path(current) / name
            actual[str(path.relative_to(directory))] = sha(path)
    require(actual == expected, "complete generated/output roster mismatch")
    return len(actual)


def preparations():
    require(sha(PREP / "preparation-binding.json") == PREP_BINDING, "prepared binding changed")
    binding = decoded(PREP / "preparation-binding.json")
    require(len(binding["files"]) == 19, "prepared member roster changed")
    for row in binding["files"]:
        path = PREP / row["path"]
        require(sha(path) == row["sha256"] and path.stat().st_size == row["bytes"], "prepared member changed")
    for name in ("driver.py", "launch.sh"):
        require(sha(RUN / name) == sha(PREP / name), "executed prepared file changed")
    authorization = decoded(EVIDENCE / "takeover-checkpoint-complete-a97-root-authorization-v1.json")
    require(authorization["binding_sha256"] == PREP_BINDING and authorization["source"] == SOURCE, "root authorization mismatch")
    return {"binding_sha256": PREP_BINDING, "explicit_members": len(binding["files"]),
            "root_authorization": authorization, "preparer": "manifest_takeover_review",
            "pre_run_independent_runner_review_claimed": False}


def sources():
    require(sha(RUN / "source.tar") == ARCHIVE, "exact9bd archive mismatch")
    expected = decoded(RUN / "archive-correspondence.json")
    found = {}
    with tarfile.open(RUN / "source.tar", "r:") as bundle:
        members = bundle.getmembers()
        require(len(members) <= 4096, "archive member bound")
        for member in members:
            if member.isdir():
                continue
            require(member.isfile() and member.name in expected and member.name not in found, "unexpected archive member")
            stream = bundle.extractfile(member)
            require(stream is not None, "archive member unreadable")
            with stream:
                data = stream.read(536_870_913)
            require(len(data) <= 536_870_912, "archive member byte bound")
            found[member.name] = {"sha256": hashlib.sha256(data).hexdigest(),
                "git_blob": hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()}
    require(found == expected, "archive member/byte/Git correspondence mismatch")
    wanted = {name: row["sha256"] for name, row in expected.items()}
    wanted[TARGET] = SOURCE
    before, after = decoded(RUN / "source-hashes-before.json"), decoded(RUN / "source-hashes-after.json")
    require(before == after == wanted, "not exact9bd plus onlya97 stable sources")
    require(all(sha(RUN / "source" / name) == value for name, value in wanted.items()), "source readback mismatch")
    require(sha(RUN / "source/spark/sia_assurance.gpr") == PROJECT, "project differs")
    for name in ("source-roster.json", "base-checkpoint-9bd.adb", "checkpoint-9bd-to-a97.patch"):
        require(sha(RUN / name) == sha(PREP / name), "frozen source context mismatch")
    require(sha(RUN / "overlay-continuity_checkpoint_wire_tests.adb") == SOURCE, "overlay changed")
    outputs = exact_roster(RUN / "source", decoded(RUN / "source-output-hashes.json"))
    return {"base_commit": PIN, "archive_sha256": ARCHIVE, "only_overlay": {TARGET: SOURCE},
            "archived_members_verified": len(expected), "source_files_stable": len(wanted),
            "complete_source_output_roster_verified": outputs, "unrelated_worktree_changes_copied": False}


def tools():
    before, after = decoded(RUN / "tool-hashes-before.json"), decoded(RUN / "tool-hashes-after.json")
    require(before == after == decoded(PREP / "expected-tool-pins.json"), "tool pin maps differ")
    require(all(sha(Path(name)) == value for name, value in before.items()), "actual tool readback differs")
    paths = decoded(RUN / "tool-paths.json")
    for name, path in paths.items():
        require(path in before, "resolved tool not pinned: " + name)
    for name in ("gnatprove", "gprbuild", "gnatls", "gcc"):
        require(decoded(RUN / (name + "-version.command.json")) == [paths[name], "--version"], "version command mismatch")
        require(read(RUN / (name + "-version.exit")) == b"0\n", "version command failed")
        read(RUN / (name + "-version.stdout"))
        require(read(RUN / (name + "-version.stderr")) == b"", "version command stderr")
    return {"paths": paths, "before_after_and_actual_readback": "MATCH", "hash_map": before}


def sequence(paths):
    receipt = decoded(RUN / "receipt.json")
    require(receipt["base_commit"] == PIN and receipt["only_overlay"] == {TARGET: SOURCE}, "receipt source mismatch")
    proof = [paths["gnatprove"], "-P", "spark/sia_assurance.gpr", "-u", "continuity_checkpoint_wire_tests.adb",
             "--mode=all", "--assumptions", "--no-inlining", "--memlimit=512", "--timeout=10", "-j1"]
    specs = [("strict-build", "120s", [paths["gprbuild"], "-p", "-j1", "-P", "spark/sia_assurance.gpr"])]
    specs += [(name + "-runtime", "30s", ["spark/bin/" + name + "_tests"]) for name in RUNTIMES]
    specs += [("complete-checkpoint-harness", "120s", proof)]
    require([row["name"] for row in receipt["checks"]] == [s[0] for s in specs], "missing/extra/reordered stage")
    for result, (name, seconds, args) in zip(receipt["checks"], specs, strict=True):
        stage = RUN / name
        command = [paths["timeout"], "--kill-after=5s", seconds] + args
        require(decoded(stage / "command.json") == result["command"] == command, "actual command mismatch")
        require(decoded(stage / "result.json") == result and read(stage / "exit") == b"0\n", "stage result mismatch")
        require(result["exit"] == 0 and result["passed"] is True, "actual stage did not pass")
        require(result["elapsed_seconds"] < int(seconds[:-1]), "stage exceeded outer bound")
        seal = decoded(stage / "input-seal.json")
        wanted = {"overlay_sha256": SOURCE, "project_sha256": PROJECT,
                  "driver_sha256": sha(PREP / "driver.py"), "source_roster_sha256": sha(PREP / "source-roster.json"),
                  "source_map_sha256": sha(RUN / "source-hashes-before.json")}
        require(seal == wanted, "stage input seal mismatch")
        stdout, stderr = read(stage / "stdout"), read(stage / "stderr")
        if name.endswith("-runtime"):
            require(stdout == stderr == b"", "runtime produced diagnostics")
        elif name == "strict-build":
            require(stderr == b"" and b"warning" not in stdout.lower(), "strict build diagnostics")
    require(receipt["complete_campaign_passed"] is True, "campaign reported incomplete")
    project = read(RUN / "source/spark/sia_assurance.gpr").decode()
    for name in RUNTIMES:
        require('"' + name + '_tests.adb"' in project, "original runtime not in unchanged project")
    return receipt


def normalized(text):
    return re.sub(r"\s+", "", text)


def pragmas(text):
    pattern = r"(?m)^[ \t]*pragma[ \t]+(Assert|Loop_Invariant)\b[\s\S]*?;"
    return [{"kind": match[1], "line": text.count("\n", 0, match.start()) + 1,
             "text": match[0], "normalized": normalized(match[0])} for match in re.finditer(pattern, text)]


def preservation():
    old = read(RUN / "base-checkpoint-9bd.adb").decode()
    new = read(RUN / "source" / TARGET).decode()
    old_oracles, new_oracles = pragmas(old), pragmas(new)
    remaining = iter(new_oracles)
    mapping = []
    for oracle in old_oracles:
        found = next((row for row in remaining if row["kind"] == oracle["kind"] and row["normalized"] == oracle["normalized"]), None)
        require(found is not None, "original oracle missing/altered/reordered")
        mapping.append({"kind": oracle["kind"], "original_line": oracle["line"], "current_line": found["line"], "text": oracle["text"]})
    loops = r"(?m)^[ \t]*for[ \t]+[A-Za-z][A-Za-z0-9_]*[ \t]+in\b[^;]*?\bloop"
    deltas = r"Bytes\s*:=\s*\(Bytes\s+with\s+delta[\s\S]*?;"
    require([normalized(x) for x in re.findall(loops, old)] == [normalized(x) for x in re.findall(loops, new)], "original loop domain/order changed")
    require([normalized(x) for x in re.findall(deltas, old)] == [normalized(x) for x in re.findall(deltas, new)], "original delta write/order changed")
    require(old.count("Decode (Bytes, Accepted, Item);") == new.count("Decode (Bytes, Accepted, Item);"), "Decode fixture site omitted")
    require(old.rsplit("\nbegin\n", 1)[1] == new.rsplit("\nbegin\n", 1)[1], "original main calls changed")
    require(not re.search(r"\bPre\s*=>|pragma\s+Assume|Skip_Proof|False_Positive|Intentional", new, re.I), "precondition/exemption added")
    require("procedure Check_Inactive_Operation (I : Operation_Index)" in new and
            "for I in Operation_Index loop\n         Check_Inactive_Operation (I);" in new, "operation domain narrowed")
    return {"original_oracles_preserved_in_order": mapping, "all_original_loop_domains_deltas_decode_sites_main_calls": "PRESERVED",
            "zero_fixture": "Separate zero/canonical helpers both initialize all bytes to zero; no cross-case state assumption",
            "full_domain_operation_helper": "I : Operation_Index, no Pre; original full Operation_Index caller loop retained",
            "production_encoder_substitution": False, "new_precondition_or_exemption": False}, new_oracles, new


def raw_report(new_oracles, text):
    stage = RUN / "complete-checkpoint-harness"
    raw = stage / "raw/continuity_checkpoint_wire_tests.spark"
    data = decoded(raw)
    require(sha(raw) == sha(RUN / "source/spark/obj/gnatprove/continuity_checkpoint_wire_tests.spark"), "raw copy differs")
    require(data["stop_reason"] == "STOP_REASON_NONE", "raw incomplete")
    for channel in ("proof", "flow", "warn_error"):
        require(isinstance(data[channel], list) and all(v["severity"] in ("info", "information") for v in data[channel]), "unclean diagnostic channel")
    require(all(data[k] == [] for k in ("pragma_assume", "skip_proof", "skip_flow_proof")), "explicit assumption/exclusion")
    require(all(row["how_proved"] == "flow" for row in data["flow"]), "flow entry not proved")
    for row in data["proof"]:
        require(row["how_proved"] in ("prover", "trivial") and row["check_tree"], "proof entry incomplete")
        for branch in row["check_tree"]:
            require(any(v["result"] == "Valid" for v in branch["proof_attempts"].values()), "actual proof-tree branch lacks Valid")
    roster = decoded(RUN / "source-roster.json")
    require([(r["kind"], r["line"]) for r in new_oracles] == [(r["kind"], r["check_line"]) for r in roster["oracles"]], "source pragma roster mismatch")
    wanted = sorted((r["name"], r["line"], r["column"]) for r in roster["declarations"])
    actual_decl = [(m[1], text.count("\n", 0, m.start()) + 1, m.start(1) - text.rfind("\n", 0, m.start(1)))
                   for m in re.finditer(r"(?m)^[ \t]*procedure[ \t]+([A-Za-z0-9_]+)", text)]
    require(sorted(actual_decl) == wanted, "complete declaration source roster mismatch")
    names = {int(key): row["name"] for key, row in data["entities"].items()}
    covered = []
    for key, mode in data["spark"].items():
        require(mode == "all", "partial SPARK mode")
        entity = data["entities"][key]
        require(len(entity["sloc"]) == 1 and entity["sloc"][0]["file"] == "continuity_checkpoint_wire_tests.adb", "entity source/SLoc mismatch")
        loc = entity["sloc"][0]
        covered.append((entity["name"], loc["line"], loc["column"]))
    require(sorted(covered) == sorted((r["full_name"], r["line"], r["column"]) for r in roster["declarations"]), "complete entity coverage missing")
    obligations(data, roster, names)
    return data, {"stop_reason": data["stop_reason"], "covered": covered,
        "proof_records": len(data["proof"]), "flow_records": len(data["flow"]),
        "proof_rule_counts": dict(collections.Counter(row["rule"] for row in data["proof"])),
        "every_actual_proof_tree_branch_has_Valid": True, "warn_error": data["warn_error"],
        "pragma_assume": data["pragma_assume"], "skip_proof": data["skip_proof"], "skip_flow_proof": data["skip_flow_proof"],
        "ordinary_assumptions": data["assumptions"], "entities": data["entities"]}


def obligations(data, roster, names):
    source_lines = read(RUN / "source" / TARGET).decode().splitlines(keepends=True)
    for declaration in roster["declarations"]:
        for field in ("header", "source"):
            row = declaration[field]
            text = "".join(source_lines[row["first"] - 1:row["last"]])
            require(text == row["text"] and hashlib.sha256(text.encode()).hexdigest() == row["sha256"], "declaration span changed")
        flow = [r for r in data["flow"] if names[r["entity"]] == declaration["full_name"]]
        if declaration["explicit_termination"]:
            require(any(r["line"] == declaration["line"] and r["rule"] == "SUBPROGRAM_TERMINATION" for r in flow), "termination absent")
        for field, rule, message in (("global_lines", "GLOBAL_WRONG", "data dependencies proved"), ("depends_lines", "DEPENDS_WRONG", "flow dependencies proved")):
            for line in declaration[field]:
                require(any(r["line"] == line and r["rule"] == rule and r["message"]["text"] == message for r in flow), "data/flow contract absent")
    for oracle in roster["oracles"]:
        rules = ("VC_ASSERT",) if oracle["kind"] == "Assert" else ("VC_LOOP_INVARIANT_INIT", "VC_LOOP_INVARIANT_PRESERV")
        for rule in rules:
            require(any(r["file"] == "continuity_checkpoint_wire_tests.adb" and r["line"] == oracle["check_line"] and r["rule"] == rule
                        and names[r["entity"]] == oracle["owner"] for r in data["proof"]), "source obligation missing/wrong owner")
    for post in roster["posts"]:
        span = post["source"]
        require("".join(source_lines[span["first"] - 1:span["last"]]) == span["text"], "full Post span mismatch")
        require(any(r["rule"] == "VC_POSTCONDITION" and r["line"] == post["check_line"] and names[r["entity"]] == post["owner"] for r in data["proof"]), "full Post check absent")


def summary(data):
    stage = RUN / "complete-checkpoint-harness"
    path = stage / "raw/gnatprove.out"
    require(sha(path) == sha(RUN / "source/spark/obj/gnatprove/gnatprove.out"), "summary copy differs")
    text = read(path).decode()
    rows = [row for row in text.splitlines() if row.startswith("Total ")]
    require(len(rows) == 1, "summary total missing/duplicate")
    fields = re.sub(r"\([0-9]+%\)", "", rows[0]).split()
    require(fields[-2:] == [".", "."], "justified/unproved nonzero")
    require(int(fields[1]) == len(data["flow"]) + len(data["proof"]), "summary raw count mismatch")
    require("16 subprograms and packages out of 16 analyzed" in text, "detailed unit completeness missing")
    require("Store_Canonical_Claim fully established" in text, "Store Post not fully established")
    generated = decoded(stage / "generated-proof-output-hashes.json")
    count = exact_roster(RUN / "source/spark/obj/gnatprove", generated)
    return {"total_row": rows[0], "reported_total": int(fields[1]), "justified": 0, "unproved": 0,
            "generated_files_hash_verified": count, "Store_Canonical_Claim_full_Post": "PROVED",
            "all_four_loop_invariants": "INITIALIZATION_AND_PRESERVATION_PROVED",
            "outer_main": "ALL_MODE_COVERED; no explicit termination aspect or invented standalone termination VC"}


def nodes(value):
    stack = [value]
    for _count in range(2_000_000):
        if not stack:
            return
        item = stack.pop()
        yield item
        if isinstance(item, dict):
            stack.extend(item.values())
        elif isinstance(item, list):
            stack.extend(item)
    raise ValueError("IR traversal bound")


def generated_semantics():
    directory = RUN / "source/spark/obj/gnatprove"
    result = {}
    for suffix in ("check_inactive_operation", "store_canonical_claim"):
        matches = list(directory.glob("*" + suffix + ".gnat-json"))
        require(len(matches) == 1, "ambiguous/missing generated IR")
        path = matches[0]
        selected = []
        for node in nodes(decoded(path)):
            if not (isinstance(node, list) and node and node[0] == "W_ASSERT"):
                continue
            labels = [x for x in nodes(node) if isinstance(x, str) and x.startswith("GP_Check:")]
            if labels:
                require(len(labels) == 1, "ambiguous GP_Check node")
                label = labels[0].split(":")
                selected.append({"label": labels[0], "rule": label[2], "line": int(label[4]), "node": node})
        if suffix == "check_inactive_operation":
            originals = [x for x in selected if x["rule"] == "VC_ASSERT" and x["line"] in (378, 385, 392)]
            require(len(originals) == 3, "original operation IR goals missing")
            for row in originals:
                require(all(token in json.dumps(row["node"]) for token in ("GP_Shape:pragargs__andthen", "accepted", "empty_checkpoint", "W_NOT")), "original conjunction missing")
        else:
            require(any(x["rule"] == "VC_POSTCONDITION" and x["line"] == 39 for x in selected), "Post IR missing")
        session = path.with_suffix("") / "why3session.xml"
        xml = ET.fromstring(read(session))
        attempts = [{"goal": g.attrib, "proof": p.attrib, "result": v.attrib}
                    for g in xml.iter("goal") for p in g.findall("proof") for v in p.findall("result")]
        result[suffix] = {"ir_sha256": sha(path), "mapped_ir_assertions": selected,
            "session_sha256": sha(session), "session_attempt_statuses": dict(collections.Counter(x["result"].get("status") for x in attempts)),
            "nonvalid_attempts_retained": [x for x in attempts if x["result"].get("status") != "valid"],
            "limits": "No one-to-one XML leaf-to-GP_Check assertion and no whole-session all-valid claim; generated unreachable probes are separate from final functional proof records"}
    return result


def main():
    provenance = preparations()
    source_binding = sources()
    tool_binding = tools()
    receipt = sequence(tool_binding["paths"])
    preserved, new_oracles, text = preservation()
    data, raw = raw_report(new_oracles, text)
    totals = summary(data)
    semantics = generated_semantics()
    save("raw-source-session-mapping.json", {"proof": data["proof"], "flow": data["flow"],
        "raw": raw, "source_preservation": preserved, "generated_semantics": semantics})
    save("review.json", {"status": "COMPLETE_CHECKPOINT_A97_POST_RUN_SOURCE_RAW_AUDIT_PASSED_WITH_LIMITATIONS",
        "base_commit": PIN, "only_overlay": {TARGET: SOURCE}, "preparation_provenance": provenance,
        "source_binding": source_binding, "tool_binding": tool_binding, "actual_sequence": receipt["checks"],
        "raw_summary": totals, "proof_scope": "COMPLETE_CHECKPOINT_TEST_UNIT_ONLY",
        "all_source_oracles_and_original_domains": "PRESERVED_AND_COVERED",
        "ordinary_modular_assumptions": "RETAINED: local dependencies and imported Claim_Payload/Operation_Payload/Decode Posts/effects/AoRTE plus Valid effects/AoRTE; imported provider bodies not proved by this command",
        "execution_provenance": "Root authored/applied additive facts and executed; reviewer authored preparation and audited retained actual outputs later",
        "reviewer_claims_independent_pre_run_preparation_review_or_execution": False,
        "new_proof_build_runtime_or_lock_execution_by_auditor": False, "worktree_edits": False,
        "all_project_combined_worktree_installed_system_p10_release_acceptance": "OPEN",
        "prior_failures_unknowns": "UNCHANGED; no retry or cap increase",
        "limits": ["Post-run audit of retained evidence, not independently repeated execution",
                   "173 is the actual one-unit reported total, not a project or sum-of-scopes total",
                   "No WCET, stack, output-disk quota or full environment-isolation claim",
                   "No XML unknown attempt relabelled Valid; final functional proof-tree branches checked separately"]})
    save("audited-inputs.json", INPUTS)
    print("POST_RUN_SOURCE_RAW_AUDIT_PASSED; no proof/build/test/lock execution")


if __name__ == "__main__":
    main()

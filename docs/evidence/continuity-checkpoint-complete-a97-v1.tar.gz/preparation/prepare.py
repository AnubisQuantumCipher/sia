#!/usr/bin/env python3
"""Derive full changed Checkpoint campaign; source/metadata preparation only."""
from pathlib import Path
import ast
import difflib
import hashlib
import json
import re
import tarfile

ROOT = Path(__file__).resolve().parent
EV = ROOT.parent
OLD = EV / "takeover-checkpoint-complete-preparation-v3"
DIAG = EV / "takeover-checkpoint-operation-byte-facts-diagnostic-v1"
AUDIT = EV / "takeover-checkpoint-operation-byte-facts-independent-audit-v1"
TARGET = "spark/tests/continuity_checkpoint_wire_tests.adb"
OVERLAY = "a97d60c565d5d2381628d6df50889395d89d9fd35ac48ff02adf03f9f5c5a738"


def read(path, bound=1048576):
    with path.open("rb") as stream:
        data = stream.read(bound + 1)
    if len(data) > bound:
        raise ValueError("preparation input bound")
    return data


def sha(data):
    return hashlib.sha256(data).hexdigest()


def put(name, value):
    (ROOT / name).write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")


def span(lines, first, last):
    text = "".join(lines[first - 1:last])
    return {"first": first, "last": last, "text": text, "sha256": sha(text.encode())}


def declarations(lines):
    stack, result = [], []
    for number, text in enumerate(lines, 1):
        start = re.match(r"^(\s*)procedure (\w+)\b", text)
        if start:
            full = ".".join([row["name"] for row in stack] + [start[2]])
            row = {"name": start[2], "full_name": full, "line": number,
                   "column": len(start[1]) + len("procedure ") + 1}
            stack.append(row)
            result.append(row)
        end = re.match(r"^\s*end (\w+);", text)
        if end and end[1] not in ("loop", "if", "case", "record", "select"):
            if not stack or stack[-1]["name"] != end[1]:
                raise ValueError("source declaration nesting mismatch")
            row = stack.pop()
            row["source"] = span(lines, row["line"], number)
            header_end = next(i for i in range(row["line"] - 1, number) if re.search(r"\bis\s*$", lines[i]))
            row["header"] = span(lines, row["line"], header_end + 1)
            row["explicit_termination"] = "Always_Terminates" in row["header"]["text"]
            row["global_lines"] = [i + 1 for i in range(row["line"] - 1, header_end + 1) if "Global =>" in lines[i]]
            row["depends_lines"] = [i + 1 for i in range(row["line"] - 1, header_end + 1) if "Depends =>" in lines[i]]
    if stack:
        raise ValueError("unclosed source declaration")
    return result


def oracles(lines, declared):
    result, posts = [], []
    for number, text in enumerate(lines, 1):
        match = re.search(r"pragma (Assert|Loop_Invariant)\b", text)
        if match:
            end = next(i for i in range(number - 1, len(lines)) if ";" in lines[i]) + 1
            check = number if text[match.end():].strip() else number + 1
            owner = max((row for row in declared if row["line"] <= number <= row["source"]["last"]), key=lambda row: row["line"])
            result.append({"kind": match[1], "check_line": check, "owner": owner["full_name"], "source": span(lines, number, end)})
    for row in declared:
        header = row["header"]
        for number in range(header["first"], header["last"] + 1):
            if "Post =>" in lines[number - 1]:
                check = number if lines[number - 1].split("Post =>", 1)[1].strip() else number + 1
                posts.append({"owner": row["full_name"], "check_line": check,
                              "source": span(lines, number, header["last"] - 1)})
    return result, posts


def replace_function(text, name, replacement):
    parsed = ast.parse(text)
    node = next(row for row in parsed.body if isinstance(row, ast.FunctionDef) and row.name == name)
    lines = text.splitlines(keepends=True)
    return "".join(lines[:node.lineno - 1]) + replacement.rstrip() + "\n" + "".join(lines[node.end_lineno:])


def driver(roster, patch_sha):
    old = read(OLD / "driver.py").decode()
    if sha(old.encode()) != "a7df556a018ddcf8d72bccdde916dc1ba00f6158c01973cd97e1bd672e77ffaa":
        raise ValueError("old complete driver changed")
    new = old.replace("Prepared Checkpoint v3 complete campaign", "Prepared changed a97 Checkpoint complete campaign")
    new = new.replace("Current priority release", "shared heavy lane release")
    new = new.replace("root-authorized-after-current", "root-authorized-for-a97")
    new = new.replace("INPUT=PREP.parent/'takeover-checkpoint-header-byte-cuts-proposal-v1'", "INPUT=PREP")
    new = new.replace("takeover-checkpoint-complete-v3", "takeover-checkpoint-complete-a97-v1")
    new = re.sub(r"^OVERLAY=.*$", "OVERLAY=" + repr(OVERLAY), new, flags=re.M)
    new = re.sub(r"^PATCH=.*$", "PATCH=" + repr(patch_sha) + "\nROSTER=" + repr(sha(read(ROOT / "source-roster.json"))) + "\nTOOL_PINS=" + repr(sha(read(ROOT / "expected-tool-pins.json"))), new, flags=re.M)
    declared = tuple((row["full_name"], row["line"]) for row in roster["declarations"])
    checks = tuple((row["kind"], row["check_line"]) for row in roster["oracles"])
    new = re.sub(r"^EXPECTED_DECLARATIONS=.*$", "EXPECTED_DECLARATIONS=" + repr(declared), new, flags=re.M)
    new = re.sub(r"^EXPECTED_ORACLES=.*$", "EXPECTED_ORACLES=" + repr(checks), new, flags=re.M)
    new = replace_function(new, "retain_overlay", read(ROOT / "retain-overlay.pyfrag").decode())
    new = replace_function(new, "obligations", read(ROOT / "full-obligations.pyfrag").decode())
    new = new.replace("require('procedure Check_Zero_And_Canonical' in (source/TARGET).read_text().splitlines()[11],'wrapper moved')", "require(digest(source/TARGET)==OVERLAY,'complete source roster input changed')")
    new = re.sub(r"    save\(OUT/'intended-coverage.json'.*", "    shutil.copyfile(PREP/'source-roster.json',OUT/'intended-coverage.json')", new)
    new = new.replace("'helper_postcondition_line':38", "'helper_postcondition_line':39")
    new = new.replace("    return binding\n", "    require(digest(path)=='49d06e57ec3aa182c75260c0c2c283e3249421ac0da83ac607e004fba36c783d','exact9bd archive byte mismatch')\n    return binding\n", 1)
    new = new.replace("    before={p:digest(Path(p)) for p in paths}", "    before={p:digest(Path(p)) for p in paths}\n    require(digest(PREP/'expected-tool-pins.json')==TOOL_PINS,'expected tool pin file changed')\n    require(before==decoded((PREP/'expected-tool-pins.json').read_bytes()),'exact diagnostic tool roster changed')", 1)
    new = new.replace("Checkpoint v3 fresh strict build/all15 original runtimes/complete unit only; no selected reruns/fullproject; v1build failure/v2timeout and all scoped records remain separate", "First changed a97 Checkpoint strict build/all15 original runtimes/complete unit only; no selected reruns or full-project claim; prior complete failures preserved")
    new = new.replace("    args=[resolved['timeout'],'--kill-after=5s',seconds]+command", "    require(digest(source/TARGET)==OVERLAY and digest(source/'spark/sia_assurance.gpr')==PROJECT,'stage source/project changed')\n    save(stage/'input-seal.json',{'overlay_sha256':digest(source/TARGET),'project_sha256':digest(source/'spark/sia_assurance.gpr'),'source_map_sha256':digest(OUT/'source-hashes-before.json'),'driver_sha256':digest(PREP/'driver.py'),'source_roster_sha256':digest(PREP/'source-roster.json')})\n    args=[resolved['timeout'],'--kill-after=5s',seconds]+command")
    new = new.replace("Never copied; Current dirty changes and docs excluded from source", "Never copied; Current, Frame and all other worktree changes/docs excluded; only frozen a97 Checkpoint overlay")
    new = new.replace("    print(json.dumps(receipt,indent=2),flush=True)\n\n\ndef main():", "    print(json.dumps(receipt,indent=2),flush=True)\n    return receipt['complete_campaign_passed']\n\n\ndef main():", 1)
    new = new.replace("        finish(args.base_commit,source,paths,before,initial,results)", "        passed=finish(args.base_commit,source,paths,before,initial,results)\n        return 0 if passed else 1", 1)
    new = new.replace("    main()\n", "    raise SystemExit(main())\n", 1)
    (ROOT / "driver.py").write_text(new)
    (ROOT / "driver-from-v3.diff").write_text("".join(difflib.unified_diff(old.splitlines(True), new.splitlines(True), fromfile="old-v3/driver.py", tofile="changed-a97/driver.py")))


def main():
    data = read(DIAG / "overlay-continuity_checkpoint_wire_tests.adb")
    if sha(data) != OVERLAY:
        raise ValueError("changed Checkpoint source mismatch")
    (ROOT / "checkpoint-a97.adb").write_bytes(data)
    with tarfile.open(DIAG / "source.tar", "r:") as archive:
        with archive.extractfile(TARGET) as stream:
            base = stream.read(1048577)
    if len(base) > 1048576 or sha(base) != "ca71eca3eff0effbd27e209c433f19faf4e2a82391c40831862569cbf1839a75":
        raise ValueError("exact9bd base mismatch")
    (ROOT / "base-checkpoint-9bd.adb").write_bytes(base)
    patch = "".join(difflib.unified_diff(base.decode().splitlines(True), data.decode().splitlines(True), fromfile="a/" + TARGET, tofile="b/" + TARGET))
    (ROOT / "checkpoint-9bd-to-a97.patch").write_text(patch)
    lines = data.decode().splitlines(keepends=True)
    declared = declarations(lines)
    checks, posts = oracles(lines, declared)
    roster = {"base_commit": "9bd84d19ae2e9907c7129f1e555bf45f9e162eac", "source_sha256": OVERLAY,
              "declarations": declared, "oracles": checks, "posts": posts,
              "termination": [{"full_name": r["full_name"], "line": r["line"]} for r in declared if r["explicit_termination"]],
              "main_implicit_termination": "Record actual raw status; composition calls all source-local explicit termination contracts; no invented standalone VC count",
              "scope": "COMPLETE CHECKPOINT UNIT; all original domains/oracles plus changed exact source; not whole project"}
    put("source-roster.json", roster)
    for name, original in [("source-review.json", DIAG / "independent-source-review.json"),
                           ("selected-raw-audit.json", AUDIT / "review.json"),
                           ("selected-raw-source-session-mapping.json", AUDIT / "raw-source-session-mapping.json"),
                           ("expected-tool-pins.json", DIAG / "tool-hashes-before.json")]:
        (ROOT / name).write_bytes(read(original))
    driver(roster, sha(patch.encode()))


if __name__ == "__main__":
    main()

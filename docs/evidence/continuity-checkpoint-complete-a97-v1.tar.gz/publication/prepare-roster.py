#!/usr/bin/env python3
"""Prepare an explicit bounded portable roster only; never package or execute tools."""
from pathlib import Path, PurePosixPath
import hashlib
import json

ROOT = Path(__file__).resolve().parent
EVIDENCE = ROOT.parent
RUN = EVIDENCE / "takeover-checkpoint-complete-a97-v1"
PREP = EVIDENCE / "takeover-checkpoint-complete-a97-preparation-v1"
AUDIT = EVIDENCE / "takeover-checkpoint-complete-a97-independent-audit-v1"
PIN = "9bd84d19ae2e9907c7129f1e555bf45f9e162eac"
SOURCE = "a97d60c565d5d2381628d6df50889395d89d9fd35ac48ff02adf03f9f5c5a738"
ARCHIVE = "49d06e57ec3aa182c75260c0c2c283e3249421ac0da83ac607e004fba36c783d"
TARGET = "spark/tests/continuity_checkpoint_wire_tests.adb"
RUNTIMES = ("policy", "transaction", "request_wire", "request_admission",
            "grant_lifetime", "retraction", "consolidation", "continuity",
            "continuity_transition", "continuity_record_wire",
            "continuity_observation_wire", "continuity_checkpoint_wire",
            "continuity_current_wire", "continuity_frame_wire", "continuity_response_wire")
CHANNELS = ("command", "command.json", "exit", "input-seal.json", "result.json", "stdout", "stderr")
HISTORY = (("takeover-checkpoint-canonical-cut-diagnostic-v1", "canonical-proof"),
           ("takeover-checkpoint-complete-v3", "complete-checkpoint-harness"),
           ("takeover-checkpoint-operation-helper-diagnostic-v1", "inactive-operation-helper-proof"))


def require(value, message):
    if not value:
        raise ValueError(message)


def sha(path):
    require(path.is_file() and not path.is_symlink(), "regular file required: " + str(path))
    require(path.stat().st_size <= 2_097_152, "metadata hash bound")
    with path.open("rb") as stream:
        data = stream.read(2_097_153)
    require(len(data) <= 2_097_152, "metadata read bound")
    return hashlib.sha256(data).hexdigest()


def decoded(path):
    sha(path)
    return json.loads(path.read_text())


def save(name, value):
    (ROOT / name).write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")


def add(rows, directory, prefix, names, role):
    require(len(names) <= 96 and len(rows) + len(names) <= 384, "roster count bound")
    for name in names:
        portable = PurePosixPath(prefix) / name
        require(not portable.is_absolute() and ".." not in portable.parts, "unsafe portable path")
        path = directory / name
        require(path.is_relative_to(EVIDENCE) and path.stat().st_size <= 1_048_576, "public member byte/location bound")
        require(str(portable) not in {r["portable_path"] for r in rows}, "duplicate portable path")
        rows.append({"source_path": str(path), "portable_path": str(portable),
                     "bytes": path.stat().st_size, "sha256": sha(path), "role": role})


def campaign(rows):
    names = ("source.tar", "archive-correspondence.json", "base-checkpoint-9bd.adb",
             "overlay-continuity_checkpoint_wire_tests.adb", "checkpoint-9bd-to-a97.patch",
             "driver.py", "launch.sh", "receipt.json", "source-binding.json", "source-roster.json",
             "source-hashes-before.json", "source-hashes-after.json", "source-output-hashes.json",
             "tool-hashes-before.json", "tool-hashes-after.json", "tool-paths.json", "storage-preflight.json",
             "source-review.json", "selected-raw-audit.json", "selected-raw-source-session-mapping.json")
    add(rows, RUN, "campaign", names, "exact a97 campaign source/tool/receipt and scoped prerequisites")
    for stem in ("archive", "base-tree", "extract", "inherited-tool-manifest",
                 "gcc-version", "gnatls-version", "gnatprove-version", "gprbuild-version"):
        add(rows, RUN, "campaign", tuple(stem + suffix for suffix in
            (".command.json", ".exit", ".stdout", ".stderr")), "actual metadata command and raw channels")
    for stage in ("strict-build",) + tuple(name + "-runtime" for name in RUNTIMES) + ("complete-checkpoint-harness",):
        add(rows, RUN / stage, "campaign/" + stage, CHANNELS, "actual stage argv/input seal/exit/raw channels")
    stage = "complete-checkpoint-harness"
    add(rows, RUN / stage, "campaign/" + stage,
        ("inspection.json", "generated-proof-output-hashes.json", "raw/continuity_checkpoint_wire_tests.spark",
         "raw/gnatprove.out", "retained-generated/continuity_checkpoint_wire_tests.adb.stdout",
         "retained-generated/continuity_checkpoint_wire_tests.adb.stderr"), "complete fresh unit raw report, summary and generated identity")
    source = RUN / "source/spark/obj/gnatprove/continuity_checkpoint_wire_tests.cswi"
    add(rows, source.parent, "campaign/effective-compiler-switches", (source.name,), "actual textual compiler switches; not a binary or session")


def preparation(rows):
    names = ("PLAN.txt", "commands.json", "preparation-binding.json", "preparation-receipt.json",
             "prepare.py", "prepare-v1-failed.py", "preparation-failure-v1.json", "driver-from-v3.diff",
             "retain-overlay.pyfrag", "full-obligations.pyfrag", "expected-tool-pins.json")
    add(rows, PREP, "preparation", names, "frozen preparation, finite command plan and retained metadata failure")
    add(rows, EVIDENCE, "authorization", ("takeover-checkpoint-complete-a97-root-authorization-v1.json",),
        "root inspection/authorization; not independent approval of preparer's own runner")
    aliases = {"driver.py": "campaign/driver.py", "launch.sh": "campaign/launch.sh",
        "checkpoint-a97.adb": "campaign/overlay-continuity_checkpoint_wire_tests.adb",
        "base-checkpoint-9bd.adb": "campaign/base-checkpoint-9bd.adb",
        "checkpoint-9bd-to-a97.patch": "campaign/checkpoint-9bd-to-a97.patch",
        "source-roster.json": "campaign/source-roster.json", "source-review.json": "campaign/source-review.json",
        "selected-raw-audit.json": "campaign/selected-raw-audit.json",
        "selected-raw-source-session-mapping.json": "campaign/selected-raw-source-session-mapping.json"}
    references = []
    for original, portable in aliases.items():
        member = next(r for r in rows if r["portable_path"] == portable)
        require(sha(PREP / original) == member["sha256"], "preparation duplicate-byte correspondence")
        references.append({"original_source_path": str(PREP / original), "portable_path": portable,
                           "sha256": member["sha256"], "reason": "identical frozen bytes retained once"})
    return references


def audit(rows):
    binding = decoded(AUDIT / "audit-binding.json")
    require(sha(AUDIT / "audit-binding.json") == "8d67a5d372fb987b99a766602014b61c26c324d6fe0b3a7ddec27ed6b3993276", "final audit binding changed")
    for row in binding["files"]:
        require(sha(AUDIT / row["path"]) == row["sha256"], "sealed final audit member changed")
    add(rows, AUDIT, "independent-audit", tuple(row["path"] for row in binding["files"]) + ("audit-binding.json",),
        "post-run audit and source/session mapping, including exact failed auditor drafts")


def histories(rows):
    index = []
    for name, stage in HISTORY:
        directory = EVIDENCE / name
        receipt = decoded(directory / "receipt.json")
        source_hash = receipt["only_overlay"][TARGET]
        require(receipt["base_commit"] == PIN and receipt["archive_sha256"] == ARCHIVE, "historical base mismatch")
        require(sha(directory / "overlay-continuity_checkpoint_wire_tests.adb") == source_hash, "historical overlay changed")
        require(sha(directory / "source.tar") == ARCHIVE, "historical archive bytes differ")
        result = decoded(directory / stage / "result.json")
        require(result["exit"] == 124 and (directory / stage / "exit").read_text() == "124\n", "historical timeout mismatch")
        require(not list((directory / stage / "raw").glob("*.spark")) and not (directory / stage / "raw/gnatprove.out").exists(), "historical raw absence changed")
        roots = ("receipt.json", "source-binding.json", "overlay-continuity_checkpoint_wire_tests.adb",
                 "tool-hashes-before.json", "tool-hashes-after.json")
        add(rows, directory, "history/" + name, roots, "source-pinned distinct historical timeout; never converted to pass")
        add(rows, directory / stage, "history/" + name + "/" + stage,
            ("command.json", "exit", "result.json", "stdout", "stderr", "inspection.json"), "historical timeout command/raw channels/refusal")
        maps = ("source-hashes-before.json", "source-hashes-after.json")
        map_root = directory if (directory / maps[0]).is_file() else directory / stage
        add(rows, map_root, "history/" + name + "/source-maps", maps, "historical source before/after identities")
        entry = {"campaign": name, "stage": stage, "base_commit": PIN, "archive_portable_path": "campaign/source.tar",
                 "only_overlay_sha256": source_hash, "actual_exit": result["exit"], "actual_elapsed_seconds": result["elapsed_seconds"],
                 "fresh_raw_spark_and_summary": "ABSENT; no functional failure site or full-unit result inferred",
                 "scope": receipt["scope"], "receipt_sha256": sha(directory / "receipt.json")}
        index.append(entry)
    return index


def historical_details(rows, index):
    canonical = EVIDENCE / HISTORY[0][0]
    add(rows, canonical, "history/" + canonical.name,
        ("canonical-cut-facts.patch", "diagnostic-conclusion.json", "generated-proof-output-inventory.json"), "original canonical timeout patch/conclusion/local generated hash roster")
    add(rows, canonical / "canonical-proof/retained-generated", "history/" + canonical.name + "/retained-generated",
        ("why31Yxsmw",), "exact retained internal quantified-pattern warning; not suppressed")
    complete = EVIDENCE / HISTORY[1][0]
    add(rows, complete / "complete-checkpoint-harness", "history/" + complete.name + "/complete-checkpoint-harness",
        ("generated-proof-output-hashes.json",), "local historical generated tree identity")
    operation = EVIDENCE / HISTORY[2][0]
    add(rows, operation / "inactive-operation-helper-proof", "history/" + operation.name + "/inactive-operation-helper-proof",
        ("generated-proof-output-hashes.json",), "local historical generated tree identity")
    add(rows, operation / "inactive-operation-helper-proof/retained-generated", "history/" + operation.name + "/retained-generated",
        ("why3zSfkDp",), "exact retained solver output; unmapped diagnostic, not asserted as source counterexample")
    index[1]["omitted_large_local_completion_audit"] = {"path": str(complete / "completion-audit.json"),
        "sha256": sha(complete / "completion-audit.json"), "bytes": (complete / "completion-audit.json").stat().st_size,
        "portable": False, "reason": "minimal historical refusal/command/receipt retained; no recursive session audit expansion"}
    save("historical-failure-index.json", {"status": "HISTORICAL_FAILURES_REMAIN_FAILED", "records": index,
         "not_complete_history": "All other earlier failures/passes and generated sessions remain local unchanged; no original record is rewritten"})


def main():
    require(sha(RUN / "source.tar") == ARCHIVE, "current archive changed")
    require(sha(RUN / "overlay-continuity_checkpoint_wire_tests.adb") == SOURCE, "current overlay changed")
    require(decoded(RUN / "receipt.json")["complete_campaign_passed"] is True, "actual campaign incomplete")
    rows = []
    campaign(rows)
    aliases = preparation(rows)
    audit(rows)
    history = histories(rows)
    historical_details(rows, history)
    add(rows, ROOT, "publication", ("prepare-roster.py", "historical-failure-index.json", "PACKAGING-LIMITATIONS.txt"),
        "bounded roster derivation and explicit packaging limits; no packaging execution")
    rows.sort(key=lambda row: row["portable_path"])
    roster = {"status": "FROZEN_EXPLICIT_PORTABLE_ROSTER_ONLY; no bundle/repo artifact created",
        "base_commit": PIN, "checkpoint_source_sha256": SOURCE, "archive_sha256": ARCHIVE, "members": rows,
        "member_bound": 384, "member_byte_bound": 1_048_576, "identical_preparation_byte_references": aliases,
        "intentional_distinct_observations": "Before/after maps and per-stage empty channels/input seals remain individually addressable; duplicate frozen source/driver/archive copies are omitted",
        "source_coverage_note": "source.tar contains exact committed9bd spark; frozen a97 overlay/full patch reconstruct this isolated campaign only. No committed or combined-worktree reproduction claim",
        "review_provenance": "Audit author prepared runner; root inspected/authorized/applied additive facts/executed; later source/raw audit is not independent pre-run runner review or new execution",
        "scope": "Strict build/all15 original runtimes/complete Checkpoint test unit: actual173checks, zero justified/unproved; provider/full-project/system/P10/release acceptance OPEN",
        "exclusions": ["No extracted source duplicate, compiled objects/binaries, caches, full Why3 sessions/config or tool executables",
                       "No private environment values, operational notes, credentials or unrelated active worktree sources",
                       "No recursive audit expansion or duplicate historical archives; full original generated trees remain local, bound by audited hashes/mapping"],
        "future_packaging_requirements": "Root bounded deterministic explicit-member retainer, --check and fresh reconstruction/hash correspondence; bind roster SHA and all members; inspect package before controlled publication. No new proof/build/test runs",
        "suggested_future_repository_paths": ["docs/evidence/continuity-checkpoint-harness-repair-v1.tar.gz", "docs/CONTINUITY-CHECKPOINT-HARNESS-REPAIR-EVIDENCE-V1.json"]}
    save("portable-publication-roster.json", roster)
    for row in rows:
        require(sha(Path(row["source_path"])) == row["sha256"], "final selected-member readback changed")
    print("FROZEN_EXPLICIT_MEMBERS", len(rows))
    print("ROSTER_SHA256", sha(ROOT / "portable-publication-roster.json"))


if __name__ == "__main__":
    main()

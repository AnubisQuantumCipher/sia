#!/usr/bin/env bash
set -euo pipefail
if [[ $# != 2 || $1 != 9bd84d19ae2e9907c7129f1e555bf45f9e162eac || $2 != ROOT_AUTHORIZED_FOR_A97 ]]; then
    printf 'usage: launch.sh 9bd84d19ae2e9907c7129f1e555bf45f9e162eac ROOT_AUTHORIZED_FOR_A97\n' >&2
    exit 2
fi
expected_env='155536a81f8d2be134c6e5cacc0c0bf9b57c94ee33659d2b19ea23c2d6ded388  /home/sicarii/opt/gnat/env.sh'
actual_env=$(/usr/bin/sha256sum /home/sicarii/opt/gnat/env.sh)
[[ "$actual_env" == "$expected_env" ]] || { printf 'GNAT environment identity refused\n' >&2; exit 1; }
source /home/sicarii/opt/gnat/env.sh
exec /usr/bin/flock -n -E 75 /home/sicarii/.worldline-heavy.lock /usr/bin/env PYTHONWARNINGS=error /usr/bin/python3.14 -B \
    /home/sicarii/Work/sia-assurance-evidence-20261019/takeover-checkpoint-complete-a97-preparation-v1/driver.py \
    --base-commit "$1" --root-authorized-for-a97

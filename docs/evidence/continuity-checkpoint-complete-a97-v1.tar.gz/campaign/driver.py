#!/usr/bin/env python3
"""Prepared changed a97 Checkpoint complete campaign; execute only after explicit root authorization and shared heavy lane release."""
from pathlib import Path
import argparse
import hashlib
import json
import os
import platform
import re
import shlex
import shutil
import subprocess
import tarfile
import time

PREP=Path(__file__).resolve().parent
INPUT=PREP
OUT=PREP.parent/'takeover-checkpoint-complete-a97-v1'
REPO=Path('/home/sicarii/Work/sia-assurance-kernel-20261019')
PIN='9bd84d19ae2e9907c7129f1e555bf45f9e162eac'
TARGET='spark/tests/continuity_checkpoint_wire_tests.adb'
BASE='ca71eca3eff0effbd27e209c433f19faf4e2a82391c40831862569cbf1839a75'
OVERLAY='a97d60c565d5d2381628d6df50889395d89d9fd35ac48ff02adf03f9f5c5a738'
PROJECT='d439a1e2908c70643c951d296294a87c3ba2756be6b1d0bb4c9a6bd4814ebe49'
PATCH='bf047be671722e4d354b161372333119b282f83308bd6f74fa606c78c4682dfe'
ROSTER='670c17dccb4f2ec61ecb662842a405bedda1911c6d82648b583ddce42ed37038'
TOOL_PINS='f7a2223e0369e7a3c6628163a91f6f6bc1b496fc1b6f25e308652ba7e9f52a8d'
RESERVE=10_000_000_000
EXPECTED_DECLARATIONS=(('Continuity_Checkpoint_Wire_Tests', 6), ('Continuity_Checkpoint_Wire_Tests.Check_Zero_And_Canonical', 13), ('Continuity_Checkpoint_Wire_Tests.Check_Zero_And_Canonical.Check_Zero_Representation', 16), ('Continuity_Checkpoint_Wire_Tests.Check_Zero_And_Canonical.Check_Canonical_Representation', 31), ('Continuity_Checkpoint_Wire_Tests.Check_Zero_And_Canonical.Check_Canonical_Representation.Store_Canonical_Claim', 34), ('Continuity_Checkpoint_Wire_Tests.Check_Header', 86), ('Continuity_Checkpoint_Wire_Tests.Check_Header_Order', 144), ('Continuity_Checkpoint_Wire_Tests.Check_Claim_Order', 182), ('Continuity_Checkpoint_Wire_Tests.Check_Operation_Order', 227), ('Continuity_Checkpoint_Wire_Tests.Check_Coverage', 269), ('Continuity_Checkpoint_Wire_Tests.Check_Counts', 287), ('Continuity_Checkpoint_Wire_Tests.Check_Header_Refusals', 306), ('Continuity_Checkpoint_Wire_Tests.Check_Inactive_Claims', 330), ('Continuity_Checkpoint_Wire_Tests.Check_Inactive_Operations', 362), ('Continuity_Checkpoint_Wire_Tests.Check_Inactive_Operations.Check_Inactive_Operation', 365), ('Continuity_Checkpoint_Wire_Tests.Check_Policy_Invalid_Preservation', 400))
EXPECTED_ORACLES=(('Assert', 24), ('Assert', 25), ('Assert', 27), ('Loop_Invariant', 65), ('Loop_Invariant', 73), ('Assert', 79), ('Loop_Invariant', 98), ('Loop_Invariant', 104), ('Assert', 108), ('Assert', 110), ('Assert', 113), ('Assert', 116), ('Assert', 119), ('Assert', 122), ('Assert', 125), ('Assert', 128), ('Assert', 131), ('Assert', 133), ('Assert', 136), ('Assert', 139), ('Assert', 152), ('Assert', 153), ('Assert', 168), ('Assert', 172), ('Assert', 176), ('Assert', 223), ('Assert', 224), ('Assert', 265), ('Assert', 266), ('Assert', 279), ('Assert', 281), ('Assert', 295), ('Assert', 296), ('Assert', 300), ('Assert', 301), ('Assert', 317), ('Assert', 324), ('Assert', 325), ('Assert', 340), ('Assert', 342), ('Assert', 344), ('Assert', 347), ('Assert', 349), ('Assert', 351), ('Assert', 354), ('Assert', 356), ('Assert', 358), ('Assert', 374), ('Assert', 376), ('Assert', 378), ('Assert', 381), ('Assert', 383), ('Assert', 385), ('Assert', 388), ('Assert', 390), ('Assert', 392), ('Assert', 410), ('Assert', 412), ('Assert', 417), ('Assert', 418), ('Assert', 421), ('Assert', 422))
RUNTIMES=('policy','transaction','request_wire','request_admission','grant_lifetime','retraction','consolidation','continuity','continuity_transition','continuity_record_wire','continuity_observation_wire','continuity_checkpoint_wire','continuity_current_wire','continuity_frame_wire','continuity_response_wire')


def require(condition,message):
    if not condition:
        raise ValueError(message)


def save(path,value):
    path.write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')


def pairs(items):
    result={}
    for key,value in items:
        require(key not in result,'duplicate JSON key')
        result[key]=value
    return result


def decoded(data):
    def invalid(value):
        raise ValueError('non-JSON numeric constant: '+value)
    return json.loads(data,object_pairs_hook=pairs,parse_constant=invalid)


def digest(path):
    require(path.is_file() and not path.is_symlink(),'hash input type')
    require(path.stat().st_size<=536_870_912,'hash byte budget')
    value=hashlib.sha256()
    with path.open('rb') as stream:
        for unused in range(8193):
            data=stream.read(65536)
            if not data:
                return value.hexdigest()
            value.update(data)
    raise ValueError('hash iteration budget')


def roster(directory):
    result={}
    for count,(current,directories,files) in enumerate(os.walk(directory,followlinks=False)):
        require(count<1024 and len(result)+len(files)<=4096,'source inventory budget')
        directories.sort()
        for name in sorted(files):
            path=Path(current)/name
            result[str(path.relative_to(directory))]=digest(path)
    return result


def small(args,label,cwd=REPO):
    value=subprocess.run(args,cwd=cwd,capture_output=True,timeout=30)
    (OUT/(label+'.stdout')).write_bytes(value.stdout)
    (OUT/(label+'.stderr')).write_bytes(value.stderr)
    save(OUT/(label+'.command.json'),args)
    (OUT/(label+'.exit')).write_text(str(value.returncode)+'\n')
    require(value.returncode==0,'preparation command failed: '+label)
    return value.stdout


def storage():
    args=['python3','/home/sicarii/.codex/skills/project-vault/scripts/storage_status.py']
    value=subprocess.run(args,cwd=REPO,capture_output=True,timeout=30)
    require(value.returncode==0,'storage preflight failed')
    data=decoded(value.stdout)
    pinned=any(OUT.is_relative_to(Path(p)) for p in data['pins'])
    scoped={key:data[key] for key in ('local_disk_bytes','configured_local_reserve_bytes','backup_service','ipad_availability','blanket_eviction_enabled')}
    scoped.update(command=args,exit=value.returncode,evidence_root=str(OUT.parent),evidence_root_pinned=pinned,stdout_retention='Only relevant scoped storage fields retained; unrelated queue/path inventory excluded',stderr=value.stderr.decode())
    save(OUT/'storage-preflight.json',scoped)
    require(pinned,'external evidence root not pinned')
    require(shutil.disk_usage(OUT).free>=max(RESERVE,data['configured_local_reserve_bytes']),'reserve unavailable')


def archive(pin):
    path=OUT/'source.tar'
    small(['git','archive','--format=tar','--output='+str(path),pin,'spark'],'archive')
    tree=small(['git','ls-tree','-r','--full-tree',pin,'spark'],'base-tree').decode().splitlines()
    expected={row.split('\t',1)[1]:row.split()[2] for row in tree}
    require(0<len(expected)<=4096,'archive member budget')
    binding={}
    with tarfile.open(path,'r:') as bundle:
        for member in bundle.getmembers():
            if member.isdir():
                continue
            require(member.isfile() and member.name in expected,'unexpected archive member')
            data=bundle.extractfile(member).read(536_870_913)
            require(len(data)<=536_870_912,'archive member byte budget')
            git_hash=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
            require(git_hash==expected[member.name],'archive blob mismatch')
            binding[member.name]={'git_blob':git_hash,'sha256':hashlib.sha256(data).hexdigest()}
    require(set(binding)==set(expected),'archive roster mismatch')
    save(OUT/'archive-correspondence.json',binding)
    require(binding[TARGET]['sha256']==BASE,'base Checkpoint file mismatch')
    require(binding['spark/sia_assurance.gpr']['sha256']==PROJECT,'strict project changed')
    require(digest(path)=='49d06e57ec3aa182c75260c0c2c283e3249421ac0da83ac607e004fba36c783d','exact9bd archive byte mismatch')
    return binding


def retain_overlay():
    require(digest(REPO/TARGET)==OVERLAY,'owner-applied Checkpoint differs from approved campaign')
    require(digest(PREP/'checkpoint-a97.adb')==OVERLAY,'frozen changed Checkpoint changed')
    require(digest(PREP/'checkpoint-9bd-to-a97.patch')==PATCH,'full base-to-overlay patch changed')
    require(digest(PREP/'source-review.json')=='5e874888ea1096a922336ffc771725b9e2944f4b983545739a891906764eb2ba','scoped source review changed')
    require(digest(PREP/'selected-raw-audit.json')=='4b778ba2b43625b6aafacb071626f5e908c3794601e1e3b63e4d7d06a56be63b','independent selected audit changed')
    require(digest(PREP/'source-roster.json')==ROSTER,'exact complete source roster changed')
    roster=decoded((PREP/'source-roster.json').read_bytes())
    require(roster['source_sha256']==OVERLAY,'complete source roster not bound')
    for name in ('checkpoint-9bd-to-a97.patch','base-checkpoint-9bd.adb','source-review.json','selected-raw-audit.json','selected-raw-source-session-mapping.json','source-roster.json'):
        shutil.copyfile(PREP/name,OUT/name)
    shutil.copyfile(PREP/'checkpoint-a97.adb',OUT/'overlay-continuity_checkpoint_wire_tests.adb')


def fresh_source(binding):
    source=OUT/'source'
    source.mkdir()
    small(['tar','-xf',str(OUT/'source.tar'),'-C',str(source)],'extract')
    require(all(digest(source/name)==row['sha256'] for name,row in binding.items()),'extraction mismatch')
    shutil.copyfile(OUT/'overlay-continuity_checkpoint_wire_tests.adb',source/TARGET)
    require(digest(source/TARGET)==OVERLAY,'campaign overlay mismatch')
    require(digest(source/'spark/sia_assurance.gpr')==PROJECT,'strict project mismatch')
    require(digest(source/TARGET)==OVERLAY,'complete source roster input changed')
    initial=roster(source)
    save(OUT/'source-hashes-before.json',initial)
    shutil.copyfile(PREP/'source-roster.json',OUT/'intended-coverage.json')
    return source,initial


def toolchain(pin):
    manifest=decoded(small(['git','show',pin+':docs/CONTINUITY-IO-COMMITTED-EVIDENCE-20261021.json'],'inherited-tool-manifest'))
    expected=manifest['receipt']['proof_tools_before']
    resolved={}
    for name in ('gnatprove','gprbuild','gnatls','gcc','timeout','git','python3','tar','flock'):
        path=shutil.which(name)
        require(path is not None,'tool missing: '+name)
        resolved[name]=str(Path(path).resolve())
    paths=sorted(set(list(expected)+list(resolved.values())+['/home/sicarii/opt/gnat/env.sh']))
    before={p:digest(Path(p)) for p in paths}
    require(digest(PREP/'expected-tool-pins.json')==TOOL_PINS,'expected tool pin file changed')
    require(before==decoded((PREP/'expected-tool-pins.json').read_bytes()),'exact diagnostic tool roster changed')
    save(OUT/'tool-paths.json',resolved)
    save(OUT/'tool-hashes-before.json',before)
    require(all(before[p]==value for p,value in expected.items()),'inherited proof tool identity changed')
    for name in ('gnatprove','gprbuild','gnatls','gcc'):
        small([resolved[name],'--version'],name+'-version')
    return resolved,paths,before


def obligations(data):
    require(digest(PREP/'source-roster.json')==ROSTER,'exact complete source roster changed')
    roster=decoded((PREP/'source-roster.json').read_bytes())
    require(roster['source_sha256']==OVERLAY,'source roster changed')
    selected=[row for row in data['proof'] if row.get('file')=='continuity_checkpoint_wire_tests.adb']
    required={}
    for kind,line in EXPECTED_ORACLES:
        rules=('VC_ASSERT',) if kind=='Assert' else ('VC_LOOP_INVARIANT_INIT','VC_LOOP_INVARIANT_PRESERV')
        for rule in rules:
            found=[row for row in selected if row.get('line')==line and row.get('rule')==rule]
            require(bool(found),'required original/added assertion/invariant missing: '+str((line,rule)))
            require(all(row['how_proved'] in ('prover','trivial') for row in found),'required obligation not proved')
            required[str(line)+':'+rule]=found
    for post in roster['posts']:
        found=[row for row in selected if row.get('rule')=='VC_POSTCONDITION' and post['source']['first']<=row.get('line',-1)<=post['source']['last']]
        require(bool(found) and all(row['how_proved'] in ('prover','trivial') for row in found),'complete Store_Canonical_Claim Post not proved')
        required[str(post['check_line'])+':VC_POSTCONDITION']=found
    names={int(key):value['name'] for key,value in data['entities'].items()}
    for declaration in roster['declarations']:
        flow=[row for row in data['flow'] if names.get(row.get('entity'))==declaration['full_name']]
        if declaration['explicit_termination']:
            found=[row for row in flow if row.get('rule')=='SUBPROGRAM_TERMINATION' and row.get('line')==declaration['line'] and row.get('how_proved')=='flow']
            require(bool(found),'explicit termination missing/unproved: '+declaration['full_name'])
            required[declaration['full_name']+':TERMINATION']=found
        for field,rule,message in (('global_lines','GLOBAL_WRONG','data dependencies proved'),('depends_lines','DEPENDS_WRONG','flow dependencies proved')):
            for line in declaration[field]:
                found=[row for row in flow if row.get('rule')==rule and row.get('line')==line and row.get('message',{}).get('text')==message and row.get('how_proved')=='flow']
                require(bool(found),'dependency contract missing/unproved: '+str((declaration['full_name'],line,rule)))
                required[declaration['full_name']+':'+str(line)+':'+rule]=found
    return required


def inspect(stage):
    raw=stage/'raw'
    reports=sorted(raw.glob('*.spark'))
    require([p.name for p in reports]==['continuity_checkpoint_wire_tests.spark'],'unexpected/missing raw report roster')
    data=decoded(reports[0].read_bytes())
    require(data['stop_reason']=='STOP_REASON_NONE','raw report incomplete')
    for channel in ('warn_error','flow','proof'):
        require(isinstance(data[channel],list),'raw diagnostic channel type')
        require(all(isinstance(v,dict) and v.get('severity') in ('info','information') for v in data[channel]),'non-information raw diagnostic')
    for field in ('pragma_assume','skip_proof','skip_flow_proof'):
        require(data[field]==[],'explicit assumption/exclusion')
    covered=[]
    for key,state in data['spark'].items():
        require(state=='all','partial SPARK entity')
        row=data['entities'][key]
        require(len(row['sloc'])==1,'ambiguous entity location')
        loc=row['sloc'][0]
        require(loc['file']=='continuity_checkpoint_wire_tests.adb','unexpected entity source')
        covered.append((row['name'],loc['line']))
    require(sorted(covered)==sorted(EXPECTED_DECLARATIONS),'complete declaration coverage mismatch')
    required=obligations(data)
    summary=raw/'gnatprove.out'
    require(summary.is_file(),'fresh summary missing')
    totals=[row for row in summary.read_text().splitlines() if row.startswith('Total ')]
    require(len(totals)==1,'missing/duplicate total row')
    fields=re.sub(r'\([0-9]+%\)','',totals[0]).split()
    require(fields[-2:]==['.','.'],'nonzero justified/unproved checks')
    return {'status':'COMPLETE CHECKPOINT UNIT ONLY','covered':covered,'required_obligations':required,'total_row':totals[0],'reported_total':int(fields[1]),'justified':0,'unproved':0,'raw_diagnostics':'No non-information warn_error/flow/proof entries','pragma_assume':[],'skip_proof':[],'skip_flow_proof':[],'assumptions':data['assumptions'],'entities':data['entities'],'full_project_acceptance':False}


def retain_generated(stage,source):
    directory=source/'spark/obj/gnatprove'
    save(stage/'generated-proof-output-hashes.json',roster(directory))
    retained=stage/'retained-generated'
    retained.mkdir()
    names=['continuity_checkpoint_wire_tests.adb.stdout','continuity_checkpoint_wire_tests.adb.stderr']
    names+=sorted(p.name for p in directory.glob('why3*') if p.is_file() and p.name!='why3.conf')
    require(len(names)<=32,'generated channel roster budget')
    for name in names:
        path=directory/name
        if path.is_file() and path.stat().st_size<=1_048_576:
            shutil.copyfile(path,retained/name)


def run_stage(source,resolved,name,command,seconds,proof=False):
    stage=OUT/name
    stage.mkdir()
    require(digest(source/TARGET)==OVERLAY and digest(source/'spark/sia_assurance.gpr')==PROJECT,'stage source/project changed')
    save(stage/'input-seal.json',{'overlay_sha256':digest(source/TARGET),'project_sha256':digest(source/'spark/sia_assurance.gpr'),'source_map_sha256':digest(OUT/'source-hashes-before.json'),'driver_sha256':digest(PREP/'driver.py'),'source_roster_sha256':digest(PREP/'source-roster.json')})
    args=[resolved['timeout'],'--kill-after=5s',seconds]+command
    save(stage/'command.json',args)
    (stage/'command').write_text(shlex.join(args)+'\n')
    require(shutil.disk_usage(OUT).free>=RESERVE,'reserve unavailable before '+name)
    if proof:
        report=source/'spark/obj/gnatprove'
        require(not list(report.glob('*.spark')) and not (report/'gnatprove.out').exists(),'stale proof reports before campaign proof')
    started=time.monotonic()
    with (stage/'stdout').open('wb') as stdout,(stage/'stderr').open('wb') as stderr:
        value=subprocess.run(args,cwd=source,stdout=stdout,stderr=stderr)
    result={'name':name,'command':args,'exit':value.returncode,'elapsed_seconds':time.monotonic()-started,'passed':value.returncode==0}
    (stage/'exit').write_text(str(value.returncode)+'\n')
    if proof:
        raw=stage/'raw'
        raw.mkdir()
        for path in sorted(list(report.glob('*.spark'))+list(report.glob('gnatprove.out'))):
            shutil.copyfile(path,raw/path.name)
        retain_generated(stage,source)
        try:
            inspection=inspect(stage)
            save(stage/'inspection.json',inspection)
        except (ValueError,KeyError,TypeError,UnicodeError) as error:
            save(stage/'inspection.json',{'status':'REFUSED','error':str(error),'full_project_acceptance':False})
            result['passed']=False
        result['fresh_summary_present']=(raw/'gnatprove.out').exists()
    save(stage/'result.json',result)
    print(json.dumps(result),flush=True)
    return result


def sequence(source,resolved):
    results=[run_stage(source,resolved,'strict-build',[resolved['gprbuild'],'-p','-j1','-P','spark/sia_assurance.gpr'],'120s')]
    if not results[-1]['passed']:
        return results
    for name in RUNTIMES:
        results.append(run_stage(source,resolved,name+'-runtime',['spark/bin/'+name+'_tests'],'30s'))
        if not results[-1]['passed']:
            return results
    proof=[resolved['gnatprove'],'-P','spark/sia_assurance.gpr','-u','continuity_checkpoint_wire_tests.adb','--mode=all','--assumptions','--no-inlining','--memlimit=512','--timeout=10','-j1']
    results.append(run_stage(source,resolved,'complete-checkpoint-harness',proof,'120s',True))
    return results


def finish(pin,source,paths,before,initial,results):
    after={p:digest(Path(p)) for p in paths}
    save(OUT/'tool-hashes-after.json',after)
    final={name:digest(source/name) for name in initial}
    save(OUT/'source-hashes-after.json',final)
    save(OUT/'source-output-hashes.json',roster(source))
    expected=['strict-build']+[name+'-runtime' for name in RUNTIMES]+['complete-checkpoint-harness']
    free=shutil.disk_usage(OUT).free
    receipt={'base_commit':pin,'archive_sha256':digest(OUT/'source.tar'),'only_overlay':{TARGET:OVERLAY},'base_checkpoint_sha256':BASE,'patch_sha256':PATCH,'project_sha256':PROJECT,'checks':results,'tool_rosters_equal':before==after,'archived_overlay_sources_unchanged':initial==final,'worktree_checkpoint_sha256_after':digest(REPO/TARGET),'free_after_bytes':free,'complete_campaign_passed':all(row['passed'] for row in results) and [row['name'] for row in results]==expected and before==after and initial==final and free>=RESERVE,'full_project_proof':'OPEN; no full-project command run','installed_acceptance':'OPEN; no installed action','scope':'First changed a97 Checkpoint strict build/all15 original runtimes/complete unit only; no selected reruns or full-project claim; prior complete failures preserved'}
    save(OUT/'receipt.json',receipt)
    print(json.dumps(receipt,indent=2),flush=True)
    return receipt['complete_campaign_passed']


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--base-commit',required=True)
    parser.add_argument('--root-authorized-for-a97',action='store_true',required=True)
    args=parser.parse_args()
    require(args.base_commit==PIN,'owner authorized only exact pinned base')
    require(not OUT.exists(),'fresh evidence directory required')
    OUT.mkdir()
    try:
        storage()
        binding=archive(args.base_commit)
        retain_overlay()
        source,initial=fresh_source(binding)
        resolved,paths,before=toolchain(args.base_commit)
        shutil.copyfile(PREP/'driver.py',OUT/'driver.py')
        shutil.copyfile(PREP/'launch.sh',OUT/'launch.sh')
        save(OUT/'source-binding.json',{'commit':args.base_commit,'source_archive_sha256':digest(OUT/'source.tar'),'base_git_blob':'6e5b30d30e9d0fe2b36c8571acd5beb3b85a9c0d','only_overlay':{TARGET:OVERLAY},'other_worktree_files':'Never copied; Current, Frame and all other worktree changes/docs excluded; only frozen a97 Checkpoint overlay','platform':platform.platform(),'lock':'launch.sh holds flock -n -E75 /home/sicarii/.worldline-heavy.lock through full campaign and retention','intended_declarations':EXPECTED_DECLARATIONS,'intended_assertions_invariants':EXPECTED_ORACLES})
        results=sequence(source,resolved)
        passed=finish(args.base_commit,source,paths,before,initial,results)
        return 0 if passed else 1
    except Exception as error:
        save(OUT/'driver-failure.json',{'type':type(error).__name__,'error':str(error),'full_project_acceptance':False})
        raise

if __name__=='__main__':
    raise SystemExit(main())

"""Recheck retained report structure; does not rerun GNATprove."""
import hashlib
import importlib.util
import json
from pathlib import Path
import sys


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise ValueError("checker import unavailable")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def refusal(action, expected):
    try:
        action()
    except ValueError as error:
        if str(error) != expected:
            raise ValueError("unexpected refusal") from error
        return str(error)
    raise ValueError("unexpected acceptance")


def main():
    evidence = Path(sys.argv[1])
    root = evidence / "focused-fixture"
    report = root / "report.txt"
    digest = hashlib.sha256(report.read_bytes()).hexdigest()
    if digest != "6c75603099fae90277394635d54f22e5e6280875e9c9e1aba5fea50c85881803":
        raise ValueError("retained report changed")
    old = load(evidence / "baseline/spark/check-proof-summary.py", "old_checker")
    new = load(evidence / "candidate/spark/check-proof-summary.py", "new_checker")
    lines = report.read_text().splitlines()
    baseline = refusal(lambda: old.check_details(lines),
                       "misbound or duplicate analysis detail row")
    new.check_details(lines, new.source_overloads(root))
    full = refusal(lambda: new.check(root, report),
                   "duplicate or incomplete subprogram coverage")
    print(json.dumps({"retained_report_sha256": digest, "baseline_refusal": baseline,
                      "candidate_detail_result": "PASS", "full_gate_refusal": full,
                      "scope": "copied historical report structure; not fresh proof"},
                     indent=2))


if __name__ == "__main__":
    main()

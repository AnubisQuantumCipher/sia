"""Retain scoped checker results; no proof execution or system acceptance."""
import ast
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

ROOT = Path(sys.argv[1]).resolve()
OUT = Path(sys.argv[2]).resolve()
RUFF = Path(sys.argv[3]).resolve()
INPUTS = json.loads((OUT / "candidate-pins.json").read_text())
PYTHON_FILES = ("spark/check-proof-summary.py", "spark/tests/test_proof_summary.py",
                "spark/tests/test_proof_summary_overloads.py")


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def pins():
    actual = {name: digest(ROOT / name) for name in INPUTS}
    if actual != INPUTS:
        raise ValueError("candidate inputs changed")
    baseline = json.loads((OUT / "baseline.json").read_text())
    if actual[PYTHON_FILES[1]] != baseline["files"][PYTHON_FILES[1]]:
        raise ValueError("original tests changed")
    return actual


def run(name, command, seconds):
    before = pins()
    started = time.monotonic_ns()
    env = {**os.environ, "PYTHONDONTWRITEBYTECODE": "1",
           "PYTHONWARNINGS": "error", "RAYON_NUM_THREADS": "1"}
    bounded = ["timeout", "--kill-after=5s", str(seconds) + "s"] + command
    with (OUT / (name + ".stdout")).open("wb") as stdout:
        with (OUT / (name + ".stderr")).open("wb") as stderr:
            result = subprocess.run(bounded, cwd=ROOT, env=env, stdout=stdout,
                                    stderr=stderr, timeout=seconds + 10, check=False)
    receipt = {"command": bounded, "exit": result.returncode,
               "elapsed_ns": time.monotonic_ns() - started,
               "before": before, "after": pins(),
               "stdout_sha256": digest(OUT / (name + ".stdout")),
               "stderr_sha256": digest(OUT / (name + ".stderr"))}
    (OUT / (name + ".json")).write_text(json.dumps(receipt, indent=2) + "\n")
    if result.returncode:
        raise ValueError(name + " failed; retained output")
    return receipt


def syntax_and_scope():
    functions = {}
    forbidden = re.compile(rb"#\s*(?:noqa\b|(?:ruff|flake8)\s*:\s*(?:noqa\b|ignore\b|file-ignore\b|disable\b|enable\b))", re.I)
    for name in PYTHON_FILES:
        raw = (ROOT / name).read_bytes()
        if len(raw) > 1048576 or forbidden.search(raw):
            raise ValueError("oversized source or suppression directive")
        tree = ast.parse(raw, filename=name)
        for node in ast.walk(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                size = node.end_lineno - node.lineno + 1
                functions[name + ":" + str(node.lineno) + ":" + node.name] = size
                if size > 60:
                    raise ValueError("routine exceeds declared review target")
    return functions


def main():
    pins()
    version = subprocess.run([str(RUFF), "--version"], capture_output=True,
                             text=True, timeout=10, check=True)
    if version.stdout.strip() != "ruff 0.17.1" or version.stderr:
        raise ValueError("unexpected Ruff tool identity")
    rules_path = ROOT / "docs/evidence/assurance-ruff-rules-v1.txt"
    if digest(rules_path) != "0fea46b8e04811e2b1142cc0517f8152d1c7f36641ca13e14d8b94ea9b3c0741":
        raise ValueError("rule profile mismatch")
    rules = ",".join(rules_path.read_text().splitlines())
    static = [str(RUFF), "check", "--isolated", "--no-cache", "--target-version", "py312",
              "--select", rules, "--ignore-noqa", "--no-fix", "--no-fix-only",
              "--no-unsafe-fixes", "--no-preview", "--no-respect-gitignore",
              "--no-force-exclude", "--output-format", "json", *PYTHON_FILES]
    functions = syntax_and_scope()
    run("final-tests", [sys.executable, "-B", "-m", "unittest", "discover",
                        "-s", "spark/tests", "-p", "test_proof_summary*.py", "-v"], 60)
    run("final-static", static, 30)
    if json.loads((OUT / "final-static.stdout").read_text()) != []:
        raise ValueError("nonempty static diagnostics")
    if (OUT / "final-static.stderr").stat().st_size:
        raise ValueError("static analyzer stderr")
    result = {"status": "TESTED", "scope": "checker only; no GNATprove execution",
              "python": sys.version, "python_sha256": digest(Path(sys.executable)),
              "ruff_version": version.stdout.strip(), "ruff_sha256": digest(RUFF),
              "functions": functions, "sources": pins(), "original_tests": "UNCHANGED"}
    (OUT / "verification.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"status": result["status"], "original_tests": "UNCHANGED"}))


if __name__ == "__main__":
    main()

"""Reproducibly package scoped checker evidence, never release acceptance."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import sys
import tarfile


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def inputs(evidence):
    names = ["baseline.json", "candidate-pins.json", "verify.py", "package.py",
             "reproduce_report.py", "review-v1.json", "review-v2.json",
             "tests-v1.log", "static-v1.json", "static-v1.stdout", "static-v1.stderr",
             "final-tests.json", "final-tests.stdout", "final-tests.stderr",
             "final-static.json", "final-static.stdout", "final-static.stderr",
             "verification.json", "retained-report-controls.json",
             "reproduced-report-controls.json"]
    for directory in ("baseline", "candidate", "focused-fixture"):
        names.extend(str(p.relative_to(evidence))
                     for p in (evidence / directory).rglob("*") if p.is_file())
    if len(names) > 128 or len(names) != len(set(names)):
        raise ValueError("unexpected package inventory")
    return {name: (evidence / name).read_bytes() for name in sorted(names)}


def archive(files):
    stream = io.BytesIO()
    with gzip.GzipFile(fileobj=stream, mode="wb", filename="", mtime=0) as zipped:
        with tarfile.open(fileobj=zipped, mode="w", format=tarfile.USTAR_FORMAT) as tar:
            for name, raw in files.items():
                if len(raw) > 4194304:
                    raise ValueError("evidence member exceeds size limit")
                item = tarfile.TarInfo(name)
                item.size, item.mode = len(raw), 0o644
                tar.addfile(item, io.BytesIO(raw))
    return stream.getvalue()


def main():
    evidence, repo = Path(sys.argv[1]), Path(sys.argv[2])
    files = inputs(evidence)
    packed = archive(files)
    if packed != archive(files):
        raise ValueError("archive reproduction mismatch")
    receipt = json.loads(files["verification.json"])
    for name, expected in receipt["sources"].items():
        if digest((repo / name).read_bytes()) != expected:
            raise ValueError("repository source mismatch")
    summary = {
        "status": "TESTED_CHECKER_ONLY_FULL_ASSURANCE_INCOMPLETE",
        "base_commit": "3c8a4720bde3071ebd551ae109b19363f0bf5d3b",
        "sources": receipt["sources"], "original_tests": "UNCHANGED",
        "results": {"tests": "32 PASS", "static": "pinned partial profile; no findings",
                    "retained_report": "overload details PASS; full gate still REFUSES"},
        "review": "actual GPT-6.1 read-only source/evidence review; no independent execution",
        "archive": {"path": "docs/evidence/proof-summary-overloads-20261024.tar.gz",
                    "sha256": digest(packed), "bytes": len(packed)},
        "members": {name: digest(raw) for name, raw in files.items()},
        "limits": ["Not an Ada parser or proof authenticity checker",
                   "No fresh GNATprove campaign; retained report structure only",
                   "No whole Python memory/time proof or hostile-filesystem custody",
                   "Full native/writer/proof/harness/recovery/installed/release gates remain open",
                   "No installation, main merge, release or marketplace acceptance"],
    }
    (repo / summary["archive"]["path"]).write_bytes(packed)
    destination = repo / "docs/PROOF-SUMMARY-OVERLOADS-EVIDENCE-20261024.json"
    destination.write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n")
    print(json.dumps({"archive": summary["archive"], "members": len(files),
                      "summary_sha256": digest(destination.read_bytes())}))


if __name__ == "__main__":
    main()

"""Derive scoped evidence from retained bytes; never a full proof gate."""
import hashlib
import gzip
import importlib.util
import io
import json
from pathlib import Path
import shutil
import sys
import tarfile

ROOT = Path(__file__).parent
REPO = Path('/home/sicarii/Work/sia-assurance-kernel-20261019')
DEST = REPO / 'docs/CONTINUITY-RESPONSE-WIRE-EVIDENCE.json'
LIMIT = 4 * 1024 * 1024


def read(path):
    with path.open('rb') as stream:
        raw = stream.read(LIMIT + 1)
    if len(raw) > LIMIT:
        raise ValueError('evidence file exceeds cap: ' + str(path))
    return raw


def artifact(path):
    raw = read(path)
    return {'path': str(path.relative_to(ROOT)),
            'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)}


def attempt(name):
    output = ROOT / name
    receipt = json.loads(read(output / 'receipt.json'))
    if 'tools_unchanged' not in receipt:
        raise ValueError('attempt has not reached a retained terminal result')
    if (not receipt['tools_unchanged'] or
            len(receipt['proof_tools_before']) != 10 or
            receipt['proof_tools_before'] != receipt['proof_tools_after']):
        raise ValueError('tool identities changed or roster is incomplete')
    runner = output / 'run-continuity-response-wire-development-v1.py'
    spec = importlib.util.spec_from_file_location('retained_runner', runner)
    driver = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(driver)
    expected = driver.make_plan()
    actual = receipt['checks']
    if not actual or len(actual) > len(expected):
        raise ValueError('missing or unexpected diagnostic commands')
    for observed, (label, duration, argv) in zip(actual, expected):
        if (observed['name'] != label or observed['command'] !=
                ['timeout', '--kill-after=5s', duration, *argv]):
            raise ValueError('diagnostic command or cap mismatch')
    if any(check['exit'] != 0 for check in actual[:-1]):
        raise ValueError('runner continued after a failed command')
    artifacts = [artifact(output / 'receipt.json')]
    for entry in receipt['checks']:
        artifacts.append(artifact(output / (entry['name'] + '.log')))
    for files in receipt.get('retained_raw', {}).values():
        if len(files) > 256:
            raise ValueError('raw roster exceeds bound')
    for phase, files in receipt.get('retained_raw', {}).items():
        for filename, expected in files.items():
            value = artifact(output / (phase + '-raw') / filename)
            if value['sha256'] != expected:
                raise ValueError('retained raw report changed')
            artifacts.append(value)
    for filename, expected in receipt['files'].items():
        value = artifact(output / 'source' / filename)
        if value['sha256'] != expected:
            raise ValueError('retained source changed')
        artifacts.append(value)
    return {'directory': name, 'base_commit': receipt['base'],
            'source_files': receipt['files'], 'checks': receipt['checks'],
            'tools_unchanged': receipt['tools_unchanged'],
            'proof_tools_before': receipt['proof_tools_before'],
            'proof_tools_after': receipt['proof_tools_after'],
            'artifacts': artifacts}


def audit_core(name, checking):
    output = ROOT / name
    raw_dir = output / 'core-proof-raw'
    gate_path = output / 'source/spark/check-proof-summary.py'
    spec = importlib.util.spec_from_file_location('retained_gate', gate_path)
    gate = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(gate)
    report = raw_dir / 'gnatprove.out'
    lines = read(report).decode('utf-8').splitlines()
    gate.check_totals(lines)
    gate.check_details(lines)
    units = [gate.UNIT.fullmatch(line).groups() for line in lines if line.startswith('in unit ')]
    if units != [('sia_continuity_response_wire', '13', '13')]:
        raise ValueError('unexpected focused core scope')
    audit = ROOT / 'response-core-report-audit-v1'
    if not checking:
        (audit / 'obj/gnatprove').mkdir(parents=True)
        shutil.copyfile(raw_dir / 'sia_continuity_response_wire.spark',
                        audit / 'obj/gnatprove/sia_continuity_response_wire.spark')
    copied = audit / 'obj/gnatprove/sia_continuity_response_wire.spark'
    if read(copied) != read(raw_dir / copied.name):
        raise ValueError('audit copy differs from retained raw report')
    gate.check_raw_diagnostics(audit, {'sia_continuity_response_wire'})
    total = next(line.strip() for line in lines if line.startswith('Total '))
    return {'status': 'SCOPED_REPORTED_CHECKS_DISCHARGED', 'unit': units[0][0],
            'summary_total_row': total, 'summary': artifact(report),
            'raw': artifact(raw_dir / copied.name), 'checker': artifact(gate_path),
            'assumptions': 'Ordinary modular dependency contracts and external toolchain assumptions remain.',
            'non_claim': 'Not a full-project check or proof of installed continuity.'}


def bundle(value, checking):
    members = {item['path'] for attempt in value['attempts'] for item in attempt['artifacts']}
    members.update(item['path'] for item in value['support'])
    base = ROOT / 'continuity-response-wire-development-v1/base.tar'
    members.add(str(base.relative_to(ROOT)))
    if len(members) > 512:
        raise ValueError('bundle member count exceeds bound')
    packed = io.BytesIO()
    total = 0
    with gzip.GzipFile(fileobj=packed, mode='wb', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w|', format=tarfile.USTAR_FORMAT) as archive:
            for name in sorted(members):
                path = ROOT / name
                if path.is_symlink() or not path.resolve().is_relative_to(ROOT.resolve()):
                    raise ValueError('unsafe evidence path')
                raw = read(path)
                total += len(raw)
                if total > 32 * 1024 * 1024:
                    raise ValueError('bundle data exceeds bound')
                entry = tarfile.TarInfo(name)
                entry.size, entry.mode = len(raw), path.stat().st_mode & 0o777
                archive.addfile(entry, io.BytesIO(raw))
    payload = packed.getvalue()
    path = REPO / 'docs/evidence/continuity-response-wire-diagnostics-v1.tar.gz'
    if checking:
        if read(path) != payload:
            raise ValueError('versioned evidence bundle does not reproduce')
    else:
        with path.open('xb') as stream:
            stream.write(payload)
    return {'path': str(path.relative_to(REPO)), 'sha256': hashlib.sha256(payload).hexdigest(),
            'bytes': len(payload), 'members': sorted(members),
            'reproduction': 'Extract retained base.tar, then overlay the five source paths from the selected attempt. Run its recorded commands under the declared limits.'}


def main():
    checking = sys.argv[1:] == ['--check']
    if sys.argv[1:] not in ([], ['--check']):
        raise ValueError('usage: retain-response-wire-evidence-v1.py [--check]')
    attempts = [attempt('continuity-response-wire-development-v' + str(i))
                for i in range(1, 2)]
    latest = attempts[-1]
    if len({entry['base_commit'] for entry in attempts}) != 1:
        raise ValueError('attempt bases differ; one archive cannot reproduce all')
    receipt = json.loads(read(ROOT / latest['directory'] / 'receipt.json'))
    core = [check for check in receipt['checks'] if check['name'] == 'core-proof']
    if len(core) != 1 or core[0]['exit'] != 0 or not core[0]['fresh_proof_summary']:
        raise ValueError('no completed fresh core proof')
    for filename, expected in latest['source_files'].items():
        if hashlib.sha256(read(REPO / filename)).hexdigest() != expected:
            raise ValueError('working source does not match latest recorded attempt')
    value = {'kind': 'Scoped response codec evidence; experimental and uninstalled',
             'retained_root': str(ROOT), 'attempts': attempts,
             'core': audit_core(latest['directory'], checking),
             'full_project_proof': 'UNPROVEN; prior full attempt reached 600 seconds',
             'integration': 'UNIMPLEMENTED: actual I/O, authenticated producers, actual harness restoration',
             'limits': ['One job; 512 MB per prover; 10 seconds per check.',
                        'Build 120 seconds, each runtime 30 seconds, focused proof 120 seconds.',
                        'No warning suppression, assumption annotation or original fixture removal.',
                        'No physical stack budget, WCET or whole-system assurance claim.'],
             'active_candidate': 'development-v1; experimental, full harness/project proof incomplete',
             'support': [artifact(ROOT / name) for name in (
                 'response-wire-source-review-v1.txt',
                 'response-wire-source-review-v2.txt',
                 'run-continuity-observation-wire-development-v2.py',
                 'run-continuity-response-wire-development-v1.py',
                 'retain-response-wire-evidence-v1.py')]}
    value['versioned_bundle'] = bundle(value, checking)
    raw = (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()
    if checking:
        if read(DEST) != raw:
            raise ValueError('committed manifest does not reproduce')
    else:
        with DEST.open('xb') as stream:
            stream.write(raw)
    print('scoped manifest matches retained evidence' if checking else 'scoped manifest retained')


if __name__ == '__main__':
    main()

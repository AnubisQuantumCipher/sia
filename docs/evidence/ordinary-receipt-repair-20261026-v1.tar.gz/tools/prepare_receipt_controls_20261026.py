"""Prepare successor receipt controls; the first snapshot remains UNRUN."""
import hashlib
import json
from pathlib import Path
import shutil

BASE = Path(__file__).resolve().parent
PRIOR = BASE / 'ordinary-receipt-controls-20261026-v1'
ROOT = BASE / 'ordinary-receipt-controls-20261026-v2'
CANDIDATE = BASE / 'ordinary-receipt-durability-20261026-v1'


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write('\n')


def main():
    if sha(PRIOR / 'execution-source.json') != \
            '2f1a29b1d54ac178fb1f31c8e2f2252d8786ab5f37c430bc19d0b16043938c58':
        raise ValueError('prior manifest changed')
    manifest = json.loads((PRIOR / 'execution-source.json').read_text())
    for name, expected in manifest.items():
        if sha(PRIOR / name) != expected:
            raise ValueError('prior source changed: ' + name)
    binding = json.loads((PRIOR / 'source-binding.json').read_text())
    for name, row in binding['files'].items():
        source = PRIOR / 'source' / name
        if sha(source) != row['sha256'] or source.stat().st_size != row['bytes'] \
                or sha(Path(binding['canonical']) / name) != row['canonical_sha256']:
            raise ValueError('baseline drift: ' + name)
    ROOT.mkdir(mode=0o700)
    for name in ('obj', 'bin', 'home', 'tmp', 'cache', 'out'):
        (ROOT / name).mkdir(mode=0o700)
    shutil.copytree(PRIOR / 'source', ROOT / 'source')
    for name in manifest:
        if name == 'config.json':
            value = json.loads((PRIOR / name).read_text().replace(str(PRIOR), str(ROOT)))
            save(ROOT / name, value)
        elif name == 'receipt_candidate.py':
            shutil.copyfile(CANDIDATE / 'proof_wrapper.py', ROOT / name)
        elif name == 'test_receipt_durability.py':
            shutil.copyfile(CANDIDATE / name, ROOT / name)
        else:
            shutil.copyfile(PRIOR / name, ROOT / name)
    save(ROOT / 'execution-source.json', {name: sha(ROOT / name) for name in manifest})
    print(json.dumps(dict(root=str(ROOT), manifest_sha256=sha(ROOT / 'execution-source.json'))))


if __name__ == '__main__':
    main()

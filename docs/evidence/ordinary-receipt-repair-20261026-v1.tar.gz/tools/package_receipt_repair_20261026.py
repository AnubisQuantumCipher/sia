"""Reproduce scoped ordinary-receipt repair evidence; no custody claim."""
import argparse
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

BASE = Path(__file__).resolve().parent
ROOT = BASE / 'ordinary-receipt-package-20261026-v1'
SOURCE = BASE / 'ordinary-receipt-durability-20261026-v1'
ARCHIVE = 'ordinary-receipt-repair-20261026-v1.tar.gz'
RUNS = {'component': 'ordinary-receipt-controls-20261026-v2',
        'integration': 'ordinary-receipt-integration-20261026-v1'}


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def add(files, prefix, directory, names):
    for name in names:
        key = prefix + '/' + name
        if key in files:
            raise ValueError('duplicate archive member')
        files[key] = directory / name


def roster():
    files = {}
    common = ('config.json', 'execution-source.json', 'source-binding.json',
              'execution-result.json', 'entry.json', 'active.json', 'proof.stdout',
              'proof.stderr', 'proof_wrapper.py', 'proof_payload.py', 'receipt_candidate.py',
              'receipt_baseline.py', 'test_receipt_durability.py', 'test_error_paths.py',
              'controller.py', 'proxy.py', 'OWNER-AUDIT.json', 'RESULT-INDEPENDENT-REVIEW.json',
              'EXECUTION-DECISION.json')
    for label, directory in RUNS.items():
        add(files, 'runs/' + label, BASE / directory, common)
    add(files, 'runs/integration', BASE / RUNS['integration'],
        ('invoke.py', 'outer.stdout', 'outer-result.json', 'TOOL-EXIT-OBSERVATION.json'))
    add(files, 'source', SOURCE, ('proof_wrapper.py', 'baseline_proof_wrapper.py',
        'test_receipt_durability.py', 'invoke.py', 'reviewed-v1-proof_wrapper.py',
        'reviewed-v1-test_receipt_durability.py', 'component-tested-v2-proof_wrapper.py',
        'component-tested-v2-test_receipt_durability.py', 'MODE-REPAIR-DISPOSITION.json',
        'STATIC-v1.json', 'STATIC-v2.json', 'STATIC-v3.json', 'AUDITOR-STATIC.json'))
    add(files, 'unrun', BASE / 'ordinary-receipt-controls-20261026-v1',
        ('UNRUN-DISPOSITION.json', 'execution-source.json', 'config.json'))
    add(files, 'tools', BASE, ('prepare_receipt_controls_20261026.py',
        'prepare_receipt_integration_20261026.py', 'audit_receipt_controls_20261026.py',
        'audit_receipt_integration_20261026.py', Path(__file__).name))
    return files


def verify_runs():
    for directory in RUNS.values():
        root = BASE / directory
        audit = json.loads((root / 'OWNER-AUDIT.json').read_text())
        for relative, expected in audit['evidence_sha256'].items():
            if sha(root / relative) != expected:
                raise ValueError('audited evidence drift: ' + relative)
        review = json.loads((root / 'RESULT-INDEPENDENT-REVIEW.json').read_text())
        if review['audit_sha256'] != sha(root / 'OWNER-AUDIT.json'):
            raise ValueError('independent review binding')
        for name, expected in json.loads((root / 'execution-source.json').read_text()).items():
            if sha(root / name) != expected:
                raise ValueError('execution source drift: ' + name)
        binding = json.loads((root / 'source-binding.json').read_text())
        for relative, row in binding['files'].items():
            path = root / 'source' / relative
            if sha(path) != row['sha256'] or path.stat().st_size != row['bytes']:
                raise ValueError('source snapshot drift: ' + relative)


def checked_members(files):
    if not 1 <= len(files) <= 128:
        raise ValueError('member count')
    total = 0
    members = {}
    for name, path in sorted(files.items()):
        if path.is_symlink() or not path.is_file() or path.stat().st_size > 1048576:
            raise ValueError('input type or size: ' + name)
        size = path.stat().st_size
        total += size
        if total > 8388608:
            raise ValueError('archive input limit')
        members[name] = dict(sha256=sha(path), bytes=size)
    return members


def archive_bytes(files, members):
    output = io.BytesIO()
    with gzip.GzipFile(fileobj=output, mode='wb', filename='', mtime=0) as zipped:
        with tarfile.open(fileobj=zipped, mode='w', format=tarfile.USTAR_FORMAT) as archive:
            for name, path in sorted(files.items()):
                with path.open('rb') as stream:
                    data = stream.read(1048577)
                if len(data) != members[name]['bytes'] or \
                        hashlib.sha256(data).hexdigest() != members[name]['sha256']:
                    raise ValueError('input changed during packaging')
                info = tarfile.TarInfo(name)
                info.size, info.mode, info.mtime = len(data), 0o444, 0
                archive.addfile(info, io.BytesIO(data))
    return output.getvalue()


def manifest(members, data):
    results = {label: json.loads((BASE / directory / 'OWNER-AUDIT.json').read_text())
               for label, directory in RUNS.items()}
    return dict(status='TESTED_ORDINARY_RECEIPT_REPAIR_NOT_CUSTODY_ACCEPTANCE',
                carrier_head='4ff2268179610297f67b1fd586e725c22ab66d12',
                archive=dict(path='docs/evidence/' + ARCHIVE, bytes=len(data),
                             sha256=hashlib.sha256(data).hexdigest()),
                members=members, results=results, authority='NONE',
                limitations=['Component and one normal actual-wrapper integration only.',
                    'Model-recorded tool exit note is not a signed platform receipt.',
                    'No hardware durability, complete crash/fault campaign or authenticated directory ancestry.',
                    'Private existing directory and nonhostile ordinary execution premises remain.',
                    'Full source snapshots are bound, not all reproduced here; local paths retained.',
                    'Observer-loss/successor recovery, C14 and all mandatory mission gates remain open.',
                    'No installed product, service, release or marketplace change.'])


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--check', action='store_true')
    args = parser.parse_args()
    verify_runs()
    files = roster()
    members = checked_members(files)
    data = archive_bytes(files, members)
    expected = manifest(members, data)
    encoded = (json.dumps(expected, indent=2, sort_keys=True) + '\n').encode()
    if args.check:
        if (ROOT / ARCHIVE).read_bytes() != data or (ROOT / 'manifest.json').read_bytes() != encoded:
            raise ValueError('package reproduction mismatch')
    else:
        ROOT.mkdir(mode=0o700)
        for name, content in ((ARCHIVE, data), ('manifest.json', encoded)):
            with (ROOT / name).open('xb') as stream:
                if stream.write(content) != len(content):
                    raise OSError('short package write')
    print(json.dumps(dict(status='PACKAGE_CHECK_PASS' if args.check else 'PACKAGE_CREATED',
                          archive=expected['archive'], members=len(members))))


if __name__ == '__main__':
    main()

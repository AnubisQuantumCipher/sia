"""Retain exact-source profiling evidence under the original suite envelope."""
import datetime
import hashlib
import json
from pathlib import Path
import subprocess

from run_sdk_sweep import BASE, ROOT, pins

WORK = ROOT / 'sdk-empty-noop-v6'
PREVIOUS = ROOT / 'sdk-scratch-sweep-v4'
OUT = ROOT / 'sdk-code-access-audit-v1'


def main():
    if (OUT / 'admission.json').exists():
        raise FileExistsError('preserve prior evidence')
    declared = json.loads((PREVIOUS / 'trace-admission.json').read_text())
    argv = declared['command'][:]
    argv[argv.index('--chdir') + 1] = str(WORK)
    at = argv.index('--chdir')
    argv[at:at] = ['--ro-bind', str(OUT), str(OUT), '--ro-bind', str(WORK), str(WORK)]
    argv[argv.index('-c'):] = [str(OUT / 'observe.py')]
    diagnostic = hashlib.sha256((OUT / 'observe.py').read_bytes()).hexdigest()
    record = {'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'command': argv, 'environment': declared['environment'],
              'source_before': pins(WORK), 'baseline_before': pins(BASE), 'previous_before': pins(PREVIOUS),
              'diagnostic_sha256': diagnostic,
              'runner_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              'scope': 'Audit-hook regression diagnostic; 30s work cap and 5s grace. Not candidate acceptance.'}
    (OUT / 'admission.json').write_text(json.dumps(record, indent=2) + '\n')
    try:
        result = subprocess.run(argv, env=declared['environment'], capture_output=True,
                                timeout=40, check=False)
        out, err, code = result.stdout, result.stderr, result.returncode
    except subprocess.TimeoutExpired as error:
        out, err, code = error.stdout or b'', error.stderr or b'', 124
    (OUT / 'stdout.json').write_bytes(out)
    (OUT / 'stderr').write_bytes(err)
    record.update(exit=code, source_after=pins(WORK), baseline_after=pins(BASE), previous_after=pins(PREVIOUS),
                  stdout_sha256=hashlib.sha256(out).hexdigest(),
                  stderr_sha256=hashlib.sha256(err).hexdigest(),
                  diagnostic_after=hashlib.sha256((OUT / 'observe.py').read_bytes()).hexdigest())
    record['source_unchanged'] = (record['source_before'] == record['source_after']
                                  and record['baseline_before'] == record['baseline_after']
                                  and record['previous_before'] == record['previous_after']
                                  and diagnostic == record['diagnostic_after'])
    (OUT / 'result.json').write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps({'exit': code, 'source_unchanged': record['source_unchanged'],
                      'stderr': err.decode()}, indent=2))
    return code


if __name__ == '__main__':
    raise SystemExit(main())

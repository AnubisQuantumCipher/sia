# Bounded producer-derived relationship checker; source only, nonauthorizing.
import sys
import time

__doc__ = 'Bounded producer-derived relationship checker; source only, nonauthorizing.'

DERIVED_SO = '/usr/lib/python3.14/lib-dynload/pyexpat.cpython-314-aarch64-linux-gnu.so'
DERIVED_PY = '/usr/lib/python3.14/xml/parsers/expat.py'
DERIVED_PYC = '/usr/lib/python3.14/xml/parsers/__pycache__/expat.cpython-314.pyc'
DERIVED_SPEC_KEYS = ('name', 'loader', 'origin', 'loader_state',
                     'submodule_search_locations', '_uninitialized_submodules',
                     '_set_fileattr', '_cached', '_initializing')
DERIVED_EXPORTS = (('ModuleSpec', 'ModuleSpec'), ('FrozenImporter', 'FrozenImporter'))
DERIVED_EXTERNAL = (('FileLoader', 'FileLoader'), ('SourceLoader', 'SourceLoader'),
                    ('LoaderBasics', '_LoaderBasics'),
                    ('SourceFileLoader', 'SourceFileLoader'),
                    ('ExtensionFileLoader', 'ExtensionFileLoader'))


def new_reference_array(bound):
    return [None] * bound


def new_derived_refs():
    return DerivedRefs()


def new_roster_row():
    return {'name': None, 'origin': None, '_module': None, '_checked': False}


def retire_reference_cell(sequence, index):
    if type(sequence) is list:
        sequence[index] = None
    else:
        list.__setitem__(sequence, index, None)


def retire_reference_array(sequence, guard):
    """Attempt every fixed slot, resuming after a recorded cell failure.

    Successful fixed-guard entry/exit is inert. Each attempted retirement
    records last_index first; cell errors never retry or skip a later cell.
    This does not qualify asynchronous interruption between those statements.
    """
    last_index = -1
    for _attempt in range(8192):
        with guard:
            for index in range(last_index + 1, 8192):
                last_index = index
                retire_reference_cell(sequence, index)
        if last_index == 8191:
            return
    with guard:
        raise RuntimeError('derived scratch sweep incomplete')


def retire_owned_attribute(value, field):
    object.__setattr__(value, field, None)


def retire_roster_module(row):
    if '_module' in row:
        dict.__setitem__(row, '_module', None)


class DerivedRefs:
    """Exactly32 persistent identity fields, no dynamic namespace."""

    __slots__ = ('sys_actual', 'type_intrinsic', 'member_get_intrinsic',
                 'dict_intrinsic', 'module_type', 'getset_descriptor_type',
                 'mappingproxy_type', 'module_namespace_descriptor',
                 'type_namespace_descriptor', 'type_bases_descriptor',
                 'getset_get_intrinsic', 'object_getattribute_intrinsic',
                 'bootstrap_module', 'external_module', 'ModuleSpec',
                 'FileLoader', 'SourceLoader', 'LoaderBasics', 'SourceFileLoader',
                 'ExtensionFileLoader', 'FrozenImporter', 'spec_namespace_descriptor',
                 'fileloader_namespace_descriptor', 'P', 'W', 'E', 'M',
                 'S_P', 'S_W', 'L_P', 'L_W', 'modules_dict')

    def __init__(self):
        for field in DerivedRefs.__slots__:
            object.__setattr__(self, field, None)


class DerivedClearGuard:
    """Fixed cleanup phase; retain actual errors before independent attempts."""

    __slots__ = ('state', 'phase')

    def __init__(self, state, phase):
        self.state, self.phase = state, phase

    def __enter__(self):
        return self

    def __exit__(self, kind, error, traceback):
        if error is not None:
            state = self.state
            if state.used < 64:
                state.raw[state.used], state.phases[state.used] = error, self.phase
                state.used += 1
            else:
                state.overflow = True
        return error is not None


class DerivedChecker:
    """One scratch and bounded strong roster; no filesystem or provider imports."""

    __slots__ = ('state', 'refs', 'keys', 'values', 'count', 'pair',
                 'current_key', 'current_value', 'rows', 'row_count',
                 'scratch_guard', 'row_guard', 'refs_guard', 'prepare_guard')

    def __init__(self, state, preparation_guard=None):
        self.state = state
        self.refs, self.keys, self.values, self.rows = None, None, None, None
        self.count, self.row_count = 0, 0
        self.pair, self.current_key, self.current_value = None, None, None
        self.scratch_guard, self.row_guard, self.refs_guard = None, None, None
        self.prepare_guard = preparation_guard
        if self.prepare_guard is None:
            self.prepare_guard = DerivedClearGuard(state, 'checker-prepare')
        initial = state.used
        with self.prepare_guard:
            self.scratch_guard = DerivedClearGuard(state, 'scratch-clear')
            self.row_guard = DerivedClearGuard(state, 'roster-reference-clear')
            self.refs_guard = DerivedClearGuard(state, 'selected-reference-clear')
            self.refs = new_derived_refs()
            self.keys = new_reference_array(8192)
            self.values = new_reference_array(8192)
            self.rows = new_reference_array(8192)
            for index in range(8192):
                self.rows[index] = new_roster_row()
            self.seed_intrinsics()
        if state.used != initial or state.overflow:
            raise state.failure

    def seed_intrinsics(self):
        """Trusted interpreter capsule, NOT inference from candidate namespaces."""
        refs = self.refs
        refs.sys_actual, refs.type_intrinsic = sys, type
        refs.dict_intrinsic, refs.module_type = dict, type(sys)
        refs.module_namespace_descriptor = type(sys).__dict__['__dict__']
        refs.type_namespace_descriptor = type.__dict__['__dict__']
        refs.type_bases_descriptor = type.__dict__['__bases__']
        refs.getset_descriptor_type = type(refs.type_namespace_descriptor)
        refs.mappingproxy_type = type(type.__dict__)
        refs.getset_get_intrinsic = refs.getset_descriptor_type.__dict__['__get__']
        member_kind = type(refs.module_namespace_descriptor)
        refs.member_get_intrinsic = member_kind.__dict__['__get__']
        refs.object_getattribute_intrinsic = object.__getattribute__
        # These native seeds are the explicit trusted installed-interpreter premise.
        # Mutable exports/tautological type checks do not independently attest them.

    def tick(self, stage=None):
        if stage is not None:
            self.state.stage = stage
        if time.monotonic_ns() >= self.state.work:
            raise TimeoutError('derived original work deadline')

    def text(self, value, points=256, byte_limit=1024, empty=True):
        if type(value) is not str or len(value) > points or (not empty and not value):
            raise ValueError('derived exact text prelength')
        self.tick()
        size = len(value)
        if size > (536870912 - self.state.read_bytes) // 4:
            raise ValueError('derived aggregate text budget')
        self.state.read_bytes += 4 * size
        encoded = 0
        for start in range(0, size, 1024):
            self.tick()
            chunk = value[start:start + 1024].encode('utf-8', 'strict')
            encoded += len(chunk)
            if encoded > byte_limit:
                raise ValueError('derived UTF8 byte bound')
            self.tick()
        return value

    def same_text(self, value, expected, points=256, byte_limit=1024):
        self.text(value, points, byte_limit)
        self.text(expected, points, byte_limit)
        self.tick()
        mismatch = value != expected
        self.tick()
        if mismatch:
            raise ValueError('derived exact text mismatch')

    def clear_scratch(self):
        guard = self.scratch_guard if self.scratch_guard is not None else self.prepare_guard
        for field in ('pair', 'current_key', 'current_value'):
            with guard:
                retire_owned_attribute(self, field)
        if self.keys is not None:
            retire_reference_array(self.keys, guard)
        if self.values is not None:
            retire_reference_array(self.values, guard)
        self.count = 0

    def snapshot(self, namespace, bound=8192):
        initial = self.state.used
        self.clear_scratch()
        if self.state.used != initial or self.state.overflow:
            raise self.state.failure
        previous_stage = self.state.stage
        self.tick('KEYS')
        if type(bound) is not int or not 0 <= bound <= 8192:
            raise ValueError('derived exact namespace limit')
        kind = type(namespace)
        if kind is not dict and kind is not self.refs.mappingproxy_type:
            raise ValueError('derived native namespace type')
        length = len(namespace)
        if length > bound:
            raise ValueError('derived namespace count bound')
        iterator = iter(namespace.items())
        try:
            for _ in range(8193):
                self.tick()
                self.pair = next(iterator, None)
                self.tick()
                if self.pair is None:
                    break
                if type(self.pair) is not tuple or len(self.pair) != 2:
                    raise ValueError('derived native pair shape')
                if self.count >= bound:
                    raise ValueError('derived namespace excess before capture')
                self.current_key, self.current_value = self.pair
                self.keys[self.count] = self.current_key
                self.values[self.count] = self.current_value
                self.count += 1
                self.pair, self.current_key, self.current_value = None, None, None
            else:
                raise ValueError('derived native iterator missing EOF')
            if len(namespace) != length or self.count != length:
                raise ValueError('derived namespace changed during capture')
            for index in range(self.count):
                key = self.text(self.keys[index], empty=False)
                if '\x00' in key:
                    raise ValueError('derived key NUL')
        finally:
            self.pair, self.current_key, self.current_value = None, None, None
            iterator = None
        self.state.stage = previous_stage

    def field(self, name, required=True):
        """ONLY owned paired arrays; never reindex a foreign namespace."""
        self.text(name)
        found, value = False, None
        for index in range(self.count):
            self.tick()
            key = self.text(self.keys[index], empty=False)
            self.text(name)
            if key == name:
                if found:
                    raise ValueError('derived duplicate field')
                found, value = True, self.values[index]
        if required and not found:
            raise ValueError('derived missing required field')
        return found, value

    def required(self, name):
        return self.field(name)[1]

    def remember(self, field, value, recheck):
        if recheck:
            if object.__getattribute__(self.refs, field) is not value:
                raise ValueError('derived selected first identity changed')
        else:
            object.__setattr__(self.refs, field, value)
        return value

    def native(self, role, descriptor, receiver, owner, name):
        refs = self.refs
        if role == 'MODULE_NAMESPACE':
            expected_kind = type(refs.module_namespace_descriptor)
            operation = refs.member_get_intrinsic
            if type(receiver) is not refs.module_type:
                raise ValueError('derived exact module receiver')
        else:
            expected_kind = refs.getset_descriptor_type
            operation = refs.getset_get_intrinsic
            if role in ('TYPE_NAMESPACE', 'TYPE_BASES'):
                if type(receiver) is not refs.type_intrinsic:
                    raise ValueError('derived exact class receiver')
            elif role == 'SPEC_NAMESPACE':
                if type(receiver) is not refs.ModuleSpec:
                    raise ValueError('derived exact spec receiver')
            elif role == 'LOADER_NAMESPACE':
                if (type(receiver) is not refs.SourceFileLoader
                        and type(receiver) is not refs.ExtensionFileLoader):
                    raise ValueError('derived exact loader receiver')
            else:
                raise ValueError('derived fixed native role')
        if type(descriptor) is not expected_kind:
            raise ValueError('derived native descriptor kind')
        get = refs.object_getattribute_intrinsic
        self.tick()
        actual_owner = get(descriptor, '__objclass__')
        self.tick()
        if actual_owner is not owner:
            raise ValueError('derived native descriptor owner')
        self.tick()
        actual_name = get(descriptor, '__name__')
        self.tick()
        self.same_text(actual_name, name)
        self.tick()
        result = operation(descriptor, receiver, type(receiver))
        self.tick()
        expected = dict
        if role == 'TYPE_NAMESPACE':
            expected = refs.mappingproxy_type
        elif role == 'TYPE_BASES':
            expected = tuple
        if type(result) is not expected:
            raise ValueError('derived native descriptor output')
        self.tick()
        return result

    def module_namespace(self, module):
        return self.native('MODULE_NAMESPACE', self.refs.module_namespace_descriptor,
                           module, self.refs.module_type, '__dict__')

    def class_namespace(self, value):
        return self.native('TYPE_NAMESPACE', self.refs.type_namespace_descriptor,
                           value, self.refs.type_intrinsic, '__dict__')

    def bases(self, value):
        return self.native('TYPE_BASES', self.refs.type_bases_descriptor,
                           value, self.refs.type_intrinsic, '__bases__')

    def module_descriptor_export(self):
        self.snapshot(self.class_namespace(self.refs.module_type), 256)
        if self.required('__dict__') is not self.refs.module_namespace_descriptor:
            raise ValueError('derived intrinsic module descriptor export')

    def bind_actual_sys(self, recheck=False):
        self.module_descriptor_export()
        self.snapshot(self.module_namespace(self.refs.sys_actual))
        modules = self.required('modules')
        self.bind_modules(modules, recheck)

    def bind_modules(self, modules, recheck=False):
        if type(modules) is not dict:
            raise ValueError('derived modules exact dict')
        first = self.refs.modules_dict
        if first is None and not recheck:
            self.refs.modules_dict = modules
        elif first is not modules:
            raise ValueError('derived actual sys modules first identity changed')

    def capture_exports(self, provider, exports, recheck):
        self.snapshot(self.module_namespace(provider))
        for field, export in exports:
            candidate = self.required(export)
            if type(candidate) is not self.refs.type_intrinsic:
                raise ValueError('derived exact anchor metaclass')
            self.remember(field, candidate, recheck)

    def checked_descriptor(self, cls, field, recheck):
        self.snapshot(self.class_namespace(cls), 256)
        descriptor = self.required('__dict__')
        if type(descriptor) is not self.refs.getset_descriptor_type:
            raise ValueError('derived heap dictionary descriptor kind')
        get = self.refs.object_getattribute_intrinsic
        self.tick()
        actual_owner = get(descriptor, '__objclass__')
        self.tick()
        if actual_owner is not cls:
            raise ValueError('derived heap dictionary descriptor owner')
        self.tick()
        actual_name = get(descriptor, '__name__')
        self.tick()
        self.same_text(actual_name, '__dict__')
        self.remember(field, descriptor, recheck)

    def base_one(self, anchor, expected):
        actual = self.bases(anchor)
        if len(actual) != 1 or actual[0] is not expected:
            raise ValueError('derived exact single base identity')

    def base_two(self, anchor, first, second):
        actual = self.bases(anchor)
        if len(actual) != 2 or actual[0] is not first or actual[1] is not second:
            raise ValueError('derived exact double base identity')

    def intrinsic_distinct(self, anchor, canonical):
        refs = self.refs
        if (anchor is refs.type_intrinsic or anchor is canonical
                or anchor is refs.module_type or anchor is refs.getset_descriptor_type
                or anchor is refs.mappingproxy_type):
            raise ValueError('derived anchor intrinsic collision')

    def anchor_distinct(self):
        r = self.refs
        if (r.ModuleSpec is r.FileLoader or r.ModuleSpec is r.SourceLoader
                or r.ModuleSpec is r.LoaderBasics or r.ModuleSpec is r.SourceFileLoader
                or r.ModuleSpec is r.ExtensionFileLoader or r.ModuleSpec is r.FrozenImporter
                or r.FileLoader is r.SourceLoader or r.FileLoader is r.LoaderBasics
                or r.FileLoader is r.SourceFileLoader or r.FileLoader is r.ExtensionFileLoader
                or r.FileLoader is r.FrozenImporter or r.SourceLoader is r.LoaderBasics
                or r.SourceLoader is r.SourceFileLoader or r.SourceLoader is r.ExtensionFileLoader
                or r.SourceLoader is r.FrozenImporter or r.LoaderBasics is r.SourceFileLoader
                or r.LoaderBasics is r.ExtensionFileLoader or r.LoaderBasics is r.FrozenImporter
                or r.SourceFileLoader is r.ExtensionFileLoader
                or r.SourceFileLoader is r.FrozenImporter
                or r.ExtensionFileLoader is r.FrozenImporter):
            raise ValueError('derived anchor distinctness')

    def anchor_bases(self):
        refs = self.refs
        actual = self.bases(refs.type_intrinsic)
        if len(actual) != 1 or type(actual[0]) is not type:
            raise ValueError('derived intrinsic object relation')
        canonical = actual[0]
        actual = None
        self.anchor_distinct()
        self.intrinsic_distinct(refs.ModuleSpec, canonical)
        self.intrinsic_distinct(refs.FileLoader, canonical)
        self.intrinsic_distinct(refs.SourceLoader, canonical)
        self.intrinsic_distinct(refs.LoaderBasics, canonical)
        self.intrinsic_distinct(refs.SourceFileLoader, canonical)
        self.intrinsic_distinct(refs.ExtensionFileLoader, canonical)
        self.intrinsic_distinct(refs.FrozenImporter, canonical)
        self.base_one(refs.ModuleSpec, canonical)
        self.base_one(refs.FileLoader, canonical)
        self.base_one(refs.LoaderBasics, canonical)
        self.base_one(refs.FrozenImporter, canonical)
        self.base_one(refs.SourceLoader, refs.LoaderBasics)
        self.base_two(refs.SourceFileLoader, refs.FileLoader, refs.SourceLoader)
        self.base_two(refs.ExtensionFileLoader, refs.FileLoader, refs.LoaderBasics)

    def closed_keys(self, allowed, optional=None):
        expected = len(allowed)
        if optional is None and self.count != expected:
            raise ValueError('derived exact closed key count')
        if optional is not None and self.count not in (expected, expected + 1):
            raise ValueError('derived bootstrap key count')
        for index in range(self.count):
            key, found = self.keys[index], False
            for literal in allowed:
                self.text(key)
                self.text(literal)
                if key == literal:
                    found = True
            if optional is not None:
                self.text(key)
                self.text(optional)
                if key == optional:
                    found = True
            if not found:
                raise ValueError('derived unknown closed key')
        for literal in allowed:
            self.required(literal)

    def spec_namespace(self, spec):
        return self.native('SPEC_NAMESPACE', self.refs.spec_namespace_descriptor,
                           spec, self.refs.ModuleSpec, '__dict__')

    def bootstrap_spec(self, module, canonical):
        self.snapshot(self.module_namespace(module))
        spec = self.required('__spec__')
        self.snapshot(self.spec_namespace(spec))
        self.closed_keys(DERIVED_SPEC_KEYS[:-1], '_initializing')
        self.same_text(self.required('name'), canonical)
        self.same_text(self.required('origin'), 'frozen')
        if self.required('loader') is not self.refs.FrozenImporter:
            raise ValueError('derived bootstrap loader identity')
        if self.required('_cached') is not None or self.required('_set_fileattr') is not False:
            raise ValueError('derived bootstrap cache/location')
        empty = self.required('_uninitialized_submodules')
        if type(empty) is not list or len(empty) != 0:
            raise ValueError('derived bootstrap empty list')
        found, value = self.field('_initializing', False)
        if found and value is not False:
            raise ValueError('derived bootstrap initialization')
        # loader_state/search_locations are required but explicitly OPAQUE_UNUSED.

    def bootstrap(self, recheck):
        refs = self.refs
        self.module_descriptor_export()
        self.snapshot(refs.modules_dict)
        boot = self.remember('bootstrap_module', self.required('_frozen_importlib'), recheck)
        external = self.remember('external_module', self.required('_frozen_importlib_external'), recheck)
        if (self.required('importlib._bootstrap') is not boot
                or self.required('importlib._bootstrap_external') is not external
                or boot is external):
            raise ValueError('derived frozen module alias')
        self.capture_exports(boot, DERIVED_EXPORTS, recheck)
        self.capture_exports(external, DERIVED_EXTERNAL, recheck)
        self.checked_descriptor(refs.ModuleSpec, 'spec_namespace_descriptor', recheck)
        self.checked_descriptor(refs.FileLoader, 'fileloader_namespace_descriptor', recheck)
        self.anchor_bases()
        self.bootstrap_spec(boot, '_frozen_importlib')
        self.bootstrap_spec(external, '_frozen_importlib_external')
        self.snapshot(refs.modules_dict)
        machinery = self.required('importlib.machinery')
        self.snapshot(self.module_namespace(machinery))
        for field in ('ModuleSpec', 'SourceFileLoader', 'ExtensionFileLoader'):
            if self.required(field) is not object.__getattribute__(refs, field):
                raise ValueError('derived machinery export alias')

    def doc(self):
        value = self.required('__doc__')
        if value is not None:
            self.text(value, 65536, 65536)

    def absent(self, name):
        if self.field(name, False)[0]:
            raise ValueError('derived forbidden present field')

    def optional_none(self, name):
        if self.field(name, False)[1] is not None:
            raise ValueError('derived optional None field')

    def role(self, value, name):
        self.snapshot(self.module_namespace(value))
        self.same_text(self.required('__name__'), name)
        self.doc()
        for field in ('__package__', '__loader__', '__spec__'):
            if self.required(field) is not None:
                raise ValueError('derived synthetic required None')
        self.optional_none('__file__')
        self.optional_none('__cached__')
        self.absent('__path__')

    def loader(self, value, cls, canonical, path):
        if type(value) is not cls:
            raise ValueError('derived exact loader type')
        namespace = self.native('LOADER_NAMESPACE', self.refs.fileloader_namespace_descriptor,
                                value, self.refs.FileLoader, '__dict__')
        self.snapshot(namespace)
        self.closed_keys(('name', 'path'))
        self.same_text(self.required('name'), canonical)
        self.same_text(self.required('path'), path, 4096, 4096)

    def file_spec(self, spec, loader, canonical, path, cached):
        self.snapshot(self.spec_namespace(spec))
        self.closed_keys(DERIVED_SPEC_KEYS)
        self.same_text(self.required('name'), canonical)
        self.same_text(self.required('origin'), path, 4096, 4096)
        if self.required('loader') is not loader:
            raise ValueError('derived spec loader identity')
        for field in ('loader_state', 'submodule_search_locations'):
            if self.required(field) is not None:
                raise ValueError('derived spec required None')
        empty = self.required('_uninitialized_submodules')
        if type(empty) is not list or len(empty) != 0:
            raise ValueError('derived spec empty list')
        if (self.required('_set_fileattr') is not True
                or self.required('_initializing') is not False):
            raise ValueError('derived exact spec booleans')
        actual = self.required('_cached')
        if cached is None:
            if actual is not None:
                raise ValueError('derived producer spec cache')
        else:
            self.same_text(actual, cached, 4096, 4096)

    def file_module(self, module, canonical, path, package, cached, recheck):
        self.snapshot(self.module_namespace(module))
        self.same_text(self.required('__name__'), canonical)
        self.same_text(self.required('__package__'), package)
        self.same_text(self.required('__file__'), path, 4096, 4096)
        self.doc()
        self.absent('__path__')
        suffix = 'P' if canonical == 'pyexpat' else 'W'
        spec = self.remember('S_' + suffix, self.required('__spec__'), recheck)
        loader = self.remember('L_' + suffix, self.required('__loader__'), recheck)
        if cached is None:
            self.optional_none('__cached__')
        else:
            self.same_text(self.required('__cached__'), cached, 4096, 4096)
        if self.required('errors') is not self.refs.E or self.required('model') is not self.refs.M:
            raise ValueError('derived module role exports')
        if suffix == 'W' and self.required('sys') is not self.refs.sys_actual:
            raise ValueError('derived wrapper actual sys export')
        cls = self.refs.ExtensionFileLoader if suffix == 'P' else self.refs.SourceFileLoader
        self.loader(loader, cls, canonical, path)
        self.file_spec(spec, loader, canonical, path, cached)

    def graph(self, recheck=False):
        self.tick('RECHECK' if recheck else 'ANCHORS')
        self.bind_actual_sys(recheck=self.refs.modules_dict is not None)
        self.bootstrap(recheck)
        self.snapshot(self.refs.modules_dict)
        for field, key in (('P', 'pyexpat'), ('W', 'xml.parsers.expat'),
                           ('E', 'pyexpat.errors'), ('M', 'pyexpat.model')):
            self.remember(field, self.required(key), recheck)
        if (self.required('xml.parsers.expat.errors') is not self.refs.E
                or self.required('xml.parsers.expat.model') is not self.refs.M):
            raise ValueError('derived wrapper child aliases')
        allowed = ('pyexpat.errors', 'pyexpat.model',
                   'xml.parsers.expat.errors', 'xml.parsers.expat.model')
        for index in range(self.count):
            name = self.text(self.keys[index])
            if name.startswith(('pyexpat.', 'xml.parsers.expat.')):
                matched = False
                for literal in allowed:
                    self.text(name)
                    self.text(literal)
                    if name == literal:
                        matched = True
                if not matched:
                    raise ValueError('derived extra registered child')
        roles = (self.refs.P, self.refs.W, self.refs.E, self.refs.M)
        for index in range(4):
            if type(roles[index]) is not self.refs.module_type:
                raise ValueError('derived exact role module')
            for earlier in range(index):
                if roles[index] is roles[earlier]:
                    raise ValueError('derived role distinctness')
            if roles[index] is self.refs.bootstrap_module or roles[index] is self.refs.external_module:
                raise ValueError('derived role bootstrap collision')
        self.tick('METADATA')
        self.role(self.refs.E, 'pyexpat.errors')
        self.role(self.refs.M, 'pyexpat.model')
        self.file_module(self.refs.P, 'pyexpat', DERIVED_SO, '', None, recheck)
        self.file_module(self.refs.W, 'xml.parsers.expat', DERIVED_PY,
                         'xml.parsers', DERIVED_PYC, recheck)

    def start_roster(self):
        self.bind_actual_sys(recheck=True)
        self.snapshot(self.refs.modules_dict)
        for index in range(self.count):
            if type(self.values[index]) is not self.refs.module_type:
                raise ValueError('derived census exact ModuleType')
        for index in range(self.count):
            name = self.keys[index]
            for earlier in range(index):
                self.text(name)
                self.text(self.rows[earlier]['name'])
                if name == self.rows[earlier]['name']:
                    raise ValueError('CENSUS_COVERAGE')
            row = self.rows[index]
            row['name'], row['_module'] = name, self.values[index]
            self.row_count += 1
        self.clear_scratch()

    def generic_fields(self, module):
        self.snapshot(self.module_namespace(module))
        path = self.field('__file__', False)[1]
        cached = self.field('__cached__', False)[1]
        spec = self.field('__spec__', False)[1]
        origin = None
        if spec is not None:
            self.snapshot(self.spec_namespace(spec))
            origin = self.field('origin', False)[1]
            if origin is not None:
                self.text(origin, 4096, 4096)
        return path, cached, origin

    def path(self, value):
        self.text(value, 4096, 4096, False)
        if not value.startswith('/') or '\x00' in value:
            raise ValueError('derived absolute path shape')
        for part in value.split('/'):
            self.text(part, 4096, 4096)
            if part == '.' or part == '..':
                raise ValueError('derived path dot component')

    def builtin_marker(self, origin):
        for literal in ('built-in', 'frozen'):
            self.text(origin, 4096, 4096)
            self.text(literal)
            if origin == literal:
                return True
        return False

    def inspect_row(self, row, origin_check, cache_exists):
        if row['_checked']:
            raise ValueError('CENSUS_VISIT')
        module = row['_module']
        path, cached, origin = self.generic_fields(module)
        if path is not None:
            self.path(path)
            actual = origin_check(path)
            if cached is not None:
                self.path(cached)
                exists = cache_exists(cached)
                if type(exists) is not bool:
                    raise ValueError('derived cache exists exact bool')
                if exists:
                    origin_check(cached)
        elif type(origin) is str and self.builtin_marker(origin):
            actual = origin
        elif module is self.refs.E or module is self.refs.M:
            actual = 'DERIVED_PINNED_PYEXPAT_RELATIONSHIP'
        else:
            self.state.refusal_seen = True
            name = row['name']
            if type(name) is str and len(name) <= 256:
                self.state.refusal_name, self.state.refusal_name_complete = name, True
            raise ValueError('unknown namespace or nonregular module origin')
        self.text(actual, 4096, 4096)
        row['origin'], row['_checked'] = actual, True

    def census(self, origin_check, cache_exists):
        self.start_roster()
        for index in range(self.row_count):
            self.tick('METADATA')
            self.inspect_row(self.rows[index], origin_check, cache_exists)
        self.final_roster()

    def final_roster(self):
        self.tick('RECHECK')
        self.bind_actual_sys(recheck=True)
        self.snapshot(self.refs.modules_dict)
        self.tick('RECHECK')
        if self.count != self.row_count:
            raise ValueError('CENSUS_COVERAGE')
        for index in range(self.count):
            name, module = self.keys[index], self.values[index]
            if type(module) is not self.refs.module_type:
                raise ValueError('derived census final exact ModuleType')
            matches = 0
            for earlier in range(index):
                self.text(name)
                self.text(self.keys[earlier])
                if name == self.keys[earlier]:
                    raise ValueError('CENSUS_COVERAGE')
            for position in range(self.row_count):
                row = self.rows[position]
                self.text(name)
                self.text(row['name'])
                if name == row['name']:
                    matches += 1
                    if not row['_checked']:
                        raise ValueError('CENSUS_VISIT')
                    if module is not row['_module']:
                        raise ValueError('CENSUS_STRONG_IDENTITY')
            if matches != 1:
                raise ValueError('CENSUS_COVERAGE')
        self.clear_scratch()

    def scalar_rows(self):
        for index in range(self.row_count):
            row = self.rows[index]
            if row['_module'] is not None or not row['_checked']:
                raise ValueError('derived roster not retired before serialization')
            del row['_module']
            del row['_checked']
        return self.rows[:self.row_count]

    def clear(self):
        self.clear_scratch()
        guard = self.row_guard if self.row_guard is not None else self.prepare_guard
        if self.rows is not None:
            for index in range(8192):
                with guard:
                    row = self.rows[index]
                    if row is not None:
                        retire_roster_module(row)
        guard = self.refs_guard if self.refs_guard is not None else self.prepare_guard
        if self.refs is not None:
            for field in DerivedRefs.__slots__:
                with guard:
                    retire_owned_attribute(self.refs, field)
        with guard:
            if time.monotonic_ns() >= self.state.total:
                raise TimeoutError('derived total deadline after independent clearing')


def build_checker(state):
    """Preallocate partial-owner guard before object/arrays; caller owns success."""
    guard = DerivedClearGuard(state, 'checker-prepare')
    checker = object.__new__(DerivedChecker)
    try:
        DerivedChecker.__init__(checker, state, guard)
    except BaseException:
        # Initial exact slots precede fallible preparation; cleanup is independent.
        checker.clear()
        raise
    return checker

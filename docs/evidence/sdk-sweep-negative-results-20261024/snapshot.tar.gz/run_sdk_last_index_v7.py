"""Run the private exhaustive-sweep successor under unchanged fixture caps."""
import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
BASE = ROOT / 'sdk-fixtures-constant-clock-v1'
WORK = ROOT / 'sdk-last-index-v7'
PREVIOUS = ROOT / 'sdk-scratch-sweep-v4'


def pins(directory):
    declared = json.loads((directory / 'OWN-SOURCE.json').read_text())['files']
    actual = {}
    for name, entry in declared.items():
        path = directory / name
        info = path.stat()
        if any(getattr(info, key) != value for key, value in entry['identity'].items()):
            raise RuntimeError('source identity changed: ' + name)
        actual[name] = hashlib.sha256(path.read_bytes()).hexdigest()
        if actual[name] != entry['sha256']:
            raise RuntimeError('source digest changed: ' + name)
    return actual


def command(phase):
    declared = json.loads((BASE / 'suite-admission.json').read_text())
    argv = declared['command'][:]
    at = argv.index(str(BASE))
    argv[at + 2:at + 2] = ['--ro-bind', str(WORK), str(WORK), '--ro-bind', str(PREVIOUS), str(PREVIOUS)]
    argv[argv.index('--chdir') + 1] = str(WORK)
    argv[argv.index('-s') + 1] = str(WORK)
    if phase == 'trace':
        argv[argv.index('120s')] = '30s'
        expression = ("import sys,unittest; sys.path.insert(0," + repr(str(WORK)) + "); "
                      "names=['test_sweep_resume_position','test_empty_retirement','test_scratch_sweep_trace','test_retirement_equivalence','test_sys_fixture_namespace','test_graph_matrix.GraphMatrix.test_collision_all_native_namespace_frontiers_graph_and_census',"
                      "'test_graph_additions.GraphAdditions.test_persistent_late_insert_replace_both_keys_every_frontier']; "
                      "suite=unittest.defaultTestLoader.loadTestsFromNames(names); "
                      "result=unittest.TextTestRunner(verbosity=2).run(suite); "
                      "raise SystemExit(0 if result.wasSuccessful() else 1)")
        argv[argv.index('-m'):] = ['-c', expression]
    return argv, declared['environment']


def main():
    if len(sys.argv) != 2 or sys.argv[1] not in ('trace', 'full'):
        raise ValueError('expected trace or full phase')
    phase = sys.argv[1]
    path = WORK / (phase + '-result.json')
    if path.exists():
        raise FileExistsError('preserve prior evidence')
    argv, environment = command(phase)
    record = {'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'command': argv, 'environment': environment,
              'source_before': pins(WORK), 'baseline_before': pins(BASE), 'previous_before': pins(PREVIOUS),
              'runner_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              'scope': 'Private candidate fixture execution; no installed or native-manager admission.'}
    (WORK / (phase + '-admission.json')).write_text(json.dumps(record, indent=2) + '\n')
    try:
        result = subprocess.run(argv, env=environment, capture_output=True,
                                timeout=40 if phase == 'trace' else 130, check=False)
        out, err, code = result.stdout, result.stderr, result.returncode
    except subprocess.TimeoutExpired as error:
        out, err, code = error.stdout or b'', error.stderr or b'', 124
    (WORK / (phase + '.stdout')).write_bytes(out)
    (WORK / (phase + '.stderr')).write_bytes(err)
    record.update(exit=code, source_after=pins(WORK), baseline_after=pins(BASE), previous_after=pins(PREVIOUS),
                  stdout_sha256=hashlib.sha256(out).hexdigest(),
                  stderr_sha256=hashlib.sha256(err).hexdigest())
    record['source_unchanged'] = (record['source_before'] == record['source_after']
                                  and record['baseline_before'] == record['baseline_after']
                                  and record['previous_before'] == record['previous_after'])
    path.write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps({'phase': phase, 'exit': code, 'source_unchanged': record['source_unchanged'],
                      'stderr_tail': err.decode()[-3000:]}, indent=2))
    return code


if __name__ == '__main__':
    raise SystemExit(main())

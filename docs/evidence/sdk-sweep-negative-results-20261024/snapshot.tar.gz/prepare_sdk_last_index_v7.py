"""Prepare a private all-call sweep successor; preserve frozen predecessors."""
import difflib
from pathlib import Path

ROOT = Path(__file__).resolve().parent
BASE = ROOT / 'sdk-scratch-sweep-v4'
OUT = ROOT / 'sdk-last-index-v7'
OLD = '''    next_index = 0
    for _attempt in range(8192):
        with guard:
            for index in range(next_index, 8192):
                next_index = index + 1
                retire_reference_cell(sequence, index)
        if next_index == 8192:
            return
'''
NEW = '''    last_index = -1
    for _attempt in range(8192):
        with guard:
            for index in range(last_index + 1, 8192):
                last_index = index
                retire_reference_cell(sequence, index)
        if last_index == 8191:
            return
'''


def main():
    OUT.mkdir()
    differences = []
    for path in sorted(BASE.glob('*.py')):
        text = path.read_text()
        if path.name in ('origin_probe.py', 'production_checker.py'):
            if text.count(OLD) != 1:
                raise ValueError('expected exact v4 sweep')
            changed = text.replace(OLD, NEW).replace(
                'advances next_index first; cell errors never retry or skip a later cell.',
                'records last_index first; cell errors never retry or skip a later cell.')
        else:
            changed = text.replace(str(BASE), str(OUT))
        (OUT / path.name).write_text(changed)
        differences.extend(difflib.unified_diff(text.splitlines(True), changed.splitlines(True),
                                                fromfile='v4/' + path.name,
                                                tofile='v7/' + path.name))
    prior = ROOT / 'sdk-empty-noop-v6/test_empty_retirement.py'
    text = prior.read_text()
    changed = text.replace('Known no-op specialization, with unchanged substituted fault paths.',
                           'All-call sweep preservation, including finalizer-driven changes.')
    changed = changed.replace('test_known_empty_path_omits_calls_not_slots',
                              'test_empty_path_preserves_all_cell_calls')
    changed = changed.replace('self.assertEqual(self.counted_empty_calls(module), 0)',
                              'self.assertEqual(self.counted_empty_calls(module), 8192)')
    (OUT / prior.name).write_text(changed)
    differences.extend(difflib.unified_diff(text.splitlines(True), changed.splitlines(True),
                                            fromfile='v6/' + prior.name,
                                            tofile='v7/' + prior.name))
    (OUT / 'source.diff').write_text(''.join(differences))


if __name__ == '__main__':
    main()

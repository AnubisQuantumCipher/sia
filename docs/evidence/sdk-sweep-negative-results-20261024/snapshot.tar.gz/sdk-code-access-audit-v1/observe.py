"""Isolated regression observation; audit hooks stay inside this child process."""
import importlib.util
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent.parent


def load(directory, filename, name):
    path = ROOT / directory / filename
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError('fixed diagnostic loader unavailable')
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


class AuditControl:
    def __init__(self):
        self.target = None
        self.calls = 0

    def hook(self, event, arguments):
        if (event == 'object.__getattr__' and self.target is not None
                and len(arguments) == 2 and arguments[0] is self.target
                and arguments[1] == '__code__'):
            self.calls += 1
            raise OSError('diagnostic code access denied')


def observe(module, state_type, control):
    state = state_type()
    guard = module.DerivedClearGuard(state, 'scratch-clear')
    slots = [None] * 8192
    retained = object()
    slots[0], slots[4096], slots[8191] = retained, retained, retained
    control.calls, control.target = 0, module.retire_reference_cell
    try:
        module.retire_reference_array(slots, guard)
    finally:
        control.target = None
    return {'module': module.__name__, 'audit_calls': control.calls,
            'occupied': [index for index in (0, 4096, 8191) if slots[index] is retained],
            'raw_used': state.used, 'overflow': state.overflow,
            'raw_classes': [type(state.raw[index]).__name__ for index in range(state.used)],
            'raw_phases': [state.phases[index] for index in range(state.used)]}


def main():
    modules = []
    for directory, label in (('sdk-scratch-sweep-v4', 'baseline'),
                              ('sdk-empty-noop-v6', 'candidate')):
        modules.append((label,
            load(directory, 'production_checker.py', label + '_checker'),
            load(directory, 'origin_probe.py', label + '_probe')))
    control = AuditControl()
    sys.addaudithook(control.hook)
    observations = []
    for label, checker, probe in modules:
        for module in (checker, probe):
            result = observe(module, probe.ProbeState, control)
            result['source'] = label
            observations.append(result)
            if label == 'baseline':
                assert result['occupied'] == [] and result['audit_calls'] == 0
                assert result['raw_used'] == 0 and not result['overflow']
            else:
                assert result['occupied'] == [0, 4096, 8191]
                assert result['audit_calls'] == 8192
                assert result['raw_used'] == 64 and result['overflow']
                assert result['raw_classes'] == ['OSError'] * 64
                assert result['raw_phases'] == ['scratch-clear'] * 64
    print(json.dumps({'status': 'REPRODUCED_CANDIDATE_CLEANUP_REGRESSION',
                      'observations': observations}, indent=2))


if __name__ == '__main__':
    main()

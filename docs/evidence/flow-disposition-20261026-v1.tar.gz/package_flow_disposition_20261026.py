"""Package closed flow disposition and scope clarification, never active proof output."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import sys
import tarfile

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'flow-disposition-package-20261026-v1'
PUBLISHED = Path('/home/sicarii/Work/sia-assurance-checkpoint-20261023')
NAME = 'flow-disposition-20261026-v1.tar.gz'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def inputs():
    folder = ROOT / 'flow-normal-reconciliation-20261026-v1'
    rows = {str(path.relative_to(ROOT)): path.read_bytes()
            for path in folder.iterdir() if path.is_file() and not path.is_symlink()}
    for name in ('project-proof-20261026-v1/FLOW-SCOPE-CLARIFICATION.json',
                 'project-flow-package-20261026-v1/project-flow-20261026-v1.tar.gz',
                 Path(__file__).name):
        rows[name] = (ROOT / name).read_bytes()
    return rows


def bundle(rows):
    output = io.BytesIO()
    with gzip.GzipFile(fileobj=output, mode='wb', filename='', mtime=0) as zipped:
        with tarfile.open(fileobj=zipped, mode='w', format=tarfile.USTAR_FORMAT) as archive:
            for name, raw in sorted(rows.items()):
                info = tarfile.TarInfo(name)
                info.size = len(raw)
                info.mode = 0o644
                archive.addfile(info, io.BytesIO(raw))
    return output.getvalue()


def generate():
    rows = inputs()
    raw = bundle(rows)
    value = dict(status='EXACT_COMPLETED_FLOW_DISPOSITION_ONLY',
        source_head='bc7f32afa393285ca2ca817ff6651739643de580',
        reconciliation_source_sha256=sha(rows['flow-normal-reconciliation-20261026-v1/source.json']),
        archive=dict(name=NAME, sha256=sha(raw), bytes=len(raw)),
        members={name: dict(sha256=sha(data), bytes=len(data)) for name, data in sorted(rows.items())},
        result='30 component methods pass; actual root disposition and separate readback exit zero; original pending identity and bytes retained',
        scope_correction='Eleven non-SPARK test/support units have zero reported entities; roster presence is not proof coverage',
        temporal_boundary='Pending absence applies after the completed flow disposition and before subsequent proof admission',
        provenance='Unsigned owner observations and actual GPT-6.1 independent readback',
        non_claims=['No replay or successor authority', 'No active deductive proof result is packaged',
                    'No full custody, native compaction, system or release acceptance'])
    manifest = (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()
    return {OUT / NAME: raw, OUT / 'manifest.json': manifest,
        PUBLISHED / 'docs/evidence' / NAME: raw,
        PUBLISHED / 'docs/FLOW-DISPOSITION-EVIDENCE-20261026.json': manifest}


def main():
    if sys.argv[1:] not in ([], ['--check']):
        raise ValueError('unsupported arguments')
    for path, raw in generate().items():
        if sys.argv[1:]:
            if path.read_bytes() != raw:
                raise ValueError('package differs: ' + str(path))
        else:
            path.parent.mkdir(exist_ok=True)
            path.write_bytes(raw)
    print('CHECK_MATCH' if sys.argv[1:] else 'PACKAGE_WRITTEN')


if __name__ == '__main__':
    main()

"""Source-bound readback of the complete declared-project flow scope only."""
import hashlib
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parent / 'project-flow-20261026-v3'


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def require(value, reason):
    if not value:
        raise ValueError(reason)


def source_checks(config, binding):
    manifest = json.loads((ROOT / 'execution-source.json').read_text())
    require(sha(ROOT / 'execution-source.json') ==
            '0db7ad7f2a8a7ca9dceebe43a8c8bbeaeaab73bf55dfd23c90f007f1afd5964f', 'manifest')
    for name, expected in manifest.items():
        require(sha(ROOT / name) == expected, 'execution input changed')
    for name, expected in binding['files'].items():
        require(sha(ROOT / 'source' / name) == expected['sha256'], 'snapshot changed')
        require(sha(Path(binding['canonical']) / name) == expected['canonical_sha256'],
                'published source changed')
    for name, expected in config['proof_tools'].items():
        require(sha(Path(name)) == expected, 'tool changed')
    for name, expected in config['helper_hashes'].items():
        require(sha(Path(config['helper_root']) / name) == expected, 'helper changed')
    entry = json.loads((ROOT / 'entry.json').read_text())
    require(entry['command'] == config['command'] and entry['manifest'] == manifest,
            'observed outer command mismatch')
    require(config['proof_command'] == [config['proof_command'][0], '-P',
        '/tmp/source/spark/sia_assurance.gpr', '-U', '--mode=flow', '--assumptions',
        '--no-inlining', '--memlimit=512', '--timeout=10', '-j1'], 'flow scope changed')


def flow_checks(binding):
    report = (ROOT / 'obj/gnatprove/gnatprove.out').read_text()
    rows = re.findall(r'^in unit (\S+), (\d+) subprograms and packages out of (\d+) analyzed$',
                      report, re.MULTILINE)
    expected = {Path(name).stem for name in binding['files'] if name.endswith(('.adb', '.ads'))}
    require(len(rows) == len(expected) and {row[0] for row in rows} == expected,
            'missing, extra or duplicate unit')
    require(all(row[1] == row[2] for row in rows), 'partial unit')
    totals = re.findall(r'^Total\s+(\d+)\s+(\d+)\s+\(100%\)\s+\.\s+\.\s+\.$',
                        report, re.MULTILINE)
    require(len(totals) == 1 and totals[0] == ('1522', '1522'), 'flow totals')
    skips = report.count('proof skipped for this unit (only flow analysis was requested)')
    require(skips == len(rows), 'unexpected proof-scope declaration')
    entity_rows = re.findall(r'flow analyzed \((\d+) errors, (\d+) checks, (\d+) warnings '
                             r'and (\d+) pragma Assume statements\)', report)
    require(bool(entity_rows) and all(row == ('0', '0', '0', '0') for row in entity_rows),
            'flow entity diagnostics or assumptions')
    diagnostics = (ROOT / 'proof.stderr').read_text()
    require(not re.search(r'^\s*(?:warning|error|low|medium|high):', diagnostics, re.MULTILINE),
            'non-info diagnostic')
    require('Success: all checks proved (1522 checks).' in (ROOT / 'proof.stdout').read_text(),
            'terminal flow success missing')
    return dict(units=rows, summary_total=totals[0], entity_rows=len(entity_rows),
                deductive_proof_skipped_by_requested_mode=skips)


def main():
    config = json.loads((ROOT / 'config.json').read_text())
    binding = json.loads((ROOT / 'source-binding.json').read_text())
    result = json.loads((ROOT / 'execution-result.json').read_text())
    require(result['exit'] == 0 and result['proof_dispatched'] is True and
            result['execution_status'] == 'TERMINAL_REPORTS_REQUIRE_AUDIT', 'execution nonpass')
    require(result['cleanup']['complete'] and not result['cleanup']['signals'] and
            not result['cleanup']['errors'] and result['cleanup']['waited'] == 0, 'cleanup')
    for group in (result['terminal'], result['cleanup']['observations']):
        require(set(group) == {'launcher', 'init', 'leader'} and
                all(v == dict(mask=17, terminal=True, reaped=True) for v in group.values()),
                'tracked terminal evidence')
    source_checks(config, binding)
    flow = flow_checks(binding)
    names = ('config.json', 'source-binding.json', 'execution-source.json', 'entry.json',
             'active.json', 'execution-result.json', 'proof.stdout', 'proof.stderr',
             'obj/gnatprove/gnatprove.out')
    audit = dict(status='FLOW_SCOPE_PASS_NO_DEDUCTIVE_PROOF', source_head=binding['head'],
        flow=flow, hashes={name: sha(ROOT / name) for name in names},
        auditor_sha256=sha(Path(__file__)), tracked_cleanup=True,
        scope='All declared Ada units of sia_assurance.gpr; separate transport/allocation projects excluded',
        non_claims=['No functional contract or run-time safety proof from flow mode',
                    'No general custody, installed/native compaction or release acceptance',
                    'Root pending intent still requires separate exact reconciliation'])
    (ROOT / 'OWNER-FLOW-AUDIT.json').write_text(json.dumps(audit, indent=2) + '\n')
    print(json.dumps(dict(status=audit['status'], units=len(flow['units']),
                          flow_checks=flow['summary_total'][0])))


if __name__ == '__main__':
    main()

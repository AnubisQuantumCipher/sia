"""Normal-flow admission negative controls; no production ledger mutation."""
import copy
import json
from pathlib import Path
import tempfile
import unittest
from unittest import mock

import flow_reconcile as subject

ROOT = Path(__file__).resolve().parent


class FlowAdmission(unittest.TestCase):
    def setUp(self):
        self.result = json.loads((subject.ATTEMPT / 'execution-result.json').read_text())
        self.tool = json.loads((subject.ATTEMPT / 'TOOL-EXIT-OBSERVATION.json').read_text())
        self.decision = json.loads((ROOT / 'decision.json').read_text())

    def refused(self, result=None, tool=None):
        with self.assertRaises(ValueError):
            subject.check_result(result if result is not None else self.result,
                                 tool if tool is not None else self.tool)

    def test_exact_completed_flow_has_no_successor_or_replay_authority(self):
        subject.check_result(self.result, self.tool)
        subject.verify_flow(self.decision)
        self.assertFalse(self.decision['replay_authorized'])
        self.assertFalse(self.decision['successor_admitted'])

    def test_incomplete_or_nonzero_result_refuses(self):
        for key, value in (('execution_status', 'FAILED_OR_INCOMPLETE'), ('exit', 1),
                           ('exit', False), ('proof_dispatched', False),
                           ('proof_dispatched', 1), ('authority', 'ALLOW')):
            changed = copy.deepcopy(self.result)
            changed[key] = value
            with self.subTest(key=key, value=value):
                self.refused(result=changed)

    def test_cleanup_failures_refuse(self):
        for key, value in (('complete', False), ('errors', ['unknown']),
                           ('signals', {'leader': 'SIGKILL'}), ('waited', 1)):
            changed = copy.deepcopy(self.result)
            changed['cleanup'][key] = value
            with self.subTest(key=key):
                self.refused(result=changed)

    def test_missing_extra_or_live_role_refuses(self):
        for group in ('terminal', 'observations'):
            for mode in ('missing', 'extra', 'live'):
                changed = copy.deepcopy(self.result)
                rows = changed['terminal'] if group == 'terminal' else changed['cleanup'][group]
                if mode == 'missing':
                    del rows['leader']
                elif mode == 'extra':
                    rows['unknown'] = rows['leader']
                else:
                    rows['leader']['terminal'] = False
                with self.subTest(group=group, mode=mode):
                    self.refused(result=changed)

    def test_outer_exit_identity_or_report_mismatch_refuses(self):
        for key, value in (('exit_code', 1), ('exit_code', False), ('session_id', 1),
                           ('tool_chunk', 'wrong'), ('reported_result', {})):
            changed = copy.deepcopy(self.tool)
            changed[key] = value
            with self.subTest(key=key, value=value):
                self.refused(tool=changed)

    def test_scope_identity_or_manufactured_permission_refuses(self):
        for key, value in (('scope', 'DEDUCTIVE_PROOF'), ('operation_manifest', '0' * 64),
                           ('pending_sha256', '0' * 64), ('successor_admitted', True),
                           ('replay_authorized', True), ('authority', 'ALLOW')):
            changed = copy.deepcopy(self.decision)
            changed[key] = value
            with self.subTest(key=key), self.assertRaises(ValueError):
                subject.verify_flow(changed)

    def test_missing_extra_and_changed_evidence_refuse(self):
        for mode in ('missing', 'extra', 'changed'):
            changed = copy.deepcopy(self.decision)
            if mode == 'missing':
                del changed['evidence_sha256']['OWNER-FLOW-AUDIT.json']
            elif mode == 'extra':
                changed['evidence_sha256']['invented.json'] = '0' * 64
            else:
                changed['evidence_sha256']['obj/gnatprove/gnatprove.out'] = '0' * 64
            with self.subTest(mode=mode), self.assertRaises(ValueError):
                subject.verify_flow(changed)

    def test_wrong_flow_audit_refuses_even_if_file_digest_is_refreshed(self):
        real_load = subject.load_module
        auditor = real_load('flow_audit')
        def incorrect(_binding):
            return dict(units=[], summary_total=['0', '0'])
        auditor.flow_checks = incorrect
        with mock.patch.object(subject, 'load_module', return_value=auditor), \
                self.assertRaisesRegex(ValueError, 'flow audit correspondence'):
            subject.verify_flow(self.decision)

    def test_missing_changed_or_nonregular_inputs_refuse(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            (root / 'directory').mkdir()
            target = root / 'target'
            target.write_bytes(b'fixed')
            (root / 'link').symlink_to(target)
            for name in ('missing', 'directory', 'link'):
                with self.subTest(name=name), self.assertRaises(ValueError):
                    subject.digest(root / name)


if __name__ == '__main__':
    unittest.main()

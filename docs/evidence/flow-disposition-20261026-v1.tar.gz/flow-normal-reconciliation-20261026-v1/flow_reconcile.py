"""Exact completed flow disposition; no replay, successor or proof authority."""
from contextlib import ExitStack
import hashlib
import importlib.util
import json
from pathlib import Path
import os
import sys

ROOT = Path(__file__).resolve().parent
ATTEMPT = ROOT.parent / 'project-flow-20261026-v3'
MANIFEST = '0db7ad7f2a8a7ca9dceebe43a8c8bbeaeaab73bf55dfd23c90f007f1afd5964f'
PENDING = 'cba8166fd4eeb2042e8e6bab83281e2e96f9907fdf0368273b5004149e9455df'
SCOPE = 'COMPLETED_FLOW_ONLY_INVOCATION_RECONCILED'
EVIDENCE = ('config.json', 'source-binding.json', 'execution-source.json',
    'proof_wrapper.py', 'proof_payload.py', 'entry.json', 'active.json',
    'execution-result.json', 'proof.stdout', 'proof.stderr',
    'TOOL-EXIT-OBSERVATION.json', 'PENDING-READBACK.json',
    'OWNER-FLOW-AUDIT.json', 'INDEPENDENT-REVIEW.json', 'obj/gnatprove/gnatprove.out')
SOURCES = ('flow_reconcile.py', 'normal_reconcile.py', 'candidate.py',
           'flow_audit.py', 'readback.py', 'test_normal.py', 'test_flow.py', 'decision.json')


def digest(path):
    if path.is_symlink() or not path.is_file() or path.stat().st_size > 1048576:
        raise ValueError('bounded regular input required')
    with path.open('rb') as stream:
        raw = stream.read(1048577)
    if len(raw) > 1048576:
        raise ValueError('input grew')
    return hashlib.sha256(raw).hexdigest()


def load_module(name):
    if name not in ('candidate', 'normal_reconcile', 'readback', 'flow_audit'):
        raise ValueError('closed module roster')
    spec = importlib.util.spec_from_file_location(name, ROOT / (name + '.py'))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def source_argument():
    if len(sys.argv) != 2 or digest(ROOT / 'source.json') != sys.argv[1]:
        raise ValueError('fixed source argument required')
    expected = json.loads((ROOT / 'source.json').read_text())
    if set(expected) != set(SOURCES):
        raise ValueError('closed source roster required')
    for name, wanted in expected.items():
        if digest(ROOT / name) != wanted:
            raise ValueError('source changed')


def check_result(result, acknowledgment):
    if result['execution_status'] != 'TERMINAL_REPORTS_REQUIRE_AUDIT' \
            or result['proof_dispatched'] is not True or type(result['exit']) is not int \
            or result['exit'] != 0 or result['authority'] != 'NONE':
        raise ValueError('not completed ordinary invocation')
    roles = {name: dict(mask=17, terminal=True, reaped=True)
             for name in ('launcher', 'init', 'leader')}
    if result['terminal'] != roles or result['cleanup'] != dict(
            complete=True, errors=[], signals={}, waited=0, observations=roles):
        raise ValueError('tracked cleanup mismatch')
    if type(acknowledgment['exit_code']) is not int or acknowledgment['exit_code'] != 0 \
            or acknowledgment['reported_result'] != result \
            or acknowledgment['session_id'] != 80694 or acknowledgment['tool_chunk'] != '764f4b':
        raise ValueError('unsigned owner observation mismatch')


def verify_flow(decision):
    if decision['scope'] != SCOPE or decision['operation_manifest'] != MANIFEST \
            or decision['pending_sha256'] != PENDING or decision['successor_admitted'] is not False \
            or decision['replay_authorized'] is not False or decision['authority'] != 'NONE':
        raise ValueError('exact flow disposition only')
    if set(decision['evidence_sha256']) != set(EVIDENCE):
        raise ValueError('closed evidence roster')
    for name, wanted in decision['evidence_sha256'].items():
        if digest(ATTEMPT / name) != wanted:
            raise ValueError('flow evidence changed')
    config = json.loads((ATTEMPT / 'config.json').read_text())
    binding = json.loads((ATTEMPT / 'source-binding.json').read_text())
    auditor = load_module('flow_audit')
    auditor.ROOT = ATTEMPT
    auditor.source_checks(config, binding)
    flow = auditor.flow_checks(binding)
    audit = json.loads((ATTEMPT / 'OWNER-FLOW-AUDIT.json').read_text())
    if audit['status'] != 'FLOW_SCOPE_PASS_NO_DEDUCTIVE_PROOF' \
            or audit['flow'] != json.loads(json.dumps(flow)) \
            or audit['auditor_sha256'] != digest(ROOT / 'flow_audit.py'):
        raise ValueError('flow audit correspondence')
    check_result(json.loads((ATTEMPT / 'execution-result.json').read_text()),
                 json.loads((ATTEMPT / 'TOOL-EXIT-OBSERVATION.json').read_text()))


def ledger_before(candidate, reader, decision):
    names = set()
    with os.scandir(candidate.LEDGER) as entries:
        for entry in entries:
            if len(names) >= 10:
                raise ValueError('extra ledger record')
            names.add(entry.name)
    if names != set(decision['ledger_before']):
        raise ValueError('ledger roster changed')
    for name, wanted in decision['ledger_before'].items():
        _, row = reader.read_file(name)
        if row['sha256'] != wanted or row['identity'] != decision['ledger_before_identity'][name]:
            raise ValueError('ledger bytes or identity changed')
    if reader.identity(candidate.LEDGER.lstat()) != decision['ledger_identity']:
        raise ValueError('ledger directory changed')


def admit(candidate, reader, helper, config, decision, lock):
    source_argument()
    verify_flow(decision)
    candidate.verify_host(config, helper)
    helper.validate_tools(config)
    candidate.verify_manifest(json.loads((ATTEMPT / 'execution-source.json').read_text()))
    candidate.verify_inputs(config, json.loads((ATTEMPT / 'source-binding.json').read_text()))
    if candidate.metadata(lock) != decision['lock_identity'] \
            or candidate.metadata(helper.LOCK.lstat()) != decision['lock_identity'] \
            or candidate.metadata(ATTEMPT.lstat()) != decision['output_identity']:
        raise ValueError('lock or output identity changed')
    ledger_before(candidate, reader, decision)


def main():
    source_argument()
    decision = json.loads((ROOT / 'decision.json').read_text())
    verify_flow(decision)
    candidate, normal, reader = (load_module(name) for name in
                                  ('candidate', 'normal_reconcile', 'readback'))
    candidate.ROOT = ATTEMPT
    normal.PENDING_SHA = PENDING
    normal.RETIRED = 'retired-' + MANIFEST + '.json'
    normal.DECISION = 'decision-' + MANIFEST + '.json'
    config = json.loads((ATTEMPT / 'config.json').read_text())
    helper = candidate.helpers(config)
    with ExitStack() as stack:
        lock = helper.hold_lock(stack)
        admit(candidate, reader, helper, config, decision, lock)
        result = normal.reconcile_once(candidate, config['recovery_ledger'], decision)
    result['status'] = SCOPE
    result['observation_scope'] = 'Flow-only report; tracked roles only; general custody unqualified'
    print(json.dumps(result), flush=True)


if __name__ == '__main__':
    main()

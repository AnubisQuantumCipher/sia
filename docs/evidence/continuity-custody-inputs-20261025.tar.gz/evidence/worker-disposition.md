# Owner disposition: mocked repair complete; custody is an owner dependency

Exact clean worker HEAD5c61b7afcb02af9ebfded2c5d2ada8f322822ba1,
tree908bc01d2388b0d77ca7584b7d6a3808110bbcc4.
Owner readback matched165 source-manifest,46 wrapper and32 stage members.
The unchanged strict eight-source profile returned zero diagnostics and AST
parsing passed. The separately admitted owner run passed58 mocked controls
in0.034s, exit0, with source hashes and nine metadata fields unchanged.
Raw evidence: continuity-observer-injected-5c61b7a-v1/.

Actual GPT-6.1 source/raw reconciliation confirms the requested MemoryError
and exact wire/direct-object refusal corrections at this scope. It did not
execute independently. Total-OOM reporting, real process custody, deadlines,
formatter imports, actual compaction and installed operation remain UNPROVEN.
The predecessor53-test failure remains retained, not replaced by this pass.

## Decision and responsible owner

No further classifier features or mocked-control expansion is requested.
Keep this exact worker source and the finite lifecycle contract unchanged.
dispatch() must continue to refuse. No actual root-profile launch is admitted.

The main integration owner, thread01a1548c-e4bd-7d10-a4df-b68d11e2b70b, owns
the next dependency. The worker is not asked to invent or commission a manager,
change credentials, create another namespace variant or request privilege.

No already-qualified whole-job route has been established. The existing required
systemd/cgroup route still needs the protected fresh-manager-image producer and
whole privileged lifetime interface, followed by its original strict C/SDK/native
qualification. Configured executable hashes, PID1 properties, PID/starttime or
cgroup names cannot replace a fresh held executable identity across possible
manager re-exec. The retained original C6 analysis failed with
analyzer-too-complex, and the reviewed source record identified no supported
same-translation-unit/full-domain repair. This is not proof of impossibility.

The alternative directbirth source attempt stopped before implementation because
the full original UID/GID/supplementary-group profile lacked a qualified mapping.
Neither a one-group map nor overflow-ID observations satisfy that requirement.
The authoritative dependency history is retained in
../takeover-execution-cursor-20261021-v218.json and
../takeover-standalone-directbirth-autokill-credential-preservation-blocker-v1.json.
These historical records locate the unresolved source/evidence obligations;
they are not fresh host observations or renewed execution grants.

The next actionable owner work is to reconcile the existing manager producer's
strict-analysis failure and original execution/credential contract against its
exact source, selecting a concrete supported repair only if evidence identifies
one. No unchanged compiler/proof retry, opaque helper, warning suppression,
weaker credential domain or increased cap is authorized by this decision.
If no such repair can be established, retain the specific prerequisite rather
than returning another classifier task to this worker.

Only after that dependency is qualified can the owner supply the worker an
exact custody/entry/deadline/recovery interface and separately admit its finite
root-profile fault matrix. Required evidence includes ownership before payload
execution, preserved credentials, death-resistant original deadlines, independent
terminal observations and unresolved-operation retention if the observer dies.

All original product, proof, runtime and release gates remain binding. Full goal
ACTIVE/INCOMPLETE. Parent may relay this record; no tool message was sent to
parent or worker, and no additional implementation owner was introduced.

/* SOURCE ONLY. One root anchor and one fixed measurement child. No exec. */
#include "witness.h"
#include <errno.h>
#include <fcntl.h>
#include <linux/magic.h>
#include <linux/sched.h>
#include <limits.h>
#include <poll.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/pidfd.h>
#include <sys/resource.h>
#include <sys/statfs.h>
#include <sys/statvfs.h>
#include <sys/syscall.h>
#include <sys/sysmacros.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>

#if !defined(__aarch64__)
#error "Only the source-reviewed Linux AArch64 legacy clone ABI is selected"
#endif
_Static_assert(sizeof(long)==8U,"selected AArch64 syscall ABI");
_Static_assert(sizeof(struct pidfd_info)>=PIDFD_INFO_SIZE_VER0,"pidfd credential ABI");
_Static_assert(sizeof(struct pidfd_info)<=512U && sizeof(struct rlimit)<=32U &&
    sizeof(struct statfs)<=256U && sizeof(struct statvfs)<=256U &&
    sizeof(sigset_t)<=256U && sizeof(struct sigaction)<=256U &&
    sizeof(siginfo_t)<=256U && sizeof(socklen_t)<=16U,
    "conditional original-local source budgets");

struct mw_dirent64 {
    uint64_t ino;
    int64_t offset;
    unsigned short length;
    unsigned char type;
    char name[];
};
static struct mw_state STATE;
static struct mw_data DATA;

static void initialize(struct mw_state *s, struct mw_data *d)
{
    for (size_t i=0U; i<MW_FDS; ++i) s->fd[i]=-1;
    for (size_t i=0U; i<MW_RX_FDS; ++i) s->received[i]=-1;
    d->clone_cell=-1;
    s->anchor_pid=getpid();
}

static bool limits(struct mw_state *s)
{
    const int resources[5]={RLIMIT_AS,RLIMIT_STACK,RLIMIT_NOFILE,RLIMIT_FSIZE,RLIMIT_CORE};
    const rlim_t values[5]={16777216U,262144U,8U,0U,0U};
    for (size_t i=0U; i<5U; ++i) {
        struct rlimit value={0,0};
        if (getrlimit(resources[i],&value)!=0) return mw_fail(s,MF_CONFIG,errno);
        if (value.rlim_cur!=values[i] || value.rlim_max!=values[i])
            return mw_fail(s,MF_CONFIG,ERANGE);
    }
    return true;
}

static bool standard_fds(struct mw_state *s)
{
    for (int fd=0; fd<3; ++fd) {
        struct stat identity={0};
        int flags=fcntl(fd,F_GETFD);
        if (flags<0 || fstat(fd,&identity)!=0) return mw_fail(s,MF_INHERIT,errno);
        if (fd==0) {
            if (!S_ISSOCK(identity.st_mode)) return mw_fail(s,MF_INHERIT,ENOTSOCK);
        } else {
            int access=fcntl(fd,F_GETFL);
            if (access<0) return mw_fail(s,MF_INHERIT,errno);
            if (!S_ISCHR(identity.st_mode) || major(identity.st_rdev)!=1U ||
                minor(identity.st_rdev)!=3U || (access&O_ACCMODE)!=O_WRONLY)
                return mw_fail(s,MF_INHERIT,EINVAL);
        }
    }
    return true;
}

static bool inherited_name(struct mw_state *s, const char *name, size_t capacity)
{
    size_t length=strnlen(name,capacity);
    if (length==capacity) return false;
    if ((length==1U && name[0]=='.') ||
        (length==2U && name[0]=='.' && name[1]=='.')) return true;
    unsigned int number=0U;
    if (length==0U || length>10U) return false;
    for (size_t i=0U; i<length; ++i) {
        if (name[i]<'0' || name[i]>'9') return false;
        unsigned int digit=(unsigned int)(unsigned char)(name[i]-'0');
        if (number>(UINT_MAX-digit)/10U) return false;
        number=number*10U+digit;
    }
    return number<=2U || number==(unsigned int)s->fd[MS_TEMP];
}

static bool inherited_fds(struct mw_state *s, struct mw_data *d)
{
    s->fd[MS_TEMP]=open("/proc/self/fd",O_RDONLY|O_DIRECTORY|O_NOFOLLOW|O_CLOEXEC);
    if (s->fd[MS_TEMP]<0) return mw_fail(s,MF_INHERIT,errno);
    long count=syscall(SYS_getdents64,s->fd[MS_TEMP],d->text,sizeof d->text);
    int saved=errno;
    bool good=count>0 && (unsigned long)count<=sizeof d->text;
    size_t cursor=0U;
    for (size_t i=0U; good && i<MW_TEXT/20U && cursor<(size_t)count; ++i) {
        size_t base=offsetof(struct mw_dirent64,name);
        if ((size_t)count-cursor<base+1U) { good=false; break; }
        unsigned short encoded_length=0U;
        memcpy(&encoded_length,d->text+cursor+offsetof(struct mw_dirent64,length),
            sizeof encoded_length);
        size_t length=encoded_length;
        if (length<base+1U || length>(size_t)count-cursor || length%8U!=0U ||
            !inherited_name(s,d->text+cursor+base,length-base)) { good=false; break; }
        cursor+=length;
    }
    if (good && cursor!=(size_t)count) good=false;
    long tail=good ? syscall(SYS_getdents64,s->fd[MS_TEMP],d->text,sizeof d->text) : -1;
    int tail_error=errno;
    mw_close(s,MS_TEMP);
    s->inherited_ok=good && tail==0 && s->closes[MS_TEMP]==0;
    return s->inherited_ok || mw_fail(s,MF_INHERIT,
        count<0 ? saved : (good && tail<0 ? tail_error : EPROTO));
}

static bool socket_option(struct mw_state *s, int option, int wanted)
{
    if (setsockopt(STDIN_FILENO,SOL_SOCKET,option,&wanted,sizeof wanted)!=0)
        return mw_fail(s,MF_CHANNEL,errno);
    int value=-1;
    socklen_t length=sizeof value;
    if (getsockopt(STDIN_FILENO,SOL_SOCKET,option,&value,&length)!=0)
        return mw_fail(s,MF_CHANNEL,errno);
    return (length==sizeof value && value==wanted) || mw_fail(s,MF_CHANNEL,EPROTO);
}

static bool channel(struct mw_state *s, struct mw_data *d)
{
    int type=0, domain=0;
    socklen_t length=sizeof type;
    if (getsockopt(STDIN_FILENO,SOL_SOCKET,SO_TYPE,&type,&length)!=0)
        return mw_fail(s,MF_CHANNEL,errno);
    if (length!=sizeof type || type!=SOCK_SEQPACKET)
        return mw_fail(s,MF_CHANNEL,EPROTOTYPE);
    length=sizeof domain;
    if (getsockopt(STDIN_FILENO,SOL_SOCKET,SO_DOMAIN,&domain,&length)!=0)
        return mw_fail(s,MF_CHANNEL,errno);
    if (length!=sizeof domain || domain!=AF_UNIX) return mw_fail(s,MF_CHANNEL,EPROTO);
    length=sizeof d->peer;
    if (getsockopt(STDIN_FILENO,SOL_SOCKET,SO_PEERCRED,&d->peer,&length)!=0)
        return mw_fail(s,MF_CHANNEL,errno);
    if (length!=sizeof d->peer || d->peer.uid!=COMMISSION.operator_uid || d->peer.pid<=0)
        return mw_fail(s,MF_CRED,EACCES);
    if (!socket_option(s,SO_PASSCRED,1) || !socket_option(s,SO_PASSPIDFD,0) ||
        !socket_option(s,SO_PASSSEC,0)) return false;
    int flags=fcntl(STDIN_FILENO,F_GETFL);
    if (flags<0 || fcntl(STDIN_FILENO,F_SETFL,flags|O_NONBLOCK)!=0 ||
        fcntl(STDIN_FILENO,F_SETFD,FD_CLOEXEC)!=0)
        return mw_fail(s,MF_CHANNEL,errno);
    int actual_flags=fcntl(STDIN_FILENO,F_GETFL);
    if (actual_flags<0) return mw_fail(s,MF_CHANNEL,errno);
    int actual_close=fcntl(STDIN_FILENO,F_GETFD);
    if (actual_close<0) return mw_fail(s,MF_CHANNEL,errno);
    return ((actual_flags&O_NONBLOCK)!=0 && (actual_close&FD_CLOEXEC)!=0) ||
        mw_fail(s,MF_CHANNEL,EPROTO);
}

static bool environment(struct mw_state *s, struct mw_data *d)
{
    const char *unit=getenv("SIA_WITNESS_UNIT"), *invocation=getenv("INVOCATION_ID");
    if (unit==NULL || invocation==NULL) return mw_fail(s,MF_ENV,EINVAL);
    size_t length=strnlen(unit,sizeof d->unit_id);
    static const char prefix[]="sia-manager-image-witness@";
    static const char suffix[]=".service";
    if (length>=sizeof d->unit_id || length<=sizeof prefix+sizeof suffix-2U ||
        memcmp(unit,prefix,sizeof prefix-1U)!=0 ||
        memcmp(unit+length-(sizeof suffix-1U),suffix,sizeof suffix-1U)!=0 ||
        strnlen(invocation,sizeof d->invocation)!=32U)
        return mw_fail(s,MF_ENV,EINVAL);
    for (size_t i=0U; i<length; ++i)
        if (unit[i]=='/' || (i+1U<length && unit[i]=='.' && unit[i+1U]=='.'))
            return mw_fail(s,MF_ENV,EINVAL);
    bool nonzero=false;
    for (size_t i=0U; i<32U; ++i) {
        char c=invocation[i];
        if (!((c>='0' && c<='9') || (c>='a' && c<='f')))
            return mw_fail(s,MF_ENV,EINVAL);
        nonzero=nonzero || c!='0';
    }
    if (!nonzero) return mw_fail(s,MF_ENV,EINVAL);
    memcpy(d->unit_id,unit,length+1U);
    memcpy(d->invocation,invocation,33U);
    int first=snprintf(d->service_cgroup,sizeof d->service_cgroup,"/system.slice/%s",unit);
    int second=snprintf(d->work_cgroup,sizeof d->work_cgroup,"/system.slice/%s/work",unit);
    return (first>0 && (size_t)first<sizeof d->service_cgroup && second>0 &&
        (size_t)second<sizeof d->work_cgroup) || mw_fail(s,MF_ENV,EOVERFLOW);
}

static bool baseline(struct mw_state *s, struct mw_data *d)
{
    if (!mw_now(s,&s->begin)) return false;
    if (s->begin>UINT64_MAX-UINT64_C(3000000000)) return mw_fail(s,MF_DEADLINE,ERANGE);
    s->work_deadline=s->begin+UINT64_C(2000000000);
    s->total_deadline=s->begin+UINT64_C(3000000000);
    if (getuid()!=0U || geteuid()!=0U || getgid()!=0U || getegid()!=0U || getppid()!=1)
        return mw_fail(s,MF_CONFIG,EACCES);
    struct sigaction disposition;
    if (sigaction(SIGCHLD,NULL,&disposition)!=0) return mw_fail(s,MF_CONFIG,errno);
    if (disposition.sa_handler!=SIG_DFL || (disposition.sa_flags&SA_NOCLDWAIT)!=0)
        return mw_fail(s,MF_CONFIG,EINVAL);
    return standard_fds(s) && mw_config(s) && limits(s) && channel(s,d) && inherited_fds(s,d) &&
        environment(s,d) && mw_self_start(s,d,&s->anchor_start);
}

static bool directory_identity(struct mw_state *s, int fd, struct stat *identity)
{
    struct statfs filesystem;
    if (fstat(fd,identity)!=0 || fstatfs(fd,&filesystem)!=0)
        return mw_fail(s,MF_CGROUP,errno);
    return (S_ISDIR(identity->st_mode) && identity->st_uid==0U &&
        identity->st_gid==0U && (identity->st_mode&0022U)==0U &&
        filesystem.f_type==CGROUP2_SUPER_MAGIC) || mw_fail(s,MF_CGROUP,ESTALE);
}

static bool readonly_ancestor(struct mw_state *s, const char *path)
{
    s->fd[MS_TEMP]=open(path,O_RDONLY|O_DIRECTORY|O_NOFOLLOW|O_CLOEXEC);
    if (s->fd[MS_TEMP]<0) return mw_fail(s,MF_CGROUP,errno);
    struct statvfs filesystem;
    bool result=fstatvfs(s->fd[MS_TEMP],&filesystem)==0;
    int saved=errno;
    mw_close(s,MS_TEMP);
    if (!result) return mw_fail(s,MF_CGROUP,saved);
    return ((filesystem.f_flag&ST_RDONLY)!=0U && s->closes[MS_TEMP]==0) ||
        mw_fail(s,MF_CGROUP,EACCES);
}

static bool create_work(struct mw_state *s, struct mw_data *d)
{
    char anchor[384]={0}, path[512]={0};
    int length=snprintf(anchor,sizeof anchor,"%s/anchor",d->service_cgroup);
    int count=snprintf(path,sizeof path,"/sys/fs/cgroup%s",d->service_cgroup);
    if (length<=0 || (size_t)length>=sizeof anchor || count<=0 || (size_t)count>=sizeof path)
        return mw_fail(s,MF_CGROUP,EOVERFLOW);
    if (!mw_self_group(s,d,anchor) || !readonly_ancestor(s,"/sys/fs/cgroup") ||
        !readonly_ancestor(s,"/sys/fs/cgroup/system.slice")) return false;
    s->fd[MS_SERVICE]=open(path,O_RDONLY|O_DIRECTORY|O_NOFOLLOW|O_CLOEXEC);
    if (s->fd[MS_SERVICE]<0) return mw_fail(s,MF_CGROUP,errno);
    if (!directory_identity(s,s->fd[MS_SERVICE],&d->service_stat)) return false;
    struct statvfs filesystem;
    if (fstatvfs(s->fd[MS_SERVICE],&filesystem)!=0) return mw_fail(s,MF_CGROUP,errno);
    if ((filesystem.f_flag&ST_RDONLY)!=0U) return mw_fail(s,MF_CGROUP,EROFS);
    if (mkdirat(s->fd[MS_SERVICE],"work",0755)!=0) return mw_fail(s,MF_CGROUP,errno);
    s->work_created=true;
    s->fd[MS_WORK]=openat(s->fd[MS_SERVICE],"work",O_RDONLY|O_DIRECTORY|O_NOFOLLOW|O_CLOEXEC);
    if (s->fd[MS_WORK]<0) return mw_fail(s,MF_CGROUP,errno);
    if (!directory_identity(s,s->fd[MS_WORK],&d->work_stat)) return false;
    if (fchmod(s->fd[MS_WORK],0755)!=0) return mw_fail(s,MF_CGROUP,errno);
    return mw_timely(s,s->work_deadline);
}

static bool child_handle(struct mw_state *s)
{
    int flags=fcntl(s->fd[MS_CHILD],F_GETFD);
    if (flags<0) return mw_fail(s,MF_CLONE,errno);
    struct pidfd_info info={.mask=PIDFD_INFO_PID|PIDFD_INFO_CREDS};
    if (ioctl(s->fd[MS_CHILD],PIDFD_GET_INFO,&info)!=0) return mw_fail(s,MF_CLONE,errno);
    uint64_t mask=PIDFD_INFO_PID|PIDFD_INFO_CREDS;
    s->child_validated=(flags&FD_CLOEXEC)!=0 && (info.mask&mask)==mask &&
        info.pid==(uint32_t)s->child_pid && info.tgid==(uint32_t)s->child_pid &&
        info.ppid==(uint32_t)s->anchor_pid && info.ruid==0U && info.euid==0U &&
        info.suid==0U && info.fsuid==0U;
    return s->child_validated || mw_fail(s,MF_CLONE,ESTALE);
}

static bool place_worker(struct mw_state *s, struct mw_data *d)
{
    mw_close(s,MS_SERVICE);
    mw_close(s,MS_EVENTS);
    mw_close(s,MS_KILL);
    if (getppid()!=s->anchor_pid || !mw_clean(s)) return mw_fail(s,MF_PLACE,ESTALE);
    s->fd[MS_TEMP]=openat(s->fd[MS_WORK],"cgroup.procs",O_WRONLY|O_NOFOLLOW|O_CLOEXEC);
    if (s->fd[MS_TEMP]<0) return mw_fail(s,MF_PLACE,errno);
    ssize_t count=write(s->fd[MS_TEMP],"0\n",2U);
    int saved=errno;
    mw_close(s,MS_TEMP);
    if (count!=2) return mw_fail(s,MF_PLACE,count<0 ? saved : EIO);
    bool result=mw_self_group(s,d,d->work_cgroup) && mw_self_start(s,d,&s->child_start);
    mw_close(s,MS_WORK);
    return result && mw_clean(s) && mw_timely(s,s->work_deadline);
}

static void close_connection(struct mw_state *s)
{
    if (close(STDIN_FILENO)!=0) {
        s->closes[9]=errno!=0 ? errno : EIO;
        (void)mw_fail(s,MF_SOCKET,s->closes[9]);
    }
}

static bool signal_set(struct mw_state *s, sigset_t *set)
{
    if (sigemptyset(set)!=0 || sigaddset(set,SIGUSR1)!=0)
        return mw_fail(s,MF_PROTOCOL,errno);
    return true;
}

static bool release_blocked(struct mw_state *s)
{
    sigset_t current;
    if (sigprocmask(SIG_SETMASK,NULL,&current)!=0)
        return mw_fail(s,MF_PROTOCOL,errno);
    int member=sigismember(&current,SIGUSR1);
    if (member<0) return mw_fail(s,MF_PROTOCOL,errno);
    return member==1 || mw_fail(s,MF_PROTOCOL,EPROTO);
}

static bool block_release(struct mw_state *s)
{
    sigset_t set, pending;
    if (!signal_set(s,&set)) return false;
    if (sigprocmask(SIG_BLOCK,&set,NULL)!=0) return mw_fail(s,MF_PROTOCOL,errno);
    if (!release_blocked(s)) return false;
    struct sigaction disposition;
    if (sigaction(SIGUSR1,NULL,&disposition)!=0 || sigpending(&pending)!=0)
        return mw_fail(s,MF_PROTOCOL,errno);
    int member=sigismember(&pending,SIGUSR1);
    if (member<0) return mw_fail(s,MF_PROTOCOL,errno);
    return (disposition.sa_handler==SIG_DFL && member==0) ||
        mw_fail(s,MF_PROTOCOL,EPROTO);
}

static bool await_release(struct mw_state *s)
{
    sigset_t set;
    if (!signal_set(s,&set) || !release_blocked(s)) return false;
    uint64_t now=0U;
    if (!mw_now(s,&now)) return false;
    if (now>=s->work_deadline) return mw_fail(s,MF_DEADLINE,ETIMEDOUT);
    uint64_t remaining=s->work_deadline-now;
    struct timespec timeout={.tv_sec=(time_t)(remaining/UINT64_C(1000000000)),
        .tv_nsec=(long)(remaining%UINT64_C(1000000000))};
    siginfo_t info={0};
    int result=sigtimedwait(&set,&info,&timeout); /* Exactly ONE wait. */
    int saved=errno;
    bool timely=mw_timely(s,s->work_deadline); /* Fresh absolute postcheck. */
    if (result<0) return mw_fail(s,MF_PROTOCOL,saved);
    if (result!=SIGUSR1 || info.si_signo!=SIGUSR1 || info.si_code!=SI_USER ||
        info.si_errno!=0 || info.si_pid!=s->anchor_pid || info.si_uid!=0U ||
        getppid()!=s->anchor_pid) return mw_fail(s,MF_PROTOCOL,EPROTO);
    if (!release_blocked(s) || !timely) return false;
    s->released=true;
    return true;
}

static void worker(struct mw_state *s, struct mw_data *d)
{
    s->worker=true;
    s->child_pid=getpid();
    /* Parent-only installed pidfd never belongs to the child's file table. */
    s->fd[MS_CHILD]=-1;
    d->clone_cell=-1;
    s->clone_raw_cell=-1;
    s->clone_result=0;
    bool result=place_worker(s,d) && mw_send(s,d,MP_PLACED,2U,false,s->work_deadline) &&
        mw_worker_namespaces(s,d) && await_release(s) && mw_preimage_namespaces(s,d) &&
        mw_receive(s,d,MR_MEASURE,s->work_deadline) && mw_measure(s,d);
    if (result) result=mw_send(s,d,MP_IMAGE,2U,true,s->work_deadline);
    if (result) result=mw_postimage_namespaces(s,d);
    /* Sole reader through the client consumption frontier. Keep the actual
     * target/proc/image handles and live placement until exact timely ACK/C4. */
    if (result) result=mw_receive(s,d,MR_POSTIMAGE_ACK,s->work_deadline);
    mw_begin_cleanup(s);
    mw_close_all(s);
    if (s->request_known)
        (void)mw_send(s,d,MP_CLOSED,result && mw_clean(s)?2U:1U,false,s->cleanup_deadline);
    close_connection(s);
    bool timely=mw_timely(s,s->total_deadline);
    _exit(result && mw_clean(s) && timely?0:1);
}

static bool create_child(struct mw_state *s, struct mw_data *d)
{
    if (!block_release(s)) return false;
    d->clone_cell=-1;
    errno=0;
    long result=syscall(SYS_clone,(unsigned long)(CLONE_PIDFD|SIGCHLD),0UL,
        &d->clone_cell,0UL,0UL);
    int saved=errno;
    s->clone_result=result;
    if (result==0) worker(s,d);
    s->clone_raw_cell=d->clone_cell;
    if (result<0) {
        /* copy_process may have released this reservation after put_user.
         * A negative syscall NEVER transfers ownership of the output number. */
        d->clone_cell=-1;
        return mw_fail(s,MF_CLONE,saved);
    }
    s->child_pid=(pid_t)result;
    s->wait_owned=true;
    int value=d->clone_cell;
    d->clone_cell=-1;
    bool unique=value>=3 && value<8;
    for (size_t i=0U; i<MW_FDS; ++i) if (s->fd[i]==value) unique=false;
    if (result>INT_MAX || !unique) return mw_fail(s,MF_CLONE,EPROTO);
    s->fd[MS_CHILD]=value; /* Positive syscall + exact disjoint output => owned. */
    return child_handle(s) && mw_challenge(s) &&
        mw_send(s,d,MP_OWNED,2U,false,s->work_deadline);
}

static bool release_worker(struct mw_state *s, struct mw_data *d)
{
    if (!s->child_validated || s->fd[MS_CHILD]<0 || !s->wait_owned)
        return mw_fail(s,MF_CHILD,EINVAL);
    if (!mw_receive(s,d,MR_PREIMAGE,s->work_deadline)) return false;
    if (pidfd_send_signal(s->fd[MS_CHILD],SIGUSR1,NULL,0U)!=0)
        return mw_fail(s,MF_CHILD,errno);
    s->released=true;
    return mw_timely(s,s->work_deadline);
}

static bool wait_failure(struct mw_state *s, size_t attempt, int error,
                         enum mw_wait outcome)
{
    s->wait_error[attempt]=error;
    s->wait_outcome[attempt]=(uint32_t)outcome;
    return mw_fail(s,MF_WAIT,error);
}

static bool wait_child(struct mw_state *s, uint64_t deadline, bool cleanup)
{
    if (!s->wait_owned || s->reaped) return true;
    size_t attempt=cleanup ? 1U : 0U;
    for (size_t i=0U; i<MW_POLLS; ++i) {
        int status=0;
        pid_t result=waitpid(s->child_pid,&status,WNOHANG);
        if (result==s->child_pid) {
            s->wait_status=status;
            s->wait_valid=true;
            s->reaped=true;
            s->wait_outcome[attempt]=MW_REAPED;
            mw_close(s,MS_CHILD);
            if (!mw_timely(s,deadline)) {
                s->wait_error[attempt]=ETIMEDOUT;
                return false;
            }
            return true;
        }
        if (result<0) return wait_failure(s,attempt,errno,MW_ERROR);
        if (result!=0) return wait_failure(s,attempt,EPROTO,MW_ERROR);
        uint64_t now=0U;
        if (!mw_now(s,&now)) return wait_failure(s,attempt,EIO,MW_ERROR);
        if (now>=deadline) return wait_failure(s,attempt,ETIMEDOUT,MW_EXPIRED);
        if (s->fd[MS_CHILD]>=0) {
            int ready=mw_poll(s,s->fd[MS_CHILD],POLLIN,deadline,MF_WAIT);
            if (ready<0) {
                enum mw_wait outcome=s->poll_error==ETIMEDOUT ? MW_EXPIRED : MW_ERROR;
                return wait_failure(s,attempt,s->poll_error,outcome);
            }
            /* Current result only: historical MF_WAIT never aborts cleanup. */
        } else {
            struct pollfd nothing={.fd=-1,.events=0,.revents=0};
            if (poll(&nothing,0U,1)<0) return wait_failure(s,attempt,errno,MW_ERROR);
        }
    }
    return wait_failure(s,attempt,ETIMEDOUT,MW_EXHAUSTED);
}

static void kill_owned(struct mw_state *s)
{
    if (s->fd[MS_KILL]>=0) {
        ssize_t count=write(s->fd[MS_KILL],"1\n",2U);
        if (count!=2) (void)mw_fail(s,MF_KILL,count<0 ? errno : EIO);
    }
    if (s->wait_owned && !s->reaped && s->fd[MS_CHILD]>=0) {
        if (pidfd_send_signal(s->fd[MS_CHILD],SIGKILL,NULL,0U)!=0)
            (void)mw_fail(s,MF_CHILD,errno);
    }
}

static bool work_identity(struct mw_state *s, struct mw_data *d)
{
    if (!s->work_created || s->fd[MS_SERVICE]<0 || s->fd[MS_WORK]<0)
        return mw_fail(s,MF_CGROUP,EINVAL);
    struct stat held={0}, path={0};
    if (fstat(s->fd[MS_WORK],&held)!=0 ||
        fstatat(s->fd[MS_SERVICE],"work",&path,AT_SYMLINK_NOFOLLOW)!=0)
        return mw_fail(s,MF_CGROUP,errno);
    return (S_ISDIR(path.st_mode) && held.st_dev==d->work_stat.st_dev &&
        held.st_ino==d->work_stat.st_ino && path.st_dev==held.st_dev &&
        path.st_ino==held.st_ino && path.st_uid==0U && path.st_gid==0U) ||
        mw_fail(s,MF_CGROUP,ESTALE);
}

static bool own_work(struct mw_state *s, struct mw_data *d)
{
    if (s->worker || s->wait_owned || s->work_owned || !work_identity(s,d))
        return mw_fail(s,MF_CGROUP,EINVAL);
    s->fd[MS_EVENTS]=openat(s->fd[MS_WORK],"cgroup.events",O_RDONLY|O_NOFOLLOW|O_CLOEXEC);
    if (s->fd[MS_EVENTS]<0) return mw_fail(s,MF_CGROUP,errno);
    s->fd[MS_KILL]=openat(s->fd[MS_WORK],"cgroup.kill",O_WRONLY|O_NONBLOCK|O_NOFOLLOW|O_CLOEXEC);
    if (s->fd[MS_KILL]<0) return mw_fail(s,MF_CGROUP,errno);
    s->work_owned=true;
    return mw_timely(s,s->work_deadline);
}

static bool events_value(struct mw_state *s, struct mw_data *d, bool *empty)
{
    size_t length=0U;
    if (s->fd[MS_EVENTS]<0) return mw_fail(s,MF_EMPTY,EBADF);
    if (lseek(s->fd[MS_EVENTS],0,SEEK_SET)!=0) return mw_fail(s,MF_EMPTY,errno);
    if (!mw_read(s,d,s->fd[MS_EVENTS],MF_EMPTY,&length)) return false;
    static const char zero[]="populated 0\nfrozen 0\n";
    static const char one[]="populated 1\nfrozen 0\n";
    if (length!=sizeof zero-1U) return mw_fail(s,MF_EMPTY,EPROTO);
    if (memcmp(d->text,zero,length)==0) { *empty=true; return true; }
    if (memcmp(d->text,one,length)==0) { *empty=false; return true; }
    return mw_fail(s,MF_EMPTY,EPROTO);
}

static bool fresh_empty(struct mw_state *s, struct mw_data *d)
{
    for (size_t i=0U; i<MW_POLLS; ++i) {
        bool empty=false;
        if (!work_identity(s,d) || !events_value(s,d,&empty)) return false;
        if (empty) {
            s->empty=true;
            return mw_now(s,&s->empty_observed) && mw_timely(s,s->cleanup_deadline);
        }
        uint64_t now=0U;
        if (!mw_now(s,&now) || now>=s->cleanup_deadline)
            return mw_fail(s,MF_EMPTY,ETIMEDOUT);
        struct pollfd entry={.fd=-1,.events=0,.revents=0};
        if (poll(&entry,0U,1)<0) return mw_fail(s,MF_EMPTY,errno);
    }
    return mw_fail(s,MF_EMPTY,ETIMEDOUT);
}

static bool remove_work(struct mw_state *s, struct mw_data *d, bool accepted)
{
    if (!s->work_created) return true;
    if (!work_identity(s,d)) return false;
    if (accepted && (!s->ack || !fresh_empty(s,d))) return false;
    if (unlinkat(s->fd[MS_SERVICE],"work",AT_REMOVEDIR)!=0)
        return mw_fail(s,MF_REMOVE,errno);
    s->removed=true;
    return mw_now(s,&s->removed_at) && mw_timely(s,s->cleanup_deadline);
}

static bool normal_cleanup(struct mw_state *s, struct mw_data *d)
{
    mw_begin_cleanup(s);
    kill_owned(s);
    bool waited=wait_child(s,s->cleanup_deadline,true);
    bool empty=s->work_owned && fresh_empty(s,d);
    if (!waited || !empty || !s->wait_valid || !s->reaped ||
        !WIFEXITED(s->wait_status) || WEXITSTATUS(s->wait_status)!=0 || !mw_clean(s))
        return mw_fail(s,MF_CHILD,ECHILD);
    if (!mw_challenge(s) || !mw_send(s,d,MP_REAPED,2U,false,s->cleanup_deadline) ||
        !mw_receive(s,d,MR_EMPTY_ACK,s->cleanup_deadline)) return false;
    s->ack=true;
    s->orderly=remove_work(s,d,true);
    return s->orderly;
}

static void emergency_cleanup(struct mw_state *s, struct mw_data *d)
{
    mw_begin_cleanup(s);
    kill_owned(s); /* Never withhold a safe owned cleanup for missing evidence. */
    bool waited=wait_child(s,s->cleanup_deadline,true);
    (void)waited;
    if (s->work_owned && !s->removed) {
        bool empty=fresh_empty(s,d);
        (void)empty;
    }
    if (s->work_created && !s->removed) {
        bool removed=remove_work(s,d,false);
        (void)removed;
    }
}

int main(void)
{
    struct mw_state *s=&STATE;
    struct mw_data *d=&DATA;
    initialize(s,d);
    bool result=baseline(s,d) && mw_receive(s,d,MR_REQUEST,s->work_deadline) &&
        create_work(s,d) && mw_send(s,d,MP_PREPARED,2U,false,s->work_deadline) &&
        mw_initial_namespaces(s,d) && mw_anchor_namespaces(s,d) && own_work(s,d) &&
        mw_receive(s,d,MR_CREATE,s->work_deadline) && create_child(s,d) &&
        release_worker(s,d) && wait_child(s,s->work_deadline,false) && normal_cleanup(s,d);
    if (!result) emergency_cleanup(s,d);
    mw_close_all(s);
    result=result && s->orderly && s->removed && mw_clean(s) &&
        mw_timely(s,s->cleanup_deadline);
    if (s->request_known)
        (void)mw_send(s,d,MP_TERMINAL,result?0U:1U,false,s->cleanup_deadline);
    close_connection(s);
    bool timely=mw_timely(s,s->total_deadline);
    return result && mw_clean(s) && timely?0:1;
}

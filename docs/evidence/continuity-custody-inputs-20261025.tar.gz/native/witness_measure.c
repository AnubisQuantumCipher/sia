/* SOURCE ONLY. Fresh observation of one externally commissioned process. */
#include "witness.h"
#include <errno.h>
#include <fcntl.h>
#include <limits.h>
#include <linux/magic.h>
#include <linux/nsfs.h>
#include <linux/sched.h>
#include <sys/statfs.h>
#include <poll.h>
#include <stdio.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/pidfd.h>
#include <unistd.h>

_Static_assert(sizeof(struct statfs)<=256U && sizeof(struct pidfd_info)<=512U,
    "conditional original measurement-local budgets");

static bool hex_nonzero(const char *field, size_t length, size_t capacity)
{
    if (length>=capacity || strnlen(field,capacity)!=length) return false;
    bool nonzero=false;
    for (size_t i=0U; i<length; ++i) {
        char c=field[i];
        if (!((c>='0' && c<='9') || (c>='a' && c<='f'))) return false;
        nonzero=nonzero || c!='0';
    }
    return nonzero;
}

bool mw_config(struct mw_state *s)
{
    if (COMMISSION.enabled!=1U || COMMISSION.operator_uid!=1000U ||
        COMMISSION.manager_pid<2U || COMMISSION.manager_pid>INT_MAX ||
        COMMISSION.manager_start==0U || COMMISSION.exe_ino==0U ||
        COMMISSION.exe_size==0U || COMMISSION.exe_size>1048576U ||
        COMMISSION.exe_mtime_nsec>=1000000000U ||
        COMMISSION.exe_ctime_nsec>=1000000000U ||
        COMMISSION.pid_ns_dev==0U || COMMISSION.pid_ns_ino==0U ||
        COMMISSION.cgroup_ns_dev==0U || COMMISSION.cgroup_ns_ino==0U ||
        COMMISSION.user_ns_dev==0U || COMMISSION.user_ns_ino==0U)
        return mw_fail(s,MF_CONFIG,EINVAL);
    size_t group=strnlen(COMMISSION.manager_cgroup,sizeof COMMISSION.manager_cgroup);
    size_t owner=strnlen(COMMISSION.original_bus_owner,sizeof COMMISSION.original_bus_owner);
    if (group>=sizeof COMMISSION.manager_cgroup || owner<2U ||
        owner>=sizeof COMMISSION.original_bus_owner ||
        strnlen(COMMISSION.boot_id,sizeof COMMISSION.boot_id)!=36U ||
        COMMISSION.original_bus_owner[0]!=':' ||
        strcmp(COMMISSION.manager_cgroup,
         "/user.slice/user-1000.slice/user@1000.service/init.scope")!=0)
        return mw_fail(s,MF_CONFIG,EINVAL);
    return (hex_nonzero(COMMISSION.generation,64U,sizeof COMMISSION.generation) &&
        hex_nonzero(COMMISSION.user_unit_invocation,32U,sizeof COMMISSION.user_unit_invocation) &&
        hex_nonzero(COMMISSION.exe_sha256,64U,sizeof COMMISSION.exe_sha256)) ||
        mw_fail(s,MF_CONFIG,EINVAL);
}

bool mw_self_start(struct mw_state *s, struct mw_data *d, uint64_t *start)
{
    size_t length=0U;
    uint64_t threads=0U;
    if (!mw_leaf(s,d,AT_FDCWD,"/proc/self/stat",MF_PROC,&length)) return false;
    return (mw_start(d->text,length,start,&threads) && threads==1U) ||
        mw_fail(s,MF_PROC,EPROTO);
}

static bool group_equal(struct mw_state *s, struct mw_data *d, const char *expected, size_t length)
{
    size_t wanted=strnlen(expected,384U);
    return (wanted<384U && length==wanted+4U &&
        memcmp(d->text,"0::",3U)==0 && d->text[length-1U]=='\n' &&
        memcmp(d->text+3U,expected,wanted)==0) || mw_fail(s,MF_CGROUP,ESTALE);
}

bool mw_self_group(struct mw_state *s, struct mw_data *d, const char *expected)
{
    size_t length=0U;
    return mw_leaf(s,d,AT_FDCWD,"/proc/self/cgroup",MF_PROC,&length) &&
        group_equal(s,d,expected,length);
}

static bool boot_current(struct mw_state *s, struct mw_data *d)
{
    size_t length=0U;
    if (!mw_leaf(s,d,AT_FDCWD,"/proc/sys/kernel/random/boot_id",MF_PROC,&length))
        return false;
    return (length==37U && d->text[36]=='\n' &&
        memcmp(d->text,COMMISSION.boot_id,36U)==0) || mw_fail(s,MF_PROC,ESTALE);
}

static bool pidfd_current(struct mw_state *s)
{
    struct pidfd_info info={.mask=PIDFD_INFO_PID|PIDFD_INFO_CREDS};
    if (ioctl(s->fd[MS_TARGET],PIDFD_GET_INFO,&info)!=0)
        return mw_fail(s,MF_PROC,errno);
    uint64_t mask=PIDFD_INFO_PID|PIDFD_INFO_CREDS;
    if ((info.mask&mask)!=mask || info.pid!=COMMISSION.manager_pid ||
        info.tgid!=COMMISSION.manager_pid || info.ppid!=1U ||
        info.ruid!=COMMISSION.operator_uid || info.euid!=COMMISSION.operator_uid ||
        info.suid!=COMMISSION.operator_uid || info.fsuid!=COMMISSION.operator_uid)
        return mw_fail(s,MF_PROC,ESTALE);
    struct pollfd entry={.fd=s->fd[MS_TARGET],.events=POLLIN|POLLHUP|POLLERR,.revents=0};
    int result=poll(&entry,1U,0);
    if (result<0) return mw_fail(s,MF_PROC,errno);
    if (result==0 && entry.revents==0) return true; /* NOT_EXIT_READY only. */
    if (result==1 && (entry.revents==POLLIN || entry.revents==(POLLIN|POLLHUP)))
        return mw_fail(s,MF_PROC,ESRCH);
    return mw_fail(s,MF_PROC,EPROTO); /* Errors/unknown masks never mean death. */
}

static bool proc_current(struct mw_state *s, struct mw_data *d)
{
    size_t length=0U;
    uint64_t start=0U, threads=0U;
    if (!pidfd_current(s) || !mw_leaf(s,d,s->fd[MS_PROC],"stat",MF_PROC,&length))
        return false;
    if (!mw_start(d->text,length,&start,&threads) || start!=COMMISSION.manager_start)
        return mw_fail(s,MF_PROC,ESTALE);
    if (!mw_leaf(s,d,s->fd[MS_PROC],"cgroup",MF_PROC,&length)) return false;
    return group_equal(s,d,COMMISSION.manager_cgroup,length);
}

bool mw_target_open(struct mw_state *s, struct mw_data *d)
{
    char path[32]={0};
    if (s->fd[MS_TARGET]>=0 || s->fd[MS_PROC]>=0)
        return mw_fail(s,MF_PROC,EINVAL);
    int length=snprintf(path,sizeof path,"/proc/%u",COMMISSION.manager_pid);
    if (length<=0 || (size_t)length>=sizeof path)
        return mw_fail(s,MF_PROC,EOVERFLOW);
    s->fd[MS_TARGET]=pidfd_open((pid_t)COMMISSION.manager_pid,0U);
    if (s->fd[MS_TARGET]<0) return mw_fail(s,MF_PROC,errno);
    s->fd[MS_PROC]=open(path,O_RDONLY|O_DIRECTORY|O_NOFOLLOW|O_CLOEXEC);
    if (s->fd[MS_PROC]<0) return mw_fail(s,MF_PROC,errno);
    return proc_current(s,d) && boot_current(s,d);
}

bool mw_target_current(struct mw_state *s, struct mw_data *d)
{
    return proc_current(s,d) && boot_current(s,d);
}

static bool expected_image(const struct stat *a)
{
    return S_ISREG(a->st_mode) && a->st_uid==0U && a->st_gid==0U &&
        (a->st_mode&0022U)==0U && a->st_nlink==1U && a->st_size>0 &&
        (uint64_t)a->st_dev==COMMISSION.exe_dev &&
        (uint64_t)a->st_ino==COMMISSION.exe_ino &&
        (uint64_t)a->st_size==COMMISSION.exe_size &&
        (int64_t)a->st_mtim.tv_sec==COMMISSION.exe_mtime_sec &&
        (uint32_t)a->st_mtim.tv_nsec==COMMISSION.exe_mtime_nsec &&
        (int64_t)a->st_ctim.tv_sec==COMMISSION.exe_ctime_sec &&
        (uint32_t)a->st_ctim.tv_nsec==COMMISSION.exe_ctime_nsec;
}

static bool current_image_link(struct mw_state *s, struct mw_data *d)
{
    static const char expected[]="/usr/lib/systemd/systemd";
    char link[128]={0};
    ssize_t count=readlinkat(s->fd[MS_PROC],"exe",link,sizeof link);
    if (count<0) return mw_fail(s,MF_IMAGE,errno);
    if (count<=0 || (size_t)count>=sizeof link ||
        (size_t)count!=sizeof expected-1U || memcmp(link,expected,(size_t)count)!=0)
        return mw_fail(s,MF_IMAGE,ESTALE);
    memcpy(d->image_link,link,(size_t)count);
    d->image_link[(size_t)count]='\0';
    struct stat current={0};
    if (fstatat(s->fd[MS_PROC],"exe",&current,0)!=0)
        return mw_fail(s,MF_IMAGE,errno);
    return expected_image(&current) || mw_fail(s,MF_IMAGE,ESTALE);
}

bool mw_measure(struct mw_state *s, struct mw_data *d)
{
    if (!s->worker || !s->released || s->measured || s->fd[MS_IMAGE]>=0)
        return mw_fail(s,MF_IMAGE,EINVAL);
    if (!mw_target_current(s,d) || !mw_now(s,&s->image_before) ||
        !current_image_link(s,d)) return false;
    /* Only this fixed kernel magic leaf is intentionally followed. */
    s->fd[MS_IMAGE]=openat(s->fd[MS_PROC],"exe",O_RDONLY|O_CLOEXEC);
    if (s->fd[MS_IMAGE]<0) return mw_fail(s,MF_IMAGE,errno);
    if (fstat(s->fd[MS_IMAGE],&d->image_stat)!=0)
        return mw_fail(s,MF_IMAGE,errno);
    if (!expected_image(&d->image_stat)) return mw_fail(s,MF_IMAGE,ESTALE);
    bool result=current_image_link(s,d) && proc_current(s,d) && boot_current(s,d) &&
        mw_now(s,&s->image_after) && mw_timely(s,s->work_deadline);
    s->measured=result;
    return result;
}

static bool namespace_identity(struct mw_state *s, struct mw_data *d, size_t kind)
{
    if (kind>=3U || (s->namespace_slot!=MS_IMAGE && s->namespace_slot!=MS_WORK))
        return mw_fail(s,MF_NAMESPACE,EINVAL);
    const uint64_t devs[3]={COMMISSION.pid_ns_dev,COMMISSION.cgroup_ns_dev,
        COMMISSION.user_ns_dev};
    const uint64_t inos[3]={COMMISSION.pid_ns_ino,COMMISSION.cgroup_ns_ino,
        COMMISSION.user_ns_ino};
    const uint32_t types[3]={CLONE_NEWPID,CLONE_NEWCGROUP,CLONE_NEWUSER};
    int fd=s->fd[s->namespace_slot];
    struct statfs fs;
    if (fstat(fd,&d->namespace_stat)!=0 || fstatfs(fd,&fs)!=0)
        return mw_fail(s,MF_NAMESPACE,errno);
    int flags=fcntl(fd,F_GETFL), close_flags=fcntl(fd,F_GETFD);
    if (flags<0 || close_flags<0) return mw_fail(s,MF_NAMESPACE,errno);
    int type=ioctl(fd,NS_GET_NSTYPE);
    if (type<0) return mw_fail(s,MF_NAMESPACE,errno);
    if (fs.f_type!=NSFS_MAGIC || (flags&O_ACCMODE)!=O_RDONLY ||
        (close_flags&FD_CLOEXEC)==0 || (uint32_t)type!=types[kind] ||
        (uint64_t)d->namespace_stat.st_dev!=devs[kind] ||
        (uint64_t)d->namespace_stat.st_ino!=inos[kind])
        return mw_fail(s,MF_NAMESPACE,ESTALE);
    s->namespace_type=types[kind];
    return mw_now(s,&s->namespace_observed) && mw_timely(s,s->work_deadline);
}

static bool namespace_one(struct mw_state *s, struct mw_data *d, size_t kind, enum mw_phase phase,
                          bool target, bool fresh)
{
    static const char *const own[3]={"/proc/self/ns/pid","/proc/self/ns/cgroup",
        "/proc/self/ns/user"};
    static const char *const manager[3]={"ns/pid","ns/cgroup","ns/user"};
    if (kind>=3U || (s->namespace_slot!=MS_IMAGE && s->namespace_slot!=MS_WORK))
        return mw_fail(s,MF_NAMESPACE,EINVAL);
    if (target && !mw_target_current(s,d)) return false;
    if (s->fd[s->namespace_slot]>=0) return mw_fail(s,MF_NAMESPACE,EBUSY);
    int parent=target ? s->fd[MS_PROC] : AT_FDCWD;
    const char *path=target ? manager[kind] : own[kind];
    s->fd[s->namespace_slot]=openat(parent,path,O_RDONLY|O_CLOEXEC);
    if (s->fd[s->namespace_slot]<0) return mw_fail(s,MF_NAMESPACE,errno);
    bool result=namespace_identity(s,d,kind);
    if (result && fresh) result=mw_challenge(s);
    if (result) result=mw_send_namespace(s,d,phase);
    mw_close(s,s->namespace_slot); /* Always before target postcheck: INITIAL peak8. */
    bool current=true;
    if (target) current=mw_target_current(s,d);
    if (s->closes[s->namespace_slot]!=0)
        (void)mw_fail(s,MF_NAMESPACE,s->closes[s->namespace_slot]);
    return result && current && mw_clean(s);
}

static bool namespace_group(struct mw_state *s, struct mw_data *d, enum mw_phase first,
                            enum mw_slot slot, bool target, bool fresh_last)
{
    if (slot!=MS_IMAGE && slot!=MS_WORK) return mw_fail(s,MF_NAMESPACE,EINVAL);
    s->namespace_slot=slot;
    for (size_t kind=0U; kind<3U; ++kind) {
        enum mw_phase phase=(enum mw_phase)((unsigned int)first+(unsigned int)kind);
        if (!namespace_one(s,d,kind,phase,target,fresh_last && kind==2U)) return false;
    }
    return true;
}

bool mw_initial_namespaces(struct mw_state *s, struct mw_data *d)
{
    if (s->worker || s->wait_owned) return mw_fail(s,MF_NAMESPACE,EINVAL);
    bool result=mw_target_open(s,d);
    if (result) result=namespace_group(s,d,MP_INITIAL_PID,MS_IMAGE,true,false);
    mw_close(s,MS_TARGET);
    mw_close(s,MS_PROC);
    return result && mw_clean(s);
}

bool mw_anchor_namespaces(struct mw_state *s, struct mw_data *d)
{
    if (s->worker || s->wait_owned) return mw_fail(s,MF_NAMESPACE,EINVAL);
    bool result=namespace_group(s,d,MP_ANCHOR_PID,MS_IMAGE,false,true);
    if (result) {
        for (size_t i=0U; i<32U; ++i) s->first_challenge[i]=s->challenge[i];
    }
    return result;
}

bool mw_worker_namespaces(struct mw_state *s, struct mw_data *d)
{
    if (!s->worker || s->released) return mw_fail(s,MF_NAMESPACE,EINVAL);
    return namespace_group(s,d,MP_WORKER_PID,MS_IMAGE,false,false);
}

bool mw_preimage_namespaces(struct mw_state *s, struct mw_data *d)
{
    if (!s->worker || !s->released || s->measured)
        return mw_fail(s,MF_NAMESPACE,EINVAL);
    return mw_target_open(s,d) && namespace_group(s,d,MP_PREIMAGE_PID,MS_IMAGE,true,true);
}

bool mw_postimage_namespaces(struct mw_state *s, struct mw_data *d)
{
    if (!s->worker || !s->released || !s->measured || s->fd[MS_IMAGE]<0)
        return mw_fail(s,MF_NAMESPACE,EINVAL);
    return namespace_group(s,d,MP_POSTIMAGE_PID,MS_WORK,true,true);
}

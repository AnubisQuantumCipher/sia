/* SOURCE ONLY. Fixed V4 Linux/AArch64 interface, no runtime target selector. */
#ifndef SIA_WITNESS_V4_H
#define SIA_WITNESS_V4_H
#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/types.h>
#include "commission.h"
enum { MW_REQUEST=176, MW_WIRE=2048, MW_NS_WIRE=256, MW_TEXT=4096,
 MW_CONTROL=256, MW_RX_FDS=64, MW_FAULTS=24, MW_CLOSE=10, MW_FDS=9,
 MW_POLLS=160, MW_RESPONSES=22 };
enum mw_slot { MS_SERVICE=0, MS_WORK=1, MS_EVENTS=2, MS_KILL=3, MS_CHILD=4,
 MS_TEMP=5, MS_TARGET=6, MS_PROC=7, MS_IMAGE=8 };
enum mw_fault { MF_CONFIG=1, MF_ENV=2, MF_CHANNEL=3, MF_RECV=4, MF_ANC=5,
 MF_PROC=6, MF_CGROUP=7, MF_CLONE=8, MF_PLACE=9, MF_IMAGE=10, MF_SEND=11,
 MF_WAIT=12, MF_KILL=13, MF_EMPTY=14, MF_REMOVE=15, MF_DEADLINE=16,
 MF_PROTOCOL=17, MF_CRED=18, MF_INHERIT=19, MF_CHILD=20, MF_SOCKET=21,
 MF_INTERNAL=22, MF_NAMESPACE=23 };
enum mw_phase { MP_PREPARED=1, MP_OWNED=2, MP_PLACED=3, MP_IMAGE=4,
 MP_CLOSED=5, MP_REAPED=6, MP_TERMINAL=7, MP_ANCHOR_PID=8,
 MP_ANCHOR_CGROUP=9, MP_ANCHOR_USER=10, MP_WORKER_PID=11,
 MP_WORKER_CGROUP=12, MP_WORKER_USER=13, MP_INITIAL_PID=14,
 MP_INITIAL_CGROUP=15, MP_INITIAL_USER=16, MP_PREIMAGE_PID=17,
 MP_PREIMAGE_CGROUP=18, MP_PREIMAGE_USER=19, MP_POSTIMAGE_PID=20,
 MP_POSTIMAGE_CGROUP=21, MP_POSTIMAGE_USER=22 };
enum mw_request { MR_REQUEST=1, MR_CREATE=2, MR_PREIMAGE=3, MR_MEASURE=4,
 MR_POSTIMAGE_ACK=5, MR_EMPTY_ACK=6 };
enum mw_wait { MW_NOT_ATTEMPTED=0, MW_REAPED=1, MW_EXPIRED=2,
 MW_ERROR=3, MW_EXHAUSTED=4 };
struct mw_state {
 int fd[MW_FDS], faults[MW_FAULTS], closes[MW_CLOSE];
 int received[MW_RX_FDS], received_closes[MW_RX_FDS];
 size_t received_count;
 pid_t anchor_pid, child_pid;
 uint64_t anchor_start, child_start, begin, work_deadline, total_deadline;
 uint64_t caller_work, caller_overall, cleanup_begin, cleanup_deadline;
 uint64_t image_before, image_after, empty_observed, removed_at, namespace_observed;
 long clone_result;
 int clone_raw_cell, wait_status, poll_error, wait_error[2];
 uint32_t wait_outcome[2], namespace_type;
 unsigned int last_recv_flags, sent_count;
 enum mw_slot namespace_slot;
 bool worker, request_known, work_created, work_owned, wait_owned;
 bool child_validated, wait_valid, reaped, measured, empty, ack, removed;
 bool cleanup_started, orderly, inherited_ok, released;
 unsigned char nonce[32], challenge[32], first_challenge[32];
};
struct mw_data {
 struct ucred peer;
 struct stat service_stat, work_stat, image_stat, namespace_stat;
 int clone_cell;
 unsigned char request[MW_REQUEST];
 char text[MW_TEXT], image_link[128], service_cgroup[384], work_cgroup[384];
 char unit_id[256], invocation[33];
};
struct mw_transport {
 unsigned char wire[MW_WIRE];
 _Alignas(struct cmsghdr) unsigned char control[MW_CONTROL];
};
_Static_assert(sizeof(struct mw_state)<=2048U, "control/history allocation budget");
_Static_assert(sizeof(struct mw_data)<=8192U, "semantic data allocation budget");
_Static_assert(sizeof(struct mw_transport)==2304U, "one wire/control capacity");
_Static_assert(offsetof(struct mw_transport,control)%_Alignof(struct cmsghdr)==0U,
    "native control alignment");
_Static_assert(_Alignof(struct mw_transport)>=_Alignof(struct cmsghdr),
    "automatic transport alignment");
_Static_assert(sizeof(pid_t)<=16U && sizeof(long)<=16U &&
    sizeof(enum mw_slot)<=8U && sizeof(struct stat)<=256U,
    "conditional scalar and semantic stat budgets");
bool mw_fail(struct mw_state *, enum mw_fault, int);
bool mw_clean(const struct mw_state *);
bool mw_now(struct mw_state *, uint64_t *);
bool mw_timely(struct mw_state *, uint64_t);
int mw_poll(struct mw_state *, int, short, uint64_t, enum mw_fault);
void mw_close(struct mw_state *, enum mw_slot);
void mw_close_all(struct mw_state *);
bool mw_read(struct mw_state *, struct mw_data *, int, enum mw_fault, size_t *);
bool mw_leaf(struct mw_state *, struct mw_data *, int, const char *, enum mw_fault, size_t *);
bool mw_start(const char *, size_t, uint64_t *, uint64_t *);
bool mw_receive(struct mw_state *, struct mw_data *, enum mw_request, uint64_t);
bool mw_send(struct mw_state *, struct mw_data *, enum mw_phase, uint32_t, bool, uint64_t);
bool mw_send_namespace(struct mw_state *, struct mw_data *, enum mw_phase);
bool mw_challenge(struct mw_state *);
bool mw_config(struct mw_state *);
bool mw_target_open(struct mw_state *, struct mw_data *);
bool mw_target_current(struct mw_state *, struct mw_data *);
bool mw_measure(struct mw_state *, struct mw_data *);
bool mw_initial_namespaces(struct mw_state *, struct mw_data *);
bool mw_anchor_namespaces(struct mw_state *, struct mw_data *);
bool mw_worker_namespaces(struct mw_state *, struct mw_data *);
bool mw_preimage_namespaces(struct mw_state *, struct mw_data *);
bool mw_postimage_namespaces(struct mw_state *, struct mw_data *);
bool mw_self_start(struct mw_state *, struct mw_data *, uint64_t *);
bool mw_self_group(struct mw_state *, struct mw_data *, const char *);
void mw_begin_cleanup(struct mw_state *);
#endif

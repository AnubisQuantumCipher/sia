# One root-profile lifecycle contract — SOURCE ONLY / ACTIVE INCOMPLETE

This contract targets only `stages.json:stages.root-profile`. It is not an
implementation or admission. `terminal_observer.dispatch()` must continue to
refuse. Original A01–A24/G1–G6/C01–C14/P01–P10/R01–R46 gates, source budgets,
credential requirements and owner authority remain binding. No full-suite,
formatter, actor, protected effect, new mechanism or privilege is authorized.

## PREPARED → CUSTODY_ESTABLISHED

Responsible authority: main owner admits exact source/plan/tool/environment/output;
its independently surviving execution custodian must own the resulting operation.
The current worker does not supply that custodian.

Existing source primitives: exclusive `mkdir`/`open('xb')`, SHA256 source seals,
`flock -F -n -E75 /home/sicarii/.worldline-heavy.lock`, `prlimit` address space
2147483648/file536870912/core0, and the existing10GB reserve requirement. These
are individual gates, not whole-job custody. Record fresh executable/native/module
identities and original credentials (uid/euid, gid/egid and complete supplementary
groups) without changing them. Fresh output-parent ownership and output identity
must be independently recorded; names must not collide with historical output.

Before launch, the custodian must retain one monotonic t0 and bind work deadline
`t0+30` and absolute terminal deadline `t0+35`. Launch, custody acquisition,
release, collection and cleanup consume this envelope. The one5s grace is already
inside it. Never recompute t0 on observation or retry. Existing supervisor samples
its own t0 in main(); that self-report does NOT implement this transition.

**UNIMPLEMENTED prerequisite:** an existing admitted credential-preserving
whole-job route that acquires ownership of the actual payload child BEFORE it
can execute payload or create descendants, and survives supervisor/observer death.
The rejected one-group/overflow-ID credential mappings are not candidates.
No particular manager, executable identity or configuration has been established
for this prerequisite; inventing one would not close it.

Current handle sequence (evidence of the gap, NOT a compliant transfer):
1. `Popen` creates and releases supervisor's direct child with a new session.
2. Supervisor calls `pidfd_open(child.pid)`.
3. `proc(child.pid)` observes identity; `enroll` opens another pidfd and rechecks.
4. Sampled descendant identities receive pidfds only after observation.
5. Signals use retained handles (or exclusive unreaped direct-child fallback),
   reconciliation waits, direct child is reaped, and handles close once.

Failure before step1 requires evidence that no child was created, not inference
from a missing PID. Failure after step1 and before2/3 leaves externally unresolved
child custody. pidfd acquisition/revalidation/close failures retain operation,
PID/starttime when known, acquired handle outcome and cleanup debt. Publishing
PID text, sampled lineage, supervisor-only pidfd and process group are insufficient.
A compliant acquisition/release ordering cannot be specified until the existing
whole-job primitive and credential profile are qualified. No payload release may
occur on that unresolved path.

## CUSTODY_ESTABLISHED → RUNNING

Release requires independently verified custody plus the original deadline,
source/tool/plan/output/credential bindings. Custodian records a unique release
operation and whether it happened; uncertainty prevents a duplicate release.

Existing `timeout --kill-after=5s 30s` in the child command and cooperative Python
clock checks do not establish enforcement if their owning supervisor/observer or
timer dies. A retained pidfd proves neither descendant containment nor independent
enforcement. **UNIMPLEMENTED:** exact existing executable/configuration identity
and evidence for death-resistant limit enforcement over all owned work, preserving
credentials. Current supervisor releases before custody; RUNNING is therefore
unreachable under this contract. No incomplete dispatcher is added.

## RUNNING → TERMINATING

Once the prerequisites exist, the independently surviving custodian owns deadline
and interruption termination. Existing source records pidfd signal attempts,
errors and direct-child wait results; these are distinct events. A sent signal
is not termination; successful wait is reaping one direct child, not proof that
all work is absent. Sampled handles omit unseen descendants.

Use only the remaining portion of the original5s grace within t0+35. No observer
or retry creates another grace. Retain every signal attempt, handle identity,
reap outcome, complete owned-work absence observation and timestamps. Missing
observations become NONPASS/recovery debt. Whole-job absence and enforcement
remain UNIMPLEMENTED until the preceding primitive is qualified.

## TERMINATING → TERMINAL

Independent custodian retains actual exit/signal/deadline state; bounded raw
stdout/stderr; original and final output identity; receipt-inclusive inventory;
current source/tool/host/import/credential observations. Expected values cannot
be copied from supervisor metadata. Compare against closed final terminal schema;
zero exit, an earlier receipt, or disk presence alone cannot produce acceptance.

Existing source-only helpers: observer `collect`, `read_record`, `classify`,
`persist`; supervisor bound terminal metadata and inventory. These functions have
mocked controls only. Independent exit/deadline/inventory producers and observer
lifetime remain UNIMPLEMENTED. The proposed admission packet pins their source,
not actual provenance. Root-profile can only characterize its actual interpreter;
it cannot establish formatter imports or continuity acceptance.

Exclusive write/flush/fsync failures retain uncertain operation and location;
never overwrite or retry that operation blindly. Preserve raw outcomes externally.
If observer cannot persist or return a result, the independently surviving
custodian must retain missing-record NONPASS and recovery debt. Such a custodian
is not established here. Disk persistence alone proves neither retrieval nor
full capture; an independently bound readback/acknowledgment is still required.

## Any state → RECOVERY_REQUIRED

Never infer cleanup from process/record absence. Retain source/stage/output/release
identities, last independently known state, raw outcomes, attempted operations,
unresolved handles/children/credentials and write locations. Main owner must
reconcile these against current independent observations before another session
releases work or retries a write. If evidence cannot resolve an operation, retain
NONPASS and the block. No recovery action is authorized by this document.

## Finite fault matrix (UNRUN)

| Fault boundary | Responsible owner | Required observable evidence | Status and debt |
|---|---|---|---|
| Before child creation | Main owner / future admitted custodian | pinned operation, lock/cap/source/credential/output checks, t0, failed launch result | NONPASS; no-child conclusion only with independent launch evidence; otherwise unknown creation debt |
| After creation before custody | Custodian, prerequisite absent | creation/release event, original credential identity, actual child and acquired-handle outcomes | RECOVERY_REQUIRED; unreconciled child; no retry |
| During custody transfer | Both transfer endpoints under main owner | unique transfer/release IDs, independent acknowledgments and retained handles, no early payload event | NONPASS; ambiguous owner/transfer debt; no duplicate release |
| Execution release failure/uncertainty | Custodian | release operation and independently observed execution boundary | RECOVERY_REQUIRED; retain whether work may have started |
| Supervisor death | Surviving custodian, currently unqualified | independent death/exit and complete owned-work set/enforcement evidence | NONPASS; unseen/unreaped work debt until proven absent |
| Observer death | Surviving custodian, currently unqualified | observer exit/deadline, retained raw channels and last committed record identities | NONPASS; missing-record/custody debt; missing file is not cleanup |
| Partial/truncated output | Observer plus custodian | bounded exact bytes, truncation/read failure, actual exit, output identity | NONPASS; incomplete evidence and unresolved process state |
| Work/terminal deadline | Custodian | original t0/deadlines, signal attempts/errors, reap and complete absence observations within envelope | NONPASS on missing/late evidence; one grace only; unresolved work retained |
| Exclusive write/flush/fsync failure | Writer and custodian | operation/path, attempted bytes/hash when retained, error and independent file readback if possible | NONPASS; uncertain persistence; no blind retry/overwrite |
| Final reaping / disappearance | Custodian | direct-child wait and separate complete owned-work absence evidence, handles and credentials | RAW only after all required observations; otherwise NONPASS/reaping-or-absence debt |
| Source/host/output/credentials changed | Main owner / custodian | separately pinned before/after identities and exact mismatch | NONPASS; stale admission and outstanding operation reconciliation |

Decisive next prerequisite: main owner must identify and admit an ACTUAL existing
credential-preserving whole-job custody/deadline mechanism and its evidence at
creation, transfer and death boundaries. Until then this contract is reviewable,
but CUSTODY_ESTABLISHED/RUNNING and real root-profile dispatch are blocked. More
classifier passes cannot substitute for that decision/evidence. Association-artifact
persistence and full continuity remain OPEN.

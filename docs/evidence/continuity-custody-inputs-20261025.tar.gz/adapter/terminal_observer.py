"""Source-only root-profile observation. No launch or cleanup authority.

Dispatch is deliberately absent until supervisor-to-child custody is qualified.
A supervisor pidfd or process group does not establish child custody.
"""
import hashlib
import json
import math
import os
import select
import re
import stat
import time

LIMIT = 8388608
SCHEMA = 'sia-root-profile-terminal-v1'
BINDINGS = {'supervisor_sha256', 'stages_sha256', 'stage', 'command',
            'environment', 'cwd', 'output', 'output_identity', 'started', 'deadline'}
FIELDS = {'schema', 'binding', 'status', 'acceptance', 'errors', 'recovery_debt',
          'exit', 'observed_owned', 'inventory'}


def pairs(items):
    result = {}
    for key, value in items:
        if key in result:
            raise ValueError('duplicate field')
        result[key] = value
    return result


def constant(value):
    raise ValueError('nonfinite JSON')


class RecordReadError(ValueError):
    def __init__(self, primary, cleanup):
        super().__init__('record read/cleanup failure')
        self.detail = {'status': 'NONPASS', 'primary': primary, 'cleanup': cleanup,
                       'recovery_debt': [] if cleanup['confirmed'] else
                       ['Descriptor close outcome uncertain; do not retry or assume cleanup.']}


def read_failure(error, phase):
    # Fixed phase and exception identity, never arbitrary exception payload.
    return {'phase': phase, 'type': type(error).__name__,
            'errno': error.errno if isinstance(error, OSError) else None}


def read_record(path):
    """One nofollow bounded read and one close; retain primary plus cleanup."""
    descriptor = None
    primary, value, phase = None, None, 'open'
    cleanup = {'attempted': False, 'confirmed': True, 'descriptor': None, 'error': None}
    try:
        descriptor = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
        phase = 'initial_identity'
        before = os.fstat(descriptor)
        phase = 'size_type'
        if not stat.S_ISREG(before.st_mode) or not 0 <= before.st_size <= LIMIT:
            raise ValueError('record size/type')
        chunks, consumed = [], 0
        while consumed <= LIMIT:
            phase = 'read'
            chunk = os.read(descriptor, min(65536, LIMIT + 1 - consumed))
            if not chunk:
                break
            chunks.append(chunk)
            consumed += len(chunk)
            if consumed > LIMIT:
                phase = 'length'
                raise ValueError('record length')
        phase = 'final_identity'
        after = os.fstat(descriptor)
        phase = 'identity_changed'
        if (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns) != (
                after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns):
            raise ValueError('record changed')
        phase = 'length'
        if consumed != before.st_size:
            raise ValueError('record length')
        value = b''.join(chunks)
    except (OSError, ValueError, RuntimeError, MemoryError, KeyboardInterrupt, SystemExit) as error:
        primary = read_failure(error, phase)
    finally:
        if descriptor is not None:
            cleanup.update(attempted=True, confirmed=False, descriptor=descriptor)
            try:
                os.close(descriptor)
                cleanup['confirmed'] = True
            except (OSError, ValueError, RuntimeError, MemoryError, KeyboardInterrupt, SystemExit) as error:
                cleanup['error'] = read_failure(error, 'close')
    if primary is not None or not cleanup['confirmed']:
        raise RecordReadError(primary, cleanup)
    return value


def collect(stdout_fd, stderr_fd, deadline):
    """Bounded raw pipes only, never inferred exit or cleanup. No new grace.

    Caller owns descriptors and must have established a nonblocking pipe source.
    This source function never launches, signals, closes, or reaps processes.
    """
    data = {stdout_fd: bytearray(), stderr_fd: bytearray()}
    active, errors = set(data), []
    if stdout_fd == stderr_fd:
        raise ValueError('distinct streams required')
    for descriptor in active:
        if os.get_blocking(descriptor) or not stat.S_ISFIFO(os.fstat(descriptor).st_mode):
            raise ValueError('nonblocking pipe required')
    while active:
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            errors.append('observation_deadline')
            break
        try:
            ready, _, _ = select.select(tuple(active), (), (), remaining)
        except (OSError, ValueError) as error:
            errors.append('raw_select_' + type(error).__name__)
            break
        for descriptor in ready:
            try:
                chunk = os.read(descriptor, min(65536, LIMIT + 1 - len(data[descriptor])))
            except BlockingIOError:
                continue
            except OSError as error:
                errors.append('raw_read_' + type(error).__name__)
                active.remove(descriptor)
                continue
            if not chunk:
                active.remove(descriptor)
            elif len(data[descriptor]) + len(chunk) > LIMIT:
                errors.append('raw_output_bound')
                active.remove(descriptor)
            else:
                data[descriptor].extend(chunk)
    return bytes(data[stdout_fd]), bytes(data[stderr_fd]), errors


def valid_inventory_row(name, row):
    if (type(name) is not str or not name or len(name) > 16384 or
            name.startswith('/') or any(part in ('', '.', '..') for part in name.split('/')) or
            type(row) is not dict or type(row.get('mode')) is not int or
            not 0 <= row['mode'] <= 65535 or
            type(row.get('bytes')) is not int or not 0 <= row['bytes'] <= 536870912):
        return False
    if stat.S_ISDIR(row['mode']):
        return set(row) == {'mode', 'bytes'}
    return (stat.S_ISREG(row['mode']) and set(row) == {'mode', 'bytes', 'sha256'} and
            type(row['sha256']) is str and re.fullmatch('[0-9a-f]{64}', row['sha256']) is not None)


def closed(value, keys):
    return (type(value) is dict and len(value) == len(keys) and
            all(type(key) is str and len(key) <= 128 for key in value) and set(value) == keys)


def text_field(value, limit):
    return type(value) is str and len(value) <= limit


def uint(value, ceiling):
    return type(value) is int and 0 <= value <= ceiling


def valid_binding(binding):
    if not closed(binding, BINDINGS):
        return False
    if any(type(binding[k]) is not str or re.fullmatch('[0-9a-f]{64}', binding[k]) is None
           for k in ('supervisor_sha256', 'stages_sha256')):
        return False
    if type(binding['stage']) is not str or binding['stage'] != 'root-profile':
        return False
    command, environment, identity = binding['command'], binding['environment'], binding['output_identity']
    if (type(command) is not list or not 1 <= len(command) <= 64 or
            not all(text_field(v, 65536) for v in command) or
            type(environment) is not dict or len(environment) > 32 or
            not all(text_field(k, 128) and text_field(v, 4096) for k, v in environment.items()) or
            not all(text_field(binding[k], 4096) for k in ('cwd', 'output'))):
        return False
    if (not closed(identity, {'device', 'inode', 'mode', 'uid'}) or
            not all(uint(identity[k], 18446744073709551615) for k in ('device', 'inode')) or
            not uint(identity['mode'], 65535) or not stat.S_ISDIR(identity['mode']) or
            not uint(identity['uid'], 4294967295)):
        return False
    # time.monotonic() produces floats. No bool/int aliases, NaN or exponent infinity.
    if not all(type(binding[k]) is float and math.isfinite(binding[k]) and binding[k] >= 0
               for k in ('started', 'deadline')):
        return False
    return binding['deadline'] > binding['started'] and binding['deadline'] == binding['started'] + 35


def classify(raw, captured_stdout, actual_exit, expected, postcheck_errors=(), *, independently_observed_inventory=None):
    """Expected binding must come from independent dispatch/source observations.

    This predicate checks correspondence, not provenance or custody. Output is
    RAW only; interpretation of profile and current host evidence remains open.
    """
    errors = list(postcheck_errors)
    result = {'schema': 'sia-root-profile-observer-v1', 'status': 'NONPASS',
              'acceptance': False, 'errors': errors, 'recovery_debt': [],
              'actual_exit': actual_exit, 'terminal_sha256': None}
    expected_valid = valid_binding(expected)
    if not expected_valid:
        errors.append('expected_binding_invalid')
    if type(actual_exit) is not int:
        errors.append('exit_unavailable')
    elif actual_exit < 0:
        errors.append('signal_exit')
    elif actual_exit != 0:
        errors.append('nonzero_exit')
    if raw is None:
        errors.append('terminal_missing')
    elif type(raw) is not bytes or len(raw) > LIMIT:
        errors.append('terminal_oversized_or_type')
    elif not raw.endswith(b'\n'):
        errors.append('terminal_truncated')
    else:
        result['terminal_sha256'] = hashlib.sha256(raw).hexdigest()
        try:
            record = json.loads(raw, object_pairs_hook=pairs, parse_constant=constant)
        except (ValueError, UnicodeError, RecursionError):
            errors.append('terminal_malformed')
        else:
            if type(record) is not dict or set(record) != FIELDS:
                errors.append('terminal_schema')
            else:
                binding = record['binding']
                binding_valid = valid_binding(binding)
                if not binding_valid:
                    errors.append('terminal_binding_invalid')
                if (record['schema'] != SCHEMA or not binding_valid or
                        not expected_valid or binding != expected):
                    errors.append('terminal_binding_mismatch')
                if raw != captured_stdout:
                    errors.append('terminal_stdout_mismatch')
                if type(record['exit']) is not int or record['exit'] != actual_exit:
                    errors.append('exit_data_disagreement')
                if record['status'] != 'RAW_REQUIRES_POSTFLIGHT_AUDIT' or record['acceptance'] is not False:
                    errors.append('terminal_nonpass')
                if record['errors'] != []:
                    errors.append('terminal_errors')
                if record['recovery_debt'] != []:
                    errors.append('terminal_recovery_debt')
                owned = record['observed_owned']
                if (type(owned) is not list or len(owned) > 64 or
                        any(type(row) is not dict or set(row) != {'pid', 'ppid', 'starttime'} or
                            any(type(row[k]) is not int or not 0 <= row[k] <= 18446744073709551615
                                for k in ('pid', 'ppid', 'starttime')) or row['pid'] == 0
                            for row in owned)):
                    errors.append('owned_schema_invalid')
                inventory = record['inventory']
                if independently_observed_inventory is None:
                    errors.append('inventory_unverified')
                elif inventory != independently_observed_inventory:
                    errors.append('inventory_observation_mismatch')
                if (type(inventory) is not dict or len(inventory) > 20000 or
                        not {'receipt.json', 'stdout.raw', 'stderr.raw'} <= set(inventory)):
                    errors.append('inventory_missing_or_invalid')
                elif (not all(valid_inventory_row(name, row) for name, row in inventory.items()) or
                      any(not stat.S_ISREG(inventory[name]['mode']) for name in
                          ('receipt.json', 'stdout.raw', 'stderr.raw'))):
                    errors.append('inventory_row_invalid')
    if errors:
        result['recovery_debt'].append('Supervisor/child custody and terminal persistence require independent reconciliation; no inferred cleanup.')
    else:
        result['status'] = 'RAW_REQUIRES_POSTFLIGHT_AUDIT'
    return result


def persist(path, result):
    """Single exclusive creation, no retry. Caller retains returned write debt.

    If this observer cannot publish either result or stderr, its invoking owner
    must retain raw exit/output and mark missing observer evidence NONPASS.
    """
    raw = json.dumps(result, sort_keys=True).encode() + b'\n'
    if len(raw) > LIMIT:
        raise ValueError('observer record bound')
    try:
        with open(path, 'xb') as stream:
            stream.write(raw)
            stream.flush()
            os.fsync(stream.fileno())
    except OSError as error:
        return {'status': 'NONPASS', 'acceptance': False, 'errors': ['observer_write_failure'],
                'prior_result': result, 'recovery_debt': [{'path': str(path),
                'write_outcome': 'UNCERTAIN_DO_NOT_RETRY', 'error': type(error).__name__}]}
    return result


def dispatch():
    raise RuntimeError('NOT_ADMITTED: prepublication child custody and external observer lifetime unqualified')

"""Verify inherited exact-type repair on the bound staged integration tree."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import resource
import shutil
import subprocess
import time

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent
SOURCE = Path('/home/sicarii/Work/sia-assurance-checkpoint-20261023')
HEAD = 'c84133a44c6bbb13e1aef044d52a6223829241ed'
TREE = 'ab756bbbb641a6ba5bc1ac94bc4f9a6b0edef880'
PRIOR = ROOT / 'r05-fresh-delivery-capture-v1/workload-result.json'
POLICY = ROOT / 'execution-policy-20261025-v1/AUTHORIZATION.md'
ROSTER = ['tests.test_ownership_exact_type_admission', 'tests.test_cognitive_mechanism_registry', 'tests.test_get_render_admission', 'tests.test_live_publication', 'tests.test_live_publication_integrity', 'tests.test_installed_engine_boundary', 'tests.test_installed_engine_get_boundary', 'tests.test_controller_delivery_wrapper', 'tests.test_checkpoint_delivery_wrapper', 'tests.test_controller_delivery_writer', 'tests.test_controller_delivery_writer_exit_tail', 'tests.test_controller_delivery_writer_completed_phase']


def read_json(path):
    with path.open('rb') as stream:
        raw = stream.read(2097153)
    if len(raw) > 2097152:
        raise ValueError('receipt input capacity')
    return json.loads(raw)


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def write_json(name, value):
    with (OUT / name).open('x') as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write('\n')


def source_state():
    prefix = ['/usr/bin/git', '-C', str(SOURCE)]
    head = subprocess.check_output(prefix + ['rev-parse', 'HEAD']).decode().strip()
    tree = subprocess.check_output(prefix + ['write-tree']).decode().strip()
    unstaged = subprocess.check_output(prefix + ['diff', '--binary'])
    untracked = subprocess.check_output(prefix + ['ls-files', '--others', '--exclude-standard'])
    if head != HEAD or tree != TREE or unstaged or untracked:
        raise ValueError('staged source identity mismatch')
    return head


def prepare():
    prior = read_json(PRIOR)
    command = list(prior['command'])
    prefix = ['/usr/bin/flock', '-F', '-n', '-E', '75',
              '/home/sicarii/.worldline-heavy.lock', '/usr/bin/prlimit',
              '--as=2147483648:2147483648', '--fsize=536870912:536870912',
              '--core=0:0', '--', '/usr/bin/timeout', '--kill-after=5s', '60s']
    if command[:len(prefix)] != prefix or command[len(prefix)] != '/usr/bin/bwrap':
        raise ValueError('historical envelope mismatch')
    old = '/home/sicarii/Work/sia-note-boundary-checkpoint-20261024'
    if command.count(old) != 1:
        raise ValueError('historical source mount mismatch')
    command[command.index(old)] = str(SOURCE)
    prefix_text, rest = command[-1].split('loadTestsFromNames(', 1)
    old_roster, suffix = rest.split('); result=', 1)
    expected_roster = '["tests.test_controller_source_capture_v3","tests.test_controller_source_capture_v3_tail"]'
    if old_roster != expected_roster:
        raise ValueError('historical roster mismatch')
    command[-1] = prefix_text + 'loadTestsFromNames(' + repr(ROSTER) + '); result=' + suffix
    command = prefix[:7] + ['--core=0:0', '--'] + command[len(prefix):]
    tracked = subprocess.check_output(['/usr/bin/git', '-C', str(SOURCE),
        'ls-files', '-z', '--', 'bin', 'tests', 'scripts', 'VERSION'])
    paths = {SOURCE / name.decode() for name in tracked.split(b'\0') if name}
    paths.update((Path(__file__), PRIOR, POLICY))
    paths.update(Path(name) for name in command if name.startswith('/usr/bin/'))
    paths.add(Path('/home/sicarii/Documents/sia-repository-audit-20261024/git-review-executable'))
    return command, prior['environment'], paths


def observe(paths):
    if len(paths) > 2048:
        raise ValueError('inventory capacity')
    return {str(path): sha(path) for path in sorted(paths)}


def execute(command, environment):
    with (OUT / 'full.stdout').open('xb') as stdout, (OUT / 'full.stderr').open('xb') as stderr:
        child = subprocess.Popen(command, env=environment, stdout=stdout, stderr=stderr)
        try:
            write_json('process.json', {'pid': child.pid, 'owner_pid': os.getpid(),
                                       'started_monotonic_ns': time.monotonic_ns()})
            return child.wait()
        finally:
            if child.poll() is None:
                child.kill()
            child.wait()


def main():
    source_state()
    command, environment, paths = prepare()
    before = observe(paths)
    free = shutil.disk_usage(OUT).free
    if free < 11073741824:
        raise ValueError('physical reserve and prior working-space admission')
    record = dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        source_head=HEAD, staged_tree=TREE, command=command, environment=environment, before=before,
        free_disk_bytes=free, inherited_as_limit=resource.getrlimit(resource.RLIMIT_AS),
        inherited_file_limit=resource.getrlimit(resource.RLIMIT_FSIZE),
        source_scope='Inherited exact-type repair; complete original affected modules plus identity controls',
        limitations='Endpoint observations, not loaded-code custody or production latency proof')
    write_json('admission.json', record)
    started = time.monotonic_ns()
    code = execute(command, environment)
    after = observe(paths)
    record.update(exit=code, elapsed_ns=time.monotonic_ns() - started, after=after,
        unchanged=before == after, free_disk_after_bytes=shutil.disk_usage(OUT).free,
        child_usage=list(resource.getrusage(resource.RUSAGE_CHILDREN)),
        outputs={name: sha(OUT / name) for name in ('full.stdout', 'full.stderr')})
    write_json('result.json', record)
    source_state()
    print(json.dumps({key: record[key] for key in ('exit', 'elapsed_ns', 'unchanged')}))
    if code or not record['unchanged']:
        raise SystemExit(1)


if __name__ == '__main__':
    main()

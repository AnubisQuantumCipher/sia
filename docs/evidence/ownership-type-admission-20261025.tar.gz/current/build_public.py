"""Package exact-type admission repair, original failure and full regression."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import re
import tarfile

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent
REPO = Path('/home/sicarii/Work/sia-assurance-checkpoint-20261023')
FILES = ('run.py', 'roster.json', 'preparation.json', 'runner-static.json',
         'runner-static.stdout', 'runner-static.stderr', 'source-static-comparison.json',
         'baseline-static.stdout', 'baseline-static.stderr', 'candidate-static.stdout',
         'candidate-static.stderr', 'admission.json', 'process.json', 'result.json',
         'full.stdout', 'full.stderr', 'REPORT.md', 'review.md', 'root-readback.json',
         'build_public.py', 'builder-static.json')
SOURCES = ('bin/siacognitiveregistry.py', 'bin/siacontrollerdeliverywrapper.py',
           'bin/siacontrollerdeliverywriter.py', 'bin/siagetrenderadmit.py',
           'bin/siainstalledengine.py', 'bin/sialivepublication.py',
           'tests/test_ownership_exact_type_admission.py')


def read(path):
    with path.open('rb') as stream:
        raw = stream.read(8388609)
    if len(raw) > 8388608:
        raise ValueError('forensic member capacity')
    return raw


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def validate():
    result = json.loads(read(OUT / 'result.json'))
    if result['exit'] != 0 or not result['unchanged'] or result['before'] != result['after']:
        raise ValueError('candidate run or endpoint mismatch')
    for name, expected in result['after'].items():
        if digest(read(Path(name))) != expected:
            raise ValueError('bound input changed')
    for name, expected in result['outputs'].items():
        if digest(read(OUT / name)) != expected:
            raise ValueError('raw output mismatch')
    raw = read(OUT / 'full.stderr').decode('utf-8')
    terminal = re.search(r'\nRan ([0-9]+) tests in ([0-9.]+)s\n\nOK\n\Z', raw)
    if terminal is None or 'skipped' in raw:
        raise ValueError('incomplete or skipped suite')
    check = json.loads(read(OUT / 'root-readback.json'))
    if check['parent_exit'] != 0 or check['tested_tree'] != result['staged_tree']:
        raise ValueError('parent or staged-source readback mismatch')
    return result, int(terminal[1]), terminal[2]


def validate_baseline():
    directory = ROOT / 'ownership-type-current-baseline-20261025-v1'
    result = json.loads(read(directory / 'result.json'))
    if result['exit'] != 1 or not result['unchanged'] or result['before'] != result['after']:
        raise ValueError('negative baseline binding mismatch')
    for name, expected in result['outputs'].items():
        if digest(read(directory / name)) != expected:
            raise ValueError('negative baseline output mismatch')
    raw = read(directory / 'full.stderr').decode('utf-8')
    terminal = re.search(r'\nRan ([0-9]+) tests in ([0-9.]+)s\n\n'
                         r'FAILED \(failures=([0-9]+), errors=([0-9]+)\)\n\Z', raw)
    if terminal is None:
        raise ValueError('missing baseline terminal failure')
    return dict(tests=int(terminal[1]), seconds=terminal[2],
                failures=int(terminal[3]), errors=int(terminal[4]), exit=result['exit'])


def validate_composition(tree):
    directory = ROOT / 'ownership-type-capture-resident-20261025-v1'
    result = json.loads(read(directory / 'result.json'))
    if result['staged_tree'] != tree or result['exit'] != 0 \
            or not result['unchanged'] or result['before'] != result['after']:
        raise ValueError('composition result binding mismatch')
    for name, expected in result['after'].items():
        if digest(read(Path(name))) != expected:
            raise ValueError('composition input changed')
    for name, expected in result['outputs'].items():
        if digest(read(directory / name)) != expected:
            raise ValueError('composition output mismatch')
    raw = read(directory / 'full.stderr').decode('utf-8')
    terminal = re.search(r'\nRan ([0-9]+) tests in ([0-9.]+)s\n\nOK\n\Z', raw)
    check = json.loads(read(OUT / 'root-readback.json'))
    if terminal is None or 'skipped' in raw or check['composition_parent_exit'] != 0:
        raise ValueError('composition completion missing')
    return dict(tests=int(terminal[1]), seconds=terminal[2], exit=result['exit'],
                wrapper_elapsed_ns=result['elapsed_ns'], source_endpoints_unchanged=True)


def payloads():
    members = {'current/' + name: read(OUT / name) for name in FILES}
    for name in SOURCES:
        members['source/' + name] = read(REPO / name)
        members['inherited/' + name] = read(OUT / 'inherited' / name)
        if name.startswith('bin/'):
            members['baseline-source/' + name] = read(OUT / 'baseline' / name)
    baseline = ROOT / 'ownership-type-current-baseline-20261025-v1'
    for name in ('run.py', 'static-result.json', 'static.stdout', 'static.stderr',
                 'admission.json', 'process.json', 'result.json', 'full.stdout', 'full.stderr'):
        members['current-baseline/' + name] = read(baseline / name)
    members['current-baseline/profile_case.py'] = read(
        ROOT / 'ownership-type-identity-baseline-v1/profile_case.py')
    composition = ROOT / 'ownership-type-capture-resident-20261025-v1'
    for name in ('run.py', 'roster.json', 'static-result.json', 'static.stdout',
                 'static.stderr', 'admission.json', 'process.json', 'result.json',
                 'full.stdout', 'full.stderr'):
        members['composition/' + name] = read(composition / name)
    prior = ROOT / 'ownership-type-identity-writer-v1'
    for name in ('profile_case.py', 'workload-result.json', 'workload.stdout', 'workload.stderr'):
        members['prior-writer/' + name] = read(prior / name)
    members['AUTHORIZATION.md'] = read(ROOT / 'execution-policy-20261025-v1/AUTHORIZATION.md')
    pins = {name: digest(raw) for name, raw in members.items()}
    members['SHA256.json'] = (json.dumps(pins, indent=2, sort_keys=True) + '\n').encode()
    return members


def archive(members):
    target = io.BytesIO()
    with gzip.GzipFile(fileobj=target, mode='wb', filename='', mtime=0) as zipped:
        with tarfile.open(fileobj=zipped, mode='w', format=tarfile.USTAR_FORMAT) as tar:
            for name, raw in sorted(members.items()):
                entry = tarfile.TarInfo(name)
                entry.size, entry.mode = len(raw), 0o644
                tar.addfile(entry, io.BytesIO(raw))
    return target.getvalue()


def main():
    result, count, seconds = validate()
    baseline = validate_baseline()
    composition = validate_composition(result['staged_tree'])
    members = payloads()
    raw = archive(members)
    if archive(members) != raw:
        raise ValueError('archive reproduction failed')
    relative = 'docs/evidence/ownership-type-admission-20261025.tar.gz'
    report = dict(schema='sia.ownership-type-admission-repair.v1',
        status='RUNTIME_REPAIR_TESTED_STATIC_NONPASS_SYSTEM_INCOMPLETE', authority='NONE',
        base_commit=result['source_head'], tested_tree=result['staged_tree'],
        tests=dict(count=count, seconds=seconds, exit=result['exit'], skips=0,
                   wrapper_elapsed_ns=result['elapsed_ns']),
        sources={name: digest(read(REPO / name)) for name in SOURCES},
        baseline=baseline,
        capture_and_resident_composition=composition,
        selected_static='NONPASS; unchanged code/message multiplicities by filename',
        source_endpoints_unchanged=True, installed_qualification=False,
        whole_system_acceptance=False, archive=dict(path=relative,
        sha256=digest(raw), bytes=len(raw), members=len(members), reproduced=True))
    with (REPO / relative).open('xb') as stream:
        stream.write(raw)
    with (REPO / 'docs/OWNERSHIP-TYPE-ADMISSION-20261025.json').open('x') as stream:
        json.dump(report, stream, indent=2, sort_keys=True)
        stream.write('\n')
    with (REPO / 'docs/OWNERSHIP-TYPE-ADMISSION-20261025.md').open('xb') as stream:
        stream.write(read(OUT / 'REPORT.md'))
    print(json.dumps(report))


if __name__ == '__main__':
    main()

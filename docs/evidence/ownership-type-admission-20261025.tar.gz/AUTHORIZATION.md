# Engineering resource policy correction

Source: direct human messages in owner thread
01a1548c-e4bd-7d10-a4df-b68d11e2b70b on 2026-10-25.

The operator requested removal of resource limits, particularly storage, and
directed verified offloading of inactive data to the iPad. The owner asked:

> Should “no resource limits” remove the engineering-job timeouts and storage
> caps while retaining SIA’s production input, memory and safety bounds?

The operator answered:

> Yes—remove engineering caps; retain product safety bounds

Exact question item:
`["request_user_input_async","call_f3d67db7b6234a408a3ceade10b7e9da",0]`.

This supersedes earlier engineering wall-clock, process-memory and output-size
caps for subsequent task work. It does not change SIA's production input/resource
contracts, internal test or service deadlines, original fixtures, semantic
requirements, source/authority gates, or permission scope. Core-dump suppression,
network isolation, source isolation and one-heavy-job coordination remain.

Older timeouts and failed-cap results are immutable historical evidence. A new
uncapped engineering run cannot be relabeled as passing the old envelope or as
proving a production latency bound. Actual physical RAM/disk availability and
unexpected effects still require observation. Spending/provider authorization,
native compiler OWNER-HOLD and unadmitted protected lifecycle operations are
unchanged.

Storage retirement uses project-vault exact-candidate snapshot, complete restore
and comparison. Active source, unique evidence and toolchain pins remain local.
No manual deletion, unverified offload or weakening of restoration checks follows.
The current Mac USB bridge is listening but reports no configured iPad; neither
archive mount is available. Offload execution awaits device availability.

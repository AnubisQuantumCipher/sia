"""Retain current exception correspondence as reproducible forensic evidence."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import re
import tarfile

OUT = Path(__file__).resolve().parent
REPO = Path('/home/sicarii/Work/sia-assurance-checkpoint-20261023')
NAMES = ('build_binding.py', 'builder-static.json', 'builder.stdout', 'binding.json',
         'verify.py', 'test_verify.py', 'run_checks.py', 'tests-admission.json',
         'tests-result.json', 'tests.stdout', 'tests.stderr', 'static.json',
         'REPORT.md', 'review.md', 'build_public.py', 'package-static.json')


def read(path):
    with path.open('rb') as stream:
        raw = stream.read(1048577)
    if len(raw) > 1048576:
        raise ValueError('forensic input decode capacity')
    return raw


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def payloads():
    members = {name: read(OUT / name) for name in NAMES}
    binding = json.loads(members['binding.json'])
    if len(binding['files']) != 32:
        raise ValueError('unexpected binding inventory')
    inventory = []
    for index, row in enumerate(binding['files']):
        raw = read(Path(row['path']))
        if sha(raw) != row['sha256'] or len(raw) != row['bytes']:
            raise ValueError('bound evidence changed')
        name = f'bound/{index:02d}-{Path(row["path"]).name}'
        members[name] = raw
        inventory.append(dict(row, archive_member=name))
    for name in ('verify.py', 'test_verify.py'):
        members['predecessor/' + name] = read(OUT.parent / 'sdk-exception-verifier-v1' / name)
    members['BOUND-MAP.json'] = (json.dumps(inventory, indent=2, sort_keys=True) + '\n').encode()
    hashes = {name: sha(raw) for name, raw in members.items()}
    members['SHA256.json'] = (json.dumps(hashes, indent=2, sort_keys=True) + '\n').encode()
    return members


def archive(members):
    target = io.BytesIO()
    with gzip.GzipFile(fileobj=target, mode='wb', filename='', mtime=0) as zipped:
        with tarfile.open(fileobj=zipped, mode='w', format=tarfile.USTAR_FORMAT) as tar:
            for name, raw in sorted(members.items()):
                entry = tarfile.TarInfo(name)
                entry.size, entry.mode = len(raw), 0o644
                tar.addfile(entry, io.BytesIO(raw))
    return target.getvalue()


def main():
    members = payloads()
    result = json.loads(members['tests-result.json'])
    if result['exit'] != 0 or not result['unchanged']:
        raise ValueError('offline verifier tests did not pass')
    if sha(members['tests.stderr']) != result['stderr_sha256']:
        raise ValueError('raw test output mismatch')
    footer = re.search(rb'\nRan (\d+) tests in ([\d.]+)s\n\nOK\n\Z', members['tests.stderr'])
    if footer is None or int(footer[1]) != 7:
        raise ValueError('retained complete footer mismatch')
    raw = archive(members)
    if archive(members) != raw:
        raise ValueError('archive did not reproduce')
    relative = 'docs/evidence/sdk-exception-reconciliation-20261025.tar.gz'
    record = {'schema': 'sia.current-sdk-exception-reconciliation.v1', 'authority': 'NONE',
              'status': 'APPROVED_EXACT_EXCEPTIONS_ONLY', 'runtime_admission': False,
              'whole_system_acceptance': False, 'bound_files': 32,
              'binding_sha256': sha(members['binding.json']),
              'raw_analysis': 'Retained exit1; exactly three BLE001 diagnostics, not rerun',
              'tests': {'count': int(footer[1]), 'seconds': footer[2].decode(), 'exit': result['exit'],
                        'unchanged': result['unchanged']},
              'archive': {'path': relative, 'sha256': sha(raw), 'bytes': len(raw),
                          'members': len(members), 'reproduced': True}}
    with (REPO / relative).open('xb') as stream:
        stream.write(raw)
    with (REPO / 'docs/SDK-EXCEPTION-RECONCILIATION-20261025.json').open('x') as stream:
        json.dump(record, stream, indent=2, sort_keys=True)
        stream.write('\n')
    with (REPO / 'docs/SDK-EXCEPTION-RECONCILIATION-20261025.md').open('xb') as stream:
        stream.write(members['REPORT.md'])
    print(json.dumps(record))


if __name__ == '__main__':
    main()

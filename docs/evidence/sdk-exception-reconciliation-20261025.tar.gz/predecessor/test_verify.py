"""Adversarial controls for exact exception-evidence classification."""

import json
import os
from pathlib import Path
import tempfile
import unittest

import verify


class EvidenceBinding(unittest.TestCase):
    def setUp(self):
        self.binding = verify.read_regular(verify.ROOT / "binding.json")
        self.records = json.loads(self.binding)["files"]
        self.originals = {
            row["path"]: verify.read_regular(row["path"]) for row in self.records}

    def test_actual_exact_evidence_retains_failure_and_no_runtime_authority(self):
        result = verify.verify(self.binding)
        self.assertEqual(result["status"], "APPROVED_EXACT_EXCEPTIONS_ONLY")
        self.assertEqual(result["raw_analyzer_status"],
                         "FAILED_ORIGINAL_STRICT167_NONPASS_THREE_BLE_ONLY")
        self.assertIs(result["runtime_admission"], False)
        self.assertIs(result["acceptance"], False)

    def test_each_changed_input_refuses_including_approval_source_and_diagnostics(self):
        for row in self.records:
            with self.subTest(path=row["path"]):
                data = dict(self.originals)
                data[row["path"]] += b" "
                with self.assertRaises(ValueError):
                    verify.verify(self.binding, data.__getitem__)

    def test_each_missing_input_refuses(self):
        for row in self.records:
            with self.subTest(path=row["path"]):
                data = dict(self.originals)
                del data[row["path"]]
                with self.assertRaises(KeyError):
                    verify.verify(self.binding, data.__getitem__)

    def test_changed_or_truncated_binding_refuses(self):
        for raw in (self.binding + b" ", self.binding[:-1], b"{}", b""):
            with self.subTest(size=len(raw)), self.assertRaises(ValueError):
                verify.verify(raw)

    def test_domain_and_byte_overflow_refuse_before_decode(self):
        for raw in (None, "{}", bytearray(), b" " * (verify.LIMIT + 1)):
            with self.subTest(kind=type(raw)), self.assertRaises(ValueError):
                verify.verify(raw)


class BoundedFileRead(unittest.TestCase):
    def test_regular_file_at_limit_and_oversized_file(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "source"
            raw = b"x" * verify.LIMIT
            path.write_bytes(raw)
            self.assertEqual(verify.read_regular(path), raw)
            path.write_bytes(raw + b"x")
            with self.assertRaises(ValueError):
                verify.read_regular(path)

    def test_symlink_directory_and_fifo_refuse_without_blocking(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / "source").write_bytes(b"test")
            (root / "link").symlink_to(root / "source")
            os.mkfifo(root / "fifo")
            for path in (root / "link", root / "fifo", root):
                with self.subTest(path=path), self.assertRaises((OSError, ValueError)):
                    verify.read_regular(path)


if __name__ == "__main__":
    unittest.main()

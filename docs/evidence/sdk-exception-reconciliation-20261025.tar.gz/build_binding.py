"""Bind unchanged approved handlers to current recorded static/runtime evidence.

This offline correspondence check grants no runtime or installation authority.
The Python parser, filesystem and hashes are trusted; hostile same-user mutation
and cryptographic authentication of conversation authorship are outside scope.
"""
import ast
import hashlib
import json
from pathlib import Path
import re

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent
WORK = ROOT / 'sdk-loop-finally-v8'
PRIOR = ROOT / 'sdk-exception-verifier-v1'
RUN = ROOT / 'sdk-full-resource-policy-20261025-v1'
REPO = Path('/home/sicarii/Work/sia-assurance-checkpoint-20261023')
PROPOSAL = ROOT.parent / 'takeover-sdk-three-BLE001-exceptions-operator-proposal-v1.json'
DECISION = ROOT / 'sdk-three-exceptions-decision.json'


def read(path):
    with path.open('rb') as stream:
        raw = stream.read(1048577)
    if len(raw) > 1048576:
        raise ValueError('bounded evidence decode capacity exceeded')
    return raw


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def load(path):
    return json.loads(read(path))


def approved_scope():
    old = load(PRIOR / 'binding.json')
    verifier = read(PRIOR / 'verify.py').decode()
    match = re.search(r'^BINDING_SHA256 = "([a-f0-9]{64})"$', verifier, re.M)
    if match is None or digest(read(PRIOR / 'binding.json')) != match[1]:
        raise ValueError('original approval binding changed')
    pin = [row['sha256'] for row in old['files'] if row['path'] == str(DECISION)]
    if pin != [digest(read(DECISION))]:
        raise ValueError('original decision changed')
    decision = load(DECISION)
    if decision['proposal_sha256'] != digest(read(PROPOSAL)):
        raise ValueError('proposal correspondence changed')
    if decision['approved_sites'] != load(PROPOSAL)['exact_requested_sites']:
        raise ValueError('approved scope differs from original proposal')
    if len(decision['approved_sites']) != 3:
        raise ValueError('approval site count changed')
    return decision['approved_sites'], verifier, match[1]


def function_bytes(raw, name):
    nodes = ast.parse(raw).body
    matches = [node for node in nodes if isinstance(node, ast.FunctionDef) and node.name == name]
    if len(matches) != 1:
        raise ValueError('approved function is not unique')
    node = matches[0]
    lines = raw.splitlines(keepends=True)
    end = node.end_lineno
    for index in range(end, len(lines)):
        if lines[index].strip():
            break
        end = index + 1
    return node.lineno, b''.join(lines[node.lineno - 1:end])


def resolve_sites(sites):
    resolved = []
    for site in sites:
        raw = read(WORK / site['file'])
        start, function = function_bytes(raw, site['function'])
        if digest(function) != site['complete_function_sha256']:
            raise ValueError('approved complete function changed')
        handler = site['handler_text_verbatim'].encode()
        if digest(handler) != site['handler_sha256'] or function.count(handler) != 1:
            raise ValueError('approved handler changed or duplicated')
        prefix = function[:function.index(handler)]
        row = start + prefix.count(b'\n')
        first = handler.splitlines()[0]
        column = first.index(b'BaseException') + 1
        resolved.append({'filename': str(WORK / site['file']), 'row': row,
                         'column': column, 'code': site['rule'],
                         'function': site['function'], 'function_sha256': digest(function),
                         'handler_sha256': digest(handler)})
    return resolved


def check_receipts(resolved):
    analysis = load(WORK / 'static-full.json')
    run = load(RUN / 'result.json')
    own = load(WORK / 'OWN-SOURCE.json')['files']
    if analysis['exit'] != 1 or analysis['stderr'] != '':
        raise ValueError('raw analyzer outcome changed')
    actual = [(d['filename'], d['location']['row'], d['location']['column'], d['code'])
              for d in analysis['diagnostics']]
    expected = [(d['filename'], d['row'], d['column'], d['code']) for d in resolved]
    if sorted(actual) != sorted(expected):
        raise ValueError('missing, extra or changed analyzer diagnostic')
    if run['exit'] != 0 or not run['unchanged'] or run['before'] != run['after']:
        raise ValueError('complete run source correspondence missing')
    if {name: row['sha256'] for name, row in own.items()} != run['before']['source']:
        raise ValueError('run and current source inventory disagree')
    if set(WORK / name for name in own) != set(WORK.glob('*.py')):
        raise ValueError('undeclared source file')
    for name, row in own.items():
        if analysis['files'].get(str(WORK / name)) != row['sha256']:
            raise ValueError('static and runtime source inventory disagree')
    if len(analysis['files']) != 23:
        raise ValueError('original static file roster changed')
    for name, expected_sha in analysis['files'].items():
        if digest(read(Path(name))) != expected_sha:
            raise ValueError('whole-source static input changed')
    for stream in ('stdout', 'stderr'):
        if digest(read(RUN / ('full.' + stream))) != run[stream + '_sha256']:
            raise ValueError('complete run output changed')
    if re.search(rb'\nRan 182 tests in [\d.]+s\n\nOK\n\Z', read(RUN / 'full.stderr')) is None:
        raise ValueError('complete suite footer missing')
    return analysis


def main():
    sites, verifier, original_pin = approved_scope()
    resolved = resolve_sites(sites)
    analysis = check_receipts(resolved)
    paths = [Path(name) for name in analysis['files']]
    paths += [PROPOSAL, DECISION, WORK / 'static-full.json', WORK / 'OWN-SOURCE.json',
              RUN / 'result.json', RUN / 'full.stdout', RUN / 'full.stderr',
              REPO / 'docs/R05-AUTHORIZATION-CORRECTION-20261024.json', PRIOR / 'binding.json']
    if len(paths) > 32 or len(paths) != len(set(paths)):
        raise ValueError('binding roster capacity or duplicates')
    records = [{'path': str(path), 'bytes': len(read(path)), 'sha256': digest(read(path))}
               for path in paths]
    binding = {'schema': 'sia.exact-three-BLE-evidence-binding.v1',
               'raw_analyzer_status': 'FAILED_ORIGINAL_STRICT167_NONPASS_THREE_BLE_ONLY',
               'classification': 'APPROVED_EXACT_EXCEPTIONS_ONLY', 'whole_system_acceptance': False,
               'scope': 'Current v8 retained static evidence and exact approved functions only',
               'resolved_sites': resolved, 'expected_diagnostics': analysis['diagnostics'],
               'files': records, 'runtime_evidence': str(RUN / 'result.json'),
               'limitations': 'No new analyzer/handler execution, authorship authentication, runtime admission or continuous custody'}
    raw = (json.dumps(binding, indent=2, sort_keys=True) + '\n').encode()
    updated = verifier.replace(original_pin, digest(raw))
    if updated == verifier or verifier.count(original_pin) != 1:
        raise ValueError('original verifier pin replacement was not unique')
    for name, value in [('binding.json', raw), ('verify.py', updated.encode()),
                        ('test_verify.py', read(PRIOR / 'test_verify.py'))]:
        with (OUT / name).open('xb') as stream:
            stream.write(value)
    print(json.dumps({'binding_sha256': digest(raw), 'bound_files': len(records),
                      'resolved_sites': resolved, 'verifier_delta': 'Embedded binding digest only'}))


if __name__ == '__main__':
    main()

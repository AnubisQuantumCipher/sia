"""Check one frozen exception disposition; never authorize runtime execution.

Python allocation, filesystem behavior and hash implementation remain trusted.
The byte and roster limits bound admitted inputs, not Python's total memory.
Same-user mutation is outside this offline consistency check's threat model.
"""

import hashlib
import json
import os
from pathlib import Path
import stat


LIMIT = 1048576
ROSTER_LIMIT = 32
BINDING_SHA256 = "a3c059c0a6a1f189e9676d7294e23603f2743e9dcfa81d38472ef48eb321178e"
ROOT = Path(__file__).resolve().parent


def read_regular(path):
    """Reject final symlinks and special files; read at most LIMIT + 1 bytes."""
    flags = os.O_RDONLY | os.O_CLOEXEC | os.O_NOFOLLOW | os.O_NONBLOCK
    descriptor = os.open(path, flags)
    try:
        before = os.fstat(descriptor)
        if not stat.S_ISREG(before.st_mode) or not 0 <= before.st_size <= LIMIT:
            raise ValueError("Evidence must be a bounded regular file")
        parts = []
        used = 0
        for _ in range(257):
            chunk = os.read(descriptor, min(4096, LIMIT + 1 - used))
            if not chunk:
                break
            parts.append(chunk)
            used += len(chunk)
            if used > LIMIT:
                raise ValueError("Evidence exceeded its byte bound")
        else:
            raise ValueError("Evidence did not reach EOF within the read bound")
        after = os.fstat(descriptor)
        fields = ("st_dev", "st_ino", "st_size", "st_mtime_ns", "st_ctime_ns")
        if used != before.st_size or any(
                getattr(before, key) != getattr(after, key) for key in fields):
            raise ValueError("Evidence changed while being read")
        return b"".join(parts)
    finally:
        os.close(descriptor)


def digest(raw):
    if type(raw) is not bytes or len(raw) > LIMIT:
        raise ValueError("Invalid evidence byte domain")
    return hashlib.sha256(raw).hexdigest()


def verify(binding_raw, reader=read_regular):
    """Return a narrow classification only for the embedded exact binding."""
    if digest(binding_raw) != BINDING_SHA256:
        raise ValueError("Exception binding identity mismatch")
    binding = json.loads(binding_raw)
    records = binding["files"]
    if type(records) is not list or not 1 <= len(records) <= ROSTER_LIMIT:
        raise ValueError("Invalid evidence roster")
    for record in records:
        raw = reader(record["path"])
        if digest(raw) != record["sha256"] or len(raw) != record["bytes"]:
            raise ValueError("Bound evidence changed: " + record["path"])
    # The binding was generated only after exact function-byte comparison with
    # the approved proposal. Entire source and raw diagnostics are pinned above.
    return {
        "status": "APPROVED_EXACT_EXCEPTIONS_ONLY",
        "raw_analyzer_status": binding["raw_analyzer_status"],
        "current_analyzer_execution": False,
        "runtime_admission": False,
        "acceptance": False,
        "bound_files": len(records),
    }


def main():
    result = verify(read_regular(ROOT / "binding.json"))
    print(json.dumps(result, sort_keys=True))


if __name__ == "__main__":
    main()

"""Execute the unchanged offline verifier tests with fresh evidence."""
import hashlib
import json
from pathlib import Path
import subprocess
import time

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent
PROPOSAL = ROOT.parent / 'takeover-sdk-three-BLE001-exceptions-operator-proposal-v1.json'
AUTH = Path('/home/sicarii/Work/sia-assurance-checkpoint-20261023/docs/R05-AUTHORIZATION-CORRECTION-20261024.json')


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def save(name, value):
    with (OUT / name).open('x') as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write('\n')


def main():
    command = ['/usr/bin/flock', '-F', '-n', '-E', '75', '/home/sicarii/.worldline-heavy.lock',
               '/usr/bin/prlimit', '--core=0', '--', '/usr/bin/bwrap', '--ro-bind', '/', '/',
               '--tmpfs', '/tmp', '--tmpfs', '/run', '--tmpfs', '/home',
               '--ro-bind', str(ROOT), str(ROOT), '--ro-bind', str(PROPOSAL), str(PROPOSAL),
               '--ro-bind', str(AUTH), str(AUTH), '--dir', '/home/audit',
               '--proc', '/proc', '--dev', '/dev', '--unshare-net', '--unshare-pid',
               '--die-with-parent', '--new-session', '--chdir', str(OUT),
               '/usr/bin/python3', '-I', '-B', '-Werror', '-m', 'unittest', 'discover',
               '-s', str(OUT), '-p', 'test_verify.py', '-v']
    environment = {'HOME': '/home/audit', 'PATH': '/usr/bin:/bin', 'TMPDIR': '/tmp',
                   'LANG': 'C', 'LC_ALL': 'C', 'TZ': 'UTC', 'PYTHONDONTWRITEBYTECODE': '1'}
    paths = [OUT / name for name in ('verify.py', 'binding.json', 'test_verify.py',
                                    'build_binding.py', 'run_checks.py')]
    binding = json.loads((OUT / 'binding.json').read_bytes())
    if len(binding['files']) > 32:
        raise ValueError('binding roster changed')
    paths.extend(Path(row['path']) for row in binding['files'])
    before = {str(path): sha(path) for path in paths}
    record = {'command': command, 'environment': environment, 'before': before}
    save('tests-admission.json', record)
    started = time.monotonic_ns()
    with (OUT / 'tests.stdout').open('xb') as stdout, (OUT / 'tests.stderr').open('xb') as stderr:
        result = subprocess.run(command, env=environment, stdout=stdout, stderr=stderr, check=False)
    after = {str(path): sha(path) for path in paths}
    record.update(exit=result.returncode, elapsed_ns=time.monotonic_ns() - started,
                  after=after, unchanged=before == after,
                  stdout_sha256=sha(OUT / 'tests.stdout'), stderr_sha256=sha(OUT / 'tests.stderr'))
    save('tests-result.json', record)
    print(json.dumps({key: record[key] for key in ('exit', 'elapsed_ns', 'unchanged')}))
    return result.returncode if record['unchanged'] else 1


if __name__ == '__main__':
    raise SystemExit(main())

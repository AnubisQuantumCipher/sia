
/home/sicarii/Work/sia-assurance-evidence-20261019/ownership-transfer-20261024/native-startup-guard-v1/source/spark/bin/continuity_probe:     file format elf64-littleaarch64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000049bc0 <__gnat_install_handler>:
   49bc0:	a9b27bfd 	stp	x29, x30, [sp, #-224]!
   49bc4:	90000000 	adrp	x0, 49000 <__gnat_is_symbolic_link+0x10>
   49bc8:	912b8000 	add	x0, x0, #0xae0
   49bcc:	910003fd 	mov	x29, sp
   49bd0:	f90027e0 	str	x0, [sp, #72]
   49bd4:	52800080 	mov	w0, #0x4                   	// #4
   49bd8:	72aa0000 	movk	w0, #0x5000, lsl #16
   49bdc:	f9000bf3 	str	x19, [sp, #16]
   49be0:	f00001f3 	adrp	x19, 88000 <sia_continuity_current_wire__empty_current+0x26c0>
   49be4:	b900d3e0 	str	w0, [sp, #208]
   49be8:	910143e0 	add	x0, sp, #0x50
   49bec:	97ffa141 	bl	320f0 <__wrap_sigemptyset>
   49bf0:	b94cf260 	ldr	w0, [x19, #3312]
   49bf4:	9133c261 	add	x1, x19, #0xcf0
   49bf8:	7100181f 	cmp	w0, #0x6
   49bfc:	5400018c 	b.gt	49c2c <__gnat_install_handler+0x6c>
   49c00:	b9400420 	ldr	w0, [x1, #4]
   49c04:	340005a0 	cbz	w0, 49cb8 <__gnat_install_handler+0xf8>
   49c08:	b94cf260 	ldr	w0, [x19, #3312]
   49c0c:	7100101f 	cmp	w0, #0x4
   49c10:	54000dcc 	b.gt	49dc8 <__gnat_install_handler+0x208>
   49c14:	9133c273 	add	x19, x19, #0xcf0
   49c18:	52800020 	mov	w0, #0x1                   	// #1
   49c1c:	b9002260 	str	w0, [x19, #32]
   49c20:	f9400bf3 	ldr	x19, [sp, #16]
   49c24:	a8ce7bfd 	ldp	x29, x30, [sp], #224
   49c28:	d65f03c0 	ret
   49c2c:	f9400421 	ldr	x1, [x1, #8]
   49c30:	39401821 	ldrb	w1, [x1, #6]
   49c34:	7101cc3f 	cmp	w1, #0x73
   49c38:	54000401 	b.ne	49cb8 <__gnat_install_handler+0xf8>  // b.any
   49c3c:	7100201f 	cmp	w0, #0x8
   49c40:	9133c260 	add	x0, x19, #0xcf0
   49c44:	5400092d 	b.le	49d68 <__gnat_install_handler+0x1a8>
   49c48:	f9400400 	ldr	x0, [x0, #8]
   49c4c:	39402001 	ldrb	w1, [x0, #8]
   49c50:	7101cc3f 	cmp	w1, #0x73
   49c54:	540008e1 	b.ne	49d70 <__gnat_install_handler+0x1b0>  // b.any
   49c58:	39401000 	ldrb	w0, [x0, #4]
   49c5c:	7101cc1f 	cmp	w0, #0x73
   49c60:	54000b01 	b.ne	49dc0 <__gnat_install_handler+0x200>  // b.any
   49c64:	b94cf260 	ldr	w0, [x19, #3312]
   49c68:	9133c261 	add	x1, x19, #0xcf0
   49c6c:	71001c1f 	cmp	w0, #0x7
   49c70:	5400066d 	b.le	49d3c <__gnat_install_handler+0x17c>
   49c74:	f9400421 	ldr	x1, [x1, #8]
   49c78:	39401c21 	ldrb	w1, [x1, #7]
   49c7c:	7101cc3f 	cmp	w1, #0x73
   49c80:	54000621 	b.ne	49d44 <__gnat_install_handler+0x184>  // b.any
   49c84:	71002c1f 	cmp	w0, #0xb
   49c88:	9133c260 	add	x0, x19, #0xcf0
   49c8c:	5400028d 	b.le	49cdc <__gnat_install_handler+0x11c>
   49c90:	f9400400 	ldr	x0, [x0, #8]
   49c94:	39402c00 	ldrb	w0, [x0, #11]
   49c98:	7101cc1f 	cmp	w0, #0x73
   49c9c:	54000241 	b.ne	49ce4 <__gnat_install_handler+0x124>  // b.any
   49ca0:	9133c273 	add	x19, x19, #0xcf0
   49ca4:	52800020 	mov	w0, #0x1                   	// #1
   49ca8:	b9002260 	str	w0, [x19, #32]
   49cac:	f9400bf3 	ldr	x19, [sp, #16]
   49cb0:	a8ce7bfd 	ldp	x29, x30, [sp], #224
   49cb4:	d65f03c0 	ret
   49cb8:	910123e1 	add	x1, sp, #0x48
   49cbc:	d2800002 	mov	x2, #0x0                   	// #0
   49cc0:	528000c0 	mov	w0, #0x6                   	// #6
   49cc4:	97ffa0f2 	bl	3208c <__wrap_sigaction>
   49cc8:	b94cf260 	ldr	w0, [x19, #3312]
   49ccc:	7100201f 	cmp	w0, #0x8
   49cd0:	9133c260 	add	x0, x19, #0xcf0
   49cd4:	54fffbac 	b.gt	49c48 <__gnat_install_handler+0x88>
   49cd8:	14000024 	b	49d68 <__gnat_install_handler+0x1a8>
   49cdc:	b9400400 	ldr	w0, [x0, #4]
   49ce0:	35fff9a0 	cbnz	w0, 49c14 <__gnat_install_handler+0x54>
   49ce4:	f00001e0 	adrp	x0, 88000 <sia_continuity_current_wire__empty_current+0x26c0>
   49ce8:	91348000 	add	x0, x0, #0xd20
   49cec:	f9001be0 	str	x0, [sp, #48]
   49cf0:	d2900000 	mov	x0, #0x8000                	// #32768
   49cf4:	d2800001 	mov	x1, #0x0                   	// #0
   49cf8:	b9003bff 	str	wzr, [sp, #56]
   49cfc:	f90023e0 	str	x0, [sp, #64]
   49d00:	9100c3e0 	add	x0, sp, #0x30
   49d04:	97ffa0ef 	bl	320c0 <__wrap_sigaltstack>
   49d08:	9133c273 	add	x19, x19, #0xcf0
   49d0c:	b940d3e0 	ldr	w0, [sp, #208]
   49d10:	910123e1 	add	x1, sp, #0x48
   49d14:	d2800002 	mov	x2, #0x0                   	// #0
   49d18:	32050000 	orr	w0, w0, #0x8000000
   49d1c:	b900d3e0 	str	w0, [sp, #208]
   49d20:	52800160 	mov	w0, #0xb                   	// #11
   49d24:	97ffa0da 	bl	3208c <__wrap_sigaction>
   49d28:	52800020 	mov	w0, #0x1                   	// #1
   49d2c:	b9002260 	str	w0, [x19, #32]
   49d30:	f9400bf3 	ldr	x19, [sp, #16]
   49d34:	a8ce7bfd 	ldp	x29, x30, [sp], #224
   49d38:	d65f03c0 	ret
   49d3c:	b9400420 	ldr	w0, [x1, #4]
   49d40:	35fff6a0 	cbnz	w0, 49c14 <__gnat_install_handler+0x54>
   49d44:	910123e1 	add	x1, sp, #0x48
   49d48:	d2800002 	mov	x2, #0x0                   	// #0
   49d4c:	528000e0 	mov	w0, #0x7                   	// #7
   49d50:	97ffa0cf 	bl	3208c <__wrap_sigaction>
   49d54:	b94cf260 	ldr	w0, [x19, #3312]
   49d58:	71002c1f 	cmp	w0, #0xb
   49d5c:	9133c260 	add	x0, x19, #0xcf0
   49d60:	54fff98c 	b.gt	49c90 <__gnat_install_handler+0xd0>
   49d64:	17ffffde 	b	49cdc <__gnat_install_handler+0x11c>
   49d68:	b9400400 	ldr	w0, [x0, #4]
   49d6c:	35fff4e0 	cbnz	w0, 49c08 <__gnat_install_handler+0x48>
   49d70:	910123e1 	add	x1, sp, #0x48
   49d74:	d2800002 	mov	x2, #0x0                   	// #0
   49d78:	52800100 	mov	w0, #0x8                   	// #8
   49d7c:	f90017e1 	str	x1, [sp, #40]
   49d80:	97ffa0c3 	bl	3208c <__wrap_sigaction>
   49d84:	b94cf260 	ldr	w0, [x19, #3312]
   49d88:	9133c262 	add	x2, x19, #0xcf0
   49d8c:	f94017e1 	ldr	x1, [sp, #40]
   49d90:	7100101f 	cmp	w0, #0x4
   49d94:	540001ac 	b.gt	49dc8 <__gnat_install_handler+0x208>
   49d98:	b9400440 	ldr	w0, [x2, #4]
   49d9c:	35fff3c0 	cbnz	w0, 49c14 <__gnat_install_handler+0x54>
   49da0:	d2800002 	mov	x2, #0x0                   	// #0
   49da4:	52800080 	mov	w0, #0x4                   	// #4
   49da8:	97ffa0b9 	bl	3208c <__wrap_sigaction>
   49dac:	b94cf260 	ldr	w0, [x19, #3312]
   49db0:	9133c261 	add	x1, x19, #0xcf0
   49db4:	71001c1f 	cmp	w0, #0x7
   49db8:	54fff5ec 	b.gt	49c74 <__gnat_install_handler+0xb4>
   49dbc:	17ffffe0 	b	49d3c <__gnat_install_handler+0x17c>
   49dc0:	910123e1 	add	x1, sp, #0x48
   49dc4:	17fffff7 	b	49da0 <__gnat_install_handler+0x1e0>
   49dc8:	9133c260 	add	x0, x19, #0xcf0
   49dcc:	f9400400 	ldr	x0, [x0, #8]
   49dd0:	39401000 	ldrb	w0, [x0, #4]
   49dd4:	7101cc1f 	cmp	w0, #0x73
   49dd8:	54fff460 	b.eq	49c64 <__gnat_install_handler+0xa4>  // b.none
   49ddc:	17fffff9 	b	49dc0 <__gnat_install_handler+0x200>

Disassembly of section .fini:


/home/sicarii/Work/sia-assurance-evidence-20261019/ownership-transfer-20261024/native-startup-guard-v1/source/spark/bin/continuity_probe:     file format elf64-littleaarch64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000032060 <__wrap___gnat_install_handler>:
   32060:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
   32064:	52800020 	mov	w0, #0x1                   	// #1
   32068:	910003fd 	mov	x29, sp
   3206c:	f9000bf3 	str	x19, [sp, #16]
   32070:	d00002b3 	adrp	x19, 88000 <sia_continuity_current_wire__empty_current+0x26c0>
   32074:	b900ca60 	str	w0, [x19, #200]
   32078:	94005ed2 	bl	49bc0 <__gnat_install_handler>
   3207c:	b900ca7f 	str	wzr, [x19, #200]
   32080:	f9400bf3 	ldr	x19, [sp, #16]
   32084:	a8c27bfd 	ldp	x29, x30, [sp], #32
   32088:	d65f03c0 	ret

Disassembly of section .fini:

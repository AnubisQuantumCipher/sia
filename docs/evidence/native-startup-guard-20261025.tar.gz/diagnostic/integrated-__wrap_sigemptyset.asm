
/home/sicarii/Work/sia-assurance-evidence-20261019/ownership-transfer-20261024/native-startup-guard-v1/source/spark/bin/continuity_probe:     file format elf64-littleaarch64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

00000000000320f0 <__wrap_sigemptyset>:
   320f0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
   320f4:	910003fd 	mov	x29, sp
   320f8:	97ff44f6 	bl	34d0 <sigemptyset@plt>
   320fc:	3100041f 	cmn	w0, #0x1
   32100:	54000060 	b.eq	3210c <__wrap_sigemptyset+0x1c>  // b.none
   32104:	a8c17bfd 	ldp	x29, x30, [sp], #16
   32108:	d65f03c0 	ret
   3210c:	d00002a1 	adrp	x1, 88000 <sia_continuity_current_wire__empty_current+0x26c0>
   32110:	b940c821 	ldr	w1, [x1, #200]
   32114:	34ffff81 	cbz	w1, 32104 <__wrap_sigemptyset+0x14>
   32118:	52800940 	mov	w0, #0x4a                  	// #74
   3211c:	97ff4475 	bl	32f0 <_exit@plt>

Disassembly of section .fini:

"""Disposable native startup faults; same child resource envelope as original."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
MODULE = ROOT / 'source/spark/tests/test_continuity_process.py'
SPEC = importlib.util.spec_from_file_location('original_controls', MODULE)
FIXTURE = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = FIXTURE
SPEC.loader.exec_module(FIXTURE)
PROCESS = FIXTURE.process
FAULTS = ('e1', 'a1', 'a2', 'a3', 'a4', 'a5', 'b1')


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def probe(path, fault, *, hold_input):
    descriptor = PROCESS.pin_executable(path, digest(path))
    try:
        child = subprocess.Popen(PROCESS.command(descriptor),
            stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            pass_fds=(descriptor,), restore_signals=False,
            env={'PATH': '/usr/bin:/bin', 'LANG': 'C', 'LC_ALL': 'C',
                 'SIA_NATIVE_FAULT': fault})
    finally:
        os.close(descriptor)
    try:
        if hold_input:
            child.wait(timeout=5)
            output, error = child.communicate(timeout=5)
        else:
            output, error = child.communicate(FIXTURE.restore_vector(), timeout=5)
        return {'exit': child.returncode, 'stdout_hex': output.hex(),
                'stderr': error.decode('ascii'), 'input_held_open': hold_input}
    finally:
        if child.poll() is None:
            child.kill()
            child.wait(timeout=1)
        PROCESS.close_pipes(child)


def main():
    binary = ROOT / 'injected-probe'
    before = digest(binary)
    rows = []
    for fault in FAULTS:
        result = probe(binary, fault, hold_input=True)
        rows.append({'fault': fault, **result})
    (ROOT / 'native-fault-results.json').write_text(
        json.dumps(rows, indent=2) + '\n')
    if digest(binary) != before:
        raise RuntimeError('binary changed')
    for row in rows:
        if (row['exit'] != 74 or row['stdout_hex']
                or row['stderr'] != 'injected setup failure\n'):
            raise RuntimeError('native fault control failed: ' + row['fault'])


if __name__ == '__main__':
    main()

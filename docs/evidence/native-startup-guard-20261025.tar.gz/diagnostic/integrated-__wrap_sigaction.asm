
/home/sicarii/Work/sia-assurance-evidence-20261019/ownership-transfer-20261024/native-startup-guard-v1/source/spark/bin/continuity_probe:     file format elf64-littleaarch64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

000000000003208c <__wrap_sigaction>:
   3208c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
   32090:	910003fd 	mov	x29, sp
   32094:	97ff4547 	bl	35b0 <sigaction@plt>
   32098:	3100041f 	cmn	w0, #0x1
   3209c:	54000060 	b.eq	320a8 <__wrap_sigaction+0x1c>  // b.none
   320a0:	a8c17bfd 	ldp	x29, x30, [sp], #16
   320a4:	d65f03c0 	ret
   320a8:	d00002a1 	adrp	x1, 88000 <sia_continuity_current_wire__empty_current+0x26c0>
   320ac:	b940c821 	ldr	w1, [x1, #200]
   320b0:	34ffff81 	cbz	w1, 320a0 <__wrap_sigaction+0x14>
   320b4:	52800940 	mov	w0, #0x4a                  	// #74
   320b8:	97ff448e 	bl	32f0 <_exit@plt>

Disassembly of section .fini:

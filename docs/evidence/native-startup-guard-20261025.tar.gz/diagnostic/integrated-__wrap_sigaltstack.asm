
/home/sicarii/Work/sia-assurance-evidence-20261019/ownership-transfer-20261024/native-startup-guard-v1/source/spark/bin/continuity_probe:     file format elf64-littleaarch64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

00000000000320c0 <__wrap_sigaltstack>:
   320c0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
   320c4:	910003fd 	mov	x29, sp
   320c8:	97ff447e 	bl	32c0 <sigaltstack@plt>
   320cc:	3100041f 	cmn	w0, #0x1
   320d0:	54000060 	b.eq	320dc <__wrap_sigaltstack+0x1c>  // b.none
   320d4:	a8c17bfd 	ldp	x29, x30, [sp], #16
   320d8:	d65f03c0 	ret
   320dc:	d00002a1 	adrp	x1, 88000 <sia_continuity_current_wire__empty_current+0x26c0>
   320e0:	b940c821 	ldr	w1, [x1, #200]
   320e4:	34ffff81 	cbz	w1, 320d4 <__wrap_sigaltstack+0x14>
   320e8:	52800940 	mov	w0, #0x4a                  	// #74
   320ec:	97ff4481 	bl	32f0 <_exit@plt>

Disassembly of section .fini:

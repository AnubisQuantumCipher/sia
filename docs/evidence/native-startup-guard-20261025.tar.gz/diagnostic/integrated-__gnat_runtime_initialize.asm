
/home/sicarii/Work/sia-assurance-evidence-20261019/ownership-transfer-20261024/native-startup-guard-v1/source/spark/bin/continuity_probe:     file format elf64-littleaarch64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000049aa0 <__gnat_runtime_initialize>:
   49aa0:	f00001e2 	adrp	x2, 88000 <sia_continuity_current_wire__empty_current+0x26c0>
   49aa4:	7100001f 	cmp	w0, #0x0
   49aa8:	b94ce441 	ldr	w1, [x2, #3300]
   49aac:	11000421 	add	w1, w1, #0x1
   49ab0:	b90ce441 	str	w1, [x2, #3300]
   49ab4:	7a411820 	ccmp	w1, #0x1, #0x0, ne	// ne = any
   49ab8:	5400004d 	b.le	49ac0 <__gnat_runtime_initialize+0x20>
   49abc:	d65f03c0 	ret
   49ac0:	17ffa168 	b	32060 <__wrap___gnat_install_handler>

Disassembly of section .fini:

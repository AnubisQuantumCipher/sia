#define _XOPEN_SOURCE 700
#include <errno.h>
#include <signal.h>
#include <stdlib.h>
#include <unistd.h>

int __real_sigaction(int sig, const struct sigaction *act,
                     struct sigaction *oldact);
int __real_sigaltstack(const stack_t *stack, stack_t *oldstack);
int __real_sigemptyset(sigset_t *set);
int sia_test_sigaction(int sig, const struct sigaction *act,
                       struct sigaction *oldact);
int sia_test_sigaltstack(const stack_t *stack, stack_t *oldstack);
int sia_test_sigemptyset(sigset_t *set);

static unsigned int action_calls, stack_calls, empty_calls;

static int inject(char kind, unsigned int occurrence)
{
    const char *choice = getenv("SIA_NATIVE_FAULT");
    if (choice != NULL && choice[0] == kind && choice[1] >= '1'
        && choice[1] <= '5' && choice[2] == '\0'
        && occurrence == (unsigned int)(choice[1] - '0')) {
        const char marker[] = "injected setup failure\n";
        if (write(STDERR_FILENO, marker, sizeof(marker) - 1U)
            != (ssize_t)(sizeof(marker) - 1U)) {
            _exit(93);
        }
        errno = EACCES;
        return 1;
    }
    return 0;
}

int sia_test_sigaction(int sig, const struct sigaction *act,
                       struct sigaction *oldact)
{
    action_calls += 1U;
    if (inject('a', action_calls) != 0) {
        return -1;
    }
    return __real_sigaction(sig, act, oldact);
}

int sia_test_sigaltstack(const stack_t *stack, stack_t *oldstack)
{
    stack_calls += 1U;
    if (inject('b', stack_calls) != 0) {
        return -1;
    }
    return __real_sigaltstack(stack, oldstack);
}

int sia_test_sigemptyset(sigset_t *set)
{
    empty_calls += 1U;
    if (inject('e', empty_calls) != 0) {
        return -1;
    }
    return __real_sigemptyset(set);
}

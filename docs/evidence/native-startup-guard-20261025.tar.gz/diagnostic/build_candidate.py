"""Isolated native error-propagation candidate; no installed files modified."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / 'source'
PROJECT = SOURCE / 'spark/transport/continuity_probe.gpr'
WRAPS = ('__gnat_install_handler', 'sigaction', 'sigaltstack', 'sigemptyset')


def run(label, command):
    argv = ['flock', '-n', '/home/sicarii/.worldline-heavy.lock',
            'prlimit', '--as=2147483648', '--fsize=536870912', '--core=0',
            'timeout', '--kill-after=5s', '60s', *command]
    with (ROOT / (label + '.stdout')).open('wb') as out:
        with (ROOT / (label + '.stderr')).open('wb') as err:
            result = subprocess.run(argv, cwd=ROOT, stdout=out, stderr=err,
                                    check=False)
    (ROOT / (label + '.json')).write_text(json.dumps(
        {'argv': argv, 'exit': result.returncode}, indent=2) + '\n')
    if result.returncode != 0:
        raise RuntimeError('command failed: ' + label)


def link(label, objects):
    run(label, ['gprbuild', '-q', '-p', '-j1', '-f', '-l', '-P', str(PROJECT),
                '-largs', *[str(ROOT / name) for name in objects],
                *['-Wl,--wrap=' + name for name in WRAPS],
                '-Wl,-Map=' + str(ROOT / (label + '.map'))])
    binary = ROOT / label
    shutil.copyfile(SOURCE / 'spark/bin/continuity_probe', binary)
    binary.chmod(0o700)


def main():
    run('ada-compile', ['gprbuild', '-q', '-p', '-j1', '-c', '-U',
                        '-P', str(PROJECT)])
    run('ada-link', ['gprbuild', '-q', '-p', '-j1', '-P', str(PROJECT)])
    link('guarded-probe', ['startup_guard.o'])
    run('inject-seam', ['objcopy',
        '--redefine-sym', '__real_sigaction=sia_test_sigaction',
        '--redefine-sym', '__real_sigaltstack=sia_test_sigaltstack',
        '--redefine-sym', '__real_sigemptyset=sia_test_sigemptyset',
        'startup_guard.o', 'startup_guard.injected.o'])
    link('injected-probe', ['startup_guard.injected.o', 'native_faults.o'])
    names = ('guarded-probe', 'injected-probe', 'startup_guard.o',
             'startup_guard.injected.o', 'native_faults.o')
    hashes = {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest()
              for name in names}
    (ROOT / 'candidate-hashes.json').write_text(
        json.dumps(hashes, indent=2) + '\n')
    shutil.copyfile(ROOT / 'guarded-probe', SOURCE / 'spark/bin/continuity_probe')


if __name__ == '__main__':
    main()

"""Bounded diagnostic over one original capture; no cached product decisions."""
from contextlib import ExitStack
import hashlib
import importlib
import json
import sys
import unittest
from unittest import mock

CASE = ('tests.test_controller_source_capture_v3.ControllerSourceCaptureV3.'
        'test_real_idle_capture_keeps_gist_origins_and_bound_empty_journal')
MAX_STRINGS = 4096
MAX_CHARACTERS = 2_000_000
MAX_ROWS = 8192
MAX_CALLS = 10_000_000
HASH = hashlib.sha256


def location(code):
    return (code.co_filename, code.co_firstlineno, code.co_name)


class Observation:
    def __init__(self):
        self.active = False
        self.calls = 0
        self.characters = 0
        self.strings = {}
        self.rows = {}
        self.traversals = []
        self.traversal = 0
        self.phase = 'capture'
        self.capture_calls = 0
        self.invalid = None
        self.site = ('outside-sizing', 0, 'none')
        self.edges = {}
        self.edge_calls = 0
        self.capture_exits = 0
        self.entry_site = None

    def string_entry(self, item):
        if type(item) is not str:
            self.invalid = 'observer requires native string'
            return None
        found = self.strings.get(item)
        if found is not None:
            return found
        if len(self.strings) >= MAX_STRINGS \
                or len(item) > MAX_CHARACTERS - self.characters:
            self.invalid = 'observer string capacity'
            return None
        found = dict(index=len(self.strings), reference=item,
                     characters=len(item), ascii=item.isascii())
        self.strings[item] = found
        self.characters += len(item)
        return found

    def record(self, item, ascii_only):
        if self.calls >= MAX_CALLS:
            self.invalid = 'observer call capacity'
            return
        self.calls += 1
        entry = self.string_entry(item)
        if entry is None:
            return
        key = (entry['index'], ascii_only, self.phase, self.site)
        row = self.rows.get(key)
        if row is None:
            if len(self.rows) >= MAX_ROWS:
                self.invalid = 'observer association capacity'
                return
            row = dict(string=entry['index'], ascii_only=ascii_only,
                       phase=self.phase, site=self.site, calls=0,
                       same_first_object_calls=0, first_call=self.calls,
                       last_call=self.calls, first_traversal=self.traversal,
                       last_traversal=0, traversal_visits=0)
            self.rows[key] = row
        row['calls'] += 1
        row['same_first_object_calls'] += int(item is entry['reference'])
        row['last_call'] = self.calls
        if row['last_traversal'] != self.traversal:
            row['traversal_visits'] += 1
            row['last_traversal'] = self.traversal

    def count(self, original, item, add, *, ascii_only=False):
        if self.active and self.invalid is None:
            try:
                self.record(item, ascii_only)
            except (MemoryError, ValueError, TypeError):
                self.invalid = 'observer recording error'
        return original(item, add, ascii_only=ascii_only)

    def sizing(self, name, original, caller, *args, **kwargs):
        if not self.active or self.invalid is not None:
            return original(*args, **kwargs)
        if len(self.traversals) >= MAX_ROWS:
            self.invalid = 'observer traversal capacity'
            return original(*args, **kwargs)
        index = 2 if name == 'siasourcebatch' else 1
        ceiling = kwargs.get('ceiling', args[index] if len(args) > index else None)
        if type(ceiling) is not int:
            self.invalid = 'observer ceiling metadata'
            return original(*args, **kwargs)
        previous, previous_site = self.traversal, self.site
        self.site = caller
        self.traversal = len(self.traversals) + 1
        row = dict(index=self.traversal, name=name, caller=caller,
                   phase=self.phase, parent=previous, ceiling=ceiling,
                   ascii_only=kwargs.get('ascii_only', False),
                   first_call=self.calls + 1, last_call=None)
        self.traversals.append(row)
        try:
            return original(*args, **kwargs)
        finally:
            row['last_call'] = self.calls
            self.traversal, self.site = previous, previous_site

    def boundary(self, name, original, *args, **kwargs):
        previous = self.phase
        self.phase = name
        try:
            return original(*args, **kwargs)
        finally:
            self.phase = previous

    def profile(self, frame, event, _argument):
        if event != 'call' or self.invalid is not None:
            return
        try:
            key = (location(frame.f_code), call_site(frame.f_back))
            if self.edge_calls >= 1_000_000_000 \
                    or (key not in self.edges and len(self.edges) >= MAX_ROWS):
                self.invalid = 'observer edge capacity'
                return
            self.edge_calls += 1
            self.edges[key] = self.edges.get(key, 0) + 1
        except (MemoryError, ValueError, TypeError, AttributeError):
            self.invalid = 'observer profiling error'

    def capture(self, original, *args, **kwargs):
        if self.active or self.capture_calls or sys.getprofile() is not None:
            self.invalid = 'observer expects one nonrecursive unprofiled capture'
            return original(*args, **kwargs)
        self.capture_calls += 1
        self.active = True
        sys.setprofile(self.profile)
        try:
            return original(*args, **kwargs)
        finally:
            sys.setprofile(None)
            self.active = False
            self.capture_exits += 1

    def report(self):
        strings = []
        for item, row in self.strings.items():
            strings.append(dict(index=row['index'], characters=row['characters'],
                ascii=row['ascii'], sha256=HASH(
                    item.encode('utf-8', 'surrogatepass')).hexdigest()))
        return dict(invalid=self.invalid, capture_calls=self.capture_calls, calls=self.calls,
                    characters=self.characters, strings=strings,
                    associations=list(self.rows.values()), traversals=self.traversals,
                    capture_exits=self.capture_exits, entry_site=self.entry_site,
                    python_call_edges=[dict(callee=key[0], caller=key[1], calls=value)
                                       for key, value in self.edges.items()])


def call_site(frame):
    return (frame.f_code.co_filename, frame.f_lineno, frame.f_code.co_name)


def fixture_origin(frame):
    for _depth in range(64):
        if frame is None or frame.f_code is Observation.capture.__code__:
            return ('product', 0, 'no fixture frame inside capture')
        if '/tests/' in frame.f_code.co_filename:
            return call_site(frame)
        frame = frame.f_back
    return ('UNKNOWN', 0, 'stack limit')


def size_wrapper(observation, name, original):
    def observed(*args, **kwargs):
        frame = sys._getframe(1)
        caller = (call_site(frame), fixture_origin(frame))
        del frame
        return observation.sizing(name, original, caller, *args, **kwargs)
    return observed


def boundary_wrapper(observation, name, original):
    def observed(*args, **kwargs):
        return observation.boundary(name, original, *args, **kwargs)
    return observed


def install(observation, stack):
    source = importlib.import_module('siasourcebatch')
    live = importlib.import_module('sialiveloop')
    original_count = live._count_ascii_json_string
    original_capture = source.capture_successor_v3

    def count(item, add, *, ascii_only=False):
        return observation.count(original_count, item, add, ascii_only=ascii_only)

    def capture(*args, **kwargs):
        observation.entry_site = call_site(sys._getframe(1))
        expected = ('/tmp/source/tests/test_controller_source_capture_v3.py', 515,
                    'test_real_idle_capture_keeps_gist_origins_and_bound_empty_journal')
        if observation.entry_site != expected:
            observation.invalid = 'unexpected capture call site'
        return observation.capture(original_capture, *args, **kwargs)

    stack.enter_context(mock.patch.object(live, '_count_ascii_json_string', count))
    stack.enter_context(mock.patch.object(source, 'capture_successor_v3', capture))
    for module, name in ((source, '_json_size'), (live, '_size')):
        wrapper = size_wrapper(observation, module.__name__, getattr(module, name))
        stack.enter_context(mock.patch.object(module, name, wrapper))
    for name in ('_validate_batch_image', '_validate_retained_projection',
                 '_validate_successor_request'):
        wrapper = boundary_wrapper(observation, name, getattr(source, name))
        stack.enter_context(mock.patch.object(source, name, wrapper))


def main():
    observation = Observation()
    with ExitStack() as stack:
        install(observation, stack)
        suite = unittest.defaultTestLoader.loadTestsFromNames([CASE])
        result = unittest.TextTestRunner(verbosity=2).run(suite)
    if observation.capture_calls != 1 or observation.capture_exits != 1:
        observation.invalid = 'missing complete capture observation'
    report = observation.report()
    report.update(success=result.wasSuccessful(), tests=result.testsRun,
                  scope='Original capture only; instrumentation changes cost. '
                        'Strings are synthetic fixture data; no plaintext output. '
                        'Python call edges only, no call timing or total Python heap proof. '
                        'No safe reuse or performance acceptance inferred.')
    print(json.dumps(report))
    raise SystemExit(0 if result.wasSuccessful() and observation.invalid is None else 1)


if __name__ == '__main__':
    main()

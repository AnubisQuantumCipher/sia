"""Diagnostic controls; no product acceptance claim."""
import unittest
from unittest import mock
import observe_case as observer


class ObserverControls(unittest.TestCase):
    def test_original_callback_and_result_preserved_on_every_call(self):
        state = observer.Observation()
        callback = mock.Mock()
        original = mock.Mock(return_value=False)
        text = 'a native value'
        state.count(original, text, callback, ascii_only=True)
        self.assertEqual(state.calls, 0)
        state.active = True
        self.assertIs(state.count(original, text, callback, ascii_only=True), False)
        self.assertIs(state.count(original, text, callback, ascii_only=True), False)
        self.assertEqual(original.call_args_list, [mock.call(text, callback, ascii_only=True)] * 3)
        callback.assert_not_called()
        self.assertEqual(state.calls, 2)
        self.assertEqual(len(state.strings), 1)

    def test_first_identity_and_modes_do_not_claim_other_identity_reuse(self):
        state = observer.Observation()
        state.active = True
        first = ''.join(['bounded', ' native', ' value'])
        second = first.encode().decode()
        self.assertIsNot(first, second)
        original = mock.Mock(return_value=True)
        for item, mode in ((first, False), (second, False), (first, True)):
            state.count(original, item, None, ascii_only=mode)
        self.assertEqual(len(state.strings), 1)
        rows = list(state.rows.values())
        self.assertEqual([row['calls'] for row in rows], [2, 1])
        self.assertEqual([row['same_first_object_calls'] for row in rows], [1, 1])

    def test_overflow_invalidates_observation_but_preserves_original(self):
        for limit in ('MAX_STRINGS', 'MAX_CHARACTERS', 'MAX_ROWS', 'MAX_CALLS'):
            with self.subTest(limit=limit), mock.patch.object(observer, limit, 0):
                state = observer.Observation()
                state.active = True
                original = mock.Mock(return_value='sentinel')
                self.assertEqual(state.count(original, 'x', None), 'sentinel')
                self.assertEqual(state.count(original, 'x', None), 'sentinel')
                self.assertIsNotNone(state.invalid)
                self.assertEqual(original.call_count, 2)

    def test_nested_state_and_original_exception_are_preserved(self):
        state = observer.Observation()
        state.active = True
        error = RuntimeError('original sentinel')
        failing = mock.Mock(side_effect=error)
        with self.assertRaises(RuntimeError) as caught:
            state.sizing('sizing', state.boundary, ('source', 1, 'caller'),
                         'validation', failing)
        self.assertIs(caught.exception, error)
        self.assertEqual(state.phase, 'capture')
        self.assertEqual(state.traversal, 0)
        self.assertEqual(state.site, ('outside-sizing', 0, 'none'))
        failing.assert_called_once_with()


if __name__ == '__main__':
    unittest.main()

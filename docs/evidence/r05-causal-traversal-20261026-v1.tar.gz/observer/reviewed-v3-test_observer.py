"""Diagnostic controls; no product acceptance claim."""
import unittest
from unittest import mock
import observe_case as observer


class ObserverControls(unittest.TestCase):
    def test_original_callback_and_result_preserved_on_every_call(self):
        state = observer.Observation()
        callback = mock.Mock()
        original = mock.Mock(return_value=False)
        text = 'a native value'
        state.count(original, text, callback, ascii_only=True)
        self.assertEqual(state.calls, 0)
        state.active = True
        self.assertIs(state.count(original, text, callback, ascii_only=True), False)
        self.assertIs(state.count(original, text, callback, ascii_only=True), False)
        self.assertEqual(original.call_args_list, [mock.call(text, callback, ascii_only=True)] * 3)
        callback.assert_not_called()
        self.assertEqual(state.calls, 2)
        self.assertEqual(len(state.strings), 1)

    def test_first_identity_and_modes_do_not_claim_other_identity_reuse(self):
        state = observer.Observation()
        state.active = True
        first = ''.join(['bounded', ' native', ' value'])
        second = first.encode().decode()
        self.assertIsNot(first, second)
        original = mock.Mock(return_value=True)
        for item, mode in ((first, False), (second, False), (first, True)):
            state.count(original, item, None, ascii_only=mode)
        self.assertEqual(len(state.strings), 1)
        rows = list(state.rows.values())
        self.assertEqual([row['calls'] for row in rows], [2, 1])
        self.assertEqual([row['same_first_object_calls'] for row in rows], [1, 1])

    def test_overflow_invalidates_observation_but_preserves_original(self):
        for limit in ('MAX_STRINGS', 'MAX_CHARACTERS', 'MAX_ROWS', 'MAX_CALLS'):
            with self.subTest(limit=limit), mock.patch.object(observer, limit, 0):
                state = observer.Observation()
                state.active = True
                original = mock.Mock(return_value='sentinel')
                self.assertEqual(state.count(original, 'x', None), 'sentinel')
                self.assertEqual(state.count(original, 'x', None), 'sentinel')
                self.assertIsNotNone(state.invalid)
                self.assertEqual(original.call_count, 2)

    def test_nested_state_and_original_exception_are_preserved(self):
        state = observer.Observation()
        state.active = True
        error = RuntimeError('original sentinel')
        failing = mock.Mock(side_effect=error)
        with self.assertRaises(RuntimeError) as caught:
            state.sizing('sialiveloop', lambda _value, _ceiling:
                         state.boundary('validation', failing),
                         ('source', 1, 'caller'), None, 100)
        self.assertIs(caught.exception, error)
        self.assertEqual(state.phase, 'capture')
        self.assertEqual(state.traversal, 0)
        self.assertEqual(state.site, ('outside-sizing', 0, 'none'))
        failing.assert_called_once_with()

class ObserverFailureControls(unittest.TestCase):
    def test_capture_clears_profile_and_phase_after_original_failure(self):
        state = observer.Observation()
        error = ValueError('original capture sentinel')
        with self.assertRaises(ValueError) as caught:
            state.capture(mock.Mock(side_effect=error))
        self.assertIs(caught.exception, error)
        self.assertFalse(state.active)
        self.assertIsNone(observer.sys.getprofile())
        self.assertEqual((state.capture_calls, state.capture_exits), (1, 1))

    def test_online_edge_capacity_keeps_original_return(self):
        state = observer.Observation()
        with mock.patch.object(observer, 'MAX_ROWS', 0):
            result = state.capture(lambda: 'unchanged')
        self.assertEqual(result, 'unchanged')
        self.assertEqual(state.invalid, 'observer edge capacity')
        self.assertEqual(len(state.edges), 0)

    def test_subclass_and_recording_error_do_not_call_overrides(self):
        class Hostile(str):
            def __hash__(self):
                raise AssertionError('must not hash subclass')
        for item in (Hostile('native-looking'), 'native'):
            state = observer.Observation()
            state.active = True
            original = mock.Mock(return_value='original')
            if type(item) is str:
                with mock.patch.object(state, 'string_entry', side_effect=MemoryError):
                    result = state.count(original, item, None)
            else:
                result = state.count(original, item, None)
            self.assertEqual(result, 'original')
            self.assertIsNotNone(state.invalid)
            original.assert_called_once_with(item, None, ascii_only=False)

    def test_surrogate_digest_collision_does_not_merge_content(self):
        state = observer.Observation()
        state.active = True
        original = mock.Mock(return_value=False)
        for item in ('\ud800', 'another'):
            state.count(original, item, None)
        with mock.patch.object(observer, 'HASH') as constructor:
            constructor.return_value.hexdigest.return_value = '0' * 64
            report = state.report()
        self.assertEqual(len(report['strings']), 2)
        self.assertEqual([row['index'] for row in report['strings']], [0, 1])
        self.assertNotIn('\ud800', observer.json.dumps(report))
        self.assertEqual(original.call_count, 2)


class MetadataControls(unittest.TestCase):
    def test_keyword_ceiling_and_invalid_metadata_forward_unchanged(self):
        state = observer.Observation()
        state.active = True
        original = mock.Mock(return_value='result')
        value = {'private canary': 'not a ceiling'}
        self.assertEqual(state.sizing('siasourcebatch', original, ('caller',),
                         {}, value, ceiling=100, ascii_only=True), 'result')
        self.assertEqual(state.traversals[0]['ceiling'], 100)
        original.assert_called_once_with({}, value, ceiling=100, ascii_only=True)
        original.reset_mock()
        self.assertEqual(state.sizing('sialiveloop', original, ('caller',), value),
                         'result')
        self.assertEqual(state.invalid, 'observer ceiling metadata')
        self.assertEqual(len(state.traversals), 1)
        original.assert_called_once_with(value)


if __name__ == '__main__':
    unittest.main()

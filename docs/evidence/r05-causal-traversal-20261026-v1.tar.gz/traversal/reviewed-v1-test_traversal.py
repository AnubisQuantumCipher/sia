"""Differential input/result/refusal/callback controls against exact baseline."""
import importlib.util
import math
import sys
import unittest
from unittest import mock

import siasourcebatch as candidate


def load_baseline():
    spec = importlib.util.spec_from_file_location('traversal_baseline',
                                                '/tmp/baseline_siasourcebatch.py')
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


BASELINE = load_baseline()


def input_case(name):
    if name == 'scalar':
        return {'normal': [None, True, False, 42, 1.25, 'text', '\u007f', '\n"\\', '\u03bb', '\U0001f600']}
    if name == 'alias':
        child = [1.25, 'same child']
        return [child, child, {'child': child}]
    if name == 'cycle':
        value = []
        value.append(value)
        return value
    if name in ('depth64', 'depth65'):
        value = 0
        for _ in range(64 if name == 'depth64' else 65):
            value = [value]
        return value
    if name == 'key':
        return {'first': 1.25, 3: 'invalid later key'}
    if name == 'nan':
        return {'first': 'x', 'later': float('nan')}
    if name == 'integer':
        return {'first': 'x', 'later': 1 << 200}
    if name == 'surrogate':
        return {'first': 'x', 'later': '\ud800'}
    if name == 'mutation':
        return [1.25, 'original later value']
    raise ValueError('unknown fixed fixture')


def observe(module, name, ceiling, ascii_only, mutation=None):
    value = input_case(name)
    trace = []
    original_add = module._JsonSizeCounter.add

    def add(counter, amount):
        trace.append(('add', amount))
        if mutation == 'addition' and len(trace) == 2:
            value.append('appended during budget callback')
        return original_add(counter, amount)

    def finite(number):
        trace.append(('finite', number.hex()))
        if mutation == 'owner':
            value[-1] = b'invalid mutation during current owner callback'
        if mutation == 'refusal':
            return False
        return math.isfinite(number)

    owner = {'math': type('MathOwner', (), {'isfinite': staticmethod(finite)})}
    with mock.patch.object(module._JsonSizeCounter, 'add', add):
        try:
            result = ('accepted', module._json_size(owner, value, ceiling,
                                                    ascii_only=ascii_only))
        except (ValueError, RuntimeError) as error:
            result = ('refused', type(error).__name__, str(error))
    return result, trace


class TraversalControls(unittest.TestCase):
    def test_original_results_refusals_and_ordered_callbacks(self):
        cases = ('scalar', 'alias', 'cycle', 'depth64', 'depth65', 'key',
                 'nan', 'integer', 'surrogate')
        for name in cases:
            for ascii_only in (False, True):
                for ceiling in (1, 10, 100, 4096):
                    with self.subTest(name=name, ascii_only=ascii_only, ceiling=ceiling):
                        self.assertEqual(observe(candidate, name, ceiling, ascii_only),
                                         observe(BASELINE, name, ceiling, ascii_only))

    def test_mutation_and_fresh_owner_refusal_preserve_trace(self):
        for mutation in ('addition', 'owner', 'refusal'):
            for ascii_only in (False, True):
                with self.subTest(mutation=mutation, ascii_only=ascii_only):
                    actual = observe(candidate, 'mutation', 4096, ascii_only, mutation)
                    expected = observe(BASELINE, 'mutation', 4096, ascii_only, mutation)
                    self.assertEqual(actual, expected)
                    self.assertTrue(actual[1])
                    if mutation in ('owner', 'refusal'):
                        self.assertEqual(actual[0][0], 'refused')


if __name__ == '__main__':
    unittest.main()

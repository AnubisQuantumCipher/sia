"""Prepare bounded observation; original source and execution custody unchanged."""
import hashlib
import json
from pathlib import Path
import shutil

BASE = Path(__file__).resolve().parent
PRIOR = BASE / 'r05-workload-delivery-baseline-20261026-v1'
ROOT = BASE / 'r05-causal-capture-20261026-v3'
OBSERVER = BASE / 'r05-causal-observer-20261026-v1'
CARRIER = Path('/home/sicarii/Work/sia-assurance-checkpoint-20261023')


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write('\n')


def inputs():
    audit = json.loads((PRIOR / 'OWNER-AUDIT.json').read_text())
    review = json.loads((PRIOR / 'RESULT-INDEPENDENT-REVIEW.json').read_text())
    if audit['status'] != 'COMPLETE_WORKLOAD_TESTS_PASS' \
            or not audit['tracked_terminal_cleanup'] \
            or review['audit_sha256'] != sha(PRIOR / 'OWNER-AUDIT.json'):
        raise ValueError('prior source/run review binding')
    binding = json.loads((PRIOR / 'source-binding.json').read_text())
    if binding['head'] != 'f330d3f31f55ab67df07112a966d703a9698b266' \
            or binding['canonical'] != str(CARRIER) or not 1 <= len(binding['files']) <= 2048:
        raise ValueError('baseline source binding')
    for name, expected in json.loads((PRIOR / 'execution-source.json').read_text()).items():
        if sha(PRIOR / name) != expected:
            raise ValueError('baseline execution drift')
    for name, row in binding['files'].items():
        if sha(PRIOR / 'source' / name) != row['sha256'] \
                or sha(CARRIER / name) != row['canonical_sha256']:
            raise ValueError('baseline source drift: ' + name)
    return binding


def snapshot(binding):
    ROOT.mkdir(mode=0o700)
    for name in ('obj', 'bin', 'home', 'tmp', 'cache', 'out'):
        (ROOT / name).mkdir(mode=0o700)
    for name in binding['files']:
        source = PRIOR / 'source' / name
        if source.is_symlink() or not source.is_file():
            raise ValueError('nonregular source')
        target = ROOT / 'source' / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, target)
        target.chmod(source.stat().st_mode & 0o777)
    for name in ('obj', 'bin'):
        (ROOT / 'source/spark' / name).mkdir(parents=True, mode=0o555)
    for path in (ROOT / 'source').rglob('*'):
        if path.is_dir():
            path.chmod(0o555)
    (ROOT / 'source').chmod(0o555)
    save(ROOT / 'source-binding.json', binding)


def configure():
    config = json.loads((PRIOR / 'config.json').read_text().replace(str(PRIOR), str(ROOT)))
    code = ('import sys; sys.path[:0]=["/tmp","/tmp/source/bin","/tmp/source"]; '
            'from tests import sia_test_home; import unittest, test_observer, observe_case; '
            'r=unittest.TextTestRunner(verbosity=2).run('
            'unittest.defaultTestLoader.loadTestsFromModule(test_observer)); '
            'sys.exit(1) if not r.wasSuccessful() else observe_case.main()')
    config['proof_command'] = ['/usr/bin/python3', '-I', '-B', '-W',
                               'error::ResourceWarning', '-c', code]
    config['candidate_phase'] = 'r05-causal-capture'
    extra = []
    for name in ('observe_case.py', 'test_observer.py'):
        extra.extend(['--ro-bind', str(ROOT / name), '/tmp/' + name])
    config['namespace_prefix'].extend(extra)
    index = config['command'].index('/usr/bin/setpriv')
    config['command'][index:index] = extra
    save(ROOT / 'config.json', config)
    names = ('proof_wrapper.py', 'proof_payload.py',
             'test_utf8_derivation.py', 'test_utf8_pool.py')
    for name in names:
        shutil.copyfile(PRIOR / name, ROOT / name)
    for name in ('observe_case.py', 'test_observer.py'):
        shutil.copyfile(OBSERVER / name, ROOT / name)
    names += ('config.json', 'source-binding.json', 'observe_case.py', 'test_observer.py')
    save(ROOT / 'execution-source.json', {name: sha(ROOT / name) for name in names})
    save(ROOT / 'OBSERVATION-SOURCE.json', dict(
        original_source='All478selected source rows unchanged from reviewed baseline.',
        status='PREPARED_NOT_EXECUTED',
        limitation='Diagnostic capture extent includes labeled fixture wrappers; '
                   'content equality is not object identity or authorization.'))


def main():
    snapshot(inputs())
    configure()
    print(json.dumps(dict(root=str(ROOT),
                          manifest_sha256=sha(ROOT / 'execution-source.json'))))


if __name__ == '__main__':
    main()

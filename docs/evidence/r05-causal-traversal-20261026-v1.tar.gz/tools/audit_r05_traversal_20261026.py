"""Audit complete original workload rosters without treating timing as assurance."""
import ast
from collections import Counter
import datetime
import hashlib
import json
from pathlib import Path
import re

BASE = Path(__file__).resolve().parent
DIAGNOSTIC = ('SIA: unprivileged PID-namespace isolation is unavailable on this host '
              '(unshare refused); bounded subprocesses fall back to process-group isolation\n')
ROSTERS = {'focused': ['test_traversal', 'tests.test_json_size_iterative',
                       'tests.test_json_key_step']}

def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def identities(root):
    manifest = json.loads((root / 'execution-source.json').read_text())
    binding = json.loads((root / 'source-binding.json').read_text())
    config = json.loads((root / 'config.json').read_text())
    mismatch = []
    for name, expected in manifest.items():
        if sha(root / name) != expected:
            mismatch.append('execution:' + name)
    for name, row in binding['files'].items():
        if sha(root / 'source' / name) != row['sha256'] \
                or (root / 'source' / name).stat().st_size != row['bytes']:
            mismatch.append('snapshot:' + name)
        if sha(Path(binding['canonical']) / name) != row['canonical_sha256']:
            mismatch.append('canonical:' + name)
    for group in ('tools', 'proof_tools'):
        for name, expected in config[group].items():
            if sha(Path(name)) != expected:
                mismatch.append('tool:' + name)
    return mismatch


def terminal_controls(execution):
    cleanup = execution['cleanup']
    terminal = execution['execution_status'] == 'TERMINAL_REPORTS_REQUIRE_AUDIT'
    terminal = terminal and cleanup['complete'] and not cleanup['errors']
    terminal = terminal and execution['proof_dispatched']
    terminal = terminal and set(execution['terminal']) == {'init', 'launcher', 'leader'}
    return terminal and all(row['terminal'] and row['reaped']
                            for row in execution['terminal'].values())


def expected_cases(root, workload):
    cases = []
    for module in ROSTERS[workload]:
        path = (root / 'test_traversal.py' if module == 'test_traversal' else
                root / 'source' / (module.replace('.', '/') + '.py'))
        for node in ast.parse(path.read_text()).body:
            if isinstance(node, ast.ClassDef):
                for method in node.body:
                    if isinstance(method, ast.FunctionDef) and method.name.startswith('test_'):
                        cases.append(module + '.' + node.name + '.' + method.name)
    return cases


def check_output(root, workload, execution):
    stderr = (root / 'proof.stderr').read_text()
    diagnostics = stderr.count(DIAGNOSTIC)
    normalized = stderr.replace(DIAGNOSTIC, '')
    counts = re.findall(r'^Ran (\d+) tests? in ([0-9.]+)s$', normalized, re.MULTILINE)
    if len(counts) != 1:
        raise ValueError('missing or ambiguous complete test summary')
    count, elapsed = int(counts[0][0]), counts[0][1]
    results = re.findall(r'^test_\S+ \(([^)]+)\) \.\.\. ok$', normalized, re.MULTILINE)
    expected = expected_cases(root, workload)
    leftover = re.sub(r'^test_\S+ \([^)]+\) \.\.\. ok\n', '', normalized, flags=re.MULTILINE)
    summary = '\n' + '-' * 70 + '\nRan ' + str(count) + ' tests in ' + elapsed + 's\n\nOK\n'
    classified = leftover == summary and not (root / 'proof.stdout').read_bytes()
    passed = (execution['exit'] == 0 and count == len(expected) == len(results)
              and Counter(results) == Counter(expected) and classified)
    return dict(output_pass=passed, tests=count, expected_tests=len(expected),
                elapsed_seconds=elapsed,
                missing=sorted((Counter(expected) - Counter(results)).elements()),
                unexpected=sorted((Counter(results) - Counter(expected)).elements()),
                nested_isolation_fallback_diagnostics=diagnostics,
                all_raw_output_classified=classified)


def audit(workload, variant):
    root = BASE / 'r05-traversal-focused-20261026-v3'
    execution = json.loads((root / 'execution-result.json').read_text())
    mismatch = identities(root)
    terminal = terminal_controls(execution)
    output = check_output(root, workload, execution)
    passed = output['output_pass'] and terminal and not mismatch
    names = ('execution-source.json', 'source-binding.json', 'execution-result.json',
             'proof.stdout', 'proof.stderr')
    result = dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  status='FOCUSED_TRAVERSAL_TESTS_PASS' if passed else 'NONPASS_CONTROL_FAILURE',
                  workload=workload, variant=variant, output=output,
                  identity_mismatches=mismatch, tracked_terminal_cleanup=terminal,
                  exit=execution['exit'],
                  evidence_sha256={name: sha(root / name) for name in names},
                  independent_review='PENDING', adoption=False,
                  historical_budget_acceptance=False, performance_qualification=False,
                  limitation='One observation. Historical timing target reported separately; '
                             'old engineering caps removed by user. No WCET, resource proof, '
                             'material performance, lifecycle, R05 BOTH or system acceptance.')
    with (root / 'OWNER-AUDIT.json').open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps(result))
    if not passed:
        raise SystemExit(1)


def main():
    audit('focused', 'private-traversal')


if __name__ == '__main__':
    main()

"""Retain closed diagnostic evidence, including failures; no runtime adoption."""
import argparse
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

BASE = Path(__file__).resolve().parent
ROOT = BASE / 'r05-causal-traversal-package-20261026-v1'
ARCHIVE = 'r05-causal-traversal-20261026-v1.tar.gz'
RUNS = {
    'causal-partial': 'r05-causal-capture-20261026-v2',
    'causal-complete': 'r05-causal-capture-20261026-v3',
    'focused': 'r05-traversal-focused-20261026-v3',
    'delivery-candidate': 'r05-traversal-workload-delivery-candidate-20261026-v1',
    'delivery-baseline': 'r05-traversal-workload-delivery-baseline-20261026-v1',
    'resident-candidate': 'r05-traversal-workload-resident-candidate-20261026-v1',
}
FILE_LIMIT = 16777216
TOTAL_LIMIT = 67108864


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def add(files, prefix, directory, names):
    for name in names:
        key = prefix + '/' + name
        if key in files:
            raise ValueError('duplicate archive member')
        files[key] = directory / name


def roster():
    files = {}
    common = ('config.json', 'execution-source.json', 'source-binding.json',
              'execution-result.json', 'proof.stdout', 'proof.stderr',
              'proof_wrapper.py', 'proof_payload.py')
    for label, directory in RUNS.items():
        names = ('OWNER-FAILURE-AUDIT.json',) if label == 'causal-partial' else (
            'OWNER-AUDIT.json', 'RESULT-INDEPENDENT-REVIEW.json')
        add(files, 'runs/' + label, BASE / directory, common + names)
        if label.startswith('causal'):
            add(files, 'runs/' + label, BASE / directory,
                ('observe_case.py', 'test_observer.py', 'OBSERVATION-SOURCE.json'))
    add(files, 'runs/causal-complete', BASE / RUNS['causal-complete'], ('CAUSAL-SUMMARY.json',))
    add(files, 'observer', BASE / 'r05-causal-observer-20261026-v1', (
        'REVIEW-AND-FAILURE-LEDGER.json', 'STATIC-v1.json', 'STATIC-v2.json',
        'STATIC-v3.json', 'STATIC-v4.json', 'reviewed-v1-observe_case.py',
        'reviewed-v1-test_observer.py', 'reviewed-v2-observe_case.py',
        'reviewed-v2-test_observer.py', 'reviewed-v3-observe_case.py',
        'reviewed-v3-test_observer.py'))
    add(files, 'traversal', BASE / 'r05-traversal-v1', (
        'siasourcebatch.py', 'baseline-siasourcebatch.py', 'test_traversal.py',
        'reviewed-v1-siasourcebatch.py', 'reviewed-v1-test_traversal.py',
        'STATIC-v1.json', 'STATIC-v2.json', 'STATIC-v3.json',
        'PREPARER-STATIC-v2.json', 'WORKLOAD-HELPERS-STATIC.json', 'FINAL-DISPOSITION.json'))
    for version, name in (('v1', 'PREPARATION-FAILURE.json'), ('v2', 'PREFLIGHT-FAILURE.json')):
        add(files, 'failures/' + version, BASE / ('r05-traversal-focused-20261026-' + version),
            (name,))
    add(files, 'tools', BASE, (
        'prepare_r05_causal_20261026.py', 'audit_r05_causal_20261026.py',
        'prepare_r05_traversal_20261026.py', 'audit_r05_traversal_20261026.py',
        'prepare_r05_traversal_workloads_20261026.py',
        'audit_r05_traversal_workloads_20261026.py',
        'R05-TRAVERSAL-WORKLOAD-EXECUTION-20261026.json',
        'R05-TRAVERSAL-WORKLOAD-PREFLIGHT-20261026.json',
        Path(__file__).name))
    return files


def verify_runs():
    for label, directory in RUNS.items():
        root = BASE / directory
        name = 'OWNER-FAILURE-AUDIT.json' if label == 'causal-partial' else 'OWNER-AUDIT.json'
        audit = json.loads((root / name).read_text())
        for relative, expected in audit['evidence_sha256'].items():
            if sha(root / relative) != expected:
                raise ValueError('audited evidence drift: ' + relative)
        if label != 'causal-partial':
            review = json.loads((root / 'RESULT-INDEPENDENT-REVIEW.json').read_text())
            expected = review.get('audit_sha256', review.get('owner_audit_sha256'))
            if expected != sha(root / name):
                raise ValueError('independent review binding')
        binding = json.loads((root / 'source-binding.json').read_text())
        for relative, row in binding['files'].items():
            path = root / 'source' / relative
            if sha(path) != row['sha256'] or path.stat().st_size != row['bytes']:
                raise ValueError('source snapshot drift: ' + relative)


def checked_members(files):
    if not 1 <= len(files) <= 256:
        raise ValueError('member count')
    total = 0
    members = {}
    for name, path in sorted(files.items()):
        if path.is_symlink() or not path.is_file() or path.stat().st_size > FILE_LIMIT:
            raise ValueError('input type or size: ' + name)
        size = path.stat().st_size
        total += size
        if total > TOTAL_LIMIT:
            raise ValueError('archive input limit')
        members[name] = dict(sha256=sha(path), bytes=size)
    return members


def archive_bytes(files, members):
    output = io.BytesIO()
    with gzip.GzipFile(fileobj=output, mode='wb', filename='', mtime=0) as zipped:
        with tarfile.open(fileobj=zipped, mode='w', format=tarfile.USTAR_FORMAT) as archive:
            for name, path in sorted(files.items()):
                with path.open('rb') as stream:
                    data = stream.read(FILE_LIMIT + 1)
                if len(data) != members[name]['bytes'] or \
                        hashlib.sha256(data).hexdigest() != members[name]['sha256']:
                    raise ValueError('input changed during packaging')
                info = tarfile.TarInfo(name)
                info.size, info.mode, info.mtime = len(data), 0o444, 0
                archive.addfile(info, io.BytesIO(data))
    return output.getvalue()


def manifest(members, data):
    results = {}
    for label, directory in RUNS.items():
        name = 'OWNER-FAILURE-AUDIT.json' if label == 'causal-partial' else 'OWNER-AUDIT.json'
        result = json.loads((BASE / directory / name).read_text())
        results[label] = dict(status=result['status'], output=result.get('output'),
                             audit_sha256=sha(BASE / directory / name))
    return dict(status='NOT_ADOPTED_NO_MATERIAL_BENEFIT_ESTABLISHED',
                baseline_head='8ed2675d1bd9a67e55f4ee25a21ca3008c50bebe',
                earlier_runtime_equivalent_head='f330d3f31f55ab67df07112a966d703a9698b266',
                archive=dict(path='docs/evidence/' + ARCHIVE, bytes=len(data),
                             sha256=hashlib.sha256(data).hexdigest()),
                members=members, results=results, authority='NONE', adoption=False,
                limits=['Causal receipt contains hashes/metadata of synthetic test strings, not plaintext.',
                        'Partial-capacity observation and preflight failures remain NONPASS or UNRUN.',
                        'Single workload observations do not establish benefit or causal slowdown.',
                        'No safe cross-validation expensive-work reuse was implemented; R05 BOTH remains open.',
                        'Original source snapshots are bound, not all reproduced in this diagnostic archive.',
                        'Observer-loss custody UNKNOWN; no C14 native restoration or installed acceptance.',
                        'Historical engineering timing observations are not current resource policy.',
                        'All A/G/C/P/R/EP obligations remain; no merge, release or marketplace acceptance.'])


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--check', action='store_true')
    args = parser.parse_args()
    verify_runs()
    files = roster()
    members = checked_members(files)
    data = archive_bytes(files, members)
    expected = manifest(members, data)
    encoded = (json.dumps(expected, indent=2, sort_keys=True) + '\n').encode()
    if args.check:
        if (ROOT / ARCHIVE).read_bytes() != data or (ROOT / 'manifest.json').read_bytes() != encoded:
            raise ValueError('package reproduction mismatch')
    else:
        ROOT.mkdir(mode=0o700)
        for name, content in ((ARCHIVE, data), ('manifest.json', encoded)):
            with (ROOT / name).open('xb') as stream:
                if stream.write(content) != len(content):
                    raise OSError('short package write')
    print(json.dumps(dict(status='PACKAGE_CHECK_PASS' if args.check else 'PACKAGE_CREATED',
                          archive=expected['archive'], members=len(members))))


if __name__ == '__main__':
    main()

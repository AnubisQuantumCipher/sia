"""Audit bounded causal observation and controls, not performance acceptance."""
import ast
import collections
import datetime
import hashlib
import json
from pathlib import Path
import re

BASE = Path(__file__).resolve().parent
ROOT = BASE / 'r05-causal-capture-20261026-v3'
DIAGNOSTIC = ('SIA: unprivileged PID-namespace isolation is unavailable on this host '
              '(unshare refused); bounded subprocesses fall back to process-group isolation\n')
CASE = ('tests.test_controller_source_capture_v3.ControllerSourceCaptureV3.'
        'test_real_idle_capture_keeps_gist_origins_and_bound_empty_journal')


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def identities(root):
    manifest = json.loads((root / 'execution-source.json').read_text())
    binding = json.loads((root / 'source-binding.json').read_text())
    config = json.loads((root / 'config.json').read_text())
    mismatch = []
    for name, expected in manifest.items():
        if sha(root / name) != expected:
            mismatch.append('execution:' + name)
    for name, row in binding['files'].items():
        if sha(root / 'source' / name) != row['sha256']:
            mismatch.append('snapshot:' + name)
        if sha(Path(binding['canonical']) / name) != row['canonical_sha256']:
            mismatch.append('canonical:' + name)
    for group in ('tools', 'proof_tools'):
        for name, expected in config[group].items():
            if sha(Path(name)) != expected:
                mismatch.append('tool:' + name)
    return mismatch


def terminal_controls(execution):
    cleanup = execution['cleanup']
    terminal = execution['execution_status'] == 'TERMINAL_REPORTS_REQUIRE_AUDIT'
    terminal = terminal and cleanup['complete'] and not cleanup['errors']
    terminal = terminal and execution['proof_dispatched']
    terminal = terminal and set(execution['terminal']) == {'init', 'launcher', 'leader'}
    return terminal and all(row['terminal'] and row['reaped']
                            for row in execution['terminal'].values())



def verify_report(report):
    if report['invalid'] is not None or report['success'] is not True \
            or report['tests'] != 1 or report['capture_calls'] != 1 \
            or report['capture_exits'] != 1:
        raise ValueError('invalid or absent capture')
    if report['entry_site'] != ['/tmp/source/tests/test_controller_source_capture_v3.py',
        515, 'test_real_idle_capture_keeps_gist_origins_and_bound_empty_journal']:
        raise ValueError('capture callsite')
    strings, rows, traversals = (report[name] for name in
                                ('strings', 'associations', 'traversals'))
    if not 1 <= len(strings) <= 4096 or not 1 <= len(rows) <= 65536 \
            or not 1 <= len(traversals) <= 8192 \
            or not 1 <= len(report['python_call_edges']) <= 8192:
        raise ValueError('table limits')
    if [row['index'] for row in strings] != list(range(len(strings))) \
            or report['characters'] != sum(row['characters'] for row in strings) \
            or not 0 <= report['characters'] <= 2_000_000:
        raise ValueError('string inventory')
    if report['calls'] != sum(row['calls'] for row in rows) \
            or not 0 < report['calls'] <= 10_000_000:
        raise ValueError('call accounting')
    for row in strings:
        if not re.fullmatch('[a-f0-9]{64}', row['sha256']) \
                or type(row['characters']) is not int or row['characters'] < 0 \
                or type(row['ascii']) is not bool:
            raise ValueError('string metadata')
    for row in rows:
        if not 0 <= row['string'] < len(strings) \
                or not 0 <= row['same_first_object_calls'] <= row['calls'] \
                or not 0 < row['first_call'] <= row['last_call'] <= report['calls']:
            raise ValueError('association metadata')
    if any(type(row['ceiling']) is not int for row in traversals):
        raise ValueError('unsafe ceiling metadata')


def check_stderr():
    text = (ROOT / 'proof.stderr').read_text()
    normalized = text.replace(DIAGNOSTIC, '')
    counts = re.findall(r'^Ran ([0-9]+) tests? in ([0-9.]+)s$', normalized, re.MULTILINE)
    if len(counts) != 2 or [count for count, _time in counts] != ['9', '1'] \
            or len(re.findall(r'^OK$', normalized, re.MULTILINE)) != 2:
        raise ValueError('test summaries')
    methods = []
    for cls in ast.parse((ROOT / 'test_observer.py').read_text()).body:
        if isinstance(cls, ast.ClassDef):
            methods += ['test_observer.' + cls.name + '.' + method.name
                        for method in cls.body if isinstance(method, ast.FunctionDef)
                        and method.name.startswith('test_')]
    methods.append(CASE)
    observed = re.findall(r'^test_\S+ \(([^)]+)\) \.\.\. ok$', normalized, re.MULTILINE)
    if collections.Counter(methods) != collections.Counter(observed):
        raise ValueError('exact test roster')
    leftover = re.sub(r'^test_\S+ \([^)]+\) \.\.\. ok$', '', normalized, flags=re.MULTILINE)
    leftover = re.sub(r'^Ran [0-9]+ tests? in [0-9.]+s$|^-+$|^OK$', '',
                      leftover, flags=re.MULTILINE)
    if leftover.strip():
        raise ValueError('unclassified diagnostic')
    return counts, text.count(DIAGNOSTIC)


def main():
    execution = json.loads((ROOT / 'execution-result.json').read_text())
    report = json.loads((ROOT / 'proof.stdout').read_text())
    verify_report(report)
    counts, fallbacks = check_stderr()
    mismatch = identities(ROOT)
    terminal = terminal_controls(execution)
    passed = not mismatch and terminal and execution['exit'] == 0
    files = ('execution-source.json', 'source-binding.json', 'execution-result.json',
             'proof.stdout', 'proof.stderr', 'observe_case.py', 'test_observer.py')
    value = dict(utc=datetime.datetime.now(datetime.UTC).isoformat(),
        status='CAUSAL_OBSERVATION_PASS' if passed else 'NONPASS',
        test_summaries=counts, known_fallback_diagnostics=fallbacks,
        observed_capture_calls=report['capture_calls'], strings=len(report['strings']),
        associations=len(report['associations']), traversals=len(report['traversals']),
        string_calls=report['calls'], python_edges=len(report['python_call_edges']),
        identity_mismatches=mismatch, tracked_terminal_cleanup=terminal,
        evidence_sha256={name: sha(ROOT / name) for name in files},
        independent_review='PENDING', performance_qualification=False,
        limitation='Instrumented original capture extent; fixture-origin work labeled. '
                   'No safe reuse, totalheap, timing or R05 acceptance.')
    (ROOT / 'OWNER-AUDIT.json').write_text(json.dumps(value, indent=2) + '\n')
    print(json.dumps(value))
    raise SystemExit(0 if passed else 1)


if __name__ == '__main__':
    main()

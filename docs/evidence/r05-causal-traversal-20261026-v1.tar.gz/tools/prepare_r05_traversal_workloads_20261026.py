"""Freeze three original-workload observations for private traversal candidate."""
import copy
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

BASE = Path(__file__).resolve().parent
PRIOR = BASE / 'r05-traversal-focused-20261026-v3'
CARRIER = Path('/home/sicarii/Work/sia-assurance-checkpoint-20261023')
HEAD = '8ed2675d1bd9a67e55f4ee25a21ca3008c50bebe'
ROSTERS = {
    'delivery': ['tests.test_controller_source_capture_v3',
                 'tests.test_controller_source_capture_v3_tail'],
    'resident': ['tests.test_controller_source_resident_v3',
                 'tests.test_controller_source_live_transaction'],
}


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write('\n')


def check_inputs():
    audit = json.loads((PRIOR / 'OWNER-AUDIT.json').read_text())
    review = json.loads((PRIOR / 'RESULT-INDEPENDENT-REVIEW.json').read_text())
    if audit['status'] != 'FOCUSED_TRAVERSAL_TESTS_PASS' or not audit['tracked_terminal_cleanup'] \
            or review['audit_sha256'] != sha(PRIOR / 'OWNER-AUDIT.json'):
        raise ValueError('prior regression evidence')
    head = subprocess.run(['git', 'rev-parse', 'HEAD'], cwd=CARRIER,
                          capture_output=True, text=True, check=True).stdout.strip()
    status = subprocess.run(['git', 'status', '--porcelain'], cwd=CARRIER,
                            capture_output=True, text=True, check=True).stdout
    if head != HEAD or status:
        raise ValueError('clean source-bound publisher required')
    binding = json.loads((PRIOR / 'source-binding.json').read_text())
    if binding['head'] != 'f330d3f31f55ab67df07112a966d703a9698b266' or binding['canonical'] != str(CARRIER) \
            or not 1 <= len(binding['files']) <= 2048:
        raise ValueError('source binding')
    for name, expected in json.loads((PRIOR / 'execution-source.json').read_text()).items():
        if sha(PRIOR / name) != expected:
            raise ValueError('prior execution changed: ' + name)
    for name, row in binding['files'].items():
        if sha(PRIOR / 'source' / name) != row['sha256'] \
                or sha(CARRIER / name) != row['canonical_sha256']:
            raise ValueError('source changed: ' + name)
    binding['head'] = HEAD
    return binding


def snapshot(root, original, variant):
    binding = copy.deepcopy(original)
    for name, row in binding['files'].items():
        source = CARRIER / name if variant == 'baseline' else PRIOR / 'source' / name
        if source.is_symlink() or not source.is_file():
            raise ValueError('nonregular source: ' + name)
        target = root / 'source' / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, target)
        target.chmod(0o555 if source.stat().st_mode & 0o111 else 0o444)
        row.update(sha256=sha(target), bytes=target.stat().st_size)
    for name in ('obj', 'bin'):
        (root / 'source/spark' / name).mkdir(parents=True, mode=0o555)
    for path in (root / 'source').rglob('*'):
        if path.is_dir():
            path.chmod(0o555)
    (root / 'source').chmod(0o555)
    binding['variant'] = variant
    save(root / 'source-binding.json', binding)


def configure(root, workload, variant):
    config = json.loads((PRIOR / 'config.json').read_text().replace(str(PRIOR), str(root)))
    code = ('import sys,unittest; sys.path[:0]=["/tmp","/tmp/source/bin","/tmp/source"]; '
            'from tests import sia_test_home; '
            'suite=unittest.defaultTestLoader.loadTestsFromNames(' + repr(ROSTERS[workload]) + '); '
            'result=unittest.TextTestRunner(verbosity=2).run(suite); '
            'raise SystemExit(0 if result.wasSuccessful() else 1)')
    config['proof_command'] = ['/usr/bin/python3', '-I', '-B', '-W',
                               'error::ResourceWarning', '-c', code]
    config['candidate_phase'] = 'r05-workload-' + workload + '-' + variant
    save(root / 'config.json', config)
    names = ('proof_wrapper.py', 'proof_payload.py',
             'test_utf8_derivation.py', 'test_utf8_pool.py',
             'baseline_siasourcebatch.py', 'test_traversal.py')
    for name in names:
        shutil.copyfile(PRIOR / name, root / name)
    names += ('config.json', 'source-binding.json')
    save(root / 'execution-source.json', {name: sha(root / name) for name in names})
    print(json.dumps(dict(root=str(root), workload=workload, variant=variant,
                         roster=ROSTERS[workload],
                         manifest_sha256=sha(root / 'execution-source.json'))))


def main():
    binding = check_inputs()
    for workload in ROSTERS:
        for variant in ('candidate', 'baseline'):
            if workload == 'resident' and variant == 'baseline':
                continue
            root = BASE / ('r05-traversal-workload-' + workload + '-' + variant + '-20261026-v1')
            root.mkdir(mode=0o700)
            for name in ('obj', 'bin', 'home', 'tmp', 'cache', 'out'):
                (root / name).mkdir(mode=0o700)
            snapshot(root, binding, variant)
            configure(root, workload, variant)


if __name__ == '__main__':
    main()

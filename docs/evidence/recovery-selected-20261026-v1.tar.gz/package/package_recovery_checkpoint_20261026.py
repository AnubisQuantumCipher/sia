"""Package fixed recovery evidence; no build, execution, installation or release."""
import argparse
import gzip
import hashlib
import io
import json
from pathlib import Path
import shutil
import tarfile

BASE = Path(__file__).resolve().parent
ROOT = BASE / 'recovery-checkpoint-package-20261026-v1'
HARNESS = BASE / 'recovery-boundaries-harness-20261026-v10'
BUILD = BASE / 'recovery-boundaries-build-runtime-20261026-v10'
UNIT = BASE / 'recovery-roles-unit-20261025-v1'
ARCHIVE = 'recovery-selected-20261026-v1.tar.gz'
CHANGED = ('spark/sia_assurance.gpr', 'spark/src/sia_recovery_records.ads',
           'spark/src/sia_recovery_records.adb', 'spark/tests/continuity_frame_wire_tests.adb',
           'spark/tests/recovery_permit_wire_tests.adb')


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write('\n')


def add_run(roster, label, root, audit, unit=None):
    names = ('config.json', 'execution-source.json', 'source-binding.json',
             'execution-result.json', 'proof.stdout', 'proof.stderr',
             'proof_wrapper.py', 'proof_payload.py', audit, 'RESULT-INDEPENDENT-REVIEW.json')
    for name in names:
        roster[label + '/' + name] = root / name
    if unit is not None:
        for name in ('gnatprove.out', unit + '.spark'):
            roster[label + '/raw/' + name] = root / 'obj/gnatprove' / name


def roster():
    result = {}
    add_run(result, 'unit', UNIT, 'OWNER-PROOF-AUDIT.json', 'sia_recovery_records')
    add_run(result, 'harness', HARNESS, 'OWNER-PROOF-AUDIT.json', 'recovery_permit_wire_tests')
    add_run(result, 'build', BUILD, 'OWNER-AUDIT.json')
    audit = json.loads((BUILD / 'OWNER-AUDIT.json').read_text())
    for name in audit['evidence_sha256']:
        result['build/' + name] = BUILD / name
    result['build/build_driver.py'] = BUILD / 'build_driver.py'
    result['harness/PRIOR-UNIT-APPLICABILITY.json'] = HARNESS / 'PRIOR-UNIT-APPLICABILITY.json'
    for version in range(5, 10):
        prefix = 'recovery-boundaries-harness-' if version == 5 else 'recovery-boundaries-generation-diagnostic-'
        root = BASE / (prefix + '20261026-v' + str(version))
        audit = 'OWNER-PROOF-AUDIT.json' if version == 5 else 'OWNER-DIAGNOSTIC-AUDIT.json'
        add_run(result, 'failure-v' + str(version), root, audit, 'recovery_permit_wire_tests')
    result['package/package_recovery_checkpoint_20261026.py'] = Path(__file__).resolve()
    return result


def check_inputs(files):
    for root, name in ((UNIT, 'OWNER-PROOF-AUDIT.json'),
                       (HARNESS, 'OWNER-PROOF-AUDIT.json'), (BUILD, 'OWNER-AUDIT.json')):
        audit = json.loads((root / name).read_text())
        for relative, expected in audit['evidence_sha256'].items():
            if sha(root / relative) != expected:
                raise ValueError('audited evidence changed: ' + str(root / relative))
        review = json.loads((root / 'RESULT-INDEPENDENT-REVIEW.json').read_text())
        if review['owner_audit_sha256'] != sha(root / name):
            raise ValueError('review binding changed')
    for name, path in files.items():
        if path.is_symlink() or not path.is_file():
            raise ValueError('nonregular package input: ' + name)
    return {name: dict(sha256=sha(path), bytes=path.stat().st_size)
            for name, path in sorted(files.items())}


def archive_bytes(files):
    output = io.BytesIO()
    with gzip.GzipFile(fileobj=output, mode='wb', filename='', mtime=0) as zipped:
        with tarfile.open(fileobj=zipped, mode='w', format=tarfile.USTAR_FORMAT) as archive:
            for name, path in sorted(files.items()):
                data = path.read_bytes()
                info = tarfile.TarInfo(name)
                info.size, info.mode, info.mtime = len(data), 0o444, 0
                archive.addfile(info, io.BytesIO(data))
    return output.getvalue()


def source_rows():
    binding = json.loads((HARNESS / 'source-binding.json').read_text())
    rows = {}
    for name, row in binding['files'].items():
        source = HARNESS / 'source' / name
        if sha(source) != row['sha256']:
            raise ValueError('source snapshot changed: ' + name)
        rows[name] = dict(sha256=sha(source), bytes=source.stat().st_size)
    return rows


def manifest(files, data):
    return dict(status='SELECTED_RECOVERY_PROOF_CHECKPOINT_NOT_SYSTEM_ACCEPTANCE',
                base_commit='333d6552d419ba33d1759d70ad5033e4962b9420',
                archive=dict(path='docs/evidence/' + ARCHIVE, bytes=len(data),
                             sha256=hashlib.sha256(data).hexdigest()),
                members=check_inputs(files), source=source_rows(),
                changed_source=list(CHANGED),
                results={'unit': json.loads((UNIT / 'OWNER-PROOF-AUDIT.json').read_text())['counts'],
                         'harness': json.loads((HARNESS / 'OWNER-PROOF-AUDIT.json').read_text())['counts'],
                         'runtime': json.loads((BUILD / 'OWNER-AUDIT.json').read_text())['original_mains']},
                limits=['Selected unit/harness and original runtime roster only; not whole-project proof.',
                        'Independent readback is not independent execution.',
                        'Observer-loss custody remains UNKNOWN.',
                        'Earlier failed runs remain failures; limited diagnostics are not full harness runs.',
                        'Compaction, R05 BOTH, judge, installed, release and marketplace acceptance remain open.',
                        'Recorded wrapper configs refer to original local paths; not a standalone execution service.',
                        'All original mandatory gates, assertions, domains and controls remain binding.'])


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--check', action='store_true')
    args = parser.parse_args()
    files = roster()
    check_inputs(files)
    data = archive_bytes(files)
    expected = manifest(files, data)
    if args.check:
        if (ROOT / ARCHIVE).read_bytes() != data:
            raise ValueError('archive reproduction mismatch')
        if json.loads((ROOT / 'manifest.json').read_text()) != expected:
            raise ValueError('manifest reproduction mismatch')
    else:
        ROOT.mkdir(mode=0o700)
        (ROOT / ARCHIVE).write_bytes(data)
        save(ROOT / 'manifest.json', expected)
        for name in CHANGED:
            target = ROOT / 'candidate' / name
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(HARNESS / 'source' / name, target)
    print(json.dumps(dict(status='PACKAGE_CHECK_PASS' if args.check else 'PACKAGE_CREATED',
                          archive_sha256=expected['archive']['sha256'], members=len(files),
                          bytes=len(data), manifest_sha256=sha(ROOT / 'manifest.json'))))


if __name__ == '__main__':
    main()

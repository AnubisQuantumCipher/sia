"""Scoped CI repair reproduction; source sealed before each bounded command."""
from pathlib import Path
import datetime, hashlib, json, os, shutil, subprocess, time

ROOT = Path(__file__).resolve().parent
REPO = Path('/home/sicarii/Work/sia-assurance-kernel-20261019')
COMMIT = '081c855102b0c447e64dbed3056bb4aaf4b3ecf9'
RUFF = Path('/home/sicarii/Work/sia-assurance-evidence-20261019/assurance-analysis-tools-v1/venv/bin/ruff')
PRIOR = ROOT.parent/'acceptance-python-analysis-committed-reproduction-v1/run-v1/cases/ci-positive/inputs/ci-step.sh'
TARGET = 'tests/test_assurance_acceptance_manifest.py'
EXPECTED = 'b1c94222c4b2da580b405ac19d3bdd0931a4d86e20c0365238193c265bc72301'

def require(value, message):
    if not value:
        raise ValueError(message)

def read(path, limit=67108864):
    with path.open('rb') as stream:
        data = stream.read(limit+1)
    require(len(data)<=limit, 'byte budget: '+str(path))
    return data

def sha(path):
    return hashlib.sha256(read(path)).hexdigest()

def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())

def roster(directory):
    result = {}
    for count, (parent, directories, files) in enumerate(os.walk(directory)):
        require(count<1024 and len(result)+len(files)<=4096, 'inventory budget')
        for name in directories:
            require(not (Path(parent)/name).is_symlink(), 'directory symlink')
        for name in sorted(files):
            p = Path(parent)/name
            require(p.is_file() and not p.is_symlink(), 'source file type')
            result[str(p.relative_to(directory))] = sha(p)
    return result

def prepare():
    result = subprocess.run(['python3','/home/sicarii/.codex/skills/project-vault/scripts/storage_status.py'], capture_output=True, timeout=30, check=True)
    state = json.loads(result.stdout)
    require(any(ROOT.is_relative_to(Path(p)) for p in state['pins']), 'evidence not pinned')
    require(shutil.disk_usage(ROOT).free>=10000000000, 'reserve')
    save(ROOT/'storage.json', {k:state[k] for k in ('local_disk_bytes','configured_local_reserve_bytes','backup_service','ipad_availability')})
    a, b = roster(ROOT/'baseline'), roster(ROOT/'candidate')
    require(set(a)==set(b) and [p for p in a if a[p]!=b[p]]==[TARGET], 'overlay roster')
    require(b[TARGET]==EXPECTED and sha(REPO/TARGET)==EXPECTED, 'applied source mismatch')
    tree = subprocess.check_output(['git','ls-tree','-r','--full-tree',COMMIT],cwd=REPO,timeout=30).decode().splitlines()
    expected = {s.split('\t')[1]:s.split()[2] for s in tree}
    require(set(a)==set(expected), 'archive roster mismatch')
    for name in expected:
        raw=read(ROOT/'baseline'/name)
        require(hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==expected[name], 'Git blob mismatch')
    save(ROOT/'git-correspondence.json', expected)
    require(sha(RUFF)=='7ac5f222f6b5db43a5551f7d21c3245e6f71f7b17c4271504d656721bb8bce05', 'ruff identity')
    require(sha(PRIOR)=='d35d5dd03d96b08e7557751f81f219193b0a1037f3f72062dc7db160b09de647', 'CI block identity')
    (ROOT/'ci-step.sh').write_bytes(read(PRIOR))
    return a,b

def execute(name, source, command, expected, inputs):
    stage=ROOT/name; stage.mkdir(); (stage/'tmp').mkdir(); (stage/'output').mkdir()
    env={'PATH':str(RUFF.parent)+':/usr/bin:/bin','LANG':'C.UTF-8','LC_ALL':'C.UTF-8',
         'PYTHONPATH':str(source),'PYTHONWARNINGS':'error','PYTHONDONTWRITEBYTECODE':'1',
         'PYTHONNOUSERSITE':'1','RAYON_NUM_THREADS':'1','RUNNER_TEMP':str(stage/'output'),
         'TMPDIR':str(stage/'tmp'),'NO_COLOR':'1','PYTHON_COLORS':'0'}
    argv=['/usr/bin/timeout','--kill-after=5s','30s']+command
    save(stage/'input-seal.json',dict(source_commit=COMMIT,source=inputs,command=argv,environment=env,expected_exit=expected,runner=sha(Path(__file__))))
    start=time.monotonic()
    with (stage/'stdout').open('xb') as out, (stage/'stderr').open('xb') as err:
        result=subprocess.run(argv,cwd=source,env=env,stdout=out,stderr=err)
    stable=roster(source)==inputs
    receipt=dict(exit=result.returncode,expected_exit=expected,elapsed_seconds=time.monotonic()-start,sources_unchanged=stable,stdout_sha256=sha(stage/'stdout'),stderr_sha256=sha(stage/'stderr'))
    save(stage/'receipt.json',receipt)
    require(result.returncode==expected and stable, 'case failed: '+name)
    return receipt

def main():
    a,b=prepare()
    identities={str(p):sha(p.resolve()) for p in [Path('/usr/bin/python3'),Path('/usr/bin/timeout'),Path('/usr/bin/bash'),RUFF]}
    save(ROOT/'tool-identities-before.json',identities)
    unit=['/usr/bin/python3','-B','-m','unittest']
    guard='tests.test_sia.ProcessWideOsPatches'
    results={'baseline-guard':execute('baseline-guard',ROOT/'baseline',unit+[guard,'-v'],1,a)}
    err=read(ROOT/'baseline-guard/stderr',2097152).decode()
    require("('test_assurance_acceptance_manifest.py', 'os', 'open')" in err and 'FAILED (failures=1)' in err, 'baseline failure mismatch')
    args=unit+['tests.test_assurance_acceptance_manifest','tests.test_assurance_source_inventory',guard,'-v']
    results['candidate-tests']=execute('candidate-tests',ROOT/'candidate',args,0,b)
    err=read(ROOT/'candidate-tests/stderr',2097152).decode()
    require('Ran 32 tests in ' in err and err.endswith('\nOK\n') and 'skipped' not in err, 'test roster/result')
    results['candidate-static']=execute('candidate-static',ROOT/'candidate',['/usr/bin/bash',str(ROOT/'ci-step.sh')],0,b)
    require(read(ROOT/'candidate-static/stdout')==b'[]' and read(ROOT/'candidate-static/stderr')==b'', 'static diagnostics')
    after={p:sha(Path(p).resolve()) for p in identities}
    save(ROOT/'tool-identities-after.json',after); require(after==identities,'tool changed')
    save(ROOT/'receipt.json',dict(status='SCOPED_TEST_AND_STATIC_PASS',candidate_sha256=EXPECTED,base_commit=COMMIT,checks=results,tools_unchanged=True,full_suite='UNRUN locally; remote1292 failed retained; laterCI required',assurance='No proof or system acceptance claim'))
    print('SCOPED_TEST_AND_STATIC_PASS',flush=True)

if __name__=='__main__':
    try:
        main()
    except Exception as error:
        save(ROOT/'failure.json',{'type':type(error).__name__,'message':str(error)})
        raise

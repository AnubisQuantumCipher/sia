"""Disposable one-child wait4 observer, outside the adapter's resource domain."""
import json
import os
from pathlib import Path
import sys


def main():
    if len(sys.argv) < 4 or sys.argv[2] != '/usr/bin/prlimit':
        raise ValueError('fixed prlimit workload required')
    output = Path(sys.argv[1])
    pid = os.posix_spawn(sys.argv[2], sys.argv[2:], dict(os.environ))
    observed, status, usage = os.wait4(pid, 0)
    if observed != pid:
        raise RuntimeError('child identity mismatch')
    exit_code = os.waitstatus_to_exitcode(status)
    value = {'pid': pid, 'wait_status': status, 'exit_code': exit_code,
             'max_rss_kib_linux': usage.ru_maxrss,
             'user_cpu_seconds': usage.ru_utime, 'system_cpu_seconds': usage.ru_stime,
             'major_faults': usage.ru_majflt, 'minor_faults': usage.ru_minflt,
             'scope': 'Observed child peak; not a worst-case bound'}
    with output.open('x') as stream:
        stream.write(json.dumps(value, sort_keys=True) + '\n')
    return exit_code if exit_code >= 0 else 74


if __name__ == '__main__':
    sys.exit(main())

#!/usr/bin/env python3
"""Fresh bounded I/O qualification diagnostic. No proof or installed claim."""
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import sys

EVIDENCE = Path('/home/sicarii/Work/sia-assurance-evidence-20261019')
DRIVER = EVIDENCE / 'run-continuity-observation-wire-development-v2.py'
STORAGE = EVIDENCE / 'run-continuity-response-wire-development-v1.py'
CHANGED = ('spark/transport/continuity_probe.gpr',
           'spark/transport/ada/continuity_probe.adb',
           'spark/transport/continuity_process.py',
           'spark/transport/CONTINUITY-IO.md',
           'spark/tests/test_continuity_process.py')


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def stack_reports(source, output):
    paths = sorted((source / 'spark/obj/continuity-probe').glob('*.su'))
    if not paths or len(paths) > 64:
        raise RuntimeError('missing or excessive stack report roster')
    reports = {}
    saved = output / 'compiler-stack'
    saved.mkdir()
    for path in paths:
        rows = path.read_text().splitlines()
        for row in rows:
            _, amount, kind = row.rsplit('\t', 2)
            if not amount.isdecimal() or kind not in ('static', 'dynamic,bounded'):
                raise RuntimeError('unbounded or malformed compiler stack row')
        shutil.copyfile(path, saved / path.name)
        reports[path.name] = {'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
                              'rows': rows}
    return reports


def main():
    if len(sys.argv) != 2 or not sys.argv[1].startswith('continuity-io-development-v'):
        raise ValueError('new bounded diagnostic name required')
    output = EVIDENCE / sys.argv[1]
    if output.parent != EVIDENCE:
        raise ValueError('invalid destination')
    output.mkdir()
    base = load(DRIVER, 'base')
    storage = load(STORAGE, 'storage')
    storage.storage(output, 'storage-preflight.json')
    base.CHANGED = CHANGED
    receipt = base.snapshot(output)
    receipt['scope'] = 'DIAGNOSTIC ONLY: no I/O proof, protected authority or installed restoration'
    for path in (Path(__file__), DRIVER, STORAGE):
        shutil.copyfile(path, output / path.name)
    source = Path(receipt['cwd'])
    receipt['source_files'] = {str(p.relative_to(source)): storage.digest(p)
                               for p in sorted((source / 'spark').rglob('*')) if p.is_file()}
    passed = base.check(output, receipt, 'strict-probe-build', '120s',
                        ['gprbuild', '-p', '-P', 'spark/transport/continuity_probe.gpr'])
    if passed:
        receipt['compiler_stack'] = stack_reports(source, output)
        receipt['binary_sha256'] = storage.digest(source / 'spark/bin/continuity_probe')
        passed = base.check(output, receipt, 'continuity-io-tests', '30s',
                            ['python3', '-B', '-W', 'error::ResourceWarning',
                             '-m', 'unittest', 'discover', '-s', 'spark/tests',
                             '-p', 'test_continuity_process.py', '-v'])
    receipt['tools_after'] = base.proof_tools()
    receipt['tools_unchanged'] = receipt['tools_after'] == receipt['proof_tools_before']
    receipt['passed'] = passed and receipt['tools_unchanged']
    receipt['full_project_acceptance'] = 'OPEN, no unchanged proof rerun'
    (output / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    storage.storage(output, 'storage-after.json')
    return 0 if receipt['passed'] else 1


if __name__ == '__main__':
    sys.exit(main())

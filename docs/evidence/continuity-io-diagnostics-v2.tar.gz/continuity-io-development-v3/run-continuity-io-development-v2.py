#!/usr/bin/env python3
"""I/O diagnostic plus the original transport and all pure runtime controls."""
import json
from pathlib import Path
import shutil
import sys

EVIDENCE = Path('/home/sicarii/Work/sia-assurance-evidence-20261019')
sys.path.insert(0, str(EVIDENCE))
import importlib.util


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main():
    if len(sys.argv) != 2 or not sys.argv[1].startswith('continuity-io-development-v'):
        raise ValueError('new bounded diagnostic name required')
    output = EVIDENCE / sys.argv[1]
    if output.parent != EVIDENCE:
        raise ValueError('invalid output directory')
    output.mkdir()
    prior = load(EVIDENCE / 'run-continuity-io-development-v1.py', 'prior')
    base = load(prior.DRIVER, 'base')
    storage = load(prior.STORAGE, 'storage')
    runtime = load(EVIDENCE / 'run-continuity-response-wire-development-v1.py', 'runtime')
    storage.storage(output, 'storage-preflight.json')
    base.CHANGED = prior.CHANGED
    receipt = base.snapshot(output)
    receipt['scope'] = 'DIAGNOSTIC: bounded I/O and regressions; no new proof or authority'
    dependencies = (Path(__file__), Path(prior.__file__), prior.DRIVER, prior.STORAGE)
    receipt['runner_dependencies'] = {str(path): storage.digest(path) for path in dependencies}
    for path in dependencies:
        shutil.copyfile(path, output / path.name)
    source = Path(receipt['cwd'])
    receipt['source_files'] = {str(path.relative_to(source)): storage.digest(path)
                               for path in sorted((source / 'spark').rglob('*')) if path.is_file()}
    plan = [('strict-probe-build', '120s',
             ['gprbuild', '-p', '-P', 'spark/transport/continuity_probe.gpr']),
            ('continuity-io-tests', '30s',
             ['python3', '-B', '-W', 'error::ResourceWarning', '-m', 'unittest',
              'discover', '-s', 'spark/tests', '-p', 'test_continuity_process.py', '-v']),
            ('original-transport-build', '120s',
             ['gprbuild', '-p', '-P', 'spark/transport/request_probe.gpr']),
            ('all-transport-support-tests', '30s',
             ['python3', '-B', '-W', 'error::ResourceWarning', '-m', 'unittest',
              'discover', '-s', 'spark/tests', '-p', 'test_*.py', '-v']),
            ('strict-policy-build', '120s', ['gprbuild', '-p', '-P', 'spark/sia_assurance.gpr'])]
    plan.extend((name + '-runtime', '30s', ['spark/bin/' + name + '_tests'])
                for name in runtime.RUNTIMES)
    passed = True
    for name, duration, command in plan:
        if not base.check(output, receipt, name, duration, command):
            passed = False
            break
        if name == 'strict-probe-build':
            receipt['compiler_stack'] = prior.stack_reports(source, output)
            receipt['binary_sha256'] = storage.digest(source / 'spark/bin/continuity_probe')
    receipt['proof_tools_after'] = base.proof_tools()
    receipt['tools_unchanged'] = receipt['proof_tools_before'] == receipt['proof_tools_after']
    receipt['passed'] = passed and receipt['tools_unchanged']
    receipt['full_project_acceptance'] = 'OPEN: no unchanged failed proofs rerun'
    (output / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    storage.storage(output, 'storage-after.json')
    return 0 if receipt['passed'] else 1


if __name__ == '__main__':
    sys.exit(main())

#!/usr/bin/env python3
"""Isolated fixed response codec diagnostics; not whole-project acceptance."""
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess
import sys

EVIDENCE = Path('/home/sicarii/Work/sia-assurance-evidence-20261019')
DRIVER = EVIDENCE / 'run-continuity-observation-wire-development-v2.py'
CHANGED = (
    'spark/sia_assurance.gpr', 'spark/verify-policy.sh',
    'spark/src/sia_continuity_response_wire.ads',
    'spark/src/sia_continuity_response_wire.adb',
    'spark/tests/continuity_response_wire_tests.adb',
)
RUNTIMES = (
    'policy', 'transaction', 'request_wire', 'request_admission',
    'grant_lifetime', 'retraction', 'consolidation', 'continuity',
    'continuity_transition', 'continuity_record_wire',
    'continuity_observation_wire', 'continuity_checkpoint_wire', 'continuity_current_wire', 'continuity_frame_wire', 'continuity_response_wire',
)


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def storage(output, name):
    status = subprocess.run(
        ['python3', '/home/sicarii/.codex/skills/project-vault/scripts/storage_status.py'],
        capture_output=True, check=True, timeout=20)
    (output / name).write_bytes(status.stdout)
    value = json.loads(status.stdout)
    if value['local_disk_bytes']['free'] < value['configured_local_reserve_bytes'] + 1_000_000_000:
        raise RuntimeError('insufficient bounded-build capacity')
    if str(EVIDENCE) not in value['pins']:
        raise RuntimeError('evidence parent not pinned')


def retain_raw(output, receipt, name):
    raw = Path(receipt['cwd']) / 'spark/obj/gnatprove'
    saved = output / (name + '-raw')
    saved.mkdir()
    products = {}
    # These compiler/prover products are untrusted diagnostic evidence.
    # Retain every top-level SPARK report, including dependency reports.
    candidates = list(raw.glob('*.spark')) + [raw / 'gnatprove.out']
    if len(candidates) > 256:
        raise RuntimeError('proof report count exceeds declared bound')
    total = 0
    for path in candidates:
        if not path.exists():
            continue
        if path.is_symlink() or not path.is_file():
            raise RuntimeError('unexpected proof product type')
        total += path.stat().st_size
        if total > 64 * 1024 * 1024:
            raise RuntimeError('proof reports exceed declared byte bound')
        shutil.copyfile(path, saved / path.name)
        products[path.name] = digest(saved / path.name)
    receipt.setdefault('retained_raw', {})[name] = products


def make_plan():
    plan = [('build', '120s', ['gprbuild', '-p', '-P', 'spark/sia_assurance.gpr'])]
    for name in RUNTIMES:
        plan.append((name.replace('_', '-') + '-tests', '30s',
                     ['spark/bin/' + name + '_tests']))
    for name, unit in (
            ('core-proof', 'sia_continuity_response_wire.adb'),
            ('harness-proof', 'continuity_response_wire_tests.adb')):
        plan.append((name, '120s', ['gnatprove', '-P', 'spark/sia_assurance.gpr',
                     '-u', unit, '--mode=all', '--assumptions', '--no-inlining',
                     '--memlimit=512', '--timeout=10']))
    return plan


def main():
    if len(sys.argv) != 2 or not sys.argv[1].startswith('continuity-response-wire-development-v'):
        raise ValueError('expected new checkpoint development directory name')
    output = EVIDENCE / sys.argv[1]
    if output.parent != EVIDENCE:
        raise ValueError('invalid output name')
    output.mkdir()
    storage(output, 'storage-preflight.json')
    spec = importlib.util.spec_from_file_location('retained_driver', DRIVER)
    driver = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(driver)
    driver.CHANGED = CHANGED
    receipt = driver.snapshot(output)
    receipt['scope'] = 'DIAGNOSTIC_ONLY: fixed response codec and harness; no full-project or runtime integration claim'
    receipt['runner_dependencies'] = {str(p): digest(p) for p in (Path(__file__), DRIVER)}
    for path in (Path(__file__), DRIVER):
        shutil.copyfile(path, output / path.name)
    source = Path(receipt['cwd'])
    receipt['source_files'] = {str(p.relative_to(source)): digest(p)
                               for p in sorted((source / 'spark').rglob('*')) if p.is_file()}
    passed = True
    for name, duration, command in make_plan():
        passed = driver.check(output, receipt, name, duration, command)
        if name.endswith('-proof'):
            retain_raw(output, receipt, name)
        (output / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
        if not passed:
            break
    receipt['proof_tools_after'] = driver.proof_tools()
    receipt['tools_unchanged'] = receipt['proof_tools_before'] == receipt['proof_tools_after']
    receipt['diagnostic_commands_passed'] = passed
    receipt['full_project_acceptance'] = 'UNRUN for this candidate'
    (output / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    storage(output, 'storage-after.json')
    return 0 if passed and receipt['tools_unchanged'] else 1


if __name__ == '__main__':
    sys.exit(main())

"""Retain bounded I/O diagnostics and failures; never whole-system acceptance."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import subprocess
import sys
import tarfile

ROOT = Path(__file__).parent
REPO = Path('/home/sicarii/Work/sia-assurance-kernel-20261019')
RUN = ROOT / 'continuity-io-development-v3'
WITNESS = ROOT / 'continuity-io-resource-witness-v3'
DEST = REPO / 'docs/CONTINUITY-IO-EVIDENCE-20261021-V2.json'
BUNDLE = REPO / 'docs/evidence/continuity-io-diagnostics-v2.tar.gz'


def read(path):
    with path.open('rb') as stream:
        value = stream.read(4_194_305)
    if len(value) > 4_194_304:
        raise ValueError('evidence input byte cap')
    return value


def sha(path):
    return hashlib.sha256(read(path)).hexdigest()


def validate_source_roster(receipt):
    names = subprocess.check_output(['git', 'ls-tree', '-r', '--name-only',
              receipt['base'], '--', 'spark'], cwd=REPO, timeout=10).decode().splitlines()
    if set(receipt['source_files']) != set(names) | set(receipt['files']):
        raise ValueError('source inventory incomplete')
    archive = subprocess.check_output(['git', 'archive', receipt['base'], 'spark'],
                                      cwd=REPO, timeout=30)
    if hashlib.sha256(archive).hexdigest() != sha(RUN / 'base.tar'):
        raise ValueError('base archive mismatch')


def validate_commands(receipt):
    commands = {
        'strict-probe-build': ['gprbuild', '-p', '-P', 'spark/transport/continuity_probe.gpr'],
        'original-transport-build': ['gprbuild', '-p', '-P', 'spark/transport/request_probe.gpr'],
        'strict-policy-build': ['gprbuild', '-p', '-P', 'spark/sia_assurance.gpr']}
    test = ['python3', '-B', '-W', 'error::ResourceWarning', '-m', 'unittest',
            'discover', '-s', 'spark/tests', '-p']
    commands['continuity-io-tests'] = test + ['test_continuity_process.py', '-v']
    commands['all-transport-support-tests'] = test + ['test_*.py', '-v']
    for entry in receipt['checks']:
        name = entry['name']
        command = commands.get(name)
        if command is None and name.endswith('-runtime'):
            command = ['spark/bin/' + name.removesuffix('-runtime') + '_tests']
        duration = '120s' if name.endswith('build') else '30s'
        if command is None or entry['command'] != ['timeout', '--kill-after=5s', duration, *command]:
            raise ValueError('exact command mismatch')


def validate(receipt):
    if receipt['base'] != '9d30f73168c34fbad97943217e7bfde892c6cf59':
        raise ValueError('unexpected diagnostic baseline')
    validate_source_roster(receipt)
    validate_commands(receipt)
    names = ['strict-probe-build', 'continuity-io-tests', 'original-transport-build',
             'all-transport-support-tests', 'strict-policy-build', 'policy-runtime',
             'transaction-runtime', 'request_wire-runtime', 'request_admission-runtime',
             'grant_lifetime-runtime', 'retraction-runtime', 'consolidation-runtime',
             'continuity-runtime', 'continuity_transition-runtime',
             'continuity_record_wire-runtime', 'continuity_observation_wire-runtime',
             'continuity_checkpoint_wire-runtime', 'continuity_current_wire-runtime',
             'continuity_frame_wire-runtime', 'continuity_response_wire-runtime']
    if [entry['name'] for entry in receipt['checks']] != names or not receipt['passed']:
        raise ValueError('missing or failed original control')
    for entry in receipt['checks']:
        duration = '120s' if entry['name'].endswith('build') else '30s'
        if entry['exit'] != 0 or entry['command'][:3] != ['timeout', '--kill-after=5s', duration]:
            raise ValueError('command result or cap mismatch')
    if (len(receipt['proof_tools_before']) != 10 or not receipt['tools_unchanged']
            or receipt['proof_tools_before'] != receipt['proof_tools_after']):
        raise ValueError('tool identity mismatch')
    for name, expected in receipt['source_files'].items():
        if sha(RUN / 'source' / name) != expected or sha(REPO / name) != expected:
            raise ValueError('source mismatch: ' + name)
    for name, expected in receipt['runner_dependencies'].items():
        if sha(RUN / Path(name).name) != expected:
            raise ValueError('retained runner changed')
    if sha(RUN / 'source/spark/bin/continuity_probe') != receipt['binary_sha256']:
        raise ValueError('compiled binary mismatch')
    for name, row in receipt['compiler_stack'].items():
        if sha(RUN / 'compiler-stack' / name) != row['sha256']:
            raise ValueError('compiler stack report mismatch')


def validate_witness(receipt):
    value = json.loads(read(WITNESS / 'receipt.json'))
    if value['source_receipt_sha256'] != sha(RUN / 'receipt.json'):
        raise ValueError('resource witness source mismatch')
    for label in ('restore', 'transition'):
        result = value[label]
        if (result['terminal_exit'] != 0
                or result['binary_sha256'] != receipt['binary_sha256']
                or result['usage_sha256'] != sha(WITNESS / (label + '-usage.log'))):
            raise ValueError('resource witness mismatch')
    for path, expected in value['tools_sha256'].items():
        if sha(Path(path)) != expected:
            raise ValueError('resource tool mismatch')
    return value


def pure_source_bindings(receipt):
    values = {}
    for name, expected in receipt['source_files'].items():
        if not name.startswith('spark/src/'):
            continue
        raw = subprocess.check_output(['git', 'show',
            '74efd05673719ce5a740d83510c652c5a956c930:' + name], cwd=REPO, timeout=10)
        if hashlib.sha256(raw).hexdigest() != expected:
            raise ValueError('pure source changed relative to prior scoped evidence')
        values[name] = expected
    return values


def bundle_paths():
    paths = [Path(__file__), ROOT / 'continuity-io-source-review-v3.txt',
             ROOT / 'continuity-io-source-review-v4.txt',
             ROOT / 'continuity-io-source-inventory-v3.json',
             ROOT / 'continuity-io-resource-witness-v3.py',
             ROOT / 'continuity-resource-observer-v1.py']
    receipt = json.loads(read(RUN / 'receipt.json'))
    paths += [RUN / 'receipt.json', RUN / 'base.tar']
    paths += [RUN / (entry['name'] + '.log') for entry in receipt['checks']]
    paths += [RUN / 'source' / name for name in receipt['files']]
    paths += list((RUN / 'compiler-stack').glob('*.su'))
    paths += list(RUN.glob('run-*.py'))
    paths += list(WITNESS.glob('*.log')) + [WITNESS / 'receipt.json']
    return sorted(set(paths))


def package(paths):
    if len(paths) > 128:
        raise ValueError('artifact count cap')
    payload, artifacts, total = io.BytesIO(), [], 0
    with gzip.GzipFile(fileobj=payload, mode='wb', mtime=0) as zipped:
        with tarfile.open(fileobj=zipped, mode='w|', format=tarfile.USTAR_FORMAT) as archive:
            for path in paths:
                raw = read(path)
                total += len(raw)
                if total > 16 * 1024 * 1024:
                    raise ValueError('aggregate artifact cap')
                name = str(path.relative_to(ROOT))
                info = tarfile.TarInfo(name)
                info.size, info.mode = len(raw), path.stat().st_mode & 0o777
                archive.addfile(info, io.BytesIO(raw))
                artifacts.append({'path': name, 'sha256': hashlib.sha256(raw).hexdigest()})
    return payload.getvalue(), artifacts


def main():
    if sys.argv[1:] not in ([], ['--check']):
        raise ValueError('optional --check only')
    receipt = json.loads(read(RUN / 'receipt.json'))
    validate(receipt)
    witness = validate_witness(receipt)
    unchanged = pure_source_bindings(receipt)
    bundle, artifacts = package(bundle_paths())
    value = {'kind': 'TESTED disposable I/O, not installed or whole-system acceptance',
             'receipt': receipt, 'resource_witness': witness,
             'prior_evidence': {name: sha(REPO / name) for name in (
                 'docs/CONTINUITY-IO-EVIDENCE-20261021.json',
                 'docs/evidence/continuity-io-diagnostics-v1.tar.gz')},
             'pure_sources_unchanged_from': '74efd05673719ce5a740d83510c652c5a956c930',
             'unchanged_pure_sources': unchanged, 'artifacts': artifacts,
             'bundle': {'path': str(BUNDLE.relative_to(REPO)),
                        'sha256': hashlib.sha256(bundle).hexdigest()},
             'limits': ['No new proof; complete harness/full-project proofs remain incomplete.',
                        'V1 passing tests did not establish safe cleanup; review failures retained.',
                        'Resource witnesses cover two target workloads, not worst-case memory or timing.',
                        'Single owner/no external reapers; no hostile-process or generic descendant guarantee.',
                        'No authenticated evidence, installed hooks, universal recall or certification.']}
    raw = (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()
    if sys.argv[1:] == ['--check']:
        if read(DEST) != raw or read(BUNDLE) != bundle:
            raise ValueError('retained evidence mismatch')
    else:
        BUNDLE.write_bytes(bundle) if not BUNDLE.exists() else sys.exit('bundle exists')
        with DEST.open('xb') as stream:
            stream.write(raw)
    print('I/O diagnostics retained and exact source bindings checked')


if __name__ == '__main__':
    main()

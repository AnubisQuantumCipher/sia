"""Bounded target workload observations, not stack/WCET or sandbox proof."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path('/home/sicarii/Work/sia-assurance-evidence-20261019')
RUN = ROOT / 'continuity-io-development-v3'
SOURCE = RUN / 'source'
OUT = ROOT / 'continuity-io-resource-witness-v3'
OBSERVER = ROOT / 'continuity-resource-observer-v1.py'


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    sys.modules[name] = value
    spec.loader.exec_module(value)
    return value


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def witness(fixture, operation, code, label):
    process = fixture.process
    binary = SOURCE / 'spark/bin/continuity_probe'
    payload = fixture.restore_vector() if operation == 1 else fixture.transition_vector()
    identity = sha(binary)
    descriptor = process.pin_executable(binary, identity)
    command = [sys.executable, '-I', str(OBSERVER), str(OUT / (label + '-usage.log')),
               *process.command(descriptor)]
    try:
        child = subprocess.Popen(command, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                 stderr=subprocess.PIPE, pass_fds=(descriptor,),
                                 restore_signals=False, start_new_session=True,
                                 cwd='/', env={'PATH': '/usr/bin:/bin', 'LC_ALL': 'C'})
        try:
            output, error, status = process.exchange(child, payload, 5)
        finally:
            try:
                process.stop_and_reap(child)
            finally:
                process.close_pipes(child)
    finally:
        os.close(descriptor)
    if (status != child.returncode or status != 0 or error
            or output != fixture.response(operation, code)):
        raise RuntimeError('target observation failed')
    usage = json.loads((OUT / (label + '-usage.log')).read_text())
    if usage['exit_code'] != 0 or usage['max_rss_kib_linux'] <= 0:
        raise RuntimeError('missing terminal resource observation')
    return {'command': command, 'input_sha256': hashlib.sha256(payload).hexdigest(),
            'binary_sha256': identity, 'response_sha256': hashlib.sha256(output).hexdigest(),
            'terminal_exit': status, 'usage_sha256': sha(OUT / (label + '-usage.log'))}


def main():
    OUT.mkdir()
    fixture = load(SOURCE / 'spark/tests/test_continuity_process.py', 'fixture')
    receipt = json.loads((RUN / 'receipt.json').read_text())
    if sha(SOURCE / 'spark/bin/continuity_probe') != receipt['binary_sha256']:
        raise ValueError('qualified binary identity mismatch')
    value = {'scope': 'Two bounded positive target workloads; no worst-case guarantee',
             'source_receipt_sha256': sha(RUN / 'receipt.json'),
             'tools_sha256': {path: sha(path) for path in
                              ('/usr/bin/prlimit', sys.executable, str(OBSERVER))},
             'runner_sha256': sha(__file__),
             'restore': witness(fixture, 1, 7, 'restore'),
             'transition': witness(fixture, 2, 9, 'transition')}
    (OUT / 'receipt.json').write_text(json.dumps(value, indent=2) + '\n')
    print('bounded target workloads observed; no general stack/WCET guarantee')


if __name__ == '__main__':
    main()

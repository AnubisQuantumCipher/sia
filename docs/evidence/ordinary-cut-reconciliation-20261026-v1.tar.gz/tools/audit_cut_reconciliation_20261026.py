"""Audit one interrupted-fixture retirement; no successor admission."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent / 'ordinary-cut-reconciliation-20261026-v2'


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def read(name):
    return json.loads((ROOT / name).read_text())


def check(condition, message):
    if not condition:
        raise ValueError(message)


def validate_sources():
    for source in (read('source.json'), read('TEST-RESULT.json')['source']):
        for name, expected in source.items():
            check(sha(ROOT / name) == expected, 'source changed: ' + name)
    test = read('TEST-RESULT.json')
    check(test['status'] == 'PASS' and test['tests'] == 54 and
          test['failures'] == test['errors'] == test['skipped'] == 0, 'test result')
    raw = (ROOT / 'tests.stderr').read_text()
    check(raw.count(' ... ok\n') == 54 and raw.endswith('Ran 54 tests in 0.180s\n\nOK\n'), 'raw tests')
    static = read('STATIC-v1.json')
    check(static['exit'] == 0 and json.loads(static['stdout']) == [] and
          not static['stderr'] and not static['functions_over_60'], 'static checks')


def validate_ledger(decision, result, post):
    check(post['status'] == 'EXACT_INTERRUPTED_FIXTURE_READBACK' and post['pending_absent'] is True and
          post['directory'] == decision['ledger_identity'], 'ledger readback')
    previous = {key: value for key, value in decision['ledger_before'].items() if key != 'pending.json'}
    expected = dict(previous)
    expected[result['retired_name']] = decision['pending_sha256']
    encoded = (json.dumps(decision, indent=2, sort_keys=True) + '\n').encode()
    expected[result['decision_name']] = hashlib.sha256(encoded).hexdigest()
    check(set(post['rows']) == set(expected), 'closed post ledger roster')
    for name, digest in expected.items():
        row = post['rows'][name]
        mode = 33060 if name == 'epoch' else 33152
        check(row['sha256'] == digest and row['identity'][2:] == [mode, 0, 0, 1], 'ledger record')
    retired = post['rows'][result['retired_name']]
    check(retired['identity'] == decision['pending_identity'] and
          retired['sha256'] == result['pending_sha256'], 'original pending identity or bytes')


def main():
    validate_sources()
    outer, result, post, note = (read(name) for name in
                               ('outer-result.json', 'outer.stdout', 'readback.stdout', 'TOOL-EXIT-OBSERVATION.json'))
    check(outer['actual_exit'] == note['invocation']['exit_code'] == note['readback']['exit_code'] == 0 and
          outer['manifest_sha256'] == sha(ROOT / 'source.json') and
          outer['wrapper_sha256'] == sha(ROOT / 'reconcile.py') and
          outer['stdout_sha256'] == sha(ROOT / 'outer.stdout'), 'actual acknowledgment')
    check(result['status'] == 'EXACT_PRE_ADMISSION_CUT_RECONCILED' and result['authority'] == 'NONE' and
          result['successor_admitted'] is False and result['replay_authorized'] is False, 'result scope')
    decision = read('decision.json')
    validate_ledger(decision, result, post)
    record = dict(status='EXACT_INTERRUPTED_FIXTURE_RECONCILIATION_PASS', authority='NONE',
                  source_manifest=sha(ROOT / 'source.json'), component_tests=54,
                  evidence_sha256={p.name: sha(p) for p in sorted(ROOT.iterdir()) if p.is_file()},
                  limits=['One exact pre-admission interrupted fixture only; no replay or successor authority',
                          'Previous history checked by bytes/metadata; original pending inode pinned',
                          'Ordinary nonhostile root/host; unsigned observations; no hardware crash proof',
                          'Whole custody, native C14, repeated compaction, R05 BOTH, judge and release remain open'])
    with (ROOT / 'OWNER-AUDIT.json').open('x') as stream:
        json.dump(record, stream, indent=2, sort_keys=True)
        stream.write('\n')
    print(json.dumps(dict(status=record['status'], source=record['source_manifest'])))


if __name__ == '__main__':
    main()

"""Unprivileged storage controls only; no root main or workload launch."""
import datetime
import fcntl
import hashlib
import importlib
import json
import os
from pathlib import Path
import resource
import shutil
import sys
import unittest

ROOT = Path(__file__).resolve().parent
LOCK = Path('/home/sicarii/.worldline-heavy.lock')
FIELDS = ('st_dev', 'st_ino', 'st_mode', 'st_uid', 'st_gid', 'st_nlink')


def identity(value):
    return [getattr(value, name) for name in FIELDS]


def main():
    if os.getresuid() != (1000, 1000, 1000):
        raise ValueError('UID1000 test runner required')
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
    hashes = {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest()
              for name in ('candidate.py', 'reconcile.py', 'test_reconcile.py', 'run_tests.py',
                           'normal_reconcile.py', 'test_normal.py', 'invoke.py', 'readback.py')}
    with LOCK.open('rb') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        meta = identity(os.fstat(lock.fileno()))
        if meta != [64768, 457925, 33188, 1000, 1000, 1] or meta != identity(LOCK.lstat()):
            raise ValueError('heavy lock changed')
        free = shutil.disk_usage(ROOT).free
        if free < 10000000000:
            raise ValueError('physical working-space reserve reached')
        sys.path.insert(0, str(ROOT))
        suite = unittest.TestSuite([
            unittest.defaultTestLoader.loadTestsFromModule(importlib.import_module(name))
            for name in ('test_normal', 'test_reconcile')])
        with (ROOT / 'tests.stderr').open('x') as stream:
            result = unittest.TextTestRunner(stream=stream, verbosity=2).run(suite)
            stream.flush()
            os.fsync(stream.fileno())
        for name, expected in hashes.items():
            if hashlib.sha256((ROOT / name).read_bytes()).hexdigest() != expected:
                raise ValueError('test source changed')
        record = dict(status='PASS' if result.wasSuccessful() else 'FAIL', authority='NONE',
                      tests=result.testsRun, failures=len(result.failures), errors=len(result.errors),
                      skipped=len(result.skipped), source=hashes, lock=meta, free_bytes=free,
                      utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                      scope='UID1000_DISPOSABLE_STORAGE_AND_MOCKED_ADMISSION_ONLY')
        with (ROOT / 'TEST-RESULT.json').open('x') as stream:
            json.dump(record, stream, indent=2)
            stream.write('\n')
            stream.flush()
            os.fsync(stream.fileno())
    print(json.dumps(record), flush=True)
    if not result.wasSuccessful():
        raise SystemExit(1)


if __name__ == '__main__':
    main()

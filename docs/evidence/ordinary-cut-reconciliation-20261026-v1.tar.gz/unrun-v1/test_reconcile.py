"""Disposable storage failure cuts; not actual observer-death qualification."""
import errno
import hashlib
import json
import os
from pathlib import Path
import stat
import tempfile
import unittest
from unittest import mock

import candidate
import reconcile


class ManualReconciliation(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        self.root = Path(temporary.name)
        self.pending = self.root / 'pending.json'
        self.data = b'{"disposable_fixture":"known-normal-case"}\n'
        self.pending.write_bytes(self.data)
        self.pending.chmod(0o600)
        epoch = self.root / 'epoch'
        epoch.write_bytes(b'0' * 64 + b'\n')
        epoch.chmod(0o444)
        self.ledger = dict(identity=candidate.metadata(self.root.stat()),
                           epoch_sha256=hashlib.sha256(epoch.read_bytes()).hexdigest())
        self.decision = dict(scope='DISPOSABLE_STORAGE_TEST_ONLY', authority='NONE')
        for module, name, value in ((candidate, 'LEDGER', self.root),
                                   (reconcile, 'PENDING_SHA', hashlib.sha256(self.data).hexdigest())):
            patcher = mock.patch.object(module, name, value)
            patcher.start()
            self.addCleanup(patcher.stop)
        patcher = mock.patch.object(candidate, 'ledger_ancestry')
        patcher.start()
        self.addCleanup(patcher.stop)

    def run_reconciliation(self):
        return reconcile.reconcile_once(candidate, self.ledger, self.decision)

    def refusal(self):
        with self.assertRaises(RuntimeError) as caught:
            self.run_reconciliation()
        value = json.loads(str(caught.exception))
        self.assertEqual(value['status'], 'UNKNOWN_NO_RETRY_OR_ROLLBACK')
        return value['errors']

    def test_normal_preserves_bytes_inode_and_decision_without_replay_authority(self):
        old = self.pending.stat()
        result = self.run_reconciliation()
        retired = self.root / reconcile.RETIRED
        self.assertFalse(self.pending.exists())
        self.assertEqual(retired.read_bytes(), self.data)
        self.assertEqual((retired.stat().st_dev, retired.stat().st_ino), (old.st_dev, old.st_ino))
        self.assertEqual(retired.stat().st_nlink, 1)
        self.assertEqual(json.loads((self.root / reconcile.DECISION).read_text()), self.decision)
        self.assertFalse(result['successor_admitted'])
        self.assertFalse(result['replay_authorized'])

    def test_existing_decision_or_retired_name_never_unlinks_pending(self):
        for name in (reconcile.DECISION, reconcile.RETIRED):
            with self.subTest(name=name):
                path = self.root / name
                path.write_bytes(b'keep-existing')
                self.refusal()
                self.assertEqual(self.pending.read_bytes(), self.data)
                self.assertEqual(path.read_bytes(), b'keep-existing')
                path.unlink()
                decision = self.root / reconcile.DECISION
                if decision.exists():
                    decision.unlink()  # Disposable setup only; production has no rollback.

    def test_wrong_pending_hash_has_no_decision_or_link(self):
        with mock.patch.object(reconcile, 'PENDING_SHA', 'f' * 64):
            self.assertEqual(self.refusal()[0]['stage'], 'validate-pending')
        self.assertFalse((self.root / reconcile.DECISION).exists())
        self.assertFalse((self.root / reconcile.RETIRED).exists())
        self.assertEqual(self.pending.read_bytes(), self.data)

    def test_symlink_pending_does_not_follow_or_remove_target(self):
        target = self.root / 'target'
        self.pending.rename(target)
        self.pending.symlink_to(target)
        self.assertEqual(self.refusal()[0]['stage'], 'open-pending')
        self.assertEqual(target.read_bytes(), self.data)
        self.assertTrue(self.pending.is_symlink())

    def test_decision_short_write_never_links_or_unlinks(self):
        with mock.patch.object(candidate.os, 'write', return_value=0), \
                mock.patch.object(reconcile.os, 'link') as link, \
                mock.patch.object(reconcile.os, 'unlink') as unlink:
            errors = self.refusal()
        self.assertEqual(errors[0]['stage'], 'durable-decision')
        link.assert_not_called()
        unlink.assert_not_called()
        self.assertEqual(self.pending.read_bytes(), self.data)

    def test_decision_file_and_directory_sync_failures_leave_pending(self):
        sync = os.fsync
        for wanted in ('file', 'directory'):
            with self.subTest(wanted=wanted):
                def fail(fd, selected=wanted):
                    role = 'directory' if stat.S_ISDIR(os.fstat(fd).st_mode) else 'file'
                    if role == selected:
                        raise OSError(errno.EIO, 'decision sync')
                    return sync(fd)
                with mock.patch.object(reconcile.os, 'fsync', side_effect=fail):
                    self.assertEqual(self.refusal()[0]['stage'], 'durable-decision')
                self.assertEqual(self.pending.read_bytes(), self.data)
                self.assertFalse((self.root / reconcile.RETIRED).exists())
                (self.root / reconcile.DECISION).unlink()

    def test_link_failure_keeps_durable_decision_and_pending(self):
        with mock.patch.object(reconcile.os, 'link', side_effect=OSError(errno.EIO, 'link')):
            errors = self.refusal()
        self.assertEqual(json.loads(errors[0]['message'])['retirement_error']['stage'], 'link-retired')
        self.assertEqual(self.pending.read_bytes(), self.data)
        self.assertEqual(json.loads((self.root / reconcile.DECISION).read_text()), self.decision)

    def test_sync_after_link_failure_keeps_both_names(self):
        sync = os.fsync
        def fail(fd):
            if stat.S_ISDIR(os.fstat(fd).st_mode) and (self.root / reconcile.RETIRED).exists():
                raise OSError(errno.EIO, 'retired directory sync')
            return sync(fd)
        with mock.patch.object(reconcile.os, 'fsync', side_effect=fail):
            errors = self.refusal()
        self.assertEqual(json.loads(errors[0]['message'])['retirement_error']['stage'],
                         'sync-retired-directory')
        self.assertEqual(self.pending.read_bytes(), self.data)
        self.assertEqual((self.root / reconcile.RETIRED).read_bytes(), self.data)

    def test_rebound_pending_is_not_unlinked(self):
        original = reconcile.pending_identity
        calls = []
        def rebind(module, directory, descriptor, links):
            calls.append(links)
            if calls == [1, 1, 2, 2]:
                self.pending.unlink()
                self.pending.write_bytes(b'changed-identity')
                self.pending.chmod(0o600)
            return original(module, directory, descriptor, links)
        with mock.patch.object(reconcile, 'pending_identity', side_effect=rebind):
            errors = self.refusal()
        self.assertEqual(json.loads(errors[0]['message'])['retirement_error']['stage'], 'check-before-unlink')
        self.assertEqual(self.pending.read_bytes(), b'changed-identity')
        self.assertEqual((self.root / reconcile.RETIRED).read_bytes(), self.data)

    def test_unlink_failure_keeps_original_and_archive(self):
        with mock.patch.object(reconcile.os, 'unlink', side_effect=OSError(errno.EIO, 'unlink')):
            errors = self.refusal()
        self.assertEqual(json.loads(errors[0]['message'])['retirement_error']['stage'], 'unlink-pending')
        self.assertEqual(self.pending.read_bytes(), self.data)
        self.assertEqual((self.root / reconcile.RETIRED).read_bytes(), self.data)

    def test_final_sync_failure_is_unknown_without_rollback(self):
        sync = os.fsync
        def fail(fd):
            if stat.S_ISDIR(os.fstat(fd).st_mode) and not self.pending.exists():
                raise OSError(errno.EIO, 'final directory sync')
            return sync(fd)
        with mock.patch.object(reconcile.os, 'fsync', side_effect=fail):
            errors = self.refusal()
        self.assertEqual(json.loads(errors[0]['message'])['retirement_error']['stage'],
                         'sync-unlinked-directory')
        self.assertFalse(self.pending.exists())
        self.assertEqual((self.root / reconcile.RETIRED).read_bytes(), self.data)
        self.refusal()  # Missing pending is not an idempotent success.

    def test_close_failure_after_unlink_refuses_acknowledgment(self):
        close = os.close
        def fail(fd):
            selected = not self.pending.exists()
            close(fd)
            if selected:
                raise OSError(errno.EIO, 'close after unlink')
        with mock.patch.object(reconcile.os, 'close', side_effect=fail):
            errors = self.refusal()
        self.assertEqual([row['stage'] for row in errors], ['close-pending', 'close-ledger'])
        self.assertFalse(self.pending.exists())
        self.assertEqual((self.root / reconcile.RETIRED).read_bytes(), self.data)

    def test_order_decision_sync_archive_sync_unlink_final_sync(self):
        sync, link, unlink = os.fsync, os.link, os.unlink
        trace = []
        def observed_sync(fd):
            trace.append('sync-dir' if stat.S_ISDIR(os.fstat(fd).st_mode) else 'sync-file')
            return sync(fd)
        def observed_link(*args, **kwargs):
            trace.append('link')
            return link(*args, **kwargs)
        def observed_unlink(*args, **kwargs):
            trace.append('unlink')
            return unlink(*args, **kwargs)
        with mock.patch.object(reconcile.os, 'fsync', side_effect=observed_sync), \
                mock.patch.object(reconcile.os, 'link', side_effect=observed_link), \
                mock.patch.object(reconcile.os, 'unlink', side_effect=observed_unlink):
            self.run_reconciliation()
        self.assertEqual(trace, ['sync-file', 'sync-dir', 'link', 'sync-dir', 'unlink', 'sync-dir'])


class CutEvidenceAdmission(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        self.root = Path(temporary.name)
        for attribute, names in (('NORMAL', reconcile.EVIDENCE_NAMES), ('REFUSAL', reconcile.REFUSAL_NAMES)):
            source = getattr(reconcile, attribute)
            target = self.root / attribute
            target.mkdir()
            for name in names:
                (target / name).write_bytes((source / name).read_bytes())
            patcher = mock.patch.object(reconcile, attribute, target)
            patcher.start()
            self.addCleanup(patcher.stop)
        self.result = reconcile.read(reconcile.NORMAL / 'witness-result.json')
        self.before = reconcile.read(reconcile.NORMAL / 'witness-before-cleanup.json')
        self.decision = dict(operation_manifest=reconcile.MANIFEST_SHA, pending_sha256=reconcile.PENDING_SHA,
                             scope='EXACT_ABORTED_PRE_ADMISSION_FIXTURE_ONLY', authority='NONE',
                             successor_admitted=False, replay_authorized=False,
                             pending_identity=self.result['pending_binding']['identity'])
        self.refresh()

    def refresh(self):
        for name in ('witness-result.json', 'outer.stdout'):
            (reconcile.NORMAL / name).write_text(json.dumps(self.result))
        (reconcile.NORMAL / 'witness-before-cleanup.json').write_text(json.dumps(self.before))
        outer = reconcile.read(reconcile.NORMAL / 'outer-result.json')
        outer['stdout_sha256'] = reconcile.sha(reconcile.NORMAL / 'outer.stdout')
        (reconcile.NORMAL / 'outer-result.json').write_text(json.dumps(outer))
        self.repin()

    def repin(self):
        self.decision['evidence_sha256'] = {
            name: reconcile.sha(reconcile.NORMAL / name) for name in reconcile.EVIDENCE_NAMES}
        self.decision['refusal_sha256'] = {
            name: reconcile.sha(reconcile.REFUSAL / name) for name in reconcile.REFUSAL_NAMES}

    def test_valid_interrupted_evidence(self):
        reconcile.verify_observations(self.decision)

    def test_closed_cut_and_refusal_rosters(self):
        for field in ('evidence_sha256', 'refusal_sha256'):
            saved = self.decision[field]
            for changed in ({}, dict(saved, unexpected='0' * 64), dict(list(saved.items())[1:])):
                with self.subTest(field=field, changed=changed):
                    self.decision[field] = changed
                    with self.assertRaisesRegex(ValueError, 'closed evidence roster'):
                        reconcile.verify_observations(self.decision)
            self.decision[field] = saved

    def test_changed_evidence_rejects(self):
        (reconcile.NORMAL / 'config.json').write_text('{}')
        with self.assertRaisesRegex(ValueError, 'evidence changed'):
            reconcile.verify_observations(self.decision)

    def test_scope_and_authority_do_not_escalate(self):
        for key, value in (('scope', 'SUCCESSOR'), ('authority', 'ALLOW'),
                           ('successor_admitted', True), ('replay_authorized', True)):
            with self.subTest(key=key), mock.patch.dict(self.decision, {key: value}):
                with self.assertRaisesRegex(ValueError, 'fixed interrupted-fixture scope'):
                    reconcile.verify_observations(self.decision)

    def test_missing_terminal_role_rejected_after_repin(self):
        del self.result['before_cleanup']['init']
        del self.before['before_cleanup']['init']
        self.refresh()
        with self.assertRaisesRegex(ValueError, 'incomplete tracked roles'):
            reconcile.verify_observations(self.decision)

    def test_cleanup_signal_cannot_supply_termination_evidence(self):
        self.result['cleanup']['signals'] = {'leader': 'SIGKILL_SENT'}
        self.refresh()
        with self.assertRaisesRegex(ValueError, 'cleanup-assisted'):
            reconcile.verify_observations(self.decision)

    def test_payload_entry_rejects(self):
        self.result['payload_entered'] = True
        self.refresh()
        with self.assertRaisesRegex(ValueError, 'wrong interrupted disposition'):
            reconcile.verify_observations(self.decision)

    def test_failed_outer_exit_rejects(self):
        path = reconcile.NORMAL / 'outer-result.json'
        outer = reconcile.read(path)
        outer['actual_exit'] = 1
        path.write_text(json.dumps(outer))
        self.repin()
        with self.assertRaisesRegex(ValueError, 'cut acknowledgment mismatch'):
            reconcile.verify_observations(self.decision)

    def test_changed_pending_readback_rejects_after_repin(self):
        (reconcile.REFUSAL / 'pending-after.json').write_text('{}')
        self.repin()
        with self.assertRaisesRegex(ValueError, 'refused pending changed'):
            reconcile.verify_observations(self.decision)

    def test_partial_handle_acquisition_rejects(self):
        self.result['unacquired_roles_unknown'] = ['init']
        self.refresh()
        with self.assertRaisesRegex(ValueError, 'incomplete tracked roles'):
            reconcile.verify_observations(self.decision)

    def test_missing_post_source_verification_rejects(self):
        self.result['post_source_and_tools_verified'] = False
        self.refresh()
        with self.assertRaisesRegex(ValueError, 'wrong interrupted disposition'):
            reconcile.verify_observations(self.decision)

    def test_preliminary_record_must_not_be_relabelled(self):
        self.before['status'] = 'PASS'
        self.refresh()
        with self.assertRaisesRegex(ValueError, 'preliminary record changed'):
            reconcile.verify_observations(self.decision)

    def test_existing_active_refusal_is_rejected(self):
        (reconcile.REFUSAL / 'active.json').write_text('{}')
        with self.assertRaisesRegex(ValueError, 'refused invocation became active'):
            reconcile.verify_observations(self.decision)

    def test_under_lock_failures_prevent_storage(self):
        (self.root / 'decision.json').write_text(json.dumps(self.decision))
        for method in ('verify_manifest', 'verify_inputs', 'verify_host'):
            with self.subTest(method=method):
                module = mock.Mock(spec=candidate)
                helper = module.helpers.return_value
                helper.hold_lock.return_value = object()
                getattr(module, method).side_effect = ValueError('admission rejected')
                with mock.patch.object(reconcile, 'ROOT', self.root), \
                        mock.patch.object(reconcile, 'verify_source_argument'), \
                        mock.patch.object(reconcile, 'verify_observations'), \
                        mock.patch.object(reconcile, 'candidate_module', return_value=module), \
                        mock.patch.object(reconcile, 'reconcile_once') as retire:
                    with self.assertRaisesRegex(ValueError, 'admission rejected'):
                        reconcile.main()
                retire.assert_not_called()


class LedgerAdmission(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        self.root = Path(temporary.name)
        for name in ('epoch', 'prior-decision', 'prior-retired', 'pending.json'):
            (self.root / name).write_text(name)
        rows = {path.name: reconcile.sha(path) for path in self.root.iterdir()}
        self.config = dict(cut=dict(ledger_files={key: value for key, value in rows.items()
                                                 if key != 'pending.json'}))
        self.decision = dict(ledger_before=rows,
                             pending_identity=candidate.metadata((self.root / 'pending.json').lstat()))
        for module, key, value in ((candidate, 'LEDGER', self.root),
                                   (reconcile, 'PENDING_SHA', rows['pending.json'])):
            patcher = mock.patch.object(module, key, value)
            patcher.start()
            self.addCleanup(patcher.stop)

    def test_exact_ledger_is_admitted(self):
        reconcile.verify_ledger_state(candidate, self.config, self.decision)

    def test_extra_record_refuses(self):
        (self.root / 'extra').write_text('unexpected')
        with self.assertRaisesRegex(ValueError, 'extra ledger record'):
            reconcile.verify_ledger_state(candidate, self.config, self.decision)

    def test_history_change_refuses(self):
        (self.root / 'prior-retired').write_text('changed')
        with self.assertRaisesRegex(ValueError, 'ledger history changed'):
            reconcile.verify_ledger_state(candidate, self.config, self.decision)

    def test_missing_record_refuses(self):
        (self.root / 'prior-retired').unlink()
        with self.assertRaisesRegex(ValueError, 'ledger roster mismatch'):
            reconcile.verify_ledger_state(candidate, self.config, self.decision)

    def test_pending_identity_change_refuses(self):
        self.decision['pending_identity'][1] = 0
        with self.assertRaisesRegex(ValueError, 'pending identity changed'):
            reconcile.verify_ledger_state(candidate, self.config, self.decision)


if __name__ == '__main__':
    unittest.main(verbosity=2)
